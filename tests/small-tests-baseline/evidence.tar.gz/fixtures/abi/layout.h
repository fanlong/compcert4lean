{
struct i12s4ci4 {
  int a:12;
  short b:4;
  char c;
  int d:4;
};
TEST4(i12s4ci4)
}
{
struct i31i15ii5 {
  int a:31;
  int b:15;
  int c;
  int d:5;
};
TEST4(i31i15ii5)
}
{
struct i7sii12 {
  int a:7;
  short b;
  int c;
  int d:12;
};
TEST4(i7sii12)
}
{
struct c1c2i20s7 {
  char a:1;
  char b:2;
  int c:20;
  short d:7;
};
TEST4(c1c2i20s7)
}
{
struct ii1ii1 {
  int a;
  int b:1;
  int c;
  int d:1;
};
TEST4(ii1ii1)
}
{
struct c7i1c3i {
  char a:7;
  int b:1;
  char c:3;
  int d;
};
TEST4(c7i1c3i)
}
{
struct s2bi11i {
  short a:2;
  _Bool b;
  int c:11;
  int d;
};
TEST4(s2bi11i)
}
{
struct s7i30s5i3 {
  short a:7;
  int b:30;
  short c:5;
  int d:3;
};
TEST4(s7i30s5i3)
}
{
struct c1s12b1i1 {
  char a:1;
  short b:12;
  _Bool c:1;
  int d:1;
};
TEST4(c1s12b1i1)
}
{
struct i15is10i15 {
  int a:15;
  int b;
  short c:10;
  int d:15;
};
TEST4(i15is10i15)
}
{
struct is1i1s1 {
  int a;
  short b:1;
  int c:1;
  short d:1;
};
TEST4(is1i1s1)
}
{
struct i15i10s10c2 {
  int a:15;
  int b:10;
  short c:10;
  char d:2;
};
TEST4(i15i10s10c2)
}
{
struct I31i4b1i9B1s {
  int :31;
  int a:4;
  _Bool b:1;
  int c:9;
  _Bool :1;
  short d;
};
TEST4(I31i4b1i9B1s)
}
{
struct c5i6i2i14 {
  char a:5;
  int b:6;
  int c:2;
  int d:14;
};
TEST4(c5i6i2i14)
}
{
struct i13b1c6s6 {
  int a:13;
  _Bool b:1;
  char c:6;
  short d:6;
};
TEST4(i13b1c6s6)
}
{
struct b1B1c3i5b {
  _Bool a:1;
  _Bool :1;
  char b:3;
  int c:5;
  _Bool d;
};
TEST4(b1B1c3i5b)
}
{
struct si9i21s2 {
  short a;
  int b:9;
  int c:21;
  short d:2;
};
TEST4(si9i21s2)
}
{
struct S0csc2c1 {
  short :0;
  char a;
  short b;
  char c:2;
  char d:1;
};
TEST4(S0csc2c1)
}
{
struct i2I2b1b1i1 {
  int a:2;
  int :2;
  _Bool b:1;
  _Bool c:1;
  int d:1;
};
TEST4(i2I2b1b1i1)
}
{
struct c2ii2b {
  char a:2;
  int b;
  int c:2;
  _Bool d;
};
TEST4(c2ii2b)
}
{
struct s2s5cc {
  short a:2;
  short b:5;
  char c;
  char d;
};
TEST4(s2s5cc)
}
{
struct C2I14b1i2ib {
  char :2;
  int :14;
  _Bool a:1;
  int b:2;
  int c;
  _Bool d;
};
TEST4(C2I14b1i2ib)
}
{
struct b1i27s7i4 {
  _Bool a:1;
  int b:27;
  short c:7;
  int d:4;
};
TEST4(b1i27s7i4)
}
{
struct cis6i15 {
  char a;
  int b;
  short c:6;
  int d:15;
};
TEST4(cis6i15)
}
{
struct s4i7c6c4 {
  short a:4;
  int b:7;
  char c:6;
  char d:4;
};
TEST4(s4i7c6c4)
}
{
struct i19sc4i22 {
  int a:19;
  short b;
  char c:4;
  int d:22;
};
TEST4(i19sc4i22)
}
{
struct b1sc4s5 {
  _Bool a:1;
  short b;
  char c:4;
  short d:5;
};
TEST4(b1sc4s5)
}
{
struct c4b1ii2 {
  char a:4;
  _Bool b:1;
  int c;
  int d:2;
};
TEST4(c4b1ii2)
}
{
struct ciic1 {
  char a;
  int b;
  int c;
  char d:1;
};
TEST4(ciic1)
}
{
struct i28b1c4c8 {
  int a:28;
  _Bool b:1;
  char c:4;
  char d:8;
};
TEST4(i28b1c4c8)
}
{
struct c1s4ci1 {
  char a:1;
  short b:4;
  char c;
  int d:1;
};
TEST4(c1s4ci1)
}
{
struct sb1b1s5 {
  short a;
  _Bool b:1;
  _Bool c:1;
  short d:5;
};
TEST4(sb1b1s5)
}
{
struct i13i2I16b1s9 {
  int a:13;
  int b:2;
  int :16;
  _Bool c:1;
  short d:9;
};
TEST4(i13i2I16b1s9)
}
{
struct ib1c5i {
  int a;
  _Bool b:1;
  char c:5;
  int d;
};
TEST4(ib1c5i)
}
{
struct s2i1b1i8 {
  short a:2;
  int b:1;
  _Bool c:1;
  int d:8;
};
TEST4(s2i1b1i8)
}
{
struct c2s6is5 {
  char a:2;
  short b:6;
  int c;
  short d:5;
};
TEST4(c2s6is5)
}
{
struct i19ci5c1 {
  int a:19;
  char b;
  int c:5;
  char d:1;
};
TEST4(i19ci5c1)
}
{
struct s3c1S10c5i5 {
  short a:3;
  char b:1;
  short :10;
  char c:5;
  int d:5;
};
TEST4(s3c1S10c5i5)
}
{
struct sI0S2s13c3i18 {
  short a;
  int :0;
  short :2;
  short b:13;
  char c:3;
  int d:18;
};
TEST4(sI0S2s13c3i18)
}
{
struct c1bic8 {
  char a:1;
  _Bool b;
  int c;
  char d:8;
};
TEST4(c1bic8)
}
{
struct s8I9b1c1S0i6 {
  short a:8;
  int :9;
  _Bool b:1;
  char c:1;
  short :0;
  int d:6;
};
TEST4(s8I9b1c1S0i6)
}
{
struct I12ss12s8i {
  int :12;
  short a;
  short b:12;
  short c:8;
  int d;
};
TEST4(I12ss12s8i)
}
{
struct ci1b1c1 {
  char a;
  int b:1;
  _Bool c:1;
  char d:1;
};
TEST4(ci1b1c1)
}
{
struct c4i3i7i17 {
  char a:4;
  int b:3;
  int c:7;
  int d:17;
};
TEST4(c4i3i7i17)
}
{
struct C8icii23 {
  char :8;
  int a;
  char b;
  int c;
  int d:23;
};
TEST4(C8icii23)
}
{
struct s14S4i2si2 {
  short a:14;
  short :4;
  int b:2;
  short c;
  int d:2;
};
TEST4(s14S4i2si2)
}
{
struct s4ici2 {
  short a:4;
  int b;
  char c;
  int d:2;
};
TEST4(s4ici2)
}
{
struct s1s5b1s {
  short a:1;
  short b:5;
  _Bool c:1;
  short d;
};
TEST4(s1s5b1s)
}
{
struct c7c1C1i25c8 {
  char a:7;
  char b:1;
  char :1;
  int c:25;
  char d:8;
};
TEST4(c7c1C1i25c8)
}
{
struct s8i28c3s12 {
  short a:8;
  int b:28;
  char c:3;
  short d:12;
};
TEST4(s8i28c3s12)
}
{
struct c4i1s2i {
  char a:4;
  int b:1;
  short c:2;
  int d;
};
TEST4(c4i1s2i)
}
{
struct s5C0s2bb1 {
  short a:5;
  char :0;
  short b:2;
  _Bool c;
  _Bool d:1;
};
TEST4(s5C0s2bb1)
}
{
struct i30I0B1si14c5 {
  int a:30;
  int :0;
  _Bool :1;
  short b;
  int c:14;
  char d:5;
};
TEST4(i30I0B1si14c5)
}
{
struct c1C4is1s13 {
  char a:1;
  char :4;
  int b;
  short c:1;
  short d:13;
};
TEST4(c1C4is1s13)
}
{
struct s8c6ic1 {
  short a:8;
  char b:6;
  int c;
  char d:1;
};
TEST4(s8c6ic1)
}
{
struct i29i1s3I0i1 {
  int a:29;
  int b:1;
  short c:3;
  int :0;
  int d:1;
};
TEST4(i29i1s3I0i1)
}
{
struct c8c4s3i8 {
  char a:8;
  char b:4;
  short c:3;
  int d:8;
};
TEST4(c8c4s3i8)
}
{
struct c2i12ic4 {
  char a:2;
  int b:12;
  int c;
  char d:4;
};
TEST4(c2i12ic4)
}
{
struct is2s12c4 {
  int a;
  short b:2;
  short c:12;
  char d:4;
};
TEST4(is2s12c4)
}
{
struct B1I3i9b1c4c6 {
  _Bool :1;
  int :3;
  int a:9;
  _Bool b:1;
  char c:4;
  char d:6;
};
TEST4(B1I3i9b1c4c6)
}
{
struct c3b1i7s4 {
  char a:3;
  _Bool b:1;
  int c:7;
  short d:4;
};
TEST4(c3b1i7s4)
}
{
struct i28i11c3s3 {
  int a:28;
  int b:11;
  char c:3;
  short d:3;
};
TEST4(i28i11c3s3)
}
{
struct s5bb1b1 {
  short a:5;
  _Bool b;
  _Bool c:1;
  _Bool d:1;
};
TEST4(s5bb1b1)
}
{
struct c1s16I32i31c6 {
  char a:1;
  short b:16;
  int :32;
  int c:31;
  char d:6;
};
TEST4(c1s16I32i31c6)
}
{
struct C0ic7i9c3 {
  char :0;
  int a;
  char b:7;
  int c:9;
  char d:3;
};
TEST4(C0ic7i9c3)
}
{
struct I0i6i2c8i4 {
  int :0;
  int a:6;
  int b:2;
  char c:8;
  int d:4;
};
TEST4(I0i6i2c8i4)
}
{
struct I7si1i19c3 {
  int :7;
  short a;
  int b:1;
  int c:19;
  char d:3;
};
TEST4(I7si1i19c3)
}
{
struct S3s16c1s11i {
  short :3;
  short a:16;
  char b:1;
  short c:11;
  int d;
};
TEST4(S3s16c1s11i)
}
{
struct s4i18I9ic6 {
  short a:4;
  int b:18;
  int :9;
  int c;
  char d:6;
};
TEST4(s4i18I9ic6)
}
{
struct bi5ii14 {
  _Bool a;
  int b:5;
  int c;
  int d:14;
};
TEST4(bi5ii14)
}
{
struct c5s5c6s13 {
  char a:5;
  short b:5;
  char c:6;
  short d:13;
};
TEST4(c5s5c6s13)
}
{
struct sb1i20c2 {
  short a;
  _Bool b:1;
  int c:20;
  char d:2;
};
TEST4(sb1i20c2)
}
{
struct i31b1i30i {
  int a:31;
  _Bool b:1;
  int c:30;
  int d;
};
TEST4(i31b1i30i)
}
{
struct i5sB1si7 {
  int a:5;
  short b;
  _Bool :1;
  short c;
  int d:7;
};
TEST4(i5sB1si7)
}
{
struct b1c2ii15 {
  _Bool a:1;
  char b:2;
  int c;
  int d:15;
};
TEST4(b1c2ii15)
}
{
struct si24b1s3 {
  short a;
  int b:24;
  _Bool c:1;
  short d:3;
};
TEST4(si24b1s3)
}
{
struct c5isb1 {
  char a:5;
  int b;
  short c;
  _Bool d:1;
};
TEST4(c5isb1)
}
{
struct c5i21i8c {
  char a:5;
  int b:21;
  int c:8;
  char d;
};
TEST4(c5i21i8c)
}
{
struct b1i1s8i29 {
  _Bool a:1;
  int b:1;
  short c:8;
  int d:29;
};
TEST4(b1i1s8i29)
}
{
struct i21c2s1i17 {
  int a:21;
  char b:2;
  short c:1;
  int d:17;
};
TEST4(i21c2s1i17)
}
{
struct c1cs9c {
  char a:1;
  char b;
  short c:9;
  char d;
};
TEST4(c1cs9c)
}
{
struct c1ii2c {
  char a:1;
  int b;
  int c:2;
  char d;
};
TEST4(c1ii2c)
}
{
struct si15i19i1 {
  short a;
  int b:15;
  int c:19;
  int d:1;
};
TEST4(si15i19i1)
}
{
struct B0b1ic3b1 {
  _Bool :0;
  _Bool a:1;
  int b;
  char c:3;
  _Bool d:1;
};
TEST4(B0b1ic3b1)
}
{
struct i4i14c1i20 {
  int a:4;
  int b:14;
  char c:1;
  int d:20;
};
TEST4(i4i14c1i20)
}
{
struct i7bc2s3 {
  int a:7;
  _Bool b;
  char c:2;
  short d:3;
};
TEST4(i7bc2s3)
}
{
struct i19I6is9c8 {
  int a:19;
  int :6;
  int b;
  short c:9;
  char d:8;
};
TEST4(i19I6is9c8)
}
{
struct ib1si4 {
  int a;
  _Bool b:1;
  short c;
  int d:4;
};
TEST4(ib1si4)
}
{
struct bi5bi16 {
  _Bool a;
  int b:5;
  _Bool c;
  int d:16;
};
TEST4(bi5bi16)
}
{
struct C4c1i4ci {
  char :4;
  char a:1;
  int b:4;
  char c;
  int d;
};
TEST4(C4c1i4ci)
}
{
struct c3b1si5 {
  char a:3;
  _Bool b:1;
  short c;
  int d:5;
};
TEST4(c3b1si5)
}
{
struct i9c4I5iB0i11 {
  int a:9;
  char b:4;
  int :5;
  int c;
  _Bool :0;
  int d:11;
};
TEST4(i9c4I5iB0i11)
}
{
struct bisi1 {
  _Bool a;
  int b;
  short c;
  int d:1;
};
TEST4(bisi1)
}
{
struct i30i13i28s2 {
  int a:30;
  int b:13;
  int c:28;
  short d:2;
};
TEST4(i30i13i28s2)
}
{
struct b1c2c2c4 {
  _Bool a:1;
  char b:2;
  char c:2;
  char d:4;
};
TEST4(b1c2c2c4)
}
{
struct ii2s14c3 {
  int a;
  int b:2;
  short c:14;
  char d:3;
};
TEST4(ii2s14c3)
}
{
struct I5s2i2sc4 {
  int :5;
  short a:2;
  int b:2;
  short c;
  char d:4;
};
TEST4(I5s2i2sc4)
}
{
struct i28sii14 {
  int a:28;
  short b;
  int c;
  int d:14;
};
TEST4(i28sii14)
}
{
struct i23B1c7i7i11 {
  int a:23;
  _Bool :1;
  char b:7;
  int c:7;
  int d:11;
};
TEST4(i23B1c7i7i11)
}
{
struct i4ib1s4 {
  int a:4;
  int b;
  _Bool c:1;
  short d:4;
};
TEST4(i4ib1s4)
}
{
struct i30s12s13s {
  int a:30;
  short b:12;
  short c:13;
  short d;
};
TEST4(i30s12s13s)
}
{
struct s15s2si9 {
  short a:15;
  short b:2;
  short c;
  int d:9;
};
TEST4(s15s2si9)
}
{
struct i7sc7i2 {
  int a:7;
  short b;
  char c:7;
  int d:2;
};
TEST4(i7sc7i2)
}
{
struct i2b1I0i11i5 {
  int a:2;
  _Bool b:1;
  int :0;
  int c:11;
  int d:5;
};
TEST4(i2b1I0i11i5)
}
{
struct i2s10s14i14 {
  int a:2;
  short b:10;
  short c:14;
  int d:14;
};
TEST4(i2s10s14i14)
}
{
struct c1c7b1s8 {
  char a:1;
  char b:7;
  _Bool c:1;
  short d:8;
};
TEST4(c1c7b1s8)
}
{
struct s3c4c2i {
  short a:3;
  char b:4;
  char c:2;
  int d;
};
TEST4(s3c4c2i)
}
{
struct i14c2c7s1 {
  int a:14;
  char b:2;
  char c:7;
  short d:1;
};
TEST4(i14c2c7s1)
}
{
struct s8s3si11 {
  short a:8;
  short b:3;
  short c;
  int d:11;
};
TEST4(s8s3si11)
}
{
struct c1b1si3 {
  char a:1;
  _Bool b:1;
  short c;
  int d:3;
};
TEST4(c1b1si3)
}
{
struct c8B1i4i2i31 {
  char a:8;
  _Bool :1;
  int b:4;
  int c:2;
  int d:31;
};
TEST4(c8B1i4i2i31)
}
{
struct s10c4s9b1 {
  short a:10;
  char b:4;
  short c:9;
  _Bool d:1;
};
TEST4(s10c4s9b1)
}
{
struct i28c4i20i8 {
  int a:28;
  char b:4;
  int c:20;
  int d:8;
};
TEST4(i28c4i20i8)
}
{
struct c1i22i4i3 {
  char a:1;
  int b:22;
  int c:4;
  int d:3;
};
TEST4(c1i22i4i3)
}
{
struct cs4i10i2 {
  char a;
  short b:4;
  int c:10;
  int d:2;
};
TEST4(cs4i10i2)
}
{
struct ci16i16i2 {
  char a;
  int b:16;
  int c:16;
  int d:2;
};
TEST4(ci16i16i2)
}
{
struct ci12i1s16 {
  char a;
  int b:12;
  int c:1;
  short d:16;
};
TEST4(ci12i1s16)
}
{
struct i19b1i14i {
  int a:19;
  _Bool b:1;
  int c:14;
  int d;
};
TEST4(i19b1i14i)
}
{
struct ii17i4i3 {
  int a;
  int b:17;
  int c:4;
  int d:3;
};
TEST4(ii17i4i3)
}
{
struct i15c2s3b {
  int a:15;
  char b:2;
  short c:3;
  _Bool d;
};
TEST4(i15c2s3b)
}
{
struct ii16ic {
  int a;
  int b:16;
  int c;
  char d;
};
TEST4(ii16ic)
}
{
struct s7i30c7i28 {
  short a:7;
  int b:30;
  char c:7;
  int d:28;
};
TEST4(s7i30c7i28)
}
{
struct i19ic2b {
  int a:19;
  int b;
  char c:2;
  _Bool d;
};
TEST4(i19ic2b)
}
{
struct c2c8ci1 {
  char a:2;
  char b:8;
  char c;
  int d:1;
};
TEST4(c2c8ci1)
}
{
struct si23i5c2 {
  short a;
  int b:23;
  int c:5;
  char d:2;
};
TEST4(si23i5c2)
}
{
struct b1I3cii {
  _Bool a:1;
  int :3;
  char b;
  int c;
  int d;
};
TEST4(b1I3cii)
}
{
struct b1cc1s {
  _Bool a:1;
  char b;
  char c:1;
  short d;
};
TEST4(b1cc1s)
}
{
struct i4bcs4 {
  int a:4;
  _Bool b;
  char c;
  short d:4;
};
TEST4(i4bcs4)
}
{
struct s2b1i17s {
  short a:2;
  _Bool b:1;
  int c:17;
  short d;
};
TEST4(s2b1i17s)
}
{
struct bi12i27s10 {
  _Bool a;
  int b:12;
  int c:27;
  short d:10;
};
TEST4(bi12i27s10)
}
{
struct s16s2b1i26 {
  short a:16;
  short b:2;
  _Bool c:1;
  int d:26;
};
TEST4(s16s2b1i26)
}
{
struct i1i6s7c2 {
  int a:1;
  int b:6;
  short c:7;
  char d:2;
};
TEST4(i1i6s7c2)
}
{
struct c2c3c4i {
  char a:2;
  char b:3;
  char c:4;
  int d;
};
TEST4(c2c3c4i)
}
{
struct i13ssi15 {
  int a:13;
  short b;
  short c;
  int d:15;
};
TEST4(i13ssi15)
}
{
struct s2b1ii4 {
  short a:2;
  _Bool b:1;
  int c;
  int d:4;
};
TEST4(s2b1ii4)
}
{
struct s6sss8 {
  short a:6;
  short b;
  short c;
  short d:8;
};
TEST4(s6sss8)
}
{
struct b1i12I0s2c7 {
  _Bool a:1;
  int b:12;
  int :0;
  short c:2;
  char d:7;
};
TEST4(b1i12I0s2c7)
}
{
struct b1cc1b1 {
  _Bool a:1;
  char b;
  char c:1;
  _Bool d:1;
};
TEST4(b1cc1b1)
}
{
struct c1sii31 {
  char a:1;
  short b;
  int c;
  int d:31;
};
TEST4(c1sii31)
}
{
struct cc1s6i23 {
  char a;
  char b:1;
  short c:6;
  int d:23;
};
TEST4(cc1s6i23)
}
{
struct s9s10b1i7 {
  short a:9;
  short b:10;
  _Bool c:1;
  int d:7;
};
TEST4(s9s10b1i7)
}
{
struct c5i5i9c8 {
  char a:5;
  int b:5;
  int c:9;
  char d:8;
};
TEST4(c5i5i9c8)
}
{
struct i7i4i4i14 {
  int a:7;
  int b:4;
  int c:4;
  int d:14;
};
TEST4(i7i4i4i14)
}
{
struct c8i1S0s6i29 {
  char a:8;
  int b:1;
  short :0;
  short c:6;
  int d:29;
};
TEST4(c8i1S0s6i29)
}
{
struct s13is16s8 {
  short a:13;
  int b;
  short c:16;
  short d:8;
};
TEST4(s13is16s8)
}
{
struct i30c1cb1 {
  int a:30;
  char b:1;
  char c;
  _Bool d:1;
};
TEST4(i30c1cb1)
}
{
struct bb1s1i3 {
  _Bool a;
  _Bool b:1;
  short c:1;
  int d:3;
};
TEST4(bb1s1i3)
}
{
struct i7ii2s4 {
  int a:7;
  int b;
  int c:2;
  short d:4;
};
TEST4(i7ii2s4)
}
{
struct i2cc3b {
  int a:2;
  char b;
  char c:3;
  _Bool d;
};
TEST4(i2cc3b)
}
{
struct b1s7i11b1 {
  _Bool a:1;
  short b:7;
  int c:11;
  _Bool d:1;
};
TEST4(b1s7i11b1)
}
{
struct s3s6i5i15 {
  short a:3;
  short b:6;
  int c:5;
  int d:15;
};
TEST4(s3s6i5i15)
}
{
struct s3s3s2c {
  short a:3;
  short b:3;
  short c:2;
  char d;
};
TEST4(s3s3s2c)
}
{
struct i1ii3c4 {
  int a:1;
  int b;
  int c:3;
  char d:4;
};
TEST4(i1ii3c4)
}
{
struct i2s5i23i5 {
  int a:2;
  short b:5;
  int c:23;
  int d:5;
};
TEST4(i2s5i23i5)
}
{
struct c5I0s4i4i21 {
  char a:5;
  int :0;
  short b:4;
  int c:4;
  int d:21;
};
TEST4(c5I0s4i4i21)
}
{
struct c4bc2I5b1 {
  char a:4;
  _Bool b;
  char c:2;
  int :5;
  _Bool d:1;
};
TEST4(c4bc2I5b1)
}
{
struct s1s10c1i10 {
  short a:1;
  short b:10;
  char c:1;
  int d:10;
};
TEST4(s1s10c1i10)
}
{
struct i21s3B1c7c {
  int a:21;
  short b:3;
  _Bool :1;
  char c:7;
  char d;
};
TEST4(i21s3B1c7c)
}
{
struct s9i11cC4i9 {
  short a:9;
  int b:11;
  char c;
  char :4;
  int d:9;
};
TEST4(s9i11cC4i9)
}
{
struct c1i2ii4 {
  char a:1;
  int b:2;
  int c;
  int d:4;
};
TEST4(c1i2ii4)
}
{
struct C1i10i32ic2 {
  char :1;
  int a:10;
  int b:32;
  int c;
  char d:2;
};
TEST4(C1i10i32ic2)
}
{
struct s7s4bs3 {
  short a:7;
  short b:4;
  _Bool c;
  short d:3;
};
TEST4(s7s4bs3)
}
{
struct ci32sc {
  char a;
  int b:32;
  short c;
  char d;
};
TEST4(ci32sc)
}
{
struct b1i5s15i1 {
  _Bool a:1;
  int b:5;
  short c:15;
  int d:1;
};
TEST4(b1i5s15i1)
}
{
struct i2s15s8s12 {
  int a:2;
  short b:15;
  short c:8;
  short d:12;
};
TEST4(i2s15s8s12)
}
{
struct S4i3i1b1s {
  short :4;
  int a:3;
  int b:1;
  _Bool c:1;
  short d;
};
TEST4(S4i3i1b1s)
}
{
struct c3i1s3i22 {
  char a:3;
  int b:1;
  short c:3;
  int d:22;
};
TEST4(c3i1s3i22)
}
{
struct i15s5c2i2 {
  int a:15;
  short b:5;
  char c:2;
  int d:2;
};
TEST4(i15s5c2i2)
}
{
struct b1i31cc6 {
  _Bool a:1;
  int b:31;
  char c;
  char d:6;
};
TEST4(b1i31cc6)
}
{
struct s8ii17I1i8 {
  short a:8;
  int b;
  int c:17;
  int :1;
  int d:8;
};
TEST4(s8ii17I1i8)
}
{
struct c2ci2b1 {
  char a:2;
  char b;
  int c:2;
  _Bool d:1;
};
TEST4(c2ci2b1)
}
{
struct ib1i20s {
  int a;
  _Bool b:1;
  int c:20;
  short d;
};
TEST4(ib1i20s)
}
{
struct s2i2s3I6s {
  short a:2;
  int b:2;
  short c:3;
  int :6;
  short d;
};
TEST4(s2i2s3I6s)
}
{
struct s13s14b1s {
  short a:13;
  short b:14;
  _Bool c:1;
  short d;
};
TEST4(s13s14b1s)
}
{
struct i29c8b1i5 {
  int a:29;
  char b:8;
  _Bool c:1;
  int d:5;
};
TEST4(i29c8b1i5)
}
{
struct b1s2i1c {
  _Bool a:1;
  short b:2;
  int c:1;
  char d;
};
TEST4(b1s2i1c)
}
{
struct b1c7s4c1 {
  _Bool a:1;
  char b:7;
  short c:4;
  char d:1;
};
TEST4(b1c7s4c1)
}
{
struct i6i12s5b {
  int a:6;
  int b:12;
  short c:5;
  _Bool d;
};
TEST4(i6i12s5b)
}
{
struct S6isB0i1i6 {
  short :6;
  int a;
  short b;
  _Bool :0;
  int c:1;
  int d:6;
};
TEST4(S6isB0i1i6)
}
{
struct i2s2i31c {
  int a:2;
  short b:2;
  int c:31;
  char d;
};
TEST4(i2s2i31c)
}
{
struct i28i13b1I8s6 {
  int a:28;
  int b:13;
  _Bool c:1;
  int :8;
  short d:6;
};
TEST4(i28i13b1I8s6)
}
{
struct i30c7s5s2 {
  int a:30;
  char b:7;
  short c:5;
  short d:2;
};
TEST4(i30c7s5s2)
}
{
struct i7ci4i14 {
  int a:7;
  char b;
  int c:4;
  int d:14;
};
TEST4(i7ci4i14)
}
{
struct cS0si6s8 {
  char a;
  short :0;
  short b;
  int c:6;
  short d:8;
};
TEST4(cS0si6s8)
}
{
struct c8s5ic {
  char a:8;
  short b:5;
  int c;
  char d;
};
TEST4(c8s5ic)
}
{
struct ic7ic {
  int a;
  char b:7;
  int c;
  char d;
};
TEST4(ic7ic)
}
{
struct i24I4i15c4i31 {
  int a:24;
  int :4;
  int b:15;
  char c:4;
  int d:31;
};
TEST4(i24I4i15c4i31)
}
{
struct i1i25i11c {
  int a:1;
  int b:25;
  int c:11;
  char d;
};
TEST4(i1i25i11c)
}
{
struct C1i3c5ci {
  char :1;
  int a:3;
  char b:5;
  char c;
  int d;
};
TEST4(C1i3c5ci)
}
{
struct b1i2i1s9 {
  _Bool a:1;
  int b:2;
  int c:1;
  short d:9;
};
TEST4(b1i2i1s9)
}
{
struct b1bc3c5 {
  _Bool a:1;
  _Bool b;
  char c:3;
  char d:5;
};
TEST4(b1bc3c5)
}
{
struct ii3C2C0c6i2 {
  int a;
  int b:3;
  char :2;
  char :0;
  char c:6;
  int d:2;
};
TEST4(ii3C2C0c6i2)
}
{
struct s6i7b1c4 {
  short a:6;
  int b:7;
  _Bool c:1;
  char d:4;
};
TEST4(s6i7b1c4)
}
{
struct ssss3 {
  short a;
  short b;
  short c;
  short d:3;
};
TEST4(ssss3)
}
{
struct ss3s4b {
  short a;
  short b:3;
  short c:4;
  _Bool d;
};
TEST4(ss3s4b)
}
{
struct iC3cc8c4 {
  int a;
  char :3;
  char b;
  char c:8;
  char d:4;
};
TEST4(iC3cc8c4)
}
{
struct i1cc5c8 {
  int a:1;
  char b;
  char c:5;
  char d:8;
};
TEST4(i1cc5c8)
}
{
struct ib1b1c5 {
  int a;
  _Bool b:1;
  _Bool c:1;
  char d:5;
};
TEST4(ib1b1c5)
}
{
struct b1s14si30 {
  _Bool a:1;
  short b:14;
  short c;
  int d:30;
};
TEST4(b1s14si30)
}
{
struct C1I0I3bi6i18i5 {
  char :1;
  int :0;
  int :3;
  _Bool a;
  int b:6;
  int c:18;
  int d:5;
};
TEST4(C1I0I3bi6i18i5)
}
{
struct i15I19c1c8c5 {
  int a:15;
  int :19;
  char b:1;
  char c:8;
  char d:5;
};
TEST4(i15I19c1c8c5)
}
{
struct i4i6ci13 {
  int a:4;
  int b:6;
  char c;
  int d:13;
};
TEST4(i4i6ci13)
}
{
struct c6I4s8i17i {
  char a:6;
  int :4;
  short b:8;
  int c:17;
  int d;
};
TEST4(c6I4s8i17i)
}
{
struct c5c1bC3i {
  char a:5;
  char b:1;
  _Bool c;
  char :3;
  int d;
};
TEST4(c5c1bC3i)
}
{
struct sb1s8i10 {
  short a;
  _Bool b:1;
  short c:8;
  int d:10;
};
TEST4(sb1s8i10)
}
{
struct i17s5s3i14 {
  int a:17;
  short b:5;
  short c:3;
  int d:14;
};
TEST4(i17s5s3i14)
}
{
struct s8c1b1b1 {
  short a:8;
  char b:1;
  _Bool c:1;
  _Bool d:1;
};
TEST4(s8c1b1b1)
}
{
struct c3S0i2c1i {
  char a:3;
  short :0;
  int b:2;
  char c:1;
  int d;
};
TEST4(c3S0i2c1i)
}
{
struct c7i2i30s2 {
  char a:7;
  int b:2;
  int c:30;
  short d:2;
};
TEST4(c7i2i30s2)
}
{
struct i1C8ss9b {
  int a:1;
  char :8;
  short b;
  short c:9;
  _Bool d;
};
TEST4(i1C8ss9b)
}
{
struct ci10c4b1 {
  char a;
  int b:10;
  char c:4;
  _Bool d:1;
};
TEST4(ci10c4b1)
}
{
struct ic2B1cC0c7 {
  int a;
  char b:2;
  _Bool :1;
  char c;
  char :0;
  char d:7;
};
TEST4(ic2B1cC0c7)
}
{
struct i5c6i3i {
  int a:5;
  char b:6;
  int c:3;
  int d;
};
TEST4(i5c6i3i)
}
{
struct i8bi7b {
  int a:8;
  _Bool b;
  int c:7;
  _Bool d;
};
TEST4(i8bi7b)
}
{
struct is3bc5 {
  int a;
  short b:3;
  _Bool c;
  char d:5;
};
TEST4(is3bc5)
}
{
struct c1I2s11c1c4 {
  char a:1;
  int :2;
  short b:11;
  char c:1;
  char d:4;
};
TEST4(c1I2s11c1c4)
}
{
struct c1i10c5c1 {
  char a:1;
  int b:10;
  char c:5;
  char d:1;
};
TEST4(c1i10c5c1)
}
{
struct i12c2i4c8 {
  int a:12;
  char b:2;
  int c:4;
  char d:8;
};
TEST4(i12c2i4c8)
}
{
struct s2i16c1i25 {
  short a:2;
  int b:16;
  char c:1;
  int d:25;
};
TEST4(s2i16c1i25)
}
{
struct iI12s4i10b1 {
  int a;
  int :12;
  short b:4;
  int c:10;
  _Bool d:1;
};
TEST4(iI12s4i10b1)
}
{
struct s4i1ii1 {
  short a:4;
  int b:1;
  int c;
  int d:1;
};
TEST4(s4i1ii1)
}
{
struct si1b1i3 {
  short a;
  int b:1;
  _Bool c:1;
  int d:3;
};
TEST4(si1b1i3)
}
{
struct sbi4c5 {
  short a;
  _Bool b;
  int c:4;
  char d:5;
};
TEST4(sbi4c5)
}
{
struct is15s7C2i {
  int a;
  short b:15;
  short c:7;
  char :2;
  int d;
};
TEST4(is15s7C2i)
}
{
struct i32c1cc6 {
  int a:32;
  char b:1;
  char c;
  char d:6;
};
TEST4(i32c1cc6)
}
{
struct b1ic7c1 {
  _Bool a:1;
  int b;
  char c:7;
  char d:1;
};
TEST4(b1ic7c1)
}
{
struct ii15ib1 {
  int a;
  int b:15;
  int c;
  _Bool d:1;
};
TEST4(ii15ib1)
}
{
struct b1i1is5 {
  _Bool a:1;
  int b:1;
  int c;
  short d:5;
};
TEST4(b1i1is5)
}
{
struct i7i9i8i1 {
  int a:7;
  int b:9;
  int c:8;
  int d:1;
};
TEST4(i7i9i8i1)
}
{
struct i3b1c3i4 {
  int a:3;
  _Bool b:1;
  char c:3;
  int d:4;
};
TEST4(i3b1c3i4)
}
{
struct i2s9i29i3 {
  int a:2;
  short b:9;
  int c:29;
  int d:3;
};
TEST4(i2s9i29i3)
}
{
struct i1c3s6s5 {
  int a:1;
  char b:3;
  short c:6;
  short d:5;
};
TEST4(i1c3s6s5)
}
{
struct c4ic6c3 {
  char a:4;
  int b;
  char c:6;
  char d:3;
};
TEST4(c4ic6c3)
}
{
struct b1i4c1c4 {
  _Bool a:1;
  int b:4;
  char c:1;
  char d:4;
};
TEST4(b1i4c1c4)
}
{
struct i23i2c6i28 {
  int a:23;
  int b:2;
  char c:6;
  int d:28;
};
TEST4(i23i2c6i28)
}
{
struct ic3sc2 {
  int a;
  char b:3;
  short c;
  char d:2;
};
TEST4(ic3sc2)
}
{
struct i32c5c3i6 {
  int a:32;
  char b:5;
  char c:3;
  int d:6;
};
TEST4(i32c5c3i6)
}
{
struct c2ic4i4 {
  char a:2;
  int b;
  char c:4;
  int d:4;
};
TEST4(c2ic4i4)
}
{
struct i12b1i13s15 {
  int a:12;
  _Bool b:1;
  int c:13;
  short d:15;
};
TEST4(i12b1i13s15)
}
{
struct b1i1s7c7 {
  _Bool a:1;
  int b:1;
  short c:7;
  char d:7;
};
TEST4(b1i1s7c7)
}
{
struct c6S1s3cc2 {
  char a:6;
  short :1;
  short b:3;
  char c;
  char d:2;
};
TEST4(c6S1s3cc2)
}
{
struct b1ii11b1 {
  _Bool a:1;
  int b;
  int c:11;
  _Bool d:1;
};
TEST4(b1ii11b1)
}
{
struct i12c6b1b1 {
  int a:12;
  char b:6;
  _Bool c:1;
  _Bool d:1;
};
TEST4(i12c6b1b1)
}
{
struct b1i6s7i {
  _Bool a:1;
  int b:6;
  short c:7;
  int d;
};
TEST4(b1i6s7i)
}
{
struct s11s16i10i {
  short a:11;
  short b:16;
  int c:10;
  int d;
};
TEST4(s11s16i10i)
}
{
struct i2i17ii12 {
  int a:2;
  int b:17;
  int c;
  int d:12;
};
TEST4(i2i17ii12)
}
{
struct i13si14c7 {
  int a:13;
  short b;
  int c:14;
  char d:7;
};
TEST4(i13si14c7)
}
{
struct c1s4s7s15 {
  char a:1;
  short b:4;
  short c:7;
  short d:15;
};
TEST4(c1s4s7s15)
}
{
struct s14c2i3i2 {
  short a:14;
  char b:2;
  int c:3;
  int d:2;
};
TEST4(s14c2i3i2)
}
{
struct ii21s6b1 {
  int a;
  int b:21;
  short c:6;
  _Bool d:1;
};
TEST4(ii21s6b1)
}
{
struct i23b1b1c4 {
  int a:23;
  _Bool b:1;
  _Bool c:1;
  char d:4;
};
TEST4(i23b1b1c4)
}
{
struct iI0I1ci15c6 {
  int a;
  int :0;
  int :1;
  char b;
  int c:15;
  char d:6;
};
TEST4(iI0I1ci15c6)
}
{
struct b1i1c8b1 {
  _Bool a:1;
  int b:1;
  char c:8;
  _Bool d:1;
};
TEST4(b1i1c8b1)
}
{
struct s5i2i11s {
  short a:5;
  int b:2;
  int c:11;
  short d;
};
TEST4(s5i2i11s)
}
{
struct i1b1c8i25 {
  int a:1;
  _Bool b:1;
  char c:8;
  int d:25;
};
TEST4(i1b1c8i25)
}
{
struct cis3c {
  char a;
  int b;
  short c:3;
  char d;
};
TEST4(cis3c)
}
{
struct ii14ii {
  int a;
  int b:14;
  int c;
  int d;
};
TEST4(ii14ii)
}
{
struct i1b1c2I1c2 {
  int a:1;
  _Bool b:1;
  char c:2;
  int :1;
  char d:2;
};
TEST4(i1b1c2I1c2)
}
{
struct c4ib1i {
  char a:4;
  int b;
  _Bool c:1;
  int d;
};
TEST4(c4ib1i)
}
{
struct b1isi4 {
  _Bool a:1;
  int b;
  short c;
  int d:4;
};
TEST4(b1isi4)
}
{
struct i16c2s12i12 {
  int a:16;
  char b:2;
  short c:12;
  int d:12;
};
TEST4(i16c2s12i12)
}
{
struct B0s1I21c2ci {
  _Bool :0;
  short a:1;
  int :21;
  char b:2;
  char c;
  int d;
};
TEST4(B0s1I21c2ci)
}
{
struct i16s1i5b1 {
  int a:16;
  short b:1;
  int c:5;
  _Bool d:1;
};
TEST4(i16s1i5b1)
}
{
struct s8ii1C0s9 {
  short a:8;
  int b;
  int c:1;
  char :0;
  short d:9;
};
TEST4(s8ii1C0s9)
}
{
struct B1i14c2si {
  _Bool :1;
  int a:14;
  char b:2;
  short c;
  int d;
};
TEST4(B1i14c2si)
}
{
struct c2i2i3s13 {
  char a:2;
  int b:2;
  int c:3;
  short d:13;
};
TEST4(c2i2i3s13)
}
{
struct ii21i9c8 {
  int a;
  int b:21;
  int c:9;
  char d:8;
};
TEST4(ii21i9c8)
}
{
struct I1I5s1b1i10s {
  int :1;
  int :5;
  short a:1;
  _Bool b:1;
  int c:10;
  short d;
};
TEST4(I1I5s1b1i10s)
}
{
struct bs6si24 {
  _Bool a;
  short b:6;
  short c;
  int d:24;
};
TEST4(bs6si24)
}
{
struct i11cc5i14 {
  int a:11;
  char b;
  char c:5;
  int d:14;
};
TEST4(i11cc5i14)
}
{
struct i7ccb1 {
  int a:7;
  char b;
  char c;
  _Bool d:1;
};
TEST4(i7ccb1)
}
{
struct i1I30i16I0bi {
  int a:1;
  int :30;
  int b:16;
  int :0;
  _Bool c;
  int d;
};
TEST4(i1I30i16I0bi)
}
{
struct ccs7s {
  char a;
  char b;
  short c:7;
  short d;
};
TEST4(ccs7s)
}
{
struct i16b1si3 {
  int a:16;
  _Bool b:1;
  short c;
  int d:3;
};
TEST4(i16b1si3)
}
{
struct s5cc1s7 {
  short a:5;
  char b;
  char c:1;
  short d:7;
};
TEST4(s5cc1s7)
}
{
struct ii4b1b1 {
  int a;
  int b:4;
  _Bool c:1;
  _Bool d:1;
};
TEST4(ii4b1b1)
}
{
struct sC0S0B1c2b1i {
  short a;
  char :0;
  short :0;
  _Bool :1;
  char b:2;
  _Bool c:1;
  int d;
};
TEST4(sC0S0B1c2b1i)
}
{
struct cc2c7s3 {
  char a;
  char b:2;
  char c:7;
  short d:3;
};
TEST4(cc2c7s3)
}
{
struct s5s14i1c3 {
  short a:5;
  short b:14;
  int c:1;
  char d:3;
};
TEST4(s5s14i1c3)
}
{
struct ic1i2i31 {
  int a;
  char b:1;
  int c:2;
  int d:31;
};
TEST4(ic1i2i31)
}
{
struct i10i2b1c8 {
  int a:10;
  int b:2;
  _Bool c:1;
  char d:8;
};
TEST4(i10i2b1c8)
}
{
struct i26ss12S11s3 {
  int a:26;
  short b;
  short c:12;
  short :11;
  short d:3;
};
TEST4(i26ss12S11s3)
}
{
struct cS9s2s4s4 {
  char a;
  short :9;
  short b:2;
  short c:4;
  short d:4;
};
TEST4(cS9s2s4s4)
}
{
struct i26s3i2i16 {
  int a:26;
  short b:3;
  int c:2;
  int d:16;
};
TEST4(i26s3i2i16)
}
{
struct b1i30b1c3 {
  _Bool a:1;
  int b:30;
  _Bool c:1;
  char d:3;
};
TEST4(b1i30b1c3)
}
{
struct i20i3ci14 {
  int a:20;
  int b:3;
  char c;
  int d:14;
};
TEST4(i20i3ci14)
}
{
struct bic2c {
  _Bool a;
  int b;
  char c:2;
  char d;
};
TEST4(bic2c)
}
{
struct i7i2s1i9 {
  int a:7;
  int b:2;
  short c:1;
  int d:9;
};
TEST4(i7i2s1i9)
}
{
struct s12sii3 {
  short a:12;
  short b;
  int c;
  int d:3;
};
TEST4(s12sii3)
}
{
struct b1i25I10i12i1 {
  _Bool a:1;
  int b:25;
  int :10;
  int c:12;
  int d:1;
};
TEST4(b1i25I10i12i1)
}
{
struct is14s16c4 {
  int a;
  short b:14;
  short c:16;
  char d:4;
};
TEST4(is14s16c4)
}
{
struct C5bcc1c2 {
  char :5;
  _Bool a;
  char b;
  char c:1;
  char d:2;
};
TEST4(C5bcc1c2)
}
{
struct B1S0b1cb1i {
  _Bool :1;
  short :0;
  _Bool a:1;
  char b;
  _Bool c:1;
  int d;
};
TEST4(B1S0b1cb1i)
}
{
struct i15c1is3 {
  int a:15;
  char b:1;
  int c;
  short d:3;
};
TEST4(i15c1is3)
}
{
struct s2s12c1s13 {
  short a:2;
  short b:12;
  char c:1;
  short d:13;
};
TEST4(s2s12c1s13)
}
{
struct i2b1c2b1 {
  int a:2;
  _Bool b:1;
  char c:2;
  _Bool d:1;
};
TEST4(i2b1c2b1)
}
{
struct i23s8C0c4s8 {
  int a:23;
  short b:8;
  char :0;
  char c:4;
  short d:8;
};
TEST4(i23s8C0c4s8)
}
{
struct i1i12cs2 {
  int a:1;
  int b:12;
  char c;
  short d:2;
};
TEST4(i1i12cs2)
}
{
struct is9c2s7 {
  int a;
  short b:9;
  char c:2;
  short d:7;
};
TEST4(is9c2s7)
}
{
struct i32s1si {
  int a:32;
  short b:1;
  short c;
  int d;
};
TEST4(i32s1si)
}
{
struct I0b1i7i2I0i {
  int :0;
  _Bool a:1;
  int b:7;
  int c:2;
  int :0;
  int d;
};
TEST4(I0b1i7i2I0i)
}
{
struct i7C0s2b1i29 {
  int a:7;
  char :0;
  short b:2;
  _Bool c:1;
  int d:29;
};
TEST4(i7C0s2b1i29)
}
{
struct S5i32i13c6b1 {
  short :5;
  int a:32;
  int b:13;
  char c:6;
  _Bool d:1;
};
TEST4(S5i32i13c6b1)
}
{
struct c2I0i15I0sc8 {
  char a:2;
  int :0;
  int b:15;
  int :0;
  short c;
  char d:8;
};
TEST4(c2I0i15I0sc8)
}
{
struct s4c7i11i2 {
  short a:4;
  char b:7;
  int c:11;
  int d:2;
};
TEST4(s4c7i11i2)
}
{
struct s1b1c4i9 {
  short a:1;
  _Bool b:1;
  char c:4;
  int d:9;
};
TEST4(s1b1c4i9)
}
{
struct ii3i8c3 {
  int a;
  int b:3;
  int c:8;
  char d:3;
};
TEST4(ii3i8c3)
}
{
struct s3i7c4i1 {
  short a:3;
  int b:7;
  char c:4;
  int d:1;
};
TEST4(s3i7c4i1)
}
{
struct i11s3c7i15 {
  int a:11;
  short b:3;
  char c:7;
  int d:15;
};
TEST4(i11s3c7i15)
}
{
struct i4ib1c {
  int a:4;
  int b;
  _Bool c:1;
  char d;
};
TEST4(i4ib1c)
}
{
struct c4C0i14b1C0i {
  char a:4;
  char :0;
  int b:14;
  _Bool c:1;
  char :0;
  int d;
};
TEST4(c4C0i14b1C0i)
}
{
struct i12i28bc7 {
  int a:12;
  int b:28;
  _Bool c;
  char d:7;
};
TEST4(i12i28bc7)
}
{
struct i16s4i4b1 {
  int a:16;
  short b:4;
  int c:4;
  _Bool d:1;
};
TEST4(i16s4i4b1)
}
{
struct ic8s3c2 {
  int a;
  char b:8;
  short c:3;
  char d:2;
};
TEST4(ic8s3c2)
}
{
struct S1b1i13c1S0i {
  short :1;
  _Bool a:1;
  int b:13;
  char c:1;
  short :0;
  int d;
};
TEST4(S1b1i13c1S0i)
}
{
struct b1c7i32s11 {
  _Bool a:1;
  char b:7;
  int c:32;
  short d:11;
};
TEST4(b1c7i32s11)
}
{
struct i2s2si6 {
  int a:2;
  short b:2;
  short c;
  int d:6;
};
TEST4(i2s2si6)
}
{
struct b1S0c6I3bi14 {
  _Bool a:1;
  short :0;
  char b:6;
  int :3;
  _Bool c;
  int d:14;
};
TEST4(b1S0c6I3bi14)
}
{
struct i13I0C0b1i15c3 {
  int a:13;
  int :0;
  char :0;
  _Bool b:1;
  int c:15;
  char d:3;
};
TEST4(i13I0C0b1i15c3)
}
{
struct ss1c1c5 {
  short a;
  short b:1;
  char c:1;
  char d:5;
};
TEST4(ss1c1c5)
}
{
struct i2i27s2s14 {
  int a:2;
  int b:27;
  short c:2;
  short d:14;
};
TEST4(i2i27s2s14)
}
{
struct c8s6i30s15 {
  char a:8;
  short b:6;
  int c:30;
  short d:15;
};
TEST4(c8s6i30s15)
}
{
struct c6si2c5 {
  char a:6;
  short b;
  int c:2;
  char d:5;
};
TEST4(c6si2c5)
}
{
struct I28i14I1i31b1i18 {
  int :28;
  int a:14;
  int :1;
  int b:31;
  _Bool c:1;
  int d:18;
};
TEST4(I28i14I1i31b1i18)
}
{
struct i1sc1b {
  int a:1;
  short b;
  char c:1;
  _Bool d;
};
TEST4(i1sc1b)
}
{
struct s14i2c1s1 {
  short a:14;
  int b:2;
  char c:1;
  short d:1;
};
TEST4(s14i2c1s1)
}
{
struct cI9s3S0c7s {
  char a;
  int :9;
  short b:3;
  short :0;
  char c:7;
  short d;
};
TEST4(cI9s3S0c7s)
}
{
struct i8ic4c {
  int a:8;
  int b;
  char c:4;
  char d;
};
TEST4(i8ic4c)
}
{
struct S14c1ii27i17 {
  short :14;
  char a:1;
  int b;
  int c:27;
  int d:17;
};
TEST4(S14c1ii27i17)
}
{
struct c1b1s8s {
  char a:1;
  _Bool b:1;
  short c:8;
  short d;
};
TEST4(c1b1s8s)
}
{
struct i6i5s8i14 {
  int a:6;
  int b:5;
  short c:8;
  int d:14;
};
TEST4(i6i5s8i14)
}
{
struct c7i2i1c1 {
  char a:7;
  int b:2;
  int c:1;
  char d:1;
};
TEST4(c7i2i1c1)
}
{
struct s4s3s5I0s {
  short a:4;
  short b:3;
  short c:5;
  int :0;
  short d;
};
TEST4(s4s3s5I0s)
}
{
struct i8cc3c7 {
  int a:8;
  char b;
  char c:3;
  char d:7;
};
TEST4(i8cc3c7)
}
{
struct cB1i29b1i4 {
  char a;
  _Bool :1;
  int b:29;
  _Bool c:1;
  int d:4;
};
TEST4(cB1i29b1i4)
}
{
struct i2s11s10i2 {
  int a:2;
  short b:11;
  short c:10;
  int d:2;
};
TEST4(i2s11s10i2)
}
{
struct sc1s1s13 {
  short a;
  char b:1;
  short c:1;
  short d:13;
};
TEST4(sc1s1s13)
}
{
struct si7i8i30 {
  short a;
  int b:7;
  int c:8;
  int d:30;
};
TEST4(si7i8i30)
}
{
struct b1b1i3c {
  _Bool a:1;
  _Bool b:1;
  int c:3;
  char d;
};
TEST4(b1b1i3c)
}
{
struct is4i2c {
  int a;
  short b:4;
  int c:2;
  char d;
};
TEST4(is4i2c)
}
{
struct c4i4i9S0b1 {
  char a:4;
  int b:4;
  int c:9;
  short :0;
  _Bool d:1;
};
TEST4(c4i4i9S0b1)
}
{
struct c1i32s8I1i9 {
  char a:1;
  int b:32;
  short c:8;
  int :1;
  int d:9;
};
TEST4(c1i32s8I1i9)
}
{
struct c8i8s3I0I0s12 {
  char a:8;
  int b:8;
  short c:3;
  int :0;
  int :0;
  short d:12;
};
TEST4(c8i8s3I0I0s12)
}
{
struct c1c5i22I12I23i {
  char a:1;
  char b:5;
  int c:22;
  int :12;
  int :23;
  int d;
};
TEST4(c1c5i22I12I23i)
}
{
struct i28s14cs {
  int a:28;
  short b:14;
  char c;
  short d;
};
TEST4(i28s14cs)
}
{
struct s11s5i14i {
  short a:11;
  short b:5;
  int c:14;
  int d;
};
TEST4(s11s5i14i)
}
{
struct c5s2c1c1 {
  char a:5;
  short b:2;
  char c:1;
  char d:1;
};
TEST4(c5s2c1c1)
}
{
struct ii5i14s5 {
  int a;
  int b:5;
  int c:14;
  short d:5;
};
TEST4(ii5i14s5)
}
{
struct c2i10i25I0B1I1I7s7 {
  char a:2;
  int b:10;
  int c:25;
  int :0;
  _Bool :1;
  int :1;
  int :7;
  short d:7;
};
TEST4(c2i10i25I0B1I1I7s7)
}
{
struct s14i7i1s8 {
  short a:14;
  int b:7;
  int c:1;
  short d:8;
};
TEST4(s14i7i1s8)
}
{
struct cc3i32C0c5 {
  char a;
  char b:3;
  int c:32;
  char :0;
  char d:5;
};
TEST4(cc3i32C0c5)
}
{
struct b1s5ic3 {
  _Bool a:1;
  short b:5;
  int c;
  char d:3;
};
TEST4(b1s5ic3)
}
{
struct C0i22s1i14s5 {
  char :0;
  int a:22;
  short b:1;
  int c:14;
  short d:5;
};
TEST4(C0i22s1i14s5)
}
{
struct i4i1c1s {
  int a:4;
  int b:1;
  char c:1;
  short d;
};
TEST4(i4i1c1s)
}
{
struct S0iii32i {
  short :0;
  int a;
  int b;
  int c:32;
  int d;
};
TEST4(S0iii32i)
}
{
struct ib1c8c4 {
  int a;
  _Bool b:1;
  char c:8;
  char d:4;
};
TEST4(ib1c8c4)
}
{
struct i2s11i12i1 {
  int a:2;
  short b:11;
  int c:12;
  int d:1;
};
TEST4(i2s11i12i1)
}
{
struct i2i14i14i30 {
  int a:2;
  int b:14;
  int c:14;
  int d:30;
};
TEST4(i2i14i14i30)
}
{
struct i4c7i6I0c3 {
  int a:4;
  char b:7;
  int c:6;
  int :0;
  char d:3;
};
TEST4(i4c7i6I0c3)
}
{
struct is14s1b1 {
  int a;
  short b:14;
  short c:1;
  _Bool d:1;
};
TEST4(is14s1b1)
}
{
struct i8i1s16c8 {
  int a:8;
  int b:1;
  short c:16;
  char d:8;
};
TEST4(i8i1s16c8)
}
{
struct c3i2s3s13 {
  char a:3;
  int b:2;
  short c:3;
  short d:13;
};
TEST4(c3i2s3s13)
}
{
struct i29I0i2c1c5 {
  int a:29;
  int :0;
  int b:2;
  char c:1;
  char d:5;
};
TEST4(i29I0i2c1c5)
}
{
struct i19i22i23I0i1 {
  int a:19;
  int b:22;
  int c:23;
  int :0;
  int d:1;
};
TEST4(i19i22i23I0i1)
}
{
struct S0s3scC6s8 {
  short :0;
  short a:3;
  short b;
  char c;
  char :6;
  short d:8;
};
TEST4(S0s3scC6s8)
}
{
struct i7i7C1s15i5 {
  int a:7;
  int b:7;
  char :1;
  short c:15;
  int d:5;
};
TEST4(i7i7C1s15i5)
}
{
struct I1b1ii4i7 {
  int :1;
  _Bool a:1;
  int b;
  int c:4;
  int d:7;
};
TEST4(I1b1ii4i7)
}
{
struct ci16i7i {
  char a;
  int b:16;
  int c:7;
  int d;
};
TEST4(ci16i7i)
}
{
struct ic1b1c6 {
  int a;
  char b:1;
  _Bool c:1;
  char d:6;
};
TEST4(ic1b1c6)
}
{
struct b1cc3c {
  _Bool a:1;
  char b;
  char c:3;
  char d;
};
TEST4(b1cc3c)
}
{
struct i7s5ci5 {
  int a:7;
  short b:5;
  char c;
  int d:5;
};
TEST4(i7s5ci5)
}
{
struct c3i21i27c5 {
  char a:3;
  int b:21;
  int c:27;
  char d:5;
};
TEST4(c3i21i27c5)
}
{
struct s3i13s7i {
  short a:3;
  int b:13;
  short c:7;
  int d;
};
TEST4(s3i13s7i)
}
{
struct i3S15ii6s7 {
  int a:3;
  short :15;
  int b;
  int c:6;
  short d:7;
};
TEST4(i3S15ii6s7)
}
{
struct i7i3cs8 {
  int a:7;
  int b:3;
  char c;
  short d:8;
};
TEST4(i7i3cs8)
}
{
struct isci23 {
  int a;
  short b;
  char c;
  int d:23;
};
TEST4(isci23)
}
{
struct cs14cb1 {
  char a;
  short b:14;
  char c;
  _Bool d:1;
};
TEST4(cs14cb1)
}
{
struct c8c6cb {
  char a:8;
  char b:6;
  char c;
  _Bool d;
};
TEST4(c8c6cb)
}
{
struct c5ic2i14 {
  char a:5;
  int b;
  char c:2;
  int d:14;
};
TEST4(c5ic2i14)
}
{
struct iis3i2 {
  int a;
  int b;
  short c:3;
  int d:2;
};
TEST4(iis3i2)
}
{
struct i5b1c2I15i7 {
  int a:5;
  _Bool b:1;
  char c:2;
  int :15;
  int d:7;
};
TEST4(i5b1c2I15i7)
}
{
struct s6C0i1ib1 {
  short a:6;
  char :0;
  int b:1;
  int c;
  _Bool d:1;
};
TEST4(s6C0i1ib1)
}
{
struct c8ii19i2 {
  char a:8;
  int b;
  int c:19;
  int d:2;
};
TEST4(c8ii19i2)
}
{
struct i17b1s8i {
  int a:17;
  _Bool b:1;
  short c:8;
  int d;
};
TEST4(i17b1s8i)
}
{
struct c1i4b1s6 {
  char a:1;
  int b:4;
  _Bool c:1;
  short d:6;
};
TEST4(c1i4b1s6)
}
{
struct c7s6cI8c1 {
  char a:7;
  short b:6;
  char c;
  int :8;
  char d:1;
};
TEST4(c7s6cI8c1)
}
{
struct i1i12i5c4 {
  int a:1;
  int b:12;
  int c:5;
  char d:4;
};
TEST4(i1i12i5c4)
}
{
struct ii11S16ci {
  int a;
  int b:11;
  short :16;
  char c;
  int d;
};
TEST4(ii11S16ci)
}
{
struct sis8i31 {
  short a;
  int b;
  short c:8;
  int d:31;
};
TEST4(sis8i31)
}
{
struct ib1s5s14 {
  int a;
  _Bool b:1;
  short c:5;
  short d:14;
};
TEST4(ib1s5s14)
}
{
struct i2c3s7b {
  int a:2;
  char b:3;
  short c:7;
  _Bool d;
};
TEST4(i2c3s7b)
}
{
struct b1i6c3b {
  _Bool a:1;
  int b:6;
  char c:3;
  _Bool d;
};
TEST4(b1i6c3b)
}
{
struct I0b1s9c2c {
  int :0;
  _Bool a:1;
  short b:9;
  char c:2;
  char d;
};
TEST4(I0b1s9c2c)
}
{
struct b1s7i3i31 {
  _Bool a:1;
  short b:7;
  int c:3;
  int d:31;
};
TEST4(b1s7i3i31)
}
{
struct s3ii9i2 {
  short a:3;
  int b;
  int c:9;
  int d:2;
};
TEST4(s3ii9i2)
}
{
struct cI29i27iI0b1 {
  char a;
  int :29;
  int b:27;
  int c;
  int :0;
  _Bool d:1;
};
TEST4(cI29i27iI0b1)
}
{
struct b1ssI14s5 {
  _Bool a:1;
  short b;
  short c;
  int :14;
  short d:5;
};
TEST4(b1ssI14s5)
}
{
struct csi2s {
  char a;
  short b;
  int c:2;
  short d;
};
TEST4(csi2s)
}
{
struct I5bs10c8s7 {
  int :5;
  _Bool a;
  short b:10;
  char c:8;
  short d:7;
};
TEST4(I5bs10c8s7)
}
{
struct c7i1I28i15I0C0i6 {
  char a:7;
  int b:1;
  int :28;
  int c:15;
  int :0;
  char :0;
  int d:6;
};
TEST4(c7i1I28i15I0C0i6)
}
{
struct i2i16s5b1 {
  int a:2;
  int b:16;
  short c:5;
  _Bool d:1;
};
TEST4(i2i16s5b1)
}
{
struct ib1i2i {
  int a;
  _Bool b:1;
  int c:2;
  int d;
};
TEST4(ib1i2i)
}
{
struct c8b1i26I0c1 {
  char a:8;
  _Bool b:1;
  int c:26;
  int :0;
  char d:1;
};
TEST4(c8b1i26I0c1)
}
{
struct i10c1sc1 {
  int a:10;
  char b:1;
  short c;
  char d:1;
};
TEST4(i10c1sc1)
}
{
struct i2i4c8I12s9 {
  int a:2;
  int b:4;
  char c:8;
  int :12;
  short d:9;
};
TEST4(i2i4c8I12s9)
}
{
struct C0c2i9i4b1 {
  char :0;
  char a:2;
  int b:9;
  int c:4;
  _Bool d:1;
};
TEST4(C0c2i9i4b1)
}
{
struct C0ic2ib1 {
  char :0;
  int a;
  char b:2;
  int c;
  _Bool d:1;
};
TEST4(C0ic2ib1)
}
{
struct s4s5i2i {
  short a:4;
  short b:5;
  int c:2;
  int d;
};
TEST4(s4s5i2i)
}
{
struct i25c3i11c {
  int a:25;
  char b:3;
  int c:11;
  char d;
};
TEST4(i25c3i11c)
}
{
struct i17i8i25c {
  int a:17;
  int b:8;
  int c:25;
  char d;
};
TEST4(i17i8i25c)
}
{
struct I3is5c4c6 {
  int :3;
  int a;
  short b:5;
  char c:4;
  char d:6;
};
TEST4(I3is5c4c6)
}
{
struct c7i7s16s {
  char a:7;
  int b:7;
  short c:16;
  short d;
};
TEST4(c7i7s16s)
}
{
struct sc5i1i11 {
  short a;
  char b:5;
  int c:1;
  int d:11;
};
TEST4(sc5i1i11)
}
{
struct i14s7s11s7 {
  int a:14;
  short b:7;
  short c:11;
  short d:7;
};
TEST4(i14s7s11s7)
}
{
struct ci1c1c1 {
  char a;
  int b:1;
  char c:1;
  char d:1;
};
TEST4(ci1c1c1)
}
{
struct s12C1s7c5s11 {
  short a:12;
  char :1;
  short b:7;
  char c:5;
  short d:11;
};
TEST4(s12C1s7c5s11)
}
{
struct i9cC2ss8 {
  int a:9;
  char b;
  char :2;
  short c;
  short d:8;
};
TEST4(i9cC2ss8)
}
{
struct c2cb1s16 {
  char a:2;
  char b;
  _Bool c:1;
  short d:16;
};
TEST4(c2cb1s16)
}
{
struct b1S0s12b1i6 {
  _Bool a:1;
  short :0;
  short b:12;
  _Bool c:1;
  int d:6;
};
TEST4(b1S0s12b1i6)
}
{
struct i14i14i9s1 {
  int a:14;
  int b:14;
  int c:9;
  short d:1;
};
TEST4(i14i14i9s1)
}
{
struct cc6cB0i7 {
  char a;
  char b:6;
  char c;
  _Bool :0;
  int d:7;
};
TEST4(cc6cB0i7)
}
{
struct I0b1i32c8b1 {
  int :0;
  _Bool a:1;
  int b:32;
  char c:8;
  _Bool d:1;
};
TEST4(I0b1i32c8b1)
}
{
struct i1i4I0s4i16 {
  int a:1;
  int b:4;
  int :0;
  short c:4;
  int d:16;
};
TEST4(i1i4I0s4i16)
}
{
struct c3I0B1c4sb {
  char a:3;
  int :0;
  _Bool :1;
  char b:4;
  short c;
  _Bool d;
};
TEST4(c3I0B1c4sb)
}
{
struct i25i6i5s1 {
  int a:25;
  int b:6;
  int c:5;
  short d:1;
};
TEST4(i25i6i5s1)
}
{
struct i1ic6s1 {
  int a:1;
  int b;
  char c:6;
  short d:1;
};
TEST4(i1ic6s1)
}
{
struct i3b1s7s5 {
  int a:3;
  _Bool b:1;
  short c:7;
  short d:5;
};
TEST4(i3b1s7s5)
}
{
struct i2s13i13s4 {
  int a:2;
  short b:13;
  int c:13;
  short d:4;
};
TEST4(i2s13i13s4)
}
{
struct iii11s {
  int a;
  int b;
  int c:11;
  short d;
};
TEST4(iii11s)
}
{
struct i2s2i27s1 {
  int a:2;
  short b:2;
  int c:27;
  short d:1;
};
TEST4(i2s2i27s1)
}
{
struct si1i22i1 {
  short a;
  int b:1;
  int c:22;
  int d:1;
};
TEST4(si1i22i1)
}
{
struct s7I2b1c7i29 {
  short a:7;
  int :2;
  _Bool b:1;
  char c:7;
  int d:29;
};
TEST4(s7I2b1c7i29)
}
{
struct C0i11I0B0ii2c3 {
  char :0;
  int a:11;
  int :0;
  _Bool :0;
  int b;
  int c:2;
  char d:3;
};
TEST4(C0i11I0B0ii2c3)
}
{
struct cb1I7i8i22 {
  char a;
  _Bool b:1;
  int :7;
  int c:8;
  int d:22;
};
TEST4(cb1I7i8i22)
}
{
struct s12b1bi {
  short a:12;
  _Bool b:1;
  _Bool c;
  int d;
};
TEST4(s12b1bi)
}
{
struct I1i11c5s9C0i24 {
  int :1;
  int a:11;
  char b:5;
  short c:9;
  char :0;
  int d:24;
};
TEST4(I1i11c5s9C0i24)
}
{
struct b1i32cc3 {
  _Bool a:1;
  int b:32;
  char c;
  char d:3;
};
TEST4(b1i32cc3)
}
{
struct c2c2c4i5 {
  char a:2;
  char b:2;
  char c:4;
  int d:5;
};
TEST4(c2c2c4i5)
}
{
struct C5c6I22c3I0sI0i {
  char :5;
  char a:6;
  int :22;
  char b:3;
  int :0;
  short c;
  int :0;
  int d;
};
TEST4(C5c6I22c3I0sI0i)
}
{
struct c8c2i2i10 {
  char a:8;
  char b:2;
  int c:2;
  int d:10;
};
TEST4(c8c2i2i10)
}
{
struct s10I0s6i12s3 {
  short a:10;
  int :0;
  short b:6;
  int c:12;
  short d:3;
};
TEST4(s10I0s6i12s3)
}
{
struct s1i3is2 {
  short a:1;
  int b:3;
  int c;
  short d:2;
};
TEST4(s1i3is2)
}
{
struct b1s1i27I26c {
  _Bool a:1;
  short b:1;
  int c:27;
  int :26;
  char d;
};
TEST4(b1s1i27I26c)
}
{
struct i12i22ss6 {
  int a:12;
  int b:22;
  short c;
  short d:6;
};
TEST4(i12i22ss6)
}
{
struct s7i21ii27 {
  short a:7;
  int b:21;
  int c;
  int d:27;
};
TEST4(s7i21ii27)
}
{
struct i1c1i15C0b {
  int a:1;
  char b:1;
  int c:15;
  char :0;
  _Bool d;
};
TEST4(i1c1i15C0b)
}
{
struct c5s5c3c5 {
  char a:5;
  short b:5;
  char c:3;
  char d:5;
};
TEST4(c5s5c3c5)
}
{
struct b1c4bs2 {
  _Bool a:1;
  char b:4;
  _Bool c;
  short d:2;
};
TEST4(b1c4bs2)
}
{
struct ii1b1c8 {
  int a;
  int b:1;
  _Bool c:1;
  char d:8;
};
TEST4(ii1b1c8)
}
{
struct c4c5si31 {
  char a:4;
  char b:5;
  short c;
  int d:31;
};
TEST4(c4c5si31)
}
{
struct ss13ss1 {
  short a;
  short b:13;
  short c;
  short d:1;
};
TEST4(ss13ss1)
}
{
struct s8C1C0s4iC7i15 {
  short a:8;
  char :1;
  char :0;
  short b:4;
  int c;
  char :7;
  int d:15;
};
TEST4(s8C1C0s4iC7i15)
}
{
struct I0i12b1i28i5 {
  int :0;
  int a:12;
  _Bool b:1;
  int c:28;
  int d:5;
};
TEST4(I0i12b1i28i5)
}
{
struct i2s5s15s12 {
  int a:2;
  short b:5;
  short c:15;
  short d:12;
};
TEST4(i2s5s15s12)
}
{
struct s5s11i6i1 {
  short a:5;
  short b:11;
  int c:6;
  int d:1;
};
TEST4(s5s11i6i1)
}
{
struct i2s2s4s5 {
  int a:2;
  short b:2;
  short c:4;
  short d:5;
};
TEST4(i2s2s4s5)
}
{
struct s4i5sc8 {
  short a:4;
  int b:5;
  short c;
  char d:8;
};
TEST4(s4i5sc8)
}
{
struct s3i22i1i20 {
  short a:3;
  int b:22;
  int c:1;
  int d:20;
};
TEST4(s3i22i1i20)
}
{
struct c4iic5 {
  char a:4;
  int b;
  int c;
  char d:5;
};
TEST4(c4iic5)
}
{
struct s7i25i12i2 {
  short a:7;
  int b:25;
  int c:12;
  int d:2;
};
TEST4(s7i25i12i2)
}
{
struct b1i13s1I0i2 {
  _Bool a:1;
  int b:13;
  short c:1;
  int :0;
  int d:2;
};
TEST4(b1i13s1I0i2)
}
{
struct s5c6s5b1 {
  short a:5;
  char b:6;
  short c:5;
  _Bool d:1;
};
TEST4(s5c6s5b1)
}
{
struct b1c1b1c1 {
  _Bool a:1;
  char b:1;
  _Bool c:1;
  char d:1;
};
TEST4(b1c1b1c1)
}
{
struct i24i1is {
  int a:24;
  int b:1;
  int c;
  short d;
};
TEST4(i24i1is)
}
{
struct c1S0ii3s {
  char a:1;
  short :0;
  int b;
  int c:3;
  short d;
};
TEST4(c1S0ii3s)
}
{
struct c6i11c5i5 {
  char a:6;
  int b:11;
  char c:5;
  int d:5;
};
TEST4(c6i11c5i5)
}
{
struct i7i24I19b1i1 {
  int a:7;
  int b:24;
  int :19;
  _Bool c:1;
  int d:1;
};
TEST4(i7i24I19b1i1)
}
{
struct c1i4s13s1 {
  char a:1;
  int b:4;
  short c:13;
  short d:1;
};
TEST4(c1i4s13s1)
}
{
struct ib1S15i2S4i13 {
  int a;
  _Bool b:1;
  short :15;
  int c:2;
  short :4;
  int d:13;
};
TEST4(ib1S15i2S4i13)
}
{
struct s7c5s5s12 {
  short a:7;
  char b:5;
  short c:5;
  short d:12;
};
TEST4(s7c5s5s12)
}
{
struct s1c4i1b1 {
  short a:1;
  char b:4;
  int c:1;
  _Bool d:1;
};
TEST4(s1c4i1b1)
}
{
struct i2cs4i11 {
  int a:2;
  char b;
  short c:4;
  int d:11;
};
TEST4(i2cs4i11)
}
{
struct i7c7sc {
  int a:7;
  char b:7;
  short c;
  char d;
};
TEST4(i7c7sc)
}
{
struct iI1c2s4s6 {
  int a;
  int :1;
  char b:2;
  short c:4;
  short d:6;
};
TEST4(iI1c2s4s6)
}
{
struct b1iI3b1b1 {
  _Bool a:1;
  int b;
  int :3;
  _Bool c:1;
  _Bool d:1;
};
TEST4(b1iI3b1b1)
}
{
struct I7c2i1i2s {
  int :7;
  char a:2;
  int b:1;
  int c:2;
  short d;
};
TEST4(I7c2i1i2s)
}
{
struct i1c1is10 {
  int a:1;
  char b:1;
  int c;
  short d:10;
};
TEST4(i1c1is10)
}
{
struct s1bis {
  short a:1;
  _Bool b;
  int c;
  short d;
};
TEST4(s1bis)
}
{
struct I1C0i17s11i22i {
  int :1;
  char :0;
  int a:17;
  short b:11;
  int c:22;
  int d;
};
TEST4(I1C0i17s11i22i)
}
{
struct b1i13i2s15 {
  _Bool a:1;
  int b:13;
  int c:2;
  short d:15;
};
TEST4(b1i13i2s15)
}
{
struct ib1s4s1 {
  int a;
  _Bool b:1;
  short c:4;
  short d:1;
};
TEST4(ib1s4s1)
}
{
struct c5i5i13S11i {
  char a:5;
  int b:5;
  int c:13;
  short :11;
  int d;
};
TEST4(c5i5i13S11i)
}
{
struct b1b1c7b1 {
  _Bool a:1;
  _Bool b:1;
  char c:7;
  _Bool d:1;
};
TEST4(b1b1c7b1)
}
{
struct c1ci9c7 {
  char a:1;
  char b;
  int c:9;
  char d:7;
};
TEST4(c1ci9c7)
}
{
struct i1b1s2i21 {
  int a:1;
  _Bool b:1;
  short c:2;
  int d:21;
};
TEST4(i1b1s2i21)
}
{
struct i31s5I0S0c5c {
  int a:31;
  short b:5;
  int :0;
  short :0;
  char c:5;
  char d;
};
TEST4(i31s5I0S0c5c)
}
{
struct b1i29cI3c {
  _Bool a:1;
  int b:29;
  char c;
  int :3;
  char d;
};
TEST4(b1i29cI3c)
}
{
struct s8c5si14 {
  short a:8;
  char b:5;
  short c;
  int d:14;
};
TEST4(s8c5si14)
}
{
struct iS4I0ii1i {
  int a;
  short :4;
  int :0;
  int b;
  int c:1;
  int d;
};
TEST4(iS4I0ii1i)
}
{
struct ss16i4b1 {
  short a;
  short b:16;
  int c:4;
  _Bool d:1;
};
TEST4(ss16i4b1)
}
{
struct s9c2c5I29c1 {
  short a:9;
  char b:2;
  char c:5;
  int :29;
  char d:1;
};
TEST4(s9c2c5I29c1)
}
{
struct cs9c7c8 {
  char a;
  short b:9;
  char c:7;
  char d:8;
};
TEST4(cs9c7c8)
}
{
struct S6i20s6i3s4 {
  short :6;
  int a:20;
  short b:6;
  int c:3;
  short d:4;
};
TEST4(S6i20s6i3s4)
}
{
struct c2i15i2i32 {
  char a:2;
  int b:15;
  int c:2;
  int d:32;
};
TEST4(c2i15i2i32)
}
{
struct i1ii27i15 {
  int a:1;
  int b;
  int c:27;
  int d:15;
};
TEST4(i1ii27i15)
}
{
struct iiI0s2c3 {
  int a;
  int b;
  int :0;
  short c:2;
  char d:3;
};
TEST4(iiI0s2c3)
}
{
struct s3i7i2c3 {
  short a:3;
  int b:7;
  int c:2;
  char d:3;
};
TEST4(s3i7i2c3)
}
{
struct iC2C0ss2c1 {
  int a;
  char :2;
  char :0;
  short b;
  short c:2;
  char d:1;
};
TEST4(iC2C0ss2c1)
}
{
struct i2b1s10i1 {
  int a:2;
  _Bool b:1;
  short c:10;
  int d:1;
};
TEST4(i2b1s10i1)
}
{
struct c2b1i3i20 {
  char a:2;
  _Bool b:1;
  int c:3;
  int d:20;
};
TEST4(c2b1i3i20)
}
{
struct i8c4s3i16 {
  int a:8;
  char b:4;
  short c:3;
  int d:16;
};
TEST4(i8c4s3i16)
}
{
struct ii6s5i {
  int a;
  int b:6;
  short c:5;
  int d;
};
TEST4(ii6s5i)
}
{
struct i26s9c5c5 {
  int a:26;
  short b:9;
  char c:5;
  char d:5;
};
TEST4(i26s9c5c5)
}
{
struct c6ii2i6 {
  char a:6;
  int b;
  int c:2;
  int d:6;
};
TEST4(c6ii2i6)
}
{
struct i28isc8 {
  int a:28;
  int b;
  short c;
  char d:8;
};
TEST4(i28isc8)
}
{
struct s15s10i2i {
  short a:15;
  short b:10;
  int c:2;
  int d;
};
TEST4(s15s10i2i)
}
{
struct i8i4i19i32 {
  int a:8;
  int b:4;
  int c:19;
  int d:32;
};
TEST4(i8i4i19i32)
}
{
struct c1ci6i {
  char a:1;
  char b;
  int c:6;
  int d;
};
TEST4(c1ci6i)
}
{
struct i2s9cs8 {
  int a:2;
  short b:9;
  char c;
  short d:8;
};
TEST4(i2s9cs8)
}
{
struct i5i10s9c1 {
  int a:5;
  int b:10;
  short c:9;
  char d:1;
};
TEST4(i5i10s9c1)
}
{
struct s7i2s5i2 {
  short a:7;
  int b:2;
  short c:5;
  int d:2;
};
TEST4(s7i2s5i2)
}
{
struct i30c2bc3 {
  int a:30;
  char b:2;
  _Bool c;
  char d:3;
};
TEST4(i30c2bc3)
}
{
struct si10iI1b1 {
  short a;
  int b:10;
  int c;
  int :1;
  _Bool d:1;
};
TEST4(si10iI1b1)
}
{
struct B1cii6i26 {
  _Bool :1;
  char a;
  int b;
  int c:6;
  int d:26;
};
TEST4(B1cii6i26)
}
{
struct C0b1i3B1I0c2i7 {
  char :0;
  _Bool a:1;
  int b:3;
  _Bool :1;
  int :0;
  char c:2;
  int d:7;
};
TEST4(C0b1i3B1I0c2i7)
}
{
struct s2B1c8i30i11 {
  short a:2;
  _Bool :1;
  char b:8;
  int c:30;
  int d:11;
};
TEST4(s2B1c8i30i11)
}
{
struct i29c5i11c7 {
  int a:29;
  char b:5;
  int c:11;
  char d:7;
};
TEST4(i29c5i11c7)
}
{
struct i32b1ci {
  int a:32;
  _Bool b:1;
  char c;
  int d;
};
TEST4(i32b1ci)
}
{
struct b1i1c7i11 {
  _Bool a:1;
  int b:1;
  char c:7;
  int d:11;
};
TEST4(b1i1c7i11)
}
{
struct c5i2cb1 {
  char a:5;
  int b:2;
  char c;
  _Bool d:1;
};
TEST4(c5i2cb1)
}
{
struct s8S12i5S4i12b1 {
  short a:8;
  short :12;
  int b:5;
  short :4;
  int c:12;
  _Bool d:1;
};
TEST4(s8S12i5S4i12b1)
}
{
struct ib1c6B0s4 {
  int a;
  _Bool b:1;
  char c:6;
  _Bool :0;
  short d:4;
};
TEST4(ib1c6B0s4)
}
{
struct c4ib1c8 {
  char a:4;
  int b;
  _Bool c:1;
  char d:8;
};
TEST4(c4ib1c8)
}
{
struct s12i14i10i6 {
  short a:12;
  int b:14;
  int c:10;
  int d:6;
};
TEST4(s12i14i10i6)
}
{
struct ii20s1i6 {
  int a;
  int b:20;
  short c:1;
  int d:6;
};
TEST4(ii20s1i6)
}
{
struct c1b1b1c {
  char a:1;
  _Bool b:1;
  _Bool c:1;
  char d;
};
TEST4(c1b1b1c)
}
{
struct i5b1s2i {
  int a:5;
  _Bool b:1;
  short c:2;
  int d;
};
TEST4(i5b1s2i)
}
{
struct s2c3i2c1 {
  short a:2;
  char b:3;
  int c:2;
  char d:1;
};
TEST4(s2c3i2c1)
}
{
struct i5ci1i19 {
  int a:5;
  char b;
  int c:1;
  int d:19;
};
TEST4(i5ci1i19)
}
{
struct is4C8s6i {
  int a;
  short b:4;
  char :8;
  short c:6;
  int d;
};
TEST4(is4C8s6i)
}
{
struct bb1ii1 {
  _Bool a;
  _Bool b:1;
  int c;
  int d:1;
};
TEST4(bb1ii1)
}
{
struct c4s9i3c4 {
  char a:4;
  short b:9;
  int c:3;
  char d:4;
};
TEST4(c4s9i3c4)
}
{
struct c3i17i14b {
  char a:3;
  int b:17;
  int c:14;
  _Bool d;
};
TEST4(c3i17i14b)
}
{
struct c4s3s1S2c3 {
  char a:4;
  short b:3;
  short c:1;
  short :2;
  char d:3;
};
TEST4(c4s3s1S2c3)
}
{
struct i13s14i19i5 {
  int a:13;
  short b:14;
  int c:19;
  int d:5;
};
TEST4(i13s14i19i5)
}
{
struct ii15i22i1 {
  int a;
  int b:15;
  int c:22;
  int d:1;
};
TEST4(ii15i22i1)
}
{
struct c6is3i26 {
  char a:6;
  int b;
  short c:3;
  int d:26;
};
TEST4(c6is3i26)
}
{
struct i2s6i1s8 {
  int a:2;
  short b:6;
  int c:1;
  short d:8;
};
TEST4(i2s6i1s8)
}
{
struct i4c2s2i {
  int a:4;
  char b:2;
  short c:2;
  int d;
};
TEST4(i4c2s2i)
}
{
struct i11i4cs3 {
  int a:11;
  int b:4;
  char c;
  short d:3;
};
TEST4(i11i4cs3)
}
{
struct i9i14s11s {
  int a:9;
  int b:14;
  short c:11;
  short d;
};
TEST4(i9i14s11s)
}
{
struct c7si1S7i1 {
  char a:7;
  short b;
  int c:1;
  short :7;
  int d:1;
};
TEST4(c7si1S7i1)
}
{
struct c6cc1b {
  char a:6;
  char b;
  char c:1;
  _Bool d;
};
TEST4(c6cc1b)
}
{
struct sc3b1s {
  short a;
  char b:3;
  _Bool c:1;
  short d;
};
TEST4(sc3b1s)
}
{
struct ci11i2c2 {
  char a;
  int b:11;
  int c:2;
  char d:2;
};
TEST4(ci11i2c2)
}
{
struct ii19sc2 {
  int a;
  int b:19;
  short c;
  char d:2;
};
TEST4(ii19sc2)
}
{
struct cc3ii1 {
  char a;
  char b:3;
  int c;
  int d:1;
};
TEST4(cc3ii1)
}
{
struct i30i3i2i6 {
  int a:30;
  int b:3;
  int c:2;
  int d:6;
};
TEST4(i30i3i2i6)
}
{
struct c7b1I13is5 {
  char a:7;
  _Bool b:1;
  int :13;
  int c;
  short d:5;
};
TEST4(c7b1I13is5)
}
{
struct I0i2i2C4S3ic5 {
  int :0;
  int a:2;
  int b:2;
  char :4;
  short :3;
  int c;
  char d:5;
};
TEST4(I0i2i2C4S3ic5)
}
{
struct i18isI5b1 {
  int a:18;
  int b;
  short c;
  int :5;
  _Bool d:1;
};
TEST4(i18isI5b1)
}
{
struct iis4i14 {
  int a;
  int b;
  short c:4;
  int d:14;
};
TEST4(iis4i14)
}
{
struct c1i10bs9 {
  char a:1;
  int b:10;
  _Bool c;
  short d:9;
};
TEST4(c1i10bs9)
}
{
struct sb1c4b1 {
  short a;
  _Bool b:1;
  char c:4;
  _Bool d:1;
};
TEST4(sb1c4b1)
}
{
struct b1i13i7i19 {
  _Bool a:1;
  int b:13;
  int c:7;
  int d:19;
};
TEST4(b1i13i7i19)
}
{
struct c1i7is1 {
  char a:1;
  int b:7;
  int c;
  short d:1;
};
TEST4(c1i7is1)
}
{
struct I16s3i1i5s6 {
  int :16;
  short a:3;
  int b:1;
  int c:5;
  short d:6;
};
TEST4(I16s3i1i5s6)
}
{
struct c8sc7b {
  char a:8;
  short b;
  char c:7;
  _Bool d;
};
TEST4(c8sc7b)
}
{
struct cs1b1c3 {
  char a;
  short b:1;
  _Bool c:1;
  char d:3;
};
TEST4(cs1b1c3)
}
{
struct i12b1c5S3s5 {
  int a:12;
  _Bool b:1;
  char c:5;
  short :3;
  short d:5;
};
TEST4(i12b1c5S3s5)
}
{
struct s15is13b1 {
  short a:15;
  int b;
  short c:13;
  _Bool d:1;
};
TEST4(s15is13b1)
}
{
struct c7is5s12 {
  char a:7;
  int b;
  short c:5;
  short d:12;
};
TEST4(c7is5s12)
}
{
struct b1b1cs4 {
  _Bool a:1;
  _Bool b:1;
  char c;
  short d:4;
};
TEST4(b1b1cs4)
}
{
struct c1cs1s3 {
  char a:1;
  char b;
  short c:1;
  short d:3;
};
TEST4(c1cs1s3)
}
{
struct i23sis6 {
  int a:23;
  short b;
  int c;
  short d:6;
};
TEST4(i23sis6)
}
{
struct I3C2i7i9c1i8 {
  int :3;
  char :2;
  int a:7;
  int b:9;
  char c:1;
  int d:8;
};
TEST4(I3C2i7i9c1i8)
}
{
struct c1b1c4i19 {
  char a:1;
  _Bool b:1;
  char c:4;
  int d:19;
};
TEST4(c1b1c4i19)
}
{
struct i15c1i9c3 {
  int a:15;
  char b:1;
  int c:9;
  char d:3;
};
TEST4(i15c1i9c3)
}
{
struct si4i6c4 {
  short a;
  int b:4;
  int c:6;
  char d:4;
};
TEST4(si4i6c4)
}
{
struct c7I3ii14s8 {
  char a:7;
  int :3;
  int b;
  int c:14;
  short d:8;
};
TEST4(c7I3ii14s8)
}
{
struct i27i8c6c5 {
  int a:27;
  int b:8;
  char c:6;
  char d:5;
};
TEST4(i27i8c6c5)
}
{
struct i31i5i13i7 {
  int a:31;
  int b:5;
  int c:13;
  int d:7;
};
TEST4(i31i5i13i7)
}
{
struct i2s9i6s2 {
  int a:2;
  short b:9;
  int c:6;
  short d:2;
};
TEST4(i2s9i6s2)
}
{
struct i2c2i6b {
  int a:2;
  char b:2;
  int c:6;
  _Bool d;
};
TEST4(i2c2i6b)
}
{
struct S10i6i6C6i1i3 {
  short :10;
  int a:6;
  int b:6;
  char :6;
  int c:1;
  int d:3;
};
TEST4(S10i6i6C6i1i3)
}
{
struct i13c1cc3 {
  int a:13;
  char b:1;
  char c;
  char d:3;
};
TEST4(i13c1cc3)
}
{
struct is15i4I0i19 {
  int a;
  short b:15;
  int c:4;
  int :0;
  int d:19;
};
TEST4(is15i4I0i19)
}
{
struct bc2i15s11 {
  _Bool a;
  char b:2;
  int c:15;
  short d:11;
};
TEST4(bc2i15s11)
}
{
struct bC7I0cc3s5 {
  _Bool a;
  char :7;
  int :0;
  char b;
  char c:3;
  short d:5;
};
TEST4(bC7I0cc3s5)
}
{
struct s13iis6 {
  short a:13;
  int b;
  int c;
  short d:6;
};
TEST4(s13iis6)
}
{
struct i28S2bs4i32 {
  int a:28;
  short :2;
  _Bool b;
  short c:4;
  int d:32;
};
TEST4(i28S2bs4i32)
}
{
struct cC8i1C6i12b {
  char a;
  char :8;
  int b:1;
  char :6;
  int c:12;
  _Bool d;
};
TEST4(cC8i1C6i12b)
}
{
struct iii3s3 {
  int a;
  int b;
  int c:3;
  short d:3;
};
TEST4(iii3s3)
}
{
struct c6c7s7i22 {
  char a:6;
  char b:7;
  short c:7;
  int d:22;
};
TEST4(c6c7s7i22)
}
{
struct I20i2iss7 {
  int :20;
  int a:2;
  int b;
  short c;
  short d:7;
};
TEST4(I20i2iss7)
}
{
struct cci26c {
  char a;
  char b;
  int c:26;
  char d;
};
TEST4(cci26c)
}
{
struct i4c1is {
  int a:4;
  char b:1;
  int c;
  short d;
};
TEST4(i4c1is)
}
{
struct i10i3i13c5 {
  int a:10;
  int b:3;
  int c:13;
  char d:5;
};
TEST4(i10i3i13c5)
}
{
struct i28s16b1b1 {
  int a:28;
  short b:16;
  _Bool c:1;
  _Bool d:1;
};
TEST4(i28s16b1b1)
}
{
struct iiii3 {
  int a;
  int b;
  int c;
  int d:3;
};
TEST4(iiii3)
}
{
struct i13si9i2 {
  int a:13;
  short b;
  int c:9;
  int d:2;
};
TEST4(i13si9i2)
}
{
struct s6i6i22s5 {
  short a:6;
  int b:6;
  int c:22;
  short d:5;
};
TEST4(s6i6i22s5)
}
{
struct c7b1S8s6S3I6i2 {
  char a:7;
  _Bool b:1;
  short :8;
  short c:6;
  short :3;
  int :6;
  int d:2;
};
TEST4(c7b1S8s6S3I6i2)
}
{
struct i5i5si11 {
  int a:5;
  int b:5;
  short c;
  int d:11;
};
TEST4(i5i5si11)
}
{
struct iI2s14i12c4 {
  int a;
  int :2;
  short b:14;
  int c:12;
  char d:4;
};
TEST4(iI2s14i12c4)
}
{
struct is5c1b {
  int a;
  short b:5;
  char c:1;
  _Bool d;
};
TEST4(is5c1b)
}
{
struct iC1c5i32i {
  int a;
  char :1;
  char b:5;
  int c:32;
  int d;
};
TEST4(iC1c5i32i)
}
{
struct c6c3is9 {
  char a:6;
  char b:3;
  int c;
  short d:9;
};
TEST4(c6c3is9)
}
{
struct ici15b1 {
  int a;
  char b;
  int c:15;
  _Bool d:1;
};
TEST4(ici15b1)
}
{
struct i11s5b1i17 {
  int a:11;
  short b:5;
  _Bool c:1;
  int d:17;
};
TEST4(i11s5b1i17)
}
{
struct i12s5i10i13 {
  int a:12;
  short b:5;
  int c:10;
  int d:13;
};
TEST4(i12s5i10i13)
}
{
struct i22c3s1s2 {
  int a:22;
  char b:3;
  short c:1;
  short d:2;
};
TEST4(i22c3s1s2)
}
{
struct i1b1i3s9 {
  int a:1;
  _Bool b:1;
  int c:3;
  short d:9;
};
TEST4(i1b1i3s9)
}
{
struct i2i2i18s1 {
  int a:2;
  int b:2;
  int c:18;
  short d:1;
};
TEST4(i2i2i18s1)
}
{
struct bi1i1i {
  _Bool a;
  int b:1;
  int c:1;
  int d;
};
TEST4(bi1i1i)
}
{
struct c1i1i14i1 {
  char a:1;
  int b:1;
  int c:14;
  int d:1;
};
TEST4(c1i1i14i1)
}
{
struct s6b1i1i {
  short a:6;
  _Bool b:1;
  int c:1;
  int d;
};
TEST4(s6b1i1i)
}
{
struct s2C0s1b1B1b {
  short a:2;
  char :0;
  short b:1;
  _Bool c:1;
  _Bool :1;
  _Bool d;
};
TEST4(s2C0s1b1B1b)
}
{
struct I0I1s4ii2s16 {
  int :0;
  int :1;
  short a:4;
  int b;
  int c:2;
  short d:16;
};
TEST4(I0I1s4ii2s16)
}
{
struct C4is14bi4 {
  char :4;
  int a;
  short b:14;
  _Bool c;
  int d:4;
};
TEST4(C4is14bi4)
}
{
struct c6I7C0c6i18s1 {
  char a:6;
  int :7;
  char :0;
  char b:6;
  int c:18;
  short d:1;
};
TEST4(c6I7C0c6i18s1)
}
{
struct s5c2i20c6 {
  short a:5;
  char b:2;
  int c:20;
  char d:6;
};
TEST4(s5c2i20c6)
}
{
struct s15s4ii {
  short a:15;
  short b:4;
  int c;
  int d;
};
TEST4(s15s4ii)
}
{
struct c4s2i28i14 {
  char a:4;
  short b:2;
  int c:28;
  int d:14;
};
TEST4(c4s2i28i14)
}
{
struct ic8i29C0i {
  int a;
  char b:8;
  int c:29;
  char :0;
  int d;
};
TEST4(ic8i29C0i)
}
{
struct s1ii15i31 {
  short a:1;
  int b;
  int c:15;
  int d:31;
};
TEST4(s1ii15i31)
}
{
struct I0I12si2s5s9 {
  int :0;
  int :12;
  short a;
  int b:2;
  short c:5;
  short d:9;
};
TEST4(I0I12si2s5s9)
}
{
struct c1C7b1S3i2s4 {
  char a:1;
  char :7;
  _Bool b:1;
  short :3;
  int c:2;
  short d:4;
};
TEST4(c1C7b1S3i2s4)
}
{
struct c3i13i25c1 {
  char a:3;
  int b:13;
  int c:25;
  char d:1;
};
TEST4(c3i13i25c1)
}
{
struct i24C0cc7I0s7 {
  int a:24;
  char :0;
  char b;
  char c:7;
  int :0;
  short d:7;
};
TEST4(i24C0cc7I0s7)
}
{
struct S10i5I26i26b1i {
  short :10;
  int a:5;
  int :26;
  int b:26;
  _Bool c:1;
  int d;
};
TEST4(S10i5I26i26b1i)
}
{
struct s12I15ss2s5 {
  short a:12;
  int :15;
  short b;
  short c:2;
  short d:5;
};
TEST4(s12I15ss2s5)
}
{
struct I5ii1b1b {
  int :5;
  int a;
  int b:1;
  _Bool c:1;
  _Bool d;
};
TEST4(I5ii1b1b)
}
{
struct I14i11C1s1i4c {
  int :14;
  int a:11;
  char :1;
  short b:1;
  int c:4;
  char d;
};
TEST4(I14i11C1s1i4c)
}
{
struct i29s8c3c4 {
  int a:29;
  short b:8;
  char c:3;
  char d:4;
};
TEST4(i29s8c3c4)
}
{
struct c4s2s1i15 {
  char a:4;
  short b:2;
  short c:1;
  int d:15;
};
TEST4(c4s2s1i15)
}
{
struct ii9s2s1 {
  int a;
  int b:9;
  short c:2;
  short d:1;
};
TEST4(ii9s2s1)
}
{
struct i28i11i4i30 {
  int a:28;
  int b:11;
  int c:4;
  int d:30;
};
TEST4(i28i11i4i30)
}
{
struct s9si1i28 {
  short a:9;
  short b;
  int c:1;
  int d:28;
};
TEST4(s9si1i28)
}
{
struct c7s2C7I0c1b1 {
  char a:7;
  short b:2;
  char :7;
  int :0;
  char c:1;
  _Bool d:1;
};
TEST4(c7s2C7I0c1b1)
}
{
struct c5i11ii30 {
  char a:5;
  int b:11;
  int c;
  int d:30;
};
TEST4(c5i11ii30)
}
{
struct i2ii7b1 {
  int a:2;
  int b;
  int c:7;
  _Bool d:1;
};
TEST4(i2ii7b1)
}
{
struct S10b1i4i1c6 {
  short :10;
  _Bool a:1;
  int b:4;
  int c:1;
  char d:6;
};
TEST4(S10b1i4i1c6)
}
{
struct cs9s14s9 {
  char a;
  short b:9;
  short c:14;
  short d:9;
};
TEST4(cs9s14s9)
}
{
struct s1i3b1i5 {
  short a:1;
  int b:3;
  _Bool c:1;
  int d:5;
};
TEST4(s1i3b1i5)
}
{
struct cbI27c3c2 {
  char a;
  _Bool b;
  int :27;
  char c:3;
  char d:2;
};
TEST4(cbI27c3c2)
}
{
struct i7b1c3i28 {
  int a:7;
  _Bool b:1;
  char c:3;
  int d:28;
};
TEST4(i7b1c3i28)
}
{
struct i2i22s8i2 {
  int a:2;
  int b:22;
  short c:8;
  int d:2;
};
TEST4(i2i22s8i2)
}
{
struct i12c7I0C5s2i28 {
  int a:12;
  char b:7;
  int :0;
  char :5;
  short c:2;
  int d:28;
};
TEST4(i12c7I0C5s2i28)
}
{
struct b1iss3 {
  _Bool a:1;
  int b;
  short c;
  short d:3;
};
TEST4(b1iss3)
}
{
struct i1c5c1s2 {
  int a:1;
  char b:5;
  char c:1;
  short d:2;
};
TEST4(i1c5c1s2)
}
{
struct bi6i27b {
  _Bool a;
  int b:6;
  int c:27;
  _Bool d;
};
TEST4(bi6i27b)
}
{
struct c4c5sc {
  char a:4;
  char b:5;
  short c;
  char d;
};
TEST4(c4c5sc)
}
{
struct c2ii1c4 {
  char a:2;
  int b;
  int c:1;
  char d:4;
};
TEST4(c2ii1c4)
}
{
struct isi13S3b1 {
  int a;
  short b;
  int c:13;
  short :3;
  _Bool d:1;
};
TEST4(isi13S3b1)
}
{
struct i23i20ii1 {
  int a:23;
  int b:20;
  int c;
  int d:1;
};
TEST4(i23i20ii1)
}
{
struct i2b1s1b {
  int a:2;
  _Bool b:1;
  short c:1;
  _Bool d;
};
TEST4(i2b1s1b)
}
{
struct ic1c3s2 {
  int a;
  char b:1;
  char c:3;
  short d:2;
};
TEST4(ic1c3s2)
}
{
struct b1iI7c4i4 {
  _Bool a:1;
  int b;
  int :7;
  char c:4;
  int d:4;
};
TEST4(b1iI7c4i4)
}
{
struct S4ci13i4s1 {
  short :4;
  char a;
  int b:13;
  int c:4;
  short d:1;
};
TEST4(S4ci13i4s1)
}
{
struct i13i8b1i2 {
  int a:13;
  int b:8;
  _Bool c:1;
  int d:2;
};
TEST4(i13i8b1i2)
}
{
struct c5b1i10i20 {
  char a:5;
  _Bool b:1;
  int c:10;
  int d:20;
};
TEST4(c5b1i10i20)
}
{
struct i8ci4B0c2 {
  int a:8;
  char b;
  int c:4;
  _Bool :0;
  char d:2;
};
TEST4(i8ci4B0c2)
}
{
struct b1i8ii2 {
  _Bool a:1;
  int b:8;
  int c;
  int d:2;
};
TEST4(b1i8ii2)
}
{
struct i6c5i18i3 {
  int a:6;
  char b:5;
  int c:18;
  int d:3;
};
TEST4(i6c5i18i3)
}
{
struct c6i26i11c8 {
  char a:6;
  int b:26;
  int c:11;
  char d:8;
};
TEST4(c6i26i11c8)
}
{
struct I0i2b1i9b1 {
  int :0;
  int a:2;
  _Bool b:1;
  int c:9;
  _Bool d:1;
};
TEST4(I0i2b1i9b1)
}
{
struct s2i9B1s1b1 {
  short a:2;
  int b:9;
  _Bool :1;
  short c:1;
  _Bool d:1;
};
TEST4(s2i9B1s1b1)
}
{
struct ii6b1i {
  int a;
  int b:6;
  _Bool c:1;
  int d;
};
TEST4(ii6b1i)
}
{
struct I4si22c1c1 {
  int :4;
  short a;
  int b:22;
  char c:1;
  char d:1;
};
TEST4(I4si22c1c1)
}
{
struct iis4i1 {
  int a;
  int b;
  short c:4;
  int d:1;
};
TEST4(iis4i1)
}
{
struct i4i2C0I4i1b1 {
  int a:4;
  int b:2;
  char :0;
  int :4;
  int c:1;
  _Bool d:1;
};
TEST4(i4i2C0I4i1b1)
}
{
struct b1ci20i {
  _Bool a:1;
  char b;
  int c:20;
  int d;
};
TEST4(b1ci20i)
}
{
struct ciis1 {
  char a;
  int b;
  int c;
  short d:1;
};
TEST4(ciis1)
}
{
struct C2s2s14i4s4 {
  char :2;
  short a:2;
  short b:14;
  int c:4;
  short d:4;
};
TEST4(C2s2s14i4s4)
}
{
struct s1s1c6S3i13 {
  short a:1;
  short b:1;
  char c:6;
  short :3;
  int d:13;
};
TEST4(s1s1c6S3i13)
}
{
struct s2s11ib1 {
  short a:2;
  short b:11;
  int c;
  _Bool d:1;
};
TEST4(s2s11ib1)
}
{
struct s9S8s14s2c4 {
  short a:9;
  short :8;
  short b:14;
  short c:2;
  char d:4;
};
TEST4(s9S8s14s2c4)
}
{
struct bc4i22i5 {
  _Bool a;
  char b:4;
  int c:22;
  int d:5;
};
TEST4(bc4i22i5)
}
{
struct i1ii9s6 {
  int a:1;
  int b;
  int c:9;
  short d:6;
};
TEST4(i1ii9s6)
}
{
struct i20ic8i15 {
  int a:20;
  int b;
  char c:8;
  int d:15;
};
TEST4(i20ic8i15)
}
{
struct i2c7is {
  int a:2;
  char b:7;
  int c;
  short d;
};
TEST4(i2c7is)
}
{
struct s16i6c1i8 {
  short a:16;
  int b:6;
  char c:1;
  int d:8;
};
TEST4(s16i6c1i8)
}
{
struct i2is8c1 {
  int a:2;
  int b;
  short c:8;
  char d:1;
};
TEST4(i2is8c1)
}
{
struct i8s3I12i6i6 {
  int a:8;
  short b:3;
  int :12;
  int c:6;
  int d:6;
};
TEST4(i8s3I12i6i6)
}
{
struct i1c5ii {
  int a:1;
  char b:5;
  int c;
  int d;
};
TEST4(i1c5ii)
}
{
struct ii17i2b1 {
  int a;
  int b:17;
  int c:2;
  _Bool d:1;
};
TEST4(ii17i2b1)
}
{
struct ib1b1s10 {
  int a;
  _Bool b:1;
  _Bool c:1;
  short d:10;
};
TEST4(ib1b1s10)
}
{
struct s8c1b1C4i {
  short a:8;
  char b:1;
  _Bool c:1;
  char :4;
  int d;
};
TEST4(s8c1b1C4i)
}
{
struct s16I0s8ib1 {
  short a:16;
  int :0;
  short b:8;
  int c;
  _Bool d:1;
};
TEST4(s16I0s8ib1)
}
{
struct s16c1b1s9 {
  short a:16;
  char b:1;
  _Bool c:1;
  short d:9;
};
TEST4(s16c1b1s9)
}
{
struct I0cii20c5 {
  int :0;
  char a;
  int b;
  int c:20;
  char d:5;
};
TEST4(I0cii20c5)
}
{
struct bc7c5i {
  _Bool a;
  char b:7;
  char c:5;
  int d;
};
TEST4(bc7c5i)
}
{
struct s7b1ii10 {
  short a:7;
  _Bool b:1;
  int c;
  int d:10;
};
TEST4(s7b1ii10)
}
{
struct i25C1S0c2s6i7 {
  int a:25;
  char :1;
  short :0;
  char b:2;
  short c:6;
  int d:7;
};
TEST4(i25C1S0c2s6i7)
}
{
struct i28s12c5b1 {
  int a:28;
  short b:12;
  char c:5;
  _Bool d:1;
};
TEST4(i28s12c5b1)
}
{
struct i15i5i2s4 {
  int a:15;
  int b:5;
  int c:2;
  short d:4;
};
TEST4(i15i5i2s4)
}
{
struct ciI6ii9 {
  char a;
  int b;
  int :6;
  int c;
  int d:9;
};
TEST4(ciI6ii9)
}
{
struct i2s7ib1 {
  int a:2;
  short b:7;
  int c;
  _Bool d:1;
};
TEST4(i2s7ib1)
}
{
struct i6S11c6s8I6i3 {
  int a:6;
  short :11;
  char b:6;
  short c:8;
  int :6;
  int d:3;
};
TEST4(i6S11c6s8I6i3)
}
{
struct c7C1c5ss8 {
  char a:7;
  char :1;
  char b:5;
  short c;
  short d:8;
};
TEST4(c7C1c5ss8)
}
{
struct i5s8i25c2 {
  int a:5;
  short b:8;
  int c:25;
  char d:2;
};
TEST4(i5s8i25c2)
}
{
struct s4s3ci1 {
  short a:4;
  short b:3;
  char c;
  int d:1;
};
TEST4(s4s3ci1)
}
{
struct is2c1s6 {
  int a;
  short b:2;
  char c:1;
  short d:6;
};
TEST4(is2c1s6)
}
{
struct s1i9c3c8 {
  short a:1;
  int b:9;
  char c:3;
  char d:8;
};
TEST4(s1i9c3c8)
}
{
struct i2c3i19s6 {
  int a:2;
  char b:3;
  int c:19;
  short d:6;
};
TEST4(i2c3i19s6)
}
{
struct i4c2s1c {
  int a:4;
  char b:2;
  short c:1;
  char d;
};
TEST4(i4c2s1c)
}
{
struct s1ci27s {
  short a:1;
  char b;
  int c:27;
  short d;
};
TEST4(s1ci27s)
}
{
struct c7c1s3c2 {
  char a:7;
  char b:1;
  short c:3;
  char d:2;
};
TEST4(c7c1s3c2)
}
{
struct c4i3s2I2i5 {
  char a:4;
  int b:3;
  short c:2;
  int :2;
  int d:5;
};
TEST4(c4i3s2I2i5)
}
{
struct i2c1c1c3 {
  int a:2;
  char b:1;
  char c:1;
  char d:3;
};
TEST4(i2c1c1c3)
}
{
struct sci5c5 {
  short a;
  char b;
  int c:5;
  char d:5;
};
TEST4(sci5c5)
}
{
struct c7c1c3i {
  char a:7;
  char b:1;
  char c:3;
  int d;
};
TEST4(c7c1c3i)
}
{
struct I0i13i28i13s2 {
  int :0;
  int a:13;
  int b:28;
  int c:13;
  short d:2;
};
TEST4(I0i13i28i13s2)
}
{
struct c1bS0i5b1 {
  char a:1;
  _Bool b;
  short :0;
  int c:5;
  _Bool d:1;
};
TEST4(c1bS0i5b1)
}
{
struct bS0i4cc {
  _Bool a;
  short :0;
  int b:4;
  char c;
  char d;
};
TEST4(bS0i4cc)
}
{
struct i15si6c7 {
  int a:15;
  short b;
  int c:6;
  char d:7;
};
TEST4(i15si6c7)
}
{
struct i6i15c3i {
  int a:6;
  int b:15;
  char c:3;
  int d;
};
TEST4(i6i15c3i)
}
{
struct ic4i29i {
  int a;
  char b:4;
  int c:29;
  int d;
};
TEST4(ic4i29i)
}
{
struct c8s4b1b1 {
  char a:8;
  short b:4;
  _Bool c:1;
  _Bool d:1;
};
TEST4(c8s4b1b1)
}
{
struct s3i11s10c {
  short a:3;
  int b:11;
  short c:10;
  char d;
};
TEST4(s3i11s10c)
}
{
struct c3c2cs3 {
  char a:3;
  char b:2;
  char c;
  short d:3;
};
TEST4(c3c2cs3)
}
{
struct c6i5i10s {
  char a:6;
  int b:5;
  int c:10;
  short d;
};
TEST4(c6i5i10s)
}
{
struct s2b1i14s2 {
  short a:2;
  _Bool b:1;
  int c:14;
  short d:2;
};
TEST4(s2b1i14s2)
}
{
struct bb1i2C3s {
  _Bool a;
  _Bool b:1;
  int c:2;
  char :3;
  short d;
};
TEST4(bb1i2C3s)
}
{
struct b1i4c1i {
  _Bool a:1;
  int b:4;
  char c:1;
  int d;
};
TEST4(b1i4c1i)
}
{
struct i11I20i4si20 {
  int a:11;
  int :20;
  int b:4;
  short c;
  int d:20;
};
TEST4(i11I20i4si20)
}
{
struct i20I2si1s15 {
  int a:20;
  int :2;
  short b;
  int c:1;
  short d:15;
};
TEST4(i20I2si1s15)
}
{
struct i31b1ii2 {
  int a:31;
  _Bool b:1;
  int c;
  int d:2;
};
TEST4(i31b1ii2)
}
{
struct c7I0cs16i {
  char a:7;
  int :0;
  char b;
  short c:16;
  int d;
};
TEST4(c7I0cs16i)
}
{
struct c1S1ic3i1 {
  char a:1;
  short :1;
  int b;
  char c:3;
  int d:1;
};
TEST4(c1S1ic3i1)
}
{
struct c3s1i7i2 {
  char a:3;
  short b:1;
  int c:7;
  int d:2;
};
TEST4(c3s1i7i2)
}
{
struct ii7I2i4b1 {
  int a;
  int b:7;
  int :2;
  int c:4;
  _Bool d:1;
};
TEST4(ii7I2i4b1)
}
{
struct c5isc6 {
  char a:5;
  int b;
  short c;
  char d:6;
};
TEST4(c5isc6)
}
{
struct c7B0c7i9i7 {
  char a:7;
  _Bool :0;
  char b:7;
  int c:9;
  int d:7;
};
TEST4(c7B0c7i9i7)
}
{
struct cs1i2c5 {
  char a;
  short b:1;
  int c:2;
  char d:5;
};
TEST4(cs1i2c5)
}
{
struct c5c8s2s6 {
  char a:5;
  char b:8;
  short c:2;
  short d:6;
};
TEST4(c5c8s2s6)
}
{
struct ibi2i19 {
  int a;
  _Bool b;
  int c:2;
  int d:19;
};
TEST4(ibi2i19)
}
{
struct I10si28S8b1s {
  int :10;
  short a;
  int b:28;
  short :8;
  _Bool c:1;
  short d;
};
TEST4(I10si28S8b1s)
}
{
struct sb1i1S5s4 {
  short a;
  _Bool b:1;
  int c:1;
  short :5;
  short d:4;
};
TEST4(sb1i1S5s4)
}
{
struct i13si25c {
  int a:13;
  short b;
  int c:25;
  char d;
};
TEST4(i13si25c)
}
{
struct s11s4si4 {
  short a:11;
  short b:4;
  short c;
  int d:4;
};
TEST4(s11s4si4)
}
{
struct B1s2s4i7S4s4 {
  _Bool :1;
  short a:2;
  short b:4;
  int c:7;
  short :4;
  short d:4;
};
TEST4(B1s2s4i7S4s4)
}
{
struct c5is3i {
  char a:5;
  int b;
  short c:3;
  int d;
};
TEST4(c5is3i)
}
{
struct i8i23s9i31 {
  int a:8;
  int b:23;
  short c:9;
  int d:31;
};
TEST4(i8i23s9i31)
}
{
struct I13i5b1i15i1 {
  int :13;
  int a:5;
  _Bool b:1;
  int c:15;
  int d:1;
};
TEST4(I13i5b1i15i1)
}
{
struct i8i1cs16 {
  int a:8;
  int b:1;
  char c;
  short d:16;
};
TEST4(i8i1cs16)
}
{
struct s12I26ibi4 {
  short a:12;
  int :26;
  int b;
  _Bool c;
  int d:4;
};
TEST4(s12I26ibi4)
}
{
struct si2I0ic5 {
  short a;
  int b:2;
  int :0;
  int c;
  char d:5;
};
TEST4(si2I0ic5)
}
{
struct i14bi20i5 {
  int a:14;
  _Bool b;
  int c:20;
  int d:5;
};
TEST4(i14bi20i5)
}
{
struct I0cc1i2s15 {
  int :0;
  char a;
  char b:1;
  int c:2;
  short d:15;
};
TEST4(I0cc1i2s15)
}
{
struct s11S0sc1i9 {
  short a:11;
  short :0;
  short b;
  char c:1;
  int d:9;
};
TEST4(s11S0sc1i9)
}
{
struct s2c1s2b1 {
  short a:2;
  char b:1;
  short c:2;
  _Bool d:1;
};
TEST4(s2c1s2b1)
}
{
struct c1b1c8i6 {
  char a:1;
  _Bool b:1;
  char c:8;
  int d:6;
};
TEST4(c1b1c8i6)
}
{
struct i17C4ii13c1 {
  int a:17;
  char :4;
  int b;
  int c:13;
  char d:1;
};
TEST4(i17C4ii13c1)
}
{
struct ii1b1i10 {
  int a;
  int b:1;
  _Bool c:1;
  int d:10;
};
TEST4(ii1b1i10)
}
{
struct i18bs3i2 {
  int a:18;
  _Bool b;
  short c:3;
  int d:2;
};
TEST4(i18bs3i2)
}
{
struct s6b1ii1 {
  short a:6;
  _Bool b:1;
  int c;
  int d:1;
};
TEST4(s6b1ii1)
}
{
struct s15b1S7c6I0i25 {
  short a:15;
  _Bool b:1;
  short :7;
  char c:6;
  int :0;
  int d:25;
};
TEST4(s15b1S7c6I0i25)
}
{
struct i20C8I1I5i15b1c1 {
  int a:20;
  char :8;
  int :1;
  int :5;
  int b:15;
  _Bool c:1;
  char d:1;
};
TEST4(i20C8I1I5i15b1c1)
}
{
struct i12c1I0s3s12 {
  int a:12;
  char b:1;
  int :0;
  short c:3;
  short d:12;
};
TEST4(i12c1I0s3s12)
}
{
struct c2b1i7C1i {
  char a:2;
  _Bool b:1;
  int c:7;
  char :1;
  int d;
};
TEST4(c2b1i7C1i)
}
{
struct I6b1I25s12i5c1 {
  int :6;
  _Bool a:1;
  int :25;
  short b:12;
  int c:5;
  char d:1;
};
TEST4(I6b1I25s12i5c1)
}
{
struct s4c3bi12 {
  short a:4;
  char b:3;
  _Bool c;
  int d:12;
};
TEST4(s4c3bi12)
}
{
struct i22b1si7 {
  int a:22;
  _Bool b:1;
  short c;
  int d:7;
};
TEST4(i22b1si7)
}
{
struct i14i12i24i2 {
  int a:14;
  int b:12;
  int c:24;
  int d:2;
};
TEST4(i14i12i24i2)
}
{
struct i3s1ci {
  int a:3;
  short b:1;
  char c;
  int d;
};
TEST4(i3s1ci)
}
{
struct ib1b1c3 {
  int a;
  _Bool b:1;
  _Bool c:1;
  char d:3;
};
TEST4(ib1b1c3)
}
{
struct c2S6s4c7i12 {
  char a:2;
  short :6;
  short b:4;
  char c:7;
  int d:12;
};
TEST4(c2S6s4c7i12)
}
{
struct S4i2b1i28s15 {
  short :4;
  int a:2;
  _Bool b:1;
  int c:28;
  short d:15;
};
TEST4(S4i2b1i28s15)
}
{
struct b1s7ii5 {
  _Bool a:1;
  short b:7;
  int c;
  int d:5;
};
TEST4(b1s7ii5)
}
{
struct ciii29 {
  char a;
  int b;
  int c;
  int d:29;
};
TEST4(ciii29)
}
{
struct c7sc1i8 {
  char a:7;
  short b;
  char c:1;
  int d:8;
};
TEST4(c7sc1i8)
}
{
struct ii24b1i4 {
  int a;
  int b:24;
  _Bool c:1;
  int d:4;
};
TEST4(ii24b1i4)
}
{
struct c6i31i4c2 {
  char a:6;
  int b:31;
  int c:4;
  char d:2;
};
TEST4(c6i31i4c2)
}
{
struct cbs5c4 {
  char a;
  _Bool b;
  short c:5;
  char d:4;
};
TEST4(cbs5c4)
}
{
struct ib1ci13 {
  int a;
  _Bool b:1;
  char c;
  int d:13;
};
TEST4(ib1ci13)
}
{
struct c3I1i23I4C0i18i32 {
  char a:3;
  int :1;
  int b:23;
  int :4;
  char :0;
  int c:18;
  int d:32;
};
TEST4(c3I1i23I4C0i18i32)
}
{
struct cb1ib1 {
  char a;
  _Bool b:1;
  int c;
  _Bool d:1;
};
TEST4(cb1ib1)
}
{
struct b1S0bi6b1 {
  _Bool a:1;
  short :0;
  _Bool b;
  int c:6;
  _Bool d:1;
};
TEST4(b1S0bi6b1)
}
{
struct c2B1i26i10I10i20 {
  char a:2;
  _Bool :1;
  int b:26;
  int c:10;
  int :10;
  int d:20;
};
TEST4(c2B1i26i10I10i20)
}
{
struct i15i3S0i4I11I0c {
  int a:15;
  int b:3;
  short :0;
  int c:4;
  int :11;
  int :0;
  char d;
};
TEST4(i15i3S0i4I11I0c)
}
{
struct i1ii22i {
  int a:1;
  int b;
  int c:22;
  int d;
};
TEST4(i1ii22i)
}
{
struct b1i11ii {
  _Bool a:1;
  int b:11;
  int c;
  int d;
};
TEST4(b1i11ii)
}
{
struct b1i14i2c {
  _Bool a:1;
  int b:14;
  int c:2;
  char d;
};
TEST4(b1i14i2c)
}
{
struct si1i1B0s {
  short a;
  int b:1;
  int c:1;
  _Bool :0;
  short d;
};
TEST4(si1i1B0s)
}
{
struct i6I0i1i16c6 {
  int a:6;
  int :0;
  int b:1;
  int c:16;
  char d:6;
};
TEST4(i6I0i1i16c6)
}
{
struct i6i1i14c1 {
  int a:6;
  int b:1;
  int c:14;
  char d:1;
};
TEST4(i6i1i14c1)
}
{
struct i6s2s3c2 {
  int a:6;
  short b:2;
  short c:3;
  char d:2;
};
TEST4(i6s2s3c2)
}
{
struct s4i1i8c {
  short a:4;
  int b:1;
  int c:8;
  char d;
};
TEST4(s4i1i8c)
}
{
struct sb1c2i2 {
  short a;
  _Bool b:1;
  char c:2;
  int d:2;
};
TEST4(sb1c2i2)
}
{
struct b1i1i10i23 {
  _Bool a:1;
  int b:1;
  int c:10;
  int d:23;
};
TEST4(b1i1i10i23)
}
{
struct i1i3s4i {
  int a:1;
  int b:3;
  short c:4;
  int d;
};
TEST4(i1i3s4i)
}
{
struct c3i1ic5 {
  char a:3;
  int b:1;
  int c;
  char d:5;
};
TEST4(c3i1ic5)
}
{
struct i5bi10C1i {
  int a:5;
  _Bool b;
  int c:10;
  char :1;
  int d;
};
TEST4(i5bi10C1i)
}
{
struct i5b1i8i11 {
  int a:5;
  _Bool b:1;
  int c:8;
  int d:11;
};
TEST4(i5b1i8i11)
}
{
struct c8i1s14I22s13 {
  char a:8;
  int b:1;
  short c:14;
  int :22;
  short d:13;
};
TEST4(c8i1s14I22s13)
}
{
struct i7i6c1c {
  int a:7;
  int b:6;
  char c:1;
  char d;
};
TEST4(i7i6c1c)
}
{
struct s3i1c6s6 {
  short a:3;
  int b:1;
  char c:6;
  short d:6;
};
TEST4(s3i1c6s6)
}
{
struct cc1c4c1 {
  char a;
  char b:1;
  char c:4;
  char d:1;
};
TEST4(cc1c4c1)
}
{
struct ib1i11c {
  int a;
  _Bool b:1;
  int c:11;
  char d;
};
TEST4(ib1i11c)
}
{
struct i2i5b1i8 {
  int a:2;
  int b:5;
  _Bool c:1;
  int d:8;
};
TEST4(i2i5b1i8)
}
{
struct is3s9c7 {
  int a;
  short b:3;
  short c:9;
  char d:7;
};
TEST4(is3s9c7)
}
{
struct i23i1i3b1 {
  int a:23;
  int b:1;
  int c:3;
  _Bool d:1;
};
TEST4(i23i1i3b1)
}
{
struct S1i23b1i16c2 {
  short :1;
  int a:23;
  _Bool b:1;
  int c:16;
  char d:2;
};
TEST4(S1i23b1i16c2)
}
{
struct c4sS12s8c5 {
  char a:4;
  short b;
  short :12;
  short c:8;
  char d:5;
};
TEST4(c4sS12s8c5)
}
{
struct i1i7ci14 {
  int a:1;
  int b:7;
  char c;
  int d:14;
};
TEST4(i1i7ci14)
}
{
struct i30S3s16sb1 {
  int a:30;
  short :3;
  short b:16;
  short c;
  _Bool d:1;
};
TEST4(i30S3s16sb1)
}
{
struct i1b1b1b1 {
  int a:1;
  _Bool b:1;
  _Bool c:1;
  _Bool d:1;
};
TEST4(i1b1b1b1)
}
{
struct ss6sc8 {
  short a;
  short b:6;
  short c;
  char d:8;
};
TEST4(ss6sc8)
}
{
struct I0ii4i17c7 {
  int :0;
  int a;
  int b:4;
  int c:17;
  char d:7;
};
TEST4(I0ii4i17c7)
}
{
struct i26i14I23I10i20I22i19 {
  int a:26;
  int b:14;
  int :23;
  int :10;
  int c:20;
  int :22;
  int d:19;
};
TEST4(i26i14I23I10i20I22i19)
}
{
struct c6b1is11 {
  char a:6;
  _Bool b:1;
  int c;
  short d:11;
};
TEST4(c6b1is11)
}
{
struct i23i1i12s4 {
  int a:23;
  int b:1;
  int c:12;
  short d:4;
};
TEST4(i23i1i12s4)
}
{
struct i17ci29b1 {
  int a:17;
  char b;
  int c:29;
  _Bool d:1;
};
TEST4(i17ci29b1)
}
{
struct C0i1s15I0is1 {
  char :0;
  int a:1;
  short b:15;
  int :0;
  int c;
  short d:1;
};
TEST4(C0i1s15I0is1)
}
{
struct i28b1s2i11 {
  int a:28;
  _Bool b:1;
  short c:2;
  int d:11;
};
TEST4(i28b1s2i11)
}
{
struct si5c6s3 {
  short a;
  int b:5;
  char c:6;
  short d:3;
};
TEST4(si5c6s3)
}
{
struct c3is12c1 {
  char a:3;
  int b;
  short c:12;
  char d:1;
};
TEST4(c3is12c1)
}
{
struct i3i7i8c4 {
  int a:3;
  int b:7;
  int c:8;
  char d:4;
};
TEST4(i3i7i8c4)
}
{
struct ci2i10b1 {
  char a;
  int b:2;
  int c:10;
  _Bool d:1;
};
TEST4(ci2i10b1)
}
{
struct c1I25i9bi3 {
  char a:1;
  int :25;
  int b:9;
  _Bool c;
  int d:3;
};
TEST4(c1I25i9bi3)
}
{
struct S6I0i14iB1c3s8 {
  short :6;
  int :0;
  int a:14;
  int b;
  _Bool :1;
  char c:3;
  short d:8;
};
TEST4(S6I0i14iB1c3s8)
}
{
struct ic2i4s7 {
  int a;
  char b:2;
  int c:4;
  short d:7;
};
TEST4(ic2i4s7)
}
{
struct s1s2i28C1i4 {
  short a:1;
  short b:2;
  int c:28;
  char :1;
  int d:4;
};
TEST4(s1s2i28C1i4)
}
{
struct b1i7si13 {
  _Bool a:1;
  int b:7;
  short c;
  int d:13;
};
TEST4(b1i7si13)
}
{
struct i6s2c1b1 {
  int a:6;
  short b:2;
  char c:1;
  _Bool d:1;
};
TEST4(i6s2c1b1)
}
{
struct i18I2c1sc2 {
  int a:18;
  int :2;
  char b:1;
  short c;
  char d:2;
};
TEST4(i18I2c1sc2)
}
{
struct is9I0c8i {
  int a;
  short b:9;
  int :0;
  char c:8;
  int d;
};
TEST4(is9I0c8i)
}
{
struct c4c5s8i12 {
  char a:4;
  char b:5;
  short c:8;
  int d:12;
};
TEST4(c4c5s8i12)
}
{
struct s7i4i2s {
  short a:7;
  int b:4;
  int c:2;
  short d;
};
TEST4(s7i4i2s)
}
{
struct i25i9s1s {
  int a:25;
  int b:9;
  short c:1;
  short d;
};
TEST4(i25i9s1s)
}
{
struct I0i20sbI14c4 {
  int :0;
  int a:20;
  short b;
  _Bool c;
  int :14;
  char d:4;
};
TEST4(I0i20sbI14c4)
}
{
struct bb1i14i21 {
  _Bool a;
  _Bool b:1;
  int c:14;
  int d:21;
};
TEST4(bb1i14i21)
}
{
struct c1ic5b {
  char a:1;
  int b;
  char c:5;
  _Bool d;
};
TEST4(c1ic5b)
}
{
struct c2i2s7i1 {
  char a:2;
  int b:2;
  short c:7;
  int d:1;
};
TEST4(c2i2s7i1)
}
{
struct i26b1bs2 {
  int a:26;
  _Bool b:1;
  _Bool c;
  short d:2;
};
TEST4(i26b1bs2)
}
{
struct i7s3s12c5 {
  int a:7;
  short b:3;
  short c:12;
  char d:5;
};
TEST4(i7s3s12c5)
}
{
struct s4i1i2c5 {
  short a:4;
  int b:1;
  int c:2;
  char d:5;
};
TEST4(s4i1i2c5)
}
{
struct s1i4i4i19 {
  short a:1;
  int b:4;
  int c:4;
  int d:19;
};
TEST4(s1i4i4i19)
}
{
struct i2i23c8c5 {
  int a:2;
  int b:23;
  char c:8;
  char d:5;
};
TEST4(i2i23c8c5)
}
{
struct i5sC8b1s9 {
  int a:5;
  short b;
  char :8;
  _Bool c:1;
  short d:9;
};
TEST4(i5sC8b1s9)
}
{
struct s2i19c1i17 {
  short a:2;
  int b:19;
  char c:1;
  int d:17;
};
TEST4(s2i19c1i17)
}
{
struct c1s3s10i7 {
  char a:1;
  short b:3;
  short c:10;
  int d:7;
};
TEST4(c1s3s10i7)
}
{
struct c4i4i21c {
  char a:4;
  int b:4;
  int c:21;
  char d;
};
TEST4(c4i4i21c)
}
{
struct s1B1ci15i2 {
  short a:1;
  _Bool :1;
  char b;
  int c:15;
  int d:2;
};
TEST4(s1B1ci15i2)
}
{
struct I2i2i3i22c {
  int :2;
  int a:2;
  int b:3;
  int c:22;
  char d;
};
TEST4(I2i2i3i22c)
}
{
struct i30C5i22i1s1 {
  int a:30;
  char :5;
  int b:22;
  int c:1;
  short d:1;
};
TEST4(i30C5i22i1s1)
}
{
struct i2i1i12I9i10 {
  int a:2;
  int b:1;
  int c:12;
  int :9;
  int d:10;
};
TEST4(i2i1i12I9i10)
}
{
struct cs11B1i14c4 {
  char a;
  short b:11;
  _Bool :1;
  int c:14;
  char d:4;
};
TEST4(cs11B1i14c4)
}
{
struct b1cs14i24 {
  _Bool a:1;
  char b;
  short c:14;
  int d:24;
};
TEST4(b1cs14i24)
}
{
struct c1s16b1B1c6 {
  char a:1;
  short b:16;
  _Bool c:1;
  _Bool :1;
  char d:6;
};
TEST4(c1s16b1B1c6)
}
{
struct bI11ic1i3 {
  _Bool a;
  int :11;
  int b;
  char c:1;
  int d:3;
};
TEST4(bI11ic1i3)
}
{
struct b1i15I0ii1 {
  _Bool a:1;
  int b:15;
  int :0;
  int c;
  int d:1;
};
TEST4(b1i15I0ii1)
}
{
struct i5i8s2i2 {
  int a:5;
  int b:8;
  short c:2;
  int d:2;
};
TEST4(i5i8s2i2)
}
{
struct sc1i2c4 {
  short a;
  char b:1;
  int c:2;
  char d:4;
};
TEST4(sc1i2c4)
}
{
struct i1c6I0S1s1i26 {
  int a:1;
  char b:6;
  int :0;
  short :1;
  short c:1;
  int d:26;
};
TEST4(i1c6I0S1s1i26)
}
{
struct i7b1C7s3s7 {
  int a:7;
  _Bool b:1;
  char :7;
  short c:3;
  short d:7;
};
TEST4(i7b1C7s3s7)
}
{
struct c2i16c1b {
  char a:2;
  int b:16;
  char c:1;
  _Bool d;
};
TEST4(c2i16c1b)
}
{
struct s5i3i32c4 {
  short a:5;
  int b:3;
  int c:32;
  char d:4;
};
TEST4(s5i3i32c4)
}
{
struct c2b1i1i7 {
  char a:2;
  _Bool b:1;
  int c:1;
  int d:7;
};
TEST4(c2b1i1i7)
}
{
struct sS0s14i14i2 {
  short a;
  short :0;
  short b:14;
  int c:14;
  int d:2;
};
TEST4(sS0s14i14i2)
}
{
struct i10s5c4i3 {
  int a:10;
  short b:5;
  char c:4;
  int d:3;
};
TEST4(i10s5c4i3)
}
{
struct c4is4i14 {
  char a:4;
  int b;
  short c:4;
  int d:14;
};
TEST4(c4is4i14)
}
{
struct i7ssi10 {
  int a:7;
  short b;
  short c;
  int d:10;
};
TEST4(i7ssi10)
}
{
struct sc1S6c5i2 {
  short a;
  char b:1;
  short :6;
  char c:5;
  int d:2;
};
TEST4(sc1S6c5i2)
}
{
struct cS1S4c4si8 {
  char a;
  short :1;
  short :4;
  char b:4;
  short c;
  int d:8;
};
TEST4(cS1S4c4si8)
}
{
struct i10i11b1b1 {
  int a:10;
  int b:11;
  _Bool c:1;
  _Bool d:1;
};
TEST4(i10i11b1b1)
}
{
struct i10ic7b1 {
  int a:10;
  int b;
  char c:7;
  _Bool d:1;
};
TEST4(i10ic7b1)
}
{
struct i25i32i3s16 {
  int a:25;
  int b:32;
  int c:3;
  short d:16;
};
TEST4(i25i32i3s16)
}
{
struct S6C5S8c7s8I0s2i4 {
  short :6;
  char :5;
  short :8;
  char a:7;
  short b:8;
  int :0;
  short c:2;
  int d:4;
};
TEST4(S6C5S8c7s8I0s2i4)
}
{
struct sc1s4s2 {
  short a;
  char b:1;
  short c:4;
  short d:2;
};
TEST4(sc1s4s2)
}
{
struct cb1s1c7 {
  char a;
  _Bool b:1;
  short c:1;
  char d:7;
};
TEST4(cb1s1c7)
}
{
struct b1ii1b {
  _Bool a:1;
  int b;
  int c:1;
  _Bool d;
};
TEST4(b1ii1b)
}
{
struct ii2i19i10 {
  int a;
  int b:2;
  int c:19;
  int d:10;
};
TEST4(ii2i19i10)
}
{
struct ii2i9i {
  int a;
  int b:2;
  int c:9;
  int d;
};
TEST4(ii2i9i)
}
{
struct s5ci32i2 {
  short a:5;
  char b;
  int c:32;
  int d:2;
};
TEST4(s5ci32i2)
}
{
struct s1iC7ii26 {
  short a:1;
  int b;
  char :7;
  int c;
  int d:26;
};
TEST4(s1iC7ii26)
}
{
struct c1s12i19I31i14 {
  char a:1;
  short b:12;
  int c:19;
  int :31;
  int d:14;
};
TEST4(c1s12i19I31i14)
}
{
struct i14I13b1b1s14 {
  int a:14;
  int :13;
  _Bool b:1;
  _Bool c:1;
  short d:14;
};
TEST4(i14I13b1b1s14)
}
{
struct c3I1i2sc {
  char a:3;
  int :1;
  int b:2;
  short c;
  char d;
};
TEST4(c3I1i2sc)
}
{
struct b1c1C0I26b1i2 {
  _Bool a:1;
  char b:1;
  char :0;
  int :26;
  _Bool c:1;
  int d:2;
};
TEST4(b1c1C0I26b1i2)
}
{
struct i13i2ii30 {
  int a:13;
  int b:2;
  int c;
  int d:30;
};
TEST4(i13i2ii30)
}
{
struct ii11ss10 {
  int a;
  int b:11;
  short c;
  short d:10;
};
TEST4(ii11ss10)
}
{
struct ici27s {
  int a;
  char b;
  int c:27;
  short d;
};
TEST4(ici27s)
}
{
struct i1s8s3i32 {
  int a:1;
  short b:8;
  short c:3;
  int d:32;
};
TEST4(i1s8s3i32)
}
{
struct i15c2i7i {
  int a:15;
  char b:2;
  int c:7;
  int d;
};
TEST4(i15c2i7i)
}
{
struct S0i27s16i27c3 {
  short :0;
  int a:27;
  short b:16;
  int c:27;
  char d:3;
};
TEST4(S0i27s16i27c3)
}
{
struct ic2ii2 {
  int a;
  char b:2;
  int c;
  int d:2;
};
TEST4(ic2ii2)
}
{
struct s1i21s16b1 {
  short a:1;
  int b:21;
  short c:16;
  _Bool d:1;
};
TEST4(s1i21s16b1)
}
{
struct c3s3s6s12 {
  char a:3;
  short b:3;
  short c:6;
  short d:12;
};
TEST4(c3s3s6s12)
}
{
struct b1sb1i22 {
  _Bool a:1;
  short b;
  _Bool c:1;
  int d:22;
};
TEST4(b1sb1i22)
}
{
struct cs3c2c7 {
  char a;
  short b:3;
  char c:2;
  char d:7;
};
TEST4(cs3c2c7)
}
{
struct b1c6i10i9 {
  _Bool a:1;
  char b:6;
  int c:10;
  int d:9;
};
TEST4(b1c6i10i9)
}
{
struct ici1i1 {
  int a;
  char b;
  int c:1;
  int d:1;
};
TEST4(ici1i1)
}
{
struct i32C0i1s1c7 {
  int a:32;
  char :0;
  int b:1;
  short c:1;
  char d:7;
};
TEST4(i32C0i1s1c7)
}
{
struct i14I23s5si12 {
  int a:14;
  int :23;
  short b:5;
  short c;
  int d:12;
};
TEST4(i14I23s5si12)
}
{
struct i14i2ic6 {
  int a:14;
  int b:2;
  int c;
  char d:6;
};
TEST4(i14i2ic6)
}
{
struct c1c4i11i14 {
  char a:1;
  char b:4;
  int c:11;
  int d:14;
};
TEST4(c1c4i11i14)
}
{
struct bi5is6 {
  _Bool a;
  int b:5;
  int c;
  short d:6;
};
TEST4(bi5is6)
}
{
struct sc8is {
  short a;
  char b:8;
  int c;
  short d;
};
TEST4(sc8is)
}
{
struct ic3s4i27 {
  int a;
  char b:3;
  short c:4;
  int d:27;
};
TEST4(ic3s4i27)
}
{
struct s1I8s4c2b {
  short a:1;
  int :8;
  short b:4;
  char c:2;
  _Bool d;
};
TEST4(s1I8s4c2b)
}
{
struct i4c6ii1 {
  int a:4;
  char b:6;
  int c;
  int d:1;
};
TEST4(i4c6ii1)
}
{
struct ci5s4b1 {
  char a;
  int b:5;
  short c:4;
  _Bool d:1;
};
TEST4(ci5s4b1)
}
{
struct ci2s10S9i2 {
  char a;
  int b:2;
  short c:10;
  short :9;
  int d:2;
};
TEST4(ci2s10S9i2)
}
{
struct c1s2i5c1 {
  char a:1;
  short b:2;
  int c:5;
  char d:1;
};
TEST4(c1s2i5c1)
}
{
struct i12s13i19s7 {
  int a:12;
  short b:13;
  int c:19;
  short d:7;
};
TEST4(i12s13i19s7)
}
{
struct i11i26s7I19s {
  int a:11;
  int b:26;
  short c:7;
  int :19;
  short d;
};
TEST4(i11i26s7I19s)
}
{
struct s2b1i11i {
  short a:2;
  _Bool b:1;
  int c:11;
  int d;
};
TEST4(s2b1i11i)
}
{
struct i3s2ii21 {
  int a:3;
  short b:2;
  int c;
  int d:21;
};
TEST4(i3s2ii21)
}
{
struct s2s9bi3 {
  short a:2;
  short b:9;
  _Bool c;
  int d:3;
};
TEST4(s2s9bi3)
}
{
struct i18c2b1i {
  int a:18;
  char b:2;
  _Bool c:1;
  int d;
};
TEST4(i18c2b1i)
}
{
struct b1c1s3b1 {
  _Bool a:1;
  char b:1;
  short c:3;
  _Bool d:1;
};
TEST4(b1c1s3b1)
}
{
struct iiI10I2b1s8 {
  int a;
  int b;
  int :10;
  int :2;
  _Bool c:1;
  short d:8;
};
TEST4(iiI10I2b1s8)
}
{
struct s6I21s2ii14 {
  short a:6;
  int :21;
  short b:2;
  int c;
  int d:14;
};
TEST4(s6I21s2ii14)
}
{
struct c5S1cs3c7 {
  char a:5;
  short :1;
  char b;
  short c:3;
  char d:7;
};
TEST4(c5S1cs3c7)
}
{
struct iS0s6s9b1 {
  int a;
  short :0;
  short b:6;
  short c:9;
  _Bool d:1;
};
TEST4(iS0s6s9b1)
}
{
struct s2s5b1c3 {
  short a:2;
  short b:5;
  _Bool c:1;
  char d:3;
};
TEST4(s2s5b1c3)
}
{
struct b1i10c1c {
  _Bool a:1;
  int b:10;
  char c:1;
  char d;
};
TEST4(b1i10c1c)
}
{
struct c4i11B1is {
  char a:4;
  int b:11;
  _Bool :1;
  int c;
  short d;
};
TEST4(c4i11B1is)
}
{
struct B0csbi1 {
  _Bool :0;
  char a;
  short b;
  _Bool c;
  int d:1;
};
TEST4(B0csbi1)
}
{
struct S3i1i13s1b {
  short :3;
  int a:1;
  int b:13;
  short c:1;
  _Bool d;
};
TEST4(S3i1i13s1b)
}
{
struct ii2s7C1B0c1 {
  int a;
  int b:2;
  short c:7;
  char :1;
  _Bool :0;
  char d:1;
};
TEST4(ii2s7C1B0c1)
}
{
struct i3i8i1I0i4 {
  int a:3;
  int b:8;
  int c:1;
  int :0;
  int d:4;
};
TEST4(i3i8i1I0i4)
}
{
struct s3s5i1i1 {
  short a:3;
  short b:5;
  int c:1;
  int d:1;
};
TEST4(s3s5i1i1)
}
{
struct is7i1i2 {
  int a;
  short b:7;
  int c:1;
  int d:2;
};
TEST4(is7i1i2)
}
{
struct i14c7i7b1 {
  int a:14;
  char b:7;
  int c:7;
  _Bool d:1;
};
TEST4(i14c7i7b1)
}
{
struct c6bi7s16 {
  char a:6;
  _Bool b;
  int c:7;
  short d:16;
};
TEST4(c6bi7s16)
}
{
struct i1b1c2c {
  int a:1;
  _Bool b:1;
  char c:2;
  char d;
};
TEST4(i1b1c2c)
}
{
struct s15b1i1i14 {
  short a:15;
  _Bool b:1;
  int c:1;
  int d:14;
};
TEST4(s15b1i1i14)
}
{
struct B1I0i7is3b1 {
  _Bool :1;
  int :0;
  int a:7;
  int b;
  short c:3;
  _Bool d:1;
};
TEST4(B1I0i7is3b1)
}
{
struct i14b1cS0i5 {
  int a:14;
  _Bool b:1;
  char c;
  short :0;
  int d:5;
};
TEST4(i14b1cS0i5)
}
{
struct s1c1c1i3 {
  short a:1;
  char b:1;
  char c:1;
  int d:3;
};
TEST4(s1c1c1i3)
}
{
struct ic6s7S5c3 {
  int a;
  char b:6;
  short c:7;
  short :5;
  char d:3;
};
TEST4(ic6s7S5c3)
}
{
struct b1i3b1i7 {
  _Bool a:1;
  int b:3;
  _Bool c:1;
  int d:7;
};
TEST4(b1i3b1i7)
}
{
struct i2s15i11c1 {
  int a:2;
  short b:15;
  int c:11;
  char d:1;
};
TEST4(i2s15i11c1)
}
{
struct B1b1c2ic1 {
  _Bool :1;
  _Bool a:1;
  char b:2;
  int c;
  char d:1;
};
TEST4(B1b1c2ic1)
}
{
struct ccS0c5i2 {
  char a;
  char b;
  short :0;
  char c:5;
  int d:2;
};
TEST4(ccS0c5i2)
}
{
struct cb1i1I20s3 {
  char a;
  _Bool b:1;
  int c:1;
  int :20;
  short d:3;
};
TEST4(cb1i1I20s3)
}
{
struct i5i2i14i1 {
  int a:5;
  int b:2;
  int c:14;
  int d:1;
};
TEST4(i5i2i14i1)
}
{
struct c4C1ic8I14i7 {
  char a:4;
  char :1;
  int b;
  char c:8;
  int :14;
  int d:7;
};
TEST4(c4C1ic8I14i7)
}
{
struct s1I28s1C4i31c3 {
  short a:1;
  int :28;
  short b:1;
  char :4;
  int c:31;
  char d:3;
};
TEST4(s1I28s1C4i31c3)
}
{
struct i12b1i2i {
  int a:12;
  _Bool b:1;
  int c:2;
  int d;
};
TEST4(i12b1i2i)
}
{
struct b1s2si8 {
  _Bool a:1;
  short b:2;
  short c;
  int d:8;
};
TEST4(b1s2si8)
}
{
struct i9i1i26b {
  int a:9;
  int b:1;
  int c:26;
  _Bool d;
};
TEST4(i9i1i26b)
}
{
struct c2i11c4c {
  char a:2;
  int b:11;
  char c:4;
  char d;
};
TEST4(c2i11c4c)
}
{
struct i1i4s5i10 {
  int a:1;
  int b:4;
  short c:5;
  int d:10;
};
TEST4(i1i4s5i10)
}
{
struct ib1i9c4 {
  int a;
  _Bool b:1;
  int c:9;
  char d:4;
};
TEST4(ib1i9c4)
}
{
struct i20s4s4b1 {
  int a:20;
  short b:4;
  short c:4;
  _Bool d:1;
};
TEST4(i20s4s4b1)
}
{
struct ii13I15b1c3 {
  int a;
  int b:13;
  int :15;
  _Bool c:1;
  char d:3;
};
TEST4(ii13I15b1c3)
}
{
struct isi7s4 {
  int a;
  short b;
  int c:7;
  short d:4;
};
TEST4(isi7s4)
}
{
struct I0i22i14ic {
  int :0;
  int a:22;
  int b:14;
  int c;
  char d;
};
TEST4(I0i22i14ic)
}
{
struct i2i2c7i10 {
  int a:2;
  int b:2;
  char c:7;
  int d:10;
};
TEST4(i2i2c7i10)
}
{
struct si1b1s14 {
  short a;
  int b:1;
  _Bool c:1;
  short d:14;
};
TEST4(si1b1s14)
}
{
struct s12i26c7i10 {
  short a:12;
  int b:26;
  char c:7;
  int d:10;
};
TEST4(s12i26c7i10)
}
{
struct s2i25i10c8 {
  short a:2;
  int b:25;
  int c:10;
  char d:8;
};
TEST4(s2i25i10c8)
}
{
struct i13c1i6b {
  int a:13;
  char b:1;
  int c:6;
  _Bool d;
};
TEST4(i13c1i6b)
}
{
struct C3i3i28s2i27 {
  char :3;
  int a:3;
  int b:28;
  short c:2;
  int d:27;
};
TEST4(C3i3i28s2i27)
}
{
struct i2ib1i {
  int a:2;
  int b;
  _Bool c:1;
  int d;
};
TEST4(i2ib1i)
}
{
struct c1bi8i8 {
  char a:1;
  _Bool b;
  int c:8;
  int d:8;
};
TEST4(c1bi8i8)
}
{
struct i11i1i6c4 {
  int a:11;
  int b:1;
  int c:6;
  char d:4;
};
TEST4(i11i1i6c4)
}
{
struct c8c2i21c2 {
  char a:8;
  char b:2;
  int c:21;
  char d:2;
};
TEST4(c8c2i21c2)
}
{
struct cb1c6s9 {
  char a;
  _Bool b:1;
  char c:6;
  short d:9;
};
TEST4(cb1c6s9)
}
{
struct s13sii22 {
  short a:13;
  short b;
  int c;
  int d:22;
};
TEST4(s13sii22)
}
{
struct s10i10ii1 {
  short a:10;
  int b:10;
  int c;
  int d:1;
};
TEST4(s10i10ii1)
}
{
struct s1s16cs {
  short a:1;
  short b:16;
  char c;
  short d;
};
TEST4(s1s16cs)
}
{
struct i9I31i24ic4 {
  int a:9;
  int :31;
  int b:24;
  int c;
  char d:4;
};
TEST4(i9I31i24ic4)
}
{
struct ii2s8b1 {
  int a;
  int b:2;
  short c:8;
  _Bool d:1;
};
TEST4(ii2s8b1)
}
{
struct i26c3sb {
  int a:26;
  char b:3;
  short c;
  _Bool d;
};
TEST4(i26c3sb)
}
{
struct i13C3cs14c {
  int a:13;
  char :3;
  char b;
  short c:14;
  char d;
};
TEST4(i13C3cs14c)
}
{
struct cs2i23s {
  char a;
  short b:2;
  int c:23;
  short d;
};
TEST4(cs2i23s)
}
{
struct c3ii2s15 {
  char a:3;
  int b;
  int c:2;
  short d:15;
};
TEST4(c3ii2s15)
}
{
struct c5i2S4S0i2i31 {
  char a:5;
  int b:2;
  short :4;
  short :0;
  int c:2;
  int d:31;
};
TEST4(c5i2S4S0i2i31)
}
{
struct b1i24bs2 {
  _Bool a:1;
  int b:24;
  _Bool c;
  short d:2;
};
TEST4(b1i24bs2)
}
{
struct i6i20c8s2 {
  int a:6;
  int b:20;
  char c:8;
  short d:2;
};
TEST4(i6i20c8s2)
}
{
struct ss2i19i8 {
  short a;
  short b:2;
  int c:19;
  int d:8;
};
TEST4(ss2i19i8)
}
{
struct i2i4bc4 {
  int a:2;
  int b:4;
  _Bool c;
  char d:4;
};
TEST4(i2i4bc4)
}
{
struct ib1i27s {
  int a;
  _Bool b:1;
  int c:27;
  short d;
};
TEST4(ib1i27s)
}
{
struct I3i29s1c6i21 {
  int :3;
  int a:29;
  short b:1;
  char c:6;
  int d:21;
};
TEST4(I3i29s1c6i21)
}
{
struct i14isi2 {
  int a:14;
  int b;
  short c;
  int d:2;
};
TEST4(i14isi2)
}
{
struct i29iS10sS0c7 {
  int a:29;
  int b;
  short :10;
  short c;
  short :0;
  char d:7;
};
TEST4(i29iS10sS0c7)
}
{
struct c1i1s4i1 {
  char a:1;
  int b:1;
  short c:4;
  int d:1;
};
TEST4(c1i1s4i1)
}
{
struct c1s6c4c {
  char a:1;
  short b:6;
  char c:4;
  char d;
};
TEST4(c1s6c4c)
}
{
struct iii14c {
  int a;
  int b;
  int c:14;
  char d;
};
TEST4(iii14c)
}
{
struct s8cs7s2 {
  short a:8;
  char b;
  short c:7;
  short d:2;
};
TEST4(s8cs7s2)
}
{
struct i1b1c2c1 {
  int a:1;
  _Bool b:1;
  char c:2;
  char d:1;
};
TEST4(i1b1c2c1)
}
{
struct s13b1bi12 {
  short a:13;
  _Bool b:1;
  _Bool c;
  int d:12;
};
TEST4(s13b1bi12)
}
{
struct i12i5c5s8 {
  int a:12;
  int b:5;
  char c:5;
  short d:8;
};
TEST4(i12i5c5s8)
}
{
struct c3ib1i17 {
  char a:3;
  int b;
  _Bool c:1;
  int d:17;
};
TEST4(c3ib1i17)
}
{
struct C0S6s3B1s13i1s3 {
  char :0;
  short :6;
  short a:3;
  _Bool :1;
  short b:13;
  int c:1;
  short d:3;
};
TEST4(C0S6s3B1s13i1s3)
}
{
struct i2b1c3c8 {
  int a:2;
  _Bool b:1;
  char c:3;
  char d:8;
};
TEST4(i2b1c3c8)
}
{
struct bC0i11s10s12 {
  _Bool a;
  char :0;
  int b:11;
  short c:10;
  short d:12;
};
TEST4(bC0i11s10s12)
}
{
struct s12bis3 {
  short a:12;
  _Bool b;
  int c;
  short d:3;
};
TEST4(s12bis3)
}
{
struct c5ci13c8 {
  char a:5;
  char b;
  int c:13;
  char d:8;
};
TEST4(c5ci13c8)
}
{
struct c4s8ii {
  char a:4;
  short b:8;
  int c;
  int d;
};
TEST4(c4s8ii)
}
{
struct i2i10s5s4 {
  int a:2;
  int b:10;
  short c:5;
  short d:4;
};
TEST4(i2i10s5s4)
}
{
struct c3c6b1c {
  char a:3;
  char b:6;
  _Bool c:1;
  char d;
};
TEST4(c3c6b1c)
}
{
struct ib1i2c2 {
  int a;
  _Bool b:1;
  int c:2;
  char d:2;
};
TEST4(ib1i2c2)
}
{
struct ib1S0s3i32 {
  int a;
  _Bool b:1;
  short :0;
  short c:3;
  int d:32;
};
TEST4(ib1S0s3i32)
}
{
struct iss1i8 {
  int a;
  short b;
  short c:1;
  int d:8;
};
TEST4(iss1i8)
}
{
struct i6i6b1i7 {
  int a:6;
  int b:6;
  _Bool c:1;
  int d:7;
};
TEST4(i6i6b1i7)
}
{
struct i11s9b1i12 {
  int a:11;
  short b:9;
  _Bool c:1;
  int d:12;
};
TEST4(i11s9b1i12)
}
{
struct s4i3is5 {
  short a:4;
  int b:3;
  int c;
  short d:5;
};
TEST4(s4i3is5)
}
{
struct c4i2s6b1 {
  char a:4;
  int b:2;
  short c:6;
  _Bool d:1;
};
TEST4(c4i2s6b1)
}
{
struct s2I4c6c2c7 {
  short a:2;
  int :4;
  char b:6;
  char c:2;
  char d:7;
};
TEST4(s2I4c6c2c7)
}
{
struct is15c6C0c1 {
  int a;
  short b:15;
  char c:6;
  char :0;
  char d:1;
};
TEST4(is15c6C0c1)
}
{
struct i5s2b1c7 {
  int a:5;
  short b:2;
  _Bool c:1;
  char d:7;
};
TEST4(i5s2b1c7)
}
{
struct s4s8c8c4 {
  short a:4;
  short b:8;
  char c:8;
  char d:4;
};
TEST4(s4s8c8c4)
}
{
struct b1i20c1i2 {
  _Bool a:1;
  int b:20;
  char c:1;
  int d:2;
};
TEST4(b1i20c1i2)
}
