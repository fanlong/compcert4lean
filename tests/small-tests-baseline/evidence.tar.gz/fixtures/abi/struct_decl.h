#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>


extern int failed;

static void failure(const char * assertion, const char * file,
                    int line, const char * fn)
{
  fprintf(stderr, "%s:%d:%s: assertion %s failed\n", file, line, fn, assertion);
  failed = 1;
}

#define check(expr) ((expr) ? (void)0 : failure(#expr,__FILE__,__LINE__,__func__))

struct s1 {
  unsigned char a;
};
extern struct s1 f1(void);
extern void f2(struct s1 x0);
extern void f3(struct s1 x0, struct s1 x1);
extern void f4(int x0, struct s1 x1);
extern void f5(double x0, struct s1 x1);
struct s2 {
  signed char a;
};
extern struct s2 f6(void);
extern void f7(struct s2 x0);
extern void f8(struct s2 x0, struct s2 x1);
extern void f9(int x0, struct s2 x1);
extern void f10(double x0, struct s2 x1);
struct s3 {
  unsigned short a;
};
extern struct s3 f11(void);
extern void f12(struct s3 x0);
extern void f13(struct s3 x0, struct s3 x1);
extern void f14(int x0, struct s3 x1);
extern void f15(double x0, struct s3 x1);
struct s4 {
  short a;
};
extern struct s4 f16(void);
extern void f17(struct s4 x0);
extern void f18(struct s4 x0, struct s4 x1);
extern void f19(int x0, struct s4 x1);
extern void f20(double x0, struct s4 x1);
struct s5 {
  int a;
};
extern struct s5 f21(void);
extern void f22(struct s5 x0);
extern void f23(struct s5 x0, struct s5 x1);
extern void f24(int x0, struct s5 x1);
extern void f25(double x0, struct s5 x1);
struct s6 {
  long long a;
};
extern struct s6 f26(void);
extern void f27(struct s6 x0);
extern void f28(struct s6 x0, struct s6 x1);
extern void f29(int x0, struct s6 x1);
extern void f30(double x0, struct s6 x1);
struct s7 {
  float a;
};
extern struct s7 f31(void);
extern void f32(struct s7 x0);
extern void f33(struct s7 x0, struct s7 x1);
extern void f34(int x0, struct s7 x1);
extern void f35(double x0, struct s7 x1);
struct s8 {
  double a;
};
extern struct s8 f36(void);
extern void f37(struct s8 x0);
extern void f38(struct s8 x0, struct s8 x1);
extern void f39(int x0, struct s8 x1);
extern void f40(double x0, struct s8 x1);
struct s9 {
  char * a;
};
extern struct s9 f41(void);
extern void f42(struct s9 x0);
extern void f43(struct s9 x0, struct s9 x1);
extern void f44(int x0, struct s9 x1);
extern void f45(double x0, struct s9 x1);
struct s10 {
  unsigned char a;
  unsigned char b;
};
extern struct s10 f46(void);
extern void f47(struct s10 x0);
extern void f48(struct s10 x0, struct s10 x1);
extern void f49(int x0, struct s10 x1);
extern void f50(double x0, struct s10 x1);
struct s11 {
  unsigned char a;
  unsigned short b;
};
extern struct s11 f51(void);
extern void f52(struct s11 x0);
extern void f53(struct s11 x0, struct s11 x1);
extern void f54(int x0, struct s11 x1);
extern void f55(double x0, struct s11 x1);
struct s12 {
  unsigned char a;
  int b;
};
extern struct s12 f56(void);
extern void f57(struct s12 x0);
extern void f58(struct s12 x0, struct s12 x1);
extern void f59(int x0, struct s12 x1);
extern void f60(double x0, struct s12 x1);
struct s13 {
  unsigned char a;
  long long b;
};
extern struct s13 f61(void);
extern void f62(struct s13 x0);
extern void f63(struct s13 x0, struct s13 x1);
extern void f64(int x0, struct s13 x1);
extern void f65(double x0, struct s13 x1);
struct s14 {
  unsigned char a;
  float b;
};
extern struct s14 f66(void);
extern void f67(struct s14 x0);
extern void f68(struct s14 x0, struct s14 x1);
extern void f69(int x0, struct s14 x1);
extern void f70(double x0, struct s14 x1);
struct s15 {
  unsigned char a;
  double b;
};
extern struct s15 f71(void);
extern void f72(struct s15 x0);
extern void f73(struct s15 x0, struct s15 x1);
extern void f74(int x0, struct s15 x1);
extern void f75(double x0, struct s15 x1);
struct s16 {
  unsigned short a;
  unsigned char b;
};
extern struct s16 f76(void);
extern void f77(struct s16 x0);
extern void f78(struct s16 x0, struct s16 x1);
extern void f79(int x0, struct s16 x1);
extern void f80(double x0, struct s16 x1);
struct s17 {
  unsigned short a;
  unsigned short b;
};
extern struct s17 f81(void);
extern void f82(struct s17 x0);
extern void f83(struct s17 x0, struct s17 x1);
extern void f84(int x0, struct s17 x1);
extern void f85(double x0, struct s17 x1);
struct s18 {
  unsigned short a;
  int b;
};
extern struct s18 f86(void);
extern void f87(struct s18 x0);
extern void f88(struct s18 x0, struct s18 x1);
extern void f89(int x0, struct s18 x1);
extern void f90(double x0, struct s18 x1);
struct s19 {
  unsigned short a;
  long long b;
};
extern struct s19 f91(void);
extern void f92(struct s19 x0);
extern void f93(struct s19 x0, struct s19 x1);
extern void f94(int x0, struct s19 x1);
extern void f95(double x0, struct s19 x1);
struct s20 {
  unsigned short a;
  float b;
};
extern struct s20 f96(void);
extern void f97(struct s20 x0);
extern void f98(struct s20 x0, struct s20 x1);
extern void f99(int x0, struct s20 x1);
extern void f100(double x0, struct s20 x1);
struct s21 {
  unsigned short a;
  double b;
};
extern struct s21 f101(void);
extern void f102(struct s21 x0);
extern void f103(struct s21 x0, struct s21 x1);
extern void f104(int x0, struct s21 x1);
extern void f105(double x0, struct s21 x1);
struct s22 {
  int a;
  unsigned char b;
};
extern struct s22 f106(void);
extern void f107(struct s22 x0);
extern void f108(struct s22 x0, struct s22 x1);
extern void f109(int x0, struct s22 x1);
extern void f110(double x0, struct s22 x1);
struct s23 {
  int a;
  unsigned short b;
};
extern struct s23 f111(void);
extern void f112(struct s23 x0);
extern void f113(struct s23 x0, struct s23 x1);
extern void f114(int x0, struct s23 x1);
extern void f115(double x0, struct s23 x1);
struct s24 {
  int a;
  int b;
};
extern struct s24 f116(void);
extern void f117(struct s24 x0);
extern void f118(struct s24 x0, struct s24 x1);
extern void f119(int x0, struct s24 x1);
extern void f120(double x0, struct s24 x1);
struct s25 {
  int a;
  long long b;
};
extern struct s25 f121(void);
extern void f122(struct s25 x0);
extern void f123(struct s25 x0, struct s25 x1);
extern void f124(int x0, struct s25 x1);
extern void f125(double x0, struct s25 x1);
struct s26 {
  int a;
  float b;
};
extern struct s26 f126(void);
extern void f127(struct s26 x0);
extern void f128(struct s26 x0, struct s26 x1);
extern void f129(int x0, struct s26 x1);
extern void f130(double x0, struct s26 x1);
struct s27 {
  int a;
  double b;
};
extern struct s27 f131(void);
extern void f132(struct s27 x0);
extern void f133(struct s27 x0, struct s27 x1);
extern void f134(int x0, struct s27 x1);
extern void f135(double x0, struct s27 x1);
struct s28 {
  long long a;
  unsigned char b;
};
extern struct s28 f136(void);
extern void f137(struct s28 x0);
extern void f138(struct s28 x0, struct s28 x1);
extern void f139(int x0, struct s28 x1);
extern void f140(double x0, struct s28 x1);
struct s29 {
  long long a;
  unsigned short b;
};
extern struct s29 f141(void);
extern void f142(struct s29 x0);
extern void f143(struct s29 x0, struct s29 x1);
extern void f144(int x0, struct s29 x1);
extern void f145(double x0, struct s29 x1);
struct s30 {
  long long a;
  int b;
};
extern struct s30 f146(void);
extern void f147(struct s30 x0);
extern void f148(struct s30 x0, struct s30 x1);
extern void f149(int x0, struct s30 x1);
extern void f150(double x0, struct s30 x1);
struct s31 {
  long long a;
  long long b;
};
extern struct s31 f151(void);
extern void f152(struct s31 x0);
extern void f153(struct s31 x0, struct s31 x1);
extern void f154(int x0, struct s31 x1);
extern void f155(double x0, struct s31 x1);
struct s32 {
  long long a;
  float b;
};
extern struct s32 f156(void);
extern void f157(struct s32 x0);
extern void f158(struct s32 x0, struct s32 x1);
extern void f159(int x0, struct s32 x1);
extern void f160(double x0, struct s32 x1);
struct s33 {
  long long a;
  double b;
};
extern struct s33 f161(void);
extern void f162(struct s33 x0);
extern void f163(struct s33 x0, struct s33 x1);
extern void f164(int x0, struct s33 x1);
extern void f165(double x0, struct s33 x1);
struct s34 {
  float a;
  unsigned char b;
};
extern struct s34 f166(void);
extern void f167(struct s34 x0);
extern void f168(struct s34 x0, struct s34 x1);
extern void f169(int x0, struct s34 x1);
extern void f170(double x0, struct s34 x1);
struct s35 {
  float a;
  unsigned short b;
};
extern struct s35 f171(void);
extern void f172(struct s35 x0);
extern void f173(struct s35 x0, struct s35 x1);
extern void f174(int x0, struct s35 x1);
extern void f175(double x0, struct s35 x1);
struct s36 {
  float a;
  int b;
};
extern struct s36 f176(void);
extern void f177(struct s36 x0);
extern void f178(struct s36 x0, struct s36 x1);
extern void f179(int x0, struct s36 x1);
extern void f180(double x0, struct s36 x1);
struct s37 {
  float a;
  long long b;
};
extern struct s37 f181(void);
extern void f182(struct s37 x0);
extern void f183(struct s37 x0, struct s37 x1);
extern void f184(int x0, struct s37 x1);
extern void f185(double x0, struct s37 x1);
struct s38 {
  float a;
  float b;
};
extern struct s38 f186(void);
extern void f187(struct s38 x0);
extern void f188(struct s38 x0, struct s38 x1);
extern void f189(int x0, struct s38 x1);
extern void f190(double x0, struct s38 x1);
struct s39 {
  float a;
  double b;
};
extern struct s39 f191(void);
extern void f192(struct s39 x0);
extern void f193(struct s39 x0, struct s39 x1);
extern void f194(int x0, struct s39 x1);
extern void f195(double x0, struct s39 x1);
struct s40 {
  double a;
  unsigned char b;
};
extern struct s40 f196(void);
extern void f197(struct s40 x0);
extern void f198(struct s40 x0, struct s40 x1);
extern void f199(int x0, struct s40 x1);
extern void f200(double x0, struct s40 x1);
struct s41 {
  double a;
  unsigned short b;
};
extern struct s41 f201(void);
extern void f202(struct s41 x0);
extern void f203(struct s41 x0, struct s41 x1);
extern void f204(int x0, struct s41 x1);
extern void f205(double x0, struct s41 x1);
struct s42 {
  double a;
  int b;
};
extern struct s42 f206(void);
extern void f207(struct s42 x0);
extern void f208(struct s42 x0, struct s42 x1);
extern void f209(int x0, struct s42 x1);
extern void f210(double x0, struct s42 x1);
struct s43 {
  double a;
  long long b;
};
extern struct s43 f211(void);
extern void f212(struct s43 x0);
extern void f213(struct s43 x0, struct s43 x1);
extern void f214(int x0, struct s43 x1);
extern void f215(double x0, struct s43 x1);
struct s44 {
  double a;
  float b;
};
extern struct s44 f216(void);
extern void f217(struct s44 x0);
extern void f218(struct s44 x0, struct s44 x1);
extern void f219(int x0, struct s44 x1);
extern void f220(double x0, struct s44 x1);
struct s45 {
  double a;
  double b;
};
extern struct s45 f221(void);
extern void f222(struct s45 x0);
extern void f223(struct s45 x0, struct s45 x1);
extern void f224(int x0, struct s45 x1);
extern void f225(double x0, struct s45 x1);
struct s46 {
  unsigned char a;
  unsigned char b;
  unsigned char c;
};
extern struct s46 f226(void);
extern void f227(struct s46 x0);
extern void f228(struct s46 x0, struct s46 x1);
extern void f229(int x0, struct s46 x1);
extern void f230(double x0, struct s46 x1);
struct s47 {
  unsigned char a;
  unsigned char b;
  unsigned char c;
  unsigned char d;
};
extern struct s47 f231(void);
extern void f232(struct s47 x0);
extern void f233(struct s47 x0, struct s47 x1);
extern void f234(int x0, struct s47 x1);
extern void f235(double x0, struct s47 x1);
struct s48 {
  unsigned char a;
  unsigned char b;
  unsigned char c;
  unsigned char d;
  unsigned char e;
  unsigned char f;
};
extern struct s48 f236(void);
extern void f237(struct s48 x0);
extern void f238(struct s48 x0, struct s48 x1);
extern void f239(int x0, struct s48 x1);
extern void f240(double x0, struct s48 x1);
struct s49 {
  unsigned char a;
  unsigned char b;
  unsigned char c;
  unsigned char d;
  unsigned char e;
  unsigned char f;
  unsigned char g;
  unsigned char h;
};
extern struct s49 f241(void);
extern void f242(struct s49 x0);
extern void f243(struct s49 x0, struct s49 x1);
extern void f244(int x0, struct s49 x1);
extern void f245(double x0, struct s49 x1);
struct s50 {
  unsigned short a;
  unsigned short b;
  unsigned short c;
};
extern struct s50 f246(void);
extern void f247(struct s50 x0);
extern void f248(struct s50 x0, struct s50 x1);
extern void f249(int x0, struct s50 x1);
extern void f250(double x0, struct s50 x1);
struct s51 {
  unsigned short a;
  unsigned short b;
  unsigned short c;
  unsigned short d;
};
extern struct s51 f251(void);
extern void f252(struct s51 x0);
extern void f253(struct s51 x0, struct s51 x1);
extern void f254(int x0, struct s51 x1);
extern void f255(double x0, struct s51 x1);
struct s52 {
  unsigned short a;
  unsigned short b;
  unsigned short c;
  unsigned short d;
  unsigned short e;
  unsigned short f;
};
extern struct s52 f256(void);
extern void f257(struct s52 x0);
extern void f258(struct s52 x0, struct s52 x1);
extern void f259(int x0, struct s52 x1);
extern void f260(double x0, struct s52 x1);
struct s53 {
  unsigned short a;
  unsigned short b;
  unsigned short c;
  unsigned short d;
  unsigned short e;
  unsigned short f;
  unsigned short g;
  unsigned short h;
};
extern struct s53 f261(void);
extern void f262(struct s53 x0);
extern void f263(struct s53 x0, struct s53 x1);
extern void f264(int x0, struct s53 x1);
extern void f265(double x0, struct s53 x1);
struct s54 {
  int a;
  int b;
  int c;
};
extern struct s54 f266(void);
extern void f267(struct s54 x0);
extern void f268(struct s54 x0, struct s54 x1);
extern void f269(int x0, struct s54 x1);
extern void f270(double x0, struct s54 x1);
struct s55 {
  int a;
  int b;
  int c;
  int d;
};
extern struct s55 f271(void);
extern void f272(struct s55 x0);
extern void f273(struct s55 x0, struct s55 x1);
extern void f274(int x0, struct s55 x1);
extern void f275(double x0, struct s55 x1);
struct s56 {
  int a;
  int b;
  int c;
  int d;
  int e;
  int f;
};
extern struct s56 f276(void);
extern void f277(struct s56 x0);
extern void f278(struct s56 x0, struct s56 x1);
extern void f279(int x0, struct s56 x1);
extern void f280(double x0, struct s56 x1);
struct s57 {
  int a;
  int b;
  int c;
  int d;
  int e;
  int f;
  int g;
  int h;
};
extern struct s57 f281(void);
extern void f282(struct s57 x0);
extern void f283(struct s57 x0, struct s57 x1);
extern void f284(int x0, struct s57 x1);
extern void f285(double x0, struct s57 x1);
struct s58 {
  long long a;
  long long b;
  long long c;
};
extern struct s58 f286(void);
extern void f287(struct s58 x0);
extern void f288(struct s58 x0, struct s58 x1);
extern void f289(int x0, struct s58 x1);
extern void f290(double x0, struct s58 x1);
struct s59 {
  long long a;
  long long b;
  long long c;
  long long d;
};
extern struct s59 f291(void);
extern void f292(struct s59 x0);
extern void f293(struct s59 x0, struct s59 x1);
extern void f294(int x0, struct s59 x1);
extern void f295(double x0, struct s59 x1);
struct s60 {
  long long a;
  long long b;
  long long c;
  long long d;
  long long e;
  long long f;
};
extern struct s60 f296(void);
extern void f297(struct s60 x0);
extern void f298(struct s60 x0, struct s60 x1);
extern void f299(int x0, struct s60 x1);
extern void f300(double x0, struct s60 x1);
struct s61 {
  long long a;
  long long b;
  long long c;
  long long d;
  long long e;
  long long f;
  long long g;
  long long h;
};
extern struct s61 f301(void);
extern void f302(struct s61 x0);
extern void f303(struct s61 x0, struct s61 x1);
extern void f304(int x0, struct s61 x1);
extern void f305(double x0, struct s61 x1);
struct s62 {
  float a;
  float b;
  float c;
};
extern struct s62 f306(void);
extern void f307(struct s62 x0);
extern void f308(struct s62 x0, struct s62 x1);
extern void f309(int x0, struct s62 x1);
extern void f310(double x0, struct s62 x1);
struct s63 {
  float a;
  float b;
  float c;
  float d;
};
extern struct s63 f311(void);
extern void f312(struct s63 x0);
extern void f313(struct s63 x0, struct s63 x1);
extern void f314(int x0, struct s63 x1);
extern void f315(double x0, struct s63 x1);
struct s64 {
  float a;
  float b;
  float c;
  float d;
  float e;
  float f;
};
extern struct s64 f316(void);
extern void f317(struct s64 x0);
extern void f318(struct s64 x0, struct s64 x1);
extern void f319(int x0, struct s64 x1);
extern void f320(double x0, struct s64 x1);
struct s65 {
  float a;
  float b;
  float c;
  float d;
  float e;
  float f;
  float g;
  float h;
};
extern struct s65 f321(void);
extern void f322(struct s65 x0);
extern void f323(struct s65 x0, struct s65 x1);
extern void f324(int x0, struct s65 x1);
extern void f325(double x0, struct s65 x1);
struct s66 {
  double a;
  double b;
  double c;
};
extern struct s66 f326(void);
extern void f327(struct s66 x0);
extern void f328(struct s66 x0, struct s66 x1);
extern void f329(int x0, struct s66 x1);
extern void f330(double x0, struct s66 x1);
struct s67 {
  double a;
  double b;
  double c;
  double d;
};
extern struct s67 f331(void);
extern void f332(struct s67 x0);
extern void f333(struct s67 x0, struct s67 x1);
extern void f334(int x0, struct s67 x1);
extern void f335(double x0, struct s67 x1);
struct s68 {
  double a;
  double b;
  double c;
  double d;
  double e;
  double f;
};
extern struct s68 f336(void);
extern void f337(struct s68 x0);
extern void f338(struct s68 x0, struct s68 x1);
extern void f339(int x0, struct s68 x1);
extern void f340(double x0, struct s68 x1);
struct s69 {
  double a;
  double b;
  double c;
  double d;
  double e;
  double f;
  double g;
  double h;
};
extern struct s69 f341(void);
extern void f342(struct s69 x0);
extern void f343(struct s69 x0, struct s69 x1);
extern void f344(int x0, struct s69 x1);
extern void f345(double x0, struct s69 x1);
