#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "vararg_decl.h"

void f1(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  va_end(l);
  check (x0 == 359424978);
  check (x1 == -1562221124);
  check (x2 == 1815701022);
}

void f2(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == 1377895494);
  check (x1 == 786384645);
  check (x2 == -7464907809330185142);
}

void f3(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  va_end(l);
  check (x0 == -869060679);
  check (x1 == -1292962594);
  check (x2 == 0x1.1fc90e8ae4d78p+5);
}

void f4(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  va_end(l);
  check (x0 == -165825162);
  check (x1 == 2865677210277011461);
  check (x2 == 242953397);
}

void f5(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == 1902534691);
  check (x1 == -6641433098825932921);
  check (x2 == 7023089093677220574);
}

void f6(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  va_end(l);
  check (x0 == -1677478395);
  check (x1 == 763066718451839546);
  check (x2 == -0x1.5a88d9cb03d4ep+5);
}

void f7(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  va_end(l);
  check (x0 == 1076806509);
  check (x1 == -0x1.66b1425c8106ap+5);
  check (x2 == -201024218);
}

void f8(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == 508313204);
  check (x1 == 0x1.9d76d8f5f836p+4);
  check (x2 == -5795356962823460286);
}

void f9(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  va_end(l);
  check (x0 == -1819372239);
  check (x1 == -0x1.35448a73f98b9p+4);
  check (x2 == 0x1.4e73f70cf636ap+5);
}

void f10(long long x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  va_end(l);
  check (x0 == -4971797672212541531);
  check (x1 == -1922283024);
  check (x2 == -1113522804);
}

void f11(long long x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == -2489200765840530951);
  check (x1 == -147460712);
  check (x2 == -3617192151061228944);
}

void f12(long long x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  va_end(l);
  check (x0 == -3238782525965314528);
  check (x1 == -1224970120);
  check (x2 == -0x1.54fc0b912fd64p+5);
}

void f13(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  va_end(l);
  check (x0 == 6447444042990336358);
  check (x1 == 6306578937032190423);
  check (x2 == -837774178);
}

void f14(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == -3094182341537540600);
  check (x1 == 6582052121744720579);
  check (x2 == -8109874353755007897);
}

void f15(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  va_end(l);
  check (x0 == -1009011661423897945);
  check (x1 == -5748340618103229792);
  check (x2 == 0x1.c0ff22b9a895p+3);
}

void f16(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  va_end(l);
  check (x0 == -1307556698743366303);
  check (x1 == 0x1.49b1fe131e4e4p+4);
  check (x2 == 1967018687);
}

void f17(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == -8373128873323628130);
  check (x1 == -0x1.1b8b50730db52p+4);
  check (x2 == 6240028794231868543);
}

void f18(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  va_end(l);
  check (x0 == 219597293007463358);
  check (x1 == -0x1.209d248df9f1cp+5);
  check (x2 == 0x1.06b6844287feep+5);
}

void f19(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.cfabe8p+4F);
  check (x1 == -1112381232);
  check (x2 == -136078582);
}

void f20(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.058d46p+5F);
  check (x1 == -261564199);
  check (x2 == -816271512240593349);
}

void f21(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.0c5df4p+5F);
  check (x1 == 929994926);
  check (x2 == -0x1.094ee516a1758p+2);
}

void f22(float x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.768e52p+5F);
  check (x1 == 85495102829890918);
  check (x2 == -2058290849);
}

void f23(float x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.b3ed0cp+4F);
  check (x1 == -903189518129672391);
  check (x2 == -2962885905197277511);
}

void f24(float x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.0f5ba4p+4F);
  check (x1 == -423722403545853660);
  check (x2 == -0x1.753a9c9e51be6p+4);
}

void f25(float x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.3cb00ap+3F);
  check (x1 == 0x1.22424233d124cp+4);
  check (x2 == 1572015079);
}

void f26(float x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.3bd4e8p-2F);
  check (x1 == -0x1.7f0ba63263p-7);
  check (x2 == -2986530589438070174);
}

void f27(float x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.3ef7c8p+2F);
  check (x1 == 0x1.8465a13dd251p+4);
  check (x2 == -0x1.7d995dad1b01ap+5);
}

void f28(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.cf1a6da9f998p+1);
  check (x1 == -1518910039);
  check (x2 == -1607654603);
}

void f29(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.14842d560a37p+4);
  check (x1 == 1473128726);
  check (x2 == -3305590614301434542);
}

void f30(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.906b12247d51p+4);
  check (x1 == -613423447);
  check (x2 == -0x1.87727d845bbcp+1);
}

void f31(double x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.73554208220fp+4);
  check (x1 == -3664856455106978918);
  check (x2 == 775993642);
}

void f32(double x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.3b4046343c179p+4);
  check (x1 == -2281112740324733311);
  check (x2 == -5570156521017131236);
}

void f33(double x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.27f3c254363p-2);
  check (x1 == -4193600751476499094);
  check (x2 == 0x1.83d073d680ecp+1);
}

void f34(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.23a352476cfb6p+4);
  check (x1 == 0x1.b8259985b054p-1);
  check (x2 == -744195134);
}

void f35(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.f7c78c12f522cp+4);
  check (x1 == 0x1.6106b27e3c608p+2);
  check (x2 == -4992434273277327112);
}

void f36(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.0a099fc6d4a7cp+3);
  check (x1 == 0x1.7ea86cb6bc6acp+5);
  check (x2 == -0x1.088acf1b29a78p+2);
}

void f37(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -1445046092);
  check (x1 == -1975936579);
  check (x2 == 1730389472);
  check (x3 == 1478666504);
}

void f38(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 2121459177);
  check (x1 == 2103463326);
  check (x2 == -228551895);
  check (x3 == 7195013931605585044);
}

void f39(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -1640768698);
  check (x1 == 1401296338);
  check (x2 == -98877459);
  check (x3 == -0x1.7498b57458c42p+5);
}

void f40(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -1384038326);
  check (x1 == -1274047355);
  check (x2 == -3503088096956866809);
  check (x3 == 28133347);
}

void f41(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -1355722973);
  check (x1 == -1123699173);
  check (x2 == -310356697724664812);
  check (x3 == 5530916566671647935);
}

void f42(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 566498622);
  check (x1 == -164386158);
  check (x2 == 2454026593132767882);
  check (x3 == 0x1.334650848c9bp+5);
}

void f43(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -696938087);
  check (x1 == -1070080870);
  check (x2 == 0x1.17608ca595ef4p+3);
  check (x3 == 77906415);
}

void f44(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -199276533);
  check (x1 == -2145374759);
  check (x2 == 0x1.3a384bf073518p+4);
  check (x3 == 853874488809628856);
}

void f45(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 1506521253);
  check (x1 == -1858410359);
  check (x2 == 0x1.174c8a971aa9cp+4);
  check (x3 == 0x1.95a932ddd5878p+4);
}

void f46(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -1959346214);
  check (x1 == -2764389137750137807);
  check (x2 == -1871219255);
  check (x3 == 2142923641);
}

void f47(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -1569901924);
  check (x1 == -6043704264483072140);
  check (x2 == 170333871);
  check (x3 == 262717837599596757);
}

void f48(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 12610356);
  check (x1 == 7890885412985214173);
  check (x2 == -1114791576);
  check (x3 == -0x1.63a894d88733dp+5);
}

void f49(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -732874692);
  check (x1 == -7966584001606153128);
  check (x2 == 8201870088602307925);
  check (x3 == -1793312842);
}

void f50(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 1943647114);
  check (x1 == -530483447763922945);
  check (x2 == -3063565391278754656);
  check (x3 == 2238207705307226773);
}

void f51(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 1892913789);
  check (x1 == 7822206821611107814);
  check (x2 == 1140383201358012743);
  check (x3 == 0x1.f8a5108fc64bp+3);
}

void f52(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 1089849600);
  check (x1 == -6453396190629267522);
  check (x2 == 0x1.e617159111c6p+3);
  check (x3 == 511105398);
}

void f53(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -579219014);
  check (x1 == 4875847001392206432);
  check (x2 == 0x1.6666e8d6da7b2p+5);
  check (x3 == -4148770280024345250);
}

void f54(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 2019589566);
  check (x1 == 3643995881483418290);
  check (x2 == 0x1.303c017928c18p+3);
  check (x3 == -0x1.50a0d8fdfe7aap+5);
}

void f55(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -1764540629);
  check (x1 == 0x1.ee05e3df4ad08p+4);
  check (x2 == 147062550);
  check (x3 == 579382097);
}

void f56(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 205924480);
  check (x1 == 0x1.58403a407323ap+5);
  check (x2 == 1881146979);
  check (x3 == 2502368680755852513);
}

void f57(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 1837081861);
  check (x1 == -0x1.f6152a60bd36dp+4);
  check (x2 == 353368475);
  check (x3 == 0x1.082f29ade00b8p+5);
}

void f58(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 2028339913);
  check (x1 == 0x1.603d4384a88p+3);
  check (x2 == -5209146470440639169);
  check (x3 == 454829462);
}

void f59(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -849235975);
  check (x1 == 0x1.b4aa17e858e2cp+4);
  check (x2 == -3470538958400062728);
  check (x3 == -2446134964275251616);
}

void f60(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 819952374);
  check (x1 == -0x1.60b0d11dc6fdcp+4);
  check (x2 == 7922390524902826388);
  check (x3 == -0x1.ec6c0617c3f3fp+4);
}

void f61(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -1128257059);
  check (x1 == -0x1.570c225af493cp+3);
  check (x2 == -0x1.5e750b7e3dab3p+5);
  check (x3 == -1004428147);
}

void f62(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -1997500289);
  check (x1 == 0x1.71334196ef4fcp+3);
  check (x2 == -0x1.207aaf1ff6054p+5);
  check (x3 == -547787666650465496);
}

void f63(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 384626661);
  check (x1 == 0x1.1d8acfcb3347p+3);
  check (x2 == -0x1.0087d4b26222ap+4);
  check (x3 == -0x1.83300d2afadc1p+4);
}

void f64(long long x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -3685631349062350180);
  check (x1 == 1570397300);
  check (x2 == -1742504644);
  check (x3 == -750563089);
}

void f65(long long x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 97216063839586273);
  check (x1 == -1376062746);
  check (x2 == -1451620885);
  check (x3 == -6254705757323335590);
}

void f66(long long x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -8384246231275541477);
  check (x1 == -2051755498);
  check (x2 == 469225311);
  check (x3 == 0x1.49ac09d0a5f4p-1);
}

void f67(long long x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 4096375621822253700);
  check (x1 == -532450537);
  check (x2 == 1512102459350253406);
  check (x3 == -599449141);
}

void f68(long long x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 2813896935711592399);
  check (x1 == 1408947757);
  check (x2 == -5497088006292366087);
  check (x3 == 2039206422884399344);
}

void f69(long long x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 3005607600168193821);
  check (x1 == 82599028);
  check (x2 == -6009762168677869894);
  check (x3 == -0x1.123327bf64a9ap+5);
}

void f70(long long x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -3049073247352223820);
  check (x1 == 1938211837);
  check (x2 == -0x1.4d3e6a7e6e978p+3);
  check (x3 == 749165510);
}

void f71(long long x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -4851250440027904151);
  check (x1 == 294853913);
  check (x2 == 0x1.4efb51527d2e8p+4);
  check (x3 == 8958506565527435041);
}

void f72(long long x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 4116966074951466500);
  check (x1 == -22622776);
  check (x2 == 0x1.9fe3fc9a5a5b8p+3);
  check (x3 == 0x1.34f04e72af2ecp+5);
}

void f73(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 1924310484161439730);
  check (x1 == -5187201658317067911);
  check (x2 == -1883593375);
  check (x3 == 1176346314);
}

void f74(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -4162783042393750771);
  check (x1 == 1947624486602445359);
  check (x2 == -2114261717);
  check (x3 == 7415999042694616475);
}

void f75(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 8306851171896508373);
  check (x1 == 1655943856802705669);
  check (x2 == -15766459);
  check (x3 == -0x1.0ccdb527067bp+3);
}

void f76(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 6018749837755183769);
  check (x1 == -924026792401846729);
  check (x2 == 1538580925615931364);
  check (x3 == -380871711);
}

void f77(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -8817475389486941232);
  check (x1 == 7038150392182796620);
  check (x2 == -710116634788725456);
  check (x3 == -1125746084457454639);
}

void f78(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -2867377179166082689);
  check (x1 == 2438115870243609249);
  check (x2 == -5567481585363274997);
  check (x3 == 0x1.702ad9510438ap+5);
}

void f79(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -7392652832198131400);
  check (x1 == -2278402126921985524);
  check (x2 == 0x1.19f6223a7277p+4);
  check (x3 == 842257082);
}

void f80(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 2766526116231485049);
  check (x1 == -6539455330709863584);
  check (x2 == 0x1.5b3112b6d7e4p+5);
  check (x3 == 5072028129040829001);
}

void f81(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -5388975356473619580);
  check (x1 == -363550020020937075);
  check (x2 == -0x1.283a624285da4p+5);
  check (x3 == -0x1.0f67f6107ea0ap+4);
}

void f82(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -1514223337871268699);
  check (x1 == -0x1.782e17fb6da91p+5);
  check (x2 == 382796591);
  check (x3 == -1289446421);
}

void f83(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 8990493608382882555);
  check (x1 == -0x1.7bc8b0fb86f48p+3);
  check (x2 == -79725348);
  check (x3 == 2362011078066337442);
}

void f84(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 6723161287530045277);
  check (x1 == -0x1.c113ab9f4985p+2);
  check (x2 == 292665972);
  check (x3 == -0x1.18667f9b9b755p+5);
}

void f85(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -6126799388973932805);
  check (x1 == -0x1.3eac6dd88a13dp+5);
  check (x2 == -8614159119768975220);
  check (x3 == 529773661);
}

void f86(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -3897469818935181801);
  check (x1 == -0x1.b2f66a5acccep+2);
  check (x2 == -3410629010478134551);
  check (x3 == 3023028825705722044);
}

void f87(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 481733938141487684);
  check (x1 == 0x1.77f193b5d984p-1);
  check (x2 == -8116214728459333129);
  check (x3 == -0x1.a7a1895c713e5p+4);
}

void f88(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -6991194740902206945);
  check (x1 == 0x1.409d2f6ee7ac6p+5);
  check (x2 == -0x1.15bb2260b99e2p+4);
  check (x3 == -2008562512);
}

void f89(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 6230788033825020966);
  check (x1 == 0x1.c12606b863d84p+4);
  check (x2 == -0x1.74cfd1826968p+5);
  check (x3 == -2581553745515055050);
}

void f90(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -6026619660610185780);
  check (x1 == 0x1.3e8899133b3e8p+4);
  check (x2 == -0x1.eae4d7d07ab31p+4);
  check (x3 == 0x1.4db9b0c9db11cp+5);
}

void f91(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.51ea76p+5F);
  check (x1 == 657822410);
  check (x2 == -259680655);
  check (x3 == -1588868041);
}

void f92(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.614402p+5F);
  check (x1 == 105355747);
  check (x2 == -1817190970);
  check (x3 == 596821572915558576);
}

void f93(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.345574p+2F);
  check (x1 == -1344140964);
  check (x2 == -201762310);
  check (x3 == -0x1.1b5e3e815901p+3);
}

void f94(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.5b7388p+5F);
  check (x1 == 138831035);
  check (x2 == 5890915413734920096);
  check (x3 == 1170439507);
}

void f95(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.914f4ep+3F);
  check (x1 == -901708113);
  check (x2 == -2248472009846266261);
  check (x3 == 5916914735009836092);
}

void f96(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.839dbcp+5F);
  check (x1 == -1453289939);
  check (x2 == 3805885858168182106);
  check (x3 == 0x1.4f6079b59ccc6p+5);
}

void f97(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.e0a68p+3F);
  check (x1 == -226379304);
  check (x2 == 0x1.5d694b073972ep+5);
  check (x3 == -331382370);
}

void f98(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.d04898p+0F);
  check (x1 == -1988060205);
  check (x2 == 0x1.65a5ae61be03p+4);
  check (x3 == -6378160163883348121);
}

void f99(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.54a94ap+4F);
  check (x1 == -446753604);
  check (x2 == 0x1.fa9f700d4f2b4p+4);
  check (x3 == -0x1.7abbdd38ecad8p+3);
}

void f100(float x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.785eb4p+5F);
  check (x1 == 8135181758416272486);
  check (x2 == 444288557);
  check (x3 == 1539643957);
}

void f101(float x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.ccd0aap+4F);
  check (x1 == 2594920467080957417);
  check (x2 == 1661453363);
  check (x3 == -6931813258906711885);
}

void f102(float x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.01b14ap+4F);
  check (x1 == -2446778831495484759);
  check (x2 == -131672199);
  check (x3 == -0x1.09471b45dff2ep+4);
}

void f103(float x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.012b44p+4F);
  check (x1 == 3493084762587142371);
  check (x2 == -8353956116721848834);
  check (x3 == -960835659);
}

void f104(float x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.4c9d82p+5F);
  check (x1 == 1079692642011568313);
  check (x2 == -5910386215838478255);
  check (x3 == -853223942979755708);
}

void f105(float x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.82cbap+2F);
  check (x1 == -4204779356924275974);
  check (x2 == -1453838133056313875);
  check (x3 == -0x1.5ee3e8f11e13p+3);
}

void f106(float x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.4ecc0ep+4F);
  check (x1 == 4369025988183143195);
  check (x2 == 0x1.0d7cf31ff543p+2);
  check (x3 == 992757697);
}

void f107(float x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.e2a77cp+3F);
  check (x1 == -446113700451689138);
  check (x2 == 0x1.07eb594a69418p+5);
  check (x3 == -8036129073541119462);
}

void f108(float x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.60092ap+5F);
  check (x1 == 6138812719369568698);
  check (x2 == -0x1.6000e47b89207p+4);
  check (x3 == 0x1.ae05f06d853bcp+4);
}

void f109(float x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.3f231cp+4F);
  check (x1 == -0x1.5916815731c6cp+5);
  check (x2 == -664509735);
  check (x3 == 850864379);
}

void f110(float x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.12071p+1F);
  check (x1 == 0x1.3f12d053cadf2p+5);
  check (x2 == -918798096);
  check (x3 == 2159426877905288864);
}

void f111(float x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.70dc34p+4F);
  check (x1 == -0x1.775892a7cf36p+3);
  check (x2 == -90690405);
  check (x3 == -0x1.8c1eb17c835acp+5);
}

void f112(float x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.669f8ap+4F);
  check (x1 == 0x1.876593d53775cp+5);
  check (x2 == 1796586587475423713);
  check (x3 == 1810921833);
}

void f113(float x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.33baep+4F);
  check (x1 == -0x1.5b917bfede58fp+5);
  check (x2 == -3904746857552307209);
  check (x3 == -1465661783242108810);
}

void f114(float x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.0fe57ap+5F);
  check (x1 == 0x1.27514907bf828p+4);
  check (x2 == -1620968819502707764);
  check (x3 == -0x1.f55c57eef7d19p+4);
}

void f115(float x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.b1623cp+2F);
  check (x1 == 0x1.515891563167p+5);
  check (x2 == -0x1.6b390de7bf05dp+5);
  check (x3 == 1114458038);
}

void f116(float x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.6fbdeep+5F);
  check (x1 == -0x1.0be282fc42b42p+5);
  check (x2 == -0x1.d5953ceee778p+4);
  check (x3 == -4369754408188776218);
}

void f117(float x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.7a2812p+5F);
  check (x1 == 0x1.8e9010f21c408p+5);
  check (x2 == 0x1.6b5df6c3ecfd8p+2);
  check (x3 == -0x1.f742fc7054999p+4);
}

void f118(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.5c329cf45a3e8p+2);
  check (x1 == -1154072941);
  check (x2 == -1958617229);
  check (x3 == 1209040476);
}

void f119(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.41286af991318p+4);
  check (x1 == 1789290894);
  check (x2 == -162740179);
  check (x3 == -904784330988199112);
}

void f120(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.1fe6d381e6f1ap+5);
  check (x1 == -1472197982);
  check (x2 == -1837793097);
  check (x3 == 0x1.53012588e709cp+4);
}

void f121(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.2728a877eb524p+3);
  check (x1 == 1071652809);
  check (x2 == 6320105014614788560);
  check (x3 == 792354742);
}

void f122(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.c55cd912e6d9p+1);
  check (x1 == 2137893632);
  check (x2 == -8736419640509049470);
  check (x3 == 3447512007547072430);
}

void f123(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.9296876cf3d81p+4);
  check (x1 == 2017027596);
  check (x2 == -7668136696906663294);
  check (x3 == 0x1.608d50b9da21ep+5);
}

void f124(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.613fba2f70a66p+5);
  check (x1 == 335856087);
  check (x2 == 0x1.1b03cfca1b2d2p+5);
  check (x3 == 460985691);
}

void f125(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.02339a06901bep+5);
  check (x1 == 471009214);
  check (x2 == -0x1.2735a57e587bbp+5);
  check (x3 == 9038333908756567190);
}

void f126(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.29c3c4eaf8488p+5);
  check (x1 == -933765704);
  check (x2 == 0x1.229610cd16a2p+3);
  check (x3 == 0x1.a634423d9d65p+3);
}

void f127(double x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.34c7c96f228a6p+4);
  check (x1 == -5158525646333457425);
  check (x2 == -420226156);
  check (x3 == -808909499);
}

void f128(double x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.1adb0e8ef791ep+5);
  check (x1 == -5901522585009499217);
  check (x2 == 296626979);
  check (x3 == -1246838133130280089);
}

void f129(double x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.34323045fc12p+5);
  check (x1 == -8778424889350918429);
  check (x2 == -1680442135);
  check (x3 == 0x1.985b75fffb9dp+4);
}

void f130(double x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.d31d0341e5bfp+2);
  check (x1 == 4123036653640454683);
  check (x2 == -8146330331831504656);
  check (x3 == 40759530);
}

void f131(double x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.e716bf222a628p+2);
  check (x1 == -8548807017413479059);
  check (x2 == 3696032817293990332);
  check (x3 == 6194051204194735608);
}

void f132(double x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.8d745804e53b3p+4);
  check (x1 == -8771181705065488441);
  check (x2 == 7361763836308525961);
  check (x3 == -0x1.5e88fef0556f9p+4);
}

void f133(double x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.2c4fbe964a16p+0);
  check (x1 == -5765134792816289955);
  check (x2 == -0x1.4f82048d372a4p+5);
  check (x3 == 254104975);
}

void f134(double x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.58fe5d2b9cad4p+4);
  check (x1 == -3216582421759950188);
  check (x2 == -0x1.253b2530ccedep+5);
  check (x3 == -7993269371005905925);
}

void f135(double x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.0950a3bb5bdep+2);
  check (x1 == 842676686985466516);
  check (x2 == 0x1.23e1ba168f31cp+3);
  check (x3 == 0x1.712e62ea80988p+5);
}

void f136(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.8a940a9af1f0bp+5);
  check (x1 == -0x1.7b01d15d4faddp+5);
  check (x2 == 680468869);
  check (x3 == 1259447516);
}

void f137(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.0921982472b9cp+4);
  check (x1 == -0x1.91c7f0107720cp+4);
  check (x2 == -483271256);
  check (x3 == 6436233302697777269);
}

void f138(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.6fd5433cfe2dcp+3);
  check (x1 == -0x1.0565de824adep+2);
  check (x2 == -1109569469);
  check (x3 == 0x1.81cdd3752b504p+4);
}

void f139(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.7a21285a782ep+5);
  check (x1 == -0x1.3da512ca29e2fp+5);
  check (x2 == -4656627859361317666);
  check (x3 == 1391263886);
}

void f140(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.3cf7279c8cbd9p+5);
  check (x1 == -0x1.1e2fe964e2621p+5);
  check (x2 == 8379416732587422751);
  check (x3 == 7358346341353651142);
}

void f141(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.4af278b735f5cp+5);
  check (x1 == 0x1.0caac579b39eap+5);
  check (x2 == -6783838905289834688);
  check (x3 == -0x1.22a5acdc7b9a4p+3);
}

void f142(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.36986b7895d22p+5);
  check (x1 == -0x1.191113995caap+4);
  check (x2 == -0x1.8af519794e527p+4);
  check (x3 == 1964623228);
}

void f143(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.0ae03a8643801p+5);
  check (x1 == 0x1.7123526617e28p+5);
  check (x2 == -0x1.d76c7e2f21378p+3);
  check (x3 == 4256799072677778877);
}

void f144(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.d06a263de4f8p+1);
  check (x1 == 0x1.abd7230e6fec8p+4);
  check (x2 == -0x1.532f477b0360ap+5);
  check (x3 == 0x1.4236116f25428p+5);
}

void f145(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  int x4 = va_arg(l, int);
  int x5 = va_arg(l, int);
  va_end(l);
  check (x0 == -1416889597);
  check (x1 == 989435626);
  check (x2 == 549881158);
  check (x3 == 1985631473);
  check (x4 == -1166221679);
  check (x5 == -892096705);
}

void f146(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  int x4 = va_arg(l, int);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  va_end(l);
  check (x0 == 514272135);
  check (x1 == 42417971);
  check (x2 == 1214146102);
  check (x3 == -284511380);
  check (x4 == -1815646765);
  check (x5 == -229073129);
  check (x6 == 1929277135);
  check (x7 == 802908122);
}

void f147(int x0, int x1, int x2, int x3, int x4, int x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  va_end(l);
  check (x0 == -1996283125);
  check (x1 == -1448643279);
  check (x2 == 1887474008);
  check (x3 == 891641358);
  check (x4 == 636169479);
  check (x5 == 1229841940);
  check (x6 == 1551449701);
  check (x7 == 1531753642);
}

void f148(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  int x4 = va_arg(l, int);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  va_end(l);
  check (x0 == -372205195);
  check (x1 == 1896203899);
  check (x2 == -824377265);
  check (x3 == 1300715519);
  check (x4 == -394731009);
  check (x5 == -1007005517);
  check (x6 == 1413980321);
  check (x7 == 1077625376);
  check (x8 == 1323240971);
  check (x9 == -381270210);
}

void f149(int x0, int x1, int x2, int x3, int x4, int x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  va_end(l);
  check (x0 == 636432176);
  check (x1 == 597083034);
  check (x2 == -397991165);
  check (x3 == -1635539635);
  check (x4 == -1072318227);
  check (x5 == 1891897078);
  check (x6 == -78072112);
  check (x7 == 2033699987);
  check (x8 == 1487976713);
  check (x9 == 871265326);
}

void f150(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  int x4 = va_arg(l, int);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  va_end(l);
  check (x0 == -1976752092);
  check (x1 == 153693369);
  check (x2 == 1909645720);
  check (x3 == 145098420);
  check (x4 == 180688047);
  check (x5 == -1897243712);
  check (x6 == -401417275);
  check (x7 == 1525741539);
  check (x8 == 227031579);
  check (x9 == 182687599);
  check (x10 == 1786720666);
  check (x11 == -700648310);
}

void f151(int x0, int x1, int x2, int x3, int x4, int x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  va_end(l);
  check (x0 == -813832358);
  check (x1 == 1617287439);
  check (x2 == 674741904);
  check (x3 == -1689932413);
  check (x4 == 228823011);
  check (x5 == -272260654);
  check (x6 == -1252414069);
  check (x7 == -111373395);
  check (x8 == -1100393839);
  check (x9 == -1488973280);
  check (x10 == -1992630175);
  check (x11 == 1336918965);
}

void f152(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  int x4 = va_arg(l, int);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  va_end(l);
  check (x0 == 854053192);
  check (x1 == -1865537446);
  check (x2 == -72472895);
  check (x3 == 1431150033);
  check (x4 == -355212525);
  check (x5 == 834702231);
  check (x6 == 696931964);
  check (x7 == -841584278);
  check (x8 == 1694736698);
  check (x9 == 1512734292);
  check (x10 == 723534493);
  check (x11 == -987499469);
  check (x12 == -1124635463);
  check (x13 == -1222947356);
  check (x14 == 167800257);
  check (x15 == -1397585518);
}

void f153(int x0, int x1, int x2, int x3, int x4, int x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  va_end(l);
  check (x0 == 1095598425);
  check (x1 == 1881687105);
  check (x2 == 2119507733);
  check (x3 == -222870089);
  check (x4 == 469662150);
  check (x5 == 835498177);
  check (x6 == 1344831068);
  check (x7 == -881533844);
  check (x8 == 740163245);
  check (x9 == -980083198);
  check (x10 == -1610444177);
  check (x11 == 1423080858);
  check (x12 == -1237381754);
  check (x13 == -1226179442);
  check (x14 == 1880629498);
  check (x15 == 1544603676);
}

void f154(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7, int x8, int x9, int x10, int x11, int x12, int x13, ...)
{
  va_list l;
  va_start(l, x13);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  va_end(l);
  check (x0 == -624752815);
  check (x1 == 1039172962);
  check (x2 == 1417609089);
  check (x3 == -790620295);
  check (x4 == -1607062814);
  check (x5 == -1135571617);
  check (x6 == 461410476);
  check (x7 == 1868464243);
  check (x8 == 864959002);
  check (x9 == 1746220267);
  check (x10 == -88051703);
  check (x11 == -1304103250);
  check (x12 == -115509353);
  check (x13 == -376145423);
  check (x14 == 848523956);
  check (x15 == -1533487293);
}

void f155(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  int x4 = va_arg(l, int);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  int x16 = va_arg(l, int);
  int x17 = va_arg(l, int);
  int x18 = va_arg(l, int);
  int x19 = va_arg(l, int);
  int x20 = va_arg(l, int);
  int x21 = va_arg(l, int);
  int x22 = va_arg(l, int);
  int x23 = va_arg(l, int);
  int x24 = va_arg(l, int);
  int x25 = va_arg(l, int);
  int x26 = va_arg(l, int);
  int x27 = va_arg(l, int);
  int x28 = va_arg(l, int);
  int x29 = va_arg(l, int);
  int x30 = va_arg(l, int);
  int x31 = va_arg(l, int);
  va_end(l);
  check (x0 == 57605404);
  check (x1 == -960267905);
  check (x2 == 1203813435);
  check (x3 == -1536225593);
  check (x4 == 1298251681);
  check (x5 == -274471940);
  check (x6 == -445871988);
  check (x7 == -655054479);
  check (x8 == -996548042);
  check (x9 == 800167122);
  check (x10 == -1014681974);
  check (x11 == 598602536);
  check (x12 == -923070297);
  check (x13 == 1447867762);
  check (x14 == -816462611);
  check (x15 == 935566346);
  check (x16 == -1145805478);
  check (x17 == 535838414);
  check (x18 == 753779831);
  check (x19 == -177629987);
  check (x20 == 1050023806);
  check (x21 == -444193967);
  check (x22 == 95814945);
  check (x23 == 559535739);
  check (x24 == 1175548532);
  check (x25 == -649735938);
  check (x26 == -585249651);
  check (x27 == 1252130810);
  check (x28 == 390215065);
  check (x29 == -1413877754);
  check (x30 == 1372447392);
  check (x31 == -268873303);
}

void f156(int x0, int x1, int x2, int x3, int x4, int x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  int x16 = va_arg(l, int);
  int x17 = va_arg(l, int);
  int x18 = va_arg(l, int);
  int x19 = va_arg(l, int);
  int x20 = va_arg(l, int);
  int x21 = va_arg(l, int);
  int x22 = va_arg(l, int);
  int x23 = va_arg(l, int);
  int x24 = va_arg(l, int);
  int x25 = va_arg(l, int);
  int x26 = va_arg(l, int);
  int x27 = va_arg(l, int);
  int x28 = va_arg(l, int);
  int x29 = va_arg(l, int);
  int x30 = va_arg(l, int);
  int x31 = va_arg(l, int);
  va_end(l);
  check (x0 == 1157214751);
  check (x1 == 1589932050);
  check (x2 == 1476300076);
  check (x3 == -1430437561);
  check (x4 == -1229436278);
  check (x5 == -1962571362);
  check (x6 == 428826351);
  check (x7 == 295164091);
  check (x8 == -1060434379);
  check (x9 == -47508621);
  check (x10 == -37766873);
  check (x11 == -267438621);
  check (x12 == 539243951);
  check (x13 == -94908942);
  check (x14 == 1879063041);
  check (x15 == 168173221);
  check (x16 == 659372969);
  check (x17 == 1921467845);
  check (x18 == -644358521);
  check (x19 == -2132323439);
  check (x20 == 1853736657);
  check (x21 == 1062458584);
  check (x22 == -1924230095);
  check (x23 == -1686728487);
  check (x24 == -861751977);
  check (x25 == -2088103259);
  check (x26 == -560445732);
  check (x27 == 1544339429);
  check (x28 == 457068933);
  check (x29 == -787090403);
  check (x30 == 868295885);
  check (x31 == -960511181);
}

void f157(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7, int x8, int x9, int x10, int x11, int x12, int x13, ...)
{
  va_list l;
  va_start(l, x13);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  int x16 = va_arg(l, int);
  int x17 = va_arg(l, int);
  int x18 = va_arg(l, int);
  int x19 = va_arg(l, int);
  int x20 = va_arg(l, int);
  int x21 = va_arg(l, int);
  int x22 = va_arg(l, int);
  int x23 = va_arg(l, int);
  int x24 = va_arg(l, int);
  int x25 = va_arg(l, int);
  int x26 = va_arg(l, int);
  int x27 = va_arg(l, int);
  int x28 = va_arg(l, int);
  int x29 = va_arg(l, int);
  int x30 = va_arg(l, int);
  int x31 = va_arg(l, int);
  va_end(l);
  check (x0 == -1719514255);
  check (x1 == 653247991);
  check (x2 == -1860247192);
  check (x3 == 198590481);
  check (x4 == -1814175504);
  check (x5 == 1663089875);
  check (x6 == -1633717052);
  check (x7 == 721673904);
  check (x8 == -1265683896);
  check (x9 == 239682285);
  check (x10 == 1164668419);
  check (x11 == 1756213581);
  check (x12 == -580464282);
  check (x13 == 1706252649);
  check (x14 == 14317483);
  check (x15 == 449790809);
  check (x16 == -505927198);
  check (x17 == -1445697325);
  check (x18 == -289864456);
  check (x19 == 1196824785);
  check (x20 == 1701047255);
  check (x21 == -627316430);
  check (x22 == -342995323);
  check (x23 == -773532940);
  check (x24 == 385752727);
  check (x25 == -1768470496);
  check (x26 == -623493518);
  check (x27 == 1620120436);
  check (x28 == -1054209673);
  check (x29 == 1082147019);
  check (x30 == -635026671);
  check (x31 == 2001266504);
}

void f158(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  va_end(l);
  check (x0 == -5138430401274632811);
  check (x1 == -2065429908643735626);
  check (x2 == 7156747918579539497);
  check (x3 == 1889624012293684361);
  check (x4 == 7730674279948387405);
  check (x5 == -1361991442091970310);
}

void f159(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  va_end(l);
  check (x0 == -5647120799942789603);
  check (x1 == 5681314785231712022);
  check (x2 == -7153494674054534766);
  check (x3 == -5604780313563474845);
  check (x4 == -6517368045522489634);
  check (x5 == -7996727095238576820);
  check (x6 == 7951850076805813309);
  check (x7 == 1072617192320951081);
}

void f160(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  va_end(l);
  check (x0 == 5370986570565925808);
  check (x1 == 8987646762597354743);
  check (x2 == 1313767108689385216);
  check (x3 == 310382890322352710);
  check (x4 == -7625140031200871166);
  check (x5 == 6230910873971966405);
  check (x6 == 3188053628766003827);
  check (x7 == 3894251671286241365);
}

void f161(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  va_end(l);
  check (x0 == -8946778096555650251);
  check (x1 == -2376092173181403518);
  check (x2 == 5164654117555791239);
  check (x3 == 595918833979128647);
  check (x4 == 128963344397007561);
  check (x5 == 8612069310914500196);
  check (x6 == -4813145566795079855);
  check (x7 == -3838631481694339580);
  check (x8 == -1744735189103047269);
  check (x9 == 5978119237157745548);
}

void f162(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  va_end(l);
  check (x0 == 3328720460983628328);
  check (x1 == -9155901278121633934);
  check (x2 == 4889171545636726555);
  check (x3 == -6605337829112327554);
  check (x4 == -1721970875841844209);
  check (x5 == 1885059846851751772);
  check (x6 == 3183841180715191807);
  check (x7 == 4610083186076444933);
  check (x8 == 9064086029710947646);
  check (x9 == 1664735137301258800);
}

void f163(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  va_end(l);
  check (x0 == 1738534457876028595);
  check (x1 == 8398245934073599286);
  check (x2 == 2404150199276534881);
  check (x3 == -413469928417042782);
  check (x4 == 8075553462705350886);
  check (x5 == 6616730034542351317);
  check (x6 == 7225590006799330577);
  check (x7 == -3078810585043605504);
  check (x8 == -6913565872607961278);
  check (x9 == 3449295451502157911);
  check (x10 == 6321153245081853427);
  check (x11 == -5154469733998345801);
}

void f164(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  va_end(l);
  check (x0 == -2636952044700804645);
  check (x1 == 2106706550183726330);
  check (x2 == -6976409780377772289);
  check (x3 == 4057518156153265300);
  check (x4 == -7477891924552959926);
  check (x5 == -6320855859911932033);
  check (x6 == 3935376049511752050);
  check (x7 == -6590015501619187600);
  check (x8 == -5399390337454439163);
  check (x9 == -2836254641330925163);
  check (x10 == -3971325912302539598);
  check (x11 == 8165075520375979388);
}

void f165(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  long long x14 = va_arg(l, long long);
  long long x15 = va_arg(l, long long);
  va_end(l);
  check (x0 == 8021367050294595689);
  check (x1 == 5966289387050517868);
  check (x2 == -7251756001158949497);
  check (x3 == -461282064023901131);
  check (x4 == 7109988575795088431);
  check (x5 == 7034939172948071308);
  check (x6 == 7424051237976585391);
  check (x7 == -1208494439316553845);
  check (x8 == 9120136251407028621);
  check (x9 == -7095616490480762670);
  check (x10 == -74090135265001715);
  check (x11 == 9210700778121023134);
  check (x12 == 3723443027841607681);
  check (x13 == -6924490146476521235);
  check (x14 == -3050881640756342740);
  check (x15 == 7333907952850625862);
}

void f166(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  long long x14 = va_arg(l, long long);
  long long x15 = va_arg(l, long long);
  va_end(l);
  check (x0 == -4465419502713426560);
  check (x1 == 3554545626042267272);
  check (x2 == -8037095940923102799);
  check (x3 == -4038227020892648462);
  check (x4 == -7810359266076428556);
  check (x5 == 4869086151445624813);
  check (x6 == 4494448565390693015);
  check (x7 == 4944615466877424437);
  check (x8 == 4169686391845976670);
  check (x9 == -5045408152623293315);
  check (x10 == 7414262994632409334);
  check (x11 == -3193567555580175562);
  check (x12 == -7796428337446052608);
  check (x13 == 3534457841146480083);
  check (x14 == -6833732212678890153);
  check (x15 == 6937780809066017729);
}

void f167(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7, long long x8, long long x9, long long x10, long long x11, long long x12, long long x13, ...)
{
  va_list l;
  va_start(l, x13);
  long long x14 = va_arg(l, long long);
  long long x15 = va_arg(l, long long);
  va_end(l);
  check (x0 == -1167674898460290603);
  check (x1 == -6359820037429637114);
  check (x2 == 8855730952456200504);
  check (x3 == -3158877631101955653);
  check (x4 == 8004260390163514096);
  check (x5 == 253178229707113610);
  check (x6 == -9124698134849112717);
  check (x7 == 378231293743041269);
  check (x8 == 3360430034956634054);
  check (x9 == 3215452256746537435);
  check (x10 == 8266611502231135777);
  check (x11 == -4158007861552482946);
  check (x12 == -2598023572967750354);
  check (x13 == -822036932612697331);
  check (x14 == 8049817753290897554);
  check (x15 == -2023975685860521022);
}

void f168(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  long long x14 = va_arg(l, long long);
  long long x15 = va_arg(l, long long);
  long long x16 = va_arg(l, long long);
  long long x17 = va_arg(l, long long);
  long long x18 = va_arg(l, long long);
  long long x19 = va_arg(l, long long);
  long long x20 = va_arg(l, long long);
  long long x21 = va_arg(l, long long);
  long long x22 = va_arg(l, long long);
  long long x23 = va_arg(l, long long);
  long long x24 = va_arg(l, long long);
  long long x25 = va_arg(l, long long);
  long long x26 = va_arg(l, long long);
  long long x27 = va_arg(l, long long);
  long long x28 = va_arg(l, long long);
  long long x29 = va_arg(l, long long);
  long long x30 = va_arg(l, long long);
  long long x31 = va_arg(l, long long);
  va_end(l);
  check (x0 == 7680766453139706011);
  check (x1 == -4173749765766461189);
  check (x2 == -3979651924177130329);
  check (x3 == 4302565634605308061);
  check (x4 == -3400428953905979642);
  check (x5 == 960494875819953564);
  check (x6 == -5407556641038319871);
  check (x7 == -3820755374648326114);
  check (x8 == -6243566852583913483);
  check (x9 == -1112621103225466691);
  check (x10 == -1972486418233502026);
  check (x11 == 5499555596280382977);
  check (x12 == -2514344024409023463);
  check (x13 == -7761116748253345247);
  check (x14 == -5857846572070150943);
  check (x15 == 3606497515113782022);
  check (x16 == -1787123078591100410);
  check (x17 == -8074837532177768375);
  check (x18 == -7573110075921279587);
  check (x19 == 4106671772660410051);
  check (x20 == -3366188543703054616);
  check (x21 == 1559156442762609988);
  check (x22 == 7618761467045217599);
  check (x23 == 7901044983409236442);
  check (x24 == -7846021161666937389);
  check (x25 == -8606577777302620539);
  check (x26 == 5028231680057739307);
  check (x27 == -2867357632849617873);
  check (x28 == -8801394156760143287);
  check (x29 == 1562463476130034573);
  check (x30 == 8727775012063320845);
  check (x31 == 9205346156416653280);
}

void f169(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  long long x14 = va_arg(l, long long);
  long long x15 = va_arg(l, long long);
  long long x16 = va_arg(l, long long);
  long long x17 = va_arg(l, long long);
  long long x18 = va_arg(l, long long);
  long long x19 = va_arg(l, long long);
  long long x20 = va_arg(l, long long);
  long long x21 = va_arg(l, long long);
  long long x22 = va_arg(l, long long);
  long long x23 = va_arg(l, long long);
  long long x24 = va_arg(l, long long);
  long long x25 = va_arg(l, long long);
  long long x26 = va_arg(l, long long);
  long long x27 = va_arg(l, long long);
  long long x28 = va_arg(l, long long);
  long long x29 = va_arg(l, long long);
  long long x30 = va_arg(l, long long);
  long long x31 = va_arg(l, long long);
  va_end(l);
  check (x0 == -7123046257320256755);
  check (x1 == 8684778297488049079);
  check (x2 == -89071364333319842);
  check (x3 == 2716010182160077985);
  check (x4 == -7587916929990714799);
  check (x5 == 6439578625645459108);
  check (x6 == -2973129288417525763);
  check (x7 == -5416532997039398122);
  check (x8 == 1181881368689918297);
  check (x9 == 1297379220444967017);
  check (x10 == -7601942277525814791);
  check (x11 == 1329616920946101187);
  check (x12 == 7895414843047260292);
  check (x13 == -8208682825376253666);
  check (x14 == 285593680464961954);
  check (x15 == -1032623352286291047);
  check (x16 == -5730518312854327492);
  check (x17 == -2174934019558193692);
  check (x18 == -7538460525400492011);
  check (x19 == 7420349528745639309);
  check (x20 == 2240762522255761272);
  check (x21 == 3777878199679308190);
  check (x22 == 5234295786590818024);
  check (x23 == -3504737477111085989);
  check (x24 == 4621235212134634086);
  check (x25 == 5846513951038241238);
  check (x26 == -7792519515530593487);
  check (x27 == -9090833822273424832);
  check (x28 == 8128429077318725493);
  check (x29 == -1773330441488007043);
  check (x30 == -1597955878845432235);
  check (x31 == 6156657326302067351);
}

void f170(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7, long long x8, long long x9, long long x10, long long x11, long long x12, long long x13, ...)
{
  va_list l;
  va_start(l, x13);
  long long x14 = va_arg(l, long long);
  long long x15 = va_arg(l, long long);
  long long x16 = va_arg(l, long long);
  long long x17 = va_arg(l, long long);
  long long x18 = va_arg(l, long long);
  long long x19 = va_arg(l, long long);
  long long x20 = va_arg(l, long long);
  long long x21 = va_arg(l, long long);
  long long x22 = va_arg(l, long long);
  long long x23 = va_arg(l, long long);
  long long x24 = va_arg(l, long long);
  long long x25 = va_arg(l, long long);
  long long x26 = va_arg(l, long long);
  long long x27 = va_arg(l, long long);
  long long x28 = va_arg(l, long long);
  long long x29 = va_arg(l, long long);
  long long x30 = va_arg(l, long long);
  long long x31 = va_arg(l, long long);
  va_end(l);
  check (x0 == 3644771427546716394);
  check (x1 == 4138865106599557496);
  check (x2 == 2710136159944319893);
  check (x3 == -7405677939958724101);
  check (x4 == 4584557111659572086);
  check (x5 == -143619041452032619);
  check (x6 == -8136937344329903290);
  check (x7 == 8674866750732785226);
  check (x8 == -5389935272339472491);
  check (x9 == 6559957627809696811);
  check (x10 == -4241125726455397128);
  check (x11 == -3133532764997106330);
  check (x12 == 2368620295178091787);
  check (x13 == 6721548268360333262);
  check (x14 == 3246881501047318098);
  check (x15 == 5493454027407917657);
  check (x16 == 5329902734942066901);
  check (x17 == 3239767908675527246);
  check (x18 == -4062713956091839771);
  check (x19 == -9096902404860319124);
  check (x20 == 5797636537374168158);
  check (x21 == -4476829549485306179);
  check (x22 == 4799883693226891250);
  check (x23 == -4618506863822635254);
  check (x24 == 2675255833659187347);
  check (x25 == -4880096111261388088);
  check (x26 == 7192939112115659504);
  check (x27 == 7890614073790724546);
  check (x28 == 597206298824234801);
  check (x29 == 2765211231409344531);
  check (x30 == -189821609327887032);
  check (x31 == 8416332516349927221);
}

void f171(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.71ac5b773e687p+4);
  check (x1 == -0x1.61db95a1c1bd7p+5);
  check (x2 == 0x1.9e3bac299cea4p+4);
  check (x3 == -0x1.760879f9dcbbp+3);
  check (x4 == -0x1.2831a6696a717p+4);
  check (x5 == 0x1.ee5962549df5p+2);
}

void f172(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.793ac644eabd2p+5);
  check (x1 == -0x1.a4da56907f0ap+2);
  check (x2 == 0x1.6af8258d26c1ap+5);
  check (x3 == 0x1.749eb80bee68p+1);
  check (x4 == -0x1.848a06b2abeep+1);
  check (x5 == 0x1.8a704e295beep+0);
  check (x6 == 0x1.c9ef30344313p+4);
  check (x7 == -0x1.34c8f69e8481ep+5);
}

void f173(double x0, double x1, double x2, double x3, double x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.497547b80c867p+4);
  check (x1 == 0x1.d4a059ea4f89p+4);
  check (x2 == 0x1.7cd073b5bbf5cp+4);
  check (x3 == 0x1.a578561fe9edcp+3);
  check (x4 == -0x1.31031a2ae68b4p+5);
  check (x5 == 0x1.3909e51ac6622p+5);
  check (x6 == 0x1.e09937b742e8p+3);
  check (x7 == -0x1.237a66bc123fp+4);
}

void f174(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.42ae1cd3cff8p+0);
  check (x1 == -0x1.678f6bb15f73bp+5);
  check (x2 == 0x1.608bf197a3338p+4);
  check (x3 == 0x1.9f2b97e0392d4p+3);
  check (x4 == -0x1.0d472acbd4eeap+5);
  check (x5 == 0x1.e12aa3008f4d4p+4);
  check (x6 == 0x1.7e702a5c3085ap+5);
  check (x7 == -0x1.ef9c0b82d4918p+2);
  check (x8 == 0x1.384ad7e653198p+4);
  check (x9 == 0x1.a3089f8b3384p+1);
}

void f175(double x0, double x1, double x2, double x3, double x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.338e86f7a93dap+5);
  check (x1 == -0x1.dde70f9cc6b5ep+4);
  check (x2 == -0x1.04bf8ae9be42ap+4);
  check (x3 == 0x1.1bbdc31f2374cp+4);
  check (x4 == 0x1.1d71c3d18c79cp+5);
  check (x5 == -0x1.730fcd46e9cd2p+5);
  check (x6 == 0x1.6adaee83c7334p+5);
  check (x7 == 0x1.33233ad04c414p+3);
  check (x8 == -0x1.b63687d4ac27p+3);
  check (x9 == -0x1.4d98e6e267f08p+4);
}

void f176(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.34253d9bc8074p+5);
  check (x1 == 0x1.ce808ac9ae58p+3);
  check (x2 == -0x1.900b6262193cep+4);
  check (x3 == -0x1.3f3f9dd25255bp+5);
  check (x4 == 0x1.dccd30ba59128p+4);
  check (x5 == -0x1.51821ae533164p+5);
  check (x6 == -0x1.563d3d4da2595p+4);
  check (x7 == 0x1.febcbe53e9e88p+2);
  check (x8 == -0x1.0db9448784a54p+3);
  check (x9 == 0x1.6784e119993dep+5);
  check (x10 == -0x1.cdc0e65c92422p+4);
  check (x11 == 0x1.59225318a5d8cp+4);
}

void f177(double x0, double x1, double x2, double x3, double x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.7952416389b0fp+5);
  check (x1 == 0x1.8af7d37fabc4p+2);
  check (x2 == 0x1.4c5d62b5438a2p+5);
  check (x3 == 0x1.0c2c591da004p+0);
  check (x4 == 0x1.af671c4940018p+4);
  check (x5 == 0x1.ae4f93f86e854p+4);
  check (x6 == -0x1.7ad853e0a3b95p+4);
  check (x7 == 0x1.4359fd3347336p+5);
  check (x8 == 0x1.8f5210796036cp+4);
  check (x9 == -0x1.212cba360e8cep+5);
  check (x10 == -0x1.ac900906dacdcp+3);
  check (x11 == 0x1.09827affb31f2p+5);
}

void f178(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  double x14 = va_arg(l, double);
  double x15 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.49d8e9e3c49b2p+4);
  check (x1 == -0x1.4d0ab2702ec94p+5);
  check (x2 == -0x1.210be61546e14p+3);
  check (x3 == 0x1.dc8fa2a4b8968p+2);
  check (x4 == 0x1.88439d19ca22p+5);
  check (x5 == -0x1.624515946c039p+5);
  check (x6 == 0x1.ad553d5922bd8p+4);
  check (x7 == 0x1.8c89fe58921c8p+3);
  check (x8 == 0x1.442c669461a24p+3);
  check (x9 == 0x1.0e7b52e72d2d8p+4);
  check (x10 == 0x1.011c1ffaddd4ep+5);
  check (x11 == 0x1.83bc80030cc66p+5);
  check (x12 == -0x1.aa78400de2a6p+0);
  check (x13 == 0x1.6015c58432c14p+4);
  check (x14 == -0x1.5cfa3ce89023bp+4);
  check (x15 == -0x1.5ff3cb94f62ep+0);
}

void f179(double x0, double x1, double x2, double x3, double x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  double x14 = va_arg(l, double);
  double x15 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.61abced607052p+5);
  check (x1 == 0x1.4c74743111512p+5);
  check (x2 == 0x1.6209862920d34p+4);
  check (x3 == 0x1.6a88b13f8fcd6p+5);
  check (x4 == -0x1.74c0d8fc008d8p+3);
  check (x5 == -0x1.403ef4bc58ea6p+4);
  check (x6 == 0x1.4aee9f6264f9cp+5);
  check (x7 == 0x1.4441f28933e4p+4);
  check (x8 == 0x1.4809d3e58b42p+3);
  check (x9 == 0x1.3390b74c30878p+4);
  check (x10 == -0x1.40069ed5a81f8p+5);
  check (x11 == 0x1.ba75463b4fbfp+1);
  check (x12 == 0x1.aa97635cdbfc8p+3);
  check (x13 == -0x1.16728b2973ff4p+5);
  check (x14 == 0x1.5ec2dfc527fdp+2);
  check (x15 == -0x1.bb63586bdb6ap+1);
}

void f180(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11, double x12, double x13, ...)
{
  va_list l;
  va_start(l, x13);
  double x14 = va_arg(l, double);
  double x15 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.195366cb27bdcp+5);
  check (x1 == -0x1.e3797235d0ap-1);
  check (x2 == 0x1.3a2a3b2f3d7bp+4);
  check (x3 == -0x1.13dd5df692a68p+4);
  check (x4 == 0x1.1510c5549ed74p+4);
  check (x5 == 0x1.02ceb09471e2cp+3);
  check (x6 == -0x1.8651ed57cfd5p+5);
  check (x7 == 0x1.9ddb22b2eebep+0);
  check (x8 == 0x1.3c6916f592bacp+5);
  check (x9 == 0x1.a7e74fca4e99cp+4);
  check (x10 == -0x1.b2b57bb6e83bcp+3);
  check (x11 == -0x1.407eed47bd612p+5);
  check (x12 == -0x1.455c3caa75cbp+2);
  check (x13 == -0x1.82a5b027a7f85p+5);
  check (x14 == -0x1.1b7a52c50c8b8p+5);
  check (x15 == 0x1.33cd2b0a7693cp+4);
}

void f181(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  double x14 = va_arg(l, double);
  double x15 = va_arg(l, double);
  double x16 = va_arg(l, double);
  double x17 = va_arg(l, double);
  double x18 = va_arg(l, double);
  double x19 = va_arg(l, double);
  double x20 = va_arg(l, double);
  double x21 = va_arg(l, double);
  double x22 = va_arg(l, double);
  double x23 = va_arg(l, double);
  double x24 = va_arg(l, double);
  double x25 = va_arg(l, double);
  double x26 = va_arg(l, double);
  double x27 = va_arg(l, double);
  double x28 = va_arg(l, double);
  double x29 = va_arg(l, double);
  double x30 = va_arg(l, double);
  double x31 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.de2425d6e1198p+4);
  check (x1 == 0x1.0edd4e0e14a9p+1);
  check (x2 == -0x1.3bd852f6dff1p+5);
  check (x3 == -0x1.06e1f6833e6dcp+4);
  check (x4 == 0x1.ba5e3f7ae456cp+4);
  check (x5 == 0x1.5202de35e9f02p+5);
  check (x6 == 0x1.8e3a12734efp-2);
  check (x7 == 0x1.226e7b962258cp+5);
  check (x8 == -0x1.c65924cac7888p+4);
  check (x9 == -0x1.5543d4ba09fb9p+5);
  check (x10 == -0x1.4ec5f40d8354p+5);
  check (x11 == 0x1.90451623cadcp-1);
  check (x12 == -0x1.6fceb5f73d608p+5);
  check (x13 == 0x1.a918fff3ae638p+4);
  check (x14 == 0x1.8c7dad95066b4p+5);
  check (x15 == -0x1.c003da8c8040cp+4);
  check (x16 == 0x1.9ee19d78ccd3cp+4);
  check (x17 == -0x1.efc60ce0e5e7cp+3);
  check (x18 == 0x1.5c1f84fbeeaep+4);
  check (x19 == -0x1.bb19d7b368224p+3);
  check (x20 == 0x1.289e88b0ccc1cp+4);
  check (x21 == -0x1.37124e3a0978p-1);
  check (x22 == -0x1.56c21b3aa643bp+5);
  check (x23 == -0x1.3c9f67347841cp+5);
  check (x24 == 0x1.8383075fd09f8p+5);
  check (x25 == -0x1.e7efc513bf4c3p+4);
  check (x26 == 0x1.829d5a22d6ffp+5);
  check (x27 == 0x1.ccb0f6a809eap+1);
  check (x28 == -0x1.43c1ec1605e52p+4);
  check (x29 == -0x1.330bc45750b58p+2);
  check (x30 == -0x1.67d5cfdbbd6a9p+5);
  check (x31 == 0x1.8c4a9784e468cp+4);
}

void f182(double x0, double x1, double x2, double x3, double x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  double x14 = va_arg(l, double);
  double x15 = va_arg(l, double);
  double x16 = va_arg(l, double);
  double x17 = va_arg(l, double);
  double x18 = va_arg(l, double);
  double x19 = va_arg(l, double);
  double x20 = va_arg(l, double);
  double x21 = va_arg(l, double);
  double x22 = va_arg(l, double);
  double x23 = va_arg(l, double);
  double x24 = va_arg(l, double);
  double x25 = va_arg(l, double);
  double x26 = va_arg(l, double);
  double x27 = va_arg(l, double);
  double x28 = va_arg(l, double);
  double x29 = va_arg(l, double);
  double x30 = va_arg(l, double);
  double x31 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.8f89daf93601p+3);
  check (x1 == -0x1.b10598c64f753p+4);
  check (x2 == 0x1.42140cc444b0cp+5);
  check (x3 == -0x1.deb1b63962bfcp+4);
  check (x4 == 0x1.4dde9457122bp+3);
  check (x5 == 0x1.cb34289e2eff4p+4);
  check (x6 == 0x1.5ba6c3b69dfbp+1);
  check (x7 == 0x1.74cfc3792686cp+5);
  check (x8 == 0x1.378b91c93b45p+3);
  check (x9 == -0x1.58a57d387dad9p+5);
  check (x10 == -0x1.bfc0dc8d8727dp+4);
  check (x11 == -0x1.2e445e3e19b6fp+4);
  check (x12 == -0x1.6390a9a927028p+3);
  check (x13 == -0x1.c309cbc51297ep+4);
  check (x14 == -0x1.27d42a9d9c60cp+3);
  check (x15 == -0x1.d38fb51045095p+4);
  check (x16 == 0x1.6c07e2e741b34p+5);
  check (x17 == -0x1.4864b538f57c6p+5);
  check (x18 == -0x1.f4d0d716a5707p+4);
  check (x19 == 0x1.aa54b6c680f78p+2);
  check (x20 == 0x1.f7d975116fabp+3);
  check (x21 == -0x1.7f215900e5ddp+3);
  check (x22 == 0x1.f392aefdc2be4p+4);
  check (x23 == 0x1.22f7abdf466b4p+5);
  check (x24 == -0x1.93e2204c9ff09p+4);
  check (x25 == -0x1.503f9f2d7c1bep+5);
  check (x26 == -0x1.2d538bcd3db1ep+4);
  check (x27 == 0x1.28bf1c16f031cp+3);
  check (x28 == -0x1.5c419fcb731a8p+5);
  check (x29 == 0x1.876629e797e14p+5);
  check (x30 == -0x1.09f247593f08p+4);
  check (x31 == 0x1.718f80f79b7d4p+5);
}

void f183(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11, double x12, double x13, ...)
{
  va_list l;
  va_start(l, x13);
  double x14 = va_arg(l, double);
  double x15 = va_arg(l, double);
  double x16 = va_arg(l, double);
  double x17 = va_arg(l, double);
  double x18 = va_arg(l, double);
  double x19 = va_arg(l, double);
  double x20 = va_arg(l, double);
  double x21 = va_arg(l, double);
  double x22 = va_arg(l, double);
  double x23 = va_arg(l, double);
  double x24 = va_arg(l, double);
  double x25 = va_arg(l, double);
  double x26 = va_arg(l, double);
  double x27 = va_arg(l, double);
  double x28 = va_arg(l, double);
  double x29 = va_arg(l, double);
  double x30 = va_arg(l, double);
  double x31 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.4efe64df0403cp+4);
  check (x1 == -0x1.2a361da58b2a8p+5);
  check (x2 == 0x1.4da96a87ed48p+5);
  check (x3 == 0x1.6abbfa98a1a58p+3);
  check (x4 == 0x1.6236cf8caf65p+5);
  check (x5 == -0x1.11a60e5c36eap+0);
  check (x6 == -0x1.833819bf30b8cp+4);
  check (x7 == 0x1.6991c637af56p+5);
  check (x8 == -0x1.22b3e54c16a9ep+4);
  check (x9 == -0x1.717c4a0947121p+5);
  check (x10 == -0x1.099e0d7a827b4p+5);
  check (x11 == 0x1.03a62d91019fap+5);
  check (x12 == -0x1.0766c89d40e6fp+5);
  check (x13 == -0x1.591e1cb407f46p+4);
  check (x14 == 0x1.55ce0f6504f38p+4);
  check (x15 == -0x1.1985cc3c6497ap+5);
  check (x16 == 0x1.1ed790e7d9dcap+5);
  check (x17 == -0x1.b8ac6bd54ff3bp+4);
  check (x18 == -0x1.744ad56d6235p+5);
  check (x19 == -0x1.1824d06b89655p+5);
  check (x20 == 0x1.788b37026117p+5);
  check (x21 == -0x1.3b9aa8dac6668p+4);
  check (x22 == -0x1.aa4ecbf3c22eap+4);
  check (x23 == -0x1.3e6f6a66c3e74p+3);
  check (x24 == 0x1.8867900f93238p+4);
  check (x25 == -0x1.787fcfb628588p+5);
  check (x26 == -0x1.d171916d74b98p+4);
  check (x27 == 0x1.fa2e547aa6b6p+2);
  check (x28 == 0x1.6c36d4674468p+5);
  check (x29 == -0x1.a81f1d28b6296p+4);
  check (x30 == -0x1.5f0b90b29dbe3p+5);
  check (x31 == -0x1.db5f2251f6b68p+4);
}

void f184(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  int x4 = va_arg(l, int);
  long long x5 = va_arg(l, long long);
  va_end(l);
  check (x0 == 2101281900);
  check (x1 == 7795706548067128403);
  check (x2 == 1183029474);
  check (x3 == -4278502574447296935);
  check (x4 == -1837297251);
  check (x5 == 2703834400518781371);
}

void f185(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  int x4 = va_arg(l, int);
  long long x5 = va_arg(l, long long);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  va_end(l);
  check (x0 == 2057290366);
  check (x1 == 1514566922856904769);
  check (x2 == 338311350);
  check (x3 == 1624995520417472926);
  check (x4 == -580354146);
  check (x5 == 4722168328255427661);
  check (x6 == 1064787640);
  check (x7 == -5438458004764631589);
}

void f186(int x0, long long x1, int x2, long long x3, int x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  va_end(l);
  check (x0 == -1196777746);
  check (x1 == -4349640348834612142);
  check (x2 == -1752043305);
  check (x3 == -8181940770191071313);
  check (x4 == -19542934);
  check (x5 == -1082112759578367330);
  check (x6 == -479499677);
  check (x7 == -8660010067636992744);
}

void f187(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  int x4 = va_arg(l, int);
  long long x5 = va_arg(l, long long);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  va_end(l);
  check (x0 == -1206868551);
  check (x1 == -2165517234932522841);
  check (x2 == -1659473323);
  check (x3 == -2056072224643458229);
  check (x4 == -911429314);
  check (x5 == -3468357254070985133);
  check (x6 == -506758755);
  check (x7 == -7341876885028021983);
  check (x8 == 350726495);
  check (x9 == 907161223085417018);
}

void f188(int x0, long long x1, int x2, long long x3, int x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  va_end(l);
  check (x0 == 769832611);
  check (x1 == 2850135700643884849);
  check (x2 == -422193959);
  check (x3 == -626863810377284598);
  check (x4 == 832992912);
  check (x5 == -3406020066056130279);
  check (x6 == 830666051);
  check (x7 == 219340346850629006);
  check (x8 == -2086829476);
  check (x9 == 617791154256843269);
}

void f189(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  int x4 = va_arg(l, int);
  long long x5 = va_arg(l, long long);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  va_end(l);
  check (x0 == 32703162);
  check (x1 == 3686610974523805272);
  check (x2 == -515100259);
  check (x3 == -2265306312381088271);
  check (x4 == -623243022);
  check (x5 == -3435350100597533171);
  check (x6 == 1505276306);
  check (x7 == 5871427736792246667);
  check (x8 == -1836348415);
  check (x9 == -7953588449138844476);
  check (x10 == 1922578507);
  check (x11 == 3103963351908038982);
}

void f190(int x0, long long x1, int x2, long long x3, int x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  va_end(l);
  check (x0 == 2040383217);
  check (x1 == -7868679259815963714);
  check (x2 == 1178086693);
  check (x3 == 3858410342630167475);
  check (x4 == 1496055099);
  check (x5 == 543037399386287656);
  check (x6 == 1465777616);
  check (x7 == 1444590229324257099);
  check (x8 == -1052481189);
  check (x9 == -2554991559743879210);
  check (x10 == 1131147407);
  check (x11 == 1110379372601820984);
}

void f191(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  int x4 = va_arg(l, int);
  long long x5 = va_arg(l, long long);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  va_end(l);
  check (x0 == -1587327106);
  check (x1 == 4587548386013910406);
  check (x2 == -1305870880);
  check (x3 == 6161502383126308140);
  check (x4 == -1596461089);
  check (x5 == 3012795587101044752);
  check (x6 == 705934465);
  check (x7 == -1184414321843717782);
  check (x8 == 808022229);
  check (x9 == 6787765901417159717);
  check (x10 == -859393046);
  check (x11 == 7688210307630695491);
  check (x12 == -1075200320);
  check (x13 == 8228686258748198786);
  check (x14 == 1004607381);
  check (x15 == 1145369775551292747);
}

void f192(int x0, long long x1, int x2, long long x3, int x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  va_end(l);
  check (x0 == -1956439563);
  check (x1 == -7252997999685681699);
  check (x2 == 2031566435);
  check (x3 == -4153907580481520220);
  check (x4 == -1379650130);
  check (x5 == 5474505284148149177);
  check (x6 == -19745483);
  check (x7 == 5737434355556327344);
  check (x8 == -1890307557);
  check (x9 == 5983524845181210474);
  check (x10 == -1438792809);
  check (x11 == 2210759732536958727);
  check (x12 == -1097645518);
  check (x13 == 2717651289751120990);
  check (x14 == -1413457542);
  check (x15 == -299655281654888348);
}

void f193(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7, int x8, long long x9, int x10, long long x11, int x12, long long x13, ...)
{
  va_list l;
  va_start(l, x13);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  va_end(l);
  check (x0 == 2005817930);
  check (x1 == 9124727616685238930);
  check (x2 == 1175841930);
  check (x3 == 1299902380951791643);
  check (x4 == 392771098);
  check (x5 == 5204900592519685591);
  check (x6 == -1942272654);
  check (x7 == -4495603742408276254);
  check (x8 == -1054983971);
  check (x9 == -7853534566400334987);
  check (x10 == 1748646090);
  check (x11 == -2967970573914480619);
  check (x12 == 937089175);
  check (x13 == 6558853782901673302);
  check (x14 == 1797562881);
  check (x15 == -1133183291748726600);
}

void f194(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  int x4 = va_arg(l, int);
  long long x5 = va_arg(l, long long);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  int x16 = va_arg(l, int);
  long long x17 = va_arg(l, long long);
  int x18 = va_arg(l, int);
  long long x19 = va_arg(l, long long);
  int x20 = va_arg(l, int);
  long long x21 = va_arg(l, long long);
  int x22 = va_arg(l, int);
  long long x23 = va_arg(l, long long);
  int x24 = va_arg(l, int);
  long long x25 = va_arg(l, long long);
  int x26 = va_arg(l, int);
  long long x27 = va_arg(l, long long);
  int x28 = va_arg(l, int);
  long long x29 = va_arg(l, long long);
  int x30 = va_arg(l, int);
  long long x31 = va_arg(l, long long);
  va_end(l);
  check (x0 == 1622292222);
  check (x1 == 8602393661277762853);
  check (x2 == 1490214699);
  check (x3 == -2995625662755041992);
  check (x4 == 1693557030);
  check (x5 == 8728158255088310309);
  check (x6 == -1487573766);
  check (x7 == -4791501633878555527);
  check (x8 == 1915101845);
  check (x9 == 3442378124667900717);
  check (x10 == 1537851202);
  check (x11 == 7068217606749267212);
  check (x12 == -664512239);
  check (x13 == -4775239207752964933);
  check (x14 == 629168398);
  check (x15 == -2109445881971704641);
  check (x16 == -1383677233);
  check (x17 == 7056438772573304515);
  check (x18 == -480780430);
  check (x19 == -9188876383750096929);
  check (x20 == 888730129);
  check (x21 == 1979672478103890791);
  check (x22 == 1052473259);
  check (x23 == 1936166498865635077);
  check (x24 == -1057274670);
  check (x25 == 4562235459385479731);
  check (x26 == -1129619964);
  check (x27 == -243587917047033645);
  check (x28 == -1567781665);
  check (x29 == 404534679445506861);
  check (x30 == 270856395);
  check (x31 == 7446348214805072298);
}

void f195(int x0, long long x1, int x2, long long x3, int x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  int x16 = va_arg(l, int);
  long long x17 = va_arg(l, long long);
  int x18 = va_arg(l, int);
  long long x19 = va_arg(l, long long);
  int x20 = va_arg(l, int);
  long long x21 = va_arg(l, long long);
  int x22 = va_arg(l, int);
  long long x23 = va_arg(l, long long);
  int x24 = va_arg(l, int);
  long long x25 = va_arg(l, long long);
  int x26 = va_arg(l, int);
  long long x27 = va_arg(l, long long);
  int x28 = va_arg(l, int);
  long long x29 = va_arg(l, long long);
  int x30 = va_arg(l, int);
  long long x31 = va_arg(l, long long);
  va_end(l);
  check (x0 == 1675709691);
  check (x1 == 1764487498711989127);
  check (x2 == -1678426139);
  check (x3 == 5819752496118659423);
  check (x4 == 659955275);
  check (x5 == -6302243808785743709);
  check (x6 == -1691274873);
  check (x7 == -6454939088536412389);
  check (x8 == 452944661);
  check (x9 == 7012404946277384296);
  check (x10 == 1364441287);
  check (x11 == -8105842358062750625);
  check (x12 == -94490555);
  check (x13 == 3141735048510226230);
  check (x14 == -1239181832);
  check (x15 == -2890719911977649552);
  check (x16 == -78972422);
  check (x17 == 2331562392741038947);
  check (x18 == 539131628);
  check (x19 == -8294485743144085619);
  check (x20 == 1794723783);
  check (x21 == 4002318007288614474);
  check (x22 == 935716287);
  check (x23 == 8280802302393157835);
  check (x24 == -656920485);
  check (x25 == -7150249304022632740);
  check (x26 == 1954832142);
  check (x27 == 6149505987229525728);
  check (x28 == 481565089);
  check (x29 == -1963872804924400213);
  check (x30 == 470984548);
  check (x31 == 2950949638210749720);
}

void f196(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7, int x8, long long x9, int x10, long long x11, int x12, long long x13, ...)
{
  va_list l;
  va_start(l, x13);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  int x16 = va_arg(l, int);
  long long x17 = va_arg(l, long long);
  int x18 = va_arg(l, int);
  long long x19 = va_arg(l, long long);
  int x20 = va_arg(l, int);
  long long x21 = va_arg(l, long long);
  int x22 = va_arg(l, int);
  long long x23 = va_arg(l, long long);
  int x24 = va_arg(l, int);
  long long x25 = va_arg(l, long long);
  int x26 = va_arg(l, int);
  long long x27 = va_arg(l, long long);
  int x28 = va_arg(l, int);
  long long x29 = va_arg(l, long long);
  int x30 = va_arg(l, int);
  long long x31 = va_arg(l, long long);
  va_end(l);
  check (x0 == 1924095644);
  check (x1 == 4200497026230075488);
  check (x2 == -368105140);
  check (x3 == -8022696757634398598);
  check (x4 == -710489218);
  check (x5 == -68840199802498301);
  check (x6 == -1027386084);
  check (x7 == -4494299176534079520);
  check (x8 == 589556588);
  check (x9 == -9007851611009677318);
  check (x10 == 617282110);
  check (x11 == -5780353032551804269);
  check (x12 == -251308531);
  check (x13 == -7487164526307168264);
  check (x14 == 340881166);
  check (x15 == 3942896681735280149);
  check (x16 == 185870479);
  check (x17 == 6366677771156053955);
  check (x18 == 544618658);
  check (x19 == -2291350537356801921);
  check (x20 == 102371990);
  check (x21 == -1746350616343134264);
  check (x22 == -629579251);
  check (x23 == 8942101680030711439);
  check (x24 == 1096722260);
  check (x25 == 8243126499962979472);
  check (x26 == 1035026792);
  check (x27 == 8122397152700875184);
  check (x28 == -557730099);
  check (x29 == -7471356718194690361);
  check (x30 == 514239217);
  check (x31 == 8775300646252608308);
}

void f197(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  va_end(l);
  check (x0 == -1829262212);
  check (x1 == -0x1.67c36e94664fap+5);
  check (x2 == 1256504760);
  check (x3 == 0x1.19bed4642555p+1);
  check (x4 == -487516088);
  check (x5 == 0x1.c6bc866ba1838p+4);
}

void f198(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  va_end(l);
  check (x0 == 867195587);
  check (x1 == -0x1.7999027557ad2p+4);
  check (x2 == -1737574096);
  check (x3 == 0x1.90cc01fb67088p+3);
  check (x4 == 1763585465);
  check (x5 == 0x1.414ea0c2cfff6p+5);
  check (x6 == -2081183474);
  check (x7 == 0x1.126704753942p+2);
}

void f199(int x0, double x1, int x2, double x3, int x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  va_end(l);
  check (x0 == -625621609);
  check (x1 == -0x1.a3bbbf654f2adp+4);
  check (x2 == -38585282);
  check (x3 == -0x1.0d222afc0aep+0);
  check (x4 == 996915887);
  check (x5 == -0x1.ae98708634954p+4);
  check (x6 == 761476581);
  check (x7 == -0x1.0705351bdfd98p+5);
}

void f200(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  va_end(l);
  check (x0 == 388213404);
  check (x1 == -0x1.d89a326e62b8bp+4);
  check (x2 == 1469220609);
  check (x3 == 0x1.528ace548db94p+4);
  check (x4 == -519305307);
  check (x5 == 0x1.2607835772d48p+2);
  check (x6 == -493637302);
  check (x7 == 0x1.60ca089b6a25cp+5);
  check (x8 == 223724096);
  check (x9 == 0x1.3cce8129fbe1p+3);
}

void f201(int x0, double x1, int x2, double x3, int x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  va_end(l);
  check (x0 == -91128154);
  check (x1 == -0x1.238cb21d28567p+4);
  check (x2 == 2038052731);
  check (x3 == -0x1.8cd0fa13d062ep+5);
  check (x4 == 1415295420);
  check (x5 == -0x1.f60737c42d234p+3);
  check (x6 == 1771216603);
  check (x7 == 0x1.8aa2512150188p+3);
  check (x8 == 208715035);
  check (x9 == 0x1.8aee4d51ae492p+5);
}

void f202(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  va_end(l);
  check (x0 == -577548883);
  check (x1 == 0x1.5229edde5c62p+2);
  check (x2 == -1328148949);
  check (x3 == 0x1.beabb138c307cp+4);
  check (x4 == -1684205015);
  check (x5 == -0x1.e27b045a40c4cp+4);
  check (x6 == 1679057669);
  check (x7 == 0x1.153b316a1cd1cp+5);
  check (x8 == -1890371794);
  check (x9 == 0x1.89dca6ad9b87cp+5);
  check (x10 == -1440297963);
  check (x11 == -0x1.5072144a50f1ap+5);
}

void f203(int x0, double x1, int x2, double x3, int x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  va_end(l);
  check (x0 == 967165480);
  check (x1 == 0x1.cd160bdc3b4c4p+4);
  check (x2 == -1237342091);
  check (x3 == 0x1.101ee8a2ee15p+1);
  check (x4 == -490392152);
  check (x5 == -0x1.848347b99a1c9p+5);
  check (x6 == -1391386089);
  check (x7 == 0x1.2a51a809363ep+5);
  check (x8 == 348707521);
  check (x9 == 0x1.5865fd610f8c4p+4);
  check (x10 == -767210357);
  check (x11 == -0x1.7a26cd184234fp+4);
}

void f204(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  double x13 = va_arg(l, double);
  int x14 = va_arg(l, int);
  double x15 = va_arg(l, double);
  va_end(l);
  check (x0 == 1411820846);
  check (x1 == -0x1.32d0e0e2cdeb2p+5);
  check (x2 == -1815515642);
  check (x3 == -0x1.404a59ce160f2p+5);
  check (x4 == -50601225);
  check (x5 == -0x1.a1a40587797dep+4);
  check (x6 == 392048417);
  check (x7 == 0x1.eba7c2c882be4p+4);
  check (x8 == 1054113911);
  check (x9 == -0x1.3bfd9c0aae064p+4);
  check (x10 == -1518317381);
  check (x11 == 0x1.1d628757f8cd8p+3);
  check (x12 == -1706140960);
  check (x13 == 0x1.b4d64bbec1f48p+2);
  check (x14 == -811361998);
  check (x15 == -0x1.6407eadab615fp+5);
}

void f205(int x0, double x1, int x2, double x3, int x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  double x13 = va_arg(l, double);
  int x14 = va_arg(l, int);
  double x15 = va_arg(l, double);
  va_end(l);
  check (x0 == -1304686793);
  check (x1 == 0x1.18765ae33ba24p+3);
  check (x2 == 8328634);
  check (x3 == -0x1.755541d3bd21bp+5);
  check (x4 == 529201262);
  check (x5 == -0x1.51c465d6aaaa4p+4);
  check (x6 == -1720800926);
  check (x7 == -0x1.3920ccf8fed3bp+4);
  check (x8 == -1701625325);
  check (x9 == -0x1.1831fd19472f4p+5);
  check (x10 == 2049872961);
  check (x11 == -0x1.2b41745eb7588p+2);
  check (x12 == 347062261);
  check (x13 == 0x1.db5acaa51e4f4p+4);
  check (x14 == 1520638345);
  check (x15 == 0x1.f628c95775b8p+2);
}

void f206(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7, int x8, double x9, int x10, double x11, int x12, double x13, ...)
{
  va_list l;
  va_start(l, x13);
  int x14 = va_arg(l, int);
  double x15 = va_arg(l, double);
  va_end(l);
  check (x0 == 263792395);
  check (x1 == 0x1.ac0209abaa5c8p+4);
  check (x2 == 989265161);
  check (x3 == -0x1.745c98ffe058p+1);
  check (x4 == -1646967273);
  check (x5 == -0x1.047712e93708p+4);
  check (x6 == -644651992);
  check (x7 == 0x1.288dd5602b20ep+5);
  check (x8 == 778818461);
  check (x9 == 0x1.f8dac193f3468p+4);
  check (x10 == -1937098666);
  check (x11 == 0x1.6132869a5a3fap+5);
  check (x12 == -440883994);
  check (x13 == 0x1.5088e66b9e57cp+4);
  check (x14 == -241060713);
  check (x15 == -0x1.a9adf029b4814p+4);
}

void f207(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  double x13 = va_arg(l, double);
  int x14 = va_arg(l, int);
  double x15 = va_arg(l, double);
  int x16 = va_arg(l, int);
  double x17 = va_arg(l, double);
  int x18 = va_arg(l, int);
  double x19 = va_arg(l, double);
  int x20 = va_arg(l, int);
  double x21 = va_arg(l, double);
  int x22 = va_arg(l, int);
  double x23 = va_arg(l, double);
  int x24 = va_arg(l, int);
  double x25 = va_arg(l, double);
  int x26 = va_arg(l, int);
  double x27 = va_arg(l, double);
  int x28 = va_arg(l, int);
  double x29 = va_arg(l, double);
  int x30 = va_arg(l, int);
  double x31 = va_arg(l, double);
  va_end(l);
  check (x0 == 85848435);
  check (x1 == -0x1.7215666a5c26p+2);
  check (x2 == -514535422);
  check (x3 == 0x1.c1b0b74c614e8p+4);
  check (x4 == 1727818286);
  check (x5 == 0x1.1bd161ea9649ep+5);
  check (x6 == 801350404);
  check (x7 == 0x1.4dd87b8c64b5p+2);
  check (x8 == 432446956);
  check (x9 == 0x1.4b2c276550d64p+4);
  check (x10 == -1435806555);
  check (x11 == 0x1.14bef0eb7fde8p+5);
  check (x12 == -1920537403);
  check (x13 == 0x1.daf258edf22bcp+4);
  check (x14 == -587965555);
  check (x15 == -0x1.cb06213160e61p+4);
  check (x16 == 695571911);
  check (x17 == -0x1.3cbc525983f1bp+4);
  check (x18 == -1429491980);
  check (x19 == 0x1.4c3da4c74b318p+4);
  check (x20 == 220092288);
  check (x21 == -0x1.e4425749f04fp+1);
  check (x22 == 893499725);
  check (x23 == -0x1.12a3adcbd449ap+5);
  check (x24 == 1070919864);
  check (x25 == -0x1.731e3186c895ep+5);
  check (x26 == 141471065);
  check (x27 == 0x1.d70ff69bfcffp+2);
  check (x28 == -1573848151);
  check (x29 == -0x1.8394b2090326p+5);
  check (x30 == -558277291);
  check (x31 == -0x1.d0291ce895568p+2);
}

void f208(int x0, double x1, int x2, double x3, int x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  double x13 = va_arg(l, double);
  int x14 = va_arg(l, int);
  double x15 = va_arg(l, double);
  int x16 = va_arg(l, int);
  double x17 = va_arg(l, double);
  int x18 = va_arg(l, int);
  double x19 = va_arg(l, double);
  int x20 = va_arg(l, int);
  double x21 = va_arg(l, double);
  int x22 = va_arg(l, int);
  double x23 = va_arg(l, double);
  int x24 = va_arg(l, int);
  double x25 = va_arg(l, double);
  int x26 = va_arg(l, int);
  double x27 = va_arg(l, double);
  int x28 = va_arg(l, int);
  double x29 = va_arg(l, double);
  int x30 = va_arg(l, int);
  double x31 = va_arg(l, double);
  va_end(l);
  check (x0 == 285989980);
  check (x1 == -0x1.b161a28114664p+4);
  check (x2 == -26110409);
  check (x3 == -0x1.76411d590262p+3);
  check (x4 == 303801445);
  check (x5 == 0x1.5c1d9f64ea3ep+2);
  check (x6 == 1088365329);
  check (x7 == 0x1.05c538c4086dp+5);
  check (x8 == -112575152);
  check (x9 == -0x1.23e85f3116941p+5);
  check (x10 == 842610607);
  check (x11 == 0x1.0ded10d7557bap+5);
  check (x12 == 19756698);
  check (x13 == 0x1.3ae92e28f8348p+5);
  check (x14 == -1453937196);
  check (x15 == 0x1.24a00d92c19bp+3);
  check (x16 == -1259371359);
  check (x17 == -0x1.c8cd260b6f4f4p+3);
  check (x18 == -1338447145);
  check (x19 == 0x1.3f9302a8fcc08p+3);
  check (x20 == 629714221);
  check (x21 == 0x1.5a962236e1962p+5);
  check (x22 == -2058883027);
  check (x23 == 0x1.255340539ep-8);
  check (x24 == 77266830);
  check (x25 == 0x1.6f4473ff105d8p+2);
  check (x26 == 1912205329);
  check (x27 == -0x1.866726c583028p+2);
  check (x28 == -1638125478);
  check (x29 == 0x1.97f4d10c470b8p+2);
  check (x30 == 424062823);
  check (x31 == -0x1.50c27b4d51a11p+5);
}

void f209(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7, int x8, double x9, int x10, double x11, int x12, double x13, ...)
{
  va_list l;
  va_start(l, x13);
  int x14 = va_arg(l, int);
  double x15 = va_arg(l, double);
  int x16 = va_arg(l, int);
  double x17 = va_arg(l, double);
  int x18 = va_arg(l, int);
  double x19 = va_arg(l, double);
  int x20 = va_arg(l, int);
  double x21 = va_arg(l, double);
  int x22 = va_arg(l, int);
  double x23 = va_arg(l, double);
  int x24 = va_arg(l, int);
  double x25 = va_arg(l, double);
  int x26 = va_arg(l, int);
  double x27 = va_arg(l, double);
  int x28 = va_arg(l, int);
  double x29 = va_arg(l, double);
  int x30 = va_arg(l, int);
  double x31 = va_arg(l, double);
  va_end(l);
  check (x0 == 1997647214);
  check (x1 == -0x1.3b96de69357ccp+4);
  check (x2 == 582375435);
  check (x3 == -0x1.188d09452b02p+0);
  check (x4 == 1528406927);
  check (x5 == 0x1.6f4536ddb56ep+4);
  check (x6 == -872382992);
  check (x7 == 0x1.64998d42df63cp+3);
  check (x8 == 502729657);
  check (x9 == -0x1.14a2826372e44p+3);
  check (x10 == 1503246997);
  check (x11 == 0x1.99b82b63c2d8cp+4);
  check (x12 == 1947852619);
  check (x13 == -0x1.c3ba5a37e696p+2);
  check (x14 == -1595325650);
  check (x15 == -0x1.5ed4e08c0ddbcp+3);
  check (x16 == 1612908721);
  check (x17 == 0x1.49f95b03f32acp+5);
  check (x18 == -1258536580);
  check (x19 == 0x1.48d0bbb35d13p+5);
  check (x20 == -838605495);
  check (x21 == -0x1.265946da69d36p+5);
  check (x22 == 1720493830);
  check (x23 == -0x1.8fa6bb0f7a68p+3);
  check (x24 == -1531371345);
  check (x25 == -0x1.6948fa13c8a81p+5);
  check (x26 == 5299772);
  check (x27 == -0x1.1b089d003e664p+3);
  check (x28 == 894035418);
  check (x29 == 0x1.4c67b5e426f52p+5);
  check (x30 == 113813725);
  check (x31 == 0x1.56d5e0407e198p+5);
}

void f210(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  va_end(l);
  check (x0 == 3809642546361448317);
  check (x1 == -0x1.83a8a6e8d91c1p+5);
  check (x2 == -4009334498260084411);
  check (x3 == 0x1.7cb9cabe2e064p+4);
  check (x4 == -6461888156724207201);
  check (x5 == -0x1.270d9a3dfd2d9p+5);
}

void f211(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  va_end(l);
  check (x0 == -6470335657427498220);
  check (x1 == 0x1.62b03476f8ffp+5);
  check (x2 == -6324878543430706112);
  check (x3 == -0x1.085cb5f9f6b1ap+4);
  check (x4 == -7115861557478825103);
  check (x5 == 0x1.26cb20912c75cp+5);
  check (x6 == 7402884048386665510);
  check (x7 == 0x1.8d7ecdb27272p+3);
}

void f212(long long x0, double x1, long long x2, double x3, long long x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  va_end(l);
  check (x0 == -6999533128592504298);
  check (x1 == 0x1.9f44cd500b21p+3);
  check (x2 == 2908717789388991894);
  check (x3 == -0x1.4b588a0a88ac3p+5);
  check (x4 == -6161641352145761067);
  check (x5 == -0x1.d005ffacba17fp+4);
  check (x6 == -2794924262900712764);
  check (x7 == -0x1.6800521afbc4p+5);
}

void f213(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  double x9 = va_arg(l, double);
  va_end(l);
  check (x0 == -7756277013377958434);
  check (x1 == 0x1.6774c958abba4p+5);
  check (x2 == -7653069727141566306);
  check (x3 == 0x1.0b08058c434f4p+4);
  check (x4 == -3021758889749575568);
  check (x5 == -0x1.465b8d80d3eb2p+5);
  check (x6 == -2652144505998481228);
  check (x7 == 0x1.810a4d5b0906cp+4);
  check (x8 == -7516643584455971919);
  check (x9 == -0x1.5b71591f33a15p+5);
}

void f214(long long x0, double x1, long long x2, double x3, long long x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  double x9 = va_arg(l, double);
  va_end(l);
  check (x0 == 791873458626076711);
  check (x1 == 0x1.3ed10be364b2p+2);
  check (x2 == -2673244282983360304);
  check (x3 == 0x1.dc9c9120f921p+4);
  check (x4 == -5621757522872000374);
  check (x5 == 0x1.103b201f9858ap+5);
  check (x6 == -6118850144409082166);
  check (x7 == 0x1.7f595fa6366ecp+4);
  check (x8 == 2916286790195564370);
  check (x9 == -0x1.26e22b4b19368p+5);
}

void f215(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  va_end(l);
  check (x0 == -6709103496690611001);
  check (x1 == -0x1.a9d14b2f873dfp+4);
  check (x2 == 7437094676907782317);
  check (x3 == 0x1.4d2c83f18bdp-2);
  check (x4 == 2595897417912636049);
  check (x5 == -0x1.5b57dbfbebb1fp+5);
  check (x6 == 8430391118025657778);
  check (x7 == -0x1.604564b0a431cp+5);
  check (x8 == 6546609744353350034);
  check (x9 == -0x1.8acfdc4b3092p+1);
  check (x10 == -1684749779270411960);
  check (x11 == -0x1.c37df55a5a2fap+4);
}

void f216(long long x0, double x1, long long x2, double x3, long long x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  va_end(l);
  check (x0 == -5434459602411747367);
  check (x1 == 0x1.2de4ca695bac8p+4);
  check (x2 == 6926035893535265179);
  check (x3 == -0x1.b1d79eaa1b2efp+4);
  check (x4 == 4460362269111323745);
  check (x5 == 0x1.154ea279322acp+5);
  check (x6 == -2697307470402865399);
  check (x7 == -0x1.12bf7f6c68cfep+4);
  check (x8 == 3739629809658903244);
  check (x9 == 0x1.2c5b8e9653666p+5);
  check (x10 == -2853060826382266171);
  check (x11 == -0x1.002e99e46d278p+5);
}

void f217(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  double x13 = va_arg(l, double);
  long long x14 = va_arg(l, long long);
  double x15 = va_arg(l, double);
  va_end(l);
  check (x0 == -6041082342366437429);
  check (x1 == -0x1.11f01575a30bdp+5);
  check (x2 == 7349883861154805331);
  check (x3 == 0x1.8509190ea427cp+3);
  check (x4 == 2016008965206351131);
  check (x5 == 0x1.588a97bf612f4p+4);
  check (x6 == 6597878428224964135);
  check (x7 == -0x1.8b8defdf0718bp+4);
  check (x8 == 6521771674801712981);
  check (x9 == -0x1.9cac2815820ap+0);
  check (x10 == -8814050392180975356);
  check (x11 == 0x1.f7510a2155efp+4);
  check (x12 == -7434909045184700397);
  check (x13 == -0x1.41aec47c03674p+5);
  check (x14 == 6113108154725150236);
  check (x15 == -0x1.406ede471c66ap+5);
}

void f218(long long x0, double x1, long long x2, double x3, long long x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  double x13 = va_arg(l, double);
  long long x14 = va_arg(l, long long);
  double x15 = va_arg(l, double);
  va_end(l);
  check (x0 == 6752687191631752432);
  check (x1 == -0x1.3d39d3e228094p+5);
  check (x2 == -3684296718839465818);
  check (x3 == 0x1.96f0f17702f64p+4);
  check (x4 == 2534387275290051572);
  check (x5 == 0x1.a66a9067a6f58p+2);
  check (x6 == -8133644112867496132);
  check (x7 == -0x1.39919fb8c0278p+2);
  check (x8 == 6546526313682422971);
  check (x9 == 0x1.81a1d742f99acp+3);
  check (x10 == -1910855404217623825);
  check (x11 == -0x1.5ad45c7dca985p+5);
  check (x12 == 6212851175673903907);
  check (x13 == 0x1.7036b8a1077cep+5);
  check (x14 == -6352486478068732432);
  check (x15 == 0x1.3796541ddc1cp+1);
}

void f219(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7, long long x8, double x9, long long x10, double x11, long long x12, double x13, ...)
{
  va_list l;
  va_start(l, x13);
  long long x14 = va_arg(l, long long);
  double x15 = va_arg(l, double);
  va_end(l);
  check (x0 == 4238693618901641292);
  check (x1 == -0x1.071fcbfaa259cp+5);
  check (x2 == -7402920289884219606);
  check (x3 == 0x1.584ffd8376e18p+5);
  check (x4 == -5130065475684308470);
  check (x5 == -0x1.c354b7e81bf28p+3);
  check (x6 == 3633412501166066037);
  check (x7 == -0x1.7eff44cea31p+2);
  check (x8 == 2841502822633153931);
  check (x9 == 0x1.aaf6a0ecc116p+0);
  check (x10 == -29325127467614001);
  check (x11 == -0x1.33c23ea49b155p+5);
  check (x12 == -1286062573990353741);
  check (x13 == -0x1.6fc8a02b12a79p+5);
  check (x14 == -1674725291415045733);
  check (x15 == -0x1.077cbb916e88cp+3);
}

void f220(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  double x13 = va_arg(l, double);
  long long x14 = va_arg(l, long long);
  double x15 = va_arg(l, double);
  long long x16 = va_arg(l, long long);
  double x17 = va_arg(l, double);
  long long x18 = va_arg(l, long long);
  double x19 = va_arg(l, double);
  long long x20 = va_arg(l, long long);
  double x21 = va_arg(l, double);
  long long x22 = va_arg(l, long long);
  double x23 = va_arg(l, double);
  long long x24 = va_arg(l, long long);
  double x25 = va_arg(l, double);
  long long x26 = va_arg(l, long long);
  double x27 = va_arg(l, double);
  long long x28 = va_arg(l, long long);
  double x29 = va_arg(l, double);
  long long x30 = va_arg(l, long long);
  double x31 = va_arg(l, double);
  va_end(l);
  check (x0 == 2752703929500466541);
  check (x1 == 0x1.06d8f42068f4cp+4);
  check (x2 == 6543223271806673124);
  check (x3 == 0x1.3b1e397d5ad5cp+5);
  check (x4 == -703373875341566723);
  check (x5 == -0x1.e608df5f7897dp+4);
  check (x6 == -4659879749672752105);
  check (x7 == 0x1.90d703e5851f8p+2);
  check (x8 == 8221574054508186320);
  check (x9 == 0x1.53a618f6e5e72p+5);
  check (x10 == 4576606807310476014);
  check (x11 == 0x1.c212251659908p+2);
  check (x12 == -4177802448300814336);
  check (x13 == -0x1.82c14fcd9f858p+5);
  check (x14 == 557781998832873777);
  check (x15 == 0x1.0349adcbd544p-1);
  check (x16 == -9003100464182381163);
  check (x17 == -0x1.c5aa70edb8904p+4);
  check (x18 == -3066163619781376778);
  check (x19 == -0x1.0e7e87e37abbcp+3);
  check (x20 == 4072014796293902764);
  check (x21 == 0x1.2f3533d63194cp+4);
  check (x22 == 5156848834818604039);
  check (x23 == -0x1.49c6fd7af4becp+5);
  check (x24 == -8785776237861602248);
  check (x25 == 0x1.4cf3602c19e18p+3);
  check (x26 == 5711601050988866569);
  check (x27 == 0x1.e34353b26af9p+3);
  check (x28 == 154277128294263651);
  check (x29 == -0x1.27b94820e4fc8p+2);
  check (x30 == 5625560203284085893);
  check (x31 == -0x1.6405a5bbb0d6ep+5);
}

void f221(long long x0, double x1, long long x2, double x3, long long x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  double x13 = va_arg(l, double);
  long long x14 = va_arg(l, long long);
  double x15 = va_arg(l, double);
  long long x16 = va_arg(l, long long);
  double x17 = va_arg(l, double);
  long long x18 = va_arg(l, long long);
  double x19 = va_arg(l, double);
  long long x20 = va_arg(l, long long);
  double x21 = va_arg(l, double);
  long long x22 = va_arg(l, long long);
  double x23 = va_arg(l, double);
  long long x24 = va_arg(l, long long);
  double x25 = va_arg(l, double);
  long long x26 = va_arg(l, long long);
  double x27 = va_arg(l, double);
  long long x28 = va_arg(l, long long);
  double x29 = va_arg(l, double);
  long long x30 = va_arg(l, long long);
  double x31 = va_arg(l, double);
  va_end(l);
  check (x0 == 5708576668523360894);
  check (x1 == 0x1.79d373fb03528p+3);
  check (x2 == 8676594468273064664);
  check (x3 == -0x1.7fc40a5330194p+3);
  check (x4 == -5680086517367370380);
  check (x5 == -0x1.3a54c275d319ap+5);
  check (x6 == -4122729870963773149);
  check (x7 == 0x1.1ed2a31775678p+2);
  check (x8 == 3806485273945370087);
  check (x9 == 0x1.75387a72b8aap+5);
  check (x10 == 7762471959644051070);
  check (x11 == -0x1.526c8496c465p+3);
  check (x12 == -30451852103140096);
  check (x13 == -0x1.991d86477db7p+1);
  check (x14 == -1414322154554077432);
  check (x15 == -0x1.5fc4bc4264c38p+5);
  check (x16 == 7616091551292295606);
  check (x17 == -0x1.77eb2aa49f4a6p+4);
  check (x18 == -4711440631684733053);
  check (x19 == -0x1.1297d955fa04ep+4);
  check (x20 == 2627199423882454337);
  check (x21 == 0x1.449b610c93f2p+0);
  check (x22 == -1859637581171241234);
  check (x23 == 0x1.122e8a09b488p+5);
  check (x24 == 3147626218843032488);
  check (x25 == -0x1.5de7ddde140b6p+5);
  check (x26 == 6088454465651888992);
  check (x27 == 0x1.d8f4bae679b58p+4);
  check (x28 == -2262929244611470129);
  check (x29 == -0x1.00ef6efdbc63p+1);
  check (x30 == 3885067062799455433);
  check (x31 == 0x1.d7df7112748dp+3);
}

void f222(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7, long long x8, double x9, long long x10, double x11, long long x12, double x13, ...)
{
  va_list l;
  va_start(l, x13);
  long long x14 = va_arg(l, long long);
  double x15 = va_arg(l, double);
  long long x16 = va_arg(l, long long);
  double x17 = va_arg(l, double);
  long long x18 = va_arg(l, long long);
  double x19 = va_arg(l, double);
  long long x20 = va_arg(l, long long);
  double x21 = va_arg(l, double);
  long long x22 = va_arg(l, long long);
  double x23 = va_arg(l, double);
  long long x24 = va_arg(l, long long);
  double x25 = va_arg(l, double);
  long long x26 = va_arg(l, long long);
  double x27 = va_arg(l, double);
  long long x28 = va_arg(l, long long);
  double x29 = va_arg(l, double);
  long long x30 = va_arg(l, long long);
  double x31 = va_arg(l, double);
  va_end(l);
  check (x0 == -4059841820591761865);
  check (x1 == 0x1.0919838d9443p+4);
  check (x2 == 3967026355621114618);
  check (x3 == 0x1.27204b475c7p+4);
  check (x4 == 7564584116651377815);
  check (x5 == -0x1.c98f2b8a49097p+4);
  check (x6 == 6601428471629196807);
  check (x7 == 0x1.9a08e27f83788p+2);
  check (x8 == 868644070098517752);
  check (x9 == -0x1.807aeb7694fdbp+4);
  check (x10 == 8004872032578307313);
  check (x11 == 0x1.62db5109ca6c4p+4);
  check (x12 == 4785801764088872046);
  check (x13 == 0x1.25b73e5521668p+2);
  check (x14 == 8586031223180042616);
  check (x15 == 0x1.db4c40b9f4cf4p+4);
  check (x16 == 3840614249491433503);
  check (x17 == 0x1.1ac97d7b69d18p+2);
  check (x18 == -330935148507099720);
  check (x19 == 0x1.d819a239b943cp+4);
  check (x20 == -2036618730679336579);
  check (x21 == -0x1.5ca7da3187478p+5);
  check (x22 == -4952543996741785342);
  check (x23 == -0x1.0896e0fe6da64p+3);
  check (x24 == 5252210869316814940);
  check (x25 == -0x1.8364a7e3b007cp+5);
  check (x26 == -4594533007969215430);
  check (x27 == -0x1.316d8edb0c81p+2);
  check (x28 == 5222965446399891275);
  check (x29 == -0x1.62e0b4239718ap+4);
  check (x30 == 930875816963334098);
  check (x31 == 0x1.6eb00ba7aa9dp+1);
}

float f223(int x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  char * x2 = va_arg(l, char *);
  int x3 = va_arg(l, int);
  double x4 = va_arg(l, double);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  va_end(l);
  check (x0 == 880610492);
  check (x1 == 0x1.6ce820a897b1ap+5);
  check (strcmp(x2, "k") == 0);
  check (x3 == 1273198395);
  check (x4 == 0x1.5e3898dde5ccep+5);
  check (x5 == 544018559);
  check (x6 == -1029698568);
  check (x7 == 0x1.62029a85bdc62p+5);
  check (x8 == 3141849129382149905);
  check (x9 == -5300491126696668083);
  return -0x1.1f2ce6cf46d28p+3;
}

void f224(float x0, double x1, char * x2, float x3)
{
  check (x0 == 0x1.be1686p+1F);
  check (x1 == 0x1.33f230cd8442cp+3);
  check (strcmp(x2, "") == 0);
  check (x3 == -0x1.dd60c2p+4F);
}

char * f225(char * x0, double x1, double x2, double x3, float x4)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 0x1.6b4f2293090bp+4);
  check (x2 == 0x1.7c78225e0041p+3);
  check (x3 == -0x1.6a5e5721bc867p+4);
  check (x4 == 0x1.d18818p+4F);
  return "";
}

signed char f226(float x0, char * x1, long long x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  long long x4 = va_arg(l, long long);
  char * x5 = va_arg(l, char *);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  char * x13 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.cb57a6p+3F);
  check (strcmp(x1, "c") == 0);
  check (x2 == -3300438537967555521);
  check (strcmp(x3, "hp") == 0);
  check (x4 == -1041135359131854169);
  check (strcmp(x5, "h") == 0);
  check (x6 == 5827440436972359970);
  check (x7 == 860055996966095937);
  check (x8 == -1073276577);
  check (x9 == 8116031199702340492);
  check (x10 == -0x1.2e896c76f3fd8p+3);
  check (x11 == 0x1.8957b8635a0d4p+4);
  check (x12 == 607257622119277083);
  check (strcmp(x13, "") == 0);
  return -84201652;
}

void f227(char * x0, long long x1, double x2, ...)
{
  va_list l;
  va_start(l, x2);
  double x3 = va_arg(l, double);
  double x4 = va_arg(l, double);
  long long x5 = va_arg(l, long long);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == -8599929139656498242);
  check (x2 == 0x1.2eaf19ad086ep+3);
  check (x3 == -0x1.80a2f78db02adp+5);
  check (x4 == 0x1.65e1587c2b53cp+5);
  check (x5 == 2086504945491028097);
  check (x6 == -1199192389);
  check (x7 == 0x1.445a9fc1ba218p+2);
}

void f228(char * x0, long long x1, char * x2, char * x3, long long x4, int x5, char * x6, double x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  int x9 = va_arg(l, int);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  char * x16 = va_arg(l, char *);
  int x17 = va_arg(l, int);
  char * x18 = va_arg(l, char *);
  long long x19 = va_arg(l, long long);
  long long x20 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "w") == 0);
  check (x1 == 2809425053381553650);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "wx") == 0);
  check (x4 == 4543034236897786663);
  check (x5 == -276605100);
  check (strcmp(x6, "m") == 0);
  check (x7 == 0x1.c7c54023e3568p+3);
  check (x8 == -4819284075335764486);
  check (x9 == -1301142930);
  check (strcmp(x10, "qa") == 0);
  check (x11 == 0x1.8e59a1ce91254p+4);
  check (x12 == 7042241250012258875);
  check (x13 == -721974744206171562);
  check (x14 == -1357189151);
  check (x15 == -403123671);
  check (strcmp(x16, "w") == 0);
  check (x17 == -602960374);
  check (strcmp(x18, "") == 0);
  check (x19 == -1300076022247124446);
  check (x20 == -7588476048231447857);
}

signed char f229(double x0, double x1, long long x2, double x3, ...)
{
  va_list l;
  va_start(l, x3);
  char * x4 = va_arg(l, char *);
  char * x5 = va_arg(l, char *);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.a5178362139cap+4);
  check (x1 == -0x1.2f2b60c19e854p+5);
  check (x2 == 7256277085474007404);
  check (x3 == -0x1.4aeb7a8435c71p+4);
  check (strcmp(x4, "n") == 0);
  check (strcmp(x5, "") == 0);
  check (x6 == -1044445959);
  check (x7 == 0x1.fb86964d64f04p+4);
  check (x8 == 0x1.8567220d522eap+5);
  return 388712111;
}

int f230(char * x0, double x1, char * x2, int x3, char * x4, char * x5, char * x6, int x7, long long x8, long long x9, long long x10, ...)
{
  va_list l;
  va_start(l, x10);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "vq") == 0);
  check (x1 == -0x1.a5edea8b8719p+2);
  check (strcmp(x2, "") == 0);
  check (x3 == -922105604);
  check (strcmp(x4, "") == 0);
  check (strcmp(x5, "") == 0);
  check (strcmp(x6, "te") == 0);
  check (x7 == 52252314);
  check (x8 == -9068210845888585775);
  check (x9 == -5287244800092113263);
  check (x10 == 3572553085994510538);
  check (x11 == 0x1.6ad9c4be671b4p+4);
  check (x12 == -165297705);
  check (x13 == -1048354480);
  return 286260549;
}

char * f231(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  char * x2 = va_arg(l, char *);
  double x3 = va_arg(l, double);
  long long x4 = va_arg(l, long long);
  va_end(l);
  check (x0 == -3695914098913012632);
  check (x1 == -0x1.0ffc55e83fefp+3);
  check (strcmp(x2, "") == 0);
  check (x3 == -0x1.3fb0dd580246bp+4);
  check (x4 == 7574380728876675419);
  return "";
}

short f232(char * x0, float x1, float x2, long long x3, long long x4, float x5)
{
  check (strcmp(x0, "m") == 0);
  check (x1 == 0x1.bc749cp+4F);
  check (x2 == -0x1.90c09cp+4F);
  check (x3 == -9162505659793198055);
  check (x4 == -3660690917292719455);
  check (x5 == -0x1.174426p+5F);
  return 432055879;
}

void f233(void)
{
}

unsigned char f234(char * x0, int x1, double x2, int x3, double x4, int x5, ...)
{
  va_list l;
  va_start(l, x5);
  double x6 = va_arg(l, double);
  char * x7 = va_arg(l, char *);
  long long x8 = va_arg(l, long long);
  int x9 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 987082487);
  check (x2 == 0x1.142f9ecb65232p+5);
  check (x3 == -12304927);
  check (x4 == -0x1.81892eb0270c3p+5);
  check (x5 == 1208013192);
  check (x6 == 0x1.052b32b225acp+5);
  check (strcmp(x7, "") == 0);
  check (x8 == -6807747391203424966);
  check (x9 == -873548909);
  return 310960379;
}

unsigned char f235(double x0, int x1, int x2, float x3)
{
  check (x0 == 0x1.27a27261e58b8p+2);
  check (x1 == -391508697);
  check (x2 == -588244090);
  check (x3 == 0x1.e95bacp+2F);
  return 408751300;
}

char * f236(char * x0, int x1, double x2, ...)
{
  va_list l;
  va_start(l, x2);
  double x3 = va_arg(l, double);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  char * x7 = va_arg(l, char *);
  int x8 = va_arg(l, int);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  int x12 = va_arg(l, int);
  char * x13 = va_arg(l, char *);
  double x14 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "m") == 0);
  check (x1 == 97250955);
  check (x2 == 0x1.126d50ddc91f8p+4);
  check (x3 == 0x1.5a08e0344c8aap+5);
  check (x4 == -1508273131);
  check (x5 == -0x1.6609dfe23b294p+5);
  check (strcmp(x6, "") == 0);
  check (strcmp(x7, "p") == 0);
  check (x8 == 1491401258);
  check (strcmp(x9, "x") == 0);
  check (x10 == 207149725193556738);
  check (strcmp(x11, "ng") == 0);
  check (x12 == -1883277528);
  check (strcmp(x13, "vu") == 0);
  check (x14 == 0x1.54f584764955cp+3);
  return "";
}

unsigned char f237(char * x0, char * x1, float x2)
{
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "eo") == 0);
  check (x2 == 0x1.3a92c2p+5F);
  return 489532345;
}

char * f238(void)
{
  return "f";
}

void f239(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  char * x4 = va_arg(l, char *);
  int x5 = va_arg(l, int);
  long long x6 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.f464296dee01p+1);
  check (x1 == -0x1.45e825adeac28p+3);
  check (x2 == 3832952752884498014);
  check (x3 == 0x1.86e5a0b973bacp+3);
  check (strcmp(x4, "") == 0);
  check (x5 == -691543214);
  check (x6 == -6162242494010868692);
}

void f240(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  char * x3 = va_arg(l, char *);
  double x4 = va_arg(l, double);
  char * x5 = va_arg(l, char *);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  char * x8 = va_arg(l, char *);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  va_end(l);
  check (x0 == -7316156671842081657);
  check (x1 == -0x1.19f538206dedp+3);
  check (x2 == -0x1.c6324f19778p+0);
  check (strcmp(x3, "sb") == 0);
  check (x4 == -0x1.06547be6370f2p+5);
  check (strcmp(x5, "a") == 0);
  check (x6 == 1135653425);
  check (x7 == -0x1.a6f8e276358p-2);
  check (strcmp(x8, "ir") == 0);
  check (x9 == -3608169333670370893);
  check (x10 == -6878237425665761835);
  check (strcmp(x11, "ra") == 0);
  check (x12 == 1571928758);
  check (x13 == 1256777652);
}

signed char f241(char * x0, float x1, int x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  char * x4 = va_arg(l, char *);
  int x5 = va_arg(l, int);
  double x6 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "h") == 0);
  check (x1 == -0x1.9bb9d6p+1F);
  check (x2 == -207883433);
  check (strcmp(x3, "") == 0);
  check (strcmp(x4, "") == 0);
  check (x5 == 333418184);
  check (x6 == 0x1.2d522f53d2668p+4);
  return -534461862;
}

void f242(char * x0, char * x1, float x2, long long x3, ...)
{
  va_list l;
  va_start(l, x3);
  char * x4 = va_arg(l, char *);
  char * x5 = va_arg(l, char *);
  va_end(l);
  check (strcmp(x0, "w") == 0);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.336176p-2F);
  check (x3 == 4523374572555496023);
  check (strcmp(x4, "") == 0);
  check (strcmp(x5, "ct") == 0);
}

void f243(int x0, int x1, double x2, long long x3, char * x4, double x5, char * x6, int x7, double x8, ...)
{
  va_list l;
  va_start(l, x8);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  long long x13 = va_arg(l, long long);
  va_end(l);
  check (x0 == 1320571200);
  check (x1 == 1365941225);
  check (x2 == 0x1.8fe877d99bb3ap+5);
  check (x3 == 7329066605434923229);
  check (strcmp(x4, "q") == 0);
  check (x5 == 0x1.2efaa5b7fd48cp+4);
  check (strcmp(x6, "") == 0);
  check (x7 == -750565070);
  check (x8 == -0x1.160a52e7f9396p+4);
  check (x9 == 0x1.03d675b600f8p-2);
  check (x10 == -7080219741100790363);
  check (x11 == 6972123897562786603);
  check (strcmp(x12, "") == 0);
  check (x13 == -1250391001282373804);
}

void f244(long long x0, float x1, int x2, float x3)
{
  check (x0 == -8152968387778153094);
  check (x1 == -0x1.671862p+3F);
  check (x2 == -912440311);
  check (x3 == 0x1.7ba732p+5F);
}

float f245(float x0, long long x1, double x2, long long x3, int x4, int x5, long long x6, long long x7, int x8, char * x9, double x10, ...)
{
  va_list l;
  va_start(l, x10);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  char * x13 = va_arg(l, char *);
  double x14 = va_arg(l, double);
  long long x15 = va_arg(l, long long);
  long long x16 = va_arg(l, long long);
  char * x17 = va_arg(l, char *);
  int x18 = va_arg(l, int);
  char * x19 = va_arg(l, char *);
  char * x20 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.38ed46p+5F);
  check (x1 == -5460263765386238908);
  check (x2 == -0x1.89ff7d195b45cp+5);
  check (x3 == -5891634392922006036);
  check (x4 == -414769906);
  check (x5 == -270024581);
  check (x6 == 6017685922514238267);
  check (x7 == -908472266062452516);
  check (x8 == 952459785);
  check (strcmp(x9, "") == 0);
  check (x10 == 0x1.afd3d3a4a2098p+4);
  check (x11 == 0x1.41a8a016e311ep+5);
  check (x12 == -8525630846104331613);
  check (strcmp(x13, "") == 0);
  check (x14 == -0x1.8de9a391a2277p+5);
  check (x15 == -6570065531223612091);
  check (x16 == 6733711639975330794);
  check (strcmp(x17, "m") == 0);
  check (x18 == -1576755067);
  check (strcmp(x19, "k") == 0);
  check (strcmp(x20, "") == 0);
  return -0x1.15cb866980f03p+5;
}

void f246(int x0, ...)
{
  va_list l;
  va_start(l, x0);
  double x1 = va_arg(l, double);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  va_end(l);
  check (x0 == -1501240518);
  check (x1 == 0x1.26e111a241fp+2);
  check (x2 == 6714299586112261130);
  check (x3 == 3036778064058806478);
  check (x4 == 2749411040150391977);
}

unsigned short f247(char * x0, char * x1, long long x2, long long x3, float x4, double x5, long long x6, ...)
{
  va_list l;
  va_start(l, x6);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  int x9 = va_arg(l, int);
  char * x10 = va_arg(l, char *);
  char * x11 = va_arg(l, char *);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "m") == 0);
  check (strcmp(x1, "iw") == 0);
  check (x2 == -4451967061161765446);
  check (x3 == -8977036637405289888);
  check (x4 == -0x1.6c6364p+4F);
  check (x5 == 0x1.383a9597441a8p+3);
  check (x6 == -7011191395967215723);
  check (x7 == 0x1.e5dd48b35795p+3);
  check (x8 == 0x1.a33568c95e38p+3);
  check (x9 == -15072578);
  check (strcmp(x10, "s") == 0);
  check (strcmp(x11, "a") == 0);
  check (x12 == -673721585);
  check (x13 == 2742864179678774140);
  check (x14 == -1493525618);
  return -264812421;
}

void f248(void)
{
}

void f249(int x0, float x1, char * x2, double x3, int x4, float x5, char * x6, double x7, ...)
{
  va_list l;
  va_start(l, x7);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  int x13 = va_arg(l, int);
  double x14 = va_arg(l, double);
  char * x15 = va_arg(l, char *);
  int x16 = va_arg(l, int);
  char * x17 = va_arg(l, char *);
  int x18 = va_arg(l, int);
  int x19 = va_arg(l, int);
  va_end(l);
  check (x0 == 939067254);
  check (x1 == 0x1.072cf8p+0F);
  check (strcmp(x2, "") == 0);
  check (x3 == -0x1.9b9466bc3ecep+3);
  check (x4 == 577572031);
  check (x5 == 0x1.2cc8eep+5F);
  check (strcmp(x6, "b") == 0);
  check (x7 == -0x1.6f30c8e6f9856p+5);
  check (x8 == -0x1.6451fcd3aae58p+3);
  check (x9 == 0x1.1d7e9660e2d52p+5);
  check (x10 == 0x1.9bf08c43ae0cp+0);
  check (x11 == -0x1.ab256812345afp+4);
  check (x12 == 6690649529174387163);
  check (x13 == -948893389);
  check (x14 == -0x1.2790b891d3cccp+5);
  check (strcmp(x15, "j") == 0);
  check (x16 == -163136395);
  check (strcmp(x17, "ec") == 0);
  check (x18 == 432846000);
  check (x19 == 737326890);
}

void f250(double x0, ...)
{
  va_list l;
  va_start(l, x0);
  char * x1 = va_arg(l, char *);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.2f67fc0aab74cp+5);
  check (strcmp(x1, "") == 0);
  check (x2 == -8836281921504108420);
}

void f251(char * x0, char * x1, double x2, float x3, float x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  double x6 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "ws") == 0);
  check (x2 == 0x1.a5c1ca45e9724p+4);
  check (x3 == -0x1.fadcecp+0F);
  check (x4 == 0x1.92dcc8p+4F);
  check (x5 == -0x1.77f6bc4c9d02ap+5);
  check (x6 == 0x1.26b6b5a6b9dc4p+4);
}

void f252(double x0, ...)
{
  va_list l;
  va_start(l, x0);
  int x1 = va_arg(l, int);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.67fd622a92d82p+5);
  check (x1 == 100990779);
  check (x2 == 0x1.3333bcaacdcep+2);
  check (x3 == 0x1.605a6ff31e794p+3);
  check (x4 == 0x1.c94035f3517e8p+3);
  check (x5 == 0x1.3dcb37389c11p+4);
}

void f253(float x0)
{
  check (x0 == -0x1.a37572p+3F);
}

unsigned char f254(int x0, double x1, char * x2, ...)
{
  va_list l;
  va_start(l, x2);
  char * x3 = va_arg(l, char *);
  char * x4 = va_arg(l, char *);
  va_end(l);
  check (x0 == -989371757);
  check (x1 == -0x1.55c98b4350195p+4);
  check (strcmp(x2, "ux") == 0);
  check (strcmp(x3, "") == 0);
  check (strcmp(x4, "") == 0);
  return 400070073;
}

signed char f255(void)
{
  return -508344472;
}

void f256(double x0, long long x1, float x2, int x3, double x4, long long x5, float x6, char * x7, int x8, ...)
{
  va_list l;
  va_start(l, x8);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.95da89ca32a4p+3);
  check (x1 == 8978686881529881035);
  check (x2 == 0x1.0b81b2p+5F);
  check (x3 == -1920695739);
  check (x4 == 0x1.8530cc7b5d6bep+5);
  check (x5 == -494354937276477104);
  check (x6 == -0x1.bb34aep+2F);
  check (strcmp(x7, "w") == 0);
  check (x8 == 1974430537);
  check (x9 == 0x1.a133d2e4a6ca4p+3);
  check (x10 == 0x1.7d81662ac4c14p+5);
}

unsigned char f257(long long x0, int x1, double x2, float x3, double x4, long long x5, float x6)
{
  check (x0 == -3908210990047860652);
  check (x1 == -444129001);
  check (x2 == 0x1.7c9bf3c5d174p+5);
  check (x3 == 0x1.cf4482p+0F);
  check (x4 == 0x1.5754f0fd42778p+5);
  check (x5 == -8656765496303253453);
  check (x6 == -0x1.bda29ap+3F);
  return -507901916;
}

void f258(float x0, long long x1, double x2, int x3, double x4, double x5, long long x6, char * x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  int x11 = va_arg(l, int);
  double x12 = va_arg(l, double);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  char * x15 = va_arg(l, char *);
  va_end(l);
  check (x0 == 0x1.ceeedep+4F);
  check (x1 == -6265762273774709740);
  check (x2 == 0x1.7655e8323832p+2);
  check (x3 == 1199686515);
  check (x4 == 0x1.ea9ccbd44c0c8p+3);
  check (x5 == -0x1.1a8ac15b62df3p+5);
  check (x6 == -3514874873839182359);
  check (strcmp(x7, "") == 0);
  check (x8 == 1144766677288378375);
  check (x9 == -2695176154197637678);
  check (x10 == 2825741283999616923);
  check (x11 == -1900323635);
  check (x12 == 0x1.87db9b320055ap+5);
  check (x13 == 216352714324506497);
  check (x14 == 2068087488);
  check (strcmp(x15, "a") == 0);
}

void f259(int x0, long long x1, float x2, long long x3, long long x4, char * x5, int x6, long long x7, float x8)
{
  check (x0 == 890063932);
  check (x1 == -1486954930444078655);
  check (x2 == 0x1.37c716p+5F);
  check (x3 == 2998869292701908817);
  check (x4 == -1314668356077915067);
  check (strcmp(x5, "") == 0);
  check (x6 == 1124252401);
  check (x7 == -7402478993823088180);
  check (x8 == -0x1.32cf0ap+4F);
}

float f260(double x0, char * x1, double x2, double x3, double x4, double x5, char * x6, char * x7, double x8, float x9, double x10, ...)
{
  va_list l;
  va_start(l, x10);
  long long x11 = va_arg(l, long long);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  double x14 = va_arg(l, double);
  int x15 = va_arg(l, int);
  char * x16 = va_arg(l, char *);
  double x17 = va_arg(l, double);
  long long x18 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.74f5cb72c3c4ep+5);
  check (strcmp(x1, "by") == 0);
  check (x2 == -0x1.47a78268dd201p+5);
  check (x3 == 0x1.03ef0f80f883p+4);
  check (x4 == -0x1.6238429b0c2p-1);
  check (x5 == 0x1.ed4b470e75918p+2);
  check (strcmp(x6, "zl") == 0);
  check (strcmp(x7, "") == 0);
  check (x8 == -0x1.e90664f69bdd8p+2);
  check (x9 == 0x1.c1bddp+4F);
  check (x10 == -0x1.3dad23c499d94p+4);
  check (x11 == 3968630348213579551);
  check (x12 == 0x1.7eb20ab13941ap+5);
  check (x13 == -0x1.4e6bcc26bd03dp+5);
  check (x14 == 0x1.2f135f0811574p+4);
  check (x15 == -1007378504);
  check (strcmp(x16, "i") == 0);
  check (x17 == 0x1.7549768be766p+2);
  check (x18 == 7298324271780221166);
  return -0x1.5f2b275048bb9p+5;
}

short f261(char * x0, double x1, float x2, double x3, int x4, double x5, float x6, float x7, long long x8, float x9)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 0x1.43488ba39fac2p+5);
  check (x2 == 0x1.b4986p+4F);
  check (x3 == -0x1.a597d86b57c9cp+3);
  check (x4 == 158909944);
  check (x5 == 0x1.c6c524e36d36p+3);
  check (x6 == -0x1.9f0edcp+3F);
  check (x7 == 0x1.0fce2cp+5F);
  check (x8 == -8218966984318768657);
  check (x9 == 0x1.9f86e6p+4F);
  return 274297523;
}

float f262(char * x0, float x1, char * x2, long long x3, long long x4, long long x5, double x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  long long x12 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 0x1.6948eep+4F);
  check (strcmp(x2, "h") == 0);
  check (x3 == -7901966172405414212);
  check (x4 == 7369277243254479830);
  check (x5 == 4581971966023530667);
  check (x6 == 0x1.1da7f0cd829dp+4);
  check (x7 == -2403406700373077348);
  check (x8 == 5715981931932128689);
  check (x9 == -127678299);
  check (x10 == -1267337855);
  check (x11 == -3805783430338707645);
  check (x12 == -2833317500795931353);
  return 0x1.365a94f597bbcp+3;
}

void f263(float x0, char * x1, char * x2, float x3, double x4, double x5, char * x6, float x7, int x8, long long x9, double x10, ...)
{
  va_list l;
  va_start(l, x10);
  char * x11 = va_arg(l, char *);
  int x12 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.8439ep+5F);
  check (strcmp(x1, "") == 0);
  check (strcmp(x2, "") == 0);
  check (x3 == -0x1.4b07eep+5F);
  check (x4 == -0x1.34e36135bdcb9p+5);
  check (x5 == -0x1.e750f4b79134p+1);
  check (strcmp(x6, "") == 0);
  check (x7 == -0x1.956beap+4F);
  check (x8 == -12010147);
  check (x9 == 7984857244712650717);
  check (x10 == 0x1.86799c2ddd4acp+4);
  check (strcmp(x11, "w") == 0);
  check (x12 == 583332379);
}

void f264(void)
{
}

void f265(int x0, char * x1, float x2, char * x3, int x4, float x5, double x6, char * x7, double x8, float x9, long long x10, ...)
{
  va_list l;
  va_start(l, x10);
  int x11 = va_arg(l, int);
  int x12 = va_arg(l, int);
  char * x13 = va_arg(l, char *);
  char * x14 = va_arg(l, char *);
  int x15 = va_arg(l, int);
  int x16 = va_arg(l, int);
  char * x17 = va_arg(l, char *);
  double x18 = va_arg(l, double);
  va_end(l);
  check (x0 == 92353621);
  check (strcmp(x1, "") == 0);
  check (x2 == -0x1.7f04dcp+2F);
  check (strcmp(x3, "vj") == 0);
  check (x4 == -2096794158);
  check (x5 == -0x1.243a38p+1F);
  check (x6 == 0x1.2825527ad5178p+3);
  check (strcmp(x7, "b") == 0);
  check (x8 == 0x1.952aca0639018p+3);
  check (x9 == 0x1.cd8a6ap+4F);
  check (x10 == -346233905166944054);
  check (x11 == -1114405677);
  check (x12 == -1036915709);
  check (strcmp(x13, "m") == 0);
  check (strcmp(x14, "i") == 0);
  check (x15 == 1090137098);
  check (x16 == 2146154468);
  check (strcmp(x17, "") == 0);
  check (x18 == 0x1.974f1d8122dbp+3);
}

short f266(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  char * x3 = va_arg(l, char *);
  double x4 = va_arg(l, double);
  int x5 = va_arg(l, int);
  double x6 = va_arg(l, double);
  int x7 = va_arg(l, int);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  double x10 = va_arg(l, double);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  va_end(l);
  check (x0 == 3217584677624396343);
  check (x1 == 5677788257559738958);
  check (x2 == -1852479952);
  check (strcmp(x3, "s") == 0);
  check (x4 == -0x1.41f550d133f6ap+5);
  check (x5 == 1309782083);
  check (x6 == 0x1.b5bf8f0f1886p+4);
  check (x7 == 931531639);
  check (x8 == 0x1.8591d4200ee4ap+5);
  check (x9 == -8751720270110101972);
  check (x10 == -0x1.9935824fc957p+1);
  check (x11 == -3328472866171462715);
  check (x12 == 1705246427);
  return 152053301;
}

void f267(long long x0, int x1, long long x2, double x3, ...)
{
  va_list l;
  va_start(l, x3);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  char * x7 = va_arg(l, char *);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  char * x10 = va_arg(l, char *);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  char * x13 = va_arg(l, char *);
  long long x14 = va_arg(l, long long);
  va_end(l);
  check (x0 == -2230124832077227184);
  check (x1 == 832087808);
  check (x2 == -1521717384517654668);
  check (x3 == -0x1.e0025d21ed174p+3);
  check (x4 == 794786085);
  check (x5 == -0x1.8f4585b9a3911p+5);
  check (strcmp(x6, "ps") == 0);
  check (strcmp(x7, "e") == 0);
  check (x8 == 0x1.98d493d770578p+2);
  check (x9 == -3069066533352165817);
  check (strcmp(x10, "h") == 0);
  check (x11 == -6038625584820556154);
  check (strcmp(x12, "k") == 0);
  check (strcmp(x13, "ko") == 0);
  check (x14 == -3040165652053014353);
}

void f268(double x0, double x1, float x2, char * x3, long long x4, float x5, int x6, double x7, float x8)
{
  check (x0 == -0x1.ccbfd19e94982p+4);
  check (x1 == 0x1.4db0ffbdbdc82p+5);
  check (x2 == 0x1.3352a4p+4F);
  check (strcmp(x3, "o") == 0);
  check (x4 == 7839817676736996027);
  check (x5 == 0x1.04c5ep+5F);
  check (x6 == 429381756);
  check (x7 == 0x1.a8913348810ap+4);
  check (x8 == -0x1.3d607cp+5F);
}

unsigned char f269(char * x0, ...)
{
  va_list l;
  va_start(l, x0);
  int x1 = va_arg(l, int);
  long long x2 = va_arg(l, long long);
  char * x3 = va_arg(l, char *);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  long long x6 = va_arg(l, long long);
  int x7 = va_arg(l, int);
  double x8 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "zn") == 0);
  check (x1 == 1596881650);
  check (x2 == -3449836571455753779);
  check (strcmp(x3, "lg") == 0);
  check (x4 == 0x1.565140d13ae7cp+5);
  check (x5 == 0x1.5d97044ebf8b8p+5);
  check (x6 == -657087953735463251);
  check (x7 == 352355355);
  check (x8 == -0x1.30622adfe7cecp+5);
  return 75381026;
}

void f270(long long x0, char * x1, int x2, double x3, float x4, float x5, long long x6, ...)
{
  va_list l;
  va_start(l, x6);
  int x7 = va_arg(l, int);
  double x8 = va_arg(l, double);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  va_end(l);
  check (x0 == -429761115495277992);
  check (strcmp(x1, "lo") == 0);
  check (x2 == 1800762868);
  check (x3 == -0x1.d0781f0cf9ffp+2);
  check (x4 == 0x1.f4caa4p+4F);
  check (x5 == 0x1.28a184p+5F);
  check (x6 == 1167375819432843989);
  check (x7 == 87396051);
  check (x8 == 0x1.58720339fc12ep+5);
  check (strcmp(x9, "") == 0);
  check (x10 == -2770974134527863667);
  check (x11 == -0x1.3cd359d18f79cp+3);
  check (x12 == 1242010516);
}

unsigned short f271(long long x0, double x1, char * x2, ...)
{
  va_list l;
  va_start(l, x2);
  int x3 = va_arg(l, int);
  double x4 = va_arg(l, double);
  int x5 = va_arg(l, int);
  va_end(l);
  check (x0 == -5893027839152564854);
  check (x1 == 0x1.8285c4a2afd4cp+5);
  check (strcmp(x2, "") == 0);
  check (x3 == -1557074689);
  check (x4 == 0x1.63055ff55159p+5);
  check (x5 == -240812134);
  return -275162629;
}

void f272(float x0, double x1, char * x2, float x3)
{
  check (x0 == -0x1.a378c4p-1F);
  check (x1 == -0x1.1853c4be978c4p+5);
  check (strcmp(x2, "c") == 0);
  check (x3 == -0x1.a93f5ep+3F);
}

short f273(long long x0, int x1, char * x2, long long x3, float x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  double x6 = va_arg(l, double);
  char * x7 = va_arg(l, char *);
  va_end(l);
  check (x0 == -2556731478262355512);
  check (x1 == -1014341553);
  check (strcmp(x2, "") == 0);
  check (x3 == 4233826779247381790);
  check (x4 == -0x1.4e16bcp+1F);
  check (x5 == -974151317624007898);
  check (x6 == 0x1.9f269c339e37cp+3);
  check (strcmp(x7, "q") == 0);
  return 458330413;
}

void f274(char * x0, float x1, double x2, float x3, long long x4, int x5, double x6, int x7, double x8, ...)
{
  va_list l;
  va_start(l, x8);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 0x1.455036p+5F);
  check (x2 == -0x1.16e93e3ffc068p+3);
  check (x3 == 0x1.45a7fep+5F);
  check (x4 == -4004193673729815144);
  check (x5 == 1845146161);
  check (x6 == 0x1.6e9fb0769788p+2);
  check (x7 == -506491829);
  check (x8 == 0x1.8607079716a46p+5);
  check (x9 == -0x1.ec30557d0bcacp+4);
  check (x10 == -1691667939);
}

void f275(float x0, int x1, int x2, long long x3, double x4, double x5, float x6, long long x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  va_end(l);
  check (x0 == 0x1.d8faaap+4F);
  check (x1 == -1664524600);
  check (x2 == -1487500134);
  check (x3 == -7908050929654297658);
  check (x4 == 0x1.a36fd2c504d4p+3);
  check (x5 == -0x1.535a20f0c2152p+5);
  check (x6 == -0x1.054f28p+5F);
  check (x7 == 1178251491070235999);
  check (x8 == -3828392848763181658);
  check (x9 == 0x1.c2272e3ffaeep+3);
  check (x10 == 2344318826756630718);
  check (strcmp(x11, "zh") == 0);
}

unsigned char f276(char * x0, char * x1, ...)
{
  va_list l;
  va_start(l, x1);
  char * x2 = va_arg(l, char *);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "zm") == 0);
  check (strcmp(x2, "gu") == 0);
  return 247154508;
}

int f277(float x0, char * x1, char * x2, double x3, int x4, char * x5, char * x6, char * x7, char * x8, ...)
{
  va_list l;
  va_start(l, x8);
  long long x9 = va_arg(l, long long);
  char * x10 = va_arg(l, char *);
  char * x11 = va_arg(l, char *);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  double x14 = va_arg(l, double);
  int x15 = va_arg(l, int);
  int x16 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.bc09fcp+2F);
  check (strcmp(x1, "k") == 0);
  check (strcmp(x2, "") == 0);
  check (x3 == -0x1.4b780378f733p+3);
  check (x4 == -309446255);
  check (strcmp(x5, "et") == 0);
  check (strcmp(x6, "i") == 0);
  check (strcmp(x7, "ri") == 0);
  check (strcmp(x8, "") == 0);
  check (x9 == -4847486021229121143);
  check (strcmp(x10, "u") == 0);
  check (strcmp(x11, "lp") == 0);
  check (x12 == 6294645278751895415);
  check (x13 == 4048669065798390876);
  check (x14 == -0x1.80f4a0de709bcp+5);
  check (x15 == 1856986039);
  check (x16 == -130408865);
  return -1737506065;
}

char * f278(float x0, float x1, float x2, float x3, double x4, float x5, float x6, int x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  char * x9 = va_arg(l, char *);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  char * x16 = va_arg(l, char *);
  char * x17 = va_arg(l, char *);
  long long x18 = va_arg(l, long long);
  char * x19 = va_arg(l, char *);
  double x20 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.3ea104p+5F);
  check (x1 == 0x1.c89b9p+3F);
  check (x2 == 0x1.45a552p-1F);
  check (x3 == -0x1.564e9cp+4F);
  check (x4 == 0x1.8bfd7f155c6a4p+5);
  check (x5 == 0x1.46f82p+3F);
  check (x6 == -0x1.f0594ep+4F);
  check (x7 == 1707270703);
  check (x8 == 4069615313214599605);
  check (strcmp(x9, "pw") == 0);
  check (strcmp(x10, "") == 0);
  check (x11 == -0x1.06c2e2d66c928p+3);
  check (x12 == -0x1.333de054c4b9cp+3);
  check (x13 == -0x1.dd6ea4eaab36cp+3);
  check (x14 == -2129993028);
  check (x15 == -2073451964);
  check (strcmp(x16, "") == 0);
  check (strcmp(x17, "") == 0);
  check (x18 == 3321606546225789514);
  check (strcmp(x19, "c") == 0);
  check (x20 == -0x1.1a8cea40ba71cp+5);
  return "w";
}

void f279(double x0, double x1, int x2, int x3, ...)
{
  va_list l;
  va_start(l, x3);
  char * x4 = va_arg(l, char *);
  va_end(l);
  check (x0 == 0x1.2007a26fd0fap+3);
  check (x1 == 0x1.26b00f397f6p+4);
  check (x2 == -1776718043);
  check (x3 == 1608912595);
  check (strcmp(x4, "f") == 0);
}

void f280(float x0, float x1, double x2, char * x3, long long x4, int x5, char * x6, float x7, double x8, float x9, float x10)
{
  check (x0 == 0x1.48be5p+5F);
  check (x1 == -0x1.a7e518p+4F);
  check (x2 == 0x1.8decdbacad99cp+5);
  check (strcmp(x3, "mb") == 0);
  check (x4 == -4016557388191931175);
  check (x5 == 521977516);
  check (strcmp(x6, "b") == 0);
  check (x7 == -0x1.419cacp+4F);
  check (x8 == -0x1.fb1b608113bp-3);
  check (x9 == 0x1.d51224p+3F);
  check (x10 == -0x1.77e678p+4F);
}

void f281(long long x0, float x1, double x2, int x3, double x4, int x5, double x6, float x7, long long x8, int x9, ...)
{
  va_list l;
  va_start(l, x9);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  double x14 = va_arg(l, double);
  long long x15 = va_arg(l, long long);
  int x16 = va_arg(l, int);
  double x17 = va_arg(l, double);
  va_end(l);
  check (x0 == -839737046748985754);
  check (x1 == -0x1.8c3d26p+5F);
  check (x2 == 0x1.581927db972b6p+5);
  check (x3 == -120163677);
  check (x4 == -0x1.13786e9ae2c2p+2);
  check (x5 == 107715119);
  check (x6 == 0x1.eb9b22e747964p+4);
  check (x7 == 0x1.21c688p+3F);
  check (x8 == 16583983585740786);
  check (x9 == 640700276);
  check (x10 == 4768094562670639616);
  check (x11 == -0x1.817ad5a24348cp+4);
  check (x12 == -5720705267226117732);
  check (x13 == -3460233239669716951);
  check (x14 == -0x1.191bc9c6a3ebp+1);
  check (x15 == -7084056397084253353);
  check (x16 == 1417185194);
  check (x17 == -0x1.d3b9463c81bcp+1);
}

void f282(long long x0, float x1, double x2, float x3)
{
  check (x0 == 7770609864033053056);
  check (x1 == -0x1.3e8996p+1F);
  check (x2 == 0x1.9c2bd7fa4dd6cp+4);
  check (x3 == 0x1.039e92p+3F);
}

void f283(float x0, long long x1, double x2, ...)
{
  va_list l;
  va_start(l, x2);
  int x3 = va_arg(l, int);
  char * x4 = va_arg(l, char *);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  char * x13 = va_arg(l, char *);
  char * x14 = va_arg(l, char *);
  va_end(l);
  check (x0 == 0x1.21e7e6p+5F);
  check (x1 == 5044897394613003977);
  check (x2 == -0x1.0dc863b061dep+5);
  check (x3 == 551037213);
  check (strcmp(x4, "gb") == 0);
  check (x5 == 824214662);
  check (x6 == 1608512937);
  check (x7 == -8559449919500890771);
  check (x8 == 510464226);
  check (x9 == -37040991);
  check (x10 == -1091371049);
  check (x11 == 8695283464068969290);
  check (strcmp(x12, "") == 0);
  check (strcmp(x13, "") == 0);
  check (strcmp(x14, "") == 0);
}

void f284(float x0, long long x1, float x2, float x3, long long x4, float x5, long long x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  double x8 = va_arg(l, double);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  char * x12 = va_arg(l, char *);
  char * x13 = va_arg(l, char *);
  va_end(l);
  check (x0 == 0x1.115484p+5F);
  check (x1 == 8074402528906806057);
  check (x2 == -0x1.0e6ed6p+4F);
  check (x3 == -0x1.4d85aep+4F);
  check (x4 == -4445826599959131050);
  check (x5 == 0x1.3f6568p+5F);
  check (x6 == -7089671770062263364);
  check (x7 == -1977961490);
  check (x8 == 0x1.f1e875ebcf7c8p+4);
  check (strcmp(x9, "uh") == 0);
  check (x10 == -1645527570);
  check (x11 == 0x1.c1881c4e7c164p+4);
  check (strcmp(x12, "e") == 0);
  check (strcmp(x13, "") == 0);
}

void f285(float x0, double x1, double x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  char * x7 = va_arg(l, char *);
  char * x8 = va_arg(l, char *);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  int x13 = va_arg(l, int);
  char * x14 = va_arg(l, char *);
  long long x15 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.329b0ap+5F);
  check (x1 == -0x1.a3c80a8d0a63cp+3);
  check (x2 == -0x1.9a6f1ee5a79p+2);
  check (strcmp(x3, "qa") == 0);
  check (x4 == 439093181);
  check (x5 == 0x1.bc6c8b66f66c8p+4);
  check (x6 == -0x1.451f157df8645p+5);
  check (strcmp(x7, "k") == 0);
  check (strcmp(x8, "f") == 0);
  check (x9 == -0x1.0363d496c1f2p+1);
  check (x10 == -0x1.73b6f1c2600dcp+4);
  check (x11 == -0x1.8749a0f3fcdb9p+4);
  check (x12 == -0x1.43ac2b582644ep+4);
  check (x13 == 1698399027);
  check (strcmp(x14, "") == 0);
  check (x15 == -3317519536534328383);
}

void f286(double x0, int x1, int x2, int x3, int x4, double x5, char * x6, int x7, char * x8, ...)
{
  va_list l;
  va_start(l, x8);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  long long x13 = va_arg(l, long long);
  long long x14 = va_arg(l, long long);
  char * x15 = va_arg(l, char *);
  long long x16 = va_arg(l, long long);
  char * x17 = va_arg(l, char *);
  long long x18 = va_arg(l, long long);
  int x19 = va_arg(l, int);
  char * x20 = va_arg(l, char *);
  va_end(l);
  check (x0 == 0x1.0799b85ef60ecp+5);
  check (x1 == 1906569674);
  check (x2 == 643833280);
  check (x3 == -1684391956);
  check (x4 == 1427520970);
  check (x5 == -0x1.1e1e446cde628p+5);
  check (strcmp(x6, "") == 0);
  check (x7 == 2122290320);
  check (strcmp(x8, "d") == 0);
  check (x9 == 0x1.11da48df728fp+4);
  check (x10 == -1653247220);
  check (x11 == -5969084465317180479);
  check (strcmp(x12, "gc") == 0);
  check (x13 == -3640534786734645904);
  check (x14 == -8634779851483398858);
  check (strcmp(x15, "pw") == 0);
  check (x16 == 8344854363560466330);
  check (strcmp(x17, "h") == 0);
  check (x18 == 384816347558204149);
  check (x19 == -1025822029);
  check (strcmp(x20, "tc") == 0);
}

void f287(char * x0, int x1, char * x2, float x3, double x4, int x5, ...)
{
  va_list l;
  va_start(l, x5);
  double x6 = va_arg(l, double);
  int x7 = va_arg(l, int);
  char * x8 = va_arg(l, char *);
  va_end(l);
  check (strcmp(x0, "wg") == 0);
  check (x1 == 363865308);
  check (strcmp(x2, "x") == 0);
  check (x3 == 0x1.bc6b2p+3F);
  check (x4 == 0x1.8cf34af516648p+4);
  check (x5 == 5296646);
  check (x6 == -0x1.2c9e20fbc43bep+5);
  check (x7 == -1272758997);
  check (strcmp(x8, "u") == 0);
}

signed char f288(char * x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == -0x1.28f4b515c0471p+5);
  check (x2 == 0x1.259d836c54de8p+4);
  check (x3 == 0x1.18384a79719dep+5);
  check (x4 == -5116100821650663821);
  check (x5 == 0x1.bc98b2e4f024p+2);
  check (x6 == -8877452586158159727);
  check (x7 == -1979311235326881472);
  check (x8 == -404818647);
  check (x9 == 7156926551408759865);
  check (x10 == -6032662564851510327);
  check (x11 == -0x1.46c642e3ce8b8p+3);
  return -275914350;
}

unsigned char f289(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  char * x2 = va_arg(l, char *);
  double x3 = va_arg(l, double);
  long long x4 = va_arg(l, long long);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  va_end(l);
  check (x0 == 6709027574004452074);
  check (x1 == -2763770865711647265);
  check (strcmp(x2, "u") == 0);
  check (x3 == -0x1.8881836788a5dp+4);
  check (x4 == 5121137855786418276);
  check (x5 == 1548939395);
  check (x6 == 1176808764);
  return 292775933;
}

void f290(int x0, float x1, double x2, char * x3, float x4, long long x5, char * x6, long long x7, ...)
{
  va_list l;
  va_start(l, x7);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  char * x13 = va_arg(l, char *);
  va_end(l);
  check (x0 == -101121801);
  check (x1 == 0x1.c0b742p+4F);
  check (x2 == 0x1.c4dbaa769d64p+2);
  check (strcmp(x3, "") == 0);
  check (x4 == -0x1.642238p+5F);
  check (x5 == 5962643340995458044);
  check (strcmp(x6, "fe") == 0);
  check (x7 == -455943489805169284);
  check (x8 == -1272959198);
  check (x9 == 1123158765);
  check (x10 == -0x1.b953f7da24c7p+4);
  check (x11 == -36225555);
  check (x12 == -306915776384125125);
  check (strcmp(x13, "lb") == 0);
}

char * f291(int x0, long long x1, double x2, int x3, float x4)
{
  check (x0 == -1340835137);
  check (x1 == -5501544465815069939);
  check (x2 == -0x1.686fa002ce64dp+5);
  check (x3 == 119747036);
  check (x4 == -0x1.b6ff98p+3F);
  return "c";
}

void f292(long long x0, long long x1, char * x2, float x3, long long x4, int x5, char * x6, int x7, int x8, double x9, ...)
{
  va_list l;
  va_start(l, x9);
  double x10 = va_arg(l, double);
  char * x11 = va_arg(l, char *);
  char * x12 = va_arg(l, char *);
  char * x13 = va_arg(l, char *);
  char * x14 = va_arg(l, char *);
  double x15 = va_arg(l, double);
  long long x16 = va_arg(l, long long);
  double x17 = va_arg(l, double);
  char * x18 = va_arg(l, char *);
  double x19 = va_arg(l, double);
  char * x20 = va_arg(l, char *);
  char * x21 = va_arg(l, char *);
  va_end(l);
  check (x0 == 8797221812402295465);
  check (x1 == 6520443597826758523);
  check (strcmp(x2, "iv") == 0);
  check (x3 == -0x1.a455a6p+3F);
  check (x4 == -6538572752034084702);
  check (x5 == -1880465097);
  check (strcmp(x6, "q") == 0);
  check (x7 == -1874710201);
  check (x8 == -845756039);
  check (x9 == -0x1.a97194b89fbd9p+4);
  check (x10 == -0x1.616509c80e201p+5);
  check (strcmp(x11, "jz") == 0);
  check (strcmp(x12, "") == 0);
  check (strcmp(x13, "") == 0);
  check (strcmp(x14, "hm") == 0);
  check (x15 == -0x1.08241c0dbdddep+5);
  check (x16 == 1882505267496089566);
  check (x17 == -0x1.b91607f476218p+3);
  check (strcmp(x18, "r") == 0);
  check (x19 == 0x1.f42258f854134p+4);
  check (strcmp(x20, "") == 0);
  check (strcmp(x21, "") == 0);
}

void f293(char * x0, int x1, double x2, long long x3, char * x4, int x5, int x6, char * x7, double x8, float x9, double x10, ...)
{
  va_list l;
  va_start(l, x10);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  int x16 = va_arg(l, int);
  long long x17 = va_arg(l, long long);
  double x18 = va_arg(l, double);
  double x19 = va_arg(l, double);
  int x20 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "t") == 0);
  check (x1 == -786862960);
  check (x2 == -0x1.8754cfd025524p+5);
  check (x3 == 1351883227508626244);
  check (strcmp(x4, "v") == 0);
  check (x5 == 664916448);
  check (x6 == 868205271);
  check (strcmp(x7, "q") == 0);
  check (x8 == 0x1.4af5e4ae82d14p+5);
  check (x9 == 0x1.eb4b52p+2F);
  check (x10 == 0x1.3a3aab9fe8428p+3);
  check (x11 == 0x1.6c7e653a74cd8p+3);
  check (x12 == 41985585);
  check (x13 == -1486809495624857503);
  check (x14 == -2089001220);
  check (x15 == 2733367569982352213);
  check (x16 == -1647409091);
  check (x17 == 6560559117785584341);
  check (x18 == -0x1.5a6b4e08811fcp+5);
  check (x19 == -0x1.852c2ad4501dp+2);
  check (x20 == 143786259);
}

void f294(int x0, long long x1, double x2, float x3, int x4, long long x5, float x6, double x7, int x8, long long x9, ...)
{
  va_list l;
  va_start(l, x9);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  char * x12 = va_arg(l, char *);
  long long x13 = va_arg(l, long long);
  double x14 = va_arg(l, double);
  int x15 = va_arg(l, int);
  int x16 = va_arg(l, int);
  long long x17 = va_arg(l, long long);
  int x18 = va_arg(l, int);
  double x19 = va_arg(l, double);
  double x20 = va_arg(l, double);
  va_end(l);
  check (x0 == 1109858847);
  check (x1 == 1372635160225514051);
  check (x2 == -0x1.465acb246096ep+5);
  check (x3 == 0x1.212c82p+5F);
  check (x4 == 1162499627);
  check (x5 == -7423316620761680386);
  check (x6 == 0x1.79fedap+4F);
  check (x7 == -0x1.ace36e4b6414fp+4);
  check (x8 == 2053456871);
  check (x9 == 55897399064173843);
  check (x10 == 8872540622966396017);
  check (x11 == 0x1.45f2378584e32p+5);
  check (strcmp(x12, "k") == 0);
  check (x13 == -3020280165285786140);
  check (x14 == -0x1.0a43fd3cfcecap+4);
  check (x15 == 786279045);
  check (x16 == -1624923133);
  check (x17 == -6921651157792110514);
  check (x18 == -185422814);
  check (x19 == 0x1.5051bc3504c9p+1);
  check (x20 == -0x1.86e1458669087p+5);
}

void f295(float x0)
{
  check (x0 == -0x1.253a3ap+5F);
}

void f296(void)
{
}

double f297(char * x0, int x1, float x2, long long x3, char * x4, long long x5, int x6, ...)
{
  va_list l;
  va_start(l, x6);
  int x7 = va_arg(l, int);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  long long x11 = va_arg(l, long long);
  double x12 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == -1353191396);
  check (x2 == 0x1.de73d8p+2F);
  check (x3 == -3540834271338585729);
  check (strcmp(x4, "d") == 0);
  check (x5 == 5369893235386119860);
  check (x6 == 2082502130);
  check (x7 == -397430094);
  check (x8 == -0x1.61b9221b35d65p+4);
  check (x9 == 0x1.14b4e144b4e5p+4);
  check (x10 == -0x1.02020c41b9658p+5);
  check (x11 == 6399971092696596247);
  check (x12 == -0x1.81b3db4bf49bp+3);
  return 0x1.d632b527a5a08p+2;
}

int f298(long long x0, float x1, float x2, double x3, float x4)
{
  check (x0 == -5803320444362264310);
  check (x1 == 0x1.6276ap+3F);
  check (x2 == 0x1.b6aaa2p+4F);
  check (x3 == -0x1.59299be710687p+5);
  check (x4 == 0x1.16446cp+5F);
  return -1200611673;
}

long long f299(char * x0, long long x1, int x2, char * x3, int x4, float x5, int x6, char * x7, double x8, ...)
{
  va_list l;
  va_start(l, x8);
  int x9 = va_arg(l, int);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  char * x13 = va_arg(l, char *);
  double x14 = va_arg(l, double);
  int x15 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "s") == 0);
  check (x1 == 2114795634863991725);
  check (x2 == -1883303616);
  check (strcmp(x3, "") == 0);
  check (x4 == -1014162939);
  check (x5 == 0x1.ab6aecp+2F);
  check (x6 == 1500285433);
  check (strcmp(x7, "fu") == 0);
  check (x8 == 0x1.1d479b2f978aap+5);
  check (x9 == 379252973);
  check (x10 == 0x1.82f3bf214f4p+3);
  check (x11 == -1081121856);
  check (x12 == -3485704085356731557);
  check (strcmp(x13, "jx") == 0);
  check (x14 == 0x1.82d23e603b464p+3);
  check (x15 == 768945262);
  return 3261839270162720307;
}

signed char f300(float x0, int x1, float x2, long long x3, float x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  char * x8 = va_arg(l, char *);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.5f4ae2p+5F);
  check (x1 == 930210981);
  check (x2 == 0x1.724174p+3F);
  check (x3 == 2400505231399532723);
  check (x4 == -0x1.6a9a7p+0F);
  check (x5 == 7149506365124953165);
  check (x6 == 559349466);
  check (x7 == -2169577933277872766);
  check (strcmp(x8, "c") == 0);
  check (x9 == 0x1.85c3348c8be34p+4);
  check (x10 == 1092637433);
  check (x11 == 8644750014683195574);
  return 389696201;
}

short f301(char * x0, ...)
{
  va_list l;
  va_start(l, x0);
  double x1 = va_arg(l, double);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  char * x4 = va_arg(l, char *);
  long long x5 = va_arg(l, long long);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  double x8 = va_arg(l, double);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "rp") == 0);
  check (x1 == -0x1.521034eb53d48p+2);
  check (x2 == -665678461);
  check (x3 == 0x1.1587d4f54f1dcp+5);
  check (strcmp(x4, "tv") == 0);
  check (x5 == -6038235396445270668);
  check (strcmp(x6, "dh") == 0);
  check (x7 == 4185627410046074882);
  check (x8 == -0x1.1a42774bb7f7p+5);
  check (strcmp(x9, "m") == 0);
  check (x10 == -495295021510510004);
  return -412938396;
}

int f302(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  va_end(l);
  check (x0 == 1970278027);
  check (x1 == 1333712801);
  check (x2 == 2011791611276024140);
  check (x3 == -3338786086826683408);
  check (x4 == -0x1.9d0fdfde0085cp+4);
  check (x5 == 0x1.6f0eaa497e57cp+4);
  check (x6 == 0x1.52245f2277b48p+3);
  return 1899175422;
}

char * f303(float x0, int x1, double x2, double x3, float x4, long long x5, int x6, ...)
{
  va_list l;
  va_start(l, x6);
  int x7 = va_arg(l, int);
  char * x8 = va_arg(l, char *);
  long long x9 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.1fcdap+5F);
  check (x1 == 594117695);
  check (x2 == -0x1.17885b4ae81f2p+5);
  check (x3 == 0x1.65efc01d51ca8p+3);
  check (x4 == -0x1.8f7d98p+4F);
  check (x5 == 1032051699229147231);
  check (x6 == -1242366118);
  check (x7 == 763099127);
  check (strcmp(x8, "bb") == 0);
  check (x9 == -5408719227798632180);
  return "";
}

signed char f304(char * x0, int x1, long long x2, float x3, float x4, long long x5, long long x6, char * x7, ...)
{
  va_list l;
  va_start(l, x7);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  char * x13 = va_arg(l, char *);
  long long x14 = va_arg(l, long long);
  int x15 = va_arg(l, int);
  int x16 = va_arg(l, int);
  double x17 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 1607956844);
  check (x2 == -1981948734327254087);
  check (x3 == 0x1.1edab2p+4F);
  check (x4 == 0x1.6327f8p+5F);
  check (x5 == -7332213299969842499);
  check (x6 == 8576515980854068487);
  check (strcmp(x7, "v") == 0);
  check (x8 == -0x1.214f44b7dc134p+3);
  check (x9 == 2931145958212816711);
  check (x10 == 5963167713423805735);
  check (x11 == -0x1.7c8a25cb68fap+0);
  check (x12 == -0x1.4e843196b3632p+5);
  check (strcmp(x13, "d") == 0);
  check (x14 == 9006980420434566160);
  check (x15 == 1373712959);
  check (x16 == -34744644);
  check (x17 == 0x1.1b7960b4c8ea8p+4);
  return 11993661;
}

unsigned short f305(long long x0, int x1, double x2, char * x3, double x4, int x5, float x6)
{
  check (x0 == -1027546187753116087);
  check (x1 == 1703615785);
  check (x2 == -0x1.397db52519908p+2);
  check (strcmp(x3, "u") == 0);
  check (x4 == -0x1.ef5e965a9161fp+4);
  check (x5 == 812022985);
  check (x6 == 0x1.2e66dap+4F);
  return -406301466;
}

void f306(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -148927269);
  check (x1 == -3893315862952420552);
  check (x2 == 7810850944044496350);
  check (x3 == -0x1.ef0a207920599p+4);
}

void f307(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  char * x8 = va_arg(l, char *);
  double x9 = va_arg(l, double);
  char * x10 = va_arg(l, char *);
  long long x11 = va_arg(l, long long);
  double x12 = va_arg(l, double);
  long long x13 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.2b9e1cp+5F);
  check (x1 == 1213685802);
  check (x2 == -652508038);
  check (x3 == -7484149774706094256);
  check (x4 == 2264147161327955050);
  check (x5 == -0x1.7b5918b481265p+4);
  check (x6 == 1141972039877428590);
  check (x7 == 3039512631733764634);
  check (strcmp(x8, "if") == 0);
  check (x9 == -0x1.1ba6fc744bb98p+2);
  check (strcmp(x10, "") == 0);
  check (x11 == -8294162568352746105);
  check (x12 == 0x1.de199d63aba74p+4);
  check (x13 == 7607425947228141580);
}

void f308(int x0, long long x1, double x2, int x3, float x4, char * x5, long long x6, float x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  char * x9 = va_arg(l, char *);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  long long x14 = va_arg(l, long long);
  char * x15 = va_arg(l, char *);
  double x16 = va_arg(l, double);
  long long x17 = va_arg(l, long long);
  long long x18 = va_arg(l, long long);
  long long x19 = va_arg(l, long long);
  char * x20 = va_arg(l, char *);
  va_end(l);
  check (x0 == 836924912);
  check (x1 == 1060251425908117377);
  check (x2 == 0x1.78414f09016cp-1);
  check (x3 == -1118199102);
  check (x4 == 0x1.dba09p+2F);
  check (strcmp(x5, "q") == 0);
  check (x6 == 833231539216552331);
  check (x7 == -0x1.49b578p+5F);
  check (x8 == 5433900494262014283);
  check (strcmp(x9, "v") == 0);
  check (strcmp(x10, "i") == 0);
  check (x11 == 0x1.2d9162977e9a4p+5);
  check (x12 == 1340548581);
  check (x13 == 1142475742);
  check (x14 == 1316365061968508428);
  check (strcmp(x15, "") == 0);
  check (x16 == -0x1.e4e9493796aep+2);
  check (x17 == -1344136922527227462);
  check (x18 == -7852662167239208475);
  check (x19 == 1985611907536137206);
  check (strcmp(x20, "") == 0);
}

void f309(float x0)
{
  check (x0 == 0x1.835e9p+5F);
}

long long f310(double x0, float x1, int x2, int x3, double x4, int x5, int x6, float x7, float x8)
{
  check (x0 == 0x1.e88e5a05560dp+4);
  check (x1 == -0x1.b3a98ep+4F);
  check (x2 == -1549559531);
  check (x3 == -1635970016);
  check (x4 == -0x1.df9601102967cp+3);
  check (x5 == 1334300516);
  check (x6 == 30196541);
  check (x7 == -0x1.c54318p+3F);
  check (x8 == 0x1.30348p+5F);
  return 9149232225553254770;
}

void f311(int x0, char * x1, float x2, long long x3, ...)
{
  va_list l;
  va_start(l, x3);
  char * x4 = va_arg(l, char *);
  int x5 = va_arg(l, int);
  long long x6 = va_arg(l, long long);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  va_end(l);
  check (x0 == 505267456);
  check (strcmp(x1, "fe") == 0);
  check (x2 == 0x1.0d8d9ap+4F);
  check (x3 == -3173312054587419831);
  check (strcmp(x4, "sv") == 0);
  check (x5 == 1534421037);
  check (x6 == 2871227460534947046);
  check (x7 == 65643992);
  check (x8 == -839017892);
  check (strcmp(x9, "") == 0);
  check (x10 == 0x1.1843a7d2423ccp+3);
}

float f312(double x0, int x1, float x2)
{
  check (x0 == -0x1.773e1c7e18283p+5);
  check (x1 == -473758487);
  check (x2 == -0x1.3a0a18p+3F);
  return -0x1.50bfb8ea412dp+1;
}

long long f313(float x0, long long x1, long long x2, float x3, long long x4, float x5, char * x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.6ac13ep+5F);
  check (x1 == -3162037854224500493);
  check (x2 == -6125512784319098696);
  check (x3 == 0x1.56582p+0F);
  check (x4 == 6085739115341688864);
  check (x5 == -0x1.52ffb2p+4F);
  check (strcmp(x6, "v") == 0);
  check (x7 == -3361986261829733019);
  check (x8 == 5390249354751479333);
  return 2376056816018432602;
}

void f314(char * x0, char * x1, double x2, double x3, int x4, double x5, char * x6, int x7, float x8, char * x9, ...)
{
  va_list l;
  va_start(l, x9);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  double x13 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "zk") == 0);
  check (x2 == 0x1.880c139118c58p+4);
  check (x3 == -0x1.1105dcd9143c5p+5);
  check (x4 == -1346102255);
  check (x5 == -0x1.e32796c3925fp+2);
  check (strcmp(x6, "") == 0);
  check (x7 == 749401044);
  check (x8 == 0x1.87485ap+4F);
  check (strcmp(x9, "") == 0);
  check (x10 == -1900273843323265671);
  check (x11 == -5408185105142591795);
  check (strcmp(x12, "") == 0);
  check (x13 == -0x1.36f8e961756c6p+5);
}

void f315(int x0, float x1, long long x2, double x3, char * x4, float x5, double x6, double x7, double x8, double x9, int x10, ...)
{
  va_list l;
  va_start(l, x10);
  char * x11 = va_arg(l, char *);
  int x12 = va_arg(l, int);
  char * x13 = va_arg(l, char *);
  va_end(l);
  check (x0 == 867303121);
  check (x1 == -0x1.e7e49ap+3F);
  check (x2 == 7416495100021317280);
  check (x3 == 0x1.2871b0207b64cp+4);
  check (strcmp(x4, "j") == 0);
  check (x5 == -0x1.df6cc8p+4F);
  check (x6 == -0x1.4659ad354b196p+4);
  check (x7 == -0x1.7ec068373959ap+4);
  check (x8 == 0x1.9a410150f8d48p+3);
  check (x9 == 0x1.1ee5bd1d674f4p+5);
  check (x10 == 325435585);
  check (strcmp(x11, "wr") == 0);
  check (x12 == -1435149548);
  check (strcmp(x13, "dj") == 0);
}

void f316(double x0, ...)
{
  va_list l;
  va_start(l, x0);
  char * x1 = va_arg(l, char *);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  long long x4 = va_arg(l, long long);
  char * x5 = va_arg(l, char *);
  char * x6 = va_arg(l, char *);
  int x7 = va_arg(l, int);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.8f634feadd284p+4);
  check (strcmp(x1, "qr") == 0);
  check (x2 == 834815937);
  check (x3 == -0x1.b3ba978835edap+4);
  check (x4 == -2889622290121868931);
  check (strcmp(x5, "") == 0);
  check (strcmp(x6, "") == 0);
  check (x7 == 1658297061);
  check (x8 == -9153574820629202453);
  check (x9 == 1812846022029390968);
  check (x10 == -1251462846);
}

void f317(int x0, double x1, char * x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  int x5 = va_arg(l, int);
  double x6 = va_arg(l, double);
  va_end(l);
  check (x0 == 547226019);
  check (x1 == -0x1.7a446c0a64b3p+2);
  check (strcmp(x2, "al") == 0);
  check (x3 == -543784106517300044);
  check (x4 == 6901134813524877173);
  check (x5 == -38766804);
  check (x6 == -0x1.031cb2fd2459ep+5);
}

unsigned short f318(char * x0, int x1, int x2, long long x3, ...)
{
  va_list l;
  va_start(l, x3);
  char * x4 = va_arg(l, char *);
  char * x5 = va_arg(l, char *);
  double x6 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "t") == 0);
  check (x1 == 1769344242);
  check (x2 == 1635704816);
  check (x3 == -7803741436329943862);
  check (strcmp(x4, "l") == 0);
  check (strcmp(x5, "in") == 0);
  check (x6 == -0x1.84e2465fe8d32p+4);
  return -101970937;
}

void f319(double x0, long long x1, char * x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  double x4 = va_arg(l, double);
  char * x5 = va_arg(l, char *);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  int x9 = va_arg(l, int);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.18bc2350a218p-2);
  check (x1 == 2774735404388523627);
  check (strcmp(x2, "of") == 0);
  check (strcmp(x3, "k") == 0);
  check (x4 == -0x1.69c6cbb70f246p+4);
  check (strcmp(x5, "m") == 0);
  check (x6 == -389525730);
  check (x7 == 0x1.c0aeca5b42ea8p+3);
  check (x8 == -0x1.6357e3fb88abdp+4);
  check (x9 == 1407503431);
  check (x10 == 0x1.84f13c7040c6cp+5);
  check (x11 == 0x1.30fa87c663308p+4);
  check (x12 == -8904775086370790423);
}

unsigned short f320(double x0, char * x1, double x2, long long x3, long long x4, ...)
{
  va_list l;
  va_start(l, x4);
  double x5 = va_arg(l, double);
  long long x6 = va_arg(l, long long);
  char * x7 = va_arg(l, char *);
  double x8 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.e3e0111832528p+3);
  check (strcmp(x1, "") == 0);
  check (x2 == -0x1.492cae1592652p+5);
  check (x3 == 8706879762223533449);
  check (x4 == -6760091726060669588);
  check (x5 == 0x1.52b468d45fd8cp+3);
  check (x6 == 3681685589883336094);
  check (strcmp(x7, "") == 0);
  check (x8 == -0x1.9b91ae47e09cp+2);
  return 201407010;
}

void f321(long long x0, long long x1, char * x2, char * x3, long long x4, long long x5, long long x6, char * x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  char * x14 = va_arg(l, char *);
  char * x15 = va_arg(l, char *);
  long long x16 = va_arg(l, long long);
  long long x17 = va_arg(l, long long);
  va_end(l);
  check (x0 == -4950567851095398179);
  check (x1 == -5059543581525121931);
  check (strcmp(x2, "x") == 0);
  check (strcmp(x3, "hd") == 0);
  check (x4 == -7588035842918834892);
  check (x5 == -6816100002953717038);
  check (x6 == -4878717707357634315);
  check (strcmp(x7, "") == 0);
  check (x8 == -6964331653969348695);
  check (strcmp(x9, "w") == 0);
  check (x10 == -780173396);
  check (x11 == -133067726781169623);
  check (x12 == -0x1.1e97b78a83379p+5);
  check (x13 == 0x1.6840af5ff5bbep+5);
  check (strcmp(x14, "z") == 0);
  check (strcmp(x15, "") == 0);
  check (x16 == 6563803130227107814);
  check (x17 == -3435679631573555052);
}

double f322(char * x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  char * x2 = va_arg(l, char *);
  char * x3 = va_arg(l, char *);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "cz") == 0);
  check (x1 == -0x1.7ed757ad31736p+4);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "x") == 0);
  check (x4 == -0x1.45cdd47ac6fe4p+3);
  check (x5 == -0x1.301009a96e581p+5);
  return -0x1.75d3b6edc4c99p+4;
}

double f323(void)
{
  return -0x1.447e7ae0e125fp+4;
}

int f324(double x0, ...)
{
  va_list l;
  va_start(l, x0);
  char * x1 = va_arg(l, char *);
  char * x2 = va_arg(l, char *);
  long long x3 = va_arg(l, long long);
  double x4 = va_arg(l, double);
  char * x5 = va_arg(l, char *);
  long long x6 = va_arg(l, long long);
  int x7 = va_arg(l, int);
  char * x8 = va_arg(l, char *);
  int x9 = va_arg(l, int);
  long long x10 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.ce55f85745fbap+4);
  check (strcmp(x1, "fv") == 0);
  check (strcmp(x2, "") == 0);
  check (x3 == -1801134832682844197);
  check (x4 == -0x1.a77e815a44a4p+4);
  check (strcmp(x5, "my") == 0);
  check (x6 == 7543797139295504822);
  check (x7 == -13098737);
  check (strcmp(x8, "i") == 0);
  check (x9 == -2114490671);
  check (x10 == -7523845368020600293);
  return -1725395142;
}

void f325(float x0, int x1, float x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  int x13 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.5dda14p+5F);
  check (x1 == -1448341360);
  check (x2 == 0x1.44e2d8p+5F);
  check (strcmp(x3, "") == 0);
  check (x4 == 0x1.018b2466dcd94p+4);
  check (x5 == -0x1.75db7a090206cp+3);
  check (x6 == 0x1.53833705b786ep+5);
  check (x7 == -0x1.d0c2a3e4fd54cp+4);
  check (x8 == 1517898047);
  check (x9 == 0x1.6b733014cf05cp+4);
  check (x10 == 4045590874656630804);
  check (x11 == 1926312397026696236);
  check (strcmp(x12, "c") == 0);
  check (x13 == -526359235);
}

char * f326(float x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  char * x4 = va_arg(l, char *);
  int x5 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.e4e8d8p+1F);
  check (x1 == 447695550354088923);
  check (x2 == 632707567);
  check (x3 == -6587565192326759569);
  check (strcmp(x4, "") == 0);
  check (x5 == -1422892359);
  return "cb";
}

void f327(char * x0, float x1, int x2, char * x3, double x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  double x6 = va_arg(l, double);
  char * x7 = va_arg(l, char *);
  double x8 = va_arg(l, double);
  int x9 = va_arg(l, int);
  double x10 = va_arg(l, double);
  char * x11 = va_arg(l, char *);
  long long x12 = va_arg(l, long long);
  int x13 = va_arg(l, int);
  double x14 = va_arg(l, double);
  long long x15 = va_arg(l, long long);
  int x16 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 0x1.0220eap+2F);
  check (x2 == 802674590);
  check (strcmp(x3, "wg") == 0);
  check (x4 == 0x1.7520a49539356p+5);
  check (x5 == 0x1.3cc2978ea641p+4);
  check (x6 == 0x1.eccb304744b68p+2);
  check (strcmp(x7, "mf") == 0);
  check (x8 == -0x1.33e1070d58f71p+5);
  check (x9 == -1721523586);
  check (x10 == 0x1.244b22d013b0cp+5);
  check (strcmp(x11, "d") == 0);
  check (x12 == -4179595550387229823);
  check (x13 == 1649280346);
  check (x14 == 0x1.1e541463549f4p+5);
  check (x15 == -8135973523165024345);
  check (x16 == 1026926927);
}

void f328(long long x0, long long x1, int x2, char * x3, char * x4, float x5)
{
  check (x0 == -6940665796129561359);
  check (x1 == -1632080728290254324);
  check (x2 == -1915284138);
  check (strcmp(x3, "") == 0);
  check (strcmp(x4, "pw") == 0);
  check (x5 == -0x1.30d1f4p+5F);
}

short f329(void)
{
  return 523848807;
}

float f330(float x0, double x1, float x2, long long x3, long long x4, char * x5, long long x6, float x7)
{
  check (x0 == 0x1.46a2d2p+5F);
  check (x1 == 0x1.143d3726d358ep+5);
  check (x2 == 0x1.899e2p+5F);
  check (x3 == 4061965947723704342);
  check (x4 == -557035097313091816);
  check (strcmp(x5, "o") == 0);
  check (x6 == -6316212609333064407);
  check (x7 == 0x1.7f79eep+4F);
  return -0x1.0e197719b2e5fp+5;
}

void f331(float x0, double x1, long long x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  int x4 = va_arg(l, int);
  char * x5 = va_arg(l, char *);
  char * x6 = va_arg(l, char *);
  char * x7 = va_arg(l, char *);
  char * x8 = va_arg(l, char *);
  va_end(l);
  check (x0 == 0x1.04e8a6p+5F);
  check (x1 == -0x1.dcb35aeae477ap+4);
  check (x2 == 2811174495189676234);
  check (x3 == -3793123838630687984);
  check (x4 == 1351427010);
  check (strcmp(x5, "") == 0);
  check (strcmp(x6, "") == 0);
  check (strcmp(x7, "sn") == 0);
  check (strcmp(x8, "d") == 0);
}

void f332(double x0, int x1, int x2, long long x3, char * x4, int x5, double x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  double x8 = va_arg(l, double);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  long long x14 = va_arg(l, long long);
  int x15 = va_arg(l, int);
  double x16 = va_arg(l, double);
  int x17 = va_arg(l, int);
  long long x18 = va_arg(l, long long);
  int x19 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.352e1c4cbcd4ep+5);
  check (x1 == -240799484);
  check (x2 == 408815127);
  check (x3 == -8266241600563963339);
  check (strcmp(x4, "j") == 0);
  check (x5 == -1969894396);
  check (x6 == -0x1.e10e29867a48p-2);
  check (x7 == 2122866641);
  check (x8 == 0x1.eb3682ff509ep+4);
  check (x9 == 1328700006);
  check (x10 == -1723773860);
  check (x11 == 1302081103);
  check (x12 == 4087217794739298836);
  check (x13 == 6704474645156904863);
  check (x14 == 8957558363750598774);
  check (x15 == 201873732);
  check (x16 == 0x1.d3a25ac0893fp+2);
  check (x17 == 1947801495);
  check (x18 == -1091422502039343554);
  check (x19 == 1481263984);
}

void f333(void)
{
}

signed char f334(float x0)
{
  check (x0 == 0x1.4a00f8p+5F);
  return 435299177;
}

void f335(void)
{
}

signed char f336(float x0, char * x1, long long x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  double x8 = va_arg(l, double);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.765864p+3F);
  check (strcmp(x1, "") == 0);
  check (x2 == -3951152112832662524);
  check (strcmp(x3, "v") == 0);
  check (x4 == 1364360627);
  check (x5 == 0x1.efdbf7ec0f95p+2);
  check (strcmp(x6, "n") == 0);
  check (x7 == 4688722018086858146);
  check (x8 == -0x1.65113a47de99p+2);
  check (strcmp(x9, "wn") == 0);
  check (x10 == -6186335732350758366);
  check (x11 == -5957221583890933712);
  check (x12 == 0x1.0a0ff5a86dfeep+5);
  check (x13 == -0x1.eb73925f0c781p+4);
  return 456852764;
}

unsigned short f337(float x0, int x1, int x2, ...)
{
  va_list l;
  va_start(l, x2);
  double x3 = va_arg(l, double);
  double x4 = va_arg(l, double);
  long long x5 = va_arg(l, long long);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  char * x8 = va_arg(l, char *);
  long long x9 = va_arg(l, long long);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  char * x12 = va_arg(l, char *);
  va_end(l);
  check (x0 == 0x1.f95804p+4F);
  check (x1 == 383381210);
  check (x2 == -1867670715);
  check (x3 == 0x1.66b688b1236f8p+4);
  check (x4 == -0x1.1453c779ec93ep+4);
  check (x5 == 5172103878154495345);
  check (x6 == 85807667580961982);
  check (x7 == -0x1.69c53b22189fdp+4);
  check (strcmp(x8, "bu") == 0);
  check (x9 == 1703853116142916199);
  check (x10 == 0x1.bbe659fbc33ap+3);
  check (x11 == 0x1.d91fc7abffe64p+4);
  check (strcmp(x12, "") == 0);
  return -103703339;
}

double f338(char * x0, char * x1, char * x2, char * x3, int x4, char * x5, ...)
{
  va_list l;
  va_start(l, x5);
  char * x6 = va_arg(l, char *);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "") == 0);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "cp") == 0);
  check (x4 == 1709742282);
  check (strcmp(x5, "") == 0);
  check (strcmp(x6, "z") == 0);
  return 0x1.bf76125538a78p+2;
}

void f339(char * x0, double x1, char * x2, double x3, char * x4, char * x5, int x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  char * x8 = va_arg(l, char *);
  int x9 = va_arg(l, int);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  int x12 = va_arg(l, int);
  double x13 = va_arg(l, double);
  long long x14 = va_arg(l, long long);
  long long x15 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "u") == 0);
  check (x1 == 0x1.2206806b8a732p+5);
  check (strcmp(x2, "q") == 0);
  check (x3 == 0x1.fd146560b078cp+4);
  check (strcmp(x4, "") == 0);
  check (strcmp(x5, "j") == 0);
  check (x6 == -56011054);
  check (x7 == -4373959091616431264);
  check (strcmp(x8, "") == 0);
  check (x9 == -2021368604);
  check (x10 == 0x1.0d3ff6aa3aa9ep+5);
  check (x11 == 1049005904);
  check (x12 == 520645667);
  check (x13 == 0x1.151e7014af292p+5);
  check (x14 == -4520916292909034400);
  check (x15 == 6116188741433837355);
}

long long f340(float x0, float x1, int x2, char * x3, long long x4, int x5, char * x6, long long x7, double x8, float x9)
{
  check (x0 == 0x1.631c4cp+5F);
  check (x1 == 0x1.4f9b46p+2F);
  check (x2 == -602422128);
  check (strcmp(x3, "zv") == 0);
  check (x4 == -1108162089871436829);
  check (x5 == 1467150173);
  check (strcmp(x6, "w") == 0);
  check (x7 == -750980166474877259);
  check (x8 == 0x1.08ba6dca9c5ap+5);
  check (x9 == 0x1.4456c2p+5F);
  return -8341874066178998339;
}

void f341(char * x0, long long x1, int x2, float x3, float x4)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -4611087756606470939);
  check (x2 == -1389444925);
  check (x3 == 0x1.4c4368p+5F);
  check (x4 == -0x1.07dc5ep+5F);
}

long long f342(double x0, char * x1, int x2, ...)
{
  va_list l;
  va_start(l, x2);
  char * x3 = va_arg(l, char *);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.5657d9c819afep+5);
  check (strcmp(x1, "ea") == 0);
  check (x2 == -1911210377);
  check (strcmp(x3, "i") == 0);
  check (x4 == 397481054);
  check (x5 == -0x1.6c7bca4ab8b28p+5);
  check (x6 == 0x1.b77d49c2c301p+4);
  check (x7 == 0x1.3b0d79297b0bep+5);
  check (x8 == -6817759528235100378);
  return -7426741672165475965;
}

void f343(int x0, char * x1, float x2, char * x3, float x4, float x5, int x6, float x7)
{
  check (x0 == 180523198);
  check (strcmp(x1, "z") == 0);
  check (x2 == 0x1.490ed4p+5F);
  check (strcmp(x3, "rd") == 0);
  check (x4 == -0x1.729f3p+4F);
  check (x5 == -0x1.cf7392p+2F);
  check (x6 == -564770630);
  check (x7 == 0x1.e0214cp+4F);
}

unsigned char f344(long long x0, long long x1, int x2, char * x3, float x4, float x5)
{
  check (x0 == -8968000023492187537);
  check (x1 == 3219442348896526502);
  check (x2 == -389904367);
  check (strcmp(x3, "q") == 0);
  check (x4 == -0x1.30aecp+5F);
  check (x5 == 0x1.0cc2bcp+3F);
  return 479420122;
}

int f345(long long x0, long long x1, long long x2, char * x3, float x4)
{
  check (x0 == -7649725443728123747);
  check (x1 == 7910656067213300869);
  check (x2 == 7166397673402158031);
  check (strcmp(x3, "") == 0);
  check (x4 == 0x1.370196p+5F);
  return -309664137;
}

void f346(double x0, char * x1, int x2, long long x3, char * x4, char * x5, int x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.6598318b6b8fap+4);
  check (strcmp(x1, "h") == 0);
  check (x2 == 893864118);
  check (x3 == -4372952471077333114);
  check (strcmp(x4, "") == 0);
  check (strcmp(x5, "h") == 0);
  check (x6 == -1530338664);
  check (x7 == -9088936009987987223);
  check (x8 == -639424147);
  check (x9 == -2040643005);
  check (x10 == 3110366407399508454);
  check (strcmp(x11, "f") == 0);
}

void f347(long long x0, int x1, long long x2, ...)
{
  va_list l;
  va_start(l, x2);
  char * x3 = va_arg(l, char *);
  char * x4 = va_arg(l, char *);
  char * x5 = va_arg(l, char *);
  va_end(l);
  check (x0 == 7756954086193292355);
  check (x1 == 1800388071);
  check (x2 == -9171515906443593038);
  check (strcmp(x3, "ov") == 0);
  check (strcmp(x4, "yx") == 0);
  check (strcmp(x5, "") == 0);
}

double f348(long long x0, int x1, double x2, char * x3, float x4, double x5, int x6, char * x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  va_end(l);
  check (x0 == -3375239158681947824);
  check (x1 == 524313065);
  check (x2 == -0x1.1f1af3cec8c7p+4);
  check (strcmp(x3, "i") == 0);
  check (x4 == 0x1.54fd16p+5F);
  check (x5 == 0x1.12bf877b26a86p+5);
  check (x6 == 1936183670);
  check (strcmp(x7, "r") == 0);
  check (x8 == -1979321463189905076);
  check (strcmp(x9, "e") == 0);
  check (x10 == 1455566127);
  check (x11 == 1079210708);
  check (x12 == 0x1.0d97f76f89f18p+5);
  check (x13 == 0x1.1a4e7bc49998p+2);
  return 0x1.88904aa657adep+5;
}

signed char f349(char * x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  char * x3 = va_arg(l, char *);
  int x4 = va_arg(l, int);
  char * x5 = va_arg(l, char *);
  double x6 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "v") == 0);
  check (x1 == -0x1.a1ed32c0b268p-1);
  check (x2 == -0x1.5b0e5a5ad7f0bp+5);
  check (strcmp(x3, "x") == 0);
  check (x4 == -1578599436);
  check (strcmp(x5, "") == 0);
  check (x6 == 0x1.5f166c49650f8p+4);
  return -453612978;
}

long long f350(double x0, char * x1, double x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  int x6 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.1ff8222e1705cp+5);
  check (strcmp(x1, "c") == 0);
  check (x2 == -0x1.3eefdbc6467d1p+4);
  check (x3 == 6097632932126221279);
  check (x4 == -0x1.2603da5fbc78cp+3);
  check (x5 == -0x1.cadb3efdeb2acp+4);
  check (x6 == -369166610);
  return -4153376280086276203;
}

void f351(int x0, ...)
{
  va_list l;
  va_start(l, x0);
  double x1 = va_arg(l, double);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  char * x4 = va_arg(l, char *);
  char * x5 = va_arg(l, char *);
  char * x6 = va_arg(l, char *);
  char * x7 = va_arg(l, char *);
  int x8 = va_arg(l, int);
  va_end(l);
  check (x0 == -2060497350);
  check (x1 == 0x1.82e4ce627a2dcp+4);
  check (x2 == -1186306408);
  check (x3 == 1774898463929680753);
  check (strcmp(x4, "g") == 0);
  check (strcmp(x5, "pm") == 0);
  check (strcmp(x6, "") == 0);
  check (strcmp(x7, "a") == 0);
  check (x8 == 1193087540);
}

void f352(long long x0, double x1, long long x2, int x3, ...)
{
  va_list l;
  va_start(l, x3);
  long long x4 = va_arg(l, long long);
  va_end(l);
  check (x0 == -2819812719553000558);
  check (x1 == 0x1.5d33244b35c9cp+4);
  check (x2 == 2475336530287483154);
  check (x3 == 406326674);
  check (x4 == 1313469490707118699);
}

void f353(int x0, int x1, double x2, float x3, double x4, long long x5, float x6, float x7, double x8, float x9, long long x10, ...)
{
  va_list l;
  va_start(l, x10);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  long long x16 = va_arg(l, long long);
  va_end(l);
  check (x0 == -1119708459);
  check (x1 == -1634327276);
  check (x2 == 0x1.749da60d8f322p+5);
  check (x3 == 0x1.038a1cp+3F);
  check (x4 == -0x1.c73acc52ae5dbp+4);
  check (x5 == -7351408073255723591);
  check (x6 == -0x1.3b2a14p+3F);
  check (x7 == -0x1.486a54p+5F);
  check (x8 == 0x1.08b02fd5dd764p+4);
  check (x9 == -0x1.9c77e2p+3F);
  check (x10 == 3705418758406717489);
  check (x11 == 2081925174);
  check (x12 == -5321363941451550026);
  check (x13 == -467980341);
  check (x14 == 729275595);
  check (x15 == 1333747591);
  check (x16 == 5651593142186218488);
}

unsigned char f354(double x0, int x1, char * x2, long long x3, float x4, int x5, int x6, char * x7, int x8, ...)
{
  va_list l;
  va_start(l, x8);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.99994ab4da2e8p+3);
  check (x1 == 1961269057);
  check (strcmp(x2, "") == 0);
  check (x3 == 8653310565015019493);
  check (x4 == 0x1.331d22p+4F);
  check (x5 == 1068426168);
  check (x6 == 1147229647);
  check (strcmp(x7, "cg") == 0);
  check (x8 == 207835852);
  check (x9 == -937802677);
  check (x10 == -1347782403);
  check (x11 == 3171625199926625229);
  return -434958245;
}

void f355(float x0, char * x1, float x2, int x3, int x4, ...)
{
  va_list l;
  va_start(l, x4);
  int x5 = va_arg(l, int);
  double x6 = va_arg(l, double);
  long long x7 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.7951c8p+2F);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.6b34ep+5F);
  check (x3 == 1972889107);
  check (x4 == -407004843);
  check (x5 == -762650224);
  check (x6 == 0x1.ac520bfc00f5p+4);
  check (x7 == -723372812131976737);
}

void f356(char * x0, int x1, double x2, float x3, double x4, int x5, double x6, char * x7, long long x8, char * x9, int x10, ...)
{
  va_list l;
  va_start(l, x10);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  int x13 = va_arg(l, int);
  double x14 = va_arg(l, double);
  int x15 = va_arg(l, int);
  long long x16 = va_arg(l, long long);
  long long x17 = va_arg(l, long long);
  double x18 = va_arg(l, double);
  int x19 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "p") == 0);
  check (x1 == -1469795892);
  check (x2 == -0x1.3673b06c37a2cp+5);
  check (x3 == -0x1.aa8b9p+4F);
  check (x4 == -0x1.9e604e3508c08p+4);
  check (x5 == 608138053);
  check (x6 == 0x1.7b3d9b37ae338p+4);
  check (strcmp(x7, "jk") == 0);
  check (x8 == -1200846830601239226);
  check (strcmp(x9, "") == 0);
  check (x10 == 336471127);
  check (x11 == 0x1.6df122a65e8aap+5);
  check (x12 == -0x1.3b3ff5c945101p+5);
  check (x13 == 588089471);
  check (x14 == -0x1.852b0745c3b17p+5);
  check (x15 == 125895612);
  check (x16 == 4512699241279415353);
  check (x17 == 8964225839131482500);
  check (x18 == 0x1.90c2dca287a98p+3);
  check (x19 == 1968860061);
}

unsigned char f357(char * x0, int x1, double x2, int x3, int x4, double x5, double x6, double x7, double x8, int x9, int x10, ...)
{
  va_list l;
  va_start(l, x10);
  int x11 = va_arg(l, int);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  char * x15 = va_arg(l, char *);
  char * x16 = va_arg(l, char *);
  char * x17 = va_arg(l, char *);
  char * x18 = va_arg(l, char *);
  int x19 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == -107296598);
  check (x2 == -0x1.b56806e13f6b4p+4);
  check (x3 == -223257523);
  check (x4 == 955806436);
  check (x5 == 0x1.b8769166a8be8p+2);
  check (x6 == -0x1.ff781b735c6ep+2);
  check (x7 == 0x1.563652d9329cep+5);
  check (x8 == 0x1.81e3aa565c5d2p+5);
  check (x9 == 1679385774);
  check (x10 == 859744905);
  check (x11 == -630277354);
  check (x12 == -2011785399);
  check (x13 == -287681752);
  check (x14 == 129736644);
  check (strcmp(x15, "d") == 0);
  check (strcmp(x16, "") == 0);
  check (strcmp(x17, "r") == 0);
  check (strcmp(x18, "") == 0);
  check (x19 == 1390465477);
  return -376374460;
}

int f358(double x0, double x1, char * x2, ...)
{
  va_list l;
  va_start(l, x2);
  double x3 = va_arg(l, double);
  char * x4 = va_arg(l, char *);
  int x5 = va_arg(l, int);
  double x6 = va_arg(l, double);
  char * x7 = va_arg(l, char *);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  char * x10 = va_arg(l, char *);
  int x11 = va_arg(l, int);
  char * x12 = va_arg(l, char *);
  double x13 = va_arg(l, double);
  double x14 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.a839da6cdbfp+0);
  check (x1 == -0x1.51cb454282aep+1);
  check (strcmp(x2, "a") == 0);
  check (x3 == -0x1.08fd68dc196d8p+2);
  check (strcmp(x4, "h") == 0);
  check (x5 == -1970004248);
  check (x6 == -0x1.0fdcd62a44f78p+5);
  check (strcmp(x7, "") == 0);
  check (x8 == 0x1.30c26d4e47a8ap+5);
  check (x9 == -0x1.b222a794p-9);
  check (strcmp(x10, "") == 0);
  check (x11 == -1442407926);
  check (strcmp(x12, "z") == 0);
  check (x13 == -0x1.5b19aaf293c61p+4);
  check (x14 == 0x1.879038c73852p+5);
  return -1207689981;
}

void f359(float x0, double x1, int x2, double x3, char * x4, char * x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  char * x7 = va_arg(l, char *);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.21f9a6p+3F);
  check (x1 == -0x1.276ba881f7f5fp+4);
  check (x2 == 1473532388);
  check (x3 == -0x1.fde04c778e188p+3);
  check (strcmp(x4, "n") == 0);
  check (strcmp(x5, "qg") == 0);
  check (x6 == -1091520624);
  check (strcmp(x7, "un") == 0);
  check (x8 == -6593823468793108761);
  check (x9 == -8319434273037475647);
  check (x10 == -4377699855107254355);
  check (x11 == -0x1.b18586198f1cp+3);
}

void f360(int x0, int x1, int x2, long long x3, char * x4, double x5, long long x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  va_end(l);
  check (x0 == 1109400404);
  check (x1 == -1292826199);
  check (x2 == 1265586749);
  check (x3 == -8806130752219285635);
  check (strcmp(x4, "ky") == 0);
  check (x5 == -0x1.650425bf5f845p+4);
  check (x6 == 7424528221564074095);
  check (x7 == -6451539246473953774);
}

double f361(void)
{
  return -0x1.e4920dcebbf84p+3;
}

void f362(float x0, long long x1, double x2, char * x3, float x4, double x5, char * x6, float x7, long long x8, double x9, ...)
{
  va_list l;
  va_start(l, x9);
  long long x10 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.e000b2p+4F);
  check (x1 == -4576235592882585200);
  check (x2 == 0x1.559f168090cc4p+5);
  check (strcmp(x3, "hj") == 0);
  check (x4 == -0x1.3dcf92p+3F);
  check (x5 == -0x1.cd2613ff77a6p+3);
  check (strcmp(x6, "p") == 0);
  check (x7 == 0x1.f743aep+4F);
  check (x8 == -7435255772518939288);
  check (x9 == 0x1.2fc2468817c5p+1);
  check (x10 == 7976546144779592719);
}

void f363(long long x0, ...)
{
  va_list l;
  va_start(l, x0);
  long long x1 = va_arg(l, long long);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  double x4 = va_arg(l, double);
  char * x5 = va_arg(l, char *);
  long long x6 = va_arg(l, long long);
  int x7 = va_arg(l, int);
  double x8 = va_arg(l, double);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  double x12 = va_arg(l, double);
  va_end(l);
  check (x0 == -8663473761702795351);
  check (x1 == 8498306888377686161);
  check (x2 == 737003175200675000);
  check (x3 == -21848868);
  check (x4 == -0x1.24d2769ab4b6dp+5);
  check (strcmp(x5, "") == 0);
  check (x6 == 22466210159888190);
  check (x7 == -620719562);
  check (x8 == -0x1.04cac1a01c298p+3);
  check (strcmp(x9, "r") == 0);
  check (x10 == -2615567019503550213);
  check (strcmp(x11, "j") == 0);
  check (x12 == -0x1.464e591e96a4p+0);
}

int f364(double x0, ...)
{
  va_list l;
  va_start(l, x0);
  long long x1 = va_arg(l, long long);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  double x4 = va_arg(l, double);
  long long x5 = va_arg(l, long long);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  char * x9 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.33c812f7bd597p+4);
  check (x1 == 7059211044464324586);
  check (x2 == 1033331163);
  check (x3 == -6931573106523872878);
  check (x4 == 0x1.241d7b78755dp+3);
  check (x5 == -5236841679094552310);
  check (strcmp(x6, "u") == 0);
  check (x7 == 4196838064703872957);
  check (x8 == 2012052911);
  check (strcmp(x9, "") == 0);
  return 100560592;
}

unsigned char f365(char * x0, float x1, double x2, float x3, float x4, int x5, long long x6, double x7, long long x8, int x9, char * x10, ...)
{
  va_list l;
  va_start(l, x10);
  long long x11 = va_arg(l, long long);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  char * x14 = va_arg(l, char *);
  long long x15 = va_arg(l, long long);
  double x16 = va_arg(l, double);
  long long x17 = va_arg(l, long long);
  double x18 = va_arg(l, double);
  double x19 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "g") == 0);
  check (x1 == 0x1.78e956p+3F);
  check (x2 == 0x1.baaae777f6bbp+4);
  check (x3 == 0x1.5dfd26p+5F);
  check (x4 == -0x1.e5c05ep+4F);
  check (x5 == 32185187);
  check (x6 == -9161435729913337620);
  check (x7 == -0x1.fa7dd2b5556ffp+4);
  check (x8 == 7063664142852668450);
  check (x9 == -895519100);
  check (strcmp(x10, "a") == 0);
  check (x11 == 580018140019724310);
  check (x12 == -1166944723524206980);
  check (x13 == 4616959893582439494);
  check (strcmp(x14, "") == 0);
  check (x15 == 9154944956101257854);
  check (x16 == 0x1.d4113e1e531bp+4);
  check (x17 == -5890645907586717083);
  check (x18 == -0x1.4e86bb188d818p+2);
  check (x19 == -0x1.a93e81e7148fap+4);
  return -224755341;
}

unsigned char f366(char * x0, long long x1, char * x2, float x3, double x4, int x5, int x6, long long x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == -3492633014075569093);
  check (strcmp(x2, "g") == 0);
  check (x3 == -0x1.54b3d4p+5F);
  check (x4 == -0x1.e0a7b8ddd882p+0);
  check (x5 == -1554918273);
  check (x6 == 1845038999);
  check (x7 == 9029433016740392999);
  check (x8 == 6734700838120378808);
  check (x9 == 6688915047703768885);
  check (x10 == -9120864394201672087);
  check (x11 == 1624890013460032996);
  check (x12 == -1215832813);
  return -80667424;
}

void f367(float x0, long long x1, char * x2, double x3, long long x4, int x5, float x6, float x7, double x8, long long x9, ...)
{
  va_list l;
  va_start(l, x9);
  long long x10 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.ccb46ep+4F);
  check (x1 == -4843063910624717224);
  check (strcmp(x2, "g") == 0);
  check (x3 == 0x1.9ea1714fb0028p+3);
  check (x4 == 5962134697647837027);
  check (x5 == 2093027558);
  check (x6 == 0x1.4f6ep+5F);
  check (x7 == 0x1.412c96p+5F);
  check (x8 == 0x1.c044749e28738p+4);
  check (x9 == 1464030997663272324);
  check (x10 == 6498515806313722936);
}

short f368(float x0, float x1, float x2, int x3, int x4, ...)
{
  va_list l;
  va_start(l, x4);
  double x5 = va_arg(l, double);
  int x6 = va_arg(l, int);
  char * x7 = va_arg(l, char *);
  long long x8 = va_arg(l, long long);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.1dcb4ep+5F);
  check (x1 == 0x1.68e35ap+3F);
  check (x2 == -0x1.7d75fp+4F);
  check (x3 == 1832068716);
  check (x4 == 1414333806);
  check (x5 == 0x1.19dcab16d6f4p-1);
  check (x6 == -801280794);
  check (strcmp(x7, "n") == 0);
  check (x8 == -2658729342230005676);
  check (x9 == -0x1.89eec189b0cf8p+2);
  check (x10 == 0x1.6704af021bc98p+4);
  return -216134684;
}

short f369(void)
{
  return -254302233;
}

unsigned char f370(long long x0, float x1, long long x2, long long x3, char * x4, ...)
{
  va_list l;
  va_start(l, x4);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  va_end(l);
  check (x0 == -944362741595812964);
  check (x1 == 0x1.afaee6p+3F);
  check (x2 == 1574143057351108963);
  check (x3 == 3335050325075631784);
  check (strcmp(x4, "") == 0);
  check (x5 == 0x1.db58e6364cd8p+1);
  check (strcmp(x6, "") == 0);
  check (x7 == 0x1.3e6cc8f773022p+5);
  check (x8 == 5216998835748368271);
  check (strcmp(x9, "jl") == 0);
  check (x10 == 0x1.6136009ec01bp+3);
  return -150201716;
}

int f371(int x0, float x1, double x2, int x3, ...)
{
  va_list l;
  va_start(l, x3);
  char * x4 = va_arg(l, char *);
  va_end(l);
  check (x0 == 1944304611);
  check (x1 == 0x1.069398p+2F);
  check (x2 == 0x1.46d546618c87p+2);
  check (x3 == 2033299863);
  check (strcmp(x4, "g") == 0);
  return -317740801;
}

void f372(double x0, char * x1, double x2, float x3, double x4, float x5, int x6, float x7, double x8, double x9, float x10)
{
  check (x0 == 0x1.5d822d4298128p+4);
  check (strcmp(x1, "dr") == 0);
  check (x2 == -0x1.5f86b8d464d36p+4);
  check (x3 == -0x1.450334p+4F);
  check (x4 == 0x1.3924c11c86a92p+5);
  check (x5 == -0x1.25f958p+4F);
  check (x6 == -1336269231);
  check (x7 == 0x1.276b2ap+5F);
  check (x8 == -0x1.efbaa283ec428p+2);
  check (x9 == 0x1.8933edc72242p+5);
  check (x10 == -0x1.9b73a6p+4F);
}

float f373(int x0, char * x1, long long x2, double x3, char * x4, int x5, float x6, double x7, int x8, char * x9, ...)
{
  va_list l;
  va_start(l, x9);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  double x13 = va_arg(l, double);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  long long x16 = va_arg(l, long long);
  double x17 = va_arg(l, double);
  va_end(l);
  check (x0 == -1010136654);
  check (strcmp(x1, "i") == 0);
  check (x2 == 9107488858019508811);
  check (x3 == 0x1.4a7b9d9fc1bbep+5);
  check (strcmp(x4, "m") == 0);
  check (x5 == -1506362094);
  check (x6 == 0x1.3e41bep+5F);
  check (x7 == -0x1.ac53a9c931ap-3);
  check (x8 == -241548268);
  check (strcmp(x9, "t") == 0);
  check (x10 == -323556221);
  check (x11 == -689174823);
  check (x12 == -6066767570770547574);
  check (x13 == 0x1.55d6d09dfd5c8p+5);
  check (x14 == -1278130497);
  check (x15 == 8512486047544567155);
  check (x16 == -5937815654893097537);
  check (x17 == -0x1.3b365d394f227p+5);
  return 0x1.7c2daca90a574p+5;
}

int f374(float x0, long long x1, double x2, char * x3, char * x4, float x5, int x6, char * x7, int x8, ...)
{
  va_list l;
  va_start(l, x8);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.5e1b1ap+4F);
  check (x1 == -3949805547158131547);
  check (x2 == -0x1.918fdd689ed3ep+4);
  check (strcmp(x3, "w") == 0);
  check (strcmp(x4, "ti") == 0);
  check (x5 == 0x1.03a5f8p+3F);
  check (x6 == -1176590888);
  check (strcmp(x7, "qk") == 0);
  check (x8 == -789737033);
  check (x9 == -0x1.784cbb0c079ccp+5);
  check (x10 == 2617571236008726468);
  check (x11 == 3094772161977548988);
  return -82559121;
}

void f375(double x0, float x1, float x2, char * x3, char * x4, ...)
{
  va_list l;
  va_start(l, x4);
  int x5 = va_arg(l, int);
  double x6 = va_arg(l, double);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  long long x14 = va_arg(l, long long);
  int x15 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.45c4b4e2eb09p+5);
  check (x1 == 0x1.8256aep+2F);
  check (x2 == 0x1.6ba694p+4F);
  check (strcmp(x3, "g") == 0);
  check (strcmp(x4, "") == 0);
  check (x5 == -1022199127);
  check (x6 == 0x1.6a24571126d4cp+5);
  check (x7 == -1010640638552937041);
  check (x8 == 1464883694);
  check (x9 == -0x1.dcddd634a914p+2);
  check (x10 == -0x1.55804bae1ac68p+2);
  check (x11 == 1847171628);
  check (x12 == 6361247729289883731);
  check (x13 == -1671848029991763941);
  check (x14 == 1125257737926285353);
  check (x15 == -1725304373);
}

unsigned short f376(char * x0, ...)
{
  va_list l;
  va_start(l, x0);
  double x1 = va_arg(l, double);
  double x2 = va_arg(l, double);
  char * x3 = va_arg(l, char *);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "c") == 0);
  check (x1 == 0x1.6b10e3c297328p+4);
  check (x2 == -0x1.24d11ce7d70d4p+4);
  check (strcmp(x3, "im") == 0);
  check (x4 == -2981137155106111235);
  check (x5 == -8010121281505465952);
  return -462206849;
}

void f377(int x0, ...)
{
  va_list l;
  va_start(l, x0);
  char * x1 = va_arg(l, char *);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  char * x4 = va_arg(l, char *);
  char * x5 = va_arg(l, char *);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  char * x8 = va_arg(l, char *);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  double x12 = va_arg(l, double);
  va_end(l);
  check (x0 == -704442052);
  check (strcmp(x1, "z") == 0);
  check (x2 == 8731365765365840067);
  check (x3 == 1964565802);
  check (strcmp(x4, "") == 0);
  check (strcmp(x5, "") == 0);
  check (x6 == 478365264);
  check (x7 == -610676158);
  check (strcmp(x8, "bw") == 0);
  check (x9 == 0x1.f092e1d278318p+4);
  check (x10 == 0x1.836fe3d995228p+2);
  check (x11 == 992675679);
  check (x12 == -0x1.e17d62f9ac23ap+4);
}

void f378(int x0, char * x1, int x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  va_end(l);
  check (x0 == 116623881);
  check (strcmp(x1, "u") == 0);
  check (x2 == -187353554);
  check (x3 == 7073899786640683007);
}

float f379(int x0, char * x1, double x2, int x3, char * x4, char * x5, double x6, ...)
{
  va_list l;
  va_start(l, x6);
  int x7 = va_arg(l, int);
  double x8 = va_arg(l, double);
  int x9 = va_arg(l, int);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  char * x12 = va_arg(l, char *);
  va_end(l);
  check (x0 == 1921517955);
  check (strcmp(x1, "") == 0);
  check (x2 == -0x1.58c75f93a817cp+5);
  check (x3 == -939711679);
  check (strcmp(x4, "w") == 0);
  check (strcmp(x5, "") == 0);
  check (x6 == -0x1.745cae7e4a505p+5);
  check (x7 == 259085891);
  check (x8 == 0x1.3b4b5727bc8b4p+4);
  check (x9 == 328785319);
  check (x10 == -3821877283951913704);
  check (x11 == -0x1.8ca90bbe9576p+5);
  check (strcmp(x12, "kz") == 0);
  return -0x1.7e1ae8fde5a5dp+5;
}

void f380(double x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  int x4 = va_arg(l, int);
  int x5 = va_arg(l, int);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  char * x8 = va_arg(l, char *);
  int x9 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.1c4b4817f05ap+4);
  check (x1 == 3036427163715274546);
  check (x2 == -1002588527);
  check (x3 == 1809537267049705509);
  check (x4 == 446998178);
  check (x5 == 1552500687);
  check (x6 == 4282222278791749913);
  check (x7 == 6746221720864541908);
  check (strcmp(x8, "r") == 0);
  check (x9 == -891888198);
}

unsigned char f381(char * x0, int x1, char * x2, char * x3, int x4, float x5, char * x6, int x7, long long x8, int x9, ...)
{
  va_list l;
  va_start(l, x9);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  int x16 = va_arg(l, int);
  long long x17 = va_arg(l, long long);
  char * x18 = va_arg(l, char *);
  double x19 = va_arg(l, double);
  char * x20 = va_arg(l, char *);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 1602489521);
  check (strcmp(x2, "ir") == 0);
  check (strcmp(x3, "a") == 0);
  check (x4 == -1217748184);
  check (x5 == 0x1.3c933ap+5F);
  check (strcmp(x6, "") == 0);
  check (x7 == -1338976697);
  check (x8 == -743013630108157970);
  check (x9 == -332924421);
  check (x10 == -1923670909);
  check (x11 == 2006366440);
  check (x12 == 1787610733);
  check (x13 == -894355467);
  check (x14 == -174619683);
  check (x15 == -3882802053915483094);
  check (x16 == -633828158);
  check (x17 == 8945034274489066713);
  check (strcmp(x18, "x") == 0);
  check (x19 == 0x1.acedd28940b7p+3);
  check (strcmp(x20, "") == 0);
  return -170441857;
}

char * f382(long long x0, char * x1, float x2)
{
  check (x0 == -2848537325273698262);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.b76c1p+4F);
  return "vl";
}

void f383(char * x0, long long x1, char * x2, float x3, double x4, ...)
{
  va_list l;
  va_start(l, x4);
  char * x5 = va_arg(l, char *);
  double x6 = va_arg(l, double);
  char * x7 = va_arg(l, char *);
  char * x8 = va_arg(l, char *);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  char * x11 = va_arg(l, char *);
  va_end(l);
  check (strcmp(x0, "vf") == 0);
  check (x1 == -88950668625353680);
  check (strcmp(x2, "") == 0);
  check (x3 == 0x1.3a2ab6p+4F);
  check (x4 == -0x1.0bebd302951b2p+5);
  check (strcmp(x5, "f") == 0);
  check (x6 == 0x1.07843cc2095fp+2);
  check (strcmp(x7, "tf") == 0);
  check (strcmp(x8, "c") == 0);
  check (strcmp(x9, "m") == 0);
  check (x10 == -0x1.23b885dd3d6d3p+5);
  check (strcmp(x11, "lk") == 0);
}

signed char f384(int x0, int x1, double x2, char * x3, float x4)
{
  check (x0 == 1134629599);
  check (x1 == -1446161495);
  check (x2 == -0x1.85964eaa80d14p+5);
  check (strcmp(x3, "qv") == 0);
  check (x4 == -0x1.26a4bcp+5F);
  return -386701964;
}

int f385(int x0, int x1, double x2, char * x3, int x4, int x5, int x6, ...)
{
  va_list l;
  va_start(l, x6);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  va_end(l);
  check (x0 == -820310325);
  check (x1 == -576007657);
  check (x2 == -0x1.e911c6faff0b5p+4);
  check (strcmp(x3, "s") == 0);
  check (x4 == -929406143);
  check (x5 == 1234641885);
  check (x6 == -858284875);
  check (x7 == -1743297679);
  check (x8 == -154973873);
  check (x9 == 0x1.88d4bd7088a36p+5);
  check (x10 == 0x1.9027bded7b22p+1);
  check (x11 == -8848833330105723885);
  check (strcmp(x12, "") == 0);
  return 255611144;
}

void f386(long long x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  va_end(l);
  check (x0 == 268739485640921195);
  check (x1 == 1815164000);
  check (x2 == 0x1.570689284b054p+5);
  check (x3 == 1723009720);
  check (x4 == -295376919);
  check (x5 == 0x1.2700c94d996ecp+5);
  check (x6 == -0x1.3510739ae3fbcp+5);
}

void f387(int x0, char * x1, int x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  va_end(l);
  check (x0 == -1147446936);
  check (strcmp(x1, "b") == 0);
  check (x2 == 190865201);
  check (x3 == -8008939739774508569);
  check (x4 == -6692154369532895499);
}

void f388(long long x0, long long x1, double x2, int x3, double x4, float x5)
{
  check (x0 == -3404794411596171317);
  check (x1 == 5277431011697174596);
  check (x2 == -0x1.91f4574c2a5ep+2);
  check (x3 == 504924269);
  check (x4 == 0x1.32b4db30d8b08p+4);
  check (x5 == -0x1.8b479ap+4F);
}

void f389(char * x0, double x1, char * x2, int x3, char * x4, int x5, int x6, int x7, char * x8, float x9)
{
  check (strcmp(x0, "rw") == 0);
  check (x1 == -0x1.12f050ba093f9p+5);
  check (strcmp(x2, "zo") == 0);
  check (x3 == -1700333435);
  check (strcmp(x4, "bv") == 0);
  check (x5 == 695789473);
  check (x6 == 799984527);
  check (x7 == -1221411307);
  check (strcmp(x8, "d") == 0);
  check (x9 == -0x1.ee09a4p+4F);
}

void f390(double x0, ...)
{
  va_list l;
  va_start(l, x0);
  double x1 = va_arg(l, double);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  double x4 = va_arg(l, double);
  char * x5 = va_arg(l, char *);
  double x6 = va_arg(l, double);
  long long x7 = va_arg(l, long long);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.76002d4cdb08ap+5);
  check (x1 == -0x1.caaea76497e7p+3);
  check (x2 == -12893873);
  check (x3 == -1710630261071329401);
  check (x4 == 0x1.22ff073b96f8p+5);
  check (strcmp(x5, "w") == 0);
  check (x6 == 0x1.885cc18daf514p+3);
  check (x7 == 3347234072170776746);
  check (x8 == 0x1.96538d83fb358p+2);
  check (x9 == 7818653364717693676);
  check (strcmp(x10, "un") == 0);
  check (x11 == -0x1.5a37159b98746p+5);
}

void f391(long long x0, char * x1, float x2, int x3, float x4, int x5, long long x6, char * x7, ...)
{
  va_list l;
  va_start(l, x7);
  char * x8 = va_arg(l, char *);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  long long x12 = va_arg(l, long long);
  double x13 = va_arg(l, double);
  va_end(l);
  check (x0 == -6688772897249871268);
  check (strcmp(x1, "") == 0);
  check (x2 == -0x1.00f38ep+4F);
  check (x3 == -1657564931);
  check (x4 == -0x1.f714dep+3F);
  check (x5 == -2044490375);
  check (x6 == 2794558176664611757);
  check (strcmp(x7, "b") == 0);
  check (strcmp(x8, "s") == 0);
  check (x9 == 4714658141453493963);
  check (x10 == -8352307048362164498);
  check (strcmp(x11, "i") == 0);
  check (x12 == -8315637634303422099);
  check (x13 == -0x1.7868d2643e162p+5);
}

float f392(float x0)
{
  check (x0 == 0x1.c92a82p+4F);
  return -0x1.7841f95ba2bc9p+5;
}

void f393(char * x0, float x1, float x2, double x3, int x4, double x5, double x6, float x7)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -0x1.46fd02p+3F);
  check (x2 == -0x1.72d048p+3F);
  check (x3 == 0x1.cccee482b4a94p+4);
  check (x4 == 240331771);
  check (x5 == -0x1.ef145afe73b18p+4);
  check (x6 == -0x1.6c87d1485c9ap+0);
  check (x7 == 0x1.fcc3p+4F);
}

int f394(char * x0, ...)
{
  va_list l;
  va_start(l, x0);
  char * x1 = va_arg(l, char *);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  char * x4 = va_arg(l, char *);
  long long x5 = va_arg(l, long long);
  char * x6 = va_arg(l, char *);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "v") == 0);
  check (strcmp(x1, "k") == 0);
  check (x2 == -3245300792685634058);
  check (x3 == -0x1.81d3a745f0e67p+5);
  check (strcmp(x4, "ab") == 0);
  check (x5 == -2625964743875037455);
  check (strcmp(x6, "ac") == 0);
  check (x7 == -0x1.70ca33972b08bp+4);
  check (x8 == 922433656);
  return -1554834830;
}

long long f395(char * x0, char * x1, int x2, ...)
{
  va_list l;
  va_start(l, x2);
  char * x3 = va_arg(l, char *);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "ms") == 0);
  check (strcmp(x1, "dy") == 0);
  check (x2 == 1765079969);
  check (strcmp(x3, "ga") == 0);
  check (x4 == -5578757459018333728);
  check (x5 == 6594643821592793736);
  check (strcmp(x6, "") == 0);
  check (x7 == 6646112187922931332);
  return -8537975113634276278;
}

signed char f396(int x0, long long x1, int x2, float x3)
{
  check (x0 == 286985400);
  check (x1 == -7311387266251951454);
  check (x2 == 1914336000);
  check (x3 == 0x1.034944p+2F);
  return 486973467;
}

int f397(long long x0, double x1, long long x2, long long x3, long long x4, long long x5, long long x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  char * x8 = va_arg(l, char *);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  char * x12 = va_arg(l, char *);
  long long x13 = va_arg(l, long long);
  va_end(l);
  check (x0 == 3728894804269904562);
  check (x1 == 0x1.017eb292f2c2ep+5);
  check (x2 == 5172531724684815032);
  check (x3 == -5886119806245789581);
  check (x4 == -3975978435453692483);
  check (x5 == -1171951691120871960);
  check (x6 == 9101510710040093231);
  check (x7 == 4360226038102736322);
  check (strcmp(x8, "aw") == 0);
  check (x9 == -0x1.080307fa1a09dp+5);
  check (x10 == -0x1.977d47fd6ee6p+1);
  check (x11 == -7012070);
  check (strcmp(x12, "") == 0);
  check (x13 == -4670222011351350073);
  return 1766675382;
}

void f398(float x0, int x1, char * x2, char * x3, long long x4, int x5, ...)
{
  va_list l;
  va_start(l, x5);
  double x6 = va_arg(l, double);
  int x7 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.1a895cp+4F);
  check (x1 == 1940735987);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "") == 0);
  check (x4 == 7822038628949301765);
  check (x5 == -2024322641);
  check (x6 == -0x1.1bf681fa9c002p+5);
  check (x7 == 1137144881);
}

unsigned char f399(float x0, char * x1, long long x2, int x3, double x4, char * x5, int x6, float x7, int x8, int x9, long long x10, ...)
{
  va_list l;
  va_start(l, x10);
  long long x11 = va_arg(l, long long);
  long long x12 = va_arg(l, long long);
  double x13 = va_arg(l, double);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  long long x16 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.7590c2p+4F);
  check (strcmp(x1, "h") == 0);
  check (x2 == -8673330767513305233);
  check (x3 == 1828710623);
  check (x4 == 0x1.f90b50c8c5f88p+4);
  check (strcmp(x5, "sx") == 0);
  check (x6 == -1920137004);
  check (x7 == -0x1.44686p+1F);
  check (x8 == -599413244);
  check (x9 == 1192910252);
  check (x10 == -5786314609602176423);
  check (x11 == -1934655404110490421);
  check (x12 == 247864091886248731);
  check (x13 == 0x1.108564b6bdb62p+5);
  check (x14 == 301701767);
  check (x15 == -2040193165);
  check (x16 == -6556225824940071541);
  return -36173321;
}

void f400(int x0, int x1, long long x2, float x3)
{
  check (x0 == -312296630);
  check (x1 == 2125117404);
  check (x2 == -536831817437974351);
  check (x3 == 0x1.53817p+5F);
}

unsigned char f401(void)
{
  return 305278492;
}

unsigned char f402(int x0, int x1, long long x2, char * x3, double x4, long long x5, char * x6, long long x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  char * x9 = va_arg(l, char *);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  double x13 = va_arg(l, double);
  va_end(l);
  check (x0 == -1117448805);
  check (x1 == 1397070986);
  check (x2 == -7881822047712719609);
  check (strcmp(x3, "") == 0);
  check (x4 == 0x1.473ced07cbbbep+5);
  check (x5 == -4206278730199123265);
  check (strcmp(x6, "") == 0);
  check (x7 == -4700396064497104481);
  check (x8 == -6723967974166959776);
  check (strcmp(x9, "oo") == 0);
  check (strcmp(x10, "e") == 0);
  check (x11 == 0x1.2457347360624p+4);
  check (x12 == -6363051988768385215);
  check (x13 == -0x1.58c562652e5c8p+2);
  return 411969728;
}

void f403(double x0, long long x1, long long x2, float x3, double x4, float x5, double x6, float x7)
{
  check (x0 == -0x1.53fb08c59ab15p+5);
  check (x1 == -2142606025796945929);
  check (x2 == 8893401622320059937);
  check (x3 == -0x1.1900f6p+3F);
  check (x4 == 0x1.80c614fabfa78p+3);
  check (x5 == -0x1.c9085ap+4F);
  check (x6 == -0x1.c0e01fa3127d8p+3);
  check (x7 == 0x1.cada46p+2F);
}

void f404(long long x0, float x1, float x2, float x3, long long x4, double x5, int x6, ...)
{
  va_list l;
  va_start(l, x6);
  char * x7 = va_arg(l, char *);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  va_end(l);
  check (x0 == 5869225607872425770);
  check (x1 == -0x1.aad512p+4F);
  check (x2 == 0x1.12165cp+4F);
  check (x3 == 0x1.3a7eaap+5F);
  check (x4 == 3191783427267381895);
  check (x5 == -0x1.1dc3c004464ccp+5);
  check (x6 == 340338545);
  check (strcmp(x7, "") == 0);
  check (x8 == 0x1.63fc41b194fa6p+5);
  check (x9 == -0x1.2b1dcb363dcep+5);
  check (x10 == -1338691100);
}

void f405(int x0, long long x1, int x2, float x3, long long x4, long long x5, char * x6, double x7, int x8, double x9, double x10, ...)
{
  va_list l;
  va_start(l, x10);
  long long x11 = va_arg(l, long long);
  long long x12 = va_arg(l, long long);
  char * x13 = va_arg(l, char *);
  long long x14 = va_arg(l, long long);
  double x15 = va_arg(l, double);
  long long x16 = va_arg(l, long long);
  long long x17 = va_arg(l, long long);
  va_end(l);
  check (x0 == 1491784699);
  check (x1 == 9117494913531589820);
  check (x2 == 276042693);
  check (x3 == 0x1.6d8a14p+4F);
  check (x4 == 5947540972798742221);
  check (x5 == 623533150851825794);
  check (strcmp(x6, "jk") == 0);
  check (x7 == -0x1.4ca6adab44d8cp+3);
  check (x8 == 1263831186);
  check (x9 == -0x1.5e0333d37054ap+4);
  check (x10 == -0x1.8cfacca02f034p+4);
  check (x11 == -6508964952510159333);
  check (x12 == -3797653321694789116);
  check (strcmp(x13, "") == 0);
  check (x14 == 4436872473581005130);
  check (x15 == 0x1.181c4cabeaf78p+4);
  check (x16 == 7823553664752172982);
  check (x17 == -5287472623467951187);
}

void f406(void)
{
}

signed char f407(float x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  double x4 = va_arg(l, double);
  long long x5 = va_arg(l, long long);
  double x6 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.7beffcp+4F);
  check (x1 == 0x1.4a86cd7a80974p+4);
  check (x2 == -1050976790);
  check (x3 == 0x1.87592ce069cdcp+4);
  check (x4 == 0x1.965e78fa2d13p+4);
  check (x5 == -3209851180859385995);
  check (x6 == 0x1.8e882f04f4b42p+5);
  return -274789815;
}

void f408(int x0, char * x1, char * x2, int x3, long long x4, int x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  char * x10 = va_arg(l, char *);
  char * x11 = va_arg(l, char *);
  long long x12 = va_arg(l, long long);
  char * x13 = va_arg(l, char *);
  int x14 = va_arg(l, int);
  va_end(l);
  check (x0 == -1462205848);
  check (strcmp(x1, "z") == 0);
  check (strcmp(x2, "xq") == 0);
  check (x3 == -285031047);
  check (x4 == -862543176140105523);
  check (x5 == 1010995369);
  check (x6 == 7880397847096153357);
  check (x7 == 1900393088);
  check (x8 == -680536412);
  check (x9 == 0x1.34121efe8db34p+4);
  check (strcmp(x10, "k") == 0);
  check (strcmp(x11, "") == 0);
  check (x12 == -7164459273887415629);
  check (strcmp(x13, "wq") == 0);
  check (x14 == 892046416);
}

unsigned char f409(long long x0, float x1, float x2, float x3, long long x4, int x5, float x6)
{
  check (x0 == -6481384395978021705);
  check (x1 == 0x1.783728p+5F);
  check (x2 == -0x1.4f9408p+5F);
  check (x3 == 0x1.8a61f6p+5F);
  check (x4 == -9039691872851130658);
  check (x5 == -329207642);
  check (x6 == 0x1.9f01a8p+4F);
  return -9962422;
}

void f410(float x0, double x1, char * x2, double x3, char * x4, ...)
{
  va_list l;
  va_start(l, x4);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.6e29fap+5F);
  check (x1 == 0x1.2a1da5aaba408p+5);
  check (strcmp(x2, "m") == 0);
  check (x3 == -0x1.328bd15ff797fp+4);
  check (strcmp(x4, "") == 0);
  check (x5 == 0x1.049283cc5e136p+5);
  check (strcmp(x6, "yu") == 0);
  check (x7 == -0x1.39f1a0e47b392p+5);
  check (x8 == 0x1.9d9dce52daf14p+4);
  check (strcmp(x9, "") == 0);
  check (x10 == 494372736);
  check (x11 == 7012440593895020133);
}

void f411(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  char * x3 = va_arg(l, char *);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  char * x8 = va_arg(l, char *);
  double x9 = va_arg(l, double);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.88c734p+4F);
  check (x1 == -1844154054);
  check (x2 == -0x1.2cf792f0071f9p+5);
  check (strcmp(x3, "qm") == 0);
  check (x4 == 0x1.6250ce3d31d88p+2);
  check (x5 == -0x1.00be46df71496p+5);
  check (x6 == -0x1.648f69ee5f55ep+4);
  check (x7 == 0x1.4d5e1454ed63p+2);
  check (strcmp(x8, "") == 0);
  check (x9 == 0x1.eda3f9335ac6p+3);
  check (strcmp(x10, "t") == 0);
  check (x11 == 0x1.241e47ae8baa8p+4);
  check (x12 == -1133840968);
}

short f412(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  char * x2 = va_arg(l, char *);
  char * x3 = va_arg(l, char *);
  char * x4 = va_arg(l, char *);
  long long x5 = va_arg(l, long long);
  double x6 = va_arg(l, double);
  long long x7 = va_arg(l, long long);
  va_end(l);
  check (x0 == 126582700);
  check (x1 == 1809045953);
  check (strcmp(x2, "kn") == 0);
  check (strcmp(x3, "v") == 0);
  check (strcmp(x4, "x") == 0);
  check (x5 == -7924397406285458602);
  check (x6 == -0x1.084fc53502fb8p+5);
  check (x7 == 6357472930508636675);
  return -110191408;
}

void f413(char * x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  int x3 = va_arg(l, int);
  char * x4 = va_arg(l, char *);
  va_end(l);
  check (strcmp(x0, "m") == 0);
  check (x1 == 7209940972449357255);
  check (x2 == 0x1.a7d92eddebc54p+3);
  check (x3 == 1427234931);
  check (strcmp(x4, "pn") == 0);
}

long long f414(long long x0, long long x1, char * x2, int x3, char * x4, char * x5, char * x6, int x7, double x8, char * x9, float x10)
{
  check (x0 == 3332021323172770669);
  check (x1 == -7835749584134344428);
  check (strcmp(x2, "xe") == 0);
  check (x3 == -1211535218);
  check (strcmp(x4, "ya") == 0);
  check (strcmp(x5, "") == 0);
  check (strcmp(x6, "pq") == 0);
  check (x7 == 1910130244);
  check (x8 == -0x1.2c0590cbf1325p+5);
  check (strcmp(x9, "") == 0);
  check (x10 == -0x1.7754e6p+5F);
  return -4096837288720221779;
}

void f415(int x0, int x1, double x2, float x3, float x4, long long x5, double x6, ...)
{
  va_list l;
  va_start(l, x6);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  int x11 = va_arg(l, int);
  char * x12 = va_arg(l, char *);
  char * x13 = va_arg(l, char *);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  int x16 = va_arg(l, int);
  char * x17 = va_arg(l, char *);
  va_end(l);
  check (x0 == 1044169548);
  check (x1 == 1762126574);
  check (x2 == 0x1.74ffe0790426p+0);
  check (x3 == -0x1.e6561p-5F);
  check (x4 == 0x1.89e9f4p+4F);
  check (x5 == -1478996642247107876);
  check (x6 == 0x1.522a780ea6f0ap+5);
  check (x7 == 0x1.2ca37660b2e1p+4);
  check (x8 == -2237227555588447244);
  check (x9 == -1051521141164062127);
  check (x10 == 2185968291040805907);
  check (x11 == 1678890927);
  check (strcmp(x12, "") == 0);
  check (strcmp(x13, "k") == 0);
  check (x14 == -623823850);
  check (x15 == 4238149781591558334);
  check (x16 == 328470252);
  check (strcmp(x17, "") == 0);
}

long long f416(void)
{
  return -8338444318046532472;
}

char * f417(double x0, double x1, char * x2, double x3, ...)
{
  va_list l;
  va_start(l, x3);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  long long x13 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.b392b2e3d36b4p+3);
  check (x1 == 0x1.4c0ad94aee564p+5);
  check (strcmp(x2, "yi") == 0);
  check (x3 == -0x1.8f7b1c55694a4p+4);
  check (x4 == 0x1.23baf6be5a0b4p+5);
  check (x5 == -0x1.d8541e09304ep+3);
  check (strcmp(x6, "xh") == 0);
  check (x7 == 0x1.7053c35ebe028p+5);
  check (x8 == 0x1.5467dd07beb2ep+5);
  check (x9 == 4296321206485065795);
  check (strcmp(x10, "") == 0);
  check (x11 == 0x1.1ec3716ac8f34p+4);
  check (x12 == 0x1.e0192f550485p+4);
  check (x13 == 8610008847562450312);
  return "";
}

unsigned char f418(float x0, double x1, int x2, double x3, double x4, float x5, long long x6, float x7)
{
  check (x0 == 0x1.a386ecp+4F);
  check (x1 == -0x1.02e3459498b4ap+5);
  check (x2 == 829775566);
  check (x3 == -0x1.27d6216f63851p+5);
  check (x4 == 0x1.899d23f17c51cp+4);
  check (x5 == -0x1.f846c4p+0F);
  check (x6 == 2669409591860942334);
  check (x7 == 0x1.d2d96ap+3F);
  return -380026418;
}

unsigned char f419(double x0, ...)
{
  va_list l;
  va_start(l, x0);
  double x1 = va_arg(l, double);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  int x4 = va_arg(l, int);
  long long x5 = va_arg(l, long long);
  long long x6 = va_arg(l, long long);
  char * x7 = va_arg(l, char *);
  double x8 = va_arg(l, double);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.5916aa530733p+1);
  check (x1 == -0x1.897f8b05f299ep+5);
  check (x2 == 1567111581);
  check (x3 == -0x1.78f107ad1bb7ep+5);
  check (x4 == 193306957);
  check (x5 == 4362841012538455904);
  check (x6 == 3750740465433711348);
  check (strcmp(x7, "mp") == 0);
  check (x8 == -0x1.6c2e9042bfe7p+4);
  check (strcmp(x9, "") == 0);
  check (x10 == -0x1.a3703af7894bcp+3);
  check (x11 == 932369841);
  return 234450053;
}

unsigned short f420(long long x0, int x1, char * x2, char * x3, double x4, double x5, char * x6, float x7)
{
  check (x0 == -2543424678288622194);
  check (x1 == -1888416697);
  check (strcmp(x2, "y") == 0);
  check (strcmp(x3, "t") == 0);
  check (x4 == 0x1.d7d11033d116p+2);
  check (x5 == 0x1.8eb93857ca3p+0);
  check (strcmp(x6, "d") == 0);
  check (x7 == -0x1.49dd44p+5F);
  return -460991477;
}

void f421(float x0)
{
  check (x0 == 0x1.5eaf8ep+5F);
}

short f422(long long x0, long long x1, long long x2, int x3, long long x4, int x5, double x6, double x7, int x8, ...)
{
  va_list l;
  va_start(l, x8);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  va_end(l);
  check (x0 == -4659502981922870288);
  check (x1 == 7203236368455605103);
  check (x2 == 4131768964428189029);
  check (x3 == 1295619543);
  check (x4 == -928518594439630155);
  check (x5 == -2026195856);
  check (x6 == -0x1.007ec5ecaac1ap+4);
  check (x7 == 0x1.564361a7314b6p+5);
  check (x8 == -1254631403);
  check (x9 == -7782709099316799147);
  check (x10 == -2241989375239868597);
  return 439541027;
}

void f423(long long x0, double x1, int x2, long long x3, long long x4, double x5, float x6, double x7, char * x8, ...)
{
  va_list l;
  va_start(l, x8);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  double x14 = va_arg(l, double);
  va_end(l);
  check (x0 == -6032275333697373315);
  check (x1 == -0x1.820b50a1afda9p+5);
  check (x2 == -1910946212);
  check (x3 == -1121011567992070858);
  check (x4 == -8231506343554514326);
  check (x5 == -0x1.3a24518bc0fa5p+5);
  check (x6 == 0x1.f7bca4p+4F);
  check (x7 == -0x1.eb04991ba4084p+3);
  check (strcmp(x8, "") == 0);
  check (x9 == -5592393229809429378);
  check (x10 == -7584110784821390930);
  check (x11 == -242019977);
  check (x12 == 4621862673231321039);
  check (x13 == 6812384790969327026);
  check (x14 == 0x1.ed9a7dc002c04p+4);
}

int f424(int x0, char * x1, double x2, char * x3, float x4)
{
  check (x0 == 223935773);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.c8efc9e42819p+1);
  check (strcmp(x3, "") == 0);
  check (x4 == 0x1.8e4bdcp+5F);
  return -935224610;
}

unsigned short f425(int x0, float x1, char * x2, ...)
{
  va_list l;
  va_start(l, x2);
  double x3 = va_arg(l, double);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  va_end(l);
  check (x0 == -358889847);
  check (x1 == -0x1.863136p+5F);
  check (strcmp(x2, "z") == 0);
  check (x3 == 0x1.14c0fe6655b28p+5);
  check (x4 == -0x1.c6a0f233a32c4p+3);
  check (x5 == -0x1.203fb63dfe3fep+5);
  check (x6 == -0x1.c5a844c83f37p+2);
  check (x7 == -244306599);
  check (x8 == 147994962);
  return 316488178;
}

unsigned short f426(int x0, char * x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == 1709297337);
  check (strcmp(x1, "e") == 0);
  check (x2 == 0x1.7187882fda44ap+5);
  check (x3 == 0x1.01c0ef332c6c4p+4);
  return 222000198;
}

unsigned char f427(double x0, char * x1, double x2, int x3, ...)
{
  va_list l;
  va_start(l, x3);
  double x4 = va_arg(l, double);
  char * x5 = va_arg(l, char *);
  double x6 = va_arg(l, double);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  int x13 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.58d8a5f03ed9dp+5);
  check (strcmp(x1, "b") == 0);
  check (x2 == 0x1.2e4d600375e22p+5);
  check (x3 == -1056763356);
  check (x4 == -0x1.22acf6264add4p+3);
  check (strcmp(x5, "r") == 0);
  check (x6 == 0x1.787ddd9652778p+3);
  check (x7 == 413153996);
  check (x8 == 1195360696);
  check (x9 == -0x1.8c16dec4a1818p+3);
  check (x10 == -7729372579897122667);
  check (x11 == 1078062019020227661);
  check (strcmp(x12, "q") == 0);
  check (x13 == 1997713726);
  return 110736147;
}

void f428(long long x0, double x1, char * x2, char * x3, float x4)
{
  check (x0 == 3723698571664203973);
  check (x1 == 0x1.88f49eac78876p+5);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "jz") == 0);
  check (x4 == 0x1.d6dadap+1F);
}

signed char f429(long long x0, float x1, int x2, long long x3, long long x4, float x5)
{
  check (x0 == -7302998367745747016);
  check (x1 == 0x1.2429bp+5F);
  check (x2 == -68546152);
  check (x3 == -461655491113207654);
  check (x4 == -490600668167066820);
  check (x5 == -0x1.ae8264p+4F);
  return 385018867;
}

signed char f430(char * x0, long long x1, long long x2, double x3, double x4, char * x5, int x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  char * x12 = va_arg(l, char *);
  int x13 = va_arg(l, int);
  double x14 = va_arg(l, double);
  int x15 = va_arg(l, int);
  double x16 = va_arg(l, double);
  double x17 = va_arg(l, double);
  double x18 = va_arg(l, double);
  int x19 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 3431596498022145775);
  check (x2 == 885117644200106649);
  check (x3 == 0x1.112c10e56b2e8p+3);
  check (x4 == 0x1.2ef04835f27p+4);
  check (strcmp(x5, "e") == 0);
  check (x6 == -167487185);
  check (x7 == 294804365);
  check (x8 == 27931983);
  check (x9 == 0x1.352e03d960134p+5);
  check (x10 == 0x1.a2a96deec78dp+3);
  check (x11 == 0x1.968f31ca144b4p+4);
  check (strcmp(x12, "mn") == 0);
  check (x13 == 691798510);
  check (x14 == 0x1.04fe3fb33bd54p+4);
  check (x15 == 723956671);
  check (x16 == 0x1.66a3b3739738p-2);
  check (x17 == 0x1.9db39121fd438p+4);
  check (x18 == 0x1.84246e5cffddap+5);
  check (x19 == -1560802388);
  return 274233014;
}

double f431(long long x0, int x1, int x2, long long x3, double x4, long long x5, char * x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  va_end(l);
  check (x0 == -1389139239892506449);
  check (x1 == 1807514746);
  check (x2 == 1777341255);
  check (x3 == 6873234772713951789);
  check (x4 == 0x1.c9eb6cabe1ep-4);
  check (x5 == 5936749792073005503);
  check (strcmp(x6, "") == 0);
  check (x7 == 1484048182);
  check (x8 == -5189260766996094280);
  check (x9 == -8447949907469236439);
  return 0x1.452ef4ed66d9cp+4;
}

void f432(float x0)
{
  check (x0 == 0x1.edb824p+4F);
}

float f433(float x0, double x1, long long x2, char * x3, float x4, float x5)
{
  check (x0 == -0x1.83536p+3F);
  check (x1 == 0x1.57bc4ea3f1374p+3);
  check (x2 == -8670558370469767670);
  check (strcmp(x3, "") == 0);
  check (x4 == 0x1.a5abd6p+3F);
  check (x5 == -0x1.0490e8p+5F);
  return -0x1.56f2af271e4dap+4;
}

void f434(char * x0, long long x1, char * x2, char * x3, long long x4, char * x5, float x6, int x7, char * x8, long long x9, float x10)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 3597387870720388596);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "") == 0);
  check (x4 == -9100642254613773564);
  check (strcmp(x5, "") == 0);
  check (x6 == -0x1.6b3acp+4F);
  check (x7 == -714025561);
  check (strcmp(x8, "") == 0);
  check (x9 == 6593047330670613933);
  check (x10 == 0x1.72f53cp+5F);
}

void f435(long long x0, double x1, long long x2, float x3, double x4, double x5, double x6, char * x7, long long x8, int x9, ...)
{
  va_list l;
  va_start(l, x9);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  double x12 = va_arg(l, double);
  char * x13 = va_arg(l, char *);
  char * x14 = va_arg(l, char *);
  int x15 = va_arg(l, int);
  char * x16 = va_arg(l, char *);
  int x17 = va_arg(l, int);
  va_end(l);
  check (x0 == 1112340541809043337);
  check (x1 == -0x1.4b6b5abd153b2p+5);
  check (x2 == 3510909056831984727);
  check (x3 == -0x1.2a9a18p+5F);
  check (x4 == -0x1.b3a2aaf8223cep+4);
  check (x5 == 0x1.52addbffc324cp+4);
  check (x6 == 0x1.3b425fc26ea76p+5);
  check (strcmp(x7, "bk") == 0);
  check (x8 == -8525909450212887855);
  check (x9 == -42372531);
  check (x10 == -3931221075725135024);
  check (strcmp(x11, "w") == 0);
  check (x12 == -0x1.144b0c01cd9bbp+5);
  check (strcmp(x13, "") == 0);
  check (strcmp(x14, "") == 0);
  check (x15 == -645236408);
  check (strcmp(x16, "p") == 0);
  check (x17 == 331484373);
}

float f436(int x0, int x1, char * x2, double x3, char * x4, ...)
{
  va_list l;
  va_start(l, x4);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  double x14 = va_arg(l, double);
  char * x15 = va_arg(l, char *);
  char * x16 = va_arg(l, char *);
  va_end(l);
  check (x0 == -1932883737);
  check (x1 == -1686372171);
  check (strcmp(x2, "gy") == 0);
  check (x3 == 0x1.469c6add28c3p+1);
  check (strcmp(x4, "u") == 0);
  check (x5 == -0x1.22c26bf8ba5c5p+4);
  check (x6 == 0x1.4a308a9ed41c8p+4);
  check (x7 == -0x1.3aa0607f44b24p+5);
  check (x8 == -8344328645602464328);
  check (strcmp(x9, "") == 0);
  check (x10 == 1084052184);
  check (x11 == 0x1.849c2727927cap+5);
  check (x12 == -2102459270);
  check (x13 == 6721858365440107547);
  check (x14 == -0x1.23d2943319b8p-1);
  check (strcmp(x15, "ct") == 0);
  check (strcmp(x16, "bm") == 0);
  return 0x1.5f46f92d6bc84p+5;
}

void f437(int x0, long long x1, char * x2, long long x3, float x4, float x5, char * x6, ...)
{
  va_list l;
  va_start(l, x6);
  double x7 = va_arg(l, double);
  va_end(l);
  check (x0 == -1578017286);
  check (x1 == -7936177746241009067);
  check (strcmp(x2, "g") == 0);
  check (x3 == -3265647520849273440);
  check (x4 == -0x1.7f61e2p+2F);
  check (x5 == 0x1.232c8ep+4F);
  check (strcmp(x6, "q") == 0);
  check (x7 == 0x1.bcddf96b16ccp+4);
}

int f438(double x0, int x1, char * x2, char * x3, float x4)
{
  check (x0 == -0x1.567b6059acd8p-1);
  check (x1 == 1836431751);
  check (strcmp(x2, "dt") == 0);
  check (strcmp(x3, "z") == 0);
  check (x4 == 0x1.a7b378p+4F);
  return 1017531477;
}

long long f439(long long x0, char * x1, int x2, int x3, int x4, double x5, double x6, double x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  int x13 = va_arg(l, int);
  char * x14 = va_arg(l, char *);
  int x15 = va_arg(l, int);
  double x16 = va_arg(l, double);
  double x17 = va_arg(l, double);
  double x18 = va_arg(l, double);
  va_end(l);
  check (x0 == 2914749209243483988);
  check (strcmp(x1, "zw") == 0);
  check (x2 == 1512128390);
  check (x3 == 713876067);
  check (x4 == 229596889);
  check (x5 == 0x1.503a4746e60d8p+4);
  check (x6 == -0x1.1c22d7ddff639p+5);
  check (x7 == -0x1.8f498bf8a8fa5p+4);
  check (x8 == -825677613440443389);
  check (x9 == 0x1.13b0ee65dd7eap+5);
  check (x10 == -978667160);
  check (x11 == 747083862);
  check (x12 == 3146381270137346382);
  check (x13 == 1783876605);
  check (strcmp(x14, "gg") == 0);
  check (x15 == -1307441470);
  check (x16 == -0x1.0cd4dc0acf208p+5);
  check (x17 == -0x1.1a5fa5520141ap+4);
  check (x18 == -0x1.e39684c172dc5p+4);
  return 1689161203693244332;
}

void f440(int x0, long long x1, char * x2, long long x3, char * x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  char * x8 = va_arg(l, char *);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  char * x11 = va_arg(l, char *);
  va_end(l);
  check (x0 == 1148521352);
  check (x1 == -8304254539502452849);
  check (strcmp(x2, "") == 0);
  check (x3 == -5020494555461985258);
  check (strcmp(x4, "") == 0);
  check (x5 == -1484388191958804826);
  check (x6 == -307738451);
  check (x7 == 5907278515224361855);
  check (strcmp(x8, "ng") == 0);
  check (x9 == -0x1.9644291fea9cp+1);
  check (x10 == -1244972682);
  check (strcmp(x11, "rd") == 0);
}

signed char f441(long long x0, char * x1, long long x2, int x3, char * x4, float x5, double x6, int x7, long long x8, float x9)
{
  check (x0 == 7825368572396376916);
  check (strcmp(x1, "") == 0);
  check (x2 == -6718535042655483889);
  check (x3 == -1110537140);
  check (strcmp(x4, "ci") == 0);
  check (x5 == -0x1.5df94cp+5F);
  check (x6 == 0x1.a9d4e2a3c607p+1);
  check (x7 == -1571514110);
  check (x8 == 6903578562116876435);
  check (x9 == 0x1.8e3472p+5F);
  return 253630520;
}

int f442(char * x0, float x1, long long x2, char * x3, char * x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  char * x6 = va_arg(l, char *);
  char * x7 = va_arg(l, char *);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  char * x12 = va_arg(l, char *);
  double x13 = va_arg(l, double);
  double x14 = va_arg(l, double);
  long long x15 = va_arg(l, long long);
  long long x16 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "ls") == 0);
  check (x1 == 0x1.1e56fap+4F);
  check (x2 == 347129725963138648);
  check (strcmp(x3, "ir") == 0);
  check (strcmp(x4, "") == 0);
  check (x5 == 0x1.53b03677fe674p+3);
  check (strcmp(x6, "au") == 0);
  check (strcmp(x7, "is") == 0);
  check (x8 == -175526916);
  check (x9 == -0x1.7c55fbb8c88e9p+5);
  check (x10 == 0x1.7219655dcb8c4p+5);
  check (x11 == 0x1.847568059a7ccp+4);
  check (strcmp(x12, "yy") == 0);
  check (x13 == 0x1.a767ec4949a44p+4);
  check (x14 == -0x1.280a4ff9a2002p+4);
  check (x15 == -8654925139574787767);
  check (x16 == 4943491571959771240);
  return -1158379832;
}

void f443(int x0, float x1, int x2, int x3, double x4, int x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  char * x7 = va_arg(l, char *);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  char * x11 = va_arg(l, char *);
  double x12 = va_arg(l, double);
  int x13 = va_arg(l, int);
  va_end(l);
  check (x0 == -1925059265);
  check (x1 == 0x1.312296p+4F);
  check (x2 == 85693242);
  check (x3 == 1688914688);
  check (x4 == -0x1.11d372bd2bf54p+4);
  check (x5 == 1293631854);
  check (x6 == -174156961);
  check (strcmp(x7, "dx") == 0);
  check (x8 == 0x1.e646d256d0014p+4);
  check (x9 == -0x1.3239cc7946542p+4);
  check (x10 == -1850156903);
  check (strcmp(x11, "u") == 0);
  check (x12 == 0x1.ec26cf64a5108p+4);
  check (x13 == -1420236500);
}

void f444(double x0, double x1, double x2, ...)
{
  va_list l;
  va_start(l, x2);
  int x3 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.953a0a8c06fb4p+4);
  check (x1 == 0x1.7fe4358181ecp+5);
  check (x2 == 0x1.8dd3e653b38aep+5);
  check (x3 == -1409450674);
}

void f445(double x0, int x1, char * x2, char * x3, char * x4, double x5, int x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.399309ad4f78cp+5);
  check (x1 == 1510156362);
  check (strcmp(x2, "j") == 0);
  check (strcmp(x3, "dq") == 0);
  check (strcmp(x4, "rs") == 0);
  check (x5 == -0x1.805fbbaf4864p+3);
  check (x6 == 846166782);
  check (x7 == -1618775866);
  check (x8 == 5309788833199994328);
  check (strcmp(x9, "c") == 0);
  check (x10 == -3998065641956683756);
}

long long f446(long long x0, float x1, double x2, float x3, long long x4, char * x5, float x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  double x10 = va_arg(l, double);
  char * x11 = va_arg(l, char *);
  va_end(l);
  check (x0 == -3340077035928372098);
  check (x1 == 0x1.895d8p+5F);
  check (x2 == 0x1.86703f544a9dp+1);
  check (x3 == -0x1.5c421p+4F);
  check (x4 == -4788980648105821183);
  check (strcmp(x5, "") == 0);
  check (x6 == 0x1.8517e8p+4F);
  check (x7 == -1730445794);
  check (x8 == -0x1.891394e9ab5b5p+4);
  check (x9 == 5723049967409746506);
  check (x10 == 0x1.913f6816f8878p+4);
  check (strcmp(x11, "gk") == 0);
  return -3943990466621953530;
}

unsigned short f447(char * x0, int x1, float x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 754018202);
  check (x2 == -0x1.61d26ap+5F);
  check (strcmp(x3, "gb") == 0);
  check (x4 == -1557349605826096936);
  check (x5 == -0x1.8f069825bddap+0);
  check (strcmp(x6, "b") == 0);
  check (x7 == 908729257579937216);
  check (x8 == 2137595933);
  check (x9 == -3953019648424700906);
  return -4829120;
}

void f448(long long x0, int x1, double x2, double x3, float x4, double x5, double x6, int x7, int x8, int x9, ...)
{
  va_list l;
  va_start(l, x9);
  char * x10 = va_arg(l, char *);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  int x16 = va_arg(l, int);
  char * x17 = va_arg(l, char *);
  char * x18 = va_arg(l, char *);
  long long x19 = va_arg(l, long long);
  long long x20 = va_arg(l, long long);
  char * x21 = va_arg(l, char *);
  va_end(l);
  check (x0 == 6531138720861228097);
  check (x1 == 1259483470);
  check (x2 == 0x1.0053e88800588p+4);
  check (x3 == 0x1.918803162afcp+2);
  check (x4 == -0x1.559a36p+4F);
  check (x5 == -0x1.a46024eede87dp+4);
  check (x6 == 0x1.a1bb5ed44f89cp+3);
  check (x7 == 885326688);
  check (x8 == 780966760);
  check (x9 == -822013912);
  check (strcmp(x10, "ud") == 0);
  check (x11 == 2517585105817420038);
  check (x12 == 639439147);
  check (x13 == 687509194);
  check (x14 == 564106330);
  check (x15 == -8329133427401313242);
  check (x16 == 541772266);
  check (strcmp(x17, "k") == 0);
  check (strcmp(x18, "") == 0);
  check (x19 == 5774002144040153665);
  check (x20 == -5416621571185012528);
  check (strcmp(x21, "dy") == 0);
}

char * f449(int x0, ...)
{
  va_list l;
  va_start(l, x0);
  double x1 = va_arg(l, double);
  char * x2 = va_arg(l, char *);
  double x3 = va_arg(l, double);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  long long x6 = va_arg(l, long long);
  char * x7 = va_arg(l, char *);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  char * x10 = va_arg(l, char *);
  va_end(l);
  check (x0 == 1977825708);
  check (x1 == -0x1.37608547a4e2ep+5);
  check (strcmp(x2, "o") == 0);
  check (x3 == -0x1.159e7324e09dep+5);
  check (x4 == 1925022791);
  check (x5 == 0x1.1955523f04fp+2);
  check (x6 == 8310344355305523420);
  check (strcmp(x7, "ot") == 0);
  check (x8 == 6069382889623661291);
  check (x9 == -7639394178144039046);
  check (strcmp(x10, "y") == 0);
  return "";
}

void f450(int x0, long long x1, char * x2, ...)
{
  va_list l;
  va_start(l, x2);
  char * x3 = va_arg(l, char *);
  double x4 = va_arg(l, double);
  char * x5 = va_arg(l, char *);
  va_end(l);
  check (x0 == 2004920064);
  check (x1 == 1908866981740348154);
  check (strcmp(x2, "a") == 0);
  check (strcmp(x3, "xj") == 0);
  check (x4 == -0x1.67bd1ba598694p+5);
  check (strcmp(x5, "") == 0);
}

void f451(float x0, double x1, char * x2, double x3, float x4, double x5, char * x6, int x7, long long x8, float x9)
{
  check (x0 == 0x1.8674dp+3F);
  check (x1 == -0x1.598153945c03ap+4);
  check (strcmp(x2, "n") == 0);
  check (x3 == -0x1.53c224959dba3p+5);
  check (x4 == 0x1.9f40a6p+4F);
  check (x5 == -0x1.bf7d48f516c5fp+4);
  check (strcmp(x6, "") == 0);
  check (x7 == -267722864);
  check (x8 == -8847227619112772465);
  check (x9 == 0x1.2bdacep+1F);
}

void f452(long long x0, double x1, int x2, long long x3, int x4, ...)
{
  va_list l;
  va_start(l, x4);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  long long x14 = va_arg(l, long long);
  int x15 = va_arg(l, int);
  char * x16 = va_arg(l, char *);
  va_end(l);
  check (x0 == 6786981795028323271);
  check (x1 == 0x1.25968b8b2596p+4);
  check (x2 == 1160723800);
  check (x3 == -2934037939437583584);
  check (x4 == 1899399846);
  check (x5 == 0x1.e27f9b9e9184p+1);
  check (strcmp(x6, "") == 0);
  check (x7 == 3155488523765662551);
  check (x8 == -969198);
  check (strcmp(x9, "ni") == 0);
  check (x10 == 1074637142);
  check (x11 == 1451331639);
  check (x12 == 0x1.ae226d9e8e07cp+4);
  check (x13 == 0x1.022047a2909a6p+5);
  check (x14 == 7431145146083460897);
  check (x15 == -1616131068);
  check (strcmp(x16, "k") == 0);
}

void f453(double x0, ...)
{
  va_list l;
  va_start(l, x0);
  char * x1 = va_arg(l, char *);
  char * x2 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.2b07123f898e2p+5);
  check (strcmp(x1, "") == 0);
  check (strcmp(x2, "") == 0);
}

double f454(double x0, long long x1, double x2, char * x3, long long x4, int x5, char * x6, double x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  char * x11 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.000188bd4f2ap+5);
  check (x1 == 2827476977970540292);
  check (x2 == 0x1.5e18a0dcc67fp+5);
  check (strcmp(x3, "f") == 0);
  check (x4 == 3475265456363539506);
  check (x5 == 1834756799);
  check (strcmp(x6, "q") == 0);
  check (x7 == -0x1.ca643daeb3bcp+0);
  check (x8 == -2221146778954367206);
  check (strcmp(x9, "mt") == 0);
  check (x10 == -0x1.521bdb0e07bc2p+5);
  check (strcmp(x11, "") == 0);
  return -0x1.139c47086856ep+5;
}

void f455(char * x0, int x1, char * x2, double x3, double x4, char * x5, char * x6, double x7, char * x8, float x9, float x10)
{
  check (strcmp(x0, "nf") == 0);
  check (x1 == -990091541);
  check (strcmp(x2, "y") == 0);
  check (x3 == 0x1.4a190b1016aap+1);
  check (x4 == -0x1.c5fb16bbabf42p+4);
  check (strcmp(x5, "") == 0);
  check (strcmp(x6, "u") == 0);
  check (x7 == -0x1.ce659e1190eb2p+4);
  check (strcmp(x8, "ex") == 0);
  check (x9 == -0x1.c5f62p+2F);
  check (x10 == -0x1.b18044p+2F);
}

void f456(void)
{
}

void f457(long long x0, int x1, long long x2, double x3, double x4, ...)
{
  va_list l;
  va_start(l, x4);
  int x5 = va_arg(l, int);
  long long x6 = va_arg(l, long long);
  char * x7 = va_arg(l, char *);
  char * x8 = va_arg(l, char *);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  va_end(l);
  check (x0 == -4183088704107341406);
  check (x1 == -293631940);
  check (x2 == 1951433067793795806);
  check (x3 == 0x1.6f0be93ca4e82p+5);
  check (x4 == 0x1.75afa14a0c2dap+5);
  check (x5 == -1682790137);
  check (x6 == -2810625771442701827);
  check (strcmp(x7, "gg") == 0);
  check (strcmp(x8, "yq") == 0);
  check (x9 == -1697818224171832666);
  check (x10 == 1197597137);
  check (x11 == 961174163);
}

short f458(double x0, int x1, char * x2, long long x3, ...)
{
  va_list l;
  va_start(l, x3);
  int x4 = va_arg(l, int);
  char * x5 = va_arg(l, char *);
  va_end(l);
  check (x0 == 0x1.8aa38954a0f62p+5);
  check (x1 == 1755929040);
  check (strcmp(x2, "y") == 0);
  check (x3 == -852349325747961357);
  check (x4 == -528986701);
  check (strcmp(x5, "ro") == 0);
  return -536760999;
}

unsigned short f459(char * x0, long long x1, long long x2, long long x3, int x4, float x5)
{
  check (strcmp(x0, "ja") == 0);
  check (x1 == -8580452957776928631);
  check (x2 == 7551253078661079189);
  check (x3 == -3096887836211969871);
  check (x4 == -866300376);
  check (x5 == -0x1.8ffc2p+5F);
  return 230810408;
}

int f460(float x0, long long x1, long long x2, long long x3, double x4, long long x5, long long x6, char * x7, char * x8, double x9, int x10, ...)
{
  va_list l;
  va_start(l, x10);
  int x11 = va_arg(l, int);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  char * x14 = va_arg(l, char *);
  long long x15 = va_arg(l, long long);
  double x16 = va_arg(l, double);
  long long x17 = va_arg(l, long long);
  long long x18 = va_arg(l, long long);
  long long x19 = va_arg(l, long long);
  double x20 = va_arg(l, double);
  char * x21 = va_arg(l, char *);
  int x22 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.ccb184p+4F);
  check (x1 == 371145016760780922);
  check (x2 == -7651408772339500446);
  check (x3 == -8397725739502352725);
  check (x4 == -0x1.2fa4f19cf4ca8p+5);
  check (x5 == 97631758895810288);
  check (x6 == -7802928474814678546);
  check (strcmp(x7, "") == 0);
  check (strcmp(x8, "lq") == 0);
  check (x9 == -0x1.d1afde5c6295p+1);
  check (x10 == 1357591004);
  check (x11 == -284909661);
  check (x12 == -142641072);
  check (x13 == -1640662685);
  check (strcmp(x14, "g") == 0);
  check (x15 == -8208205157200549136);
  check (x16 == 0x1.8d6c09857634p+2);
  check (x17 == 8567442892322636103);
  check (x18 == 1876327329938168813);
  check (x19 == 6621558789175268637);
  check (x20 == -0x1.19aa0b682e47cp+5);
  check (strcmp(x21, "np") == 0);
  check (x22 == -654603124);
  return 657428119;
}

void f461(double x0, char * x1, char * x2, long long x3, int x4, char * x5, char * x6, int x7, int x8, int x9, float x10)
{
  check (x0 == 0x1.04fa1551accecp+4);
  check (strcmp(x1, "xv") == 0);
  check (strcmp(x2, "") == 0);
  check (x3 == 4521021799245562075);
  check (x4 == 442676745);
  check (strcmp(x5, "") == 0);
  check (strcmp(x6, "") == 0);
  check (x7 == -1015977850);
  check (x8 == -152309192);
  check (x9 == -59469468);
  check (x10 == -0x1.4ed72cp+4F);
}

void f462(char * x0, float x1, double x2, char * x3, double x4, double x5, long long x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  long long x11 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "f") == 0);
  check (x1 == -0x1.cb69e4p+3F);
  check (x2 == -0x1.7c5ba71c60639p+5);
  check (strcmp(x3, "zj") == 0);
  check (x4 == -0x1.cf1f1ea3e3c2p+4);
  check (x5 == -0x1.deba7be93abdbp+4);
  check (x6 == -5383175227743470451);
  check (x7 == 2189022040572435127);
  check (x8 == 7738184846733503198);
  check (strcmp(x9, "") == 0);
  check (x10 == -0x1.35475971c891p+4);
  check (x11 == -724439081858302702);
}

void f463(int x0, long long x1, int x2, char * x3, int x4, char * x5, float x6, int x7, double x8, double x9, ...)
{
  va_list l;
  va_start(l, x9);
  char * x10 = va_arg(l, char *);
  long long x11 = va_arg(l, long long);
  long long x12 = va_arg(l, long long);
  char * x13 = va_arg(l, char *);
  int x14 = va_arg(l, int);
  double x15 = va_arg(l, double);
  va_end(l);
  check (x0 == -1613431125);
  check (x1 == -2279226944540707646);
  check (x2 == -1553652926);
  check (strcmp(x3, "") == 0);
  check (x4 == -564138388);
  check (strcmp(x5, "i") == 0);
  check (x6 == 0x1.210fdep+4F);
  check (x7 == 909225134);
  check (x8 == -0x1.583cf6c23379p+2);
  check (x9 == -0x1.01d692c32e3eep+4);
  check (strcmp(x10, "un") == 0);
  check (x11 == -5072118962435481767);
  check (x12 == -1568677558664840053);
  check (strcmp(x13, "u") == 0);
  check (x14 == -210371824);
  check (x15 == -0x1.50d914c03338p+3);
}

short f464(long long x0, char * x1, double x2, double x3, ...)
{
  va_list l;
  va_start(l, x3);
  int x4 = va_arg(l, int);
  int x5 = va_arg(l, int);
  double x6 = va_arg(l, double);
  int x7 = va_arg(l, int);
  va_end(l);
  check (x0 == 3441675435695409651);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.3211867b814ep+5);
  check (x3 == 0x1.165dd5224ce38p+3);
  check (x4 == -1453875715);
  check (x5 == -1436156682);
  check (x6 == -0x1.a8713419fe854p+3);
  check (x7 == 1091351706);
  return 116602742;
}

short f465(double x0, ...)
{
  va_list l;
  va_start(l, x0);
  double x1 = va_arg(l, double);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.3b10916fcef18p+4);
  check (x1 == -0x1.79ffa05c9f5afp+5);
  check (x2 == 984534765420987531);
  check (x3 == 0x1.4909446f529c4p+5);
  return -508976166;
}

signed char f466(int x0, char * x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  va_end(l);
  check (x0 == -454837357);
  check (strcmp(x1, "") == 0);
  check (x2 == 111240261);
  check (x3 == -7739071356052650126);
  check (x4 == 7951045253483613970);
  return 256944226;
}

void f467(long long x0, ...)
{
  va_list l;
  va_start(l, x0);
  double x1 = va_arg(l, double);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == 3092945891219883833);
  check (x1 == -0x1.1e2ec1bb46ae2p+5);
  check (x2 == 3275105333968491987);
}

void f468(int x0, double x1, int x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  char * x4 = va_arg(l, char *);
  va_end(l);
  check (x0 == 423684324);
  check (x1 == 0x1.21a1ecc22cdc8p+3);
  check (x2 == -1963862824);
  check (x3 == 4856666994394623229);
  check (strcmp(x4, "") == 0);
}

unsigned short f469(char * x0, long long x1, float x2, long long x3, double x4, float x5, int x6, double x7, long long x8, double x9, ...)
{
  va_list l;
  va_start(l, x9);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  char * x15 = va_arg(l, char *);
  char * x16 = va_arg(l, char *);
  long long x17 = va_arg(l, long long);
  long long x18 = va_arg(l, long long);
  char * x19 = va_arg(l, char *);
  long long x20 = va_arg(l, long long);
  int x21 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "h") == 0);
  check (x1 == -1859745287902798633);
  check (x2 == -0x1.2c4fb6p-3F);
  check (x3 == 8817381647518280879);
  check (x4 == -0x1.5dd72e3ae9dfbp+5);
  check (x5 == 0x1.23810cp+5F);
  check (x6 == -729237242);
  check (x7 == 0x1.f1abfbe37aa24p+4);
  check (x8 == -457649514637023615);
  check (x9 == 0x1.0d6da7ac8c0d8p+3);
  check (x10 == -1309169112);
  check (x11 == -3827666976791921074);
  check (x12 == 680075702);
  check (x13 == 6210357095358154935);
  check (x14 == -101554523);
  check (strcmp(x15, "jo") == 0);
  check (strcmp(x16, "jm") == 0);
  check (x17 == 1864769428870608778);
  check (x18 == -5097624462335850760);
  check (strcmp(x19, "d") == 0);
  check (x20 == -2224454466772420642);
  check (x21 == 1331964661);
  return 426384647;
}

void f470(double x0, double x1, long long x2, int x3, double x4, ...)
{
  va_list l;
  va_start(l, x4);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  char * x8 = va_arg(l, char *);
  va_end(l);
  check (x0 == 0x1.7701ab469864p+5);
  check (x1 == 0x1.0a8618a706e44p+3);
  check (x2 == 510492394365680779);
  check (x3 == -1091738348);
  check (x4 == 0x1.3efb605f5e434p+5);
  check (x5 == 1290119251);
  check (x6 == 805973639);
  check (x7 == 66888567);
  check (strcmp(x8, "") == 0);
}

unsigned short f471(float x0, int x1, float x2, double x3, char * x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  int x13 = va_arg(l, int);
  long long x14 = va_arg(l, long long);
  char * x15 = va_arg(l, char *);
  double x16 = va_arg(l, double);
  double x17 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.20a086p+5F);
  check (x1 == 22739900);
  check (x2 == 0x1.04f24p+4F);
  check (x3 == 0x1.7ddbe5491d118p+4);
  check (strcmp(x4, "d") == 0);
  check (x5 == 1399999975557627438);
  check (x6 == -979071720729495506);
  check (x7 == 6210329465289788228);
  check (x8 == -845261329455869777);
  check (strcmp(x9, "b") == 0);
  check (x10 == 0x1.da79bc84b6788p+4);
  check (x11 == 1143615238);
  check (x12 == 9205245695571776255);
  check (x13 == -1059702907);
  check (x14 == 6026857156842592738);
  check (strcmp(x15, "gs") == 0);
  check (x16 == -0x1.2080bc6d1cf4dp+5);
  check (x17 == -0x1.1f8b260b1acp+2);
  return 336293032;
}

int f472(float x0, long long x1, int x2, int x3, char * x4, char * x5, int x6, double x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.127f2p+5F);
  check (x1 == 8361563117239913931);
  check (x2 == -708981828);
  check (x3 == -682177507);
  check (strcmp(x4, "j") == 0);
  check (strcmp(x5, "a") == 0);
  check (x6 == -1035562504);
  check (x7 == 0x1.ca141077f4cc8p+3);
  check (x8 == -8110757907165980708);
  check (x9 == 2091592325379509654);
  return 209900256;
}

void f473(char * x0, char * x1, long long x2, float x3, float x4)
{
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "") == 0);
  check (x2 == -6596332103010422241);
  check (x3 == 0x1.6f730ap+5F);
  check (x4 == 0x1.f3e3c4p+4F);
}

void f474(void)
{
}

void f475(int x0, int x1, long long x2, long long x3, char * x4, ...)
{
  va_list l;
  va_start(l, x4);
  int x5 = va_arg(l, int);
  double x6 = va_arg(l, double);
  va_end(l);
  check (x0 == -1789861995);
  check (x1 == 65794141);
  check (x2 == -8678248775806784123);
  check (x3 == 727935938741720899);
  check (strcmp(x4, "no") == 0);
  check (x5 == -1209516127);
  check (x6 == 0x1.8be52b724befap+5);
}

void f476(char * x0, double x1, long long x2, ...)
{
  va_list l;
  va_start(l, x2);
  double x3 = va_arg(l, double);
  char * x4 = va_arg(l, char *);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  int x7 = va_arg(l, int);
  long long x8 = va_arg(l, long long);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "py") == 0);
  check (x1 == -0x1.9f0c3cb45b717p+4);
  check (x2 == 7044885812300100702);
  check (x3 == 0x1.a087b7c64aa38p+4);
  check (strcmp(x4, "f") == 0);
  check (x5 == 0x1.ee4a7e88a741p+4);
  check (x6 == -0x1.401b303bcc896p+5);
  check (x7 == -1643400595);
  check (x8 == -6055613274544340933);
  check (strcmp(x9, "b") == 0);
  check (x10 == 1703751279);
  check (x11 == -0x1.2c8d049b17a6dp+5);
  check (x12 == 1036938235);
}

signed char f477(long long x0, float x1, char * x2, double x3, int x4, double x5, float x6, double x7, double x8, long long x9, double x10, ...)
{
  va_list l;
  va_start(l, x10);
  long long x11 = va_arg(l, long long);
  long long x12 = va_arg(l, long long);
  va_end(l);
  check (x0 == -4981457954179849412);
  check (x1 == 0x1.19727p+4F);
  check (strcmp(x2, "ur") == 0);
  check (x3 == -0x1.fc7bbecfc7e67p+4);
  check (x4 == -1858670971);
  check (x5 == -0x1.d5e3b1d63e39p+4);
  check (x6 == -0x1.aaee7ep+3F);
  check (x7 == 0x1.9ae66928955bp+1);
  check (x8 == -0x1.50d0dacead73fp+4);
  check (x9 == -6792125561638610440);
  check (x10 == 0x1.30a330bddbc3p+4);
  check (x11 == -1254707167331127018);
  check (x12 == -1557716816123251151);
  return 99738855;
}

unsigned char f478(int x0, double x1, long long x2, double x3, int x4, ...)
{
  va_list l;
  va_start(l, x4);
  int x5 = va_arg(l, int);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  va_end(l);
  check (x0 == -1738626056);
  check (x1 == -0x1.2de4d1a73c3f6p+5);
  check (x2 == 3149483165371455966);
  check (x3 == -0x1.e5e0ab7f6dfbap+4);
  check (x4 == -741220564);
  check (x5 == -336958194);
  check (x6 == -0x1.c3eec33b637f9p+4);
  check (x7 == -0x1.2c29e1facbb78p+5);
  check (x8 == 0x1.934faa893ce4p+4);
  return 46609167;
}

void f479(int x0, int x1, int x2, char * x3, int x4, float x5, int x6, ...)
{
  va_list l;
  va_start(l, x6);
  int x7 = va_arg(l, int);
  char * x8 = va_arg(l, char *);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  long long x14 = va_arg(l, long long);
  long long x15 = va_arg(l, long long);
  double x16 = va_arg(l, double);
  char * x17 = va_arg(l, char *);
  long long x18 = va_arg(l, long long);
  va_end(l);
  check (x0 == 1124630208);
  check (x1 == 1092809248);
  check (x2 == 2071298591);
  check (strcmp(x3, "ai") == 0);
  check (x4 == 1536243244);
  check (x5 == -0x1.89caa2p+5F);
  check (x6 == 1988835336);
  check (x7 == 1778442459);
  check (strcmp(x8, "") == 0);
  check (x9 == -0x1.c8a257562179p+2);
  check (x10 == 1503486678);
  check (x11 == -0x1.2dd3d4dcbbcdfp+5);
  check (x12 == -1793535980);
  check (x13 == -5001379318247038898);
  check (x14 == 6770056227770594402);
  check (x15 == -1758958832915014383);
  check (x16 == 0x1.5fb1bf73e2066p+5);
  check (strcmp(x17, "h") == 0);
  check (x18 == -8046525426970221834);
}

int f480(int x0, int x1, long long x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  double x4 = va_arg(l, double);
  int x5 = va_arg(l, int);
  va_end(l);
  check (x0 == -264806641);
  check (x1 == 368629457);
  check (x2 == 6073383306546713128);
  check (strcmp(x3, "xb") == 0);
  check (x4 == 0x1.cc02ef1729efp+1);
  check (x5 == 1629606706);
  return 1017239924;
}

int f481(float x0, char * x1, int x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  double x4 = va_arg(l, double);
  int x5 = va_arg(l, int);
  char * x6 = va_arg(l, char *);
  int x7 = va_arg(l, int);
  char * x8 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.82fcdap+5F);
  check (strcmp(x1, "av") == 0);
  check (x2 == 2112946337);
  check (strcmp(x3, "fo") == 0);
  check (x4 == -0x1.8c6ffa3db93a8p+3);
  check (x5 == -1411196581);
  check (strcmp(x6, "m") == 0);
  check (x7 == 1183197745);
  check (strcmp(x8, "zy") == 0);
  return 305707200;
}

unsigned short f482(double x0, float x1, char * x2, double x3, float x4, long long x5, double x6, ...)
{
  va_list l;
  va_start(l, x6);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  double x13 = va_arg(l, double);
  double x14 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.47dc78359c7fp+4);
  check (x1 == 0x1.fd8cbap+3F);
  check (strcmp(x2, "mu") == 0);
  check (x3 == 0x1.3520fbe826f1p+4);
  check (x4 == 0x1.7d8132p+4F);
  check (x5 == 8161909211195693285);
  check (x6 == 0x1.dc52ea5737428p+3);
  check (x7 == 0x1.78bf86ca8152p+0);
  check (x8 == -5238119274067864212);
  check (x9 == 1371665610);
  check (x10 == -1183020625);
  check (x11 == -1944016242);
  check (x12 == 5127346095352164750);
  check (x13 == 0x1.eb3c45ed7c108p+2);
  check (x14 == 0x1.d3382128b1cp+0);
  return 328161624;
}

void f483(int x0, char * x1, long long x2, float x3)
{
  check (x0 == 1990308632);
  check (strcmp(x1, "") == 0);
  check (x2 == -8208414291246551077);
  check (x3 == -0x1.72894ap+5F);
}

void f484(long long x0, double x1, char * x2, ...)
{
  va_list l;
  va_start(l, x2);
  char * x3 = va_arg(l, char *);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  va_end(l);
  check (x0 == -2837839556032175157);
  check (x1 == 0x1.6245aad9bffdp+5);
  check (strcmp(x2, "k") == 0);
  check (strcmp(x3, "uc") == 0);
  check (x4 == 7745849908150609330);
  check (x5 == 2156536073251677927);
}

long long f485(int x0, float x1, double x2, ...)
{
  va_list l;
  va_start(l, x2);
  char * x3 = va_arg(l, char *);
  char * x4 = va_arg(l, char *);
  va_end(l);
  check (x0 == 1649678245);
  check (x1 == -0x1.cf8ca4p-5F);
  check (x2 == -0x1.28bf4b25638f1p+5);
  check (strcmp(x3, "bx") == 0);
  check (strcmp(x4, "v") == 0);
  return -7593823269043106072;
}

void f486(float x0, long long x1, long long x2, int x3, double x4, long long x5, double x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  char * x11 = va_arg(l, char *);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  double x15 = va_arg(l, double);
  char * x16 = va_arg(l, char *);
  int x17 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.6b046ap+4F);
  check (x1 == 1946252880016561096);
  check (x2 == 225316091108943196);
  check (x3 == 1900889988);
  check (x4 == 0x1.d503f33cf5ep-3);
  check (x5 == 3391719220547287569);
  check (x6 == 0x1.11e7e5339ac92p+5);
  check (x7 == -6761704709855275128);
  check (x8 == 695788152);
  check (x9 == 2717630359834829336);
  check (x10 == 1521664899);
  check (strcmp(x11, "gn") == 0);
  check (x12 == -1482873030786247727);
  check (x13 == 6128064440941605652);
  check (x14 == 1926528990);
  check (x15 == -0x1.06089d974a9p+1);
  check (strcmp(x16, "fp") == 0);
  check (x17 == 1108125219);
}

int f487(int x0, long long x1, double x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  int x4 = va_arg(l, int);
  long long x5 = va_arg(l, long long);
  char * x6 = va_arg(l, char *);
  char * x7 = va_arg(l, char *);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  long long x13 = va_arg(l, long long);
  char * x14 = va_arg(l, char *);
  va_end(l);
  check (x0 == 2076937530);
  check (x1 == 4496011919892396696);
  check (x2 == -0x1.935c880596bc6p+4);
  check (x3 == 2368047998335318973);
  check (x4 == -733820000);
  check (x5 == 5367072593640329219);
  check (strcmp(x6, "") == 0);
  check (strcmp(x7, "jx") == 0);
  check (x8 == -0x1.095abbc1c826p+2);
  check (x9 == -8102496600985539800);
  check (x10 == 698879239);
  check (x11 == -0x1.7b519f63e3949p+4);
  check (x12 == 0x1.11f91077b8f84p+4);
  check (x13 == -1103863388969090019);
  check (strcmp(x14, "pk") == 0);
  return 724735184;
}

void f488(double x0, ...)
{
  va_list l;
  va_start(l, x0);
  char * x1 = va_arg(l, char *);
  long long x2 = va_arg(l, long long);
  char * x3 = va_arg(l, char *);
  char * x4 = va_arg(l, char *);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  int x7 = va_arg(l, int);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.9fd483d4d59a8p+4);
  check (strcmp(x1, "o") == 0);
  check (x2 == -1505681063745686924);
  check (strcmp(x3, "") == 0);
  check (strcmp(x4, "go") == 0);
  check (x5 == -0x1.102a7df0ce6b6p+5);
  check (x6 == -0x1.4c44551302487p+5);
  check (x7 == -719239906);
  check (x8 == 0x1.aa25df777d93p+1);
  check (x9 == -0x1.880565ee32552p+5);
  check (x10 == 6536561442510662059);
}

void f489(int x0, ...)
{
  va_list l;
  va_start(l, x0);
  long long x1 = va_arg(l, long long);
  char * x2 = va_arg(l, char *);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  double x8 = va_arg(l, double);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  va_end(l);
  check (x0 == 556137699);
  check (x1 == -8506443797512955591);
  check (strcmp(x2, "d") == 0);
  check (x3 == -3870457569821168887);
  check (x4 == 4273485909301346191);
  check (x5 == -742077583);
  check (x6 == 1512685080);
  check (x7 == 5801394799897302686);
  check (x8 == 0x1.7e3c1ca2f585ep+5);
  check (strcmp(x9, "") == 0);
  check (x10 == 1974404511);
  check (x11 == 0x1.1a4b5762c3d88p+4);
}

void f490(double x0, ...)
{
  va_list l;
  va_start(l, x0);
  long long x1 = va_arg(l, long long);
  char * x2 = va_arg(l, char *);
  long long x3 = va_arg(l, long long);
  double x4 = va_arg(l, double);
  long long x5 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.06debece9f29p+3);
  check (x1 == 7395079662439375560);
  check (strcmp(x2, "") == 0);
  check (x3 == -1195092298507015320);
  check (x4 == -0x1.82c477dd97851p+5);
  check (x5 == 3399467016899805619);
}

float f491(int x0, long long x1, long long x2, double x3, ...)
{
  va_list l;
  va_start(l, x3);
  char * x4 = va_arg(l, char *);
  long long x5 = va_arg(l, long long);
  double x6 = va_arg(l, double);
  int x7 = va_arg(l, int);
  char * x8 = va_arg(l, char *);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  char * x11 = va_arg(l, char *);
  double x12 = va_arg(l, double);
  va_end(l);
  check (x0 == -625320957);
  check (x1 == -1525701813325274915);
  check (x2 == -2423513978029863395);
  check (x3 == 0x1.c2d6cca0cde3p+2);
  check (strcmp(x4, "") == 0);
  check (x5 == -245139832763243504);
  check (x6 == -0x1.1b78ab179b4bp+5);
  check (x7 == 1151193352);
  check (strcmp(x8, "kb") == 0);
  check (x9 == 0x1.f57f2eefe288p+1);
  check (x10 == -0x1.5bf4d874b3985p+4);
  check (strcmp(x11, "") == 0);
  check (x12 == 0x1.442d61bcab214p+5);
  return 0x1.3fa7f91e668ap+2;
}

void f492(long long x0, float x1, char * x2, double x3, double x4, float x5, long long x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  char * x10 = va_arg(l, char *);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  char * x13 = va_arg(l, char *);
  int x14 = va_arg(l, int);
  double x15 = va_arg(l, double);
  int x16 = va_arg(l, int);
  va_end(l);
  check (x0 == 2499137313056970316);
  check (x1 == 0x1.81f942p+4F);
  check (strcmp(x2, "") == 0);
  check (x3 == -0x1.5702e13467138p+3);
  check (x4 == -0x1.7e1338b9b9f6dp+5);
  check (x5 == -0x1.2b217ep+2F);
  check (x6 == 3409169819483140607);
  check (x7 == 1941106801);
  check (x8 == -850841273);
  check (x9 == 1521652897);
  check (strcmp(x10, "ik") == 0);
  check (x11 == -4248151032378236044);
  check (x12 == -299454802);
  check (strcmp(x13, "yl") == 0);
  check (x14 == 1737133976);
  check (x15 == -0x1.4581fdf8ed814p+4);
  check (x16 == 881421933);
}

signed char f493(double x0, ...)
{
  va_list l;
  va_start(l, x0);
  char * x1 = va_arg(l, char *);
  double x2 = va_arg(l, double);
  char * x3 = va_arg(l, char *);
  int x4 = va_arg(l, int);
  char * x5 = va_arg(l, char *);
  char * x6 = va_arg(l, char *);
  int x7 = va_arg(l, int);
  long long x8 = va_arg(l, long long);
  int x9 = va_arg(l, int);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.b3e7f73929a8p+0);
  check (strcmp(x1, "") == 0);
  check (x2 == -0x1.e1fd6f3fa215p+1);
  check (strcmp(x3, "") == 0);
  check (x4 == 643099168);
  check (strcmp(x5, "k") == 0);
  check (strcmp(x6, "qv") == 0);
  check (x7 == 1060013639);
  check (x8 == -5649686171471899207);
  check (x9 == 322030614);
  check (strcmp(x10, "") == 0);
  check (x11 == 0x1.173d10ed86c1cp+4);
  check (x12 == 1255040962);
  return -363374247;
}

short f494(double x0, char * x1, double x2, double x3, int x4, float x5, long long x6, long long x7, ...)
{
  va_list l;
  va_start(l, x7);
  double x8 = va_arg(l, double);
  int x9 = va_arg(l, int);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  long long x14 = va_arg(l, long long);
  char * x15 = va_arg(l, char *);
  double x16 = va_arg(l, double);
  int x17 = va_arg(l, int);
  double x18 = va_arg(l, double);
  char * x19 = va_arg(l, char *);
  va_end(l);
  check (x0 == 0x1.27f21c01160f8p+3);
  check (strcmp(x1, "nq") == 0);
  check (x2 == 0x1.ce9275e14c0cp+3);
  check (x3 == -0x1.41ee620acd564p+5);
  check (x4 == 354381792);
  check (x5 == -0x1.1e47bcp+5F);
  check (x6 == 1316630861071370470);
  check (x7 == 6316264718836293419);
  check (x8 == 0x1.09191db9e3p+5);
  check (x9 == 437596463);
  check (x10 == -0x1.0b4a4141c3a57p+5);
  check (x11 == -0x1.47f0aaed59b57p+5);
  check (x12 == 31328260);
  check (x13 == 1229202954074516754);
  check (x14 == 6409107729878666053);
  check (strcmp(x15, "") == 0);
  check (x16 == -0x1.df5a8fecc5636p+4);
  check (x17 == 1870791342);
  check (x18 == -0x1.06ee5c7d9d7fap+5);
  check (strcmp(x19, "z") == 0);
  return -386043006;
}

long long f495(double x0, float x1, float x2, double x3, ...)
{
  va_list l;
  va_start(l, x3);
  char * x4 = va_arg(l, char *);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  char * x8 = va_arg(l, char *);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.2f240463c4978p+4);
  check (x1 == 0x1.d16e56p+4F);
  check (x2 == 0x1.77ea6cp+4F);
  check (x3 == -0x1.1cbe25546f428p+3);
  check (strcmp(x4, "") == 0);
  check (x5 == -537405277);
  check (x6 == 775164369);
  check (x7 == -5797071416553158081);
  check (strcmp(x8, "sm") == 0);
  check (strcmp(x9, "") == 0);
  check (x10 == 1651144867);
  check (x11 == 0x1.795923ecad484p+4);
  return -7953726854742778049;
}

void f496(double x0, long long x1, int x2, double x3, int x4, char * x5, double x6, float x7, char * x8, ...)
{
  va_list l;
  va_start(l, x8);
  int x9 = va_arg(l, int);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  long long x13 = va_arg(l, long long);
  double x14 = va_arg(l, double);
  long long x15 = va_arg(l, long long);
  double x16 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.0d7e05d60b6ep+4);
  check (x1 == 924974350230110704);
  check (x2 == -1105436760);
  check (x3 == -0x1.fef6bedb7b6dp+3);
  check (x4 == -474052090);
  check (strcmp(x5, "h") == 0);
  check (x6 == 0x1.8bfc096d682f6p+5);
  check (x7 == -0x1.6ac36p+3F);
  check (strcmp(x8, "x") == 0);
  check (x9 == 299869371);
  check (x10 == 0x1.2a9dc336cc4ep+1);
  check (x11 == 0x1.8645a5f37ec36p+5);
  check (x12 == 0x1.d9fa185b0678p-2);
  check (x13 == -107454757750749833);
  check (x14 == -0x1.9304b39574a2cp+3);
  check (x15 == 8991864676009315385);
  check (x16 == -0x1.3ee9ad754bce1p+4);
}

int f497(long long x0, char * x1, float x2, int x3, char * x4, float x5, double x6, char * x7, ...)
{
  va_list l;
  va_start(l, x7);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  double x14 = va_arg(l, double);
  double x15 = va_arg(l, double);
  double x16 = va_arg(l, double);
  char * x17 = va_arg(l, char *);
  char * x18 = va_arg(l, char *);
  double x19 = va_arg(l, double);
  va_end(l);
  check (x0 == 9067052149775252579);
  check (strcmp(x1, "am") == 0);
  check (x2 == -0x1.3f7ad6p+5F);
  check (x3 == -1531602223);
  check (strcmp(x4, "oj") == 0);
  check (x5 == -0x1.714fdep+4F);
  check (x6 == -0x1.49bdbdcfb143p+3);
  check (strcmp(x7, "") == 0);
  check (x8 == -1860971214);
  check (x9 == -3351872412661437216);
  check (x10 == -1423444904);
  check (x11 == 6536640503442391623);
  check (x12 == 0x1.73a1a83789456p+5);
  check (x13 == -0x1.10dc5aebcfff2p+4);
  check (x14 == 0x1.52d530fbd82c8p+2);
  check (x15 == -0x1.bfd265ad4ef8dp+4);
  check (x16 == -0x1.2088592523f88p+5);
  check (strcmp(x17, "mj") == 0);
  check (strcmp(x18, "") == 0);
  check (x19 == -0x1.fc610f5bd49cep+4);
  return 189252878;
}

char * f498(double x0, double x1, int x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.78e74e7b4e7bp+5);
  check (x1 == 0x1.1d192d6665684p+5);
  check (x2 == 609386512);
  check (x3 == 515880579105358902);
  check (x4 == 7803400743594830996);
  check (x5 == -0x1.c0d8fc93947acp+3);
  return "";
}

void f499(void)
{
}

unsigned char f500(float x0, double x1, double x2, int x3, long long x4, ...)
{
  va_list l;
  va_start(l, x4);
  int x5 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.7137bcp+5F);
  check (x1 == 0x1.083b8670578e8p+4);
  check (x2 == 0x1.341f3b9c9808p+1);
  check (x3 == 82124363);
  check (x4 == 4273729732326104388);
  check (x5 == 616046139);
  return 18020773;
}

void f501(void)
{
}

void f502(char * x0, char * x1, double x2, double x3, double x4, char * x5, float x6, float x7, char * x8, char * x9, ...)
{
  va_list l;
  va_start(l, x9);
  double x10 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "nw") == 0);
  check (strcmp(x1, "ng") == 0);
  check (x2 == -0x1.b703520af0abp+2);
  check (x3 == -0x1.ccceafe3e0eccp+4);
  check (x4 == 0x1.30526ee7f0dcep+5);
  check (strcmp(x5, "ph") == 0);
  check (x6 == 0x1.49f386p+5F);
  check (x7 == 0x1.e7efb2p+4F);
  check (strcmp(x8, "qt") == 0);
  check (strcmp(x9, "") == 0);
  check (x10 == -0x1.d63bf428445ep+4);
}

void f503(int x0, double x1, float x2, float x3, int x4, float x5, long long x6, ...)
{
  va_list l;
  va_start(l, x6);
  char * x7 = va_arg(l, char *);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  va_end(l);
  check (x0 == 1798878281);
  check (x1 == -0x1.0b8ac1b2292a8p+3);
  check (x2 == -0x1.8ecd6ep+5F);
  check (x3 == -0x1.69da92p+4F);
  check (x4 == -1335348672);
  check (x5 == -0x1.4a5a7p+0F);
  check (x6 == 8738125266098186668);
  check (strcmp(x7, "") == 0);
  check (x8 == -1446268868);
  check (x9 == 0x1.bf8f1fc760338p+3);
  check (x10 == -0x1.de94b9344fad8p+3);
}

signed char f504(int x0, char * x1, int x2, char * x3, double x4, int x5, int x6, float x7, double x8, ...)
{
  va_list l;
  va_start(l, x8);
  char * x9 = va_arg(l, char *);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  int x13 = va_arg(l, int);
  va_end(l);
  check (x0 == 244509094);
  check (strcmp(x1, "") == 0);
  check (x2 == 770552651);
  check (strcmp(x3, "u") == 0);
  check (x4 == -0x1.30e09eae206f7p+4);
  check (x5 == 1597672026);
  check (x6 == -118654103);
  check (x7 == 0x1.85e3cp+4F);
  check (x8 == 0x1.de379b44080ap+4);
  check (strcmp(x9, "nr") == 0);
  check (strcmp(x10, "") == 0);
  check (x11 == 0x1.e36b20c9faa94p+4);
  check (x12 == -2748047483634507751);
  check (x13 == -1104646640);
  return 187233868;
}

void f505(char * x0, char * x1, double x2, float x3)
{
  check (strcmp(x0, "ex") == 0);
  check (strcmp(x1, "e") == 0);
  check (x2 == 0x1.790af46748624p+5);
  check (x3 == 0x1.5398dp+5F);
}

void f506(double x0, float x1, double x2, char * x3, float x4, char * x5, char * x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  int x13 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.1a5c776bd9de4p+3);
  check (x1 == 0x1.0396c4p+2F);
  check (x2 == 0x1.e1c6016d5851p+4);
  check (strcmp(x3, "ga") == 0);
  check (x4 == 0x1.09a2f6p+2F);
  check (strcmp(x5, "b") == 0);
  check (strcmp(x6, "ib") == 0);
  check (x7 == -6558662452786854647);
  check (x8 == 1245572389);
  check (x9 == 0x1.6e14b0b7f8834p+4);
  check (x10 == -1694067589);
  check (x11 == -0x1.8f0074fb1ce2p+0);
  check (x12 == 1732907963720042730);
  check (x13 == 1646310654);
}

long long f507(int x0, char * x1, int x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  char * x4 = va_arg(l, char *);
  long long x5 = va_arg(l, long long);
  va_end(l);
  check (x0 == -651952185);
  check (strcmp(x1, "l") == 0);
  check (x2 == 1853001903);
  check (strcmp(x3, "nc") == 0);
  check (strcmp(x4, "g") == 0);
  check (x5 == -2601809875231634152);
  return 1930727983678913588;
}

void f508(float x0, double x1, double x2, double x3, ...)
{
  va_list l;
  va_start(l, x3);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  char * x8 = va_arg(l, char *);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  char * x11 = va_arg(l, char *);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  double x14 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.aaf274p+4F);
  check (x1 == -0x1.f3822e9e647cap+4);
  check (x2 == -0x1.76f5fed431e48p+2);
  check (x3 == -0x1.c9eb02682e57p+1);
  check (x4 == 0x1.2a08f961a36bap+5);
  check (x5 == 0x1.18e828387a5dp+4);
  check (strcmp(x6, "wx") == 0);
  check (x7 == 3981182153445660123);
  check (strcmp(x8, "") == 0);
  check (x9 == -1902437595);
  check (x10 == 1774891545);
  check (strcmp(x11, "") == 0);
  check (x12 == 1630948436);
  check (x13 == 1292718334);
  check (x14 == -0x1.0a02e01b96adcp+4);
}

void f509(long long x0, double x1, float x2, char * x3, double x4, double x5, char * x6, char * x7, float x8, char * x9, ...)
{
  va_list l;
  va_start(l, x9);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  long long x12 = va_arg(l, long long);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  long long x16 = va_arg(l, long long);
  long long x17 = va_arg(l, long long);
  double x18 = va_arg(l, double);
  long long x19 = va_arg(l, long long);
  int x20 = va_arg(l, int);
  va_end(l);
  check (x0 == -7952187229834953590);
  check (x1 == -0x1.5a6a8a48b6568p+3);
  check (x2 == 0x1.b83fap+4F);
  check (strcmp(x3, "tb") == 0);
  check (x4 == -0x1.4a18214f8c59ep+5);
  check (x5 == -0x1.892134fa25938p+5);
  check (strcmp(x6, "v") == 0);
  check (strcmp(x7, "") == 0);
  check (x8 == -0x1.cca53ep+4F);
  check (strcmp(x9, "rt") == 0);
  check (x10 == 6888358195601309165);
  check (strcmp(x11, "") == 0);
  check (x12 == 6771964114822910718);
  check (x13 == -1094672446);
  check (x14 == -344555233);
  check (x15 == -750146799510835077);
  check (x16 == -2468906402371680535);
  check (x17 == -5239875721579740148);
  check (x18 == -0x1.2a1fc984254dp+1);
  check (x19 == 7328451540451387922);
  check (x20 == -1575222014);
}

double f510(long long x0, int x1, long long x2, long long x3, long long x4, ...)
{
  va_list l;
  va_start(l, x4);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  va_end(l);
  check (x0 == -1017899302790885832);
  check (x1 == -176678215);
  check (x2 == -9089079110903146822);
  check (x3 == 926281361436496019);
  check (x4 == 3759872874475197959);
  check (x5 == 0x1.5a3847df2d774p+5);
  check (x6 == -0x1.809d2df4d3307p+5);
  check (x7 == -0x1.a402b97d26d9cp+3);
  check (x8 == 2057031648);
  check (x9 == -1507422706);
  return 0x1.0d281e8ab78ep+4;
}

short f511(char * x0, int x1, float x2, long long x3, long long x4, float x5, int x6, double x7, long long x8, long long x9, char * x10, ...)
{
  va_list l;
  va_start(l, x10);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  char * x13 = va_arg(l, char *);
  double x14 = va_arg(l, double);
  double x15 = va_arg(l, double);
  double x16 = va_arg(l, double);
  long long x17 = va_arg(l, long long);
  char * x18 = va_arg(l, char *);
  char * x19 = va_arg(l, char *);
  double x20 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "oq") == 0);
  check (x1 == -828344192);
  check (x2 == 0x1.d6f1dep+4F);
  check (x3 == 5828183684608355986);
  check (x4 == -3551820415930537204);
  check (x5 == 0x1.4e6c7ap+5F);
  check (x6 == -121574205);
  check (x7 == -0x1.9cab90221957ap+4);
  check (x8 == 1695238037491674857);
  check (x9 == 3602788237121354324);
  check (strcmp(x10, "") == 0);
  check (x11 == -0x1.3b70c7861208p-2);
  check (x12 == 9220487526464789609);
  check (strcmp(x13, "m") == 0);
  check (x14 == 0x1.764a74992f93p+2);
  check (x15 == -0x1.c7bd4c501ab24p+3);
  check (x16 == -0x1.ebd0bb9358f5p+3);
  check (x17 == -1029575674031138501);
  check (strcmp(x18, "nw") == 0);
  check (strcmp(x19, "wk") == 0);
  check (x20 == 0x1.b40e699c7e73p+1);
  return 39293760;
}

short f512(float x0, long long x1, float x2, double x3, long long x4, long long x5, double x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  char * x8 = va_arg(l, char *);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  long long x11 = va_arg(l, long long);
  double x12 = va_arg(l, double);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  char * x16 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.3136d6p+4F);
  check (x1 == -5131772831501270453);
  check (x2 == 0x1.ac977ep+4F);
  check (x3 == 0x1.82e67a4751384p+4);
  check (x4 == -152046794516214871);
  check (x5 == -2686009953251989677);
  check (x6 == -0x1.6e3191be6d38p+0);
  check (x7 == 197508484);
  check (strcmp(x8, "b") == 0);
  check (strcmp(x9, "jy") == 0);
  check (x10 == 0x1.0df4a51a43b8cp+3);
  check (x11 == 6402972165995281082);
  check (x12 == 0x1.b578b90d096b8p+3);
  check (x13 == 905495105);
  check (x14 == 987947171);
  check (x15 == 305901769);
  check (strcmp(x16, "") == 0);
  return 41823136;
}

char * f513(float x0, char * x1, int x2, float x3)
{
  check (x0 == 0x1.5f25b2p+5F);
  check (strcmp(x1, "") == 0);
  check (x2 == 1247418810);
  check (x3 == -0x1.31216ep+5F);
  return "wf";
}

void f514(float x0, float x1)
{
  check (x0 == -0x1.31584ep+3F);
  check (x1 == 0x1.1062e8p+3F);
}

void f515(int x0, int x1, char * x2, ...)
{
  va_list l;
  va_start(l, x2);
  char * x3 = va_arg(l, char *);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  int x7 = va_arg(l, int);
  char * x8 = va_arg(l, char *);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  double x13 = va_arg(l, double);
  int x14 = va_arg(l, int);
  va_end(l);
  check (x0 == -59529341);
  check (x1 == -1942726981);
  check (strcmp(x2, "m") == 0);
  check (strcmp(x3, "rt") == 0);
  check (x4 == 7477404251717217658);
  check (x5 == -0x1.269dfb0336a08p+5);
  check (x6 == -0x1.5fadcb0f7bf22p+5);
  check (x7 == -458505438);
  check (strcmp(x8, "sl") == 0);
  check (strcmp(x9, "") == 0);
  check (x10 == -0x1.8104c1603f356p+5);
  check (x11 == -6484798746886086784);
  check (x12 == 123828328);
  check (x13 == -0x1.1526039885b44p+4);
  check (x14 == 2142119050);
}

void f516(char * x0, ...)
{
  va_list l;
  va_start(l, x0);
  long long x1 = va_arg(l, long long);
  long long x2 = va_arg(l, long long);
  double x3 = va_arg(l, double);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "x") == 0);
  check (x1 == 8983749367112252155);
  check (x2 == -2414032101388523989);
  check (x3 == 0x1.92697982f8f3p+3);
  check (x4 == -23983818591887564);
  check (x5 == 3739889602196038057);
  check (x6 == -1085086301);
  check (x7 == 0x1.c28098e6f743p+4);
}

void f517(int x0, int x1, char * x2, int x3, long long x4, char * x5, float x6, float x7, char * x8, ...)
{
  va_list l;
  va_start(l, x8);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  long long x11 = va_arg(l, long long);
  va_end(l);
  check (x0 == -571139464);
  check (x1 == 1270847116);
  check (strcmp(x2, "yc") == 0);
  check (x3 == 1411859401);
  check (x4 == -2491334963369161517);
  check (strcmp(x5, "c") == 0);
  check (x6 == -0x1.054e54p+5F);
  check (x7 == -0x1.23870ep+4F);
  check (strcmp(x8, "") == 0);
  check (x9 == 0x1.169dd9f8f68ep+2);
  check (x10 == -0x1.16a21ae0e0523p+5);
  check (x11 == -6814862987840914625);
}

unsigned char f518(long long x0, int x1, double x2, char * x3, double x4, int x5, long long x6, float x7)
{
  check (x0 == -4572740975018088296);
  check (x1 == 2061584246);
  check (x2 == -0x1.f65e093ab22ccp+3);
  check (strcmp(x3, "") == 0);
  check (x4 == 0x1.91d50bdf15e9p+3);
  check (x5 == 1210843119);
  check (x6 == 1709850131847537874);
  check (x7 == -0x1.edaa4ap+4F);
  return -439005426;
}

signed char f519(long long x0, float x1, long long x2, ...)
{
  va_list l;
  va_start(l, x2);
  int x3 = va_arg(l, int);
  long long x4 = va_arg(l, long long);
  int x5 = va_arg(l, int);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  va_end(l);
  check (x0 == -7759359980323158405);
  check (x1 == 0x1.90511ap+4F);
  check (x2 == 4427428993970271842);
  check (x3 == -799817705);
  check (x4 == 1447954731924560890);
  check (x5 == 1670122740);
  check (strcmp(x6, "") == 0);
  check (x7 == 7791722256667529060);
  check (x8 == -1936245491);
  check (x9 == -868390373);
  return -322849503;
}

void f520(float x0, float x1, char * x2, float x3, int x4, long long x5, double x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  char * x12 = va_arg(l, char *);
  char * x13 = va_arg(l, char *);
  double x14 = va_arg(l, double);
  double x15 = va_arg(l, double);
  double x16 = va_arg(l, double);
  char * x17 = va_arg(l, char *);
  double x18 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.c83862p+4F);
  check (x1 == 0x1.28f68p+5F);
  check (strcmp(x2, "u") == 0);
  check (x3 == -0x1.17db22p+5F);
  check (x4 == -1893609524);
  check (x5 == 1376561809374834330);
  check (x6 == 0x1.eeaa6b6a91e18p+3);
  check (x7 == -1141771397);
  check (x8 == 1059883812);
  check (x9 == 1878760592);
  check (x10 == -0x1.e886cf062a52p+2);
  check (x11 == 0x1.049032807fe86p+5);
  check (strcmp(x12, "g") == 0);
  check (strcmp(x13, "xy") == 0);
  check (x14 == 0x1.dba0cf17d5c2p+0);
  check (x15 == -0x1.bb82f7658dce8p+2);
  check (x16 == 0x1.44af287261b9p+5);
  check (strcmp(x17, "sg") == 0);
  check (x18 == 0x1.04b3ffdda70ep+3);
}

unsigned char f521(float x0, int x1, long long x2, double x3, int x4, long long x5, long long x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.3a99fp+5F);
  check (x1 == 216478274);
  check (x2 == 9214521487584816137);
  check (x3 == -0x1.402257a4c0f5p+5);
  check (x4 == -1702289222);
  check (x5 == 2373198978270937138);
  check (x6 == 9123128734294932014);
  check (x7 == 2523318209244906958);
  check (x8 == -1767283371374065002);
  check (strcmp(x9, "dc") == 0);
  check (x10 == 743288435);
  check (x11 == 0x1.5a6cd600652a4p+5);
  check (x12 == 0x1.650f1aa5f760ap+5);
  return -523337920;
}

void f522(float x0, float x1, int x2, double x3, ...)
{
  va_list l;
  va_start(l, x3);
  int x4 = va_arg(l, int);
  char * x5 = va_arg(l, char *);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  char * x8 = va_arg(l, char *);
  int x9 = va_arg(l, int);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.848f32p+5F);
  check (x1 == 0x1.8083ccp+3F);
  check (x2 == -2009376865);
  check (x3 == 0x1.bce36fe5a8a6cp+4);
  check (x4 == 959766711);
  check (strcmp(x5, "") == 0);
  check (x6 == -3937866228603091076);
  check (x7 == 3156430611373474695);
  check (strcmp(x8, "") == 0);
  check (x9 == -250480375);
  check (strcmp(x10, "c") == 0);
  check (x11 == -0x1.6427216f8d30ap+5);
  check (x12 == -2092803091);
}

float f523(float x0, int x1, double x2, double x3, float x4, double x5, int x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  char * x12 = va_arg(l, char *);
  long long x13 = va_arg(l, long long);
  char * x14 = va_arg(l, char *);
  double x15 = va_arg(l, double);
  double x16 = va_arg(l, double);
  char * x17 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.8ab0e4p+5F);
  check (x1 == -1481574566);
  check (x2 == 0x1.10b487eb50ca2p+5);
  check (x3 == -0x1.89c045c9cd963p+5);
  check (x4 == -0x1.124d3cp+3F);
  check (x5 == -0x1.f2565c40d9e54p+4);
  check (x6 == -496215247);
  check (x7 == -1442888657);
  check (x8 == 1752505881);
  check (x9 == 0x1.a13185832fdfp+3);
  check (x10 == 969690593);
  check (x11 == 0x1.ba0be4972f02p+3);
  check (strcmp(x12, "h") == 0);
  check (x13 == -1923305637321720560);
  check (strcmp(x14, "") == 0);
  check (x15 == 0x1.609c5fe7b49d4p+3);
  check (x16 == -0x1.1acee027c7cdap+5);
  check (strcmp(x17, "h") == 0);
  return -0x1.28bfda199ad88p+3;
}

unsigned short f524(int x0, long long x1, int x2, long long x3, float x4)
{
  check (x0 == 1480255774);
  check (x1 == -3073147713313255759);
  check (x2 == -1029372633);
  check (x3 == -5098863275645614687);
  check (x4 == -0x1.5b5bb6p+5F);
  return 485303843;
}

void f525(long long x0, double x1, int x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  long long x4 = va_arg(l, long long);
  int x5 = va_arg(l, int);
  va_end(l);
  check (x0 == -7409978769002218785);
  check (x1 == 0x1.2fcda58801954p+4);
  check (x2 == 55773943);
  check (strcmp(x3, "") == 0);
  check (x4 == 467835886182215763);
  check (x5 == -1579479498);
}

double f526(double x0, double x1, long long x2, char * x3, float x4, double x5, long long x6, float x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  double x12 = va_arg(l, double);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  char * x16 = va_arg(l, char *);
  double x17 = va_arg(l, double);
  char * x18 = va_arg(l, char *);
  va_end(l);
  check (x0 == 0x1.89842cb20daap+0);
  check (x1 == -0x1.2ac7594316abcp+3);
  check (x2 == -6232490480648844681);
  check (strcmp(x3, "ag") == 0);
  check (x4 == 0x1.20fa5ep+5F);
  check (x5 == 0x1.82921d7e89104p+4);
  check (x6 == -4873326973335777349);
  check (x7 == -0x1.b03f4ap+4F);
  check (x8 == -5658329014223809032);
  check (x9 == 7239803764381444189);
  check (x10 == 3395247704272537503);
  check (strcmp(x11, "x") == 0);
  check (x12 == 0x1.769b097923588p+4);
  check (x13 == -1761992647);
  check (x14 == 1002787026);
  check (x15 == 1523920409);
  check (strcmp(x16, "") == 0);
  check (x17 == 0x1.312102fd88518p+4);
  check (strcmp(x18, "r") == 0);
  return -0x1.7e86e135094d4p+4;
}

float f527(void)
{
  return -0x1.3407d4491ad32p+5;
}

short f528(char * x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  double x4 = va_arg(l, double);
  char * x5 = va_arg(l, char *);
  long long x6 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 0x1.4c22bc2f9b6dcp+4);
  check (x2 == 972527470);
  check (x3 == -5226027206361503183);
  check (x4 == -0x1.348295833a456p+5);
  check (strcmp(x5, "zl") == 0);
  check (x6 == -8816272440449236248);
  return 252894856;
}

void f529(void)
{
}

short f530(int x0, char * x1, float x2, double x3, float x4, int x5, ...)
{
  va_list l;
  va_start(l, x5);
  double x6 = va_arg(l, double);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  char * x10 = va_arg(l, char *);
  char * x11 = va_arg(l, char *);
  char * x12 = va_arg(l, char *);
  va_end(l);
  check (x0 == 972477848);
  check (strcmp(x1, "w") == 0);
  check (x2 == 0x1.c024ecp+4F);
  check (x3 == 0x1.79dd147362902p+5);
  check (x4 == -0x1.f698ap+0F);
  check (x5 == 1971094942);
  check (x6 == -0x1.369b87c374201p+4);
  check (x7 == 3004482235910548209);
  check (x8 == -1282551546);
  check (x9 == -1201220347013816886);
  check (strcmp(x10, "gu") == 0);
  check (strcmp(x11, "k") == 0);
  check (strcmp(x12, "b") == 0);
  return 497202762;
}

unsigned short f531(char * x0, int x1, double x2, double x3, char * x4, long long x5, float x6, char * x7, ...)
{
  va_list l;
  va_start(l, x7);
  char * x8 = va_arg(l, char *);
  long long x9 = va_arg(l, long long);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  double x16 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "o") == 0);
  check (x1 == 767709112);
  check (x2 == 0x1.2d4e736e702d4p+4);
  check (x3 == 0x1.5b90c048c9eap+5);
  check (strcmp(x4, "z") == 0);
  check (x5 == -861970088082761768);
  check (x6 == 0x1.9deee2p+4F);
  check (strcmp(x7, "ae") == 0);
  check (strcmp(x8, "") == 0);
  check (x9 == -7675337716757400194);
  check (strcmp(x10, "i") == 0);
  check (x11 == -0x1.6982e70e0e156p+4);
  check (x12 == 0x1.439cfc38c696p+5);
  check (x13 == -2416939910125236944);
  check (x14 == 2094574980);
  check (x15 == -9141091173761559155);
  check (x16 == 0x1.b991227dbd9ccp+3);
  return -189745097;
}

void f532(long long x0, double x1, float x2, float x3, float x4, char * x5, int x6, float x7, int x8, long long x9, ...)
{
  va_list l;
  va_start(l, x9);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  int x12 = va_arg(l, int);
  char * x13 = va_arg(l, char *);
  int x14 = va_arg(l, int);
  va_end(l);
  check (x0 == 8784686957353186823);
  check (x1 == -0x1.54833c5919be3p+5);
  check (x2 == -0x1.37fbb2p+3F);
  check (x3 == -0x1.4251a6p+4F);
  check (x4 == -0x1.7fb65p+2F);
  check (strcmp(x5, "my") == 0);
  check (x6 == 394073720);
  check (x7 == -0x1.9217dep+3F);
  check (x8 == -96573073);
  check (x9 == 8290516323485685336);
  check (x10 == -0x1.43a2b0d28abdfp+4);
  check (x11 == 754473761);
  check (x12 == 301625330);
  check (strcmp(x13, "q") == 0);
  check (x14 == 1815556357);
}

unsigned short f533(float x0, float x1, int x2, double x3, double x4, float x5, int x6, float x7, char * x8, double x9, long long x10, ...)
{
  va_list l;
  va_start(l, x10);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  double x16 = va_arg(l, double);
  char * x17 = va_arg(l, char *);
  double x18 = va_arg(l, double);
  long long x19 = va_arg(l, long long);
  double x20 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.cf2314p+3F);
  check (x1 == -0x1.10c196p+3F);
  check (x2 == 2136122701);
  check (x3 == -0x1.1a8c89bb7de2ap+5);
  check (x4 == 0x1.2631d0908f4bp+2);
  check (x5 == -0x1.597544p+5F);
  check (x6 == 1709552844);
  check (x7 == 0x1.a4089cp+4F);
  check (strcmp(x8, "") == 0);
  check (x9 == 0x1.e887c715617ccp+4);
  check (x10 == 2545769689655215965);
  check (x11 == -8093832326274495498);
  check (strcmp(x12, "e") == 0);
  check (x13 == 1819077510);
  check (x14 == 629841100);
  check (x15 == -9145413208239521943);
  check (x16 == -0x1.b740fef0ac19bp+4);
  check (strcmp(x17, "v") == 0);
  check (x18 == 0x1.a3682efe576e4p+4);
  check (x19 == -5878880310163128514);
  check (x20 == -0x1.e75638882546p+1);
  return 334157829;
}

void f534(double x0, double x1, long long x2, char * x3, int x4, char * x5, long long x6, long long x7, double x8, char * x9, int x10, ...)
{
  va_list l;
  va_start(l, x10);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  char * x13 = va_arg(l, char *);
  int x14 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.6a885804bf1p-1);
  check (x1 == -0x1.9d08e65ba8ae2p+4);
  check (x2 == -5194079658675282136);
  check (strcmp(x3, "z") == 0);
  check (x4 == -1751099162);
  check (strcmp(x5, "vr") == 0);
  check (x6 == 4369164843112851440);
  check (x7 == 23141014236653083);
  check (x8 == 0x1.06df3ac45b954p+3);
  check (strcmp(x9, "") == 0);
  check (x10 == 1418062658);
  check (x11 == 0x1.e049467cffe9cp+4);
  check (x12 == -1689564276640444071);
  check (strcmp(x13, "") == 0);
  check (x14 == 1511790788);
}

long long f535(char * x0, long long x1, long long x2, float x3, double x4, float x5, long long x6, ...)
{
  va_list l;
  va_start(l, x6);
  char * x7 = va_arg(l, char *);
  long long x8 = va_arg(l, long long);
  double x9 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 7893994441795009860);
  check (x2 == 3746295763452153143);
  check (x3 == 0x1.15490ep+5F);
  check (x4 == -0x1.44f120a52962ap+5);
  check (x5 == 0x1.8b2d84p+5F);
  check (x6 == 2259721128970133124);
  check (strcmp(x7, "") == 0);
  check (x8 == 6698804892780814335);
  check (x9 == 0x1.efdfb85ea0188p+4);
  return -2966051762440522075;
}

void f536(long long x0, char * x1, long long x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  va_end(l);
  check (x0 == -1496722834956437840);
  check (strcmp(x1, "") == 0);
  check (x2 == -5743784618782441441);
  check (strcmp(x3, "") == 0);
  check (x4 == 0x1.c01fe45a32a38p+4);
  check (x5 == 0x1.de98f8c0a4d8p+0);
  check (strcmp(x6, "") == 0);
  check (x7 == -9056188527555560148);
  check (x8 == 5072609348756823732);
  check (x9 == 1022212250);
  check (x10 == 1532022636);
  check (x11 == -7173590080507240407);
  check (x12 == 1148701616);
  check (x13 == 2921893121470474002);
  check (x14 == -465128987);
}

float f537(void)
{
  return -0x1.ae05618085459p+4;
}

unsigned char f538(double x0, float x1)
{
  check (x0 == -0x1.1bd04bffa9faep+4);
  check (x1 == 0x1.d5b2fap+3F);
  return -102027939;
}

short f539(double x0, int x1, int x2, char * x3, int x4, long long x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  char * x10 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.2f6a378286fb8p+2);
  check (x1 == -829089096);
  check (x2 == 1555262113);
  check (strcmp(x3, "s") == 0);
  check (x4 == -1555002920);
  check (x5 == 1428822819874240521);
  check (x6 == -2068468886);
  check (x7 == 2106273274);
  check (x8 == 227239238);
  check (x9 == -742870723);
  check (strcmp(x10, "d") == 0);
  return -322160786;
}

void f540(double x0, char * x1, float x2, double x3, long long x4, ...)
{
  va_list l;
  va_start(l, x4);
  int x5 = va_arg(l, int);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  long long x8 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.e3e28f96e4aep+2);
  check (strcmp(x1, "b") == 0);
  check (x2 == 0x1.643bfp+1F);
  check (x3 == 0x1.46509ff1ce478p+2);
  check (x4 == -3953951112177812083);
  check (x5 == -35829848);
  check (x6 == -6892021542998755305);
  check (x7 == 0x1.604d94cacba8cp+5);
  check (x8 == -2871603373389305324);
}

unsigned char f541(float x0, long long x1, int x2, int x3, double x4, double x5, int x6, char * x7, long long x8, int x9, char * x10, ...)
{
  va_list l;
  va_start(l, x10);
  int x11 = va_arg(l, int);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  int x14 = va_arg(l, int);
  double x15 = va_arg(l, double);
  double x16 = va_arg(l, double);
  char * x17 = va_arg(l, char *);
  long long x18 = va_arg(l, long long);
  long long x19 = va_arg(l, long long);
  int x20 = va_arg(l, int);
  double x21 = va_arg(l, double);
  char * x22 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.304dap+5F);
  check (x1 == 6353242918429893303);
  check (x2 == -479318415);
  check (x3 == -772674521);
  check (x4 == -0x1.6265ccc9ad1ap+0);
  check (x5 == 0x1.22632fa01544p+1);
  check (x6 == 640679940);
  check (strcmp(x7, "xm") == 0);
  check (x8 == -1414227088618573429);
  check (x9 == -1168033057);
  check (strcmp(x10, "d") == 0);
  check (x11 == -1363151946);
  check (x12 == -0x1.2ba7a953762p-1);
  check (x13 == 0x1.38de85e47683p+5);
  check (x14 == 1047562712);
  check (x15 == 0x1.d9d280937b24p+4);
  check (x16 == 0x1.e8cb333ebac7p+3);
  check (strcmp(x17, "") == 0);
  check (x18 == 3932303769132766187);
  check (x19 == 2510536494076463661);
  check (x20 == -1617227974);
  check (x21 == 0x1.187b3772b6108p+4);
  check (strcmp(x22, "c") == 0);
  return 531006380;
}

void f542(int x0, ...)
{
  va_list l;
  va_start(l, x0);
  double x1 = va_arg(l, double);
  char * x2 = va_arg(l, char *);
  int x3 = va_arg(l, int);
  int x4 = va_arg(l, int);
  long long x5 = va_arg(l, long long);
  long long x6 = va_arg(l, long long);
  int x7 = va_arg(l, int);
  char * x8 = va_arg(l, char *);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  va_end(l);
  check (x0 == 1262113270);
  check (x1 == 0x1.8d088f2125a4p+1);
  check (strcmp(x2, "") == 0);
  check (x3 == 74183402);
  check (x4 == 110340599);
  check (x5 == -6441231034753087305);
  check (x6 == -4042276067362204747);
  check (x7 == 1189239202);
  check (strcmp(x8, "") == 0);
  check (strcmp(x9, "qb") == 0);
  check (x10 == -1393053640);
  check (x11 == 148631831);
}

void f543(void)
{
}

void f544(char * x0, int x1, char * x2, float x3, char * x4, int x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  double x13 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "xn") == 0);
  check (x1 == 638707019);
  check (strcmp(x2, "sj") == 0);
  check (x3 == -0x1.877676p+3F);
  check (strcmp(x4, "l") == 0);
  check (x5 == -1480625252);
  check (x6 == 8696243274217057601);
  check (x7 == -1200358625);
  check (x8 == 1795411772);
  check (x9 == -0x1.8be5a0918676dp+5);
  check (x10 == 334111222);
  check (x11 == 2100974585877414477);
  check (strcmp(x12, "") == 0);
  check (x13 == 0x1.94c0bcd201c4cp+4);
}

void f545(long long x0, int x1, long long x2, double x3, int x4, ...)
{
  va_list l;
  va_start(l, x4);
  int x5 = va_arg(l, int);
  char * x6 = va_arg(l, char *);
  int x7 = va_arg(l, int);
  char * x8 = va_arg(l, char *);
  char * x9 = va_arg(l, char *);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  char * x12 = va_arg(l, char *);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  va_end(l);
  check (x0 == 7730231872730052573);
  check (x1 == -1205741730);
  check (x2 == -3274010710732184602);
  check (x3 == 0x1.0bdf642be232p+5);
  check (x4 == 1872115344);
  check (x5 == -1471691508);
  check (strcmp(x6, "") == 0);
  check (x7 == -1502339216);
  check (strcmp(x8, "h") == 0);
  check (strcmp(x9, "u") == 0);
  check (strcmp(x10, "ib") == 0);
  check (x11 == -0x1.9c6a8b3531a2p+2);
  check (strcmp(x12, "b") == 0);
  check (x13 == 1999880833);
  check (x14 == -8109088);
}

signed char f546(void)
{
  return -67278650;
}

void f547(float x0, int x1, char * x2, ...)
{
  va_list l;
  va_start(l, x2);
  char * x3 = va_arg(l, char *);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.7f945ap+4F);
  check (x1 == -1382248931);
  check (strcmp(x2, "p") == 0);
  check (strcmp(x3, "jy") == 0);
  check (x4 == -2113910881707529575);
  check (x5 == -0x1.667cf482e252p+5);
}

void f548(int x0, float x1, long long x2, double x3, double x4, ...)
{
  va_list l;
  va_start(l, x4);
  long long x5 = va_arg(l, long long);
  char * x6 = va_arg(l, char *);
  va_end(l);
  check (x0 == -353957268);
  check (x1 == 0x1.32913ap+3F);
  check (x2 == -4249896693879178290);
  check (x3 == -0x1.85abd17725d2cp+3);
  check (x4 == -0x1.7ed04068616efp+4);
  check (x5 == 7987477250887422933);
  check (strcmp(x6, "o") == 0);
}

signed char f549(long long x0, int x1, long long x2, double x3, long long x4, float x5, char * x6, double x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  int x11 = va_arg(l, int);
  double x12 = va_arg(l, double);
  char * x13 = va_arg(l, char *);
  char * x14 = va_arg(l, char *);
  long long x15 = va_arg(l, long long);
  double x16 = va_arg(l, double);
  int x17 = va_arg(l, int);
  long long x18 = va_arg(l, long long);
  int x19 = va_arg(l, int);
  va_end(l);
  check (x0 == 7410075724737335107);
  check (x1 == -1040532043);
  check (x2 == 3535838193547037023);
  check (x3 == 0x1.48ecc60ad72a4p+4);
  check (x4 == 1528369831060304550);
  check (x5 == 0x1.f8f3a4p+2F);
  check (strcmp(x6, "w") == 0);
  check (x7 == 0x1.2f87453d9bb28p+4);
  check (x8 == 1967884146437431789);
  check (x9 == -0x1.31da3ed09cc05p+4);
  check (x10 == -496650687397827104);
  check (x11 == -1480918338);
  check (x12 == -0x1.3c11f4f928684p+5);
  check (strcmp(x13, "") == 0);
  check (strcmp(x14, "f") == 0);
  check (x15 == -217003070902442168);
  check (x16 == 0x1.39655d3c8b53cp+4);
  check (x17 == -1454746890);
  check (x18 == 8554161589578494100);
  check (x19 == 190436192);
  return -190217927;
}

void f550(float x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  int x3 = va_arg(l, int);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  char * x9 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.0696ecp+5F);
  check (x1 == -751879081);
  check (x2 == -1463543090239527823);
  check (x3 == -1407985688);
  check (x4 == 160306366);
  check (x5 == -0x1.74a8af79cfb11p+5);
  check (x6 == -0x1.74d2cc0b44c03p+4);
  check (x7 == 0x1.81f5ba9d95ffp+5);
  check (x8 == 0x1.178360dababb2p+5);
  check (strcmp(x9, "e") == 0);
}

signed char f551(long long x0, float x1, int x2, char * x3, int x4, float x5)
{
  check (x0 == 8388536694602410541);
  check (x1 == 0x1.13bcccp+5F);
  check (x2 == 451430514);
  check (strcmp(x3, "") == 0);
  check (x4 == -785208510);
  check (x5 == -0x1.6492dcp+1F);
  return 317447107;
}

int f552(long long x0, float x1, float x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  long long x4 = va_arg(l, long long);
  char * x5 = va_arg(l, char *);
  va_end(l);
  check (x0 == 7746876322165760833);
  check (x1 == -0x1.5adadap+4F);
  check (x2 == -0x1.f5f036p+3F);
  check (strcmp(x3, "wd") == 0);
  check (x4 == -4829922143638835400);
  check (strcmp(x5, "") == 0);
  return 1789111052;
}

void f553(void)
{
}

char * f554(char * x0, long long x1, long long x2, long long x3, double x4, ...)
{
  va_list l;
  va_start(l, x4);
  long long x5 = va_arg(l, long long);
  char * x6 = va_arg(l, char *);
  int x7 = va_arg(l, int);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  char * x12 = va_arg(l, char *);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  char * x15 = va_arg(l, char *);
  double x16 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 4186213902172969692);
  check (x2 == 7064173624906808330);
  check (x3 == 6164530808455782707);
  check (x4 == 0x1.024be90a630bp+2);
  check (x5 == 8839513535509104275);
  check (strcmp(x6, "hb") == 0);
  check (x7 == -2052549188);
  check (x8 == -0x1.78fc3e97a5a43p+5);
  check (x9 == -2607177193378727911);
  check (x10 == 0x1.594735636dafp+5);
  check (x11 == 1847885607);
  check (strcmp(x12, "v") == 0);
  check (x13 == 3591550192550182094);
  check (x14 == 2057941646);
  check (strcmp(x15, "rc") == 0);
  check (x16 == -0x1.4f1ebf87ba684p+4);
  return "y";
}

int f555(int x0, char * x1, long long x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  char * x7 = va_arg(l, char *);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  va_end(l);
  check (x0 == 1397226439);
  check (strcmp(x1, "kl") == 0);
  check (x2 == -6390682720830159080);
  check (x3 == 3098191562268198506);
  check (x4 == 0x1.ed1d62c0d4548p+2);
  check (x5 == -0x1.51560054c096p+3);
  check (strcmp(x6, "") == 0);
  check (strcmp(x7, "") == 0);
  check (x8 == 1898098220);
  check (x9 == 679816092);
  check (x10 == -518341237);
  check (x11 == -1228507786728731217);
  check (strcmp(x12, "") == 0);
  return -269388257;
}

char * f556(int x0, long long x1, double x2, long long x3, char * x4, ...)
{
  va_list l;
  va_start(l, x4);
  char * x5 = va_arg(l, char *);
  double x6 = va_arg(l, double);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  int x9 = va_arg(l, int);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  va_end(l);
  check (x0 == 1255941764);
  check (x1 == -606350957517177638);
  check (x2 == -0x1.1675b557492a8p+5);
  check (x3 == -3846326204071899950);
  check (strcmp(x4, "") == 0);
  check (strcmp(x5, "") == 0);
  check (x6 == 0x1.a507362d07e2cp+4);
  check (x7 == -506521180009401055);
  check (x8 == -286015233);
  check (x9 == 1538536807);
  check (x10 == -6628117677660823713);
  check (x11 == -7509780196484447046);
  check (x12 == 170746462);
  return "xq";
}

void f557(double x0, long long x1, long long x2, long long x3, long long x4, float x5, float x6)
{
  check (x0 == -0x1.1fea08ef3be1cp+3);
  check (x1 == 1231000221965872253);
  check (x2 == 4298491641687918135);
  check (x3 == -6740767039821507648);
  check (x4 == -3510841410357832240);
  check (x5 == 0x1.f32bc2p+3F);
  check (x6 == -0x1.4280cep+3F);
}

void f558(float x0, double x1, int x2, int x3, long long x4, ...)
{
  va_list l;
  va_start(l, x4);
  int x5 = va_arg(l, int);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  long long x11 = va_arg(l, long long);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  double x14 = va_arg(l, double);
  double x15 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.166cfep+2F);
  check (x1 == 0x1.ab56ed9d4ee28p+4);
  check (x2 == 1754810215);
  check (x3 == 1375057869);
  check (x4 == -1957161966017920104);
  check (x5 == 1260490310);
  check (strcmp(x6, "n") == 0);
  check (x7 == -5674880395024575388);
  check (x8 == -1434475658);
  check (strcmp(x9, "nm") == 0);
  check (x10 == 0x1.6ce8f062df978p+4);
  check (x11 == 9165352564945872203);
  check (x12 == -0x1.69b275c85d357p+5);
  check (x13 == 0x1.6b0bf8016848p+5);
  check (x14 == 0x1.66a7435cef624p+5);
  check (x15 == 0x1.4bb59fac03872p+5);
}

void f559(int x0, char * x1, int x2, float x3, float x4, float x5, char * x6, char * x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  int x9 = va_arg(l, int);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  int x12 = va_arg(l, int);
  char * x13 = va_arg(l, char *);
  int x14 = va_arg(l, int);
  va_end(l);
  check (x0 == 1119881781);
  check (strcmp(x1, "o") == 0);
  check (x2 == 1724742225);
  check (x3 == 0x1.a6f6c6p+4F);
  check (x4 == 0x1.78dbfap+5F);
  check (x5 == 0x1.47d75p+5F);
  check (strcmp(x6, "e") == 0);
  check (strcmp(x7, "n") == 0);
  check (x8 == 3101986023843295641);
  check (x9 == -2048723949);
  check (x10 == 104642630134579599);
  check (strcmp(x11, "dk") == 0);
  check (x12 == 1338234810);
  check (strcmp(x13, "cq") == 0);
  check (x14 == -1771497900);
}

unsigned short f560(double x0, int x1, int x2, float x3, int x4, double x5, long long x6, int x7, char * x8, long long x9, float x10)
{
  check (x0 == -0x1.82001d30caf74p+5);
  check (x1 == -107726475);
  check (x2 == -1800383137);
  check (x3 == -0x1.35129ep+5F);
  check (x4 == -164186545);
  check (x5 == -0x1.62178ce68201cp+5);
  check (x6 == -5156292856568060212);
  check (x7 == 1418668653);
  check (strcmp(x8, "ga") == 0);
  check (x9 == -6310622347309610917);
  check (x10 == 0x1.59ac56p+2F);
  return -179388924;
}

void f561(float x0, float x1, int x2, int x3, char * x4, char * x5, ...)
{
  va_list l;
  va_start(l, x5);
  char * x6 = va_arg(l, char *);
  double x7 = va_arg(l, double);
  char * x8 = va_arg(l, char *);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.3c3714p+2F);
  check (x1 == -0x1.5024bp+5F);
  check (x2 == 862755397);
  check (x3 == 2091565542);
  check (strcmp(x4, "bd") == 0);
  check (strcmp(x5, "z") == 0);
  check (strcmp(x6, "c") == 0);
  check (x7 == 0x1.22efe0ce5f5cp+0);
  check (strcmp(x8, "li") == 0);
  check (strcmp(x9, "b") == 0);
  check (x10 == 704820973);
  check (x11 == 0x1.e84dd8e8923f8p+2);
  check (x12 == -0x1.6923f88bf92bep+5);
}

long long f562(int x0, ...)
{
  va_list l;
  va_start(l, x0);
  int x1 = va_arg(l, int);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  char * x4 = va_arg(l, char *);
  va_end(l);
  check (x0 == -772177932);
  check (x1 == 883921892);
  check (x2 == -0x1.e6574a1890688p+2);
  check (x3 == -1443315617672487977);
  check (strcmp(x4, "") == 0);
  return 7441097621895104987;
}

float f563(float x0, char * x1, float x2)
{
  check (x0 == -0x1.882aa8p+5F);
  check (strcmp(x1, "z") == 0);
  check (x2 == 0x1.5c3c5ep+5F);
  return -0x1.6550590883ab4p+4;
}

void f564(long long x0, float x1, float x2, int x3, int x4, ...)
{
  va_list l;
  va_start(l, x4);
  char * x5 = va_arg(l, char *);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  va_end(l);
  check (x0 == -2039294200464676978);
  check (x1 == 0x1.a79e2cp+4F);
  check (x2 == 0x1.6ef854p+5F);
  check (x3 == 147017829);
  check (x4 == -1431554094);
  check (strcmp(x5, "st") == 0);
  check (x6 == 1561180988);
  check (x7 == 6802559661172802502);
  check (x8 == -610797454);
}

short f565(float x0, float x1, long long x2, float x3, char * x4, int x5, int x6, float x7, double x8, int x9, double x10, ...)
{
  va_list l;
  va_start(l, x10);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  int x14 = va_arg(l, int);
  double x15 = va_arg(l, double);
  int x16 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.203284p+5F);
  check (x1 == 0x1.17ff4cp+5F);
  check (x2 == 4960990124650603468);
  check (x3 == -0x1.f1f0eap+4F);
  check (strcmp(x4, "c") == 0);
  check (x5 == -1914937311);
  check (x6 == 1738727781);
  check (x7 == 0x1.ed2a5p+3F);
  check (x8 == 0x1.6ce81d30fd00ap+5);
  check (x9 == -1196369579);
  check (x10 == -0x1.19c32c2d2b0e8p+5);
  check (x11 == 0x1.4a9881680bde4p+4);
  check (x12 == 0x1.01629918dc80ap+5);
  check (x13 == 0x1.4a4dab638692cp+5);
  check (x14 == -1947265083);
  check (x15 == 0x1.571fb14f4337cp+4);
  check (x16 == 1177886641);
  return 263663530;
}

unsigned short f566(double x0, double x1, float x2, int x3, char * x4, int x5, double x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.7fbbbc9c8bcc8p+2);
  check (x1 == 0x1.3e9e673e19bc6p+5);
  check (x2 == 0x1.9508dap+4F);
  check (x3 == -1975714379);
  check (strcmp(x4, "oq") == 0);
  check (x5 == 1561082007);
  check (x6 == 0x1.071db8efb91p-2);
  check (x7 == 2095285010);
  check (x8 == -0x1.805479e471f02p+5);
  check (x9 == -0x1.56147c8e81fp+4);
  check (x10 == 0x1.4b5d8544fe26ep+5);
  check (x11 == 489073228);
  return -379525376;
}

unsigned char f567(long long x0, double x1, char * x2, double x3, char * x4, float x5, double x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  double x8 = va_arg(l, double);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  va_end(l);
  check (x0 == 5392171703235331082);
  check (x1 == 0x1.3ae3ac1449152p+5);
  check (strcmp(x2, "") == 0);
  check (x3 == -0x1.68e05c62c5582p+5);
  check (strcmp(x4, "q") == 0);
  check (x5 == 0x1.37160cp+5F);
  check (x6 == 0x1.4a657cbb860dcp+4);
  check (x7 == -734859057);
  check (x8 == -0x1.f7eee2e4ecc4p-1);
  check (strcmp(x9, "") == 0);
  check (x10 == -5447626643971544640);
  check (x11 == -959017552);
  check (x12 == 5140727014358927006);
  return 371522144;
}

void f568(float x0, long long x1, float x2, long long x3, long long x4, double x5, long long x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.81246cp+4F);
  check (x1 == 1791195525044733894);
  check (x2 == 0x1.52c8ap+3F);
  check (x3 == 5100341654775555757);
  check (x4 == -1949854282280122798);
  check (x5 == -0x1.2355543423149p+5);
  check (x6 == 6581850378987397480);
  check (x7 == -394136027);
  check (x8 == 0x1.700fb78f99c76p+5);
  check (x9 == 0x1.54e62f91063ap+3);
  check (x10 == -2115523354);
}

void f569(double x0, ...)
{
  va_list l;
  va_start(l, x0);
  int x1 = va_arg(l, int);
  int x2 = va_arg(l, int);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  int x5 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.f920a16c7c081p+4);
  check (x1 == 2064650932);
  check (x2 == 204169512);
  check (x3 == 7039394762897550066);
  check (x4 == 8184586000491168676);
  check (x5 == 444568970);
}

void f570(void)
{
}

void f571(double x0, float x1, float x2, double x3, ...)
{
  va_list l;
  va_start(l, x3);
  double x4 = va_arg(l, double);
  long long x5 = va_arg(l, long long);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  char * x10 = va_arg(l, char *);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  long long x13 = va_arg(l, long long);
  char * x14 = va_arg(l, char *);
  double x15 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.3f31bc5752dd8p+5);
  check (x1 == 0x1.e6302ap+2F);
  check (x2 == -0x1.260238p+4F);
  check (x3 == -0x1.5038968442f7p+5);
  check (x4 == -0x1.7c611bb15840bp+5);
  check (x5 == -7298951395524275436);
  check (x6 == 917106162);
  check (x7 == 245813638);
  check (x8 == -0x1.4705ae50aab82p+5);
  check (x9 == -8652832969470019780);
  check (strcmp(x10, "") == 0);
  check (x11 == -5726123959703364059);
  check (strcmp(x12, "aj") == 0);
  check (x13 == -5582807806781207605);
  check (strcmp(x14, "r") == 0);
  check (x15 == 0x1.8b83870860548p+4);
}

void f572(int x0, char * x1, double x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  long long x6 = va_arg(l, long long);
  va_end(l);
  check (x0 == 1245122773);
  check (strcmp(x1, "") == 0);
  check (x2 == -0x1.8c0a8c6fb72bdp+5);
  check (strcmp(x3, "fn") == 0);
  check (x4 == 7723737855437059959);
  check (x5 == -4921753107660369630);
  check (x6 == 8320357314525756719);
}

void f573(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  char * x2 = va_arg(l, char *);
  char * x3 = va_arg(l, char *);
  char * x4 = va_arg(l, char *);
  int x5 = va_arg(l, int);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.d57795d911b18p+3);
  check (x1 == 1857771995);
  check (strcmp(x2, "ki") == 0);
  check (strcmp(x3, "jm") == 0);
  check (strcmp(x4, "i") == 0);
  check (x5 == -466476220);
  check (x6 == -5872853918910996267);
  check (x7 == -8473789874934999806);
}

void f574(double x0, float x1, int x2, double x3, int x4, long long x5, long long x6, long long x7, ...)
{
  va_list l;
  va_start(l, x7);
  char * x8 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.7e0cfc4647dap+5);
  check (x1 == 0x1.544be8p+5F);
  check (x2 == 1766434936);
  check (x3 == -0x1.bd64ae756b6fp+2);
  check (x4 == -1219694058);
  check (x5 == 1601712367660320974);
  check (x6 == 6583196504011463179);
  check (x7 == 5981059661437967017);
  check (strcmp(x8, "") == 0);
}

float f575(float x0, int x1, char * x2, double x3, int x4, int x5, int x6, ...)
{
  va_list l;
  va_start(l, x6);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  double x12 = va_arg(l, double);
  long long x13 = va_arg(l, long long);
  long long x14 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.f73cc8p+3F);
  check (x1 == 1411139781);
  check (strcmp(x2, "t") == 0);
  check (x3 == 0x1.87e4a619cb9fp+4);
  check (x4 == 626800579);
  check (x5 == -1476154551);
  check (x6 == 2103456633);
  check (x7 == 0x1.3aa7b0c141c58p+5);
  check (x8 == -1371413535);
  check (x9 == 131230215916667313);
  check (x10 == -0x1.854fcca858908p+2);
  check (x11 == 1785594678);
  check (x12 == -0x1.5ce0a35434049p+4);
  check (x13 == -2013525579165033210);
  check (x14 == 5316180501848133634);
  return -0x1.254464a2715f1p+5;
}

float f576(char * x0, float x1, long long x2, long long x3, double x4, double x5, int x6, float x7)
{
  check (strcmp(x0, "z") == 0);
  check (x1 == -0x1.0cf07cp+2F);
  check (x2 == -1083737581266618600);
  check (x3 == -4192230367285534420);
  check (x4 == -0x1.c1f36847c58b1p+4);
  check (x5 == -0x1.70aba36464586p+5);
  check (x6 == -1633862445);
  check (x7 == -0x1.4804cap+3F);
  return 0x1.136e654cb547cp+4;
}

void f577(long long x0, double x1, double x2, char * x3, int x4, double x5, char * x6, char * x7, int x8, char * x9, double x10, ...)
{
  va_list l;
  va_start(l, x10);
  char * x11 = va_arg(l, char *);
  double x12 = va_arg(l, double);
  char * x13 = va_arg(l, char *);
  long long x14 = va_arg(l, long long);
  char * x15 = va_arg(l, char *);
  long long x16 = va_arg(l, long long);
  char * x17 = va_arg(l, char *);
  long long x18 = va_arg(l, long long);
  int x19 = va_arg(l, int);
  va_end(l);
  check (x0 == -7998204164749943798);
  check (x1 == 0x1.ae629008d36c4p+3);
  check (x2 == -0x1.6ee51e96769f6p+5);
  check (strcmp(x3, "y") == 0);
  check (x4 == 1729019749);
  check (x5 == -0x1.d74b8c20395c3p+4);
  check (strcmp(x6, "m") == 0);
  check (strcmp(x7, "n") == 0);
  check (x8 == -1529292665);
  check (strcmp(x9, "") == 0);
  check (x10 == 0x1.62cbc453be42cp+3);
  check (strcmp(x11, "") == 0);
  check (x12 == -0x1.0d8c38576085p+5);
  check (strcmp(x13, "k") == 0);
  check (x14 == 6831612564546006264);
  check (strcmp(x15, "v") == 0);
  check (x16 == -770290849636613861);
  check (strcmp(x17, "jf") == 0);
  check (x18 == -6658814257162962508);
  check (x19 == 1760454807);
}

int f578(void)
{
  return -53771081;
}

void f579(long long x0, double x1, long long x2, double x3, float x4)
{
  check (x0 == 6874400531628409083);
  check (x1 == 0x1.7fd674de85848p+2);
  check (x2 == 2413132070650506650);
  check (x3 == -0x1.841dd26fb6d65p+5);
  check (x4 == -0x1.314a3ap+3F);
}

float f580(long long x0, int x1, int x2, long long x3, ...)
{
  va_list l;
  va_start(l, x3);
  double x4 = va_arg(l, double);
  long long x5 = va_arg(l, long long);
  int x6 = va_arg(l, int);
  char * x7 = va_arg(l, char *);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  va_end(l);
  check (x0 == -1200921070185497114);
  check (x1 == 723682123);
  check (x2 == -838699950);
  check (x3 == -2798077814189756999);
  check (x4 == -0x1.146137f209e58p+4);
  check (x5 == -2303308333142813984);
  check (x6 == 1867910889);
  check (strcmp(x7, "l") == 0);
  check (x8 == 0x1.36e24d9604de4p+5);
  check (x9 == -3805334446325926332);
  check (x10 == -934513081);
  check (x11 == -1341550829);
  return 0x1.5f60eb1979bd8p+4;
}

void f581(double x0, char * x1, char * x2, char * x3, long long x4, double x5, float x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  char * x11 = va_arg(l, char *);
  va_end(l);
  check (x0 == 0x1.62c7d8077c61cp+4);
  check (strcmp(x1, "i") == 0);
  check (strcmp(x2, "f") == 0);
  check (strcmp(x3, "r") == 0);
  check (x4 == -5639302176979454456);
  check (x5 == 0x1.c819222336acp+0);
  check (x6 == 0x1.7a6714p+5F);
  check (x7 == 1780294554);
  check (x8 == 5168305285845341942);
  check (strcmp(x9, "n") == 0);
  check (x10 == -488490490);
  check (strcmp(x11, "u") == 0);
}

void f582(float x0, int x1, double x2, float x3, float x4, int x5, double x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  double x13 = va_arg(l, double);
  char * x14 = va_arg(l, char *);
  int x15 = va_arg(l, int);
  int x16 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.de945ap+4F);
  check (x1 == 948082525);
  check (x2 == 0x1.24ca7116a4f6p+5);
  check (x3 == -0x1.675fd4p+3F);
  check (x4 == -0x1.8ea102p+5F);
  check (x5 == 1039480709);
  check (x6 == -0x1.51dccf3d527a4p+3);
  check (x7 == 3264011584981200754);
  check (x8 == 1237639062);
  check (strcmp(x9, "r") == 0);
  check (x10 == 1239697135);
  check (x11 == -869609986);
  check (x12 == -5619339265646166324);
  check (x13 == 0x1.6e44f85d59a3cp+5);
  check (strcmp(x14, "gv") == 0);
  check (x15 == 968056811);
  check (x16 == 984473993);
}

void f583(char * x0, float x1, int x2, long long x3, int x4, long long x5, char * x6, char * x7, double x8, double x9, char * x10, ...)
{
  va_list l;
  va_start(l, x10);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 0x1.3aba88p+4F);
  check (x2 == -232478720);
  check (x3 == -2998100074326028926);
  check (x4 == -1672035971);
  check (x5 == -4148810961608434490);
  check (strcmp(x6, "") == 0);
  check (strcmp(x7, "p") == 0);
  check (x8 == 0x1.313f55566144ap+5);
  check (x9 == 0x1.65f38cd2279b6p+5);
  check (strcmp(x10, "p") == 0);
  check (x11 == 0x1.9a748378ab37p+3);
  check (x12 == -637653982761750565);
}

double f584(int x0, ...)
{
  va_list l;
  va_start(l, x0);
  char * x1 = va_arg(l, char *);
  long long x2 = va_arg(l, long long);
  long long x3 = va_arg(l, long long);
  int x4 = va_arg(l, int);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  va_end(l);
  check (x0 == -2055222978);
  check (strcmp(x1, "yy") == 0);
  check (x2 == 4208852735004330834);
  check (x3 == -4673232213016711015);
  check (x4 == -195593720);
  check (x5 == 2120437856);
  check (x6 == -562581243);
  return -0x1.131b7e620d13p+2;
}

void f585(char * x0, char * x1, long long x2, int x3, double x4, float x5)
{
  check (strcmp(x0, "d") == 0);
  check (strcmp(x1, "h") == 0);
  check (x2 == 6647328201421121520);
  check (x3 == -937597927);
  check (x4 == 0x1.f8758e28c54f8p+4);
  check (x5 == -0x1.359fbep+5F);
}

int f586(void)
{
  return -1319154786;
}

int f587(void)
{
  return 344736865;
}

short f588(float x0, long long x1, double x2, long long x3, int x4, float x5, double x6, float x7, long long x8, float x9)
{
  check (x0 == 0x1.ed248ap+4F);
  check (x1 == 5909704293210198499);
  check (x2 == 0x1.13a09b5e0584cp+3);
  check (x3 == 1211651080908209059);
  check (x4 == -391304249);
  check (x5 == -0x1.fc878ap+2F);
  check (x6 == -0x1.b473118434533p+4);
  check (x7 == 0x1.8496ep+5F);
  check (x8 == -8395815346627644071);
  check (x9 == 0x1.1b29ep+5F);
  return 260556072;
}

int f589(int x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  char * x3 = va_arg(l, char *);
  long long x4 = va_arg(l, long long);
  int x5 = va_arg(l, int);
  char * x6 = va_arg(l, char *);
  va_end(l);
  check (x0 == 1558936214);
  check (x1 == 1284446448317536924);
  check (x2 == 1411241138106466469);
  check (strcmp(x3, "") == 0);
  check (x4 == 3887979282438863394);
  check (x5 == -283106386);
  check (strcmp(x6, "jy") == 0);
  return 228838927;
}

void f590(int x0, ...)
{
  va_list l;
  va_start(l, x0);
  char * x1 = va_arg(l, char *);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  double x6 = va_arg(l, double);
  long long x7 = va_arg(l, long long);
  double x8 = va_arg(l, double);
  va_end(l);
  check (x0 == 575891934);
  check (strcmp(x1, "w") == 0);
  check (x2 == 0x1.88ca481d600c2p+5);
  check (x3 == 6742533440532794600);
  check (x4 == -8462718044848788771);
  check (x5 == -2014644236662954408);
  check (x6 == -0x1.33b1b7fe2b7d8p+4);
  check (x7 == 3905611834053580771);
  check (x8 == 0x1.77bfa6c3f79a8p+2);
}

char * f591(float x0, int x1, long long x2, float x3, double x4, ...)
{
  va_list l;
  va_start(l, x4);
  long long x5 = va_arg(l, long long);
  int x6 = va_arg(l, int);
  char * x7 = va_arg(l, char *);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.3232cap+5F);
  check (x1 == 1545844966);
  check (x2 == -3696214788596571914);
  check (x3 == -0x1.0348c4p+2F);
  check (x4 == -0x1.9c0e6811c6361p+4);
  check (x5 == -4547715094048853101);
  check (x6 == -1934393619);
  check (strcmp(x7, "q") == 0);
  check (x8 == -1507750914);
  check (x9 == -3380424355536714386);
  check (x10 == 1454357008);
  check (x11 == -0x1.21a3bc54998d2p+5);
  check (x12 == -4667543389674695796);
  return "d";
}

unsigned char f592(long long x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  char * x2 = va_arg(l, char *);
  double x3 = va_arg(l, double);
  char * x4 = va_arg(l, char *);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  char * x8 = va_arg(l, char *);
  double x9 = va_arg(l, double);
  va_end(l);
  check (x0 == -6010526387574749282);
  check (x1 == -0x1.54cfaff3ed2b6p+5);
  check (strcmp(x2, "cy") == 0);
  check (x3 == 0x1.8389344353708p+4);
  check (strcmp(x4, "d") == 0);
  check (x5 == 0x1.7db44641b8accp+4);
  check (strcmp(x6, "rk") == 0);
  check (x7 == 1851361746258123059);
  check (strcmp(x8, "") == 0);
  check (x9 == -0x1.39c513f7c51a6p+4);
  return -283781041;
}

void f593(long long x0, ...)
{
  va_list l;
  va_start(l, x0);
  double x1 = va_arg(l, double);
  va_end(l);
  check (x0 == -1606293719242913555);
  check (x1 == -0x1.597554d97293ap+4);
}

void f594(int x0, long long x1, long long x2, float x3, long long x4, char * x5, float x6, double x7, ...)
{
  va_list l;
  va_start(l, x7);
  char * x8 = va_arg(l, char *);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  va_end(l);
  check (x0 == 613919097);
  check (x1 == -6839072874997353397);
  check (x2 == -1412880681287440009);
  check (x3 == -0x1.1ce698p+4F);
  check (x4 == -3210698475411362292);
  check (strcmp(x5, "") == 0);
  check (x6 == 0x1.8c1bap+5F);
  check (x7 == -0x1.6bbd3e7357b08p+4);
  check (strcmp(x8, "") == 0);
  check (strcmp(x9, "k") == 0);
  check (x10 == 4789690432534831324);
}

unsigned short f595(float x0, int x1, int x2, long long x3, char * x4, int x5, double x6, float x7)
{
  check (x0 == 0x1.9fb562p+3F);
  check (x1 == 91189867);
  check (x2 == 650714991);
  check (x3 == 5104098104168875624);
  check (strcmp(x4, "") == 0);
  check (x5 == -254870107);
  check (x6 == 0x1.7e4acfcb5e3b8p+5);
  check (x7 == 0x1.05c722p+4F);
  return 132118786;
}

void f596(int x0, float x1, int x2, long long x3, long long x4, char * x5, ...)
{
  va_list l;
  va_start(l, x5);
  char * x6 = va_arg(l, char *);
  va_end(l);
  check (x0 == 439592826);
  check (x1 == -0x1.d3fb64p+4F);
  check (x2 == 210246548);
  check (x3 == -6057735894740793294);
  check (x4 == -964723570602079407);
  check (strcmp(x5, "z") == 0);
  check (strcmp(x6, "y") == 0);
}

void f597(char * x0, int x1, char * x2, char * x3, float x4, int x5, float x6, char * x7, ...)
{
  va_list l;
  va_start(l, x7);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  char * x11 = va_arg(l, char *);
  long long x12 = va_arg(l, long long);
  char * x13 = va_arg(l, char *);
  char * x14 = va_arg(l, char *);
  char * x15 = va_arg(l, char *);
  double x16 = va_arg(l, double);
  double x17 = va_arg(l, double);
  int x18 = va_arg(l, int);
  char * x19 = va_arg(l, char *);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 1225247850);
  check (strcmp(x2, "eo") == 0);
  check (strcmp(x3, "") == 0);
  check (x4 == 0x1.dad08cp+0F);
  check (x5 == 566934922);
  check (x6 == 0x1.ac09aep+1F);
  check (strcmp(x7, "") == 0);
  check (x8 == -0x1.3441fd6a0b4dp+1);
  check (x9 == 0x1.34fd0580d0a88p+3);
  check (x10 == 0x1.b283eccf3b4a8p+4);
  check (strcmp(x11, "gl") == 0);
  check (x12 == -1437603341657675818);
  check (strcmp(x13, "") == 0);
  check (strcmp(x14, "vj") == 0);
  check (strcmp(x15, "") == 0);
  check (x16 == -0x1.4ee812e0c5f93p+4);
  check (x17 == 0x1.d42d725eda34cp+4);
  check (x18 == -86589506);
  check (strcmp(x19, "") == 0);
}

void f598(double x0, char * x1, double x2, int x3, char * x4, double x5, float x6, char * x7, double x8, int x9, ...)
{
  va_list l;
  va_start(l, x9);
  int x10 = va_arg(l, int);
  char * x11 = va_arg(l, char *);
  double x12 = va_arg(l, double);
  char * x13 = va_arg(l, char *);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  double x16 = va_arg(l, double);
  double x17 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.1b9c6d33b3694p+4);
  check (strcmp(x1, "bk") == 0);
  check (x2 == -0x1.1f06098a1e5a8p+4);
  check (x3 == -1661295811);
  check (strcmp(x4, "qo") == 0);
  check (x5 == -0x1.2d41d41a7e6fdp+4);
  check (x6 == 0x1.274238p+5F);
  check (strcmp(x7, "yi") == 0);
  check (x8 == 0x1.5aa5ce3c7ca3ap+5);
  check (x9 == 1214375879);
  check (x10 == -92492881);
  check (strcmp(x11, "lt") == 0);
  check (x12 == 0x1.2d36507d0cd78p+5);
  check (strcmp(x13, "") == 0);
  check (x14 == -433132298);
  check (x15 == -6638107430273770276);
  check (x16 == -0x1.73632fdb028f5p+5);
  check (x17 == 0x1.41e9d7bef6438p+2);
}

void f599(float x0, long long x1, long long x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.0a5c62p+3F);
  check (x1 == -1437248243466294719);
  check (x2 == 2192732621401526400);
  check (x3 == -2129777702216336045);
  check (x4 == 5488384474265387762);
  check (x5 == 0x1.b385552c78788p+3);
}

long long f600(long long x0, float x1, int x2, int x3, int x4, char * x5, float x6, char * x7, int x8, char * x9, double x10, ...)
{
  va_list l;
  va_start(l, x10);
  int x11 = va_arg(l, int);
  int x12 = va_arg(l, int);
  double x13 = va_arg(l, double);
  char * x14 = va_arg(l, char *);
  double x15 = va_arg(l, double);
  va_end(l);
  check (x0 == 8548938812409740645);
  check (x1 == -0x1.4fc516p+3F);
  check (x2 == 1923042089);
  check (x3 == 1720220438);
  check (x4 == 924625963);
  check (strcmp(x5, "") == 0);
  check (x6 == -0x1.74730cp+5F);
  check (strcmp(x7, "") == 0);
  check (x8 == 1243502182);
  check (strcmp(x9, "") == 0);
  check (x10 == -0x1.2ddc7a0ade424p+3);
  check (x11 == -2100580644);
  check (x12 == -1714656852);
  check (x13 == -0x1.d4f3aad90d5d8p+3);
  check (strcmp(x14, "dn") == 0);
  check (x15 == -0x1.5d4e40aebbe29p+4);
  return 7456500054151728525;
}

void f601(char * x0, char * x1, double x2, float x3, double x4, float x5, double x6, double x7, int x8, char * x9, int x10, ...)
{
  va_list l;
  va_start(l, x10);
  char * x11 = va_arg(l, char *);
  char * x12 = va_arg(l, char *);
  char * x13 = va_arg(l, char *);
  int x14 = va_arg(l, int);
  double x15 = va_arg(l, double);
  char * x16 = va_arg(l, char *);
  char * x17 = va_arg(l, char *);
  char * x18 = va_arg(l, char *);
  double x19 = va_arg(l, double);
  double x20 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "") == 0);
  check (x2 == -0x1.55dff485e9053p+5);
  check (x3 == -0x1.585982p+5F);
  check (x4 == -0x1.6ce4340eae608p+4);
  check (x5 == 0x1.888976p+5F);
  check (x6 == 0x1.827810f00f894p+5);
  check (x7 == -0x1.02409281a4de2p+5);
  check (x8 == -1361236657);
  check (strcmp(x9, "es") == 0);
  check (x10 == 462683981);
  check (strcmp(x11, "g") == 0);
  check (strcmp(x12, "hy") == 0);
  check (strcmp(x13, "") == 0);
  check (x14 == -849774625);
  check (x15 == 0x1.3a1a645fe6214p+4);
  check (strcmp(x16, "") == 0);
  check (strcmp(x17, "f") == 0);
  check (strcmp(x18, "d") == 0);
  check (x19 == 0x1.12f048530539cp+4);
  check (x20 == 0x1.c88880587df68p+4);
}

void f602(long long x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  char * x3 = va_arg(l, char *);
  char * x4 = va_arg(l, char *);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  va_end(l);
  check (x0 == -3225866366080192854);
  check (x1 == 7747388518188295935);
  check (x2 == 0x1.1dec18eae8248p+2);
  check (strcmp(x3, "tb") == 0);
  check (strcmp(x4, "te") == 0);
  check (x5 == 0x1.c21ede743b2ap+0);
  check (x6 == -0x1.eb6f51e88b8p-4);
  check (x7 == -0x1.4f7cf4b40c616p+5);
  check (x8 == -0x1.1c6c42d60d1f3p+5);
  check (x9 == -0x1.1b8e214012e5cp+5);
  check (x10 == -0x1.8afc5634b4a66p+5);
  check (x11 == -0x1.023631171e5c2p+4);
}

void f603(long long x0, double x1, int x2, float x3, int x4, int x5, float x6, float x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  double x9 = va_arg(l, double);
  va_end(l);
  check (x0 == -131759271021167308);
  check (x1 == -0x1.f1f246efa6519p+4);
  check (x2 == 2052229948);
  check (x3 == -0x1.5f5f1p+5F);
  check (x4 == 2018441658);
  check (x5 == -1256043477);
  check (x6 == 0x1.b9c42p+3F);
  check (x7 == -0x1.866bdep+5F);
  check (x8 == 2246125240120251299);
  check (x9 == -0x1.76783cd36aecp+5);
}

void f604(char * x0, int x1, long long x2, char * x3, double x4, float x5, char * x6, double x7, ...)
{
  va_list l;
  va_start(l, x7);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  char * x10 = va_arg(l, char *);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == -2080589611);
  check (x2 == -1008472608135867976);
  check (strcmp(x3, "ii") == 0);
  check (x4 == 0x1.85fe47498c9b6p+5);
  check (x5 == -0x1.eb1062p+4F);
  check (strcmp(x6, "d") == 0);
  check (x7 == 0x1.3efe10c3ba9dep+5);
  check (x8 == -812051159);
  check (x9 == -0x1.64e05607a5c34p+4);
  check (strcmp(x10, "a") == 0);
  check (x11 == -7413593815604792790);
  check (strcmp(x12, "nt") == 0);
  check (x13 == -1252423462);
  check (x14 == -707683619);
  check (x15 == -374879432);
}

signed char f605(float x0, char * x1, char * x2, int x3, char * x4, int x5, int x6, float x7)
{
  check (x0 == -0x1.e02662p+1F);
  check (strcmp(x1, "sc") == 0);
  check (strcmp(x2, "") == 0);
  check (x3 == -462044302);
  check (strcmp(x4, "") == 0);
  check (x5 == 955920632);
  check (x6 == -1280024851);
  check (x7 == -0x1.92e8d4p+2F);
  return 471667376;
}

void f606(char * x0, int x1, int x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  char * x4 = va_arg(l, char *);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  char * x7 = va_arg(l, char *);
  char * x8 = va_arg(l, char *);
  long long x9 = va_arg(l, long long);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  double x13 = va_arg(l, double);
  long long x14 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 1564872346);
  check (x2 == 907329276);
  check (x3 == -5173643799795348529);
  check (strcmp(x4, "tk") == 0);
  check (x5 == 1767739958);
  check (x6 == 1072912657);
  check (strcmp(x7, "w") == 0);
  check (strcmp(x8, "") == 0);
  check (x9 == 1060086561931974853);
  check (x10 == -879608095);
  check (x11 == -652945953);
  check (x12 == 7954915392307621442);
  check (x13 == -0x1.f91646acb0147p+4);
  check (x14 == 3418180576762642690);
}

char * f607(long long x0, double x1, double x2, int x3, long long x4, float x5)
{
  check (x0 == 8389549318565367211);
  check (x1 == 0x1.0b0daa3f4cdp+2);
  check (x2 == -0x1.6051c303892dap+5);
  check (x3 == 1595012736);
  check (x4 == 3939231186474907876);
  check (x5 == -0x1.adc19ap+1F);
  return "";
}

signed char f608(void)
{
  return 310992921;
}

int f609(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  char * x2 = va_arg(l, char *);
  long long x3 = va_arg(l, long long);
  char * x4 = va_arg(l, char *);
  char * x5 = va_arg(l, char *);
  double x6 = va_arg(l, double);
  char * x7 = va_arg(l, char *);
  char * x8 = va_arg(l, char *);
  double x9 = va_arg(l, double);
  char * x10 = va_arg(l, char *);
  long long x11 = va_arg(l, long long);
  double x12 = va_arg(l, double);
  long long x13 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.90ec560a932acp+3);
  check (x1 == -0x1.67aea5d95e551p+4);
  check (strcmp(x2, "") == 0);
  check (x3 == -8588638061169398311);
  check (strcmp(x4, "y") == 0);
  check (strcmp(x5, "") == 0);
  check (x6 == -0x1.093e1e0982c82p+4);
  check (strcmp(x7, "w") == 0);
  check (strcmp(x8, "") == 0);
  check (x9 == 0x1.f382758187514p+4);
  check (strcmp(x10, "iz") == 0);
  check (x11 == -1360992768432908900);
  check (x12 == -0x1.d1673c45b5c5fp+4);
  check (x13 == -2690279873019069672);
  return 269648066;
}

void f610(double x0, char * x1, int x2, long long x3, int x4, char * x5, double x6, double x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  double x9 = va_arg(l, double);
  char * x10 = va_arg(l, char *);
  char * x11 = va_arg(l, char *);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  double x14 = va_arg(l, double);
  long long x15 = va_arg(l, long long);
  double x16 = va_arg(l, double);
  int x17 = va_arg(l, int);
  double x18 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.0f118e36349c8p+2);
  check (strcmp(x1, "") == 0);
  check (x2 == -2075559511);
  check (x3 == 3519757924312170868);
  check (x4 == -698848033);
  check (strcmp(x5, "i") == 0);
  check (x6 == 0x1.9424ef5bf903cp+3);
  check (x7 == -0x1.75ec6eb13af4fp+5);
  check (x8 == 5187146857427162719);
  check (x9 == 0x1.7dbb5eb5ef11p+5);
  check (strcmp(x10, "a") == 0);
  check (strcmp(x11, "") == 0);
  check (x12 == 304988408);
  check (x13 == -9040502092554335374);
  check (x14 == -0x1.11c14fc52375cp+5);
  check (x15 == -2543939973448170113);
  check (x16 == 0x1.ef18b5e23e5ap+4);
  check (x17 == -923811976);
  check (x18 == 0x1.0d3d7aa3c3302p+5);
}

void f611(long long x0, float x1, float x2, char * x3, long long x4, ...)
{
  va_list l;
  va_start(l, x4);
  char * x5 = va_arg(l, char *);
  va_end(l);
  check (x0 == -5120240935899343292);
  check (x1 == -0x1.69c1dp+5F);
  check (x2 == 0x1.d8d3cep+4F);
  check (strcmp(x3, "f") == 0);
  check (x4 == 3934528999776025528);
  check (strcmp(x5, "ju") == 0);
}

void f612(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  long long x2 = va_arg(l, long long);
  va_end(l);
  check (x0 == 1819477407);
  check (x1 == -1203568227);
  check (x2 == 3694474857801203734);
}

signed char f613(int x0, float x1, float x2, float x3, long long x4, long long x5, char * x6, double x7, float x8, int x9, float x10)
{
  check (x0 == -1771306250);
  check (x1 == -0x1.b512c2p+2F);
  check (x2 == 0x1.2dff3cp-1F);
  check (x3 == -0x1.18044ep+4F);
  check (x4 == -2318183522248439844);
  check (x5 == 1650726648707629926);
  check (strcmp(x6, "j") == 0);
  check (x7 == -0x1.7febc382e794p-1);
  check (x8 == 0x1.81a32ap+5F);
  check (x9 == -28377364);
  check (x10 == -0x1.0f92a4p+3F);
  return -485981997;
}

float f614(char * x0, long long x1, float x2)
{
  check (strcmp(x0, "mj") == 0);
  check (x1 == -828899054996193599);
  check (x2 == -0x1.5eaaa2p+5F);
  return -0x1.239ff10e1e028p+3;
}

double f615(int x0, double x1, float x2, int x3, char * x4, float x5)
{
  check (x0 == -1812474834);
  check (x1 == 0x1.50da177eeb1dap+5);
  check (x2 == 0x1.e29c54p+4F);
  check (x3 == 1307541174);
  check (strcmp(x4, "") == 0);
  check (x5 == 0x1.1bfd9cp+5F);
  return 0x1.073138061cd8cp+3;
}

double f616(long long x0, int x1, char * x2, ...)
{
  va_list l;
  va_start(l, x2);
  int x3 = va_arg(l, int);
  int x4 = va_arg(l, int);
  long long x5 = va_arg(l, long long);
  long long x6 = va_arg(l, long long);
  char * x7 = va_arg(l, char *);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  va_end(l);
  check (x0 == -8615737153638088308);
  check (x1 == 1109910946);
  check (strcmp(x2, "gw") == 0);
  check (x3 == 1736923791);
  check (x4 == -2096866747);
  check (x5 == -4257582868174086548);
  check (x6 == 2181687769024172495);
  check (strcmp(x7, "") == 0);
  check (x8 == 0x1.20d6dd56c02dp+2);
  check (x9 == -6762082900715991516);
  check (x10 == 6145781177741228778);
  check (strcmp(x11, "") == 0);
  check (x12 == -0x1.0599e55570934p+3);
  check (x13 == -0x1.0a2e3f8756288p+2);
  return -0x1.dfc9a744a7c77p+4;
}

void f617(float x0, char * x1, int x2, float x3)
{
  check (x0 == -0x1.466e1cp+4F);
  check (strcmp(x1, "") == 0);
  check (x2 == 1756527267);
  check (x3 == 0x1.b2f874p+2F);
}

void f618(int x0, double x1, float x2)
{
  check (x0 == -1340624680);
  check (x1 == -0x1.2bf90d635c33p+1);
  check (x2 == -0x1.fd47aep+3F);
}

float f619(int x0, long long x1, long long x2, long long x3, long long x4, ...)
{
  va_list l;
  va_start(l, x4);
  int x5 = va_arg(l, int);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  char * x9 = va_arg(l, char *);
  va_end(l);
  check (x0 == -187959198);
  check (x1 == 208707181507894175);
  check (x2 == -5638103979469228455);
  check (x3 == 2984511488087942380);
  check (x4 == -7874804799140832543);
  check (x5 == -2113726061);
  check (x6 == -6213056264536725772);
  check (x7 == -0x1.30925cef0583bp+5);
  check (x8 == -1891148);
  check (strcmp(x9, "qa") == 0);
  return 0x1.5b468db993deap+5;
}

unsigned char f620(char * x0, char * x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  char * x4 = va_arg(l, char *);
  char * x5 = va_arg(l, char *);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "gh") == 0);
  check (x2 == 0x1.ca1c0acbf38bp+4);
  check (x3 == -0x1.c3fe99725be0cp+3);
  check (strcmp(x4, "fw") == 0);
  check (strcmp(x5, "") == 0);
  check (x6 == 2015901704);
  check (x7 == -8495424927078404014);
  return -499425696;
}

double f621(int x0, char * x1, long long x2, ...)
{
  va_list l;
  va_start(l, x2);
  char * x3 = va_arg(l, char *);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  long long x6 = va_arg(l, long long);
  char * x7 = va_arg(l, char *);
  char * x8 = va_arg(l, char *);
  long long x9 = va_arg(l, long long);
  va_end(l);
  check (x0 == -177189053);
  check (strcmp(x1, "") == 0);
  check (x2 == 7142449366587603624);
  check (strcmp(x3, "") == 0);
  check (x4 == -6364373401726786850);
  check (x5 == 5452076689348022708);
  check (x6 == 8804990196057740377);
  check (strcmp(x7, "gr") == 0);
  check (strcmp(x8, "") == 0);
  check (x9 == -8918805900708829346);
  return 0x1.78ea65ace86ep+3;
}

float f622(long long x0, long long x1, long long x2, int x3, char * x4, char * x5, float x6, float x7, int x8, double x9, ...)
{
  va_list l;
  va_start(l, x9);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  char * x12 = va_arg(l, char *);
  va_end(l);
  check (x0 == 547184949249757999);
  check (x1 == 5941739354517701838);
  check (x2 == -5346372466948576782);
  check (x3 == -1539047160);
  check (strcmp(x4, "l") == 0);
  check (strcmp(x5, "bb") == 0);
  check (x6 == -0x1.59c7bap+4F);
  check (x7 == -0x1.3c636cp+4F);
  check (x8 == -1977108359);
  check (x9 == 0x1.351ff6703987ap+5);
  check (x10 == 6171762307607568305);
  check (strcmp(x11, "ph") == 0);
  check (strcmp(x12, "ao") == 0);
  return 0x1.dcb4fb8d22c2p+4;
}

signed char f623(double x0, double x1, long long x2, long long x3, int x4, ...)
{
  va_list l;
  va_start(l, x4);
  char * x5 = va_arg(l, char *);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  long long x14 = va_arg(l, long long);
  int x15 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.0634c9cd0e7cep+5);
  check (x1 == 0x1.1e0869500c9fp+4);
  check (x2 == -3501619966134180474);
  check (x3 == 7271432008532077239);
  check (x4 == 1134273527);
  check (strcmp(x5, "z") == 0);
  check (strcmp(x6, "m") == 0);
  check (x7 == 5694669144119031793);
  check (x8 == -1993727952);
  check (x9 == -0x1.5e2933134a9e7p+5);
  check (x10 == -556108535);
  check (x11 == 1515181104527854772);
  check (x12 == -1930930757);
  check (x13 == -2106393457);
  check (x14 == -1513321562193627998);
  check (x15 == -1412480631);
  return 155737873;
}

char * f624(int x0, float x1, float x2, double x3, ...)
{
  va_list l;
  va_start(l, x3);
  char * x4 = va_arg(l, char *);
  int x5 = va_arg(l, int);
  double x6 = va_arg(l, double);
  int x7 = va_arg(l, int);
  long long x8 = va_arg(l, long long);
  int x9 = va_arg(l, int);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  va_end(l);
  check (x0 == -747559199);
  check (x1 == 0x1.6d19f2p+5F);
  check (x2 == -0x1.0c6478p+5F);
  check (x3 == -0x1.a1789deeee0ep+2);
  check (strcmp(x4, "xy") == 0);
  check (x5 == 273657478);
  check (x6 == 0x1.9e25d90444d64p+3);
  check (x7 == -589062463);
  check (x8 == 7759781279018340227);
  check (x9 == 301407843);
  check (x10 == -0x1.2a977fbcf6f4cp+4);
  check (x11 == -0x1.af307530058cp+0);
  check (x12 == 0x1.55d44b954553p+2);
  return "hc";
}

void f625(long long x0, int x1, char * x2, double x3, ...)
{
  va_list l;
  va_start(l, x3);
  int x4 = va_arg(l, int);
  char * x5 = va_arg(l, char *);
  char * x6 = va_arg(l, char *);
  int x7 = va_arg(l, int);
  long long x8 = va_arg(l, long long);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  va_end(l);
  check (x0 == -5043579740373115186);
  check (x1 == -765739729);
  check (strcmp(x2, "if") == 0);
  check (x3 == 0x1.553ed4c812c66p+5);
  check (x4 == -1450743264);
  check (strcmp(x5, "") == 0);
  check (strcmp(x6, "ic") == 0);
  check (x7 == 1528894666);
  check (x8 == -4295331302826968663);
  check (strcmp(x9, "z") == 0);
  check (x10 == -0x1.bfbe16ad9ecep+3);
  check (x11 == -1266232048);
}

void f626(int x0, long long x1, float x2, float x3, long long x4, float x5, int x6, ...)
{
  va_list l;
  va_start(l, x6);
  int x7 = va_arg(l, int);
  char * x8 = va_arg(l, char *);
  int x9 = va_arg(l, int);
  long long x10 = va_arg(l, long long);
  int x11 = va_arg(l, int);
  char * x12 = va_arg(l, char *);
  va_end(l);
  check (x0 == -1344926246);
  check (x1 == -421183147830527406);
  check (x2 == 0x1.2ff8c8p+1F);
  check (x3 == -0x1.534adp+4F);
  check (x4 == 8099629238747404336);
  check (x5 == 0x1.868fd6p+3F);
  check (x6 == -503133587);
  check (x7 == 1249838987);
  check (strcmp(x8, "io") == 0);
  check (x9 == 1082079563);
  check (x10 == -3918770263459058100);
  check (x11 == 1581668471);
  check (strcmp(x12, "t") == 0);
}

int f627(void)
{
  return -1829867664;
}

void f628(char * x0, long long x1, double x2, long long x3, double x4, int x5, long long x6, double x7, ...)
{
  va_list l;
  va_start(l, x7);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  double x10 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "oc") == 0);
  check (x1 == -9217538561892391980);
  check (x2 == 0x1.f3c0bcfd31bbp+3);
  check (x3 == -7946251573754236074);
  check (x4 == -0x1.343c7b71319dap+5);
  check (x5 == 1353035069);
  check (x6 == 7287745300589057960);
  check (x7 == -0x1.1e08cf0ff599cp+5);
  check (x8 == 1732066304);
  check (x9 == 0x1.f8cebf84eacf8p+4);
  check (x10 == 0x1.dabce41a4d2bp+3);
}

char * f629(long long x0, float x1, long long x2, char * x3, int x4, long long x5, double x6, ...)
{
  va_list l;
  va_start(l, x6);
  int x7 = va_arg(l, int);
  va_end(l);
  check (x0 == 146502663118481574);
  check (x1 == 0x1.0c9c62p+4F);
  check (x2 == 3815575656811470531);
  check (strcmp(x3, "u") == 0);
  check (x4 == 1679663445);
  check (x5 == -1395487532524630300);
  check (x6 == -0x1.576aae1a91839p+5);
  check (x7 == -1859589493);
  return "v";
}

void f630(long long x0, double x1, float x2, char * x3, int x4, double x5, float x6, float x7)
{
  check (x0 == 6569183602416844708);
  check (x1 == 0x1.48e7bf88427dp+5);
  check (x2 == -0x1.8cdb5p+5F);
  check (strcmp(x3, "e") == 0);
  check (x4 == 824291211);
  check (x5 == -0x1.8901bf59d7799p+5);
  check (x6 == -0x1.2bb3acp+5F);
  check (x7 == 0x1.5591d2p+5F);
}

void f631(double x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  int x2 = va_arg(l, int);
  double x3 = va_arg(l, double);
  double x4 = va_arg(l, double);
  char * x5 = va_arg(l, char *);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  char * x8 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.e89f1479d49c8p+2);
  check (x1 == -1495663381);
  check (x2 == 1656171470);
  check (x3 == -0x1.ea4cbd31d2fp+0);
  check (x4 == -0x1.1f8eabaf295d8p+4);
  check (strcmp(x5, "") == 0);
  check (x6 == 465606698);
  check (x7 == -0x1.2b48b1aefaf79p+4);
  check (strcmp(x8, "kk") == 0);
}

unsigned char f632(float x0, long long x1, double x2, long long x3, float x4, char * x5, ...)
{
  va_list l;
  va_start(l, x5);
  char * x6 = va_arg(l, char *);
  char * x7 = va_arg(l, char *);
  long long x8 = va_arg(l, long long);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.2fd294p+4F);
  check (x1 == -588463664444324021);
  check (x2 == -0x1.1e0a74b5dbd8p+4);
  check (x3 == -7207797486385991930);
  check (x4 == 0x1.12fc64p+2F);
  check (strcmp(x5, "") == 0);
  check (strcmp(x6, "") == 0);
  check (strcmp(x7, "") == 0);
  check (x8 == 6330759665922262785);
  check (strcmp(x9, "") == 0);
  check (x10 == -0x1.34374367fb95dp+4);
  check (x11 == -0x1.667e8e7d42e5p+5);
  check (x12 == 7384386207144349506);
  return -166218482;
}

void f633(char * x0, float x1, float x2, long long x3, char * x4, ...)
{
  va_list l;
  va_start(l, x4);
  double x5 = va_arg(l, double);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  long long x8 = va_arg(l, long long);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  char * x14 = va_arg(l, char *);
  int x15 = va_arg(l, int);
  double x16 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "cp") == 0);
  check (x1 == -0x1.eaca5p+3F);
  check (x2 == -0x1.a4b538p+4F);
  check (x3 == 1026451162850323114);
  check (strcmp(x4, "es") == 0);
  check (x5 == -0x1.15a163a71e64p-1);
  check (x6 == 1601993968);
  check (x7 == -116524704);
  check (x8 == 8552210943544301086);
  check (x9 == -85623240);
  check (x10 == 840736215);
  check (x11 == -1068888202);
  check (x12 == 3992442782739677467);
  check (x13 == -8703215556391474645);
  check (strcmp(x14, "u") == 0);
  check (x15 == -1350219812);
  check (x16 == -0x1.a8c3f074e2382p+4);
}

void f634(long long x0, char * x1, char * x2, double x3, char * x4, char * x5, char * x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  va_end(l);
  check (x0 == 3798273438506068514);
  check (strcmp(x1, "eg") == 0);
  check (strcmp(x2, "j") == 0);
  check (x3 == -0x1.2cc34f8b6bc78p+4);
  check (strcmp(x4, "") == 0);
  check (strcmp(x5, "cy") == 0);
  check (strcmp(x6, "") == 0);
  check (x7 == 1137340383);
  check (x8 == 3387893095306772005);
  check (x9 == -6669120512685267456);
}

void f635(int x0, int x1, float x2)
{
  check (x0 == -1088547301);
  check (x1 == -1258498568);
  check (x2 == 0x1.a60ccp+4F);
}

float f636(char * x0, int x1, float x2, long long x3, int x4, double x5, int x6, char * x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  int x9 = va_arg(l, int);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  double x13 = va_arg(l, double);
  double x14 = va_arg(l, double);
  double x15 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "r") == 0);
  check (x1 == 79782339);
  check (x2 == 0x1.36cac8p+5F);
  check (x3 == 8919041018464589865);
  check (x4 == 1155136068);
  check (x5 == -0x1.11de9e15ba0d8p+5);
  check (x6 == -1299285610);
  check (strcmp(x7, "tn") == 0);
  check (x8 == -6138261563589878042);
  check (x9 == -886630806);
  check (x10 == -0x1.1d6c0b0eed3cp+5);
  check (x11 == -1526803768);
  check (x12 == -7887639675954083565);
  check (x13 == -0x1.812699851687fp+5);
  check (x14 == 0x1.d7ea328ceda18p+4);
  check (x15 == -0x1.b2564c530c42dp+4);
  return -0x1.6d2337971de1fp+4;
}

void f637(char * x0, int x1, long long x2, long long x3, char * x4, double x5, int x6, float x7, char * x8, double x9, ...)
{
  va_list l;
  va_start(l, x9);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  char * x12 = va_arg(l, char *);
  double x13 = va_arg(l, double);
  int x14 = va_arg(l, int);
  char * x15 = va_arg(l, char *);
  va_end(l);
  check (strcmp(x0, "y") == 0);
  check (x1 == -816329033);
  check (x2 == -3741695569855730315);
  check (x3 == 2206563217582123786);
  check (strcmp(x4, "") == 0);
  check (x5 == -0x1.83460f9add948p+2);
  check (x6 == 2027963869);
  check (x7 == -0x1.214a8ep+5F);
  check (strcmp(x8, "xy") == 0);
  check (x9 == 0x1.a986265808eep+4);
  check (x10 == -2306280156297823933);
  check (x11 == 0x1.21e59905a3d2p+3);
  check (strcmp(x12, "rt") == 0);
  check (x13 == -0x1.50d8aa9e3486p+2);
  check (x14 == -1787510018);
  check (strcmp(x15, "qt") == 0);
}

unsigned short f638(float x0, long long x1, long long x2, ...)
{
  va_list l;
  va_start(l, x2);
  int x3 = va_arg(l, int);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.6bfc88p+5F);
  check (x1 == 349380893780640591);
  check (x2 == 2714783807000847261);
  check (x3 == 2117421366);
  check (x4 == 0x1.5d85bb0dd81p-1);
  check (x5 == -0x1.96eb21aa81ddfp+4);
  return -373039950;
}

void f639(int x0, int x1, long long x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  int x6 = va_arg(l, int);
  char * x7 = va_arg(l, char *);
  double x8 = va_arg(l, double);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  char * x11 = va_arg(l, char *);
  char * x12 = va_arg(l, char *);
  double x13 = va_arg(l, double);
  char * x14 = va_arg(l, char *);
  va_end(l);
  check (x0 == -1187953195);
  check (x1 == -1949769754);
  check (x2 == -1892650183612110446);
  check (x3 == 3496299691700584099);
  check (x4 == 1771475272);
  check (x5 == 0x1.2d4475201a99p+3);
  check (x6 == -822598276);
  check (strcmp(x7, "b") == 0);
  check (x8 == 0x1.326d98f0058ecp+5);
  check (strcmp(x9, "") == 0);
  check (x10 == 0x1.2a6a28a846bbap+5);
  check (strcmp(x11, "") == 0);
  check (strcmp(x12, "rp") == 0);
  check (x13 == 0x1.2361f15bea8a4p+5);
  check (strcmp(x14, "mb") == 0);
}

void f640(double x0, char * x1, float x2, int x3, int x4, double x5, char * x6, double x7, char * x8, ...)
{
  va_list l;
  va_start(l, x8);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.94167d62c0fap+3);
  check (strcmp(x1, "y") == 0);
  check (x2 == 0x1.394e6p+5F);
  check (x3 == -1587915109);
  check (x4 == -1088998360);
  check (x5 == -0x1.620e803e1568ep+5);
  check (strcmp(x6, "z") == 0);
  check (x7 == -0x1.8a7638c8147fdp+5);
  check (strcmp(x8, "wv") == 0);
  check (strcmp(x9, "xo") == 0);
  check (x10 == -2937526815564948103);
  check (x11 == 2600044501742680935);
}

int f641(char * x0, double x1, float x2, long long x3, float x4)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -0x1.1b7c460f5cfb4p+4);
  check (x2 == 0x1.eb1034p+2F);
  check (x3 == 4912913164045855025);
  check (x4 == 0x1.727e32p+4F);
  return 903768430;
}

void f642(int x0, char * x1, double x2, float x3, float x4)
{
  check (x0 == -1365273179);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.0d6b3f2ba8406p+5);
  check (x3 == 0x1.1a0ea6p+5F);
  check (x4 == -0x1.16ca82p+5F);
}

long long f643(double x0, int x1, int x2, float x3, double x4, long long x5, long long x6, char * x7, ...)
{
  va_list l;
  va_start(l, x7);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  double x12 = va_arg(l, double);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  char * x15 = va_arg(l, char *);
  char * x16 = va_arg(l, char *);
  char * x17 = va_arg(l, char *);
  double x18 = va_arg(l, double);
  int x19 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.25e3f779c6149p+4);
  check (x1 == 581861176);
  check (x2 == -683934681);
  check (x3 == -0x1.d724f8p+4F);
  check (x4 == 0x1.93a7575589bcp+4);
  check (x5 == -2506328392131763210);
  check (x6 == 3507097896546837780);
  check (strcmp(x7, "n") == 0);
  check (x8 == 2068784971);
  check (x9 == -0x1.0adae9998db44p+5);
  check (strcmp(x10, "") == 0);
  check (x11 == -0x1.4684769b6c3e3p+4);
  check (x12 == 0x1.5d09b8eafa48ap+5);
  check (x13 == -4590071897467501932);
  check (x14 == -990144499);
  check (strcmp(x15, "") == 0);
  check (strcmp(x16, "") == 0);
  check (strcmp(x17, "k") == 0);
  check (x18 == 0x1.33a669027e3eep+5);
  check (x19 == 2082035264);
  return -218982151881425774;
}

void f644(float x0, float x1, float x2, long long x3, char * x4, long long x5, long long x6, ...)
{
  va_list l;
  va_start(l, x6);
  int x7 = va_arg(l, int);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  char * x10 = va_arg(l, char *);
  char * x11 = va_arg(l, char *);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  long long x15 = va_arg(l, long long);
  int x16 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.5d6c7cp+0F);
  check (x1 == -0x1.e8df18p+4F);
  check (x2 == -0x1.3e72d8p+5F);
  check (x3 == 437621942423595983);
  check (strcmp(x4, "z") == 0);
  check (x5 == -5512698382316777594);
  check (x6 == -6455415996889137058);
  check (x7 == 1033505905);
  check (x8 == -0x1.dbaabe4870ap+3);
  check (x9 == 50425697929873964);
  check (strcmp(x10, "") == 0);
  check (strcmp(x11, "go") == 0);
  check (x12 == -1008554134638755647);
  check (x13 == 6913706153578024595);
  check (x14 == -258699417);
  check (x15 == 5514889292004705570);
  check (x16 == -1229601298);
}

float f645(int x0, char * x1, double x2, char * x3, long long x4, double x5, float x6, long long x7, ...)
{
  va_list l;
  va_start(l, x7);
  int x8 = va_arg(l, int);
  va_end(l);
  check (x0 == 2064578907);
  check (strcmp(x1, "") == 0);
  check (x2 == -0x1.00a621279c9b2p+4);
  check (strcmp(x3, "rv") == 0);
  check (x4 == -5622966164531639756);
  check (x5 == 0x1.dbdd67e18697p+4);
  check (x6 == -0x1.571af8p+4F);
  check (x7 == 2518812247611033146);
  check (x8 == -1044637563);
  return -0x1.f636db1fbf1f6p+4;
}

void f646(char * x0, char * x1, float x2, float x3)
{
  check (strcmp(x0, "s") == 0);
  check (strcmp(x1, "oo") == 0);
  check (x2 == 0x1.411be2p+4F);
  check (x3 == -0x1.f0f8fep+4F);
}

void f647(double x0, double x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  char * x4 = va_arg(l, char *);
  char * x5 = va_arg(l, char *);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  va_end(l);
  check (x0 == 0x1.af3032c2289fp+4);
  check (x1 == 0x1.f6668327e83a4p+4);
  check (x2 == 0x1.3c18ce556da24p+5);
  check (x3 == -3185181259585629561);
  check (strcmp(x4, "") == 0);
  check (strcmp(x5, "fj") == 0);
  check (x6 == 0x1.59c279d775aa4p+5);
  check (x7 == 0x1.43dc1f708306p+3);
}

float f648(float x0, int x1, float x2, long long x3, long long x4, double x5, double x6, int x7, int x8, long long x9, char * x10, ...)
{
  va_list l;
  va_start(l, x10);
  int x11 = va_arg(l, int);
  double x12 = va_arg(l, double);
  char * x13 = va_arg(l, char *);
  char * x14 = va_arg(l, char *);
  int x15 = va_arg(l, int);
  int x16 = va_arg(l, int);
  va_end(l);
  check (x0 == 0x1.11f86cp+5F);
  check (x1 == -1781855986);
  check (x2 == 0x1.75e512p+3F);
  check (x3 == -1323056392180592835);
  check (x4 == -5878885792793727526);
  check (x5 == 0x1.7b95dc7b3854p+4);
  check (x6 == -0x1.4f0c1995d8e19p+4);
  check (x7 == 1795264236);
  check (x8 == 1165422760);
  check (x9 == 5327301867136099849);
  check (strcmp(x10, "") == 0);
  check (x11 == 277219865);
  check (x12 == -0x1.1815877187afp+1);
  check (strcmp(x13, "") == 0);
  check (strcmp(x14, "") == 0);
  check (x15 == -1111465773);
  check (x16 == 1823669135);
  return 0x1.330f6810d8d7p+4;
}

char * f649(int x0, double x1, double x2, ...)
{
  va_list l;
  va_start(l, x2);
  char * x3 = va_arg(l, char *);
  long long x4 = va_arg(l, long long);
  long long x5 = va_arg(l, long long);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  double x8 = va_arg(l, double);
  va_end(l);
  check (x0 == -1697727152);
  check (x1 == -0x1.d2d01f8362adp+4);
  check (x2 == -0x1.0969589128b04p+5);
  check (strcmp(x3, "ky") == 0);
  check (x4 == -1311675918054309991);
  check (x5 == 5553966877889997251);
  check (x6 == 1733836014);
  check (x7 == -587926258);
  check (x8 == -0x1.7220d4eef37c8p+3);
  return "";
}

void f650(long long x0, float x1, float x2, long long x3, double x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  char * x6 = va_arg(l, char *);
  char * x7 = va_arg(l, char *);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  int x11 = va_arg(l, int);
  va_end(l);
  check (x0 == -2682452516823688473);
  check (x1 == 0x1.5afap+2F);
  check (x2 == -0x1.17679cp+4F);
  check (x3 == 3147568539306732941);
  check (x4 == -0x1.66f8dd703bf55p+5);
  check (x5 == 0x1.78679eb4611fep+5);
  check (strcmp(x6, "d") == 0);
  check (strcmp(x7, "") == 0);
  check (x8 == -0x1.98a03b38cdaefp+4);
  check (x9 == 0x1.30517bde86e4p+5);
  check (x10 == 8361950544101958725);
  check (x11 == 2008067230);
}

unsigned char f651(long long x0, long long x1, long long x2, char * x3, double x4, double x5, long long x6, ...)
{
  va_list l;
  va_start(l, x6);
  double x7 = va_arg(l, double);
  va_end(l);
  check (x0 == -1492856601456366813);
  check (x1 == 3210379746510596745);
  check (x2 == 1464362373363724668);
  check (strcmp(x3, "qb") == 0);
  check (x4 == 0x1.427a81ca2acap+5);
  check (x5 == -0x1.302570219f828p+5);
  check (x6 == 6737368438786276128);
  check (x7 == -0x1.93abadc78fa2p+3);
  return 349160973;
}

unsigned short f652(char * x0, ...)
{
  va_list l;
  va_start(l, x0);
  double x1 = va_arg(l, double);
  char * x2 = va_arg(l, char *);
  int x3 = va_arg(l, int);
  long long x4 = va_arg(l, long long);
  char * x5 = va_arg(l, char *);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "ko") == 0);
  check (x1 == 0x1.729808a4ab02p+4);
  check (strcmp(x2, "l") == 0);
  check (x3 == -124251942);
  check (x4 == -2600490318683432363);
  check (strcmp(x5, "v") == 0);
  check (strcmp(x6, "k") == 0);
  check (x7 == 2906665546869162569);
  return -175720499;
}

void f653(int x0, double x1, long long x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  long long x4 = va_arg(l, long long);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  va_end(l);
  check (x0 == 2006996479);
  check (x1 == 0x1.45ad8d1e7dab8p+3);
  check (x2 == -2342502688323166835);
  check (x3 == -5530637500125412312);
  check (x4 == -4303803848588391412);
  check (x5 == 0x1.525c42167573p+4);
  check (x6 == -0x1.28435be8753bdp+5);
  check (x7 == 0x1.ef0f38777a76p+0);
  check (x8 == -0x1.1d56224ab6cd2p+4);
}

void f654(int x0, long long x1, double x2, double x3, char * x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  char * x7 = va_arg(l, char *);
  char * x8 = va_arg(l, char *);
  va_end(l);
  check (x0 == -276065562);
  check (x1 == -4896889940483283061);
  check (x2 == -0x1.163fb3d9be854p+4);
  check (x3 == 0x1.884fcb2ff88bcp+3);
  check (strcmp(x4, "") == 0);
  check (x5 == 0x1.0a7b760b5c9ecp+3);
  check (x6 == -2100760464);
  check (strcmp(x7, "y") == 0);
  check (strcmp(x8, "j") == 0);
}

void f655(char * x0, float x1, int x2, float x3, int x4, float x5, double x6, int x7, int x8, ...)
{
  va_list l;
  va_start(l, x8);
  long long x9 = va_arg(l, long long);
  double x10 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "cp") == 0);
  check (x1 == -0x1.3a8a1ap+3F);
  check (x2 == 1899544549);
  check (x3 == -0x1.2dd0bp+5F);
  check (x4 == -102069440);
  check (x5 == 0x1.1e3f1cp+5F);
  check (x6 == 0x1.416db433ac3a4p+5);
  check (x7 == -1412494041);
  check (x8 == -1296389917);
  check (x9 == 5117189682248027843);
  check (x10 == -0x1.64d36b8a3054ap+5);
}

signed char f656(float x0, char * x1, int x2, int x3, char * x4, int x5, ...)
{
  va_list l;
  va_start(l, x5);
  int x6 = va_arg(l, int);
  long long x7 = va_arg(l, long long);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  char * x10 = va_arg(l, char *);
  char * x11 = va_arg(l, char *);
  char * x12 = va_arg(l, char *);
  double x13 = va_arg(l, double);
  long long x14 = va_arg(l, long long);
  char * x15 = va_arg(l, char *);
  char * x16 = va_arg(l, char *);
  long long x17 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.4361ep+5F);
  check (strcmp(x1, "c") == 0);
  check (x2 == 889766650);
  check (x3 == 1429314100);
  check (strcmp(x4, "a") == 0);
  check (x5 == 14167378);
  check (x6 == -593463160);
  check (x7 == -736664145385048193);
  check (x8 == 0x1.23cd903303c98p+3);
  check (x9 == -4591006240404468919);
  check (strcmp(x10, "") == 0);
  check (strcmp(x11, "") == 0);
  check (strcmp(x12, "d") == 0);
  check (x13 == 0x1.380286b501a02p+5);
  check (x14 == 101126630960372363);
  check (strcmp(x15, "") == 0);
  check (strcmp(x16, "") == 0);
  check (x17 == -8163784675802707061);
  return -279885365;
}

double f657(char * x0, char * x1, float x2, double x3, int x4, long long x5, int x6, int x7, long long x8, char * x9, ...)
{
  va_list l;
  va_start(l, x9);
  double x10 = va_arg(l, double);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "oi") == 0);
  check (strcmp(x1, "fc") == 0);
  check (x2 == -0x1.0f1c56p+4F);
  check (x3 == 0x1.73c317e7933a2p+5);
  check (x4 == 848237124);
  check (x5 == -3217992989939229884);
  check (x6 == 1030265678);
  check (x7 == -226777007);
  check (x8 == 8253346827661922013);
  check (strcmp(x9, "") == 0);
  check (x10 == -0x1.28fbd7d923654p+5);
  check (x11 == 0x1.83a4bbb2a6d9p+4);
  check (x12 == -5758475476294075987);
  return -0x1.c2f761250de46p+4;
}

double f658(char * x0, char * x1, float x2, char * x3, double x4, ...)
{
  va_list l;
  va_start(l, x4);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  double x7 = va_arg(l, double);
  char * x8 = va_arg(l, char *);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  int x11 = va_arg(l, int);
  char * x12 = va_arg(l, char *);
  long long x13 = va_arg(l, long long);
  double x14 = va_arg(l, double);
  int x15 = va_arg(l, int);
  double x16 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "zd") == 0);
  check (strcmp(x1, "jo") == 0);
  check (x2 == -0x1.88a364p+5F);
  check (strcmp(x3, "nr") == 0);
  check (x4 == 0x1.03776b753f0fcp+3);
  check (x5 == 0x1.579c055988744p+4);
  check (strcmp(x6, "iz") == 0);
  check (x7 == 0x1.e6b8a6d91120cp+4);
  check (strcmp(x8, "") == 0);
  check (strcmp(x9, "u") == 0);
  check (x10 == 1505321931077810488);
  check (x11 == 551752351);
  check (strcmp(x12, "c") == 0);
  check (x13 == 8792873102080589895);
  check (x14 == 0x1.e0009759af978p+2);
  check (x15 == 1382010072);
  check (x16 == 0x1.12565e4b72908p+3);
  return 0x1.65c22c235fb7ep+5;
}

void f659(int x0, ...)
{
  va_list l;
  va_start(l, x0);
  double x1 = va_arg(l, double);
  int x2 = va_arg(l, int);
  int x3 = va_arg(l, int);
  char * x4 = va_arg(l, char *);
  int x5 = va_arg(l, int);
  char * x6 = va_arg(l, char *);
  int x7 = va_arg(l, int);
  long long x8 = va_arg(l, long long);
  char * x9 = va_arg(l, char *);
  double x10 = va_arg(l, double);
  long long x11 = va_arg(l, long long);
  va_end(l);
  check (x0 == -875364434);
  check (x1 == 0x1.d976cd61d92cp+3);
  check (x2 == 97528049);
  check (x3 == 183702950);
  check (strcmp(x4, "ru") == 0);
  check (x5 == -1792857550);
  check (strcmp(x6, "s") == 0);
  check (x7 == 303048718);
  check (x8 == -9186190290389128614);
  check (strcmp(x9, "ft") == 0);
  check (x10 == 0x1.eae07e2383b08p+4);
  check (x11 == -566164750394717669);
}

int f660(void)
{
  return 474177692;
}

float f661(float x0, char * x1, float x2, int x3, float x4, long long x5, long long x6, int x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  int x9 = va_arg(l, int);
  long long x10 = va_arg(l, long long);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  long long x14 = va_arg(l, long long);
  int x15 = va_arg(l, int);
  double x16 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.f0bf2ep+2F);
  check (strcmp(x1, "n") == 0);
  check (x2 == 0x1.17b842p+3F);
  check (x3 == 1757670968);
  check (x4 == -0x1.9485d2p+4F);
  check (x5 == 3553239126551381398);
  check (x6 == -7468601704491466311);
  check (x7 == 196012669);
  check (x8 == -6769402016187374936);
  check (x9 == 905688913);
  check (x10 == -8511177467490139296);
  check (x11 == -0x1.dc84d926f03acp+3);
  check (x12 == 859723451);
  check (x13 == -7844150188543847404);
  check (x14 == -3645694689356736980);
  check (x15 == -1895999461);
  check (x16 == -0x1.58b64efe89a52p+4);
  return -0x1.f7b4ad22006fp+4;
}

void f662(char * x0, double x1, long long x2, char * x3, int x4, double x5, int x6, long long x7, int x8, char * x9, ...)
{
  va_list l;
  va_start(l, x9);
  char * x10 = va_arg(l, char *);
  double x11 = va_arg(l, double);
  char * x12 = va_arg(l, char *);
  char * x13 = va_arg(l, char *);
  double x14 = va_arg(l, double);
  int x15 = va_arg(l, int);
  double x16 = va_arg(l, double);
  double x17 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "y") == 0);
  check (x1 == 0x1.6d334a08117d8p+4);
  check (x2 == 2356876561578874312);
  check (strcmp(x3, "hd") == 0);
  check (x4 == 847177987);
  check (x5 == -0x1.7012d09588ab6p+5);
  check (x6 == -1364835889);
  check (x7 == 1564735355421946155);
  check (x8 == -2138843807);
  check (strcmp(x9, "") == 0);
  check (strcmp(x10, "") == 0);
  check (x11 == -0x1.2bf1612d62bd3p+5);
  check (strcmp(x12, "") == 0);
  check (strcmp(x13, "") == 0);
  check (x14 == 0x1.1293cf79b1724p+4);
  check (x15 == -1404737936);
  check (x16 == 0x1.10c936b5c97cp+5);
  check (x17 == -0x1.d39c431b4d552p+4);
}

void f663(int x0, long long x1, float x2, float x3, char * x4, int x5, float x6, int x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  va_end(l);
  check (x0 == -1128002351);
  check (x1 == -5831744838140581097);
  check (x2 == -0x1.250b3ep+3F);
  check (x3 == -0x1.26702p+4F);
  check (strcmp(x4, "q") == 0);
  check (x5 == 625964783);
  check (x6 == 0x1.190af2p+4F);
  check (x7 == -754499637);
  check (x8 == 6942457409606774668);
  check (x9 == 0x1.63e66b48826c8p+5);
  check (x10 == 6427110086082022795);
  check (strcmp(x11, "") == 0);
}

int f664(char * x0, int x1, int x2, char * x3, double x4, ...)
{
  va_list l;
  va_start(l, x4);
  long long x5 = va_arg(l, long long);
  int x6 = va_arg(l, int);
  char * x7 = va_arg(l, char *);
  double x8 = va_arg(l, double);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  int x11 = va_arg(l, int);
  char * x12 = va_arg(l, char *);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  char * x15 = va_arg(l, char *);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 1973853702);
  check (x2 == 705914605);
  check (strcmp(x3, "y") == 0);
  check (x4 == -0x1.db031537e956cp+3);
  check (x5 == -8395727873903635112);
  check (x6 == -792608242);
  check (strcmp(x7, "k") == 0);
  check (x8 == 0x1.1a88dc467f6f2p+5);
  check (strcmp(x9, "") == 0);
  check (x10 == -2759664866527831115);
  check (x11 == -1416104276);
  check (strcmp(x12, "vm") == 0);
  check (x13 == -1061751221);
  check (x14 == -1108137346);
  check (strcmp(x15, "zr") == 0);
  return 1833979080;
}

short f665(char * x0, char * x1, float x2, float x3, double x4, double x5, char * x6, long long x7, ...)
{
  va_list l;
  va_start(l, x7);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  double x10 = va_arg(l, double);
  long long x11 = va_arg(l, long long);
  long long x12 = va_arg(l, long long);
  char * x13 = va_arg(l, char *);
  char * x14 = va_arg(l, char *);
  double x15 = va_arg(l, double);
  double x16 = va_arg(l, double);
  double x17 = va_arg(l, double);
  int x18 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "sb") == 0);
  check (strcmp(x1, "jb") == 0);
  check (x2 == -0x1.15e758p+3F);
  check (x3 == -0x1.72da1p+5F);
  check (x4 == -0x1.4908da6efa868p+2);
  check (x5 == -0x1.396b14414b462p+5);
  check (strcmp(x6, "hg") == 0);
  check (x7 == 7731655530350973607);
  check (x8 == -0x1.e2a135fd988d7p+4);
  check (x9 == -2610305730455693136);
  check (x10 == 0x1.13888713f13b4p+4);
  check (x11 == 42326595271206464);
  check (x12 == 5045907935158101578);
  check (strcmp(x13, "zo") == 0);
  check (strcmp(x14, "") == 0);
  check (x15 == -0x1.63a28a07ab71p+2);
  check (x16 == 0x1.09e8427f0245cp+5);
  check (x17 == -0x1.3b623710bcedp+2);
  check (x18 == -552853342);
  return 268588395;
}

int f666(int x0, ...)
{
  va_list l;
  va_start(l, x0);
  long long x1 = va_arg(l, long long);
  va_end(l);
  check (x0 == 920580807);
  check (x1 == -3173914579294635642);
  return -1516187776;
}

void f667(double x0, double x1, double x2, float x3, char * x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  double x6 = va_arg(l, double);
  double x7 = va_arg(l, double);
  int x8 = va_arg(l, int);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.069dbea7f5f68p+5);
  check (x1 == 0x1.66cc90694417cp+5);
  check (x2 == 0x1.ddb94640ffbf8p+4);
  check (x3 == -0x1.248dfap+5F);
  check (strcmp(x4, "c") == 0);
  check (x5 == 0x1.0049cf2edd218p+2);
  check (x6 == 0x1.8bd349f612304p+3);
  check (x7 == -0x1.4586f2d56d55cp+5);
  check (x8 == 775218595);
  check (strcmp(x9, "u") == 0);
  check (x10 == 3493322490663154879);
}

float f668(float x0, double x1, int x2, double x3, char * x4, int x5, char * x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  char * x11 = va_arg(l, char *);
  char * x12 = va_arg(l, char *);
  int x13 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.4e088cp+5F);
  check (x1 == -0x1.14ded6ae1eab8p+3);
  check (x2 == -1903451904);
  check (x3 == 0x1.20e797638dfa4p+5);
  check (strcmp(x4, "ud") == 0);
  check (x5 == -857629265);
  check (strcmp(x6, "") == 0);
  check (x7 == 3254611156257424803);
  check (x8 == -1525015089);
  check (x9 == 0x1.0770cee9980bp+2);
  check (x10 == -2102488012);
  check (strcmp(x11, "j") == 0);
  check (strcmp(x12, "") == 0);
  check (x13 == 545842080);
  return -0x1.76e9e5baba0f7p+5;
}

short f669(int x0, long long x1, float x2, char * x3, long long x4, double x5, double x6, float x7, float x8)
{
  check (x0 == 1609144253);
  check (x1 == 1153169113682578948);
  check (x2 == 0x1.822ab4p+2F);
  check (strcmp(x3, "dg") == 0);
  check (x4 == 1130061744682193977);
  check (x5 == 0x1.7edbe66ae956p+2);
  check (x6 == 0x1.5177677763786p+5);
  check (x7 == -0x1.823112p+4F);
  check (x8 == -0x1.9af0dap+4F);
  return 121225586;
}

long long f670(float x0, float x1, float x2)
{
  check (x0 == -0x1.ae2002p+3F);
  check (x1 == -0x1.913a0ep+4F);
  check (x2 == 0x1.18313ap+4F);
  return -6959248285087389708;
}

float f671(char * x0, double x1, long long x2, double x3, char * x4, float x5, int x6, long long x7, char * x8, char * x9, double x10, ...)
{
  va_list l;
  va_start(l, x10);
  char * x11 = va_arg(l, char *);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  char * x14 = va_arg(l, char *);
  int x15 = va_arg(l, int);
  int x16 = va_arg(l, int);
  int x17 = va_arg(l, int);
  long long x18 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "f") == 0);
  check (x1 == -0x1.4df19e00ebefp+5);
  check (x2 == 3818253661908911851);
  check (x3 == 0x1.767fa8a3980ap+2);
  check (strcmp(x4, "c") == 0);
  check (x5 == -0x1.b7a028p+3F);
  check (x6 == 1190479578);
  check (x7 == -9045853469000302919);
  check (strcmp(x8, "s") == 0);
  check (strcmp(x9, "") == 0);
  check (x10 == 0x1.3986b3158525cp+5);
  check (strcmp(x11, "j") == 0);
  check (x12 == 852094260);
  check (x13 == 848012779);
  check (strcmp(x14, "c") == 0);
  check (x15 == 2079361764);
  check (x16 == -38601674);
  check (x17 == 663004539);
  check (x18 == 1053834206880342394);
  return 0x1.409717dbb0f1ep+5;
}

void f672(void)
{
}

long long f673(float x0, float x1, long long x2, char * x3, int x4, long long x5, double x6, long long x7, char * x8, ...)
{
  va_list l;
  va_start(l, x8);
  double x9 = va_arg(l, double);
  long long x10 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.3e35c4p+5F);
  check (x1 == -0x1.968ee8p+3F);
  check (x2 == 8433498826289563926);
  check (strcmp(x3, "") == 0);
  check (x4 == 242319173);
  check (x5 == -5506388642912533925);
  check (x6 == -0x1.e2d0237e1315dp+4);
  check (x7 == -1648442553969680669);
  check (strcmp(x8, "q") == 0);
  check (x9 == -0x1.503f98a4d51dbp+5);
  check (x10 == 1417664714775283816);
  return 3913619852902404880;
}

short f674(float x0, double x1, char * x2, int x3, int x4, ...)
{
  va_list l;
  va_start(l, x4);
  char * x5 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.3c3774p+5F);
  check (x1 == -0x1.d84a2c7a95b08p+3);
  check (strcmp(x2, "") == 0);
  check (x3 == 933152245);
  check (x4 == 1012200319);
  check (strcmp(x5, "l") == 0);
  return -397020579;
}

long long f675(int x0, int x1, ...)
{
  va_list l;
  va_start(l, x1);
  char * x2 = va_arg(l, char *);
  double x3 = va_arg(l, double);
  double x4 = va_arg(l, double);
  double x5 = va_arg(l, double);
  double x6 = va_arg(l, double);
  int x7 = va_arg(l, int);
  char * x8 = va_arg(l, char *);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  va_end(l);
  check (x0 == -520863509);
  check (x1 == 1630487220);
  check (strcmp(x2, "") == 0);
  check (x3 == 0x1.667d30f45215p+4);
  check (x4 == 0x1.309384fe87e5p+5);
  check (x5 == 0x1.0759676fbec7p+2);
  check (x6 == 0x1.e9b43902d6a7p+4);
  check (x7 == -881514322);
  check (strcmp(x8, "p") == 0);
  check (strcmp(x9, "") == 0);
  check (x10 == 4714083201215846726);
  check (strcmp(x11, "") == 0);
  check (x12 == -1024778529);
  check (x13 == 1217228234);
  return -682023577706211229;
}

double f676(char * x0, float x1, long long x2, float x3, float x4, double x5, char * x6, float x7, float x8)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -0x1.812158p+3F);
  check (x2 == -2278986424629807488);
  check (x3 == 0x1.cb2d94p+4F);
  check (x4 == 0x1.0d3d1ap+3F);
  check (x5 == -0x1.793cc52731dbp+2);
  check (strcmp(x6, "i") == 0);
  check (x7 == 0x1.db5422p+3F);
  check (x8 == 0x1.558f08p+5F);
  return -0x1.69a56c7a5a9acp+4;
}

void f677(float x0, int x1, double x2, double x3, int x4, char * x5, char * x6, double x7, ...)
{
  va_list l;
  va_start(l, x7);
  int x8 = va_arg(l, int);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  long long x11 = va_arg(l, long long);
  double x12 = va_arg(l, double);
  char * x13 = va_arg(l, char *);
  char * x14 = va_arg(l, char *);
  double x15 = va_arg(l, double);
  char * x16 = va_arg(l, char *);
  char * x17 = va_arg(l, char *);
  long long x18 = va_arg(l, long long);
  va_end(l);
  check (x0 == 0x1.706d14p+4F);
  check (x1 == 2025826491);
  check (x2 == -0x1.67b6a8abe3557p+4);
  check (x3 == -0x1.64cd624313571p+4);
  check (x4 == 2030656516);
  check (strcmp(x5, "oo") == 0);
  check (strcmp(x6, "aq") == 0);
  check (x7 == -0x1.360104de5fa3p+5);
  check (x8 == 1930303152);
  check (strcmp(x9, "") == 0);
  check (x10 == -8009807674419147213);
  check (x11 == 2017130798119899133);
  check (x12 == 0x1.16155b8bd439p+1);
  check (strcmp(x13, "n") == 0);
  check (strcmp(x14, "") == 0);
  check (x15 == -0x1.75aa124ef270bp+5);
  check (strcmp(x16, "") == 0);
  check (strcmp(x17, "") == 0);
  check (x18 == -3311010493127433547);
}

short f678(char * x0, long long x1, ...)
{
  va_list l;
  va_start(l, x1);
  double x2 = va_arg(l, double);
  long long x3 = va_arg(l, long long);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "js") == 0);
  check (x1 == -3805939337381161460);
  check (x2 == 0x1.12b276706874cp+3);
  check (x3 == 2220111173955058815);
  check (x4 == 1955584158);
  check (x5 == 0x1.2de182341a578p+4);
  check (x6 == 1266974008);
  check (x7 == 0x1.355f59900cb54p+3);
  return 424086427;
}

void f679(int x0, double x1, double x2, double x3, long long x4, double x5, char * x6, float x7, int x8, ...)
{
  va_list l;
  va_start(l, x8);
  long long x9 = va_arg(l, long long);
  double x10 = va_arg(l, double);
  char * x11 = va_arg(l, char *);
  int x12 = va_arg(l, int);
  char * x13 = va_arg(l, char *);
  va_end(l);
  check (x0 == 2059911633);
  check (x1 == 0x1.55bdec45977fp+5);
  check (x2 == 0x1.363a01995b6fep+5);
  check (x3 == -0x1.c5fd7c325044cp+4);
  check (x4 == 2158515337712687738);
  check (x5 == -0x1.3c5dd49e9d062p+5);
  check (strcmp(x6, "sb") == 0);
  check (x7 == 0x1.7721f2p+3F);
  check (x8 == -1496893898);
  check (x9 == 8616908048078776375);
  check (x10 == 0x1.0296c5a07c088p+5);
  check (strcmp(x11, "z") == 0);
  check (x12 == 1530608568);
  check (strcmp(x13, "") == 0);
}

void f680(void)
{
}

int f681(int x0, int x1, int x2, float x3, char * x4, char * x5, long long x6, char * x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  int x9 = va_arg(l, int);
  double x10 = va_arg(l, double);
  char * x11 = va_arg(l, char *);
  int x12 = va_arg(l, int);
  va_end(l);
  check (x0 == 1732213699);
  check (x1 == 1545166901);
  check (x2 == -2015578578);
  check (x3 == 0x1.656fdp+4F);
  check (strcmp(x4, "n") == 0);
  check (strcmp(x5, "") == 0);
  check (x6 == -8885769528345554289);
  check (strcmp(x7, "") == 0);
  check (x8 == 890883522288784557);
  check (x9 == -1100987316);
  check (x10 == 0x1.a7f1888b2fbap+0);
  check (strcmp(x11, "gw") == 0);
  check (x12 == 1963532801);
  return -806284336;
}

void f682(long long x0, double x1, float x2, double x3, double x4, int x5, long long x6, ...)
{
  va_list l;
  va_start(l, x6);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  char * x10 = va_arg(l, char *);
  va_end(l);
  check (x0 == -2836230558094006280);
  check (x1 == 0x1.62a41069d2404p+4);
  check (x2 == 0x1.f6248ep+4F);
  check (x3 == 0x1.1f403bd7d5754p+3);
  check (x4 == -0x1.6b01f5d072eccp+5);
  check (x5 == 55888541);
  check (x6 == 1386459273026800978);
  check (x7 == 0x1.6ddde521f7274p+4);
  check (x8 == -0x1.2ed54f3e00752p+5);
  check (x9 == -84358091667469811);
  check (strcmp(x10, "q") == 0);
}

unsigned short f683(char * x0, long long x1, char * x2, double x3, double x4, int x5, int x6, int x7, float x8, float x9)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 1675396916365188636);
  check (strcmp(x2, "v") == 0);
  check (x3 == -0x1.6226580c75e78p+3);
  check (x4 == -0x1.f8f4beb50823cp+3);
  check (x5 == -612709851);
  check (x6 == -2106492062);
  check (x7 == 1419738696);
  check (x8 == 0x1.3d05bap+5F);
  check (x9 == 0x1.c091f2p-2F);
  return -423950550;
}

signed char f684(float x0, int x1, double x2, double x3, long long x4, float x5, char * x6, int x7, char * x8, int x9, ...)
{
  va_list l;
  va_start(l, x9);
  double x10 = va_arg(l, double);
  long long x11 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.26253p+4F);
  check (x1 == 738329358);
  check (x2 == -0x1.0fbb94d006ad4p+5);
  check (x3 == -0x1.de6ea22bd26dcp+3);
  check (x4 == -661358659782600706);
  check (x5 == 0x1.78abeap+2F);
  check (strcmp(x6, "n") == 0);
  check (x7 == 1131696978);
  check (strcmp(x8, "d") == 0);
  check (x9 == -1496134647);
  check (x10 == 0x1.003a2b7fa1112p+5);
  check (x11 == 6501746381738153343);
  return -236511941;
}

void f685(float x0, char * x1, long long x2, double x3, float x4, float x5, float x6)
{
  check (x0 == -0x1.79a5bap+5F);
  check (strcmp(x1, "h") == 0);
  check (x2 == -3140362815423910069);
  check (x3 == 0x1.56f6d1bdd3d4p+3);
  check (x4 == 0x1.190ef6p+4F);
  check (x5 == 0x1.c3afc8p+4F);
  check (x6 == -0x1.68f074p+2F);
}

void f686(void)
{
}

void f687(char * x0, int x1, char * x2, float x3)
{
  check (strcmp(x0, "pq") == 0);
  check (x1 == -1627631899);
  check (strcmp(x2, "g") == 0);
  check (x3 == 0x1.8817bp+5F);
}

void f688(void)
{
}

signed char f689(long long x0, int x1, char * x2, double x3, float x4, double x5, long long x6, double x7, int x8, ...)
{
  va_list l;
  va_start(l, x8);
  double x9 = va_arg(l, double);
  char * x10 = va_arg(l, char *);
  long long x11 = va_arg(l, long long);
  long long x12 = va_arg(l, long long);
  double x13 = va_arg(l, double);
  double x14 = va_arg(l, double);
  long long x15 = va_arg(l, long long);
  char * x16 = va_arg(l, char *);
  char * x17 = va_arg(l, char *);
  long long x18 = va_arg(l, long long);
  double x19 = va_arg(l, double);
  va_end(l);
  check (x0 == 6367016584592931901);
  check (x1 == -1689355882);
  check (strcmp(x2, "") == 0);
  check (x3 == -0x1.6f8a7eed655e9p+5);
  check (x4 == 0x1.93854ep+4F);
  check (x5 == 0x1.056beeab1c49p+4);
  check (x6 == 1633533153470720632);
  check (x7 == 0x1.1f9b23d13056p+5);
  check (x8 == -1609503591);
  check (x9 == 0x1.43597d3f2cdd4p+5);
  check (strcmp(x10, "co") == 0);
  check (x11 == 973602969520741354);
  check (x12 == 1043328895423696761);
  check (x13 == 0x1.0eb04233c8428p+3);
  check (x14 == -0x1.160d0c3fd83f1p+5);
  check (x15 == -6172222920797026190);
  check (strcmp(x16, "") == 0);
  check (strcmp(x17, "") == 0);
  check (x18 == -9022912784743794387);
  check (x19 == 0x1.4ebc0a93560d4p+3);
  return 435436059;
}

char * f690(long long x0, int x1, int x2, long long x3, float x4, float x5, float x6, double x7, ...)
{
  va_list l;
  va_start(l, x7);
  double x8 = va_arg(l, double);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  int x12 = va_arg(l, int);
  int x13 = va_arg(l, int);
  char * x14 = va_arg(l, char *);
  double x15 = va_arg(l, double);
  int x16 = va_arg(l, int);
  double x17 = va_arg(l, double);
  double x18 = va_arg(l, double);
  va_end(l);
  check (x0 == -3750900501354088184);
  check (x1 == -1576281349);
  check (x2 == -1697988757);
  check (x3 == 2038851159846018016);
  check (x4 == 0x1.17798p+1F);
  check (x5 == -0x1.b8987ap+3F);
  check (x6 == -0x1.fdb2dap+3F);
  check (x7 == -0x1.ffe71400fc8e1p+4);
  check (x8 == -0x1.c0f78e3433138p+4);
  check (x9 == 1933489868);
  check (x10 == -1666213284);
  check (x11 == -9036964026481189336);
  check (x12 == 1421136308);
  check (x13 == -709259359);
  check (strcmp(x14, "e") == 0);
  check (x15 == -0x1.0a1a796422928p+5);
  check (x16 == -14291841);
  check (x17 == 0x1.42e4a8c96b8a8p+5);
  check (x18 == 0x1.277e1ad78d6e4p+5);
  return "tk";
}

long long f691(long long x0, char * x1, long long x2, double x3, float x4, long long x5, int x6, float x7, long long x8, double x9, ...)
{
  va_list l;
  va_start(l, x9);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  char * x13 = va_arg(l, char *);
  char * x14 = va_arg(l, char *);
  char * x15 = va_arg(l, char *);
  int x16 = va_arg(l, int);
  char * x17 = va_arg(l, char *);
  char * x18 = va_arg(l, char *);
  double x19 = va_arg(l, double);
  long long x20 = va_arg(l, long long);
  va_end(l);
  check (x0 == -7442204861738462214);
  check (strcmp(x1, "") == 0);
  check (x2 == 7528309936253066000);
  check (x3 == 0x1.e13c083a62ec8p+3);
  check (x4 == 0x1.c3649ep+4F);
  check (x5 == 6758695546646999538);
  check (x6 == -16687990);
  check (x7 == 0x1.47b584p+1F);
  check (x8 == 4210117645755700783);
  check (x9 == 0x1.c67180802818p+2);
  check (x10 == 1964792412);
  check (x11 == 0x1.2349b59a95748p+5);
  check (x12 == 4977338945267546701);
  check (strcmp(x13, "gy") == 0);
  check (strcmp(x14, "ur") == 0);
  check (strcmp(x15, "") == 0);
  check (x16 == 1707759517);
  check (strcmp(x17, "w") == 0);
  check (strcmp(x18, "kq") == 0);
  check (x19 == 0x1.16f2a58377b8p+1);
  check (x20 == -3135265790968006712);
  return 3051136623865764158;
}

void f692(int x0, long long x1, char * x2, char * x3, ...)
{
  va_list l;
  va_start(l, x3);
  int x4 = va_arg(l, int);
  long long x5 = va_arg(l, long long);
  char * x6 = va_arg(l, char *);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  double x9 = va_arg(l, double);
  va_end(l);
  check (x0 == -2064448899);
  check (x1 == -3058825207710041941);
  check (strcmp(x2, "cy") == 0);
  check (strcmp(x3, "f") == 0);
  check (x4 == 862600121);
  check (x5 == 682843603940626958);
  check (strcmp(x6, "") == 0);
  check (x7 == -1723318956502309032);
  check (x8 == -5861788712640166613);
  check (x9 == -0x1.eff3f44ac744p+4);
}

void f693(void)
{
}

void f694(char * x0, char * x1, int x2, double x3, long long x4, char * x5, double x6, ...)
{
  va_list l;
  va_start(l, x6);
  char * x7 = va_arg(l, char *);
  long long x8 = va_arg(l, long long);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "l") == 0);
  check (strcmp(x1, "") == 0);
  check (x2 == 880333893);
  check (x3 == -0x1.1d6d89a782d42p+5);
  check (x4 == -1327741968292242621);
  check (strcmp(x5, "") == 0);
  check (x6 == 0x1.8b7611d8ba972p+5);
  check (strcmp(x7, "em") == 0);
  check (x8 == 8204550104807411134);
  check (x9 == -291356861);
  check (x10 == -1981861892);
}

unsigned short f695(long long x0, double x1, char * x2, char * x3, float x4, long long x5, char * x6, int x7, int x8, ...)
{
  va_list l;
  va_start(l, x8);
  char * x9 = va_arg(l, char *);
  long long x10 = va_arg(l, long long);
  char * x11 = va_arg(l, char *);
  char * x12 = va_arg(l, char *);
  double x13 = va_arg(l, double);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  va_end(l);
  check (x0 == -5300664604302227697);
  check (x1 == -0x1.8209169bba2afp+4);
  check (strcmp(x2, "o") == 0);
  check (strcmp(x3, "va") == 0);
  check (x4 == 0x1.56c6dcp+5F);
  check (x5 == -3551388045920458891);
  check (strcmp(x6, "b") == 0);
  check (x7 == 1577587036);
  check (x8 == -1790503741);
  check (strcmp(x9, "m") == 0);
  check (x10 == -5297153997977870730);
  check (strcmp(x11, "u") == 0);
  check (strcmp(x12, "wn") == 0);
  check (x13 == -0x1.2727170f0aa8p+5);
  check (x14 == -381008049);
  check (x15 == -139024982);
  return -412330355;
}

void f696(char * x0, long long x1, char * x2, char * x3, long long x4, char * x5, int x6, float x7, float x8, int x9, ...)
{
  va_list l;
  va_start(l, x9);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  int x12 = va_arg(l, int);
  char * x13 = va_arg(l, char *);
  double x14 = va_arg(l, double);
  char * x15 = va_arg(l, char *);
  double x16 = va_arg(l, double);
  double x17 = va_arg(l, double);
  int x18 = va_arg(l, int);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 2495811398441534509);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "u") == 0);
  check (x4 == -4570585142567549395);
  check (strcmp(x5, "qb") == 0);
  check (x6 == 1309514874);
  check (x7 == -0x1.88d3e8p+2F);
  check (x8 == 0x1.31b2cp+5F);
  check (x9 == -204122122);
  check (x10 == 0x1.3b65a97c303ecp+4);
  check (x11 == -2084753124);
  check (x12 == 1642009557);
  check (strcmp(x13, "") == 0);
  check (x14 == 0x1.141b7772bc48ep+5);
  check (strcmp(x15, "g") == 0);
  check (x16 == -0x1.542c942fb1d17p+5);
  check (x17 == 0x1.0f6e64d6227dp+3);
  check (x18 == 725564924);
}

unsigned char f697(char * x0, int x1, long long x2, double x3, char * x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  double x7 = va_arg(l, double);
  char * x8 = va_arg(l, char *);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  double x11 = va_arg(l, double);
  int x12 = va_arg(l, int);
  long long x13 = va_arg(l, long long);
  double x14 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "g") == 0);
  check (x1 == 1946893453);
  check (x2 == -559523310121702532);
  check (x3 == -0x1.15dc454503154p+4);
  check (strcmp(x4, "ba") == 0);
  check (x5 == -0x1.037f3e0f00593p+5);
  check (x6 == 377112244389569770);
  check (x7 == 0x1.2bf7b1aaddcd2p+5);
  check (strcmp(x8, "vw") == 0);
  check (x9 == 0x1.2c9fce8ca2bbp+4);
  check (x10 == 733276130);
  check (x11 == 0x1.839291f73c858p+4);
  check (x12 == -1524859481);
  check (x13 == 2039280883253698794);
  check (x14 == 0x1.5ca11a96c1b3p+2);
  return 47938248;
}

void f698(char * x0, double x1, char * x2, double x3, ...)
{
  va_list l;
  va_start(l, x3);
  double x4 = va_arg(l, double);
  char * x5 = va_arg(l, char *);
  double x6 = va_arg(l, double);
  long long x7 = va_arg(l, long long);
  double x8 = va_arg(l, double);
  long long x9 = va_arg(l, long long);
  va_end(l);
  check (strcmp(x0, "l") == 0);
  check (x1 == -0x1.5f13f7ec26578p+2);
  check (strcmp(x2, "zx") == 0);
  check (x3 == 0x1.73855e89e794p+4);
  check (x4 == 0x1.1b461ecbf156ep+5);
  check (strcmp(x5, "rr") == 0);
  check (x6 == 0x1.a61759183adbp+2);
  check (x7 == -6981952327172804064);
  check (x8 == -0x1.3456dac0fa01p+1);
  check (x9 == 1964686500670336744);
}

char * f699(long long x0, float x1, double x2, float x3, double x4, ...)
{
  va_list l;
  va_start(l, x4);
  int x5 = va_arg(l, int);
  double x6 = va_arg(l, double);
  int x7 = va_arg(l, int);
  int x8 = va_arg(l, int);
  long long x9 = va_arg(l, long long);
  double x10 = va_arg(l, double);
  va_end(l);
  check (x0 == -4484989185756434957);
  check (x1 == 0x1.03271cp+4F);
  check (x2 == 0x1.85836e21957e6p+5);
  check (x3 == -0x1.6b6d74p+5F);
  check (x4 == -0x1.d4e72733c892dp+4);
  check (x5 == 2102876187);
  check (x6 == -0x1.6b998919b5fc4p+3);
  check (x7 == 961358198);
  check (x8 == -386745656);
  check (x9 == 7181354233035117320);
  check (x10 == -0x1.6819c3668f37fp+4);
  return "gr";
}

signed char f700(char * x0, float x1, float x2, long long x3, int x4, double x5, float x6, float x7, int x8, double x9, int x10, ...)
{
  va_list l;
  va_start(l, x10);
  int x11 = va_arg(l, int);
  double x12 = va_arg(l, double);
  double x13 = va_arg(l, double);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  char * x16 = va_arg(l, char *);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == -0x1.76f524p+4F);
  check (x2 == -0x1.32452ap+3F);
  check (x3 == -2459085891581484819);
  check (x4 == 1807275214);
  check (x5 == -0x1.751da7955f9cp-1);
  check (x6 == -0x1.eee3ecp+1F);
  check (x7 == 0x1.d6802ap+4F);
  check (x8 == -889719577);
  check (x9 == -0x1.2f22060d193c5p+5);
  check (x10 == 1070089972);
  check (x11 == -382796327);
  check (x12 == 0x1.79d8b1c9848dcp+4);
  check (x13 == -0x1.69611dcb66a13p+4);
  check (x14 == 2145204948);
  check (x15 == -49637352);
  check (strcmp(x16, "p") == 0);
  return -212889468;
}

float f701(char * x0, int x1, float x2, int x3, float x4)
{
  check (strcmp(x0, "qh") == 0);
  check (x1 == 536526275);
  check (x2 == -0x1.24f366p+3F);
  check (x3 == -870089933);
  check (x4 == -0x1.a97c4cp+3F);
  return -0x1.8dfc571fc7bddp+5;
}

void f702(double x0, double x1, char * x2, ...)
{
  va_list l;
  va_start(l, x2);
  long long x3 = va_arg(l, long long);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  int x6 = va_arg(l, int);
  double x7 = va_arg(l, double);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  va_end(l);
  check (x0 == -0x1.72786789c47bdp+4);
  check (x1 == 0x1.274ae290b81e2p+5);
  check (strcmp(x2, "fq") == 0);
  check (x3 == 4638354944769506192);
  check (x4 == -918471340);
  check (x5 == -0x1.cf50a7e54346p+1);
  check (x6 == 391822947);
  check (x7 == 0x1.6d081523d5234p+5);
  check (x8 == 0x1.8fbf79ebeae82p+5);
  check (x9 == 0x1.59852ab52c65p+5);
}

void f703(double x0, double x1, double x2, long long x3, double x4, ...)
{
  va_list l;
  va_start(l, x4);
  int x5 = va_arg(l, int);
  int x6 = va_arg(l, int);
  int x7 = va_arg(l, int);
  double x8 = va_arg(l, double);
  double x9 = va_arg(l, double);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  int x13 = va_arg(l, int);
  int x14 = va_arg(l, int);
  int x15 = va_arg(l, int);
  int x16 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.3d5bd1cb3bcdep+5);
  check (x1 == 0x1.8424dc25660d4p+4);
  check (x2 == -0x1.dd44fe45c972p+1);
  check (x3 == 7835436811188437354);
  check (x4 == 0x1.fedd960071c3p+3);
  check (x5 == 1525250532);
  check (x6 == -1303953130);
  check (x7 == -427497845);
  check (x8 == -0x1.778087c141bacp+5);
  check (x9 == -0x1.cfee2bc652de3p+4);
  check (x10 == 1525129954);
  check (x11 == -4732772884075157065);
  check (strcmp(x12, "ny") == 0);
  check (x13 == -225945003);
  check (x14 == 1184322853);
  check (x15 == -1423255312);
  check (x16 == -2061209602);
}

short f704(int x0, char * x1, char * x2, long long x3, int x4, float x5, int x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  int x8 = va_arg(l, int);
  char * x9 = va_arg(l, char *);
  int x10 = va_arg(l, int);
  long long x11 = va_arg(l, long long);
  char * x12 = va_arg(l, char *);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  va_end(l);
  check (x0 == -930195258);
  check (strcmp(x1, "") == 0);
  check (strcmp(x2, "xo") == 0);
  check (x3 == -6530266032080582828);
  check (x4 == 1514799402);
  check (x5 == -0x1.84cc2ap+4F);
  check (x6 == -505806579);
  check (x7 == 6360264925827467512);
  check (x8 == 1646764990);
  check (strcmp(x9, "a") == 0);
  check (x10 == 1873465129);
  check (x11 == 7607821824489512407);
  check (strcmp(x12, "rt") == 0);
  check (x13 == -4912495514248060641);
  check (x14 == -10090495);
  return 161513069;
}

void f705(long long x0, float x1, float x2, float x3)
{
  check (x0 == -7401032677358378648);
  check (x1 == -0x1.3c610cp+5F);
  check (x2 == 0x1.2651eap+5F);
  check (x3 == -0x1.83937ap+5F);
}

unsigned short f706(double x0, int x1, long long x2, double x3, char * x4, int x5, int x6, float x7, long long x8, double x9, ...)
{
  va_list l;
  va_start(l, x9);
  int x10 = va_arg(l, int);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  int x13 = va_arg(l, int);
  char * x14 = va_arg(l, char *);
  int x15 = va_arg(l, int);
  int x16 = va_arg(l, int);
  va_end(l);
  check (x0 == -0x1.11bba3cf2d308p+3);
  check (x1 == -678978009);
  check (x2 == -904477038191105343);
  check (x3 == -0x1.0fe972863d318p+4);
  check (strcmp(x4, "r") == 0);
  check (x5 == -1173630298);
  check (x6 == -1269452061);
  check (x7 == 0x1.2d46a2p+3F);
  check (x8 == -4993312352704182924);
  check (x9 == 0x1.426dbec95364ep+5);
  check (x10 == 1954297985);
  check (x11 == 811102318);
  check (x12 == -400772448744947459);
  check (x13 == 1754981564);
  check (strcmp(x14, "hk") == 0);
  check (x15 == -372770022);
  check (x16 == 1430613552);
  return -119099672;
}

void f707(char * x0, double x1, char * x2, double x3, ...)
{
  va_list l;
  va_start(l, x3);
  int x4 = va_arg(l, int);
  double x5 = va_arg(l, double);
  char * x6 = va_arg(l, char *);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (x1 == 0x1.574fb5282ad32p+5);
  check (strcmp(x2, "") == 0);
  check (x3 == -0x1.498d8a3a2b8dcp+5);
  check (x4 == 1256123682);
  check (x5 == -0x1.7ff843c5e6468p+5);
  check (strcmp(x6, "h") == 0);
}

unsigned short f708(long long x0, long long x1, float x2, char * x3, long long x4, ...)
{
  va_list l;
  va_start(l, x4);
  long long x5 = va_arg(l, long long);
  long long x6 = va_arg(l, long long);
  long long x7 = va_arg(l, long long);
  double x8 = va_arg(l, double);
  int x9 = va_arg(l, int);
  int x10 = va_arg(l, int);
  va_end(l);
  check (x0 == 8855239887090695481);
  check (x1 == 7581219621979276725);
  check (x2 == -0x1.00800ep+2F);
  check (strcmp(x3, "rk") == 0);
  check (x4 == 8828917983308899398);
  check (x5 == -8124030964293730888);
  check (x6 == -1685211800034789018);
  check (x7 == -4935141429391310898);
  check (x8 == -0x1.4060c17c450acp+5);
  check (x9 == -73538952);
  check (x10 == -1039545829);
  return 133978539;
}

void f709(long long x0, float x1, float x2, long long x3, double x4, long long x5, double x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  long long x12 = va_arg(l, long long);
  long long x13 = va_arg(l, long long);
  int x14 = va_arg(l, int);
  va_end(l);
  check (x0 == 6014465501601863499);
  check (x1 == 0x1.58d382p+5F);
  check (x2 == 0x1.3d87ep+4F);
  check (x3 == 6845176419187105710);
  check (x4 == 0x1.5805fe8a0f554p+3);
  check (x5 == 3309687262534505698);
  check (x6 == -0x1.4a4ed89bf43e4p+4);
  check (x7 == 65661957);
  check (x8 == -1284694857554390933);
  check (x9 == 7547413822156468334);
  check (x10 == -0x1.bd0f630cc1637p+4);
  check (x11 == 350409935);
  check (x12 == 4359162586439416569);
  check (x13 == -1361214722032881327);
  check (x14 == -554111631);
}

char * f710(char * x0, char * x1, float x2, double x3, long long x4, double x5, long long x6, char * x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  char * x9 = va_arg(l, char *);
  char * x10 = va_arg(l, char *);
  va_end(l);
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.5fb602p+3F);
  check (x3 == -0x1.38458dc42b32fp+5);
  check (x4 == 4908422009768745045);
  check (x5 == -0x1.5b984ac901d4fp+5);
  check (x6 == 1422511125041748284);
  check (strcmp(x7, "") == 0);
  check (x8 == 6754188163068925040);
  check (strcmp(x9, "fk") == 0);
  check (strcmp(x10, "n") == 0);
  return "";
}

void f711(int x0, char * x1, double x2, long long x3, double x4, int x5, double x6, ...)
{
  va_list l;
  va_start(l, x6);
  long long x7 = va_arg(l, long long);
  long long x8 = va_arg(l, long long);
  int x9 = va_arg(l, int);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  char * x12 = va_arg(l, char *);
  va_end(l);
  check (x0 == 17776914);
  check (strcmp(x1, "q") == 0);
  check (x2 == 0x1.52ba948e84608p+5);
  check (x3 == -7689314548975836677);
  check (x4 == -0x1.6f477a4a2adabp+5);
  check (x5 == 286473971);
  check (x6 == -0x1.4ec17e930d9c7p+5);
  check (x7 == -1366357397949222732);
  check (x8 == -7230077827323117320);
  check (x9 == -1226429119);
  check (x10 == -0x1.9125be7a10efp+4);
  check (x11 == 1535745609);
  check (strcmp(x12, "s") == 0);
}

signed char f712(float x0, double x1, float x2, long long x3, int x4, float x5, int x6, double x7, int x8, double x9, ...)
{
  va_list l;
  va_start(l, x9);
  double x10 = va_arg(l, double);
  int x11 = va_arg(l, int);
  int x12 = va_arg(l, int);
  char * x13 = va_arg(l, char *);
  long long x14 = va_arg(l, long long);
  long long x15 = va_arg(l, long long);
  double x16 = va_arg(l, double);
  int x17 = va_arg(l, int);
  long long x18 = va_arg(l, long long);
  va_end(l);
  check (x0 == -0x1.518e02p+5F);
  check (x1 == 0x1.5a245ef1f5cd4p+4);
  check (x2 == -0x1.afa2f6p+3F);
  check (x3 == 6396970551448115493);
  check (x4 == -1443148615);
  check (x5 == -0x1.29e8a8p+5F);
  check (x6 == 1198590045);
  check (x7 == -0x1.43fdc08dc7d9cp+3);
  check (x8 == -1789225121);
  check (x9 == 0x1.d367ff37b3e3p+3);
  check (x10 == -0x1.018255d695bfep+5);
  check (x11 == 1473371005);
  check (x12 == 1688430142);
  check (strcmp(x13, "w") == 0);
  check (x14 == -8901740783675604601);
  check (x15 == 8779848120204494513);
  check (x16 == -0x1.b63576755cd56p+4);
  check (x17 == -723890098);
  check (x18 == 1801803073481109447);
  return -169183345;
}

float f713(char * x0, long long x1, int x2, int x3, int x4, int x5, float x6)
{
  check (strcmp(x0, "j") == 0);
  check (x1 == -7804864611931326238);
  check (x2 == 1030860420);
  check (x3 == -363815033);
  check (x4 == 1699473626);
  check (x5 == -324611234);
  check (x6 == -0x1.d40d8ap+3F);
  return -0x1.72915ca5fec98p+2;
}

void f714(float x0, char * x1, long long x2, long long x3, int x4, float x5, char * x6, char * x7, int x8, int x9, int x10, ...)
{
  va_list l;
  va_start(l, x10);
  double x11 = va_arg(l, double);
  long long x12 = va_arg(l, long long);
  char * x13 = va_arg(l, char *);
  char * x14 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.549fcp+5F);
  check (strcmp(x1, "") == 0);
  check (x2 == -8598668267699225307);
  check (x3 == -6066755665501404374);
  check (x4 == 2126574980);
  check (x5 == 0x1.9f2e3ep+4F);
  check (strcmp(x6, "") == 0);
  check (strcmp(x7, "k") == 0);
  check (x8 == 1320724073);
  check (x9 == -1163915213);
  check (x10 == 331680728);
  check (x11 == -0x1.875832617daap+5);
  check (x12 == -1081894045607833815);
  check (strcmp(x13, "xm") == 0);
  check (strcmp(x14, "zi") == 0);
}

signed char f715(float x0, float x1, char * x2, double x3, char * x4, int x5, long long x6, int x7, ...)
{
  va_list l;
  va_start(l, x7);
  long long x8 = va_arg(l, long long);
  long long x9 = va_arg(l, long long);
  char * x10 = va_arg(l, char *);
  va_end(l);
  check (x0 == -0x1.658ep+4F);
  check (x1 == -0x1.793d0ap+4F);
  check (strcmp(x2, "") == 0);
  check (x3 == -0x1.381884797ca3p+5);
  check (strcmp(x4, "v") == 0);
  check (x5 == 1524685348);
  check (x6 == -6734931617300810523);
  check (x7 == 874126211);
  check (x8 == 8190862678723229925);
  check (x9 == 4611748873698641410);
  check (strcmp(x10, "md") == 0);
  return -439843639;
}

unsigned char f716(long long x0, double x1, char * x2, float x3, char * x4, double x5, ...)
{
  va_list l;
  va_start(l, x5);
  long long x6 = va_arg(l, long long);
  int x7 = va_arg(l, int);
  va_end(l);
  check (x0 == -2412224687332121186);
  check (x1 == -0x1.bf59b23e671ecp+4);
  check (strcmp(x2, "bn") == 0);
  check (x3 == 0x1.f28d36p+4F);
  check (strcmp(x4, "") == 0);
  check (x5 == 0x1.6b8b95f9aa2bcp+3);
  check (x6 == 7953983380489026108);
  check (x7 == -812757294);
  return -142923619;
}

unsigned short f717(char * x0, int x1, float x2, float x3, double x4, double x5, double x6, char * x7, long long x8, ...)
{
  va_list l;
  va_start(l, x8);
  double x9 = va_arg(l, double);
  va_end(l);
  check (strcmp(x0, "f") == 0);
  check (x1 == 1208974437);
  check (x2 == 0x1.196b32p+5F);
  check (x3 == -0x1.fba332p+4F);
  check (x4 == -0x1.da2593c591da2p+4);
  check (x5 == -0x1.6f08c83d80ef6p+5);
  check (x6 == -0x1.d8009be4a79b4p+4);
  check (strcmp(x7, "") == 0);
  check (x8 == 1965762088698384909);
  check (x9 == -0x1.2fc1deda862e6p+5);
  return -303041415;
}

void f718(int x0, ...)
{
  va_list l;
  va_start(l, x0);
  char * x1 = va_arg(l, char *);
  double x2 = va_arg(l, double);
  double x3 = va_arg(l, double);
  long long x4 = va_arg(l, long long);
  char * x5 = va_arg(l, char *);
  long long x6 = va_arg(l, long long);
  int x7 = va_arg(l, int);
  va_end(l);
  check (x0 == -425143655);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.9134f1e5b3c8p+4);
  check (x3 == 0x1.bb69a14932464p+3);
  check (x4 == -6259729363396866658);
  check (strcmp(x5, "v") == 0);
  check (x6 == 3178345139128936672);
  check (x7 == 1867949463);
}

short f719(void)
{
  return -424099173;
}

long long f720(void)
{
  return -9164859480658306097;
}

void f721(long long x0, long long x1, int x2, double x3, double x4, float x5)
{
  check (x0 == -7668166041995321423);
  check (x1 == 2623561741131440059);
  check (x2 == 1861166846);
  check (x3 == 0x1.96360dae9388p+4);
  check (x4 == 0x1.8456c3c74e538p+2);
  check (x5 == -0x1.0174eap+0F);
}

unsigned short f722(long long x0, float x1)
{
  check (x0 == 2536834788558919162);
  check (x1 == 0x1.277ec4p+5F);
  return -450455010;
}

