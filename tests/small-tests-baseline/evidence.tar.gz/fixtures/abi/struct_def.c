#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "struct_decl.h"

struct s1 f1(void)
{
  return (struct s1){450782004};
}

void f2(struct s1 x0)
{
  check (x0.a == 210);
}

void f3(struct s1 x0, struct s1 x1)
{
  check (x0.a == 234);
  check (x1.a == 188);
}

void f4(int x0, struct s1 x1)
{
  check (x0 == 1815701022);
  check (x1.a == 229);
}

void f5(double x0, struct s1 x1)
{
  check (x0 == 0x1.f76a831c5397p+2);
  check (x1.a == 5);
}

struct s2 f6(void)
{
  return (struct s2){-225722087};
}

void f7(struct s2 x0)
{
  check (x0.a == -105);
}

void f8(struct s2 x0, struct s2 x1)
{
  check (x0.a == 74);
  check (x1.a == -41);
}

void f9(int x0, struct s2 x1)
{
  check (x0 == 1947842430);
  check (x1.a == -34);
}

void f10(double x0, struct s2 x1)
{
  check (x0 == 0x1.1fc90e8ae4d78p+5);
  check (x1.a == 91);
}

struct s3 f11(void)
{
  return (struct s3){371045750};
}

void f12(struct s3 x0)
{
  check (x0.a == 61138);
}

void f13(struct s3 x0, struct s3 x1)
{
  check (x0.a == 47349);
  check (x1.a == 24581);
}

void f14(int x0, struct s3 x1)
{
  check (x0 == 242953397);
  check (x1.a == 49977);
}

void f15(double x0, struct s3 x1)
{
  check (x0 == 0x1.7c994f1a97fbp+3);
  check (x1.a == 36643);
}

struct s4 f16(void)
{
  return (struct s4){-252354681};
}

void f17(struct s4 x0)
{
  check (x0.a == 19286);
}

void f18(struct s4 x0, struct s4 x1)
{
  check (x0.a == 6472);
  check (x1.a == 734);
}

void f19(int x0, struct s4 x1)
{
  check (x0 == -1677478395);
  check (x1.a == 4352);
}

void f20(double x0, struct s4 x1)
{
  check (x0 == 0x1.098fb3dd45ef8p+5);
  check (x1.a == -16889);
}

struct s5 f21(void)
{
  return (struct s5){1577533673};
}

void f22(struct s5 x0)
{
  check (x0.a == 2061240087);
}

void f23(struct s5 x0, struct s5 x1)
{
  check (x0.a == 109785855);
  check (x1.a == -1908988732);
}

void f24(int x0, struct s5 x1)
{
  check (x0 == 986535705);
  check (x1.a == -275829590);
}

void f25(double x0, struct s5 x1)
{
  check (x0 == 0x1.b018822955398p+2);
  check (x1.a == -1819372239);
}

struct s6 f26(void)
{
  return (struct s6){-3105154652647668272};
}

void f27(struct s6 x0)
{
  check (x0.a == 3378611537454465391);
}

void f28(struct s6 x0, struct s6 x1)
{
  check (x0.a == 6537315735875373552);
  check (x1.a == 3416050011937819997);
}

void f29(int x0, struct s6 x1)
{
  check (x0 == -2123243015);
  check (x1.a == -4770020751718028244);
}

void f30(double x0, struct s6 x1)
{
  check (x0 == 0x1.8bcde682c8466p+5);
  check (x1.a == -3238782525965314528);
}

struct s7 f31(void)
{
  return (struct s7){0x1.1f537de4ed74p+5};
}

void f32(struct s7 x0)
{
  check (x0.a == -0x1.54fc0cp+5F);
}

void f33(struct s7 x0, struct s7 x1)
{
  check (x0.a == 0x1.274088p+3F);
  check (x1.a == -0x1.f72312p+2F);
}

void f34(int x0, struct s7 x1)
{
  check (x0 == 700688855);
  check (x1.a == -0x1.c0617cp+4F);
}

void f35(double x0, struct s7 x1)
{
  check (x0 == -0x1.260a64981aed2p+4);
  check (x1.a == -0x1.6070d4p+4F);
}

struct s8 f36(void)
{
  return (struct s8){-0x1.657e7ae346456p+4};
}

void f37(struct s8 x0)
{
  check (x0.a == 0x1.74a4ec30c5bcep+5);
}

void f38(struct s8 x0, struct s8 x1)
{
  check (x0.a == 0x1.3a13dc3c291b8p+5);
  check (x1.a == 0x1.090bd2521edc4p+4);
}

void f39(int x0, struct s8 x1)
{
  check (x0 == -1058592089);
  check (x1.a == 0x1.9512a51a88c2cp+4);
}

void f40(double x0, struct s8 x1)
{
  check (x0 == -0x1.0cb18c10ff00ep+5);
  check (x1.a == 0x1.287d6f4752cd2p+5);
}

struct s9 f41(void)
{
  return (struct s9){""};
}

void f42(struct s9 x0)
{
  check (strcmp(x0.a, "") == 0);
}

void f43(struct s9 x0, struct s9 x1)
{
  check (strcmp(x0.a, "") == 0);
  check (strcmp(x1.a, "s") == 0);
}

void f44(int x0, struct s9 x1)
{
  check (x0 == 117078430);
  check (strcmp(x1.a, "e") == 0);
}

void f45(double x0, struct s9 x1)
{
  check (x0 == -0x1.1870de6a4f604p+3);
  check (strcmp(x1.a, "o") == 0);
}

struct s10 f46(void)
{
  return (struct s10){-332354996, -212278338};
}

void f47(struct s10 x0)
{
  check (x0.a == 144);
  check (x0.b == 70);
}

void f48(struct s10 x0, struct s10 x1)
{
  check (x0.a == 5);
  check (x0.b == 128);
  check (x1.a == 214);
  check (x1.b == 16);
}

void f49(int x0, struct s10 x1)
{
  check (x0 == -1112381232);
  check (x1.a == 51);
  check (x1.b == 10);
}

void f50(double x0, struct s10 x1)
{
  check (x0 == 0x1.058d46e3148b2p+5);
  check (x1.a == 207);
  check (x1.b == 217);
}

struct s11 f51(void)
{
  return (struct s11){185612783, -223341175};
}

void f52(struct s11 x0)
{
  check (x0.a == 59);
  check (x0.b == 48682);
}

void f53(struct s11 x0, struct s11 x1)
{
  check (x0.a == 247);
  check (x0.b == 59224);
  check (x1.a == 174);
  check (x1.b == 46297);
}

void f54(int x0, struct s11 x1)
{
  check (x0 == 1285894652);
  check (x1.a == 28);
  check (x1.b == 43200);
}

void f55(double x0, struct s11 x1)
{
  check (x0 == -0x1.58b8b10825683p+4);
  check (x1.a == 246);
  check (x1.b == 63839);
}

struct s12 f56(void)
{
  return (struct s12){-78251852, -1906949473};
}

void f57(struct s12 x0)
{
  check (x0.a == 172);
  check (x0.b == 1933564125);
}

void f58(struct s12 x0, struct s12 x1)
{
  check (x0.a == 222);
  check (x0.b == 1964828987);
  check (x1.a == 173);
  check (x1.b == -394622240);
}

void f59(int x0, struct s12 x1)
{
  check (x0 == 1060027508);
  check (x1.a == 177);
  check (x1.b == -1716875482);
}

void f60(double x0, struct s12 x1)
{
  check (x0 == 0x1.22424233d124cp+4);
  check (x1.a == 225);
  check (x1.b == -875240157);
}

struct s13 f61(void)
{
  return (struct s13){3311735, -5188281542945856611};
}

void f62(struct s13 x0)
{
  check (x0.a == 2);
  check (x0.b == 2436054323590893261);
}

void f63(struct s13 x0, struct s13 x1)
{
  check (x0.a == 104);
  check (x0.b == -9002517791903262263);
  check (x1.a == 189);
  check (x1.b == -5040905127155251799);
}

void f64(int x0, struct s13 x1)
{
  check (x0 == -1607654603);
  check (x1.a == 45);
  check (x1.b == -1163175273696450282);
}

void f65(double x0, struct s13 x1)
{
  check (x0 == -0x1.25b6d9848376p+5);
  check (x1.a == 82);
  check (x1.b == 6629600029036599347);
}

struct s14 f66(void)
{
  return (struct s14){-76552535, -0x1.87727d845bbcp+1};
}

void f67(struct s14 x0)
{
  check (x0.a == 93);
  check (x0.b == 0x1.559ab4p+5F);
}

void f68(struct s14 x0, struct s14 x1)
{
  check (x0.a == 226);
  check (x0.b == -0x1.58fe98p-1F);
  check (x1.a == 42);
  check (x1.b == -0x1.3b4046p+4F);
}

void f69(int x0, struct s14 x1)
{
  check (x0 == -2124451791);
  check (x1.a == 129);
  check (x1.b == -0x1.09129p+5F);
}

void f70(double x0, struct s14 x1)
{
  check (x0 == 0x1.d0d8d023834a8p+2);
  check (x1.a == 51);
  check (x1.b == -0x1.b7948cp+3F);
}

struct s15 f71(void)
{
  return (struct s15){-294740630, 0x1.83d073d680ecp+1};
}

void f72(struct s15 x0)
{
  check (x0.a == 182);
  check (x0.b == 0x1.75b0578c78b96p+5);
}

void f73(struct s15 x0, struct s15 x1)
{
  check (x0.a == 212);
  check (x0.b == -0x1.34efea07bf133p+4);
  check (x1.a == 184);
  check (x1.b == 0x1.078c1542be3c4p+3);
}

void f74(int x0, struct s15 x1)
{
  check (x0 == 1723296699);
  check (x1.a == 235);
  check (x1.b == 0x1.f529ed56a3e5p+3);
}

void f75(double x0, struct s15 x1)
{
  check (x0 == -0x1.81ca9bad6beccp+4);
  check (x1.a == 127);
  check (x1.b == -0x1.088acf1b29a78p+2);
}

struct s16 f76(void)
{
  return (struct s16){25989974, 165566644};
}

void f77(struct s16 x0)
{
  check (x0.a == 43638);
  check (x0.b == 189);
}

void f78(struct s16 x0, struct s16 x1)
{
  check (x0.a == 59449);
  check (x0.b == 224);
  check (x1.a == 5525);
  check (x1.b == 8);
}

void f79(int x0, struct s16 x1)
{
  check (x0 == 2121459177);
  check (x1.a == 57641);
  check (x1.b == 158);
}

void f80(double x0, struct s16 x1)
{
  check (x0 == 0x1.cb6e5f02078d4p+4);
  check (x1.a == 22038);
  check (x1.b == 51);
}

struct s17 f81(void)
{
  return (struct s17){-346657644, -399262278};
}

void f82(struct s17 x0)
{
  check (x0.a == 56134);
  check (x0.b == 19889);
}

void f83(struct s17 x0, struct s17 x1)
{
  check (x0.a == 5586);
  check (x0.b == 9939);
  check (x1.a == 16365);
  check (x1.b == 52228);
}

void f84(int x0, struct s17 x1)
{
  check (x0 == 1448707066);
  check (x1.a == 16458);
  check (x1.b == 53118);
}

void f85(double x0, struct s17 x1)
{
  check (x0 == -0x1.f322227d4f5p+1);
  check (x1.a == 8126);
  check (x1.b == 40711);
}

struct s18 f86(void)
{
  return (struct s18){-518802928, -180084018};
}

void f87(struct s18 x0)
{
  check (x0.a == 20259);
  check (x0.b == -1123699173);
}

void f88(struct s18 x0, struct s18 x1)
{
  check (x0.a == 52911);
  check (x0.b == 1316307988);
  check (x1.a == 23796);
  check (x1.b == 919168191);
}

void f89(int x0, struct s18 x1)
{
  check (x0 == 566498622);
  check (x1.a == 47067);
  check (x1.b == -1996126542);
}

void f90(double x0, struct s18 x1)
{
  check (x0 == 0x1.390233be9b4acp+5);
  check (x1.a == 38078);
  check (x1.b == -218736169);
}

struct s19 f91(void)
{
  return (struct s19){-160067175, -1148990584631858503};
}

void f92(struct s19 x0)
{
  check (x0.a == 26934);
  check (x0.b == 4695337395212137791);
}

void f93(struct s19 x0, struct s19 x1)
{
  check (x0.a == 18443);
  check (x0.b == 2308107411769263091);
  check (x1.a == 40099);
  check (x1.b == 853874488809628856);
}

void f94(int x0, struct s19 x1)
{
  check (x0 == 1506521253);
  check (x1.a == 6834);
  check (x1.b == -7881179922387171957);
}

void f95(double x0, struct s19 x1)
{
  check (x0 == 0x1.95a932ddd5878p+4);
  check (x1.a == 30378);
  check (x1.b == -6366729590814299418);
}

struct s20 f96(void)
{
  return (struct s20){527721521, -0x1.84557f4d8fb77p+4};
}

void f97(struct s20 x0)
{
  check (x0.a == 45369);
  check (x0.b == -0x1.7fcf88p+5F);
}

void f98(struct s20 x0, struct s20 x1)
{
  check (x0.a == 12956);
  check (x0.b == 0x1.9cacecp+4F);
  check (x1.a == 6004);
  check (x1.b == -0x1.111764p+5F);
}

void f99(int x0, struct s20 x1)
{
  check (x0 == 244675052);
  check (x1.a == 24789);
  check (x1.b == -0x1.869ac4p+5F);
}

void f100(double x0, struct s20 x1)
{
  check (x0 == 0x1.1366d3bc60632p+5);
  check (x1.a == 38109);
  check (x1.b == 0x1.716a62p+5F);
}

struct s21 f101(void)
{
  return (struct s21){-109790911, -0x1.a265f09f9d44bp+4};
}

void f102(struct s21 x0)
{
  check (x0.a == 14396);
  check (x0.b == -0x1.47ed990b20901p+5);
}

void f103(struct s21 x0, struct s21 x1)
{
  check (x0.a == 35928);
  check (x0.b == -0x1.34cf327e7c506p+5);
  check (x1.a == 52565);
  check (x1.b == -0x1.103e8f280c46cp+4);
}

void f104(int x0, struct s21 x1)
{
  check (x0 == 1943647114);
  check (x1.a == 63711);
  check (x1.b == 0x1.b8581fe8fe738p+3);
}

void f105(double x0, struct s21 x1)
{
  check (x0 == -0x1.f71a225948d64p+3);
  check (x1.a == 13472);
  check (x1.b == 0x1.61118e76f0f1ap+5);
}

struct s22 f106(void)
{
  return (struct s22){1859156861, 282301053};
}

void f107(struct s22 x0)
{
  check (x0.a == -1304936796);
  check (x0.b == 230);
}

void f108(struct s22 x0, struct s22 x1)
{
  check (x0.a == 1062064619);
  check (x0.b == 71);
  check (x1.a == -367540222);
  check (x1.b == 101);
}

void f109(int x0, struct s22 x1)
{
  check (x0 == 866633562);
  check (x1.a == 783218622);
  check (x1.b == 241);
}

void f110(double x0, struct s22 x1)
{
  check (x0 == 0x1.8eb2dd062617p+5);
  check (x1.a == -1592439001);
  check (x1.b == 186);
}

struct s23 f111(void)
{
  return (struct s23){246019086, 287494752};
}

void f112(struct s23 x0)
{
  check (x0.a == -55831904);
  check (x0.b == 35132);
}

void f113(struct s23 x0, struct s23 x1)
{
  check (x0.a == 1416852830);
  check (x0.b == 27897);
  check (x1.a == -1403118349);
  check (x1.b == 19402);
}

void f114(int x0, struct s23 x1)
{
  check (x0 == -2122589996);
  check (x1.a == 129359416);
  check (x1.b == 55849);
}

void f115(double x0, struct s23 x1)
{
  check (x0 == -0x1.cabda96e77868p+3);
  check (x1.a == -1279079508);
  check (x1.b == 54912);
}

struct s24 f116(void)
{
  return (struct s24){-1812095004, 1890498760};
}

void f117(struct s24 x0)
{
  check (x0.a == 682879303);
  check (x0.b == 1996844329);
}

void f118(struct s24 x0, struct s24 x1)
{
  check (x0.a == -596900446);
  check (x0.b == -1719405343);
  check (x1.a == 1837081861);
  check (x1.b == -873812894);
}

void f119(int x0, struct s24 x1)
{
  check (x0 == 353368475);
  check (x1.a == -1256030666);
  check (x1.b == 2028339913);
}

void f120(double x0, struct s24 x1)
{
  check (x0 == 0x1.603d4384a88p+3);
  check (x1.a == -556428407);
  check (x1.b == -152436980);
}

struct s25 f121(void)
{
  return (struct s25){-1280826129, -7316568651887840872};
}

void f122(struct s25 x0)
{
  check (x0.a == 1062776017);
  check (x0.b == -9010939211461274409);
}

void f123(struct s25 x0, struct s25 x1)
{
  check (x0.a == 164787212);
  check (x0.b == 7988486642612859523);
  check (x1.a == -1211633452);
  check (x1.b == 4853087427906869595);
}

void f124(int x0, struct s25 x1)
{
  check (x0 == -1128257059);
  check (x1.a == -651978519);
  check (x1.b == -1081522815091978829);
}

void f125(double x0, struct s25 x1)
{
  check (x0 == 0x1.d6a006879d244p+4);
  check (x1.a == -409421860);
  check (x1.b == -4100805016390209027);
}

struct s26 f126(void)
{
  return (struct s26){-510167021, -0x1.0fcd96ac180dfp+5};
}

void f127(struct s26 x0)
{
  check (x0.a == 1571964502);
  check (x0.b == 0x1.87775ap+4F);
}

void f128(struct s26 x0, struct s26 x1)
{
  check (x0.a == -686332331);
  check (x0.b == -0x1.185584p+5F);
  check (x1.a == -1172813156);
  check (x1.b == -0x1.df67c4p+1F);
}

void f129(int x0, struct s26 x1)
{
  check (x0 == -1742504644);
  check (x1.a == -750563089);
  check (x1.b == -0x1.4c8af6p+5F);
}

void f130(double x0, struct s26 x1)
{
  check (x0 == 0x1.4e5f19dee8188p+2);
  check (x1.a == -1538611978);
  check (x1.b == 0x1.5b25aap+3F);
}

struct s27 f131(void)
{
  return (struct s27){-1473845158, 0x1.6c855f5d7163cp+4};
}

void f132(struct s27 x0)
{
  check (x0.a == -304810474);
  check (x0.b == 0x1.b8e539e4752bp+3);
}

void f133(struct s27 x0, struct s27 x1)
{
  check (x0.a == -578950471);
  check (x0.b == 0x1.39ecb3dea4d58p+2);
  check (x1.a == -1387722108);
  check (x1.b == 0x1.a58f505e191p-2);
}

void f134(int x0, struct s27 x1)
{
  check (x0 == 1408255155);
  check (x1.a == -1991287261);
  check (x1.b == -0x1.b7c07b72f4fedp+4);
}

void f135(double x0, struct s27 x1)
{
  check (x0 == 0x1.279ee5a10222p+5);
  check (x1.a == 1408947757);
  check (x1.b == -0x1.acbdf9a1b5766p+4);
}

struct s28 f136(void)
{
  return (struct s28){-7378056962774999617, 465058032};
}

void f137(struct s28 x0)
{
  check (x0.a == 3005607600168193821);
  check (x0.b == 148);
}

void f138(struct s28 x0, struct s28 x1)
{
  check (x0.a == 5011935939289949336);
  check (x0.b == 186);
  check (x1.a == -6736231869584637411);
  check (x1.b == 37);
}

void f139(int x0, struct s28 x1)
{
  check (x0 == 568895837);
  check (x1.a == -2823089690153465173);
  check (x1.b == 88);
}

void f140(double x0, struct s28 x1)
{
  check (x0 == -0x1.0fdefcd5c7502p+5);
  check (x1.a == 7019838422983881864);
  check (x1.b == 25);
}

struct s29 f141(void)
{
  return (struct s29){-4946767010283495353, 290195719};
}

void f142(struct s29 x0)
{
  check (x0.a == 2141993738737130324);
  check (x0.b == 65028);
}

void f143(struct s29 x0, struct s29 x1)
{
  check (x0.a == 9199081016697467462);
  check (x0.b == 23575);
  check (x1.a == -3589997681132222015);
  check (x1.b == 6338);
}

void f144(int x0, struct s29 x1)
{
  check (x0 == -1571880597);
  check (x1.a == -4004709014795347406);
  check (x1.b == 42337);
}

void f145(double x0, struct s29 x1)
{
  check (x0 == -0x1.438dbf1dbd2a4p+5);
  check (x1.a == -4162783042393750771);
  check (x1.b == 45745);
}

struct s30 f146(void)
{
  return (struct s30){-5480136876204796410, -734103738};
}

void f147(struct s30 x0)
{
  check (x0.a == -7161632261904739433);
  check (x0.b == 384679893);
}

void f148(struct s30 x0, struct s30 x1)
{
  check (x0.a == 1655943856802705669);
  check (x0.b == -15766459);
  check (x1.a == 2785457078199258533);
  check (x1.b == -1219071335);
}

void f149(int x0, struct s30 x1)
{
  check (x0 == -860567012);
  check (x1.a == 8701319485013396684);
  check (x1.b == 397458395);
}

void f150(double x0, struct s30 x1)
{
  check (x0 == -0x1.41052823ef161p+5);
  check (x1.a == 7672003959483129798);
  check (x1.b == -237702836);
}

struct s31 f151(void)
{
  return (struct s31){-710116634788725456, -1125746084457454639};
}

void f152(struct s31 x0)
{
  check (x0.a == -2867377179166082689);
  check (x0.b == 2438115870243609249);
}

void f153(struct s31 x0, struct s31 x1)
{
  check (x0.a == -5567481585363274997);
  check (x0.b == -5810483165404764631);
  check (x1.a == -5673725954458197362);
  check (x1.b == -7902545747332296229);
}

void f154(int x0, struct s31 x1)
{
  check (x0 == 445643060);
  check (x1.a == -6407157356906237087);
  check (x1.b == -7912635108962811880);
}

void f155(double x0, struct s31 x1)
{
  check (x0 == 0x1.2fc80b7609958p+2);
  check (x1.a == 10246336403069655);
  check (x1.b == -7998521500189979172);
}

struct s32 f156(void)
{
  return (struct s32){4662808498417018043, 0x1.5d12e1fbd097p+4};
}

void f157(struct s32 x0)
{
  check (x0.a == 1775746362653330738);
  check (x0.b == 0x1.2a97cep+4F);
}

void f158(struct s32 x0, struct s32 x1)
{
  check (x0.a == 5863448758647772447);
  check (x0.b == -0x1.cb2d6p+3F);
  check (x1.a == -5996218570252070921);
  check (x1.b == -0x1.ebd756p+2F);
}

void f159(int x0, struct s32 x1)
{
  check (x0 == -1738047084);
  check (x1.a == -85604440416876734);
  check (x1.b == -0x1.fd9a8cp-2F);
}

void f160(double x0, struct s32 x1)
{
  check (x0 == 0x1.09215a7850c92p+5);
  check (x1.a == -2343741634815828736);
  check (x1.b == -0x1.6be4cap+4F);
}

struct s33 f161(void)
{
  return (struct s33){8242811742561973546, 0x1.469ae34a12b72p+5};
}

void f162(struct s33 x0)
{
  check (x0.a == 8187654296218072904);
  check (x0.b == -0x1.c422a91b28c18p+2);
}

void f163(struct s33 x0, struct s33 x1)
{
  check (x0.a == 568840137674323020);
  check (x0.b == 0x1.850fd04e7cb24p+4);
  check (x1.a == 3956869377390794029);
  check (x1.b == 0x1.429c0861059a6p+5);
}

void f164(int x0, struct s33 x1)
{
  check (x0 == -1479552307);
  check (x1.a == -4404512927516861989);
  check (x1.b == 0x1.85d985f7deab4p+5);
}

void f165(double x0, struct s33 x1)
{
  check (x0 == 0x1.a0531f84aefe4p+4);
  check (x1.a == 3411710355216270447);
  check (x1.b == -0x1.fabbfed91e862p+4);
}

struct s34 f166(void)
{
  return (struct s34){-0x1.7860eae198ed4p+4, -330285196};
}

void f167(struct s34 x0)
{
  check (x0.a == -0x1.1ccf16p+3F);
  check (x0.b == 221);
}

void f168(struct s34 x0, struct s34 x1)
{
  check (x0.a == -0x1.287ee6p+5F);
  check (x0.b == 245);
  check (x1.a == 0x1.217fp+2F);
  check (x1.b == 93);
}

void f169(int x0, struct s34 x1)
{
  check (x0 == -1152060004);
  check (x1.a == 0x1.2a87fp+5F);
  check (x1.b == 47);
}

void f170(double x0, struct s34 x1)
{
  check (x0 == -0x1.667ca9d844338p+5);
  check (x1.a == -0x1.31887cp+2F);
  check (x1.b == 165);
}

struct s35 f171(void)
{
  return (struct s35){-0x1.1f56614742eedp+5, -329433332};
}

void f172(struct s35 x0)
{
  check (x0.a == 0x1.4db9bp+5F);
  check (x0.b == 58051);
}

void f173(struct s35 x0, struct s35 x1)
{
  check (x0.a == 0x1.a5d26p+4F);
  check (x0.b == 37578);
  check (x1.a == 0x1.9d0bb2p+4F);
  check (x1.b == 13266);
}

void f174(int x0, struct s35 x1)
{
  check (x0 == -908212935);
  check (x1.a == -0x1.58bc1cp+4F);
  check (x1.b == 39395);
}

void f175(double x0, struct s35 x1)
{
  check (x0 == -0x1.33d3579316aa4p+4);
  check (x1.a == 0x1.c419dep+0F);
  check (x1.b == 63664);
}

struct s36 f176(void)
{
  return (struct s36){-0x1.345574cd53158p+2, -1344140964};
}

void f177(struct s36 x0)
{
  check (x0.a == 0x1.f359cap+4F);
  check (x0.b == 1515530165);
}

void f178(struct s36 x0, struct s36 x1)
{
  check (x0.a == 0x1.5b7388p+5F);
  check (x0.b == 138831035);
  check (x1.a == -0x1.385b36p+5F);
  check (x1.b == 524632817);
}

void f179(int x0, struct s36 x1)
{
  check (x0 == -574292381);
  check (x1.a == 0x1.a927eap+3F);
  check (x1.b == -1003427730);
}

void f180(double x0, struct s36 x1)
{
  check (x0 == 0x1.0f4f003a1f3c8p+5);
  check (x1.a == -0x1.2650cep+5F);
  check (x1.b == 73517053);
}

struct s37 f181(void)
{
  return (struct s37){0x1.bd2128998c488p+2, -2814264140199828456};
}

void f182(struct s37 x0)
{
  check (x0.a == 0x1.373314p+5F);
  check (x0.b == -2904724171930145257);
}

void f183(struct s37 x0, struct s37 x1)
{
  check (x0.a == 0x1.ceab26p+4F);
  check (x0.b == -4684592017084951337);
  check (x1.a == 0x1.245752p+5F);
  check (x1.b == 8811506025757711315);
}

void f184(int x0, struct s37 x1)
{
  check (x0 == 776883879);
  check (x1.a == -0x1.9bcd7ep+1F);
  check (x1.b == 8724643086277304086);
}

void f185(double x0, struct s37 x1)
{
  check (x0 == 0x1.0c920cc7eaf44p+3);
  check (x1.a == 0x1.fa9f7p+4F);
  check (x1.b == 5051693522324474451);
}

struct s38 f186(void)
{
  return (struct s38){-0x1.85e2d50c5e853p+5, -0x1.cb029a0898ab6p+4};
}

void f187(struct s38 x0)
{
  check (x0.a == -0x1.13eabcp+3F);
  check (x0.b == -0x1.a701c4p+2F);
}

void f188(struct s38 x0, struct s38 x1)
{
  check (x0.a == 0x1.ccd0aap+4F);
  check (x0.b == -0x1.8ed30ep+4F);
  check (x1.a == -0x1.7b7bdcp+5F);
  check (x1.b == 0x1.340a12p+4F);
}

void f189(int x0, struct s38 x1)
{
  check (x0 == 1032177843);
  check (x1.a == -0x1.01b14ap+4F);
  check (x1.b == 0x1.2e34c4p+5F);
}

void f190(double x0, struct s38 x1)
{
  check (x0 == -0x1.c1d1a68b26be8p+3);
  check (x1.a == 0x1.3401a6p+5F);
  check (x1.b == 0x1.49059ap+4F);
}

struct s39 f191(void)
{
  return (struct s39){0x1.21c25eadc2568p+5, -0x1.6e5e475105fp+2};
}

void f192(struct s39 x0)
{
  check (x0.a == 0x1.968e96p+4F);
  check (x0.b == 0x1.1626110abf4p+4);
}

void f193(struct s39 x0, struct s39 x1)
{
  check (x0.a == 0x1.9096eap+3F);
  check (x0.b == 0x1.506d3f537276p+5);
  check (x1.a == -0x1.16b7eap+5F);
  check (x1.b == 0x1.2ad880962da54p+5);
}

void f194(int x0, struct s39 x1)
{
  check (x0 == 1513575343);
  check (x1.a == 0x1.40d68p+4F);
  check (x1.b == -0x1.82cba080090ep+2);
}

void f195(double x0, struct s39 x1)
{
  check (x0 == -0x1.d69b6d766f33cp+3);
  check (x1.a == 0x1.dca3b8p+0F);
  check (x1.b == 0x1.16443a1bbcc9ep+5);
}

struct s40 f196(void)
{
  return (struct s40){-0x1.5ee3e8f11e13p+3, 449637252};
}

void f197(struct s40 x0)
{
  check (x0.a == -0x1.6670a18344cfcp+4);
  check (x0.b == 243);
}

void f198(struct s40 x0, struct s40 x1)
{
  check (x0.a == -0x1.5055ea4a0abp+5);
  check (x0.b == 182);
  check (x1.a == 0x1.53a980f365beep+5);
  check (x1.b == 152);
}

void f199(int x0, struct s40 x1)
{
  check (x0 == -1650214369);
  check (x1.a == 0x1.53468e56a9c94p+5);
  check (x1.b == 102);
}

void f200(double x0, struct s40 x1)
{
  check (x0 == -0x1.cc00496a40a53p+4);
  check (x1.a == -0x1.542f4b75417a4p+4);
  check (x1.b == 13);
}

struct s41 f201(void)
{
  return (struct s41){-0x1.1262ec08c024bp+5, -188365166};
}

void f202(struct s41 x0)
{
  check (x0.a == -0x1.61240d686e5b3p+5);
  check (x0.b == 31739);
}

void f203(struct s41 x0, struct s41 x1)
{
  check (x0.a == 0x1.ae05f06d853bcp+4);
  check (x0.b == 65242);
  check (x1.a == -0x1.1c71affe41b9cp+5);
  check (x1.b == 39294);
}

void f204(int x0, struct s41 x1)
{
  check (x0 == -664509735);
  check (x1.a == 0x1.d3e3008d5e254p+4);
  check (x1.b == 56787);
}

void f205(double x0, struct s41 x1)
{
  check (x0 == 0x1.456f981cf6fc8p+4);
  check (x1.a == -0x1.3b491b7a87698p+4);
  check (x1.b == 16624);
}

struct s42 f206(void)
{
  return (struct s42){0x1.2a67453a68c8cp+5, 421485310};
}

void f207(struct s42 x0)
{
  check (x0.a == 0x1.a6193dbcbc8fp+4);
  check (x0.b == 2047251715);
}

void f208(struct s42 x0, struct s42 x1)
{
  check (x0.a == 0x1.de529c6fe3718p+4);
  check (x0.b == -835133062);
  check (x1.a == 0x1.7ddd738872c1p+5);
  check (x1.b == -1442257695);
}

void f209(int x0, struct s42 x1)
{
  check (x0 == -1967902239);
  check (x1.a == 0x1.2a7bdb5479ddp+4);
  check (x1.b == -743385001);
}

void f210(double x0, struct s42 x1)
{
  check (x0 == -0x1.5b917bfede58fp+5);
  check (x1.a == 0x1.6a267c3ac7014p+3);
  check (x1.b == -197257186);
}

struct s43 f211(void)
{
  return (struct s43){0x1.8b69b9837f16p+0, -3274147762378740424};
}

void f212(struct s43 x0)
{
  check (x0.a == 0x1.3d28293c75148p+2);
  check (x0.b == -7321829404139722879);
}

void f213(struct s43 x0, struct s43 x1)
{
  check (x0.a == -0x1.45d4a9ae55716p+4);
  check (x0.b == -3118147426284939155);
  check (x1.a == -0x1.6b390de7bf05dp+5);
  check (x1.b == -8026731829316443005);
}

void f214(int x0, struct s43 x1)
{
  check (x0 == -237130372);
  check (x1.a == -0x1.19ddff71df142p+4);
  check (x1.b == 1283735415415508498);
}

void f215(double x0, struct s43 x1)
{
  check (x0 == -0x1.61e3899caedep+0);
  check (x1.a == -0x1.d1dfc36f5140ap+4);
  check (x1.b == 8392412469743728698);
}

struct s44 f216(void)
{
  return (struct s44){-0x1.f742fc7054999p+4, 0x1.5c329cf45a3e8p+2};
}

void f217(struct s44 x0)
{
  check (x0.a == 0x1.54260e37b4048p+5);
  check (x0.b == -0x1.034896p+5F);
}

void f218(struct s44 x0, struct s44 x1)
{
  check (x0.a == -0x1.2b31d47615ecap+5);
  check (x0.b == 0x1.41286ap+4F);
  check (x1.a == 0x1.0a404ee0abe3cp+4);
  check (x1.b == 0x1.16bfc6p+5F);
}

void f219(int x0, struct s44 x1)
{
  check (x0 == -842646073);
  check (x1.a == 0x1.b21cd6033b928p+2);
  check (x1.b == 0x1.5c338cp+5F);
}

void f220(double x0, struct s44 x1)
{
  check (x0 == -0x1.7379b58c8df78p+3);
  check (x1.a == 0x1.99c2711a35e64p+4);
  check (x1.b == 0x1.9d6a48p+4F);
}

struct s45 f221(void)
{
  return (struct s45){0x1.56ddc1dd6728ap+5, -0x1.8a82bc8a0c73ap+4};
}

void f222(struct s45 x0)
{
  check (x0.a == -0x1.6701c551fa2f5p+5);
  check (x0.b == 0x1.7cb358db3f008p+4);
}

void f223(struct s45 x0, struct s45 x1)
{
  check (x0.a == -0x1.c55cd912e6d9p+1);
  check (x0.b == 0x1.88dad986da584p+5);
  check (x1.a == -0x1.f0df065a19698p+2);
  check (x1.b == -0x1.6ccc12a200c6ap+4);
}

void f224(int x0, struct s45 x1)
{
  check (x0 == -1195593810);
  check (x1.a == -0x1.9296876cf3d81p+4);
  check (x1.b == 0x1.2ecd7b9a4b412p+5);
}

void f225(double x0, struct s45 x1)
{
  check (x0 == -0x1.e35ad3ba3e478p+3);
  check (x1.a == 0x1.46887322ab0e6p+5);
  check (x1.b == -0x1.cf59a532f72bp+3);
}

struct s46 f226(void)
{
  return (struct s46){474122694, -327058572, -201014825};
}

void f227(struct s46 x0)
{
  check (x0.a == 237);
  check (x0.b == 26);
  check (x0.c == 212);
}

void f228(struct s46 x0, struct s46 x1)
{
  check (x0.a == 91);
  check (x0.b == 113);
  check (x0.c == 40);
  check (x1.a == 60);
  check (x1.b == 190);
  check (x1.c == 61);
}

void f229(int x0, struct s46 x1)
{
  check (x0 == 245069159);
  check (x1.a == 54);
  check (x1.b == 150);
  check (x1.c == 64);
}

void f230(double x0, struct s46 x1)
{
  check (x0 == 0x1.0fdd921e670fp+5);
  check (x1.a == 184);
  check (x1.b == 117);
  check (x1.c == 34);
}

struct s47 f231(void)
{
  return (struct s47){142052201, 141668199, 144528927, -207219031};
}

void f232(struct s47 x0)
{
  check (x0.a == 75);
  check (x0.b == 5);
  check (x0.c == 239);
  check (x0.d == 187);
}

void f233(struct s47 x0, struct s47 x1)
{
  check (x0.a == 148);
  check (x0.b == 219);
  check (x0.c == 69);
  check (x0.d == 98);
  check (x1.a == 142);
  check (x1.b == 58);
  check (x1.c == 231);
  check (x1.d == 175);
}

void f234(int x0, struct s47 x1)
{
  check (x0 == 296626979);
  check (x1.a == 174);
  check (x1.b == 75);
  check (x1.c == 103);
  check (x1.d == 57);
}

void f235(double x0, struct s47 x1)
{
  check (x0 == 0x1.e23f3d6ade6e8p+4);
  check (x1.a == 74);
  check (x1.b == 227);
  check (x1.c == 198);
  check (x1.d == 233);
}

struct s48 f236(void)
{
  return (struct s48){-22210825, 274043924, -1101211, 78368612, 523064595, 81780727};
}

void f237(struct s48 x0)
{
  check (x0.a == 27);
  check (x0.b == 40);
  check (x0.c == 229);
  check (x0.d == 240);
  check (x0.e == 148);
  check (x0.f == 234);
}

void f238(struct s48 x0, struct s48 x1)
{
  check (x0.a == 87);
  check (x0.b == 114);
  check (x0.c == 152);
  check (x0.d == 62);
  check (x0.e == 109);
  check (x0.f == 163);
  check (x1.a == 15);
  check (x1.b == 188);
  check (x1.c == 181);
  check (x1.d == 2);
  check (x1.e == 248);
  check (x1.f == 140);
}

void f239(int x0, struct s48 x1)
{
  check (x0 == 2079325832);
  check (x1.a == 216);
  check (x1.b == 199);
  check (x1.c == 86);
  check (x1.d == 209);
  check (x1.e == 137);
  check (x1.f == 63);
}

void f240(double x0, struct s48 x1)
{
  check (x0 == -0x1.06d7a92efa24p+4);
  check (x1.a == 9);
  check (x1.b == 154);
  check (x1.c == 205);
  check (x1.d == 93);
  check (x1.e == 143);
  check (x1.f == 111);
}

struct s49 f241(void)
{
  return (struct s49){418520364, -282765937, -520207206, -231521292, 214907037, -311321263, 3900052, -133187363};
}

void f242(struct s49 x0)
{
  check (x0.a == 221);
  check (x0.b == 41);
  check (x0.c == 109);
  check (x0.d == 251);
  check (x0.e == 254);
  check (x0.f == 214);
  check (x0.g == 112);
  check (x0.h == 237);
}

void f243(struct s49 x0, struct s49 x1)
{
  check (x0.a == 148);
  check (x0.b == 66);
  check (x0.c == 61);
  check (x0.d == 98);
  check (x0.e == 182);
  check (x0.f == 148);
  check (x0.g == 100);
  check (x0.h == 33);
  check (x1.a == 64);
  check (x1.b == 168);
  check (x1.c == 133);
  check (x1.d == 25);
  check (x1.e == 220);
  check (x1.f == 38);
  check (x1.g == 155);
  check (x1.h == 165);
}

void f244(int x0, struct s49 x1)
{
  check (x0 == -1909846621);
  check (x1.a == 168);
  check (x1.b == 85);
  check (x1.c == 90);
  check (x1.d == 117);
  check (x1.e == 123);
  check (x1.f == 218);
  check (x1.g == 190);
  check (x1.h == 65);
}

void f245(double x0, struct s49 x1)
{
  check (x0 == 0x1.754e6b4fb978ap+5);
  check (x1.a == 179);
  check (x1.b == 14);
  check (x1.c == 26);
  check (x1.d == 181);
  check (x1.e == 146);
  check (x1.f == 86);
  check (x1.g == 235);
  check (x1.h == 136);
}

struct s50 f246(void)
{
  return (struct s50){529841374, 96140801, -219348850};
}

void f247(struct s50 x0)
{
  check (x0.a == 3184);
  check (x0.b == 35888);
  check (x0.c == 26143);
}

void f248(struct s50 x0, struct s50 x1)
{
  check (x0.a == 58134);
  check (x0.b == 56679);
  check (x0.c == 44157);
  check (x1.a == 29727);
  check (x1.b == 52086);
  check (x1.c == 25611);
}

void f249(int x0, struct s50 x1)
{
  check (x0 == -1485132521);
  check (x1.a == 52279);
  check (x1.b == 37455);
  check (x1.c == 19772);
}

void f250(double x0, struct s50 x1)
{
  check (x0 == -0x1.333bdd1a4244ap+5);
  check (x1.a == 32576);
  check (x1.b == 1951);
  check (x1.c == 58097);
}

struct s51 f251(void)
{
  return (struct s51){71746484, 416874075, 521324449, -188620674};
}

void f252(struct s51 x0)
{
  check (x0.a == 19420);
  check (x0.b == 41682);
  check (x0.c == 55561);
  check (x0.d == 50556);
}

void f253(struct s51 x0, struct s51 x1)
{
  check (x0.a == 62858);
  check (x0.b == 25015);
  check (x0.c == 3368);
  check (x0.d == 61980);
  check (x1.a == 7972);
  check (x1.b == 20325);
  check (x1.c == 29635);
  check (x1.d == 49359);
}

void f254(int x0, struct s51 x1)
{
  check (x0 == 1986989253);
  check (x1.a == 35995);
  check (x1.b == 5595);
  check (x1.c == 5601);
  check (x1.d == 59516);
}

void f255(double x0, struct s51 x1)
{
  check (x0 == 0x1.72a14178e685cp+4);
  check (x1.a == 58028);
  check (x1.b == 30442);
  check (x1.c == 64259);
  check (x1.d == 45284);
}

struct s52 f256(void)
{
  return (struct s52){452564714, 82950964, 13010246, 282159009, 375018737, 514294882};
}

void f257(struct s52 x0)
{
  check (x0.a == 56977);
  check (x0.b == 19555);
  check (x0.c == 44863);
  check (x0.d == 25916);
  check (x0.e == 11143);
  check (x0.f == 55452);
}

void f258(struct s52 x0, struct s52 x1)
{
  check (x0.a == 16179);
  check (x0.b == 47517);
  check (x0.c == 26166);
  check (x0.d == 60047);
  check (x0.e == 45932);
  check (x0.f == 28570);
  check (x1.a == 28115);
  check (x1.b == 41447);
  check (x1.c == 40727);
  check (x1.d == 55745);
  check (x1.e == 28367);
  check (x1.f == 61368);
}

void f259(int x0, struct s52 x1)
{
  check (x0 == -1689680134);
  check (x1.a == 8971);
  check (x1.b == 42578);
  check (x1.c == 30001);
  check (x1.d == 49857);
  check (x1.e == 37208);
  check (x1.f == 58052);
}

void f260(double x0, struct s52 x1)
{
  check (x0 == -0x1.c7ac8ef3d674p+0);
  check (x1.a == 11527);
  check (x1.b == 19073);
  check (x1.c == 58900);
  check (x1.d == 60365);
  check (x1.e == 15973);
  check (x1.f == 52841);
}

struct s53 f261(void)
{
  return (struct s53){-78859094, -161570977, 164665717, -508357419, 285591163, 101446347, -287506353, 2607461};
}

void f262(struct s53 x0)
{
  check (x0.a == 22527);
  check (x0.b == 60727);
  check (x0.c == 57855);
  check (x0.d == 33223);
  check (x0.e == 20659);
  check (x0.f == 27109);
  check (x0.g == 41121);
  check (x0.h == 65233);
}

void f263(struct s53 x0, struct s53 x1)
{
  check (x0.a == 16928);
  check (x0.b == 43105);
  check (x0.c == 3595);
  check (x0.d == 51739);
  check (x0.e == 18238);
  check (x0.f == 28644);
  check (x0.g == 12080);
  check (x0.h == 3400);
  check (x1.a == 50074);
  check (x1.b == 22671);
  check (x1.c == 8963);
  check (x1.d == 9542);
  check (x1.e == 42317);
  check (x1.f == 42135);
  check (x1.g == 47341);
  check (x1.h == 26661);
}

void f264(int x0, struct s53 x1)
{
  check (x0 == -1114110129);
  check (x1.a == 46800);
  check (x1.b == 25993);
  check (x1.c == 52371);
  check (x1.d == 28453);
  check (x1.e == 47369);
  check (x1.f == 49100);
  check (x1.g == 29742);
  check (x1.h == 1294);
}

void f265(double x0, struct s53 x1)
{
  check (x0 == 0x1.54cc521bf9a38p+4);
  check (x1.a == 11449);
  check (x1.b == 12769);
  check (x1.c == 57752);
  check (x1.d == 41012);
  check (x1.e == 1716);
  check (x1.f == 15136);
  check (x1.g == 5295);
  check (x1.h == 11598);
}

struct s54 f266(void)
{
  return (struct s54){40398235, 2128836673, -770196380};
}

void f267(struct s54 x0)
{
  check (x0.a == -813077584);
  check (x0.b == -822953675);
  check (x0.c == -1102354705);
}

void f268(struct s54 x0, struct s54 x1)
{
  check (x0.a == -1546544965);
  check (x0.b == -1120789179);
  check (x0.c == -319268428);
  check (x1.a == 875148878);
  check (x1.b == -653511120);
  check (x1.c == -227576861);
}

void f269(int x0, struct s54 x1)
{
  check (x0 == -1748889414);
  check (x1.a == -331560385);
  check (x1.b == 1930180550);
  check (x1.c == 1835925762);
}

void f270(double x0, struct s54 x1)
{
  check (x0 == 0x1.97ed0ae2aa0ep+3);
  check (x1.a == 1270154961);
  check (x1.b == 1222701288);
  check (x1.c == 68903934);
}

struct s55 f271(void)
{
  return (struct s55){-2094011745, 1244358849, 1504382843, -376502836};
}

void f272(struct s55 x0)
{
  check (x0.a == -636837872);
  check (x0.b == 602649651);
  check (x0.c == -1737972595);
  check (x0.d == -1095762535);
}

void f273(struct s55 x0, struct s55 x1)
{
  check (x0.a == 493652316);
  check (x0.b == 1414368155);
  check (x0.c == -873362258);
  check (x0.d == 1914939786);
  check (x1.a == 867832304);
  check (x1.b == 1710012470);
  check (x1.c == -2107262811);
  check (x1.d == 1899233657);
}

void f274(int x0, struct s55 x1)
{
  check (x0 == 1676010821);
  check (x1.a == 1888701279);
  check (x1.b == -126389512);
  check (x1.c == -1585042084);
  check (x1.d == 1592001549);
}

void f275(double x0, struct s55 x1)
{
  check (x0 == -0x1.3602402b58175p+5);
  check (x1.a == 594342856);
  check (x1.b == 1097502855);
  check (x1.c == -1269095678);
  check (x1.d == -724322331);
}

struct s56 f276(void)
{
  return (struct s56){-1344324086, -2014742986, -2052156259, -2113919123, 740385887, 1642647504};
}

void f277(struct s56 x0)
{
  check (x0.a == -1478527619);
  check (x0.b == 1083029283);
  check (x0.c == 1090657006);
  check (x0.d == -1946734822);
  check (x0.e == -79118108);
  check (x0.f == 278450333);
}

void f278(struct s56 x0, struct s56 x1)
{
  check (x0.a == -384472236);
  check (x0.b == -1129288703);
  check (x0.c == -368902093);
  check (x0.d == 1099237150);
  check (x0.e == -1215525153);
  check (x0.f == -418234137);
  check (x1.a == 1852653572);
  check (x1.b == 247991754);
  check (x1.c == -155090660);
  check (x1.d == 800929339);
  check (x1.e == -458785323);
  check (x1.f == -598412318);
}

void f279(int x0, struct s56 x1)
{
  check (x0 == -866899555);
  check (x1.a == 1105570655);
  check (x1.b == 998449963);
  check (x1.c == 70319619);
  check (x1.d == 1775060919);
  check (x1.e == -1627442816);
  check (x1.f == -1428647701);
}

void f280(double x0, struct s56 x1)
{
  check (x0 == -0x1.b9a05f3e9ff9dp+4);
  check (x1.a == 333479667);
  check (x1.b == -410714259);
  check (x1.c == -2028834241);
  check (x1.d == 1970859700);
  check (x1.e == -1549457394);
  check (x1.f == -2095839552);
}

struct s57 f281(void)
{
  return (struct s57){-1556001572, -741503189, 1089468836, -1749477125, 1613559968, 1262067752, -38315583, 424021687};
}

void f282(struct s57 x0)
{
  check (x0.a == -1239899849);
  check (x0.b == 1212598905);
  check (x0.c == -1939206716);
  check (x0.d == 1561341678);
  check (x0.e == -1760132827);
  check (x0.f == 473082591);
  check (x0.g == 1226188033);
  check (x0.h == -812375367);
}

void f283(struct s57 x0, struct s57 x1)
{
  check (x0.a == -1839575787);
  check (x0.b == 241057370);
  check (x0.c == -1020266062);
  check (x0.d == -1791510506);
  check (x0.e == -1992608852);
  check (x0.f == -989345356);
  check (x0.g == -821263593);
  check (x0.h == 1871873655);
  check (x1.a == -327970441);
  check (x1.b == -1033528309);
  check (x1.c == -755590432);
  check (x1.d == -878039353);
  check (x1.e == -1094998271);
  check (x1.f == 1700980336);
  check (x1.g == 1133496704);
  check (x1.h == 1145738069);
}

void f284(int x0, struct s57 x1)
{
  check (x0 == 1572115023);
  check (x1.a == -870901838);
  check (x1.b == 2093595905);
  check (x1.c == 1682659984);
  check (x1.d == 917318514);
  check (x1.e == 1547294906);
  check (x1.f == 1477264327);
  check (x1.g == -387644538);
  check (x1.h == 1334680527);
}

void f285(double x0, struct s57 x1)
{
  check (x0 == 0x1.aa7d89e6f78p-5);
  check (x1.a == 1696458700);
  check (x1.b == 1495023119);
  check (x1.c == 1207879464);
  check (x1.d == 1958961143);
  check (x1.e == -570063302);
  check (x1.f == 2106380128);
  check (x1.g == -215532182);
  check (x1.h == 310324292);
}

struct s58 f286(void)
{
  return (struct s58){2004723339903230192, 6397415174471306602, 4819258099187834544};
}

void f287(struct s58 x0)
{
  check (x0.a == 7864354302794522772);
  check (x0.b == -3195831438043025917);
  check (x0.c == 6497405992266599743);
}

void f288(struct s58 x0, struct s58 x1)
{
  check (x0.a == 6982636052040341865);
  check (x0.b == -9207998756414875964);
  check (x0.c == -7926330336746133022);
  check (x1.a == -1552305682186930785);
  check (x1.b == -8515405049812870959);
  check (x1.c == 1826485582942621559);
}

void f289(int x0, struct s58 x1)
{
  check (x0 == -1120420969);
  check (x1.a == 5891877809946940148);
  check (x1.b == 414198837228287746);
  check (x1.c == 1029957303263444594);
}

void f290(double x0, struct s58 x1)
{
  check (x0 == 0x1.c55cccd0d83p-1);
  check (x1.a == 3479737001473941325);
  check (x1.b == -5440816454689209583);
  check (x1.c == -2462842471211201829);
}

struct s59 f291(void)
{
  return (struct s59){-7837027076644551922, 4374303578401666934, 1620389363152891905, -4398874295435412346};
}

void f292(struct s59 x0)
{
  check (x0.a == 2208066821676405006);
  check (x0.b == -522667975979130469);
  check (x0.c == 6263431241607187268);
  check (x0.d == -8090070468402203799);
}

void f293(struct s59 x0, struct s59 x1)
{
  check (x0.a == -6154966703787290981);
  check (x0.b == 251239613809491994);
  check (x0.c == -4464866342266211079);
  check (x0.d == -3268472778921023930);
  check (x1.a == -1744277274733010432);
  check (x1.b == -3309836993627192140);
  check (x1.c == 1296595703325259959);
  check (x1.d == 3085954471522892401);
}

void f294(int x0, struct s59 x1)
{
  check (x0 == -2029660416);
  check (x1.a == 310382890322352710);
  check (x1.b == -7625140031200871166);
  check (x1.c == 6230910873971966405);
  check (x1.d == 3188053628766003827);
}

void f295(double x0, struct s59 x1)
{
  check (x0 == -0x1.8747c38d5c09cp+3);
  check (x1.a == 6167710983073211108);
  check (x1.b == 6228397073198854919);
  check (x1.c == 3085024040854890041);
  check (x1.d == 8712948434506908694);
}

struct s60 f296(void)
{
  return (struct s60){8830942043370466793, -7181376488475664989, 5475827025808791150, 1689952632491852805, 5202218061220139611, -5716583426545799401};
}

void f297(struct s60 x0)
{
  check (x0.a == -3652332570717718915);
  check (x0.b == -8385153050934849232);
  check (x0.c == 2796580170212265591);
  check (x0.d == -4761308511779651338);
  check (x0.e == -2011959598710697358);
  check (x0.f == -837830109172576315);
}

void f298(struct s60 x0, struct s60 x1)
{
  check (x0.a == -3741235593561171267);
  check (x0.b == -820991670170863378);
  check (x0.c == 5962138712415955169);
  check (x0.d == -2000609577541218522);
  check (x0.e == 65808555680337795);
  check (x0.f == 4218524788692500665);
  check (x1.a == 7445458094847756153);
  check (x1.b == 1791615147233262889);
  check (x1.c == 2529433344807568474);
  check (x1.d == 7184352829095371683);
  check (x1.e == 6159634947789934416);
  check (x1.f == 1444361232073586775);
}

void f299(int x0, struct s60 x1)
{
  check (x0 == 382590090);
  check (x1.a == -289330091119253646);
  check (x1.b == 579284392501295509);
  check (x1.c == -6054430554678754373);
  check (x1.d == -8583385428984158307);
  check (x1.e == -8541192730599954335);
  check (x1.f == -8904703611215753751);
}

void f300(double x0, struct s60 x1)
{
  check (x0 == 0x1.a98c86feb9258p+4);
  check (x1.a == 4057518156153265300);
  check (x1.b == -7477891924552959926);
  check (x1.c == -6320855859911932033);
  check (x1.d == 3935376049511752050);
  check (x1.e == -6590015501619187600);
  check (x1.f == -5399390337454439163);
}

struct s61 f301(void)
{
  return (struct s61){-2836254641330925163, -3971325912302539598, 8165075520375979388, 8021367050294595689, 5966289387050517868, -7251756001158949497, -461282064023901131, 7109988575795088431};
}

void f302(struct s61 x0)
{
  check (x0.a == 7034939172948071308);
  check (x0.b == 7424051237976585391);
  check (x0.c == -1208494439316553845);
  check (x0.d == 9120136251407028621);
  check (x0.e == -7095616490480762670);
  check (x0.f == -74090135265001715);
  check (x0.g == 9210700778121023134);
  check (x0.h == 3723443027841607681);
}

void f303(struct s61 x0, struct s61 x1)
{
  check (x0.a == -6924490146476521235);
  check (x0.b == -3050881640756342740);
  check (x0.c == 7333907952850625862);
  check (x0.d == -4465419502713426560);
  check (x0.e == 3554545626042267272);
  check (x0.f == -8037095940923102799);
  check (x0.g == -4038227020892648462);
  check (x0.h == -7810359266076428556);
  check (x1.a == 4869086151445624813);
  check (x1.b == 4494448565390693015);
  check (x1.c == 4944615466877424437);
  check (x1.d == 4169686391845976670);
  check (x1.e == -5045408152623293315);
  check (x1.f == 7414262994632409334);
  check (x1.g == -3193567555580175562);
  check (x1.h == -7796428337446052608);
}

void f304(int x0, struct s61 x1)
{
  check (x0 == -1003246920);
  check (x1.a == 4280713908087870217);
  check (x1.b == 8957439470917897101);
  check (x1.c == 1698121181740029815);
  check (x1.d == 6779422321090594172);
  check (x1.e == 7767898063319302534);
  check (x1.f == -8315006110463056353);
  check (x1.g == -5364749496295923286);
  check (x1.h == 1043632969619464456);
}

void f305(double x0, struct s61 x1)
{
  check (x0 == 0x1.6742a97d17bcep+5);
  check (x1.a == 534113460973376480);
  check (x1.b == -1972749546722034222);
  check (x1.c == -33440608009732110);
  check (x1.d == -6564347790249916681);
  check (x1.e == 4154932980812663836);
  check (x1.f == 5888594362943646845);
  check (x1.g == -3329671628006563281);
  check (x1.h == -587837659352929050);
}

struct s62 f306(void)
{
  return (struct s62){-0x1.ff9339a57288fp+4, -0x1.98d49c44638b8p+4, -0x1.c9e1bc02de657p+4};
}

void f307(struct s62 x0)
{
  check (x0.a == -0x1.1162bp+5F);
  check (x0.b == -0x1.807b94p+3F);
  check (x0.c == 0x1.3a0c0cp-1F);
}

void f308(struct s62 x0, struct s62 x1)
{
  check (x0.a == 0x1.41878ep+5F);
  check (x0.b == 0x1.73026p+4F);
  check (x0.c == 0x1.6d018p+5F);
  check (x1.a == 0x1.190304p+5F);
  check (x1.b == 0x1.0a7a2ap+5F);
  check (x1.c == 0x1.f71434p+4F);
}

void f309(int x0, struct s62 x1)
{
  check (x0 == -1407500543);
  check (x1.a == 0x1.29a304p+4F);
  check (x1.b == -0x1.c3eb7p+4F);
  check (x1.c == -0x1.59d91cp+5F);
}

void f310(double x0, struct s62 x1)
{
  check (x0 == -0x1.740935eb74bp+5);
  check (x1.a == 0x1.daa4e2p+2F);
  check (x1.b == 0x1.eaf3ep+2F);
  check (x1.c == 0x1.b02aa4p+4F);
}

struct s63 f311(void)
{
  return (struct s63){0x1.e6499c1270c28p+3, 0x1.5d59fe857a964p+4, -0x1.72b690335b40bp+4, -0x1.7f3dbee5bb16p+3};
}

void f312(struct s63 x0)
{
  check (x0.a == 0x1.db7992p+4F);
  check (x0.b == -0x1.297d58p+5F);
  check (x0.c == -0x1.1d00e8p+5F);
  check (x0.d == -0x1.4d2046p+4F);
}

void f313(struct s63 x0, struct s63 x1)
{
  check (x0.a == 0x1.8cf4b6p+5F);
  check (x0.b == 0x1.d2f372p+4F);
  check (x0.c == -0x1.957c24p+4F);
  check (x0.d == 0x1.8c9b98p+2F);
  check (x1.a == 0x1.4e89ep+5F);
  check (x1.b == 0x1.0ddfd6p+5F);
  check (x1.c == -0x1.d878b8p+3F);
  check (x1.d == -0x1.765e0ep+2F);
}

void f314(int x0, struct s63 x1)
{
  check (x0 == 933889343);
  check (x1.a == 0x1.1a7388p+5F);
  check (x1.b == 0x1.be655p+4F);
  check (x1.c == -0x1.b1e336p+4F);
  check (x1.d == 0x1.bfcab8p+1F);
}

void f315(double x0, struct s63 x1)
{
  check (x0 == 0x1.9565da10b5428p+3);
  check (x1.a == -0x1.74691ap+5F);
  check (x1.b == 0x1.4bdee8p+0F);
  check (x1.c == 0x1.38220ep-2F);
  check (x1.d == 0x1.60d2e2p+4F);
}

struct s64 f316(void)
{
  return (struct s64){-0x1.cf4aed40d5f98p+3, 0x1.0b903eee9a8c4p+3, 0x1.3f8f9229a0712p+5, 0x1.837df5dbf2336p+5, 0x1.979482a10868cp+3, 0x1.5e1522cc5933p+1};
}

void f317(struct s64 x0)
{
  check (x0.a == 0x1.a46886p+1F);
  check (x0.b == -0x1.bd9c16p+4F);
  check (x0.c == 0x1.cea754p+3F);
  check (x0.d == -0x1.cd8eb2p+3F);
  check (x0.e == 0x1.8776bcp+4F);
  check (x0.f == 0x1.d44592p+4F);
}

void f318(struct s64 x0, struct s64 x1)
{
  check (x0.a == 0x1.116bdp+3F);
  check (x0.b == -0x1.59e4d6p+2F);
  check (x0.c == -0x1.57a702p+2F);
  check (x0.d == -0x1.3cf316p+4F);
  check (x0.e == 0x1.0b3f48p+5F);
  check (x0.f == -0x1.014fdp+5F);
  check (x1.a == -0x1.2bc328p+5F);
  check (x1.b == 0x1.634adcp+4F);
  check (x1.c == -0x1.82e088p+5F);
  check (x1.d == -0x1.156496p+5F);
  check (x1.e == 0x1.d894b2p+4F);
  check (x1.f == -0x1.5989c4p+4F);
}

void f319(int x0, struct s64 x1)
{
  check (x0 == 945002968);
  check (x1.a == 0x1.8ee712p+2F);
  check (x1.b == 0x1.c74308p+4F);
  check (x1.c == -0x1.3c86c2p+5F);
  check (x1.d == -0x1.299344p+3F);
  check (x1.e == 0x1.89166ep+5F);
  check (x1.f == -0x1.3529e4p+5F);
}

void f320(double x0, struct s64 x1)
{
  check (x0 == -0x1.12d4bc17d7dcap+4);
  check (x1.a == 0x1.157d1ep+5F);
  check (x1.b == -0x1.98c918p+2F);
  check (x1.c == 0x1.fdcf56p+4F);
  check (x1.d == -0x1.116ceep+4F);
  check (x1.e == -0x1.65240cp+4F);
  check (x1.f == 0x1.3cd256p+3F);
}

struct s65 f321(void)
{
  return (struct s65){-0x1.7542cb4a7fd24p+4, 0x1.70198fa77577ap+5, 0x1.62edb517d1bfep+5, 0x1.0e4b8bf635024p+4, -0x1.572a7ee49d4d7p+5, 0x1.da5d39f64ffb8p+3, -0x1.64403c187c962p+5, -0x1.34087bce60e58p+5};
}

void f322(struct s65 x0)
{
  check (x0.a == -0x1.2d0a18p+5F);
  check (x0.b == 0x1.263c32p+5F);
  check (x0.c == -0x1.e7ec4p+1F);
  check (x0.d == 0x1.698d28p+4F);
  check (x0.e == 0x1.d2c596p+4F);
  check (x0.f == -0x1.ffd7dcp+3F);
  check (x0.g == -0x1.8733ecp+3F);
  check (x0.h == 0x1.cc62aep+4F);
}

void f323(struct s65 x0, struct s65 x1)
{
  check (x0.a == 0x1.1fa88ap+3F);
  check (x0.b == -0x1.2c1f46p+3F);
  check (x0.c == -0x1.71b844p+5F);
  check (x0.d == 0x1.ea3aacp+2F);
  check (x0.e == 0x1.34083ap+4F);
  check (x0.f == 0x1.43fdbep+4F);
  check (x0.g == 0x1.2c5822p+5F);
  check (x0.h == 0x1.3d9656p+5F);
  check (x1.a == 0x1.8b127p+5F);
  check (x1.b == 0x1.365e36p+1F);
  check (x1.c == -0x1.4145fep+5F);
  check (x1.d == -0x1.14c846p+5F);
  check (x1.e == 0x1.2fc51ep+4F);
  check (x1.f == 0x1.87cbcap+3F);
  check (x1.g == -0x1.084e42p+5F);
  check (x1.h == -0x1.5ca678p+4F);
}

void f324(int x0, struct s65 x1)
{
  check (x0 == -1642056878);
  check (x1.a == 0x1.258d6cp+3F);
  check (x1.b == 0x1.0802d2p+5F);
  check (x1.c == -0x1.ea0b76p+2F);
  check (x1.d == -0x1.7a98p+5F);
  check (x1.e == 0x1.a7b2eep+4F);
  check (x1.f == -0x1.1f9f58p+5F);
  check (x1.g == 0x1.687cb4p+2F);
  check (x1.h == 0x1.f014c6p+4F);
}

void f325(double x0, struct s65 x1)
{
  check (x0 == 0x1.3c7232c8cdbfcp+5);
  check (x1.a == -0x1.5e6bfap+0F);
  check (x1.b == -0x1.383e7ap+5F);
  check (x1.c == -0x1.b12666p+3F);
  check (x1.d == 0x1.13533ep+4F);
  check (x1.e == -0x1.326caep+5F);
  check (x1.f == 0x1.146b4p+5F);
  check (x1.g == -0x1.774394p+5F);
  check (x1.h == 0x1.8b446p+5F);
}

struct s66 f326(void)
{
  return (struct s66){-0x1.9bc58aec5d286p+4, 0x1.9daf2e6302a74p+4, 0x1.ab81943d83d38p+4};
}

void f327(struct s66 x0)
{
  check (x0.a == -0x1.53376b1963029p+5);
  check (x0.b == 0x1.665814bafc6aap+5);
  check (x0.c == 0x1.1336a0b3e11d4p+5);
}

void f328(struct s66 x0, struct s66 x1)
{
  check (x0.a == -0x1.0c6c7b81c04c4p+5);
  check (x0.b == 0x1.dc1b83d5f3294p+4);
  check (x0.c == -0x1.44ff3f19341ap+3);
  check (x1.a == 0x1.608c566865b92p+5);
  check (x1.b == -0x1.4d8561f18edc6p+5);
  check (x1.c == -0x1.3ffe08de67983p+4);
}

void f329(int x0, struct s66 x1)
{
  check (x0 == 1664566933);
  check (x1.a == 0x1.7f90a30d5ca74p+5);
  check (x1.b == 0x1.239d4a3d3891cp+5);
  check (x1.c == -0x1.6dcbaeec0388ap+5);
}

void f330(double x0, struct s66 x1)
{
  check (x0 == 0x1.62b1d078c9f78p+5);
  check (x1.a == 0x1.e9df584ddf398p+4);
  check (x1.b == -0x1.1550b80e48d35p+5);
  check (x1.c == 0x1.580f5ef149d64p+4);
}

struct s67 f331(void)
{
  return (struct s67){0x1.e6c1914db64b8p+3, 0x1.bf7347cdd7c14p+4, 0x1.2a823ee8e93dp+2, 0x1.22b7d94bdedd8p+5};
}

void f332(struct s67 x0)
{
  check (x0.a == -0x1.8f3b3fe21d63fp+4);
  check (x0.b == 0x1.8edf87cbd3de6p+5);
  check (x0.c == 0x1.737998cf66e1p+2);
  check (x0.d == 0x1.e7c46be0b456p+3);
}

void f333(struct s67 x0, struct s67 x1)
{
  check (x0.a == 0x1.1dfae375a503p+3);
  check (x0.b == -0x1.516124cb465f2p+5);
  check (x0.c == -0x1.69a2cf819a87bp+5);
  check (x0.d == 0x1.8662282fefce4p+3);
  check (x1.a == -0x1.7bd181bd5bd87p+5);
  check (x1.b == -0x1.5247e134df66cp+5);
  check (x1.c == -0x1.0c0289f0de9ap+0);
  check (x1.d == -0x1.47dceb5197aa4p+5);
}

void f334(int x0, struct s67 x1)
{
  check (x0 == -702763847);
  check (x1.a == -0x1.b1b4ab4ffba08p+3);
  check (x1.b == 0x1.7588b492be574p+4);
  check (x1.c == -0x1.e1657fdf51cbp+1);
  check (x1.d == -0x1.63de953d7daacp+5);
}

void f335(double x0, struct s67 x1)
{
  check (x0 == -0x1.06a48c40463f6p+5);
  check (x1.a == -0x1.659cce37b7cep+5);
  check (x1.b == -0x1.0331f0f34f6a5p+5);
  check (x1.c == -0x1.65b0991b573dep+5);
  check (x1.d == -0x1.d1ad7a98e38bcp+4);
}

struct s68 f336(void)
{
  return (struct s68){-0x1.47c854887bce2p+5, -0x1.1722cbd292fe2p+4, 0x1.4c79c99fddeep+3, 0x1.158cb75ab5c7p+5, 0x1.81cccffe73c0cp+5, 0x1.a620afbf5b5ep+2};
}

void f337(struct s68 x0)
{
  check (x0.a == 0x1.4f63f19cc8dp-1);
  check (x0.b == 0x1.8603de811393p+4);
  check (x0.c == -0x1.100e785ed98e8p+2);
  check (x0.d == 0x1.2b95fb65bdac4p+3);
  check (x0.e == 0x1.59b0c62f1d014p+4);
  check (x0.f == -0x1.64956ce26016cp+5);
}

void f338(struct s68 x0, struct s68 x1)
{
  check (x0.a == 0x1.f644a3a98603p+4);
  check (x0.b == -0x1.e62c8c14332dp+2);
  check (x0.c == 0x1.bb4d44f79f7ap+1);
  check (x0.d == 0x1.e9e8a3d270b2p+0);
  check (x0.e == 0x1.17b5ac39bf5e6p+5);
  check (x0.f == 0x1.6c9eeba3648d4p+4);
  check (x1.a == 0x1.edbde86ef09c8p+2);
  check (x1.b == 0x1.09762f5548fc8p+4);
  check (x1.c == -0x1.326c3c7a0dbb6p+5);
  check (x1.d == -0x1.4a8784429524p+3);
  check (x1.e == -0x1.fc75de31ea104p+3);
  check (x1.f == 0x1.5680174fe2ebp+4);
}

void f339(int x0, struct s68 x1)
{
  check (x0 == 869731840);
  check (x1.a == -0x1.022f54296131cp+5);
  check (x1.b == -0x1.24772b976360dp+5);
  check (x1.c == -0x1.3c664bd76b615p+4);
  check (x1.d == -0x1.23f92c9ab298p+5);
  check (x1.e == 0x1.98b98e67bd484p+4);
  check (x1.f == -0x1.1dacdb2044b2fp+5);
}

void f340(double x0, struct s68 x1)
{
  check (x0 == 0x1.731f29aa4dcp+3);
  check (x1.a == -0x1.a24d872667d84p+3);
  check (x1.b == 0x1.226d83e562718p+2);
  check (x1.c == 0x1.dc8f5a045eaap+2);
  check (x1.d == -0x1.8a3b4999e10bep+5);
  check (x1.e == -0x1.1d777ef2d1b83p+5);
  check (x1.f == -0x1.d601c48f3de31p+4);
}

struct s69 f341(void)
{
  return (struct s69){-0x1.0ba84e94c9146p+5, 0x1.648713a86aa9cp+3, 0x1.b0d130ee644f8p+2, 0x1.15a5aefe042c6p+5, 0x1.3ba9b7c2e7b5p+2, -0x1.99cd442771fp+0, -0x1.0bc54987b10ep+5, -0x1.49a7d879f54fp+5};
}

void f342(struct s69 x0)
{
  check (x0.a == 0x1.efdc53b8015c8p+2);
  check (x0.b == 0x1.309d2c94305c8p+2);
  check (x0.c == -0x1.1c7d6caad7fcep+4);
  check (x0.d == 0x1.d15123511abdp+3);
  check (x0.e == -0x1.17cb2deb1c5c6p+4);
  check (x0.f == -0x1.4c0ca81a7becfp+5);
  check (x0.g == 0x1.9fee5424d4458p+4);
  check (x0.h == 0x1.04e2b403cb3f4p+5);
}

void f343(struct s69 x0, struct s69 x1)
{
  check (x0.a == -0x1.76c18ba7c07dfp+5);
  check (x0.b == 0x1.67c7c336bba8p+1);
  check (x0.c == -0x1.dd2f7652ddf08p+3);
  check (x0.d == 0x1.ec21dec61013cp+4);
  check (x0.e == -0x1.f40fc3acb1bd2p+4);
  check (x0.f == 0x1.fa7df5567fcbp+4);
  check (x0.g == 0x1.bb7f913a5d3a8p+4);
  check (x0.h == 0x1.e6006071d52ecp+4);
  check (x1.a == 0x1.327fceaecc6bcp+4);
  check (x1.b == -0x1.5f6daab7109e9p+5);
  check (x1.c == 0x1.59ef6be351272p+5);
  check (x1.d == 0x1.7a2f5ea9254dap+5);
  check (x1.e == -0x1.0a13ed5bc6f4p+0);
  check (x1.f == 0x1.ed598d51a2a38p+2);
  check (x1.g == 0x1.83dae2b718454p+5);
  check (x1.h == 0x1.771e300f6a218p+5);
}

void f344(int x0, struct s69 x1)
{
  check (x0 == -1358227050);
  check (x1.a == 0x1.2bbaf3894d708p+4);
  check (x1.b == -0x1.4b514c968c44ap+5);
  check (x1.c == -0x1.18b308e9396e8p+3);
  check (x1.d == -0x1.7a0ef3c9c0c58p+3);
  check (x1.e == -0x1.7f584962f2b58p+5);
  check (x1.f == 0x1.e28d459df0228p+2);
  check (x1.g == -0x1.59fe159a62ae2p+5);
  check (x1.h == -0x1.6645bff1952d8p+4);
}

void f345(double x0, struct s69 x1)
{
  check (x0 == -0x1.04b60cd0b7a54p+3);
  check (x1.a == -0x1.a7b99e9cb0cb5p+4);
  check (x1.b == 0x1.d0a54047f8908p+4);
  check (x1.c == 0x1.600ef8020edd8p+3);
  check (x1.d == -0x1.77cdb6a42f615p+5);
  check (x1.e == -0x1.66ea527a9b87ep+4);
  check (x1.f == -0x1.6b07f17c96871p+4);
  check (x1.g == -0x1.36588c07f7f48p+5);
  check (x1.h == -0x1.6769d1d7b38e3p+5);
}

