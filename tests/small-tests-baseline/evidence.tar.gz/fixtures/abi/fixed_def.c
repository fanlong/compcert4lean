#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "fixed_decl.h"

unsigned char f1(void)
{
  return 450782004;
}

signed char f2(void)
{
  return -177445934;
}

unsigned short f3(void)
{
  return 527586794;
}

short f4(void)
{
  return 48391612;
}

int f5(void)
{
  return 1815701022;
}

long long f6(void)
{
  return 6091190040057659072;
}

float f7(void)
{
  return -0x1.505a247cb0c84p+4;
}

double f8(void)
{
  return 0x1.8bdf6347217p+4;
}

char * f9(void)
{
  return "";
}

void f10(unsigned char x0)
{
  check (x0 == 185);
}

void f11(signed char x0)
{
  check (x0 == 126);
}

void f12(unsigned short x0)
{
  check (x0 == 62686);
}

void f13(short x0)
{
  check (x0 == -21695);
}

void f14(int x0)
{
  check (x0 == 80612187);
}

void f15(long long x0)
{
  check (x0 == 7019629353647716597);
}

void f16(float x0)
{
  check (x0 == -0x1.6d963ap+3F);
}

void f17(double x0)
{
  check (x0 == -0x1.276eef6957e28p+4);
}

void f18(char * x0)
{
  check (strcmp(x0, "") == 0);
}

void f19(int x0, int x1)
{
  check (x0 == -1890349277);
  check (x1 == -897103018);
}

void f20(int x0, long long x1)
{
  check (x0 == 512557790);
  check (x1 == 2810507307273687296);
}

void f21(int x0, float x1)
{
  check (x0 == 893301306);
  check (x1 == -0x1.5a88dap+5F);
}

void f22(int x0, double x1)
{
  check (x0 == 1076806509);
  check (x1 == -0x1.66b1425c8106ap+5);
}

void f23(long long x0, int x1)
{
  check (x0 == -215848110264998716);
  check (x1 == 986535705);
}

void f24(long long x0, long long x1)
{
  check (x0 == 8927202270820107824);
  check (x1 == 2486169674628109617);
}

void f25(long long x0, float x1)
{
  check (x0 == -3105154652647668272);
  check (x1 == 0x1.5861f8p+5F);
}

void f26(long long x0, double x1)
{
  check (x0 == -636674504077813734);
  check (x1 == -0x1.ebd6f2e8c1b32p+4);
}

void f27(float x0, int x1)
{
  check (x0 == -0x1.257778p+5F);
  check (x1 == -2123243015);
}

void f28(float x0, long long x1)
{
  check (x0 == 0x1.22221ap+5F);
  check (x1 == -3617192151061228944);
}

void f29(float x0, float x1)
{
  check (x0 == -0x1.eeb6b2p+4F);
  check (x1 == 0x1.56b9f8p+4F);
}

void f30(float x0, double x1)
{
  check (x0 == -0x1.1bf59p+5F);
  check (x1 == 0x1.7fac25ed81fap+0);
}

void f31(double x0, int x1)
{
  check (x0 == 0x1.eb2f1b04ce814p+4);
  check (x1 == 1578492036);
}

void f32(double x0, long long x1)
{
  check (x0 == 0x1.c680bbf7506e8p+4);
  check (x1 == -1895641904108992969);
}

void f33(double x0, float x1)
{
  check (x0 == -0x1.6070d3ba43266p+4);
  check (x1 == -0x1.657e7ap+4F);
}

void f34(double x0, double x1)
{
  check (x0 == 0x1.74a4ec30c5bcep+5);
  check (x1 == 0x1.3a13dc3c291b8p+5);
}

void f35(int x0, int x1, int x2)
{
  check (x0 == 1788482215);
  check (x1 == -1058592089);
  check (x2 == 808710687);
}

void f36(int x0, int x1, long long x2)
{
  check (x0 == -1971247106);
  check (x1 == 934813025);
  check (x2 == 814031241209297937);
}

void f37(int x0, int x1, float x2)
{
  check (x0 == -525776440);
  check (x1 == 117078430);
  check (x2 == -0x1.1b8b5p+4F);
}

void f38(int x0, int x1, double x2)
{
  check (x0 == 1516512386);
  check (x1 == -591211632);
  check (x2 == -0x1.3c51c26d3cfd8p+4);
}

void f39(int x0, long long x1, int x2)
{
  check (x0 == 149499974);
  check (x1 == 6719677545270994646);
  check (x2 == 338900670);
}

void f40(int x0, long long x1, long long x2)
{
  check (x0 == 857904947);
  check (x1 == -5849439672846215929);
  check (x2 == -280852419404875281);
}

void f41(int x0, long long x1, float x2)
{
  check (x0 == 1755375163);
  check (x1 == -6727825898062551208);
  check (x2 == -0x1.650bacp+5F);
}

void f42(int x0, long long x1, double x2)
{
  check (x0 == 1285894652);
  check (x1 == -4299976464738093729);
  check (x2 == 0x1.ca33868e8eap-3);
}

void f43(int x0, float x1, int x2)
{
  check (x0 == -615122764);
  check (x1 == -0x1.b9937ep+4F);
  check (x2 == 654724921);
}

void f44(int x0, float x1, long long x2)
{
  check (x0 == 1535564766);
  check (x1 == 0x1.07e964p+5F);
  check (x2 == -3414950968713114912);
}

void f45(int x0, float x1, float x2)
{
  check (x0 == 1060027508);
  check (x1 == -0x1.1eee98p+3F);
  check (x2 == 0x1.5124c2p+2F);
}

void f46(int x0, float x1, double x2)
{
  check (x0 == -1977467423);
  check (x1 == -0x1.f835ap+4F);
  check (x2 == 0x1.dcd9cfff277a8p+3);
}

void f47(int x0, double x1, int x2)
{
  check (x0 == -436264035);
  check (x1 == -0x1.655a9463c2934p+4);
  check (x2 == 590384845);
}

void f48(int x0, double x1, long long x2)
{
  check (x0 == 797519720);
  check (x1 == -0x1.7d995dad1b01ap+5);
  check (x2 == -2840591129732420102);
}

void f49(int x0, double x1, float x2)
{
  check (x0 == 1327314810);
  check (x1 == 0x1.7146df38c8d0ep+5);
  check (x2 == 0x1.88e29p+5F);
}

void f50(int x0, double x1, double x2)
{
  check (x0 == -2105695283);
  check (x1 == -0x1.cc7517d56db6p+1);
  check (x2 == 0x1.906b12247d51p+4);
}

void f51(long long x0, int x1, int x2)
{
  check (x0 == 3953027608139137348);
  check (x1 == -2141769635);
  check (x2 == 995364460);
}

void f52(long long x0, int x1, long long x2)
{
  check (x0 == 3036348530111388172);
  check (x1 == -1771018351);
  check (x2 == -5508074385608576975);
}

void f53(long long x0, int x1, float x2)
{
  check (x0 == 1300353776637137055);
  check (x1 == 614859284);
  check (x2 == 0x1.4a7892p+5F);
}

void f54(long long x0, int x1, double x2)
{
  check (x0 == 8330435943610353924);
  check (x1 == -1607422026);
  check (x2 == 0x1.75b0578c78b96p+5);
}

void f55(long long x0, long long x1, int x2)
{
  check (x0 == 4900083008501218242);
  check (x1 == -8283899911481238379);
  check (x2 == 1723296699);
}

void f56(long long x0, long long x1, long long x2)
{
  check (x0 == -5749845212926708381);
  check (x1 == -5466138798496885377);
  check (x2 == 7446334089332560726);
}

void f57(long long x0, long long x1, float x2)
{
  check (x0 == 5534830060667247037);
  check (x1 == -7365380488276470379);
  check (x2 == -0x1.bc7604p+4F);
}

void f58(long long x0, long long x1, double x2)
{
  check (x0 == -7625728545207071330);
  check (x1 == -4857091745999202794);
  check (x2 == -0x1.0247b2c2fdd32p+5);
}

void f59(long long x0, float x1, int x2)
{
  check (x0 == -6373447992649167439);
  check (x1 == 0x1.449de6p+5F);
  check (x2 == 2031799300);
}

void f60(long long x0, float x1, long long x2)
{
  check (x0 == -7667834668602802102);
  check (x1 == 0x1.f58582p+4F);
  check (x2 == -3503088096956866809);
}

void f61(long long x0, float x1, float x2)
{
  check (x0 == 30207952216662734);
  check (x1 == -0x1.3461d2p+5F);
  check (x2 == -0x1.f279a2p+3F);
}

void f62(long long x0, float x1, double x2)
{
  check (x0 == -7809997096130159372);
  check (x1 == 0x1.1cd56cp+5F);
  check (x2 == 0x1.613098b9e68cp+1);
}

void f63(long long x0, double x1, int x2)
{
  check (x0 == -4788194311407302990);
  check (x1 == 0x1.390233be9b4acp+5);
  check (x2 == -1198195661);
}

void f64(long long x0, double x1, long long x2)
{
  check (x0 == 8475040464703966319);
  check (x1 == 0x1.2bdec1115d22p+0);
  check (x2 == 6941207221076541935);
}

void f65(long long x0, double x1, float x2)
{
  check (x0 == -213971547767150030);
  check (x1 == -0x1.c32b9d44f36e1p+4);
  check (x2 == -0x1.13702ep+5F);
}

void f66(long long x0, double x1, double x2)
{
  check (x0 == -5399524384024240867);
  check (x1 == 0x1.00a54db609c88p+5);
  check (x2 == -0x1.0caac92d227eap+5);
}

void f67(float x0, int x1, int x2)
{
  check (x0 == -0x1.aa788ap+2F);
  check (x1 == -280070486);
  check (x2 == -1634511699);
}

void f68(float x0, int x1, long long x2)
{
  check (x0 == 0x1.892ee4p+5F);
  check (x1 == -1871219255);
  check (x2 == -6922425297852985686);
}

void f69(float x0, int x1, float x2)
{
  check (x0 == -0x1.0150a6p+3F);
  check (x1 == 200873844);
  check (x2 == -0x1.111764p+5F);
}

void f70(float x0, int x1, double x2)
{
  check (x0 == -0x1.b367ep+4F);
  check (x1 == 1603840508);
  check (x2 == -0x1.37e73734da6b1p+5);
}

void f71(float x0, long long x1, int x2)
{
  check (x0 == 0x1.fb618ap+4F);
  check (x1 == -1196998339766994623);
  check (x2 == 1329830455);
}

void f72(float x0, long long x1, long long x2)
{
  check (x0 == 0x1.3edfep+2F);
  check (x1 == -3765815135498981049);
  check (x2 == -485628630304223850);
}

void f73(float x0, long long x1, float x2)
{
  check (x0 == 0x1.47d3cp+5F);
  check (x1 == -6618604561373503371);
  check (x2 == -0x1.246b1cp+2F);
}

void f74(float x0, long long x1, double x2)
{
  check (x0 == -0x1.4dc4dcp+4F);
  check (x1 == 2238207705307226773);
  check (x2 == 0x1.a4a94e4749704p+4);
}

void f75(float x0, float x1, int x2)
{
  check (x0 == 0x1.c77e1ep+4F);
  check (x1 == 0x1.c42af4p+2F);
  check (x2 == -926654137);
}

void f76(float x0, float x1, long long x2)
{
  check (x0 == 0x1.f8a51p+3F);
  check (x1 == -0x1.83ffbp+5F);
  check (x2 == -6453396190629267522);
}

void f77(float x0, float x1, float x2)
{
  check (x0 == 0x1.e61716p+3F);
  check (x1 == -0x1.33261cp+1F);
  check (x2 == -0x1.f8d426p+1F);
}

void f78(float x0, float x1, double x2)
{
  check (x0 == -0x1.b1672ap+4F);
  check (x1 == 0x1.34f60ep+2F);
  check (x2 == -0x1.d185321899918p+3);
}

void f79(float x0, double x1, int x2)
{
  check (x0 == -0x1.20b98ap+4F);
  check (x1 == 0x1.30b623d07b094p+5);
  check (x2 == -901231670);
}

void f80(float x0, double x1, long long x2)
{
  check (x0 == -0x1.7d73eap+5F);
  check (x1 == -0x1.2f9ea63c8fc4p+5);
  check (x2 == -7066645457789567189);
}

void f81(float x0, double x1, float x2)
{
  check (x0 == 0x1.ee05e4p+4F);
  check (x1 == -0x1.226e0b63d6222p+5);
  check (x2 == 0x1.fac5d8p+1F);
}

void f82(float x0, double x1, double x2)
{
  check (x0 == -0x1.ed260cp+4F);
  check (x1 == 0x1.58403a407323ap+5);
  check (x2 == 0x1.93209fc07e1e8p+4);
}

void f83(double x0, int x1, int x2)
{
  check (x0 == -0x1.07a2072572e6ep+5);
  check (x1 == 1374121009);
  check (x2 == 1643292383);
}

void f84(double x0, int x1, long long x2)
{
  check (x0 == 0x1.36ebf4e14f56cp+3);
  check (x1 == -139571278);
  check (x2 == 6959212005104681673);
}

void f85(double x0, int x1, float x2)
{
  check (x0 == 0x1.603d4384a88p+3);
  check (x1 == -556428407);
  check (x2 == 0x1.1e6cf4p+5F);
}

void f86(double x0, int x1, double x2)
{
  check (x0 == 0x1.eb6b9b6196fecp+4);
  check (x1 == 1775849037);
  check (x2 == 0x1.ad8f25ea550cp-1);
}

void f87(double x0, long long x1, int x2)
{
  check (x0 == 0x1.6fa041285f51cp+5);
  check (x1 == -2446134964275251616);
  check (x2 == 819952374);
}

void f88(double x0, long long x1, long long x2)
{
  check (x0 == -0x1.60b0d11dc6fdcp+4);
  check (x1 == 7922390524902826388);
  check (x2 == 7139162357569542102);
}

void f89(double x0, long long x1, float x2)
{
  check (x0 == 0x1.416d8622bb108p+4);
  check (x1 == -7308682386173680917);
  check (x2 == -0x1.5c5b78p+5F);
}

void f90(double x0, long long x1, double x2)
{
  check (x0 == -0x1.2040f1c292bffp+5);
  check (x1 == -3902206868610871742);
  check (x2 == 0x1.5c04f6a7c2a8p+0);
}

void f91(double x0, float x1, int x2)
{
  check (x0 == 0x1.69fc837a8f958p+5);
  check (x1 == -0x1.c5b926p+3F);
  check (x2 == -1514800662);
}

void f92(double x0, float x1, long long x2)
{
  check (x0 == -0x1.0087d4b26222ap+4);
  check (x1 == -0x1.83300ep+4F);
  check (x2 == -3685631349062350180);
}

void f93(double x0, float x1, float x2)
{
  check (x0 == -0x1.df67c4ddd676p+1);
  check (x1 == -0x1.89118ap+3F);
  check (x2 == -0x1.3e6d18p+4F);
}

void f94(double x0, float x1, double x2)
{
  check (x0 == -0x1.4c8af547dd585p+5);
  check (x1 == 0x1.4e5f1ap+2F);
  check (x2 == 0x1.ad28705fd81b8p+2);
}

void f95(double x0, double x1, int x2)
{
  check (x0 == 0x1.5b25a9546754cp+3);
  check (x1 == 0x1.979961b0bed1p+3);
  check (x2 == 781496805);
}

void f96(double x0, double x1, long long x2)
{
  check (x0 == 0x1.59cc0836f5604p+4);
  check (x1 == 0x1.b8e539e4752bp+3);
  check (x2 == -621643334193414469);
}

void f97(double x0, double x1, float x2)
{
  check (x0 == 0x1.5373e1bee7b28p+2);
  check (x1 == -0x1.40f37acba7bbfp+5);
  check (x2 == -0x1.3f26c8p+4F);
}

void f98(double x0, double x1, double x2)
{
  check (x0 == 0x1.394781ae4ed6p+1);
  check (x1 == -0x1.74fecca573fc8p+2);
  check (x2 == -0x1.7bbbf2817c08p+2);
}

void f99(int x0, int x1, int x2, int x3)
{
  check (x0 == -322448375);
  check (x1 == 1816391595);
  check (x2 == 1172446457);
  check (x3 == 1899158975);
}

void f100(int x0, int x1, int x2, long long x3)
{
  check (x0 == 98119346);
  check (x1 == 507334429);
  check (x2 == 82599028);
  check (x3 == -6009762168677869894);
}

void f101(int x0, int x1, int x2, float x3)
{
  check (x0 == -1978637512);
  check (x1 == 1455296549);
  check (x2 == 568895837);
  check (x3 == 0x1.48b442p+2F);
}

void f102(int x0, int x1, int x2, double x3)
{
  check (x0 == -651180200);
  check (x1 == -1975511877);
  check (x2 == -2052200599);
  check (x3 == -0x1.68a228830cbd8p+4);
}

void f103(int x0, int x1, long long x2, int x3)
{
  check (x0 == -312068493);
  check (x1 == -246675193);
  check (x2 == 2141993738737130324);
  check (x3 == 72756087);
}

void f104(int x0, int x1, long long x2, long long x3)
{
  check (x0 == 608875078);
  check (x1 == -1014960308);
  check (x2 == 5469853127711791298);
  check (x3 == 2923892079632150092);
}

void f105(int x0, int x1, long long x2, float x3)
{
  check (x0 == 1884396082);
  check (x1 == 1525664605);
  check (x2 == -6103882318065480829);
  check (x3 == 0x1.334f3ap+5F);
}

void f106(int x0, int x1, long long x2, double x3)
{
  check (x0 == -808807889);
  check (x1 == -2114261717);
  check (x2 == 7415999042694616475);
  check (x3 == -0x1.d7ed9f1228ed5p+4);
}

void f107(int x0, int x1, float x2, int x3)
{
  check (x0 == 1899025601);
  check (x1 == 146223365);
  check (x2 == 0x1.8440cap+5F);
  check (x3 == -1700808239);
}

void f108(int x0, int x1, float x2, long long x3)
{
  check (x0 == 1310430298);
  check (x1 == 2071906495);
  check (x2 == 0x1.2a9b94p+4F);
  check (x3 == 1538580925615931364);
}

void f109(int x0, int x1, float x2, float x3)
{
  check (x0 == -380871711);
  check (x1 == 378020710);
  check (x2 == -0x1.8b3892p+5F);
  check (x3 == 0x1.bdcb9p+4F);
}

void f110(int x0, int x1, float x2, double x3)
{
  check (x0 == -661347653);
  check (x1 == 381536239);
  check (x2 == -0x1.80564p+4F);
  check (x3 == 0x1.4b6fcc51c618p+0);
}

void f111(int x0, int x1, double x2, int x3)
{
  check (x0 == -424158974);
  check (x1 == 1595726497);
  check (x2 == -0x1.073766362cebbp+5);
  check (x3 == -385130582);
}

void f112(int x0, int x1, double x2, long long x3)
{
  check (x0 == -1465293271);
  check (x1 == -989101768);
  check (x2 == -0x1.7cf585221bbfcp+5);
  check (x3 == -3945429839753295604);
}

void f113(int x0, int x1, double x2, float x3)
{
  check (x0 == 842257082);
  check (x1 == -1718439071);
  check (x2 == -0x1.227e596f2110ap+5);
  check (x3 == 0x1.004caap+5F);
}

void f114(int x0, int x1, double x2, double x3)
{
  check (x0 == 2076605536);
  check (x1 == 428726999);
  check (x2 == -0x1.5e16d64e3e9dp+5);
  check (x3 == -0x1.84d5009ed695p+1);
}

void f115(int x0, long long x1, int x2, int x3)
{
  check (x0 == -338582341);
  check (x1 == -2630769608351727663);
  check (x2 == -1792750286);
  check (x3 == -1410230378);
}

void f116(int x0, long long x1, int x2, long long x3)
{
  check (x0 == 1165794898);
  check (x1 == -864395359444466897);
  check (x2 == -1289446421);
  check (x3 == 8990493608382882555);
}

void f117(int x0, long long x1, int x2, float x3)
{
  check (x0 == -1738047084);
  check (x1 == -85604440416876734);
  check (x2 == -1615956318);
  check (x3 == 0x1.09215ap+5F);
}

void f118(int x0, long long x1, int x2, double x3)
{
  check (x0 == 2112187802);
  check (x1 == 783618840737200756);
  check (x2 == -913217938);
  check (x3 == 0x1.295b999dd680cp+4);
}

void f119(int x0, long long x1, long long x2, int x3)
{
  check (x0 == -46331081);
  check (x1 == -904698155544514642);
  check (x2 == -3966137881959615395);
  check (x3 == 665165669);
}

void f120(int x0, long long x1, long long x2, long long x3)
{
  check (x0 == -287763021);
  check (x1 == -36040568405750800);
  check (x2 == -7780422812546641203);
  check (x3 == -4404512927516861989);
}

void f121(int x0, long long x1, long long x2, float x3)
{
  check (x0 == 1060118322);
  check (x1 == -2582310199054981422);
  check (x2 == 9064621368939513022);
  check (x3 == 0x1.5ce258p+5F);
}

void f122(int x0, long long x1, long long x2, double x3)
{
  check (x0 == -867156108);
  check (x1 == 1626769021412313309);
  check (x2 == 2455008444113696245);
  check (x3 == 0x1.217eff006f498p+2);
}

void f123(int x0, long long x1, float x2, int x3)
{
  check (x0 == 1912031218);
  check (x1 == -4572503679388489139);
  check (x2 == -0x1.c219c2p+4F);
  check (x3 == -1317759643);
}

void f124(int x0, long long x1, float x2, long long x3)
{
  check (x0 == 911882661);
  check (x1 == -2143479123364987124);
  check (x2 == 0x1.4db9bp+5F);
  check (x3 == 3548237201410061436);
}

void f125(int x0, long long x1, float x2, float x3)
{
  check (x0 == -1614876653);
  check (x1 == 2024382277320690743);
  check (x2 == -0x1.614402p+5F);
  check (x3 == -0x1.4180fcp+5F);
}

void f126(int x0, long long x1, float x2, double x3)
{
  check (x0 == -1817190970);
  check (x1 == 596821572915558576);
  check (x2 == -0x1.345574p+2F);
  check (x3 == 0x1.8d12ea069196p+4);
}

void f127(int x0, long long x1, double x2, int x3)
{
  check (x0 == -201762310);
  check (x1 == 1627288124458155545);
  check (x2 == -0x1.1968c11ca463cp+4);
  check (x3 == -71701707);
}

void f128(int x0, long long x1, double x2, long long x3)
{
  check (x0 == 2106265504);
  check (x1 == 1256749851627290211);
  check (x2 == 0x1.a927eaad453d8p+3);
  check (x3 == -1077422321008948614);
}

void f129(int x0, long long x1, double x2, float x3)
{
  check (x0 == -846536731);
  check (x1 == -8312999434302404611);
  check (x2 == 0x1.bd2128998c488p+2);
  check (x3 == 0x1.79b21ep+2F);
}

void f130(int x0, long long x1, double x2, double x3)
{
  check (x0 == 130815322);
  check (x1 == 1059789740292793093);
  check (x2 == -0x1.62a7d285f598p+1);
  check (x3 == 0x1.3cb96ce6baaccp+4);
}

void f131(int x0, float x1, int x2, int x3)
{
  check (x0 == 1745179863);
  check (x1 == 0x1.245752p+5F);
  check (x2 == -383580114);
  check (x3 == -268769072);
}

void f132(int x0, float x1, int x2, long long x3)
{
  check (x0 == -483914150);
  check (x1 == 0x1.21d28p+5F);
  check (x2 == 1839226646);
  check (x3 == 8743674007445272811);
}

void f133(int x0, float x1, int x2, float x3)
{
  check (x0 == 796189844);
  check (x1 == -0x1.81647cp+3F);
  check (x2 == -1060167129);
  check (x3 == -0x1.cb029ap+4F);
}

void f134(int x0, float x1, int x2, double x3)
{
  check (x0 == 444288557);
  check (x1 == -0x1.a701c4p+2F);
  check (x2 == -1301364964);
  check (x3 == -0x1.8ed30e5bf3c24p+4);
}

void f135(int x0, float x1, long long x2, int x3)
{
  check (x0 == 1101278177);
  check (x1 == 0x1.340a12p+4F);
  check (x2 == 5719978539181324563);
  check (x3 == -497898371);
}

void f136(int x0, float x1, long long x2, long long x3)
{
  check (x0 == -926668119);
  check (x1 == 0x1.2de586p+5F);
  check (x2 == -3073456533012926684);
  check (x3 == 5605733868509837398);
}

void f137(int x0, float x1, long long x2, float x3)
{
  check (x0 == -212804632);
  check (x1 == -0x1.181802p+5F);
  check (x2 == -1031689432387615567);
  check (x3 == 0x1.506d4p+5F);
}

void f138(int x0, float x1, long long x2, double x3)
{
  check (x0 == -910960455);
  check (x1 == 0x1.2ad88p+5F);
  check (x2 == 1625189149833360736);
  check (x3 == -0x1.6090e0de7ca6p+4);
}

void f139(int x0, float x1, float x2, int x3)
{
  check (x0 == 1665708908);
  check (x1 == 0x1.7da7b4p+3F);
  check (x2 == 0x1.7e64fp+4F);
  check (x3 == 2037586676);
}

void f140(int x0, float x1, float x2, long long x3)
{
  check (x0 == 2060249988);
  check (x1 == -0x1.6670a2p+4F);
  check (x2 == 0x1.2d53fep+5F);
  check (x3 == 7542536437981289980);
}

void f141(int x0, float x1, float x2, float x3)
{
  check (x0 == 1534795160);
  check (x1 == -0x1.d81698p+1F);
  check (x2 == 0x1.53468ep+5F);
  check (x3 == 0x1.07eb5ap+5F);
}

void f142(int x0, float x1, float x2, double x3)
{
  check (x0 == 1105706173);
  check (x1 == -0x1.49dbbep+3F);
  check (x2 == -0x1.1262ecp+5F);
  check (x3 == 0x1.346935990ea0cp+5);
}

void f143(int x0, float x1, double x2, int x3)
{
  check (x0 == 1374387195);
  check (x1 == 0x1.ae05fp+4F);
  check (x2 == 0x1.3f231c6443c38p+4);
  check (x3 == -2073781890);
}

void f144(int x0, float x1, double x2, long long x3)
{
  check (x0 == -664509735);
  check (x1 == 0x1.d3e3p+4F);
  check (x2 == -0x1.12070fdffa2bp+1);
  check (x3 == -7034156418254800441);
}

void f145(int x0, float x1, double x2, float x3)
{
  check (x0 == 937102785);
  check (x1 == 0x1.8ec73cp+3F);
  check (x2 == -0x1.70dc342d2fc07p+4);
  check (x3 == -0x1.775892p+3F);
}

void f146(int x0, float x1, double x2, double x3)
{
  check (x0 == -90690405);
  check (x1 == -0x1.8c1eb2p+5F);
  check (x2 == -0x1.669f89c371c7fp+4);
  check (x3 == 0x1.876593d53775cp+5);
}

void f147(int x0, double x1, int x2, int x3)
{
  check (x0 == 1673201646);
  check (x1 == 0x1.be7747852e638p+4);
  check (x2 == 1739929451);
  check (x3 == -203456402);
}

void f148(int x0, double x1, int x2, long long x3)
{
  check (x0 == -1873091828);
  check (x1 == -0x1.376789a35766p+3);
  check (x2 == -1365003906);
  check (x3 == 7118220047331332052);
}

void f149(int x0, double x1, int x2, float x3)
{
  check (x0 == 735055145);
  check (x1 == 0x1.2ce8615d7a508p+3);
  check (x2 == 473819009);
  check (x3 == -0x1.45d4aap+4F);
}

void f150(int x0, double x1, int x2, double x3)
{
  check (x0 == 1390966206);
  check (x1 == -0x1.fe0ba56fd4ed8p+2);
  check (x2 == -1747689767);
  check (x3 == 0x1.7a668865f958p+5);
}

void f151(int x0, double x1, long long x2, int x3)
{
  check (x0 == -237130372);
  check (x1 == -0x1.19ddff71df142p+4);
  check (x2 == 1283735415415508498);
  check (x3 == -1625455909);
}

void f152(int x0, double x1, long long x2, long long x3)
{
  check (x0 == -1923255536);
  check (x1 == -0x1.613024530b7f7p+4);
  check (x2 == -6840535465861408322);
  check (x3 == 1792107979885872966);
}

void f153(int x0, double x1, long long x2, float x3)
{
  check (x0 == -624263162);
  check (x1 == 0x1.6a84d912b2ddap+5);
  check (x2 == -4078244858251663330);
  check (x3 == 0x1.0a404ep+4F);
}

void f154(int x0, double x1, long long x2, double x3)
{
  check (x0 == -162740179);
  check (x1 == -0x1.c7a3f7900957ap+4);
  check (x2 == -8568708503769201122);
  check (x3 == 0x1.9c8213d2c338cp+3);
}

void f155(int x0, double x1, float x2, int x3)
{
  check (x0 == -1837793097);
  check (x1 == 0x1.53012588e709cp+4);
  check (x2 == 0x1.2728a8p+3F);
  check (x3 == 1071652809);
}

void f156(int x0, double x1, float x2, long long x3)
{
  check (x0 == 1591089178);
  check (x1 == 0x1.17e01308a3f9p+5);
  check (x2 == -0x1.ee6d9ap+3F);
  check (x3 == -2826695336034194688);
}

void f157(int x0, double x1, float x2, float x3)
{
  check (x0 == 453509759);
  check (x1 == -0x1.6ccc12a200c6ap+4);
  check (x2 == 0x1.353694p+5F);
  check (x3 == -0x1.929688p+4F);
}

void f158(int x0, double x1, float x2, double x3)
{
  check (x0 == 2017027596);
  check (x1 == -0x1.e35ad3ba3e478p+3);
  check (x2 == 0x1.468874p+5F);
  check (x3 == -0x1.cf59a532f72bp+3);
}

void f159(int x0, double x1, double x2, int x3)
{
  check (x0 == -1937671308);
  check (x1 == -0x1.24d2e7a65c48cp+3);
  check (x2 == -0x1.0aacc86d4fc3p+3);
  check (x3 == -606700687);
}

void f160(int x0, double x1, double x2, long long x3)
{
  check (x0 == 335577148);
  check (x1 == -0x1.30f764002244p+2);
  check (x2 == -0x1.b2d188edb9ad3p+4);
  check (x3 == 7076110651949465664);
}

void f161(int x0, double x1, double x2, float x3)
{
  check (x0 == -1245721025);
  check (x1 == 0x1.016a1e3821294p+5);
  check (x2 == 0x1.a7593a9f8a584p+3);
  check (x3 == 0x1.aebad2p+3F);
}

void f162(int x0, double x1, double x2, double x3)
{
  check (x0 == 1188993099);
  check (x1 == 0x1.0d66353212372p+5);
  check (x2 == 0x1.5ba0e316efedcp+3);
  check (x3 == -0x1.955e7c386a60cp+4);
}

void f163(long long x0, int x1, int x2, int x3)
{
  check (x0 == 2474665750640503866);
  check (x1 == -24095825);
  check (x2 == 296626979);
  check (x3 == -1161208501);
}

void f164(long long x0, int x1, int x2, long long x3)
{
  check (x0 == 8210216938284524825);
  check (x1 == 414389322);
  check (x2 == -267673914);
  check (x3 == -7517838470881635308);
}

void f165(long long x0, int x1, int x2, float x3)
{
  check (x0 == 6425215932790822163);
  check (x1 == -534277605);
  check (x2 == 1003073253);
  check (x3 == -0x1.ceb14cp+3F);
}

void f166(long long x0, int x1, int x2, double x3)
{
  check (x0 == -5927925312940601998);
  check (x1 == 628237630);
  check (x2 == 1086877091);
  check (x3 == -0x1.7722fc9edae58p+4);
}

void f167(long long x0, int x1, long long x2, int x3)
{
  check (x0 == 6194051204194735608);
  check (x1 == 270143733);
  check (x2 == -8771181705065488441);
  check (x3 == -1733757743);
}

void f168(long long x0, int x1, long long x2, long long x3)
{
  check (x0 == -7394088360375319255);
  check (x1 == -1598016759);
  check (x2 == -5765134792816289955);
  check (x3 == -1059978567058580180);
}

void f169(long long x0, int x1, long long x2, float x3)
{
  check (x0 == -1135028986226457612);
  check (x1 == 1299291473);
  check (x2 == 5045137928792744157);
  check (x3 == -0x1.5a71ep+5F);
}

void f170(long long x0, int x1, long long x2, double x3)
{
  check (x0 == -5356947645683780394);
  check (x1 == 784803821);
  check (x2 == 5639154692196298557);
  check (x3 == 0x1.712e62ea80988p+5);
}

void f171(long long x0, int x1, float x2, int x3)
{
  check (x0 == 4619499530537415713);
  check (x1 == 931083944);
  check (x2 == 0x1.1e4f44p+5F);
  check (x3 == 62197542);
}

void f172(long long x0, int x1, float x2, long long x3)
{
  check (x0 == -5140431636941389006);
  check (x1 == -483271256);
  check (x2 == 0x1.0822d2p+3F);
  check (x3 == 6848517763051598298);
}

void f173(long long x0, int x1, float x2, float x3)
{
  check (x0 == -1776471520477350974);
  check (x1 == -78632525);
  check (x2 == -0x1.23e8fep+4F);
  check (x3 == -0x1.b4f176p+4F);
}

void f174(long long x0, int x1, float x2, double x3)
{
  check (x0 == 7143457754911430280);
  check (x1 == -1514471935);
  check (x2 == 0x1.4cd09cp+5F);
  check (x3 == 0x1.dd9df213308d8p+3);
}

void f175(long long x0, int x1, double x2, int x3)
{
  check (x0 == 7924144403258977405);
  check (x1 == -88749194);
  check (x2 == 0x1.0bf6597e3c1cp+2);
  check (x3 == -92681161);
}

void f176(long long x0, int x1, double x2, long long x3)
{
  check (x0 == -189270690806015766);
  check (x1 == 1018789696);
  check (x2 == -0x1.22a5acdc7b9a4p+3);
  check (x3 == 5635761901457819553);
}

void f177(long long x0, int x1, double x2, float x3)
{
  check (x0 == -2089367899785157934);
  check (x1 == 1964623228);
  check (x2 == -0x1.0ae03a8643801p+5);
  check (x3 == 0x1.712352p+5F);
}

void f178(long long x0, int x1, double x2, double x3)
{
  check (x0 == 5018298447023272899);
  check (x1 == -13904451);
  check (x2 == -0x1.d06a263de4f8p+1);
  check (x3 == 0x1.abd7230e6fec8p+4);
}

void f179(long long x0, long long x1, int x2, int x3)
{
  check (x0 == -4524041912124751857);
  check (x1 == -3732466241092453629);
  check (x2 == 989435626);
  check (x3 == 549881158);
}

void f180(long long x0, long long x1, int x2, long long x3)
{
  check (x0 == 2132055560661992546);
  check (x1 == 1710333324441136959);
  check (x2 == 514272135);
  check (x3 == -4566140067892512355);
}

void f181(long long x0, long long x1, int x2, float x3)
{
  check (x0 == 7349587223912297324);
  check (x1 == -6561221886651031065);
  check (x2 == -752100927);
  check (x3 == 0x1.32afb4p+5F);
}

void f182(long long x0, long long x1, int x2, double x3)
{
  check (x0 == -6425966247333911797);
  check (x1 == 3056217142423634625);
  check (x2 == 117301956);
  check (x3 == -0x1.c7ac8ef3d674p+0);
}

void f183(long long x0, long long x1, long long x2, int x3)
{
  check (x0 == 8840797654394725908);
  check (x1 == -2945829585958613399);
  check (x2 == -6514553790185563787);
  check (x3 == 1896203899);
}

void f184(long long x0, long long x1, long long x2, long long x3)
{
  check (x0 == -5496854366073140891);
  check (x1 == -708970260535385601);
  check (x2 == 8142108096765520357);
  check (x3 == 1924514459175043616);
}

void f185(long long x0, long long x1, long long x2, float x3)
{
  check (x0 == 1420819174330059291);
  check (x1 == -1531404222641262800);
  check (x2 == -8582259010771462001);
  check (x3 == -0x1.f82f5cp+4F);
}

void f186(long long x0, long long x1, long long x2, double x3)
{
  check (x0 == -2795071645367813907);
  check (x1 == 6643095038812751695);
  check (x2 == 637146520515759251);
  check (x3 == -0x1.6d7bdc3c8c91p+3);
}

void f187(long long x0, long long x1, float x2, int x3)
{
  check (x0 == -3676171997269981938);
  check (x1 == 5433717702196276409);
  check (x2 == 0x1.bd9808p+4F);
  check (x3 == 145098420);
}

void f188(long long x0, long long x1, float x2, long long x3)
{
  check (x0 == 194012314009349454);
  check (x1 == 43377275207605189);
  check (x2 == -0x1.f9df2ap+2F);
  check (x3 == 4855459320429112240);
}

void f189(long long x0, long long x1, float x2, float x3)
{
  check (x0 == -883639779349024358);
  check (x1 == -752315393760978757);
  check (x2 == 0x1.6cf26ep+5F);
  check (x3 == 0x1.4440c2p+4F);
}

void f190(long long x0, long long x1, float x2, double x3)
{
  check (x0 == 939683952992824707);
  check (x1 == 245696838050477027);
  check (x2 == -0x1.9c18bcp+3F);
  check (x3 == 0x1.31efc03bd707cp+4);
}

void f191(long long x0, long long x1, double x2, int x3)
{
  check (x0 == -2539170432973974895);
  check (x1 == 3012913133546673330);
  check (x2 == -0x1.fb52559365006p+4);
  check (x3 == 1222701288);
}

void f192(long long x0, long long x1, double x2, long long x3)
{
  check (x0 == -9149387000798893990);
  check (x1 == -77817178297243455);
  check (x2 == -0x1.3c96f9e95b5ccp+3);
  check (x3 == 4207419177394277271);
}

void f193(long long x0, long long x1, double x2, float x3)
{
  check (x0 == 748324998831911987);
  check (x1 == -6477819882023706310);
  check (x2 == -0x1.23b353670682p+3);
  check (x3 == 0x1.162682p+4F);
}

void f194(long long x0, long long x1, double x2, double x3)
{
  check (x0 == -5672005499270099794);
  check (x1 == -7167221097260429852);
  check (x2 == -0x1.12faa40965a88p+5);
  check (x3 == 0x1.3d6f6f50d078p+4);
}

void f195(long long x0, float x1, int x2, int x3)
{
  check (x0 == 5788075870483906937);
  check (x1 == 0x1.85cd9p+2F);
  check (x2 == 1888701279);
  check (x3 == -126389512);
}

void f196(long long x0, float x1, int x2, long long x3)
{
  check (x0 == 7521446059299352769);
  check (x1 == -0x1.8c0ba8p+4F);
  check (x2 == -881533844);
  check (x3 == -8428627804086955897);
}

void f197(long long x0, float x1, int x2, float x3)
{
  check (x0 == 3249004910838190703);
  check (x1 == -0x1.1771bcp+4F);
  check (x2 == -1237381754);
  check (x3 == 0x1.1e6cd4p+5F);
}

void f198(long long x0, float x1, int x2, double x3)
{
  check (x0 == -2592375470943099027);
  check (x1 == 0x1.2f42cep+4F);
  check (x2 == 1642647504);
  check (x3 == 0x1.89a4f29a63e84p+3);
}

void f199(long long x0, float x1, long long x2, int x3)
{
  check (x0 == 1162893838056953721);
  check (x1 == 0x1.528c04p-2F);
  check (x2 == -5830996756752973596);
  check (x3 == 278450333);
}

void f200(long long x0, float x1, long long x2, long long x3)
{
  check (x0 == 4198862099332348442);
  check (x1 == 0x1.942456p+3F);
  check (x2 == 4517141222267356958);
  check (x3 == -1305160193941866601);
}

void f201(long long x0, float x1, long long x2, float x3)
{
  check (x0 == 8819488965052416004);
  check (x1 == -0x1.ae76a8p+4F);
  check (x2 == 4445158690331229468);
  check (x3 == -0x1.3b7492p+5F);
}

void f202(long long x0, float x1, long long x2, double x3)
{
  check (x0 == 5904270852355322850);
  check (x1 == -0x1.ebc7fp+4F);
  check (x2 == 1187097452459844604);
  check (x3 == 0x1.0f32ab867e734p+3);
}

void f203(long long x0, float x1, float x2, int x3)
{
  check (x0 == 3908326628027877303);
  check (x1 == -0x1.9142a8p+0F);
  check (x2 == 0x1.0f2628p+4F);
  check (x3 == -1906983232);
}

void f204(long long x0, float x1, float x2, long long x3)
{
  check (x0 == -8865300970792611673);
  check (x1 == -0x1.e5049p+3F);
  check (x2 == -0x1.a09fc4p+4F);
  check (x3 == 5616242733852469262);
}

void f205(long long x0, float x1, float x2, float x3)
{
  check (x0 == -6862076601267372338);
  check (x1 == 0x1.43383p+4F);
  check (x2 == 0x1.0ba7c4p+5F);
  check (x3 == 0x1.7e5426p+5F);
}

void f206(long long x0, float x1, float x2, double x3)
{
  check (x0 == -5088635658223945568);
  check (x1 == -0x1.03afaep+5F);
  check (x2 == 0x1.7373e2p+5F);
  check (x3 == -0x1.5051203d425e8p+3);
}

void f207(long long x0, float x1, double x2, int x3)
{
  check (x0 == -1331332324954092403);
  check (x1 == -0x1.0b17p+5F);
  check (x2 == -0x1.b51188144d254p+3);
  check (x3 == -1413877754);
}

void f208(long long x0, float x1, double x2, long long x3)
{
  check (x0 == 6085340184930593503);
  check (x1 == -0x1.1e6b32p+5F);
  check (x2 == -0x1.9a889bed0e767p+4);
  check (x3 == 2636456557910330668);
}

void f209(long long x0, float x1, double x2, float x3)
{
  check (x0 == -6147606654240163406);
  check (x1 == -0x1.0d8f06p+4F);
  check (x2 == -0x1.1c9bfa17d8eb2p+5);
  check (x3 == -0x1.511ea6p+5F);
}

void f210(long long x0, float x1, double x2, double x3)
{
  check (x0 == -5493511086746694091);
  check (x1 == 0x1.6c9a74p+5F);
  check (x2 == 0x1.73dc8a702e926p+5);
  check (x3 == 0x1.917c432befb1p+4);
}

void f211(long long x0, double x1, int x2, int x3)
{
  check (x0 == 579008783723409095);
  check (x1 == 0x1.8029a797e5264p+5);
  check (x2 == 1700980336);
  check (x3 == 1133496704);
}

void f212(long long x0, double x1, int x2, long long x3)
{
  check (x0 == -7993145151972751931);
  check (x1 == -0x1.4056898acaedcp+3);
  check (x2 == -2132323439);
  check (x3 == 1990434579911760528);
}

void f213(long long x0, double x1, int x2, float x3)
{
  check (x0 == -8238408782220192719);
  check (x1 == -0x1.c5af6b0fe59d8p+2);
  check (x2 == -861751977);
  check (x3 == -0x1.63c216p+5F);
}

void f214(long long x0, double x1, int x2, double x3)
{
  check (x0 == -601774021993265247);
  check (x1 == 0x1.ffae8bdbd3ecp+2);
  check (x2 == 1495023119);
  check (x3 == -0x1.2c0f4688a9b65p+5);
}

void f215(long long x0, double x1, long long x2, int x3)
{
  check (x0 == -2508267507484212429);
  check (x1 == -0x1.448d43d68bafp+3);
  check (x2 == 701419690238885226);
  check (x3 == 310324292);
}

void f216(long long x0, double x1, long long x2, long long x3)
{
  check (x0 == 2004723339903230192);
  check (x1 == 0x1.38c9c2ca864b8p+2);
  check (x2 == -6365876345548454188);
  check (x3 == 806631166576636488);
}

void f217(long long x0, double x1, long long x2, float x3)
{
  check (x0 == 4869042912548651253);
  check (x1 == 0x1.2faf75fe3beep+3);
  check (x2 == -3412915635436990106);
  check (x3 == 0x1.1d0776p+3F);
}

void f218(long long x0, double x1, long long x2, double x3)
{
  check (x0 == -9207998756414875964);
  check (x1 == -0x1.2bff1c4b4384ep+5);
  check (x2 == 2995147394344315091);
  check (x3 == 0x1.70117c43e2c2p+4);
}

void f219(long long x0, double x1, float x2, int x3)
{
  check (x0 == 5896766846626993729);
  check (x1 == 0x1.4d5c855b36108p+3);
  check (x2 == 0x1.6d38a8p+5F);
  check (x3 == 1192271515);
}

void f220(long long x0, double x1, float x2, long long x3)
{
  check (x0 == 4896363821355900567);
  check (x1 == -0x1.d673e9a77d9dp+3);
  check (x2 == -0x1.0227cep+3F);
  check (x3 == -2872094945455825693);
}

void f221(long long x0, double x1, float x2, float x3)
{
  check (x0 == 8298102023564312779);
  check (x1 == -0x1.2486e69ff5328p+3);
  check (x2 == 0x1.230f4cp+5F);
  check (x3 == 0x1.13fb36p+2F);
}

void f222(long long x0, double x1, float x2, double x3)
{
  check (x0 == 6511906833904990659);
  check (x1 == 0x1.cac92a99da434p+4);
  check (x2 == -0x1.2e841cp+3F);
  check (x3 == 0x1.bcc29d948de98p+3);
}

void f223(long long x0, double x1, double x2, int x3)
{
  check (x0 == -7188185764807344847);
  check (x1 == -0x1.554d558b1ec45p+4);
  check (x2 == 0x1.2a9c21f9ddb7p+2);
  check (x3 == -964323787);
}

void f224(long long x0, double x1, double x2, long long x3)
{
  check (x0 == -2466526938875799864);
  check (x1 == 0x1.2cdc15664c598p+2);
  check (x2 == 0x1.02448f55e220cp+4);
  check (x3 == -5604780313563474845);
}

void f225(long long x0, double x1, double x2, float x3)
{
  check (x0 == -6517368045522489634);
  check (x1 == -0x1.5cd816336ac22p+5);
  check (x2 == -0x1.444c192efd5ap+1);
  check (x3 == -0x1.4abc6p+0F);
}

void f226(long long x0, double x1, double x2, double x3)
{
  check (x0 == 1072617192320951081);
  check (x1 == 0x1.fb7b7dece0df8p+3);
  check (x2 == 0x1.f3fe93c43b1a8p+3);
  check (x3 == 0x1.1a9f4432e3764p+4);
}

void f227(float x0, int x1, int x2, int x3)
{
  check (x0 == -0x1.206414p+5F);
  check (x1 == 766119712);
  check (x2 == 570808902);
  check (x3 == 1488469546);
}

void f228(float x0, int x1, int x2, long long x3)
{
  check (x0 == 0x1.231a9ep+5F);
  check (x1 == 1446494661);
  check (x2 == -1325860983);
  check (x3 == 4073052043159053580);
}

void f229(float x0, int x1, int x2, float x3)
{
  check (x0 == -0x1.e129c4p+3F);
  check (x1 == 646845237);
  check (x2 == 2082059015);
  check (x3 == 0x1.1954b6p+4F);
}

void f230(float x0, int x1, int x2, double x3)
{
  check (x0 == 0x1.a0c96ap+4F);
  check (x1 == 554992662);
  check (x2 == -365478912);
  check (x3 == 0x1.5bdffed1e5f2p+5);
}

void f231(float x0, int x1, long long x2, int x3)
{
  check (x0 == -0x1.82d2d8p+1F);
  check (x1 == 804794027);
  check (x2 == -1460371531416753188);
  check (x3 == 1576680964);
}

void f232(float x0, int x1, long long x2, long long x3)
{
  check (x0 == -0x1.54e752p+0F);
  check (x1 == -1029015899);
  check (x2 == 8425633346289220482);
  check (x3 == -2422870035341521176);
}

void f233(float x0, int x1, long long x2, float x3)
{
  check (x0 == 0x1.77600ap+4F);
  check (x1 == 258428535);
  check (x2 == -4761308511779651338);
  check (x3 == -0x1.8827a4p+4F);
}

void f234(float x0, int x1, long long x2, double x3)
{
  check (x0 == -0x1.84793ep-3F);
  check (x1 == 1755598789);
  check (x2 == -3741235593561171267);
  check (x3 == -0x1.535ad5763d128p+4);
}

void f235(float x0, int x1, float x2, int x3)
{
  check (x0 == -0x1.6967ep+5F);
  check (x1 == -148346655);
  check (x2 == -0x1.78674ep+4F);
  check (x3 == -2014059984);
}

void f236(float x0, int x1, float x2, long long x3)
{
  check (x0 == 0x1.96707ap-1F);
  check (x1 == -366159929);
  check (x2 == 0x1.e28d4ap+2F);
  check (x3 == 2404150199276534881);
}

void f237(float x0, int x1, float x2, float x3)
{
  check (x0 == 0x1.c463f2p+3F);
  check (x1 == -1939248921);
  check (x2 == -0x1.0d4bc2p+4F);
  check (x3 == 0x1.7e8ebap+4F);
}

void f238(float x0, int x1, float x2, double x3)
{
  check (x0 == -0x1.f79422p+3F);
  check (x1 == 266530065);
  check (x2 == -0x1.10b54p+4F);
  check (x3 == -0x1.cbcaed02cf56cp+3);
}

void f239(float x0, int x1, double x2, int x3)
{
  check (x0 == 0x1.8e794ep+4F);
  check (x1 == -1082560576);
  check (x2 == 0x1.1f188fccc7d66p+5);
  check (x3 == -1343660557);
}

void f240(float x0, int x1, double x2, long long x3)
{
  check (x0 == 0x1.75e3e6p+1F);
  check (x1 == -685594723);
  check (x2 == 0x1.256d8ce9a3f3cp+3);
  check (x3 == 2106706550183726330);
}

void f241(float x0, int x1, double x2, float x3)
{
  check (x0 == 0x1.6724aep+5F);
  check (x1 == -83593517);
  check (x2 == 0x1.7c554a80fbcp+4);
  check (x3 == 0x1.6571b8p+0F);
}

void f242(float x0, int x1, double x2, double x3)
{
  check (x0 == 0x1.7bda4cp+5F);
  check (x1 == -1316960385);
  check (x2 == -0x1.152322bc98cep+3);
  check (x3 == -0x1.334cf2449b99p+5);
}

void f243(float x0, long long x1, int x2, int x3)
{
  check (x0 == -0x1.663bc6p+4F);
  check (x1 == -5399390337454439163);
  check (x2 == 1653499321);
  check (x3 == 1391206508);
}

void f244(float x0, long long x1, int x2, long long x3)
{
  check (x0 == 0x1.5b935ep+4F);
  check (x1 == 8165075520375979388);
  check (x2 == -1119454379);
  check (x3 == -8054086477955329448);
}

void f245(float x0, long long x1, int x2, float x3)
{
  check (x0 == 0x1.51353ap+5F);
  check (x1 == -6321007264912992353);
  check (x2 == 546876469);
  check (x3 == -0x1.0a7452p+5F);
}

void f246(float x0, long long x1, int x2, double x3)
{
  check (x0 == -0x1.80025p+4F);
  check (x1 == -1368191711335779818);
  check (x2 == 1105507503);
  check (x3 == 0x1.697043817f028p+5);
}

void f247(float x0, long long x1, long long x2, int x3)
{
  check (x0 == -0x1.534f14p+2F);
  check (x1 == 7499008377808014233);
  check (x2 == 6457986169601137151);
  check (x3 == 506150669);
}

void f248(float x0, long long x1, long long x2, long long x3)
{
  check (x0 == 0x1.873522p+5F);
  check (x1 == -1588289399493144877);
  check (x2 == 1186097869956649880);
  check (x3 == -2553234038837715649);
}

void f249(float x0, long long x1, long long x2, float x3)
{
  check (x0 == -0x1.cb528p+1F);
  check (x1 == 5351606017970382108);
  check (x2 == -4617725222680010413);
  check (x3 == -0x1.74e6f6p+5F);
}

void f250(float x0, long long x1, long long x2, double x3)
{
  check (x0 == -0x1.78db08p+5F);
  check (x1 == 1983581095153981358);
  check (x2 == 2825007739463278211);
  check (x3 == 0x1.8708220a12b14p+5);
}

void f251(float x0, long long x1, float x2, int x3)
{
  check (x0 == 0x1.1c83ecp+3F);
  check (x1 == 4494448565390693015);
  check (x2 == -0x1.51f7b4p+4F);
  check (x3 == 1822416003);
}

void f252(float x0, long long x1, float x2, long long x3)
{
  check (x0 == 0x1.d4fdf4p+4F);
  check (x1 == -5045408152623293315);
  check (x2 == -0x1.ba9294p+2F);
  check (x3 == 7492969189661519081);
}

void f253(float x0, long long x1, float x2, float x3)
{
  check (x0 == 0x1.b0e74cp+3F);
  check (x1 == -40735531055273805);
  check (x2 == -0x1.5c02e6p+0F);
  check (x3 == -0x1.55dab2p+5F);
}

void f254(float x0, long long x1, float x2, double x3)
{
  check (x0 == 0x1.aef1c6p+4F);
  check (x1 == -3208325518965096226);
  check (x2 == -0x1.8ca602p+4F);
  check (x3 == -0x1.a05f6cdfea56p+0);
}

void f255(float x0, long long x1, double x2, int x3)
{
  check (x0 == 0x1.7c1fc6p+4F);
  check (x1 == 7774717424601704445);
  check (x2 == 0x1.4b033b4980b4cp+4);
  check (x3 == -1135386198);
}

void f256(float x0, long long x1, double x2, long long x3)
{
  check (x0 == 0x1.442a74p+5F);
  check (x1 == -8384716095038314712);
  check (x2 == -0x1.d6263e16e2p+1);
  check (x3 == 378231293743041269);
}

void f257(float x0, long long x1, double x2, float x3)
{
  check (x0 == 0x1.4bc44ap+5F);
  check (x1 == 7899436877524914986);
  check (x2 == -0x1.2b2ad1d957735p+4);
  check (x3 == 0x1.4c4172p+3F);
}

void f258(float x0, long long x1, double x2, double x3)
{
  check (x0 == -0x1.54ca48p+3F);
  check (x1 == -1195728655791694515);
  check (x2 == 0x1.c14e1699cc9cp+4);
  check (x3 == -0x1.f93c767a6718p-1);
}

void f259(float x0, float x1, int x2, int x3)
{
  check (x0 == 0x1.81aee2p+5F);
  check (x1 == -0x1.e38b7ap+2F);
  check (x2 == 1380027330);
  check (x3 == -1436663404);
}

void f260(float x0, float x1, int x2, long long x3)
{
  check (x0 == 0x1.4ebf72p+5F);
  check (x1 == -0x1.edfcbep+3F);
  check (x2 == 588627619);
  check (x3 == 8327655339970732696);
}

void f261(float x0, float x1, int x2, float x3)
{
  check (x0 == 0x1.6d018p+5F);
  check (x1 == 0x1.190304p+5F);
  check (x2 == 894530560);
  check (x3 == 0x1.f71434p+4F);
}

void f262(float x0, float x1, int x2, double x3)
{
  check (x0 == 0x1.2ea928p+4F);
  check (x1 == 0x1.29a304p+4F);
  check (x2 == -1913890902);
  check (x3 == -0x1.59d91c8231611p+5);
}

void f263(float x0, float x1, long long x2, int x3)
{
  check (x0 == -0x1.740936p+5F);
  check (x1 == 0x1.daa4e2p+2F);
  check (x2 == 7582431942063544436);
  check (x3 == 1254999553);
}

void f264(float x0, float x1, long long x2, long long x3)
{
  check (x0 == 0x1.fea59p+4F);
  check (x1 == 0x1.25fae8p-1F);
  check (x2 == 144557777347792410);
  check (x3 == 919076514725995571);
}

void f265(float x0, float x1, long long x2, float x3)
{
  check (x0 == -0x1.2feceep+5F);
  check (x1 == -0x1.4086a4p+2F);
  check (x2 == 7919911886643111983);
  check (x3 == 0x1.d2f372p+4F);
}

void f266(float x0, float x1, long long x2, double x3)
{
  check (x0 == -0x1.957c24p+4F);
  check (x1 == 0x1.8c9b98p+2F);
  check (x2 == 4517346182462412138);
  check (x3 == -0x1.119f4f10880ap+1);
}

void f267(float x0, float x1, float x2, int x3)
{
  check (x0 == 0x1.9681d6p-3F);
  check (x1 == 0x1.5a4f9ep+3F);
  check (x2 == 0x1.bd8022p+2F);
  check (x3 == 108878298);
}

void f268(float x0, float x1, float x2, long long x3)
{
  check (x0 == -0x1.e88aacp+4F);
  check (x1 == -0x1.5dd44cp+0F);
  check (x2 == 0x1.f6a854p+4F);
  check (x3 == 5028231680057739307);
}

void f269(float x0, float x1, float x2, float x3)
{
  check (x0 == 0x1.4bdee8p+0F);
  check (x1 == 0x1.38220ep-2F);
  check (x2 == 0x1.60d2e2p+4F);
  check (x3 == -0x1.cf4aeep+3F);
}

void f270(float x0, float x1, float x2, double x3)
{
  check (x0 == 0x1.0b903ep+3F);
  check (x1 == 0x1.3f8f92p+5F);
  check (x2 == 0x1.837df6p+5F);
  check (x3 == 0x1.979482a10868cp+3);
}

void f271(float x0, float x1, double x2, int x3)
{
  check (x0 == 0x1.5e1522p+1F);
  check (x1 == 0x1.a46886p+1F);
  check (x2 == -0x1.bd9c1620784e9p+4);
  check (x3 == -381630114);
}

void f272(float x0, float x1, double x2, long long x3)
{
  check (x0 == -0x1.cd8eb2p+3F);
  check (x1 == 0x1.8776bcp+4F);
  check (x2 == 0x1.d44591f376998p+4);
  check (x3 == 6439578625645459108);
}

void f273(float x0, float x1, double x2, float x3)
{
  check (x0 == -0x1.f82ed6p+2F);
  check (x1 == 0x1.724a3cp+2F);
  check (x2 == 0x1.4c1e2d2d8c338p+4);
  check (x3 == -0x1.7be7b2p+5F);
}

void f274(float x0, float x1, double x2, double x3)
{
  check (x0 == 0x1.aeb9a4p+4F);
  check (x1 == 0x1.0df17ep+5F);
  check (x2 == -0x1.2ba0dcc7e5a94p+3);
  check (x3 == 0x1.99df6df968fbcp+4);
}

void f275(float x0, double x1, int x2, int x3)
{
  check (x0 == -0x1.59bcccp+5F);
  check (x1 == 0x1.168b6a6d71296p+5);
  check (x2 == 729141640);
  check (x3 == 932788510);
}

void f276(float x0, double x1, int x2, long long x3)
{
  check (x0 == -0x1.93a8bep+4F);
  check (x1 == 0x1.518752a9d0c2p+0);
  check (x2 == 1010031513);
  check (x3 == -5730518312854327492);
}

void f277(float x0, double x1, int x2, float x3)
{
  check (x0 == -0x1.3529e4p+5F);
  check (x1 == -0x1.12d4bc17d7dcap+4);
  check (x2 == -1238173675);
  check (x3 == -0x1.98c918p+2F);
}

void f278(float x0, double x1, int x2, double x3)
{
  check (x0 == 0x1.fdcf56p+4F);
  check (x1 == -0x1.116ced306945p+4);
  check (x2 == -776544045);
  check (x3 == 0x1.3cd256c1737bcp+3);
}

void f279(float x0, double x1, long long x2, int x3)
{
  check (x0 == -0x1.7542ccp+4F);
  check (x1 == 0x1.70198fa77577ap+5);
  check (x2 == -4676640831765498941);
  check (x3 == -1899617899);
}

void f280(float x0, double x1, long long x2, long long x3)
{
  check (x0 == -0x1.2c0134p+3F);
  check (x1 == -0x1.9e4b1139cb459p+4);
  check (x2 == 1348595155264568119);
  check (x3 == 142617196952546487);
}

void f281(float x0, double x1, long long x2, float x3)
{
  check (x0 == 0x1.229c96p+5F);
  check (x1 == 0x1.1e0918811813cp+3);
  check (x2 == -1597955878845432235);
  check (x3 == -0x1.ffd7dcp+3F);
}

void f282(float x0, double x1, long long x2, double x3)
{
  check (x0 == -0x1.8733ecp+3F);
  check (x1 == 0x1.cc62aede088bcp+4);
  check (x2 == 4138865106599557496);
  check (x3 == -0x1.dddc7037b07dp+3);
}

void f283(float x0, double x1, float x2, int x3)
{
  check (x0 == 0x1.007866p+4F);
  check (x1 == -0x1.f8a8c66e95c55p+4);
  check (x2 == 0x1.7d2cfp+5F);
  check (x3 == -1179454657);
}

void f284(float x0, double x1, float x2, long long x3)
{
  check (x0 == 0x1.46f30ep+2F);
  check (x1 == 0x1.61dd91d436596p+5);
  check (x2 == -0x1.e4f48cp+4F);
  check (x3 == 5463312279528034827);
}

void f285(float x0, double x1, float x2, float x3)
{
  check (x0 == -0x1.14c846p+5F);
  check (x1 == 0x1.2fc51e9c760bp+4);
  check (x2 == 0x1.87cbcap+3F);
  check (x3 == -0x1.084e42p+5F);
}

void f286(float x0, double x1, float x2, double x3)
{
  check (x0 == -0x1.5ca678p+4F);
  check (x1 == -0x1.76d7e76bd017p+1);
  check (x2 == 0x1.258d6cp+3F);
  check (x3 == 0x1.0802d2dc281ep+5);
}

void f287(float x0, double x1, double x2, int x3)
{
  check (x0 == -0x1.ea0b76p+2F);
  check (x1 == -0x1.7a9800f4cc17fp+5);
  check (x2 == 0x1.a7b2ed4241d88p+4);
  check (x3 == 1224572420);
}

void f288(float x0, double x1, double x2, long long x3)
{
  check (x0 == 0x1.687cb4p+2F);
  check (x1 == 0x1.f014c6c8a3a9cp+4);
  check (x2 == 0x1.3c7232c8cdbfcp+5);
  check (x3 == -6356849868588853112);
}

void f289(float x0, double x1, double x2, float x3)
{
  check (x0 == -0x1.60669cp+4F);
  check (x1 == -0x1.7914de5671266p+5);
  check (x2 == -0x1.d40d0a4332b31p+4);
  check (x3 == 0x1.1ef418p+5F);
}

void f290(float x0, double x1, double x2, double x3)
{
  check (x0 == -0x1.0d696p+5F);
  check (x1 == -0x1.493b8d8c3a1cap+4);
  check (x2 == 0x1.48b5e812da23p+4);
  check (x3 == -0x1.1f563363ef164p+4);
}

void f291(double x0, int x1, int x2, int x3)
{
  check (x0 == -0x1.7f858f1d04a1ap+5);
  check (x1 == 1384116936);
  check (x2 == -1890988020);
  check (x3 == 762730598);
}

void f292(double x0, int x1, int x2, long long x3)
{
  check (x0 == -0x1.30dfc73258p-7);
  check (x1 == 556191707);
  check (x2 == 1778040802);
  check (x3 == -5312906134700150817);
}

void f293(double x0, int x1, int x2, float x3)
{
  check (x0 == -0x1.4d8561f18edc6p+5);
  check (x1 == -751614125);
  check (x2 == 1664566933);
  check (x3 == 0x1.7f90a4p+5F);
}

void f294(double x0, int x1, int x2, double x3)
{
  check (x0 == 0x1.239d4a3d3891cp+5);
  check (x1 == 45908317);
  check (x2 == -1134549720);
  check (x3 == 0x1.e9df584ddf398p+4);
}

void f295(double x0, int x1, long long x2, int x3)
{
  check (x0 == -0x1.1550b80e48d35p+5);
  check (x1 == -1379717951);
  check (x2 == -6165695899100406630);
  check (x3 == -1579355106);
}

void f296(double x0, int x1, long long x2, long long x3)
{
  check (x0 == -0x1.848a06b2abeep+1);
  check (x1 == 553414869);
  check (x2 == -7164013319183340508);
  check (x3 == -6274149290452297398);
}

void f297(double x0, int x1, long long x2, float x3)
{
  check (x0 == 0x1.d4a059ea4f89p+4);
  check (x1 == -281310785);
  check (x2 == -424610158424772107);
  check (x3 == 0x1.866228p+3F);
}

void f298(double x0, int x1, long long x2, double x3)
{
  check (x0 == -0x1.7bd181bd5bd87p+5);
  check (x1 == -990903690);
  check (x2 == 2870233668088923113);
  check (x3 == -0x1.678f6bb15f73bp+5);
}

void f299(double x0, int x1, float x2, int x3)
{
  check (x0 == 0x1.608bf197a3338p+4);
  check (x1 == -1471304705);
  check (x2 == -0x1.0d472ap+5F);
  check (x3 == 859776317);
}

void f300(double x0, int x1, float x2, long long x3)
{
  check (x0 == 0x1.7e702a5c3085ap+5);
  check (x1 == -620020397);
  check (x2 == 0x1.384ad8p+4F);
  check (x3 == -8609168085781150948);
}

void f301(double x0, int x1, float x2, float x3)
{
  check (x0 == -0x1.d1ad7a98e38bcp+4);
  check (x1 == -2050555014);
  check (x2 == -0x1.1722ccp+4F);
  check (x3 == 0x1.4c79cap+3F);
}

void f302(double x0, int x1, float x2, double x3)
{
  check (x0 == 0x1.158cb75ab5c7p+5);
  check (x1 == 2128424796);
  check (x2 == 0x1.a620bp+2F);
  check (x3 == 0x1.4f63f19cc8dp-1);
}

void f303(double x0, int x1, double x2, int x3)
{
  check (x0 == 0x1.8603de811393p+4);
  check (x1 == -582514423);
  check (x2 == 0x1.2b95fb65bdac4p+3);
  check (x3 == -1378623753);
}

void f304(double x0, int x1, double x2, long long x3)
{
  check (x0 == -0x1.64956ce26016cp+5);
  check (x1 == -1273546305);
  check (x2 == -0x1.e62c8c14332dp+2);
  check (x3 == 4075154345800202349);
}

void f305(double x0, int x1, double x2, float x3)
{
  check (x0 == 0x1.febcbe53e9e88p+2);
  check (x1 == 1520108479);
  check (x2 == 0x1.6784e119993dep+5);
  check (x3 == -0x1.cdc0e6p+4F);
}

void f306(double x0, int x1, double x2, double x3)
{
  check (x0 == 0x1.59225318a5d8cp+4);
  check (x1 == -2117044826);
  check (x2 == 0x1.8af7d37fabc4p+2);
  check (x3 == 0x1.4c5d62b5438a2p+5);
}

void f307(double x0, long long x1, int x2, int x3)
{
  check (x0 == 0x1.0c2c591da004p+0);
  check (x1 == 887319212162834346);
  check (x2 == 144330350);
  check (x3 == 324538738);
}

void f308(double x0, long long x1, int x2, long long x3)
{
  check (x0 == -0x1.23f92c9ab298p+5);
  check (x1 == 7788507057432146857);
  check (x2 == 393069153);
  check (x3 == -3652585478275577320);
}

void f309(double x0, long long x1, int x2, float x3)
{
  check (x0 == 0x1.226d83e562718p+2);
  check (x1 == 2968153173513475327);
  check (x2 == -1530659055);
  check (x3 == 0x1.88439ep+5F);
}

void f310(double x0, long long x1, int x2, double x3)
{
  check (x0 == -0x1.624515946c039p+5);
  check (x1 == -2572936754354885655);
  check (x2 == 1683227404);
  check (x3 == 0x1.15a5aefe042c6p+5);
}

void f311(double x0, long long x1, long long x2, int x3)
{
  check (x0 == 0x1.3ba9b7c2e7b5p+2);
  check (x1 == -8665367117668493558);
  check (x2 == -8666117773688002816);
  check (x3 == -1527421124);
}

void f312(double x0, long long x1, long long x2, long long x3)
{
  check (x0 == 0x1.309d2c94305c8p+2);
  check (x1 == 1524385651800878916);
  check (x2 == -7014871778848740946);
  check (x3 == -7972523454735797755);
}

void f313(double x0, long long x1, long long x2, float x3)
{
  check (x0 == -0x1.74c0d8fc008d8p+3);
  check (x1 == -1960143764068172015);
  check (x2 == 5220552901029029340);
  check (x3 == 0x1.4809d4p+3F);
}

void f314(double x0, long long x1, long long x2, double x3)
{
  check (x0 == 0x1.3390b74c30878p+4);
  check (x1 == 2421097890542942836);
  check (x2 == -4868572559017761325);
  check (x3 == -0x1.16728b2973ff4p+5);
}

void f315(double x0, long long x1, float x2, int x3)
{
  check (x0 == 0x1.5ec2dfc527fdp+2);
  check (x1 == 5148209924914594035);
  check (x2 == 0x1.7a2f5ep+5F);
  check (x3 == -1621772850);
}

void f316(double x0, long long x1, float x2, long long x3)
{
  check (x0 == 0x1.ed598d51a2a38p+2);
  check (x1 == 4594183260767331996);
  check (x2 == 0x1.02cebp+3F);
  check (x3 == 6931479337707060465);
}

void f317(double x0, long long x1, float x2, float x3)
{
  check (x0 == -0x1.4b514c968c44ap+5);
  check (x1 == 1628249656023893440);
  check (x2 == -0x1.b2b57cp+3F);
  check (x3 == -0x1.407eeep+5F);
}

void f318(double x0, long long x1, float x2, double x3)
{
  check (x0 == -0x1.455c3caa75cbp+2);
  check (x1 == 19243385444059710);
  check (x2 == -0x1.04b60cp+3F);
  check (x3 == -0x1.a7b99e9cb0cb5p+4);
}

void f319(double x0, long long x1, double x2, int x3)
{
  check (x0 == 0x1.d0a54047f8908p+4);
  check (x1 == -1602539825163174277);
  check (x2 == -0x1.06e1f6833e6dcp+4);
  check (x3 == 1907480980);
}

void f320(double x0, long long x1, double x2, long long x3)
{
  check (x0 == 0x1.5202de35e9f02p+5);
  check (x1 == 1733865892510381796);
  check (x2 == 0x1.70eef36c9b9fp+1);
  check (x3 == -8166280867900889923);
}

void f321(double x0, long long x1, double x2, float x3)
{
  check (x0 == -0x1.4ec5f40d8354p+5);
  check (x1 == 8655924560434077995);
  check (x2 == 0x1.731a8a203148p-1);
  check (x3 == 0x1.119acap+5F);
}

void f322(double x0, long long x1, double x2, double x3)
{
  check (x0 == -0x1.8008192b0e095p+5);
  check (x1 == -5220423756235120011);
  check (x2 == -0x1.efc60ce0e5e7cp+3);
  check (x3 == 0x1.5c1f84fbeeaep+4);
}

void f323(double x0, float x1, int x2, int x3)
{
  check (x0 == -0x1.bb19d7b368224p+3);
  check (x1 == 0x1.289e88p+4F);
  check (x2 == 1604089093);
  check (x3 == -996913219);
}

void f324(double x0, float x1, int x2, long long x3)
{
  check (x0 == -0x1.3c9f67347841cp+5);
  check (x1 == 0x1.838308p+5F);
  check (x2 == 209422202);
  check (x3 == 2286552696394610993);
}

void f325(double x0, float x1, int x2, float x3)
{
  check (x0 == 0x1.0f435bbbb32c4p+5);
  check (x1 == -0x1.550b58p+4F);
  check (x2 == -965500715);
  check (x3 == 0x1.6468bap+2F);
}

void f326(double x0, float x1, int x2, double x3)
{
  check (x0 == 0x1.c9fee15d8953p+1);
  check (x1 == -0x1.73dd4ap+4F);
  check (x2 == -835944656);
  check (x3 == -0x1.b8aff2a06f5fap+4);
}

void f327(double x0, float x1, long long x2, int x3)
{
  check (x0 == 0x1.4122b231829cap+5);
  check (x1 == 0x1.aeff1p+2F);
  check (x2 == 176495729844223595);
  check (x3 == -1110233509);
}

void f328(double x0, float x1, long long x2, long long x3)
{
  check (x0 == 0x1.378b91c93b45p+3);
  check (x1 == -0x1.58a57ep+5F);
  check (x2 == 2559663458968797884);
  check (x3 == 8136112140863111610);
}

void f329(double x0, float x1, long long x2, float x3)
{
  check (x0 == -0x1.c309cbc51297ep+4);
  check (x1 == -0x1.27d42ap+3F);
  check (x2 == 1392468792669355675);
  check (x3 == 0x1.6541d6p+4F);
}

void f330(double x0, float x1, long long x2, double x3)
{
  check (x0 == 0x1.7b51f1961e6d4p+5);
  check (x1 == -0x1.37f086p+4F);
  check (x2 == -6238776459103324790);
  check (x3 == -0x1.7f215900e5ddp+3);
}

void f331(double x0, float x1, float x2, int x3)
{
  check (x0 == 0x1.f392aefdc2be4p+4);
  check (x1 == 0x1.22f7acp+5F);
  check (x2 == -0x1.93e22p+4F);
  check (x3 == 85565784);
}

void f332(double x0, float x1, float x2, long long x3)
{
  check (x0 == -0x1.2d538bcd3db1ep+4);
  check (x1 == 0x1.28bf1cp+3F);
  check (x2 == -0x1.5c41ap+5F);
  check (x3 == -4624081255055915723);
}

void f333(double x0, float x1, float x2, float x3)
{
  check (x0 == -0x1.2482d5674f924p+3);
  check (x1 == 0x1.7bfc3ap+2F);
  check (x2 == 0x1.2d355ep+5F);
  check (x3 == 0x1.56a402p+4F);
}

void f334(double x0, float x1, float x2, double x3)
{
  check (x0 == 0x1.a1a593ef6a5ap+1);
  check (x1 == -0x1.884d7ap+4F);
  check (x2 == -0x1.436e9cp+2F);
  check (x3 == -0x1.761716aee234cp+5);
}

void f335(double x0, float x1, double x2, int x3)
{
  check (x0 == -0x1.042a82f4c6703p+5);
  check (x1 == 0x1.b4ab14p+3F);
  check (x2 == -0x1.43890acf0acf9p+4);
  check (x3 == -1375222193);
}

void f336(double x0, float x1, double x2, long long x3)
{
  check (x0 == 0x1.e0cfd8c9330f8p+4);
  check (x1 == -0x1.8039bep+5F);
  check (x2 == -0x1.50fe8b44dd9b2p+5);
  check (x3 == -6317117901620112104);
}

void f337(double x0, float x1, double x2, float x3)
{
  check (x0 == -0x1.1985cc3c6497ap+5);
  check (x1 == 0x1.1ed79p+5F);
  check (x2 == -0x1.b8ac6bd54ff3bp+4);
  check (x3 == -0x1.744ad6p+5F);
}

void f338(double x0, float x1, double x2, double x3)
{
  check (x0 == -0x1.1824d06b89655p+5);
  check (x1 == 0x1.788b38p+5F);
  check (x2 == -0x1.3b9aa8dac6668p+4);
  check (x3 == -0x1.aa4ecbf3c22eap+4);
}

void f339(double x0, double x1, int x2, int x3)
{
  check (x0 == -0x1.3e6f6a66c3e74p+3);
  check (x1 == 0x1.8867900f93238p+4);
  check (x2 == 1105283979);
  check (x3 == -1922966666);
}

void f340(double x0, double x1, int x2, long long x3)
{
  check (x0 == 0x1.fa2e547aa6b6p+2);
  check (x1 == 0x1.6c36d4674468p+5);
  check (x2 == 1325989589);
  check (x3 == -5694056187168055922);
}

void f341(double x0, double x1, int x2, float x3)
{
  check (x0 == 0x1.e21cc1ca12838p+4);
  check (x1 == 0x1.5639335dec9dcp+4);
  check (x2 == 1387942995);
  check (x3 == -0x1.3e9308p+5F);
}

void f342(double x0, double x1, int x2, double x3)
{
  check (x0 == -0x1.519d764d547bep+4);
  check (x1 == -0x1.fd2679a8a9154p+3);
  check (x2 == 1504887698);
  check (x3 == -0x1.b7eb5cb45eb43p+4);
}

void f343(double x0, double x1, long long x2, int x3)
{
  check (x0 == 0x1.4cccff2c08aacp+5);
  check (x1 == -0x1.2a1dbccf58a56p+4);
  check (x2 == 2216751923110492342);
  check (x3 == 1513395011);
}

void f344(double x0, double x1, long long x2, long long x3)
{
  check (x0 == 0x1.4f3c6001ac398p+5);
  check (x1 == -0x1.bff33121065c8p+3);
  check (x2 == -3183775473145292428);
  check (x3 == -8153863183067849463);
}

void f345(double x0, double x1, long long x2, float x3)
{
  check (x0 == 0x1.21d34bcdce396p+5);
  check (x1 == 0x1.d4ba10a4454cp+3);
  check (x2 == 8845191802650343226);
  check (x3 == -0x1.22c8e8p+4F);
}

void f346(double x0, double x1, long long x2, double x3)
{
  check (x0 == 0x1.5b8580b6546b8p+2);
  check (x1 == 0x1.81707b2d25p+5);
  check (x2 == -1082112759578367330);
  check (x3 == 0x1.55f58ec5bef6p+2);
}

void f347(double x0, double x1, float x2, int x3)
{
  check (x0 == -0x1.22d9f6797de6p+0);
  check (x1 == 0x1.707315e29e1ap+3);
  check (x2 == -0x1.05492cp+5F);
  check (x3 == 1490837671);
}

void f348(double x0, double x1, float x2, long long x3)
{
  check (x0 == -0x1.233b5672f67f8p+2);
  check (x1 == -0x1.c55f976989dafp+4);
  check (x2 == -0x1.2eed24p+3F);
  check (x3 == -1975012453410951728);
}

void f349(double x0, double x1, float x2, float x3)
{
  check (x0 == -0x1.543f9e32d8841p+5);
  check (x1 == -0x1.47467d8e6424p+1);
  check (x2 == 0x1.54aa9ap+5F);
  check (x3 == -0x1.156076p+4F);
}

void f350(double x0, double x1, float x2, double x3)
{
  check (x0 == 0x1.caf06896b983cp+4);
  check (x1 == 0x1.cda1569bc3088p+3);
  check (x2 == 0x1.4ac1e6p+5F);
  check (x3 == 0x1.6b721bd4cd6e8p+4);
}

void f351(double x0, double x1, double x2, int x3)
{
  check (x0 == 0x1.55c3929240d3cp+3);
  check (x1 == -0x1.17cb0d77a21fp+2);
  check (x2 == -0x1.8ed3f76358967p+4);
  check (x3 == 108418013);
}

void f352(double x0, double x1, double x2, long long x3)
{
  check (x0 == 0x1.36e5e5b912652p+5);
  check (x1 == 0x1.b5c9f39e0b074p+4);
  check (x2 == -0x1.ef9aa7ac43ae6p+4);
  check (x3 == -1771001256599518628);
}

void f353(double x0, double x1, double x2, float x3)
{
  check (x0 == 0x1.cadc11b5159cp+1);
  check (x1 == -0x1.fabb6a1b123bp+4);
  check (x2 == 0x1.44a7f21bc2edp+4);
  check (x3 == -0x1.4298b2p+3F);
}

void f354(double x0, double x1, double x2, double x3)
{
  check (x0 == 0x1.0386c30a1355p+1);
  check (x1 == -0x1.73df3c72deddp+5);
  check (x2 == 0x1.78144f2107088p+3);
  check (x3 == -0x1.de53cf820b458p+2);
}

void f355(int x0, int x1, int x2, int x3, int x4, int x5)
{
  check (x0 == -423094771);
  check (x1 == 1505276306);
  check (x2 == 1173225900);
  check (x3 == -39393538);
  check (x4 == 1340083113);
  check (x5 == 124640452);
}

void f356(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7)
{
  check (x0 == 1922578507);
  check (x1 == -1404176156);
  check (x2 == -2145968655);
  check (x3 == 2087250985);
  check (x4 == 992973758);
  check (x5 == 1178086693);
  check (x6 == -701542642);
  check (x7 == -954253759);
}

void f357(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7, int x8, int x9)
{
  check (x0 == -514825008);
  check (x1 == 975957544);
  check (x2 == 1465777616);
  check (x3 == 1345379491);
  check (x4 == -40814461);
  check (x5 == -864158835);
  check (x6 == -1655158826);
  check (x7 == 1131147407);
  check (x8 == 1034121376);
  check (x9 == 967938458);
}

void f358(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7, int x8, int x9, int x10, int x11)
{
  check (x0 == -1298572493);
  check (x1 == -2109303418);
  check (x2 == -1305870880);
  check (x3 == 1443378966);
  check (x4 == 872750106);
  check (x5 == -584067502);
  check (x6 == -1106923504);
  check (x7 == 705934465);
  check (x8 == -1103071796);
  check (x9 == -1437055712);
  check (x10 == 1916925301);
  check (x11 == -864379867);
}

void f359(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7, int x8, int x9, int x10, int x11, int x12, int x13, int x14, int x15)
{
  check (x0 == -859393046);
  check (x1 == -1429730775);
  check (x2 == -584436702);
  check (x3 == 907987319);
  check (x4 == 215158658);
  check (x5 == 1004607381);
  check (x6 == 1066708728);
  check (x7 == -729838178);
  check (x8 == 1486598137);
  check (x9 == 1344126429);
  check (x10 == 2031566435);
  check (x11 == 426339393);
  check (x12 == 717727326);
  check (x13 == -1883364492);
  check (x14 == -22660167);
  check (x15 == -19745483);
}

void f360(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7, int x8, int x9, int x10, int x11, int x12, int x13, int x14, int x15, int x16, int x17, int x18, int x19, int x20, int x21, int x22, int x23, int x24, int x25, int x26, int x27, int x28, int x29, int x30, int x31)
{
  check (x0 == 1048434839);
  check (x1 == 461905554);
  check (x2 == -514234587);
  check (x3 == 96472938);
  check (x4 == -1438792809);
  check (x5 == 2058930445);
  check (x6 == -939066786);
  check (x7 == -1298062494);
  check (x8 == 83848286);
  check (x9 == -1413457542);
  check (x10 == -279075729);
  check (x11 == 956834669);
  check (x12 == -1382477177);
  check (x13 == 683174546);
  check (x14 == 1175841930);
  check (x15 == 1210628432);
  check (x16 == -160140420);
  check (x17 == -1563519804);
  check (x18 == 475735511);
  check (x19 == -1942272654);
  check (x20 == 108110044);
  check (x21 == -1187952713);
  check (x22 == 1965355593);
  check (x23 == -227220619);
  check (x24 == 1748646090);
  check (x25 == 1530829299);
  check (x26 == 1813001740);
  check (x27 == -152147627);
  check (x28 == -409678506);
  check (x29 == 1797562881);
  check (x30 == -1055359181);
  check (x31 == 204018589);
}

void f361(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5)
{
  check (x0 == -1432556973172761132);
  check (x1 == 6420030855427841835);
  check (x2 == -2995625662755041992);
  check (x3 == 1818443015186246839);
  check (x4 == 2052416614585665254);
  check (x5 == -6524358139460670822);
}

void f362(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7)
{
  check (x0 == -7893380784044236139);
  check (x1 == 3442378124667900717);
  check (x2 == -2960430863517272362);
  check (x3 == -5234052192265542229);
  check (x4 == 1793253587295126774);
  check (x5 == -5337206238629308146);
  check (x6 == -2109445881971704641);
  check (x7 == 7737659921410301462);
}

void f363(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7, long long x8, long long x9)
{
  check (x0 == 6098328753400630847);
  check (x1 == 2851048571571680884);
  check (x2 == -1004897092244016623);
  check (x3 == 1979672478103890791);
  check (x4 == -8093287479821212847);
  check (x5 == 700722888949744943);
  check (x6 == 2724731105122010090);
  check (x7 == 4281405557676137988);
  check (x8 == -243587917047033645);
  check (x9 == 2928293273872764448);
}

void f364(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7, long long x8, long long x9, long long x10, long long x11)
{
  check (x0 == 8280785781046036156);
  check (x1 == -5473828832771639042);
  check (x2 == -5843229045195453189);
  check (x3 == 1764487498711989127);
  check (x4 == 7421175693490725445);
  check (x5 == -1948336425508299808);
  check (x6 == -5495300211722437994);
  check (x7 == 4568123950159180167);
  check (x8 == -6454939088536412389);
  check (x9 == 5098031644914311974);
  check (x10 == 5549437607527880917);
  check (x11 == 8822157796788735305);
}

void f365(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7, long long x8, long long x9, long long x10, long long x11, long long x12, long long x13, long long x14, long long x15)
{
  check (x0 == -56088162696548283);
  check (x1 == 3141735048510226230);
  check (x2 == 7892810677154611693);
  check (x3 == -7972745059940243433);
  check (x4 == -5885227262144577902);
  check (x5 == 3478134692310580972);
  check (x6 == -8294485743144085619);
  check (x7 == -2684616029369034285);
  check (x8 == 8044998567589378292);
  check (x9 == -788138276494162104);
  check (x10 == -5196928128377147301);
  check (x11 == -7150249304022632740);
  check (x12 == 6710671048277666885);
  check (x13 == 5349442618315074672);
  check (x14 == 1592477114504556635);
  check (x15 == -4723032894781347996);
}

void f366(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7, long long x8, long long x9, long long x10, long long x11, long long x12, long long x13, long long x14, long long x15, long long x16, long long x17, long long x18, long long x19, long long x20, long long x21, long long x22, long long x23, long long x24, long long x25, long long x26, long long x27, long long x28, long long x29, long long x30, long long x31)
{
  check (x0 == 2950949638210749720);
  check (x1 == -7157390070168439085);
  check (x2 == -7916817867445027145);
  check (x3 == -3894833564467421384);
  check (x4 == -6511094147122279554);
  check (x5 == -68840199802498301);
  check (x6 == 3508538611409765116);
  check (x7 == 9013604975829805868);
  check (x8 == -3544378733840909635);
  check (x9 == -6200752028167505346);
  check (x10 == -5780353032551804269);
  check (x11 == -4881526498773745591);
  check (x12 == 910725473368700404);
  check (x13 == -2185056190031991151);
  check (x14 == 6268896796132780175);
  check (x15 == 6366677771156053955);
  check (x16 == 5196465850108463886);
  check (x17 == -2072603470473678256);
  check (x18 == 6991261571398688119);
  check (x19 == -8330113277657259507);
  check (x20 == 8942101680030711439);
  check (x21 == -3434089458137273305);
  check (x22 == 3258848165895207272);
  check (x23 == -8640181905047538508);
  check (x24 == 155934121472931533);
  check (x25 == -7471356718194690361);
  check (x26 == -4059525863128591881);
  check (x27 == 7946916884173851674);
  check (x28 == -4371846318264939614);
  check (x29 == -7874210323407090044);
  check (x30 == 8536550905392207944);
  check (x31 == -248788625111440588);
}

void f367(float x0, float x1, float x2, float x3, float x4, float x5)
{
  check (x0 == -0x1.b5eb44p+4F);
  check (x1 == -0x1.271abp+4F);
  check (x2 == -0x1.798f76p+5F);
  check (x3 == -0x1.abbbe4p+4F);
  check (x4 == 0x1.43ffd6p+5F);
  check (x5 == 0x1.631834p+4F);
}

void f368(float x0, float x1, float x2, float x3, float x4, float x5, float x6, float x7)
{
  check (x0 == -0x1.0c6bdcp+4F);
  check (x1 == 0x1.4e977p+5F);
  check (x2 == 0x1.0c354cp+4F);
  check (x3 == -0x1.e870dep+4F);
  check (x4 == -0x1.0815cp+5F);
  check (x5 == -0x1.ed6b22p+4F);
  check (x6 == 0x1.12daaep+4F);
  check (x7 == 0x1.2d78bap+4F);
}

void f369(float x0, float x1, float x2, float x3, float x4, float x5, float x6, float x7, float x8, float x9)
{
  check (x0 == -0x1.4fecbap+4F);
  check (x1 == -0x1.37a3dcp+5F);
  check (x2 == 0x1.8751d6p+4F);
  check (x3 == 0x1.411c7ap+5F);
  check (x4 == 0x1.21b72ap+5F);
  check (x5 == -0x1.53a924p+5F);
  check (x6 == 0x1.d72d48p+4F);
  check (x7 == -0x1.c6094cp+3F);
  check (x8 == 0x1.2a25c8p+3F);
  check (x9 == 0x1.182da6p+3F);
}

void f370(float x0, float x1, float x2, float x3, float x4, float x5, float x6, float x7, float x8, float x9, float x10, float x11)
{
  check (x0 == 0x1.9f7c1ap+4F);
  check (x1 == 0x1.00c42cp+0F);
  check (x2 == -0x1.6a159ap+4F);
  check (x3 == 0x1.79be1ap+4F);
  check (x4 == -0x1.062e78p-1F);
  check (x5 == -0x1.473fd2p+5F);
  check (x6 == 0x1.da5b98p+4F);
  check (x7 == -0x1.8cc8fp+5F);
  check (x8 == -0x1.3afe78p+5F);
  check (x9 == -0x1.bf953ap+2F);
  check (x10 == -0x1.88db72p+4F);
  check (x11 == 0x1.5af686p+5F);
}

void f371(float x0, float x1, float x2, float x3, float x4, float x5, float x6, float x7, float x8, float x9, float x10, float x11, float x12, float x13, float x14, float x15)
{
  check (x0 == 0x1.c5c622p+4F);
  check (x1 == 0x1.bb4bdap-2F);
  check (x2 == -0x1.bcf84ap+2F);
  check (x3 == -0x1.228d66p+5F);
  check (x4 == 0x1.07e768p+5F);
  check (x5 == 0x1.8dcb46p+3F);
  check (x6 == -0x1.1971cp+0F);
  check (x7 == -0x1.8094ecp+4F);
  check (x8 == -0x1.d23c28p+4F);
  check (x9 == 0x1.2a438cp+4F);
  check (x10 == -0x1.643c68p+5F);
  check (x11 == -0x1.0b40dep+5F);
  check (x12 == -0x1.08967cp+5F);
  check (x13 == 0x1.776ecap+4F);
  check (x14 == 0x1.5bb856p+5F);
  check (x15 == 0x1.10c28ep+4F);
}

void f372(float x0, float x1, float x2, float x3, float x4, float x5, float x6, float x7, float x8, float x9, float x10, float x11, float x12, float x13, float x14, float x15, float x16, float x17, float x18, float x19, float x20, float x21, float x22, float x23, float x24, float x25, float x26, float x27, float x28, float x29, float x30, float x31)
{
  check (x0 == -0x1.168722p+5F);
  check (x1 == 0x1.1d1cc2p+4F);
  check (x2 == -0x1.42708p+5F);
  check (x3 == -0x1.10b9dp+4F);
  check (x4 == -0x1.dc1cf8p+4F);
  check (x5 == 0x1.317904p+5F);
  check (x6 == -0x1.f08d3ap+4F);
  check (x7 == 0x1.3738f2p+5F);
  check (x8 == 0x1.7214e8p+3F);
  check (x9 == 0x1.1a6632p+5F);
  check (x10 == -0x1.5583c6p+5F);
  check (x11 == -0x1.b6da22p+3F);
  check (x12 == -0x1.fcbeeep+3F);
  check (x13 == 0x1.623dacp+3F);
  check (x14 == -0x1.3f5074p+4F);
  check (x15 == 0x1.7bcc82p+5F);
  check (x16 == -0x1.cb8194p+4F);
  check (x17 == -0x1.7355fep+4F);
  check (x18 == 0x1.5f19b4p+4F);
  check (x19 == 0x1.9af7p+2F);
  check (x20 == 0x1.4c1f4cp+4F);
  check (x21 == 0x1.634732p+5F);
  check (x22 == -0x1.f615ecp+3F);
  check (x23 == -0x1.c708bcp+4F);
  check (x24 == 0x1.43ba24p+5F);
  check (x25 == -0x1.128e68p+5F);
  check (x26 == 0x1.82de56p+3F);
  check (x27 == -0x1.8925b4p-2F);
  check (x28 == -0x1.8aaa94p+4F);
  check (x29 == -0x1.58908ap+5F);
  check (x30 == 0x1.204b12p+4F);
  check (x31 == -0x1.35a216p+4F);
}

void f373(double x0, double x1, double x2, double x3, double x4, double x5)
{
  check (x0 == -0x1.81cbd035cf3d2p+5);
  check (x1 == 0x1.29262d7c5f382p+5);
  check (x2 == 0x1.1a453ae5dd19p+5);
  check (x3 == 0x1.696dc86f54be8p+4);
  check (x4 == 0x1.2793d0c614a7p+4);
  check (x5 == 0x1.5696d5b3b5ac8p+2);
}

void f374(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7)
{
  check (x0 == -0x1.145244b54c25p+5);
  check (x1 == 0x1.7c76a52e7628cp+4);
  check (x2 == 0x1.054b94401229ap+5);
  check (x3 == -0x1.96c88b519fefcp+3);
  check (x4 == 0x1.107e9fe8043d6p+5);
  check (x5 == -0x1.45699871d172p+1);
  check (x6 == 0x1.247bfdff4e9ecp+3);
  check (x7 == 0x1.82ab358db711ep+5);
}

void f375(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9)
{
  check (x0 == 0x1.3ac83bfbfec98p+5);
  check (x1 == 0x1.05042a8ae2374p+5);
  check (x2 == 0x1.5cd19a1b221e8p+4);
  check (x3 == -0x1.153cc7b2ce4a8p+5);
  check (x4 == 0x1.a3f9a65cbfc4p-1);
  check (x5 == -0x1.397c62bebb35ep+5);
  check (x6 == -0x1.70d4138887bfp+3);
  check (x7 == -0x1.e6a5898cf7718p+2);
  check (x8 == 0x1.65bf5d2ac655p+3);
  check (x9 == 0x1.7da71191d9484p+4);
}

void f376(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11)
{
  check (x0 == -0x1.62e12e928026ep+5);
  check (x1 == -0x1.2212be55f2156p+4);
  check (x2 == 0x1.b853a0af05214p+4);
  check (x3 == 0x1.311aa6a043616p+5);
  check (x4 == -0x1.4db0d7fc5668p+0);
  check (x5 == -0x1.320ebb06a174fp+4);
  check (x6 == -0x1.19b4b30657946p+4);
  check (x7 == -0x1.69274adb1913cp+5);
  check (x8 == 0x1.686b16e2232b8p+3);
  check (x9 == 0x1.66d9fcb759618p+3);
  check (x10 == 0x1.fef40e891edp+0);
  check (x11 == 0x1.0c0e755b92fbcp+5);
}

void f377(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11, double x12, double x13, double x14, double x15)
{
  check (x0 == -0x1.1ba879cdba5cp+1);
  check (x1 == 0x1.3ae959c6ebc94p+4);
  check (x2 == 0x1.47c67d7e4f73cp+4);
  check (x3 == 0x1.2701b2c54f9e8p+2);
  check (x4 == 0x1.bf0392e631ee8p+4);
  check (x5 == 0x1.50568bdec6876p+5);
  check (x6 == 0x1.e598bf056f208p+3);
  check (x7 == -0x1.08d1f8f64f098p+4);
  check (x8 == 0x1.107d84561fda4p+4);
  check (x9 == 0x1.61cd359fc6ef6p+5);
  check (x10 == -0x1.449a51464a74p-1);
  check (x11 == 0x1.89b6c3f1f5714p+5);
  check (x12 == -0x1.0895e71a21a4p+3);
  check (x13 == -0x1.8ae867ac63c6p+2);
  check (x14 == -0x1.5018078d5a622p+5);
  check (x15 == -0x1.4de64caba8fp+4);
}

void f378(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11, double x12, double x13, double x14, double x15, double x16, double x17, double x18, double x19, double x20, double x21, double x22, double x23, double x24, double x25, double x26, double x27, double x28, double x29, double x30, double x31)
{
  check (x0 == -0x1.a1930016a4ddbp+4);
  check (x1 == 0x1.7a92a143b1ad4p+5);
  check (x2 == 0x1.8b554c2d00344p+5);
  check (x3 == -0x1.84ddff9150292p+4);
  check (x4 == -0x1.128cc7a62baefp+5);
  check (x5 == -0x1.1001fa968b0dp+3);
  check (x6 == -0x1.804c3dfe9ba15p+4);
  check (x7 == 0x1.58b7ecd326fbcp+3);
  check (x8 == -0x1.08ae11517699ep+5);
  check (x9 == -0x1.033447a47c4cp-1);
  check (x10 == -0x1.8de4be25546b2p+5);
  check (x11 == -0x1.d2075ee851d64p+4);
  check (x12 == 0x1.0a5afa98b08p+5);
  check (x13 == 0x1.0d57bafec17ap+3);
  check (x14 == 0x1.cabddc439e59cp+4);
  check (x15 == -0x1.fcbbcacf10977p+4);
  check (x16 == -0x1.23e5b7658a3dbp+4);
  check (x17 == -0x1.1900e751d45b4p+5);
  check (x18 == -0x1.23e650c8ed121p+5);
  check (x19 == -0x1.6f0776f9b5ffp+1);
  check (x20 == 0x1.321612c7ad8fcp+4);
  check (x21 == 0x1.ec82c4e6ee65cp+4);
  check (x22 == 0x1.fcc0ab86b1dep+1);
  check (x23 == -0x1.5f8171c500dap+4);
  check (x24 == 0x1.219609c952c74p+3);
  check (x25 == -0x1.1bb3529555a77p+5);
  check (x26 == -0x1.3d631e1ddfcc4p+3);
  check (x27 == -0x1.c3ddb8adfeda8p+2);
  check (x28 == -0x1.177d114699ba2p+5);
  check (x29 == -0x1.784f721110bb9p+4);
  check (x30 == -0x1.783025597a5e4p+4);
  check (x31 == -0x1.5866e6b706673p+4);
}

void f379(int x0, long long x1, int x2, long long x3, int x4, long long x5)
{
  check (x0 == -2015654770);
  check (x1 == 716653978532097895);
  check (x2 == -988862123);
  check (x3 == -2466728654179640739);
  check (x4 == 823660008);
  check (x5 == -5272217850553273719);
}

void f380(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7)
{
  check (x0 == 1528406927);
  check (x1 == -3770579074154420253);
  check (x2 == 362336643);
  check (x3 == 1257099725035211705);
  check (x4 == -1703435973);
  check (x5 == 1614099172513992492);
  check (x6 == -750013163);
  check (x7 == -4702775168291073133);
}

void f381(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7, int x8, long long x9)
{
  check (x0 == -1595325650);
  check (x1 == 1602981869158816429);
  check (x2 == 1327133866);
  check (x3 == 3026298066479890812);
  check (x4 == -95542402);
  check (x5 == -5512131811937022583);
  check (x6 == 1039822329);
  check (x7 == 6975678907018234127);
  check (x8 == -1531371345);
  check (x9 == -3402970413890770432);
}

void f382(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7, int x8, long long x9, int x10, long long x11)
{
  check (x0 == 896708658);
  check (x1 == 4236448195687343578);
  check (x2 == 983017510);
  check (x3 == -9101165479232786281);
  check (x4 == -79909837);
  check (x5 == -8483183148190961614);
  check (x6 == -1796866116);
  check (x7 == 675335784646766848);
  check (x8 == 1659592218);
  check (x9 == 5767308369281755955);
  check (x10 == -1885408982);
  check (x11 == 1035655038079628638);
}

void f383(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7, int x8, long long x9, int x10, long long x11, int x12, long long x13, int x14, long long x15)
{
  check (x0 == -1590025862);
  check (x1 == 7842076538450601827);
  check (x2 == -34183735);
  check (x3 == 6550337071398316611);
  check (x4 == -172267386);
  check (x5 == 8673804281254757629);
  check (x6 == -1091097255);
  check (x7 == 1813422903077560904);
  check (x8 == 334742130);
  check (x9 == -4100251046507000904);
  check (x10 == -36175878);
  check (x11 == -9151416467906400044);
  check (x12 == 1995943021);
  check (x13 == 4173621555652906187);
  check (x14 == 1353292457);
  check (x15 == -6375672691363589202);
}

void f384(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7, int x8, long long x9, int x10, long long x11, int x12, long long x13, int x14, long long x15, int x16, long long x17, int x18, long long x19, int x20, long long x21, int x22, long long x23, int x24, long long x25, int x26, long long x27, int x28, long long x29, int x30, long long x31)
{
  check (x0 == 1283153529);
  check (x1 == 6925298346680196411);
  check (x2 == -891385059);
  check (x3 == 3379461259116639559);
  check (x4 == -1209196995);
  check (x5 == -1820234708450516249);
  check (x6 == 649603801);
  check (x7 == 527513708541539381);
  check (x8 == 1265028160);
  check (x9 == -4315037738782710494);
  check (x10 == -118581955);
  check (x11 == 4376291797803467454);
  check (x12 == -71772421);
  check (x13 == 6842489707283958516);
  check (x14 == -22927078);
  check (x15 == -7122009935182834671);
  check (x16 == 62665218);
  check (x17 == -7191874957624977033);
  check (x18 == -1503757222);
  check (x19 == -6801786523296253809);
  check (x20 == 1423833574);
  check (x21 == 2486651285551772626);
  check (x22 == 1873512994);
  check (x23 == -6124239478838528499);
  check (x24 == 1039076295);
  check (x25 == -8006903791084562979);
  check (x26 == 766797925);
  check (x27 == 2437208692896991684);
  check (x28 == 369994110);
  check (x29 == 2290879009162642306);
  check (x30 == -1815112293);
  check (x31 == 3963838333005623802);
}

void f385(int x0, float x1, int x2, float x3, int x4, float x5)
{
  check (x0 == 1206269430);
  check (x1 == -0x1.95a208p+4F);
  check (x2 == -828017528);
  check (x3 == 0x1.26ff8p+5F);
  check (x4 == 1777769851);
  check (x5 == -0x1.6c6cdcp+5F);
}

void f386(int x0, float x1, int x2, float x3, int x4, float x5, int x6, float x7)
{
  check (x0 == -2002700535);
  check (x1 == -0x1.12bf8p+4F);
  check (x2 == -812165634);
  check (x3 == -0x1.764cccp+4F);
  check (x4 == -2073747379);
  check (x5 == 0x1.bd2146p+3F);
  check (x6 == -880712620);
  check (x7 == 0x1.a0506ap+4F);
}

void f387(int x0, float x1, int x2, float x3, int x4, float x5, int x6, float x7, int x8, float x9)
{
  check (x0 == -140608584);
  check (x1 == -0x1.a96adap+2F);
  check (x2 == 746731091);
  check (x3 == 0x1.85091ap+3F);
  check (x4 == 1877554659);
  check (x5 == 0x1.b84bd6p+4F);
  check (x6 == 602122405);
  check (x7 == 0x1.b70a5ap+4F);
  check (x8 == 271418819);
  check (x9 == 0x1.f58d7cp+3F);
}

void f388(int x0, float x1, int x2, float x3, int x4, float x5, int x6, float x7, int x8, float x9, int x10, float x11)
{
  check (x0 == 1488453224);
  check (x1 == -0x1.f80348p+4F);
  check (x2 == -39249660);
  check (x3 == 0x1.f7510ap+4F);
  check (x4 == 1665635958);
  check (x5 == 0x1.8f262ep+5F);
  check (x6 == -435951979);
  check (x7 == 0x1.89a004p+2F);
  check (x8 == -2040690735);
  check (x9 == 0x1.1d9e36p+5F);
  check (x10 == 759660220);
  check (x11 == 0x1.0ab058p+5F);
}

void f389(int x0, float x1, int x2, float x3, int x4, float x5, int x6, float x7, int x8, float x9, int x10, float x11, int x12, float x13, int x14, float x15)
{
  check (x0 == -1972389722);
  check (x1 == 0x1.96f0f2p+4F);
  check (x2 == -1934635214);
  check (x3 == -0x1.cb2146p+3F);
  check (x4 == 1103533688);
  check (x5 == 0x1.dd245cp+4F);
  check (x6 == -589479035);
  check (x7 == 0x1.1d215cp+4F);
  check (x8 == -795105357);
  check (x9 == -0x1.48dcfep+4F);
  check (x10 == 1316559599);
  check (x11 == -0x1.5ad45cp+5F);
  check (x12 == 1491201256);
  check (x13 == 0x1.a3be76p+4F);
  check (x14 == -240159590);
  check (x15 == -0x1.73fd02p+5F);
}

void f390(int x0, float x1, int x2, float x3, int x4, float x5, int x6, float x7, int x8, float x9, int x10, float x11, int x12, float x13, int x14, float x15, int x16, float x17, int x18, float x19, int x20, float x21, int x22, float x23, int x24, float x25, int x26, float x27, int x28, float x29, int x30, float x31)
{
  check (x0 == -1584474906);
  check (x1 == 0x1.1a5e7ap+4F);
  check (x2 == 632719022);
  check (x3 == 0x1.275c5ap+5F);
  check (x4 == -51685590);
  check (x5 == 0x1.584ffep+5F);
  check (x6 == -482778491);
  check (x7 == 0x1.39035ap+3F);
  check (x8 == 1381424819);
  check (x9 == -0x1.b65394p+4F);
  check (x10 == 1546356477);
  check (x11 == -0x1.c4fb3ep+1F);
  check (x12 == -352310184);
  check (x13 == -0x1.5d4056p+4F);
  check (x14 == -1303592753);
  check (x15 == -0x1.33c23ep+5F);
  check (x16 == -1197739108);
  check (x17 == 0x1.8b561ap+5F);
  check (x18 == 1523850238);
  check (x19 == 0x1.048bbp+5F);
  check (x20 == 1522201090);
  check (x21 == -0x1.67b638p+3F);
  check (x22 == 1692645976);
  check (x23 == -0x1.80a64ep+5F);
  check (x24 == -233103132);
  check (x25 == 0x1.3b1e3ap+5F);
  check (x26 == -655067969);
  check (x27 == -0x1.3f12fap+5F);
  check (x28 == -1657848261);
  check (x29 == -0x1.2301d8p+5F);
  check (x30 == -469621136);
  check (x31 == -0x1.272312p+5F);
}

void f391(int x0, double x1, int x2, double x3, int x4, double x5)
{
  check (x0 == 291890958);
  check (x1 == -0x1.4bca12aef167ap+5);
  check (x2 == -1302322450);
  check (x3 == 0x1.c212251659908p+2);
  check (x4 == 404085563);
  check (x5 == 0x1.503d3d9857454p+4);
}

void f392(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7)
{
  check (x0 == -468039968);
  check (x1 == -0x1.b47af22ae7b01p+4);
  check (x2 == 1616050395);
  check (x3 == -0x1.ee4fd12b9c0f9p+4);
  check (x4 == 2030619672);
  check (x5 == 0x1.8d4e9b5a69564p+4);
  check (x6 == -608926474);
  check (x7 == -0x1.0e7e87e37abbcp+3);
}

void f393(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7, int x8, double x9)
{
  check (x0 == -502607993);
  check (x1 == -0x1.69cd66b68a5d9p+5);
  check (x2 == 1234171796);
  check (x3 == 0x1.89bf9cbad243p+4);
  check (x4 == 94251305);
  check (x5 == -0x1.816d7bc68640cp+3);
  check (x6 == 646416130);
  check (x7 == -0x1.ab2010cce6194p+4);
  check (x8 == -17798135);
  check (x9 == 0x1.e34353b26af9p+3);
}

void f394(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7, int x8, double x9, int x10, double x11)
{
  check (x0 == 143681772);
  check (x1 == 0x1.46c0df10bac8p+2);
  check (x2 == -1931703068);
  check (x3 == -0x1.0278eb7681ef1p+5);
  check (x4 == 59026191);
  check (x5 == 0x1.691eebbe42592p+5);
  check (x6 == -1739183125);
  check (x7 == -0x1.541ad70318b24p+3);
  check (x8 == -980874536);
  check (x9 == -0x1.7fc40a5330194p+3);
  check (x10 == -995025504);
  check (x11 == 0x1.6ce6595c56728p+3);
}

void f395(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7, int x8, double x9, int x10, double x11, int x12, double x13, int x14, double x15)
{
  check (x0 == 1910898156);
  check (x1 == -0x1.2818b9c532dfcp+5);
  check (x2 == 1658733616);
  check (x3 == -0x1.3d70c51d043efp+4);
  check (x4 == -582282100);
  check (x5 == -0x1.9c074f8758f08p+2);
  check (x6 == -1249667458);
  check (x7 == -0x1.526c8496c465p+3);
  check (x8 == -28360498);
  check (x9 == 0x1.2412485a6ff5cp+4);
  check (x10 == -1924594002);
  check (x11 == 0x1.27fa37db54ef4p+4);
  check (x12 == 1138477050);
  check (x13 == 0x1.52e686eea7ef8p+3);
  check (x14 == -1143415984);
  check (x15 == -0x1.5979124b2fd65p+5);
}

void f396(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7, int x8, double x9, int x10, double x11, int x12, double x13, int x14, double x15, int x16, double x17, int x18, double x19, int x20, double x21, int x22, double x23, int x24, double x25, int x26, double x27, int x28, double x29, int x30, double x31)
{
  check (x0 == 806807427);
  check (x1 == -0x1.1297d955fa04ep+4);
  check (x2 == -1848197165);
  check (x3 == -0x1.6db03a8b098a7p+4);
  check (x4 == -1645767426);
  check (x5 == -0x1.667b255c2988p+5);
  check (x6 == 1978613310);
  check (x7 == 0x1.703578fdb2f14p+4);
  check (x8 == 165072864);
  check (x9 == -0x1.30105fb0b79f8p+5);
  check (x10 == 408048480);
  check (x11 == 0x1.d8f4bae679b58p+4);
  check (x12 == -2107517091);
  check (x13 == 0x1.590e767f3283ap+5);
  check (x14 == 1787122419);
  check (x15 == -0x1.fb4b855c18bap+0);
  check (x16 == 1768946980);
  check (x17 == -0x1.114c742f3336p+1);
  check (x18 == -318723215);
  check (x19 == 0x1.5b4d970ba466p+4);
  check (x20 == -982994182);
  check (x21 == 0x1.27204b475c7p+4);
  check (x22 == -1544866637);
  check (x23 == 0x1.8dbda55960becp+4);
  check (x24 == -348173931);
  check (x25 == -0x1.03cc013edab5ep+4);
  check (x26 == 1679405144);
  check (x27 == 0x1.957c5df4980a4p+4);
  check (x28 == 447449844);
  check (x29 == -0x1.b6df847381ebbp+4);
  check (x30 == -1236663055);
  check (x31 == 0x1.62db5109ca6c4p+4);
}

void f397(long long x0, float x1, long long x2, float x3, long long x4, float x5)
{
  check (x0 == 4785801764088872046);
  check (x1 == 0x1.25b73ep+2F);
  check (x2 == 8586031223180042616);
  check (x3 == 0x1.db4c4p+4F);
  check (x4 == 3840614249491433503);
  check (x5 == 0x1.1ac97ep+2F);
}

void f398(long long x0, float x1, long long x2, float x3, long long x4, float x5, long long x6, float x7)
{
  check (x0 == -330935148507099720);
  check (x1 == 0x1.d819a2p+4F);
  check (x2 == -2036618730679336579);
  check (x3 == -0x1.5ca7dap+5F);
  check (x4 == -4952543996741785342);
  check (x5 == -0x1.0896ep+3F);
  check (x6 == 5252210869316814940);
  check (x7 == -0x1.8364a8p+5F);
}

void f399(long long x0, float x1, long long x2, float x3, long long x4, float x5, long long x6, float x7, long long x8, float x9)
{
  check (x0 == -4594533007969215430);
  check (x1 == -0x1.316d8ep+2F);
  check (x2 == 5222965446399891275);
  check (x3 == -0x1.62e0b4p+4F);
  check (x4 == 930875816963334098);
  check (x5 == 0x1.6eb00cp+1F);
  check (x6 == -4413873416109822686);
  check (x7 == 0x1.5f3794p+4F);
  check (x8 == -5563167892611491228);
  check (x9 == -0x1.42237cp+5F);
}

void f400(long long x0, float x1, long long x2, float x3, long long x4, float x5, long long x6, float x7, long long x8, float x9, long long x10, float x11)
{
  check (x0 == 5633226159284914493);
  check (x1 == -0x1.5e5bdp+5F);
  check (x2 == -3542461622822811062);
  check (x3 == 0x1.d5ea48p+4F);
  check (x4 == -7856285668828652720);
  check (x5 == -0x1.66d642p+5F);
  check (x6 == -413372358248625160);
  check (x7 == 0x1.62029ap+5F);
  check (x8 == 3141849129382149905);
  check (x9 == -0x1.37d178p+3F);
  check (x10 == -2611981681636038282);
  check (x11 == -0x1.2fc55p+3F);
}

void f401(long long x0, float x1, long long x2, float x3, long long x4, float x5, long long x6, float x7, long long x8, float x9, long long x10, float x11, long long x12, float x13, long long x14, float x15)
{
  check (x0 == -4743302682290876029);
  check (x1 == 0x1.54da1ap+5F);
  check (x2 == -5360701301012779250);
  check (x3 == 0x1.1bb79p+5F);
  check (x4 == -7708824747727038723);
  check (x5 == -0x1.adc674p+1F);
  check (x6 == 5393634098042998079);
  check (x7 == -0x1.c1e552p+4F);
  check (x8 == 6602860087976457967);
  check (x9 == 0x1.70de66p+4F);
  check (x10 == -4560490064318100677);
  check (x11 == 0x1.8c6e6p+2F);
  check (x12 == -6201641412528511055);
  check (x13 == -0x1.403db2p+5F);
  check (x14 == 4289570164227552661);
  check (x15 == -0x1.79a268p+4F);
}

void f402(long long x0, float x1, long long x2, float x3, long long x4, float x5, long long x6, float x7, long long x8, float x9, long long x10, float x11, long long x12, float x13, long long x14, float x15, long long x16, float x17, long long x18, float x19, long long x20, float x21, long long x22, float x23, long long x24, float x25, long long x26, float x27, long long x28, float x29, long long x30, float x31)
{
  check (x0 == 2124944317141421801);
  check (x1 == 0x1.f44088p+4F);
  check (x2 == 6683878460132795808);
  check (x3 == -0x1.c79376p+2F);
  check (x4 == 3292605488923538059);
  check (x5 == -0x1.7cd34cp+5F);
  check (x6 == 8254180554966866783);
  check (x7 == 0x1.f02d5ap+4F);
  check (x8 == -6253980212159705323);
  check (x9 == -0x1.00712ap+5F);
  check (x10 == 860055996966095937);
  check (x11 == -0x1.8fa742p+5F);
  check (x12 == 8116031199702340492);
  check (x13 == -0x1.2e896cp+3F);
  check (x14 == -3751792011146389728);
  check (x15 == -0x1.4a66b6p+5F);
  check (x16 == 6250657440629901343);
  check (x17 == -0x1.7e848ap+5F);
  check (x18 == 4663574053055225240);
  check (x19 == -0x1.e558fap+4F);
  check (x20 == 6707007865128439334);
  check (x21 == -0x1.226facp+4F);
  check (x22 == -4445166152671219617);
  check (x23 == -0x1.7c0ab4p+5F);
  check (x24 == 4765646746810409789);
  check (x25 == 0x1.ef9b78p+4F);
  check (x26 == 2063672483915351739);
  check (x27 == 0x1.445aap+2F);
  check (x28 == 6758075718086150802);
  check (x29 == 0x1.092f98p+5F);
  check (x30 == -7119625559893119323);
  check (x31 == -0x1.44c89cp+4F);
}

void f403(long long x0, double x1, long long x2, double x3, long long x4, double x5)
{
  check (x0 == -4625048762028647228);
  check (x1 == 0x1.929339893fd2cp+4);
  check (x2 == 6433631088760665948);
  check (x3 == -0x1.8ff6941c7ae3ep+5);
  check (x4 == -8341337005941817067);
  check (x5 == -0x1.882b4b9513002p+5);
}

void f404(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7)
{
  check (x0 == -8987929280055585587);
  check (x1 == -0x1.a167011062f7p+4);
  check (x2 == 7558641433951593941);
  check (x3 == 0x1.605cfe6f2619p+5);
  check (x4 == 9149640156914079572);
  check (x5 == -0x1.923497ef55238p+3);
  check (x6 == 7658198411043359483);
  check (x7 == -0x1.14105d40c0335p+5);
}

void f405(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7, long long x8, double x9)
{
  check (x0 == -6008777600803747664);
  check (x1 == -0x1.4dd679b0293bp+4);
  check (x2 == -4901105254789267610);
  check (x3 == -0x1.7c34b41d25daap+5);
  check (x4 == -721974744206171562);
  check (x5 == 0x1.79a16cfd83bdp+4);
  check (x6 == -5044536763345915899);
  check (x7 == 0x1.9c87c763f1768p+3);
  check (x8 == -6845676587911458370);
  check (x9 == 0x1.a7eec567cf20cp+4);
}

void f406(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7, long long x8, double x9, long long x10, double x11)
{
  check (x0 == -7588476048231447857);
  check (x1 == 0x1.fff9327c44418p+4);
  check (x2 == 617801188719895415);
  check (x3 == 0x1.cab54f8415bcp+3);
  check (x4 == -8085561860157116493);
  check (x5 == -0x1.e8a8a4205cdccp+3);
  check (x6 == -6828828271868115716);
  check (x7 == -0x1.2f2b60c19e854p+5);
  check (x8 == 7256277085474007404);
  check (x9 == -0x1.4aeb7a8435c71p+4);
  check (x10 == -1059675880031231840);
  check (x11 == -0x1.7a2c41cb3bbb5p+5);
}

void f407(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7, long long x8, double x9, long long x10, double x11, long long x12, double x13, long long x14, double x15)
{
  check (x0 == 5553857602003537301);
  check (x1 == 0x1.219cf397d59c8p+5);
  check (x2 == 994864204345752339);
  check (x3 == -0x1.7ad8f071a8aebp+5);
  check (x4 == 1357252131386745770);
  check (x5 == -0x1.51fa23bcd76b6p+4);
  check (x6 == 2823685967218127767);
  check (x7 == -0x1.81fd854c3745cp+3);
  check (x8 == -1300203100998322180);
  check (x9 == 0x1.34fa0981f7424p+3);
  check (x10 == -8203356174116463521);
  check (x11 == 0x1.e21b86cd0d274p+4);
  check (x12 == -4529103705281940574);
  check (x13 == 0x1.a051d5615e77p+3);
  check (x14 == 679711078956748442);
  check (x15 == -0x1.2455d5f34a34ap+5);
}

void f408(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7, long long x8, double x9, long long x10, double x11, long long x12, double x13, long long x14, double x15, long long x16, double x17, long long x18, double x19, long long x20, double x21, long long x22, double x23, long long x24, double x25, long long x26, double x27, long long x28, double x29, long long x30, double x31)
{
  check (x0 == 1430938460784409464);
  check (x1 == -0x1.43198e11a29cp+0);
  check (x2 == -6918819636519950565);
  check (x3 == -0x1.4750be4b52638p+2);
  check (x4 == 8808741416378523984);
  check (x5 == -0x1.757044381618cp+4);
  check (x6 == -9062693905658193502);
  check (x7 == 0x1.0d0771250a968p+3);
  check (x8 == 6922289907895192522);
  check (x9 == 0x1.7b0e7cf18b8a6p+5);
  check (x10 == 6736159199818820134);
  check (x11 == -0x1.7b8a39e94ffc5p+5);
  check (x12 == 3804863710728130390);
  check (x13 == 0x1.c3b68f89f213p+1);
  check (x14 == 3425271500340453564);
  check (x15 == -0x1.1aa938749d43cp+4);
  check (x16 == 6607136313231776489);
  check (x17 == -0x1.a36aab875b86cp+4);
  check (x18 == -3223619728753880241);
  check (x19 == -0x1.6742262a4716cp+5);
  check (x20 == -2313296692970981738);
  check (x21 == -0x1.05ccf3165fef8p+3);
  check (x22 == 6958396398726172637);
  check (x23 == 0x1.41e81e7962ef6p+5);
  check (x24 == 6731360964491445388);
  check (x25 == -0x1.8121ca36360e8p+5);
  check (x26 == 8862774766736992880);
  check (x27 == -0x1.1cc1326ebbe5p+4);
  check (x28 == 7967132031159789466);
  check (x29 == -0x1.105df58e9e4c6p+4);
  check (x30 == 474948951647905664);
  check (x31 == 0x1.92919420fb784p+4);
}

void f409(float x0, double x1, float x2, double x3, float x4, double x5)
{
  check (x0 == -0x1.463a0ep+5F);
  check (x1 == -0x1.9c30b65a4abep+1);
  check (x2 == -0x1.837826p+4F);
  check (x3 == -0x1.0694ffa0efd72p+5);
  check (x4 == 0x1.29ee82p+4F);
  check (x5 == -0x1.43d2dd2222668p+5);
}

void f410(float x0, double x1, float x2, double x3, float x4, double x5, float x6, double x7)
{
  check (x0 == -0x1.069d7ep+5F);
  check (x1 == 0x1.cf5df887a93ep+4);
  check (x2 == 0x1.a2ac3ep+4F);
  check (x3 == -0x1.2931f617bf10ap+5);
  check (x4 == 0x1.fec822p+3F);
  check (x5 == -0x1.01a746115924ep+4);
  check (x6 == 0x1.fb85b8p+2F);
  check (x7 == -0x1.c3413dc8ec97p+1);
}

void f411(float x0, double x1, float x2, double x3, float x4, double x5, float x6, double x7, float x8, double x9)
{
  check (x0 == -0x1.040864p+4F);
  check (x1 == 0x1.308b1f9934adcp+5);
  check (x2 == -0x1.206f22p+5F);
  check (x3 == -0x1.1e1e7f665f6bbp+5);
  check (x4 == -0x1.9dd598p+4F);
  check (x5 == 0x1.1409686f6f9d8p+5);
  check (x6 == 0x1.b4bdbcp+3F);
  check (x7 == -0x1.fac8803ac1315p+4);
  check (x8 == 0x1.c6becap+3F);
  check (x9 == 0x1.154938607fef8p+4);
}

void f412(float x0, double x1, float x2, double x3, float x4, double x5, float x6, double x7, float x8, double x9, float x10, double x11)
{
  check (x0 == -0x1.57f322p+5F);
  check (x1 == -0x1.1e8e8a4a5ee12p+5);
  check (x2 == -0x1.bb5912p+1F);
  check (x3 == -0x1.5b70468d78adcp+3);
  check (x4 == 0x1.8c8aaep+3F);
  check (x5 == -0x1.7cfd69f57dc8p+1);
  check (x6 == 0x1.426b62p+4F);
  check (x7 == -0x1.03abf4a058278p+5);
  check (x8 == -0x1.20e918p+4F);
  check (x9 == -0x1.634723c01f15cp+3);
  check (x10 == -0x1.bde1bp+4F);
  check (x11 == -0x1.0042d11c911e7p+5);
}

void f413(float x0, double x1, float x2, double x3, float x4, double x5, float x6, double x7, float x8, double x9, float x10, double x11, float x12, double x13, float x14, double x15)
{
  check (x0 == 0x1.0815aep+5F);
  check (x1 == -0x1.ba39055834b1bp+4);
  check (x2 == -0x1.964d5ep+4F);
  check (x3 == 0x1.e501c2414e87cp+4);
  check (x4 == -0x1.2daa8ep+3F);
  check (x5 == 0x1.c91d778ca7ac8p+2);
  check (x6 == 0x1.0b4134p+4F);
  check (x7 == -0x1.7fa07f9f1943cp+5);
  check (x8 == -0x1.3ba418p+4F);
  check (x9 == 0x1.32ab21f0508d4p+4);
  check (x10 == -0x1.4a227ep+5F);
  check (x11 == 0x1.3a92c1894175cp+5);
  check (x12 == -0x1.142f0ep+4F);
  check (x13 == 0x1.45799d9f2727ep+5);
  check (x14 == -0x1.08935cp+4F);
  check (x15 == 0x1.f048834ea61c8p+3);
}

void f414(float x0, double x1, float x2, double x3, float x4, double x5, float x6, double x7, float x8, double x9, float x10, double x11, float x12, double x13, float x14, double x15, float x16, double x17, float x18, double x19, float x20, double x21, float x22, double x23, float x24, double x25, float x26, double x27, float x28, double x29, float x30, double x31)
{
  check (x0 == -0x1.4e4e8p+5F);
  check (x1 == -0x1.f99f782775618p+2);
  check (x2 == -0x1.3db9e2p+5F);
  check (x3 == -0x1.1e97876222d98p+4);
  check (x4 == 0x1.f4642ap+1F);
  check (x5 == -0x1.45e825adeac28p+3);
  check (x6 == -0x1.18b5a2p+4F);
  check (x7 == 0x1.1ceeaa7fcb38cp+3);
  check (x8 == 0x1.18204ep+5F);
  check (x9 == -0x1.ccf599f7f7c38p+3);
  check (x10 == 0x1.f0575cp+3F);
  check (x11 == -0x1.d2fe3d1e5b01p+3);
  check (x12 == 0x1.3333cp+5F);
  check (x13 == -0x1.0bdf6bdade8b9p+5);
  check (x14 == 0x1.2432c4p+5F);
  check (x15 == 0x1.3d0114d9d2608p+2);
  check (x16 == 0x1.799254p+5F);
  check (x17 == 0x1.6d3fd21cf7ep+0);
  check (x18 == -0x1.aac21cp+1F);
  check (x19 == 0x1.d4d72634889ep+4);
  check (x20 == 0x1.ed9606p+3F);
  check (x21 == -0x1.2dbd9fc6c123cp+4);
  check (x22 == -0x1.c5dep+4F);
  check (x23 == 0x1.f3a24ea439cep+2);
  check (x24 == 0x1.e937p+3F);
  check (x25 == -0x1.06547be6370f2p+5);
  check (x26 == 0x1.54b1bcp+5F);
  check (x27 == -0x1.61df4c9b62b5bp+5);
  check (x28 == -0x1.a6f8e2p-2F);
  check (x29 == -0x1.4c9937eb589aep+4);
  check (x30 == 0x1.e8df44p+3F);
  check (x31 == 0x1.bfdca90c2a3p+0);
}

void f415(int x0, long long x1, float x2, double x3, int x4, long long x5)
{
  check (x0 == -2110890493);
  check (x1 == 5924198326309439683);
  check (x2 == -0x1.79630cp+3F);
  check (x3 == 0x1.c2e717265b38p-2);
  check (x4 == 716574760);
  check (x5 == -4759906004936192865);
}

void f416(int x0, long long x1, float x2, double x3, int x4, long long x5, float x6, double x7)
{
  check (x0 == 1433481649);
  check (x1 == 1606306312240853647);
  check (x2 == 0x1.d1c904p+4F);
  check (x3 == 0x1.57035aed5e594p+3);
  check (x4 == 502332839);
  check (x5 == -4834899154163803824);
  check (x6 == -0x1.cd2fc6p+4F);
  check (x7 == -0x1.d6ccce8679588p+3);
}

void f417(int x0, long long x1, float x2, double x3, int x4, long long x5, float x6, double x7, int x8, long long x9)
{
  check (x0 == -1071332774);
  check (x1 == -5530444281749552333);
  check (x2 == -0x1.6e5e18p+5F);
  check (x3 == 0x1.02ad110d063a4p+5);
  check (x4 == -115286341);
  check (x5 == -598347636197685714);
  check (x6 == 0x1.336176p-2F);
  check (x7 == 0x1.52b8bc651d2d8p+5);
  check (x8 == -258550597);
  check (x9 == 1703560940339619483);
}

void f418(int x0, long long x1, float x2, double x3, int x4, long long x5, float x6, double x7, int x8, long long x9, float x10, double x11)
{
  check (x0 == 1731576349);
  check (x1 == -142512853985259733);
  check (x2 == 0x1.34236ap+4F);
  check (x3 == -0x1.eba235df942cbp+4);
  check (x4 == -947902216);
  check (x5 == 5332257013602231417);
  check (x6 == -0x1.826a7ep+5F);
  check (x7 == -0x1.1a8d59c1fe8b8p+4);
  check (x8 == 463464297);
  check (x9 == -7599301478246900207);
  check (x10 == -0x1.c9c0f6p+3F);
  check (x11 == 0x1.0e5925298ca9p+4);
}

void f419(int x0, long long x1, float x2, double x3, int x4, long long x5, float x6, double x7, int x8, long long x9, float x10, double x11, int x12, long long x13, float x14, double x15)
{
  check (x0 == -1890241325);
  check (x1 == 2630943682798004567);
  check (x2 == 0x1.61b1a6p+4F);
  check (x3 == -0x1.34ff82c36c14ap+5);
  check (x4 == 597978649);
  check (x5 == 2161353340787579254);
  check (x6 == 0x1.fa0bf8p+4F);
  check (x7 == 0x1.4064236513c88p+5);
  check (x8 == 1513625428);
  check (x9 == 1397943766896039433);
  check (x10 == -0x1.76ee02p+5F);
  check (x11 == -0x1.20251c563d6ep+1);
  check (x12 == -1786874502);
  check (x13 == -5317524468545326241);
  check (x14 == -0x1.8a9a36p+2F);
  check (x15 == -0x1.191bd128d1634p+5);
}

void f420(int x0, long long x1, float x2, double x3, int x4, long long x5, float x6, double x7, int x8, long long x9, float x10, double x11, int x12, long long x13, float x14, double x15, int x16, long long x17, float x18, double x19, int x20, long long x21, float x22, double x23, int x24, long long x25, float x26, double x27, int x28, long long x29, float x30, double x31)
{
  check (x0 == 959675783);
  check (x1 == 1196041243376320773);
  check (x2 == 0x1.0a72f6p+5F);
  check (x3 == -0x1.cbe643b36ad04p+3);
  check (x4 == 1123302514);
  check (x5 == -6718510740770238895);
  check (x6 == 0x1.002834p+5F);
  check (x7 == 0x1.f0d345e879478p+3);
  check (x8 == 1641225881);
  check (x9 == -5572241851790438625);
  check (x10 == -0x1.0e075p+3F);
  check (x11 == 0x1.3fa8f1e5b895cp+4);
  check (x12 == -63478716);
  check (x13 == 3467414303472329434);
  check (x14 == -0x1.d84a7cp-1F);
  check (x15 == 0x1.6be3ace6af198p+3);
  check (x16 == -270024581);
  check (x17 == 6017685922514238267);
  check (x18 == -0x1.ccc23p+4F);
  check (x19 == 0x1.1a551b768cabp+5);
  check (x20 == 1877570176);
  check (x21 == 4346389735073521158);
  check (x22 == 0x1.4ee12ep+5F);
  check (x23 == -0x1.f80ae605dec22p+4);
  check (x24 == 2050124089);
  check (x25 == 7082638387698057430);
  check (x26 == 0x1.927e26p-1F);
  check (x27 == -0x1.7fef1e10fc643p+4);
  check (x28 == -148676762);
  check (x29 == 7530344175266096969);
  check (x30 == 0x1.516b7ap+4F);
  check (x31 == -0x1.15cb866980f03p+5);
}

void f421(int x0)
{
  check (x0 == -1015869374);
}

void f422(int x0, char * x1, int x2, double x3, double x4, float x5, float x6, float x7, double x8)
{
  check (x0 == 1240232142);
  check (strcmp(x1, "ub") == 0);
  check (x2 == -1647534744);
  check (x3 == -0x1.4094cedef0975p+5);
  check (x4 == -0x1.8a79ec82693ap+4);
  check (x5 == 0x1.39641cp+3F);
  check (x6 == -0x1.618a56p+5F);
  check (x7 == 0x1.4edf18p+1F);
  check (x8 == 0x1.fe9a5b7ee898p+1);
}

void f423(long long x0, int x1, char * x2)
{
  check (x0 == -8665413124681905845);
  check (x1 == -1434207296);
  check (strcmp(x2, "") == 0);
}

char * f424(double x0, double x1, long long x2, char * x3, long long x4, float x5, double x6, int x7)
{
  check (x0 == 0x1.2bca63c697988p+2);
  check (x1 == 0x1.8bc702c34bba8p+4);
  check (x2 == 3239818990999700158);
  check (strcmp(x3, "s") == 0);
  check (x4 == 992036704999165499);
  check (x5 == -0x1.d08258p+3F);
  check (x6 == 0x1.bcd3ae4af3e9p+3);
  check (x7 == -1493525618);
  return "nu";
}

void f425(int x0, float x1, char * x2, double x3, int x4, float x5, char * x6, double x7)
{
  check (x0 == -980612814);
  check (x1 == 0x1.391782p+5F);
  check (strcmp(x2, "tg") == 0);
  check (x3 == -0x1.d5bae22c76912p+4);
  check (x4 == 91017471);
  check (x5 == 0x1.483dd6p+5F);
  check (strcmp(x6, "iz") == 0);
  check (x7 == -0x1.6d6199381f1a6p+5);
}

void f426(double x0, long long x1, int x2)
{
  check (x0 == 0x1.15c33c22e6478p+4);
  check (x1 == 1754775007698874349);
  check (x2 == -656432153);
}

long long f427(float x0, long long x1, double x2, int x3, int x4, double x5, char * x6, int x7, long long x8, char * x9, int x10)
{
  check (x0 == 0x1.f7daaep+4F);
  check (x1 == 6303598955662405784);
  check (x2 == -0x1.9d7b888770df9p+4);
  check (x3 == 207824772);
  check (x4 == -1802915835);
  check (x5 == -0x1.bea5a4cfa5fap+4);
  check (strcmp(x6, "j") == 0);
  check (x7 == 1388970980);
  check (x8 == -1339300442168892344);
  check (strcmp(x9, "q") == 0);
  check (x10 == -872114698);
  return 4882742375719656158;
}

void f428(double x0, double x1)
{
  check (x0 == -0x1.d6fe29b3a6838p+3);
  check (x1 == -0x1.f4dbddc0309e4p+3);
}

int f429(long long x0, double x1)
{
  check (x0 == 6631361243123345453);
  check (x1 == -0x1.e311eb947f6bcp+3);
  return -1567837711;
}

void f430(int x0, float x1)
{
  check (x0 == -1577972474);
  check (x1 == -0x1.e4787ep+4F);
}

long long f431(char * x0, long long x1, long long x2, int x3, int x4, int x5, double x6, long long x7)
{
  check (strcmp(x0, "lr") == 0);
  check (x1 == 7824883241317064450);
  check (x2 == -3471128067833059549);
  check (x3 == 1632927412);
  check (x4 == 1888537793);
  check (x5 == -607764353);
  check (x6 == -0x1.5123afcd7ecddp+5);
  check (x7 == 8400627593300028090);
  return -4147257517354942497;
}

void f432(double x0, double x1, float x2, int x3, long long x4)
{
  check (x0 == 0x1.17a4f199b3c22p+5);
  check (x1 == 0x1.64786a609792ep+5);
  check (x2 == -0x1.150da8p+4F);
  check (x3 == 1410379071);
  check (x4 == -2413400064731809023);
}

signed char f433(char * x0)
{
  check (strcmp(x0, "") == 0);
  return 308990103;
}

void f434(char * x0, float x1, char * x2, float x3, char * x4, float x5)
{
  check (strcmp(x0, "w") == 0);
  check (x1 == -0x1.bb34aep+2F);
  check (strcmp(x2, "w") == 0);
  check (x3 == 0x1.0f10bep+5F);
  check (strcmp(x4, "l") == 0);
  check (x5 == 0x1.7d8166p+5F);
}

unsigned char f435(long long x0, int x1, double x2, float x3, double x4, long long x5, float x6)
{
  check (x0 == -3908210990047860652);
  check (x1 == -444129001);
  check (x2 == 0x1.7c9bf3c5d174p+5);
  check (x3 == 0x1.cf4482p+0F);
  check (x4 == 0x1.5754f0fd42778p+5);
  check (x5 == -8656765496303253453);
  check (x6 == -0x1.bda29ap+3F);
  return -507901916;
}

void f436(float x0, long long x1, double x2, int x3, double x4, double x5, long long x6, char * x7)
{
  check (x0 == 0x1.771efap+4F);
  check (x1 == -2494910827047751660);
  check (x2 == -0x1.00887c8e99507p+5);
  check (x3 == 610850475);
  check (x4 == 0x1.ceeede4b67b38p+4);
  check (x5 == 0x1.a20843fb2fcep+2);
  check (x6 == 5605729385131691151);
  check (strcmp(x7, "p") == 0);
}

void f437(void)
{
}

long long f438(char * x0, char * x1, int x2, double x3, char * x4, char * x5, double x6, float x7)
{
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "") == 0);
  check (x2 == -202109029);
  check (x3 == -0x1.afb3efe66f87dp+4);
  check (strcmp(x4, "be") == 0);
  check (strcmp(x5, "") == 0);
  check (x6 == 0x1.fe63cd903e60cp+4);
  check (x7 == -0x1.5577fep+4F);
  return 7293006492954305425;
}

void f439(float x0, long long x1, long long x2, char * x3)
{
  check (x0 == -0x1.62e354p+5F);
  check (x1 == -201176859960062916);
  check (x2 == -1486954930444078655);
  check (strcmp(x3, "nc") == 0);
}

int f440(char * x0, char * x1, int x2, char * x3, float x4, float x5)
{
  check (strcmp(x0, "s") == 0);
  check (strcmp(x1, "im") == 0);
  check (x2 == 1685469183);
  check (strcmp(x3, "") == 0);
  check (x4 == -0x1.9af4e4p+1F);
  check (x5 == 0x1.0c8694p+4F);
  return -1885287289;
}

void f441(float x0, double x1)
{
  check (x0 == -0x1.4f4952p+5F);
  check (x1 == -0x1.0852456454e52p+4);
}

float f442(long long x0, int x1, char * x2)
{
  check (x0 == -4574786867840467559);
  check (x1 == 741846488);
  check (strcmp(x2, "") == 0);
  return 0x1.03ef0f80f883p+4;
}

float f443(int x0, long long x1, float x2, int x3)
{
  check (x0 == -929955458);
  check (x1 == 8349241252947778100);
  check (x2 == -0x1.3dad24p+4F);
  check (x3 == -598892263);
  return 0x1.f28353e38a158p+2;
}

float f444(long long x0, int x1, long long x2, int x3, double x4, char * x5, float x6)
{
  check (x0 == -9168495147017343737);
  check (x1 == -1355844911);
  check (x2 == 6015696631526171849);
  check (x3 == -1126124554);
  check (x4 == 0x1.0846d8d3c0b5p+1);
  check (strcmp(x5, "z") == 0);
  check (x6 == -0x1.0fddacp+2F);
  return -0x1.5057465ce74ap+0;
}

short f445(int x0, char * x1, char * x2, float x3)
{
  check (x0 == -1840827060);
  check (strcmp(x1, "k") == 0);
  check (strcmp(x2, "n") == 0);
  check (x3 == -0x1.2ab06cp+5F);
  return 364810964;
}

signed char f446(long long x0, int x1, int x2)
{
  check (x0 == -2084858707348297909);
  check (x1 == -697335107);
  check (x2 == 814383526);
  return 31906184;
}

float f447(int x0, float x1, int x2, double x3, int x4)
{
  check (x0 == 1735041625);
  check (x1 == 0x1.6948eep+4F);
  check (x2 == 1324891379);
  check (x3 == -0x1.1b172a64237cap+5);
  check (x4 == 654583766);
  return -0x1.9b2bc810344b3p+4;
}

void f448(int x0, double x1, int x2, char * x3)
{
  check (x0 == -42462564);
  check (x1 == 0x1.6e425c1db6638p+5);
  check (x2 == 1484676499);
  check (strcmp(x3, "u") == 0);
}

void f449(double x0, float x1, float x2, float x3, float x4, double x5, double x6, int x7)
{
  check (x0 == -0x1.391bb7bc54cddp+5);
  check (x1 == -0x1.6d16d4p+5F);
  check (x2 == -0x1.d0ea68p+3F);
  check (x3 == 0x1.0903acp+3F);
  check (x4 == 0x1.7925bap+5F);
  check (x5 == 0x1.b3e12b3703288p+2);
  check (x6 == -0x1.3fe9c072c2c18p+5);
  check (x7 == 533167569);
}

float f450(float x0, char * x1, double x2)
{
  check (x0 == -0x1.391342p+3F);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.2dcd1548444d8p+4);
  return -0x1.5da0aa36d5afbp+4;
}

void f451(double x0, char * x1, float x2, int x3, char * x4, double x5, double x6, char * x7, int x8, char * x9)
{
  check (x0 == 0x1.68a7b7ae28ac4p+5);
  check (strcmp(x1, "") == 0);
  check (x2 == -0x1.341e36p+2F);
  check (x3 == 1840099829);
  check (strcmp(x4, "nu") == 0);
  check (x5 == 0x1.f411a8128bd94p+4);
  check (x6 == 0x1.1fd572f18b34p+3);
  check (strcmp(x7, "k") == 0);
  check (x8 == -762088177);
  check (strcmp(x9, "mt") == 0);
}

double f452(char * x0)
{
  check (strcmp(x0, "sq") == 0);
  return 0x1.a111163f62bc8p+4;
}

long long f453(double x0)
{
  check (x0 == 0x1.2825527ad5178p+3);
  return -5630994881618525096;
}

double f454(float x0, float x1, char * x2, float x3, long long x4, int x5, int x6, float x7)
{
  check (x0 == 0x1.fd32c2p+1F);
  check (x1 == 0x1.685e54p+0F);
  check (strcmp(x2, "x") == 0);
  check (x3 == 0x1.81394cp+3F);
  check (x4 == 7640738329126546128);
  check (x5 == 1921711578);
  check (x6 == 1413687500);
  check (x7 == -0x1.2fb75cp+3F);
  return 0x1.495776a3bc2d4p+4;
}

long long f455(double x0, char * x1, char * x2, long long x3, int x4, float x5, double x6, char * x7)
{
  check (x0 == 0x1.53c1cceca1cecp+5);
  check (strcmp(x1, "") == 0);
  check (strcmp(x2, "") == 0);
  check (x3 == 1105934127044374804);
  check (x4 == 1178487668);
  check (x5 == -0x1.c045cap+4F);
  check (x6 == 0x1.b5bf8f0f1886p+4);
  check (strcmp(x7, "zd") == 0);
  return 4034204378606768929;
}

short f456(double x0, float x1, int x2)
{
  check (x0 == 0x1.1a07c6e063594p+3);
  check (x1 == 0x1.69ddfap+4F);
  check (x2 == 553350536);
  return 117388943;
}

int f457(char * x0, int x1, char * x2, double x3, char * x4, int x5, char * x6, char * x7, int x8, double x9)
{
  check (strcmp(x0, "u") == 0);
  check (x1 == -347972784);
  check (strcmp(x2, "") == 0);
  check (x3 == -0x1.7755d007502f6p+5);
  check (strcmp(x4, "wd") == 0);
  check (x5 == 485822856);
  check (strcmp(x6, "") == 0);
  check (strcmp(x7, "b") == 0);
  check (x8 == 74557069);
  check (x9 == 0x1.c86b3f7ba788p+3);
  return 79873958;
}

char * f458(float x0, float x1, long long x2, int x3, float x4, char * x5, float x6, int x7, char * x8, float x9)
{
  check (x0 == 0x1.800ee6p+5F);
  check (x1 == 0x1.13e81ap+4F);
  check (x2 == 8554637079345217039);
  check (x3 == 1071096687);
  check (x4 == 0x1.6582c2p+4F);
  check (strcmp(x5, "pl") == 0);
  check (x6 == -0x1.629304p+5F);
  check (x7 == 750874870);
  check (strcmp(x8, "rm") == 0);
  check (x9 == -0x1.bd38b2p+4F);
  return "";
}

void f459(long long x0, double x1, float x2, long long x3, int x4, char * x5, int x6)
{
  check (x0 == -5140499923530184650);
  check (x1 == 0x1.4a04d372a1d94p+4);
  check (x2 == 0x1.c0892ep+3F);
  check (x3 == 2072759926690125566);
  check (x4 == -1340815779);
  check (strcmp(x5, "g") == 0);
  check (x6 == 1957795903);
}

void f460(long long x0, long long x1, char * x2, double x3, float x4)
{
  check (x0 == -3062114765852251643);
  check (x1 == 7862760728161655281);
  check (strcmp(x2, "xx") == 0);
  check (x3 == -0x1.12f319566176cp+4);
  check (x4 == -0x1.30622ap+5F);
}

float f461(long long x0, char * x1, int x2, double x3, float x4, float x5, long long x6)
{
  check (x0 == 6795411416575975154);
  check (strcmp(x1, "") == 0);
  check (x2 == 1511438362);
  check (x3 == 0x1.80892bd29def2p+5);
  check (x4 == -0x1.512ab6p+2F);
  check (x5 == -0x1.07d93p+4F);
  check (x6 == 741615775782368756);
  return -0x1.d0781f0cf9ffp+2;
}

short f462(void)
{
  return 398131271;
}

void f463(float x0, int x1, long long x2, char * x3, int x4)
{
  check (x0 == 0x1.206f28p+2F);
  check (x1 == -1247030131);
  check (x2 == 3921076818436752973);
  check (strcmp(x3, "") == 0);
  check (x4 == 543680408);
}

void f464(double x0, char * x1, char * x2, float x3, int x4, float x5, long long x6, char * x7, long long x8)
{
  check (x0 == 0x1.8285c4a2afd4cp+5);
  check (strcmp(x1, "") == 0);
  check (strcmp(x2, "xy") == 0);
  check (x3 == 0x1.7c6106p+5F);
  check (x4 == -1885775365);
  check (x5 == 0x1.6a29e2p+5F);
  check (x6 == 944568378017938066);
  check (strcmp(x7, "q") == 0);
  check (x8 == -884704395993618939);
}

unsigned short f465(float x0, char * x1, char * x2, int x3, long long x4, int x5)
{
  check (x0 == 0x1.302d8p+5F);
  check (strcmp(x1, "ex") == 0);
  check (strcmp(x2, "") == 0);
  check (x3 == -405891427);
  check (x4 == 1227013684972181995);
  check (x5 == -1000186948);
  return -343383693;
}

unsigned char f466(long long x0, int x1, int x2, double x3, long long x4, long long x5, long long x6, double x7, int x8, int x9)
{
  check (x0 == 6857221878488582098);
  check (x1 == 1730962491);
  check (x2 == 291858990);
  check (x3 == -0x1.285250f0f064p+0);
  check (x4 == -4556768309803156686);
  check (x5 == -8323750441865572717);
  check (x6 == 7563523046052198818);
  check (x7 == 0x1.45a7fd9b45ebcp+5);
  check (x8 == 565771334);
  check (x9 == 677857933);
  return 234533425;
}

void f467(long long x0, int x1, char * x2, long long x3, int x4, long long x5, double x6, char * x7)
{
  check (x0 == -7371333566673562632);
  check (x1 == 583842555);
  check (strcmp(x2, "z") == 0);
  check (x3 == -1007304995085823762);
  check (x4 == -1006666575);
  check (x5 == -2054288800049442669);
  check (x6 == 0x1.d8faaa8d6b8d4p+4);
  check (strcmp(x7, "") == 0);
}

char * f468(float x0, long long x1)
{
  check (x0 == -0x1.1fb2c2p+5F);
  check (x1 == 8369459781745381848);
  return "";
}

char * f469(long long x0, long long x1, long long x2, float x3, int x4, int x5, float x6, float x7)
{
  check (x0 == -2276048252443342279);
  check (x1 == 9150293830039087051);
  check (x2 == 2847786057469800577);
  check (x3 == -0x1.2ff2eep+4F);
  check (x4 == -1410904197);
  check (x5 == -613597738);
  check (x6 == -0x1.a40fdap+4F);
  check (x7 == 0x1.7049f6p+4F);
  return "";
}

short f470(char * x0, char * x1, double x2, int x3, char * x4)
{
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "v") == 0);
  check (x2 == -0x1.1f57d917e44cp-1);
  check (x3 == -355225065);
  check (strcmp(x4, "zu") == 0);
  return -27818728;
}

unsigned char f471(double x0, double x1, char * x2, double x3, float x4, long long x5, char * x6, char * x7, double x8, long long x9, float x10)
{
  check (x0 == -0x1.a740dd3fcaf98p+3);
  check (x1 == -0x1.d9548fc4e2f38p+4);
  check (strcmp(x2, "") == 0);
  check (x3 == 0x1.d8c302bd8a89p+4);
  check (x4 == 0x1.06d3d8p+4F);
  check (x5 == 5178030567210428519);
  check (strcmp(x6, "f") == 0);
  check (strcmp(x7, "rv") == 0);
  check (x8 == -0x1.2badc17b9aafap+5);
  check (x9 == -9201690741735638843);
  check (x10 == 0x1.4220d2p+3F);
  return 406462047;
}

double f472(void)
{
  return 0x1.75c9708ad8f2ap+5;
}

void f473(float x0, float x1, double x2, float x3, float x4, int x5, long long x6, long long x7, char * x8, int x9)
{
  check (x0 == 0x1.36efd6p+2F);
  check (x1 == 0x1.053a4p+5F);
  check (x2 == 0x1.e550a8f061234p+4);
  check (x3 == 0x1.c5e5e2p+2F);
  check (x4 == -0x1.ca56a2p+2F);
  check (x5 == -2038269283);
  check (x6 == 740970995396018880);
  check (x7 == 8983648937899378320);
  check (strcmp(x8, "") == 0);
  check (x9 == 82375094);
}

void f474(double x0, float x1, char * x2, char * x3, char * x4, long long x5, long long x6, double x7, char * x8)
{
  check (x0 == -0x1.56c9294a9523dp+5);
  check (x1 == -0x1.789738p+4F);
  check (strcmp(x2, "sr") == 0);
  check (strcmp(x3, "e") == 0);
  check (strcmp(x4, "mp") == 0);
  check (x5 == 5863210990172298808);
  check (x6 == -6433859347771378132);
  check (x7 == -0x1.1a8cea40ba71cp+5);
  check (strcmp(x8, "w") == 0);
}

void f475(double x0, double x1, int x2, int x3)
{
  check (x0 == -0x1.697531db3f382p+5);
  check (x1 == 0x1.2007a26fd0fap+3);
  check (x2 == 734632501);
  check (x3 == -1776718043);
}

void f476(float x0, double x1, double x2)
{
  check (x0 == -0x1.23592p+5F);
  check (x1 == 0x1.2c530b3a7e8b8p+4);
  check (x2 == 0x1.20a8a29265cap+4);
}

void f477(float x0, double x1, float x2, float x3, int x4)
{
  check (x0 == 0x1.19991p+5F);
  check (x1 == 0x1.b6ccdba4e06bcp+4);
  check (x2 == -0x1.393bp+4F);
  check (x3 == -0x1.b49814p+4F);
  check (x4 == 554256728);
}

void f478(long long x0, int x1, double x2, int x3, double x4, int x5, long long x6, double x7)
{
  check (x0 == -5546593685724542983);
  check (x1 == 1557529550);
  check (x2 == 0x1.73954a446a7f4p+3);
  check (x3 == -610134774);
  check (x4 == -0x1.8acc86906bc38p+5);
  check (x5 == 474601067);
  check (x6 == 5140219771157459695);
  check (x7 == -0x1.796a5131c2fc9p+4);
}

void f479(int x0, float x1, char * x2, char * x3, int x4)
{
  check (x0 == -406157722);
  check (x1 == -0x1.8c3d26p+5F);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "") == 0);
  check (x4 == -120163677);
}

short f480(char * x0, char * x1, char * x2, double x3)
{
  check (strcmp(x0, "wy") == 0);
  check (strcmp(x1, "") == 0);
  check (strcmp(x2, "ii") == 0);
  check (x3 == -0x1.32d00afe4de1p+5);
  return -204561930;
}

int f481(char * x0, int x1, long long x2, char * x3, char * x4)
{
  check (strcmp(x0, "fp") == 0);
  check (x1 == -691244055);
  check (x2 == -5836704164269698999);
  check (strcmp(x3, "en") == 0);
  check (strcmp(x4, "z") == 0);
  return -2034291514;
}

unsigned short f482(double x0, int x1, int x2, char * x3, char * x4, char * x5, long long x6, float x7)
{
  check (x0 == -0x1.784e368506c5fp+5);
  check (x1 == -699188504);
  check (x2 == -69797352);
  check (strcmp(x3, "r") == 0);
  check (strcmp(x4, "u") == 0);
  check (strcmp(x5, "") == 0);
  check (x6 == 6115974265430917039);
  check (x7 == 0x1.0dd9c6p+5F);
  return 389105058;
}

signed char f483(float x0, long long x1, double x2, double x3, double x4, double x5, char * x6, float x7, float x8)
{
  check (x0 == -0x1.90813ep-3F);
  check (x1 == -8559449919500890771);
  check (x2 == -0x1.3acaceea434p+1);
  check (x3 == 0x1.7466fde17b0e8p+5);
  check (x4 == 0x1.82dd7e05ba3f4p+5);
  check (x5 == 0x1.0c850042eaa88p+2);
  check (strcmp(x6, "") == 0);
  check (x7 == 0x1.4272f6p+5F);
  check (x8 == -0x1.164f9ap+3F);
  return -174486708;
}

void f484(float x0, float x1, long long x2, float x3, long long x4, int x5, long long x6, char * x7, float x8, int x9, int x10)
{
  check (x0 == -0x1.1115b6p+4F);
  check (x1 == 0x1.115484p+5F);
  check (x2 == 8074402528906806057);
  check (x3 == -0x1.0e6ed6p+4F);
  check (x4 == -6581396348517336836);
  check (x5 == 678693974);
  check (x6 == 5648445071552397209);
  check (strcmp(x7, "i") == 0);
  check (x8 == -0x1.11b236p+5F);
  check (x9 == -202730477);
  check (x10 == -1015740042);
}

void f485(double x0, char * x1, float x2, int x3, int x4, float x5)
{
  check (x0 == -0x1.6eac77401407fp+4);
  check (strcmp(x1, "n") == 0);
  check (x2 == -0x1.76a4bp+5F);
  check (x3 == -822569224);
  check (x4 == -1140254162);
  check (x5 == -0x1.1bd27ap+4F);
}

unsigned short f486(double x0, float x1)
{
  check (x0 == 0x1.65bf069576fa6p+5);
  check (x1 == -0x1.329b0ap+5F);
  return 428625213;
}

void f487(void)
{
}

long long f488(int x0, long long x1, long long x2, int x3, long long x4, long long x5, long long x6, char * x7, float x8, double x9)
{
  check (x0 == 1982355074);
  check (x1 == -8226104597427411864);
  check (x2 == 7212037341119110900);
  check (x3 == 1568395665);
  check (x4 == 3850483097003483709);
  check (x5 == -4729629598536269587);
  check (x6 == 1350046714922444323);
  check (strcmp(x7, "u") == 0);
  check (x8 == -0x1.ae4f68p+4F);
  check (x9 == -0x1.b678277efbf27p+4);
  return -6696833607349658218;
}

signed char f489(long long x0, float x1, char * x2, double x3, int x4, double x5, double x6, double x7, float x8, double x9, long long x10)
{
  check (x0 == -6083031235165151808);
  check (x1 == -0x1.b7c228p+2F);
  check (strcmp(x2, "") == 0);
  check (x3 == -0x1.07989ec0e1a7fp+5);
  check (x4 == -1577994914);
  check (x5 == 0x1.7d3ac10de438cp+5);
  check (x6 == -0x1.ebc09598613c3p+4);
  check (x7 == 0x1.11da48df728fp+4);
  check (x8 == -0x1.fc3e1ep+1F);
  check (x9 == 0x1.021d99365b772p+5);
  check (x10 == 1796734586872829134);
  return -521437258;
}

unsigned short f490(float x0, char * x1, char * x2, float x3)
{
  check (x0 == -0x1.39f138p+4F);
  check (strcmp(x1, "") == 0);
  check (strcmp(x2, "kq") == 0);
  check (x3 == -0x1.fc7df4p+4F);
  return -178482761;
}

void f491(int x0, char * x1, int x2)
{
  check (x0 == 598672269);
  check (strcmp(x1, "") == 0);
  check (x2 == -25494354);
}

void f492(double x0, int x1, long long x2, char * x3, long long x4)
{
  check (x0 == -0x1.3c7c776fee3b8p+2);
  check (x1 == -1571227546);
  check (x2 == -4220988618446108754);
  check (strcmp(x3, "cf") == 0);
  check (x4 == -3749192386323882200);
}

int f493(char * x0)
{
  check (strcmp(x0, "ju") == 0);
  return -1778507848;
}

double f494(double x0, char * x1, float x2)
{
  check (x0 == -0x1.c8cf83d46c1fp+2);
  check (strcmp(x1, "hk") == 0);
  check (x2 == -0x1.73b3c8p+5F);
  return 0x1.0dad368c38f6p+1;
}

void f495(char * x0, int x1, long long x2, long long x3, int x4, int x5, char * x6, char * x7, double x8)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 1537968273);
  check (x2 == -1979311235326881472);
  check (x3 == -5046356730037506026);
  check (x4 == -1941449671);
  check (x5 == -1323387536);
  check (strcmp(x6, "") == 0);
  check (strcmp(x7, "") == 0);
  check (x8 == -0x1.9b24f8b40d8c9p+4);
}

unsigned char f496(long long x0, long long x1)
{
  check (x0 == 4930723876875984894);
  check (x1 == 6728149016525499888);
  return -395594203;
}

void f497(float x0, double x1)
{
  check (x0 == 0x1.7a4754p+4F);
  check (x1 == 0x1.bdd68e06f995cp+4);
}

void f498(long long x0, double x1, long long x2, long long x3)
{
  check (x0 == 1263588789586192381);
  check (x1 == 0x1.553c44b9a3a92p+5);
  check (x2 == 7585625474220575992);
  check (x3 == 5044516665094899378);
}

short f499(int x0, char * x1, char * x2, float x3, int x4)
{
  check (x0 == -691346377);
  check (strcmp(x1, "b") == 0);
  check (strcmp(x2, "j") == 0);
  check (x3 == -0x1.f366d8p+3F);
  check (x4 == -2088607239);
  return -337018267;
}

void f500(float x0, long long x1, double x2, float x3)
{
  check (x0 == -0x1.e739eep+4F);
  check (x1 == -5978515549021103399);
  check (x2 == -0x1.a931c084d973cp+4);
  check (x3 == 0x1.e2929ep+0F);
}

void f501(float x0, double x1, long long x2)
{
  check (x0 == 0x1.dcd1fp+4F);
  check (x1 == -0x1.138c64bc879cbp+5);
  check (x2 == 6726969480207662671);
}

void f502(float x0, float x1, long long x2, long long x3, double x4)
{
  check (x0 == -0x1.cc993p-2F);
  check (x1 == -0x1.4f1e8cp+4F);
  check (x2 == -3662036530195049473);
  check (x3 == 248111488226803363);
  check (x4 == 0x1.2bfcb9e250f9cp+5);
}

char * f503(long long x0, int x1, char * x2, int x3, int x4, double x5, double x6, long long x7)
{
  check (x0 == 8620113540353252415);
  check (x1 == -359665442);
  check (strcmp(x2, "m") == 0);
  check (x3 == -813287978);
  check (x4 == -769112149);
  check (x5 == 0x1.a1320dafbc6cp+3);
  check (x6 == 0x1.d84639e17f628p+3);
  check (x7 == -964960134609094679);
  return "v";
}

short f504(char * x0, double x1, double x2, long long x3, int x4, long long x5, long long x6, float x7, double x8, int x9)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 0x1.6c77fd726d1cep+5);
  check (x2 == 0x1.671ceb71ba6bep+5);
  check (x3 == -963430962267539169);
  check (x4 == -1181088795);
  check (x5 == -5001330557312489024);
  check (x6 == 8827927699516293700);
  check (x7 == -0x1.2ec42ap+4F);
  check (x8 == 0x1.508a1e6e0dd3cp+4);
  check (x9 == 1087847233);
  return 335634360;
}

short f505(int x0, char * x1, int x2, double x3, long long x4, char * x5, int x6, int x7, char * x8, double x9, float x10)
{
  check (x0 == -1159901027);
  check (strcmp(x1, "q") == 0);
  check (x2 == 1344049556);
  check (x3 == 0x1.45a8b3b4ddcc8p+5);
  check (x4 == -2423654873993082626);
  check (strcmp(x5, "v") == 0);
  check (x6 == 1372302887);
  check (x7 == 631722107);
  check (strcmp(x8, "z") == 0);
  check (x9 == -0x1.7dbf2f2bd7c53p+5);
  check (x10 == -0x1.12fcc8p+4F);
  return -296528168;
}

signed char f506(char * x0, long long x1, int x2)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 664964448235176070);
  check (x2 == 525194230);
  return 122303801;
}

unsigned char f507(int x0, char * x1, float x2, double x3, float x4, char * x5)
{
  check (x0 == 1510460026);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.309adp+4F);
  check (x3 == 0x1.0fb80e63a9fe4p+5);
  check (x4 == -0x1.6501d2p+4F);
  check (strcmp(x5, "c") == 0);
  return -393084653;
}

void f508(int x0, long long x1, double x2, float x3, int x4, long long x5, float x6, double x7, int x8, long long x9)
{
  check (x0 == -1826718983);
  check (x1 == -6697401719643977335);
  check (x2 == 0x1.17831a688412p+1);
  check (x3 == 0x1.a1cc84p+3F);
  check (x4 == 99985050);
  check (x5 == 7913024228019345951);
  check (x6 == -0x1.ef1608p+4F);
  check (x7 == -0x1.0825b98d23579p+5);
  check (x8 == -950189906);
  check (x9 == 8377736854820771371);
}

void f509(long long x0, double x1, float x2, float x3, float x4, long long x5, float x6, char * x7)
{
  check (x0 == -2754611682361282393);
  check (x1 == -0x1.bb3f01cb3702cp+3);
  check (x2 == 0x1.45f238p+5F);
  check (x3 == 0x1.29defep+4F);
  check (x4 == -0x1.7ef622p+3F);
  check (x5 == 4750590659912102080);
  check (x6 == 0x1.73a5a8p+4F);
  check (strcmp(x7, "jn") == 0);
}

void f510(char * x0, int x1, float x2, float x3, int x4, int x5, int x6, long long x7, float x8, long long x9)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -626664832);
  check (x2 == -0x1.4f9be8p+3F);
  check (x3 == -0x1.4198ccp+5F);
  check (x4 == 919107122);
  check (x5 == -1615561359);
  check (x6 == 415547725);
  check (x7 == -7768693109037597206);
  check (x8 == -0x1.bec0d2p+2F);
  check (x9 == 2053107477993060124);
}

float f511(int x0, char * x1, long long x2, long long x3, double x4, long long x5, int x6, float x7)
{
  check (x0 == 52872569);
  check (strcmp(x1, "h") == 0);
  check (x2 == 2803430017098964970);
  check (x3 == 5387534862508499325);
  check (x4 == -0x1.75032ebd2020cp+3);
  check (x5 == 4052324620907096610);
  check (x6 == -46740261);
  check (x7 == 0x1.d37fc2p+4F);
  return -0x1.1749c2157bcc8p+5;
}

char * f512(double x0, float x1, double x2, long long x3, float x4, long long x5, float x6, float x7)
{
  check (x0 == -0x1.a0d0e7f29556p+2);
  check (x1 == -0x1.828056p+5F);
  check (x2 == 0x1.04328b8cc88d8p+2);
  check (x3 == 8286411263679033692);
  check (x4 == -0x1.0c9fa6p+5F);
  check (x5 == -6391903976554194387);
  check (x6 == 0x1.8fb7cap+1F);
  check (x7 == 0x1.619ab8p+4F);
  return "";
}

signed char f513(char * x0, int x1, int x2, char * x3, float x4, long long x5, long long x6, int x7, long long x8, int x9)
{
  check (strcmp(x0, "ma") == 0);
  check (x1 == -1014162939);
  check (x2 == 608579699);
  check (strcmp(x3, "l") == 0);
  check (x4 == 0x1.5eb4ep+4F);
  check (x5 == -8661487909786712245);
  check (x6 == -8816152257797260499);
  check (x7 == -334350926);
  check (x8 == 566652504041925224);
  check (x9 == -892712483);
  return -468433885;
}

void f514(int x0, char * x1, float x2, char * x3, char * x4, char * x5, char * x6, float x7, char * x8, float x9, int x10)
{
  check (x0 == -527582443);
  check (strcmp(x1, "v") == 0);
  check (x2 == -0x1.6ded7ap+5F);
  check (strcmp(x3, "vs") == 0);
  check (strcmp(x4, "be") == 0);
  check (strcmp(x5, "y") == 0);
  check (strcmp(x6, "") == 0);
  check (x7 == 0x1.724174p+3F);
  check (strcmp(x8, "e") == 0);
  check (x9 == -0x1.8027c8p+5F);
  check (x10 == 771880246);
}

void f515(char * x0, long long x1, double x2, long long x3, float x4)
{
  check (strcmp(x0, "c") == 0);
  check (x1 == -4907293276569942723);
  check (x2 == -0x1.736d1a6047afdp+5);
  check (x3 == -8552430054028981559);
  check (x4 == -0x1.2a5c98p+4F);
}

void f516(float x0, char * x1, char * x2, long long x3, double x4, long long x5, char * x6)
{
  check (x0 == 0x1.8dc8b6p+5F);
  check (strcmp(x1, "") == 0);
  check (strcmp(x2, "k") == 0);
  check (x3 == -3230088412229579029);
  check (x4 == -0x1.5565e763a4208p+3);
  check (x5 == 4317372558597149592);
  check (strcmp(x6, "tv") == 0);
}

int f517(char * x0, int x1, float x2, float x3, double x4, float x5, char * x6, int x7)
{
  check (strcmp(x0, "m") == 0);
  check (x1 == -461279435);
  check (x2 == -0x1.33a9cp+5F);
  check (x3 == -0x1.46dd18p+5F);
  check (x4 == 0x1.0e0f802577518p+5);
  check (x5 == 0x1.6eb3fcp+5F);
  check (strcmp(x6, "n") == 0);
  check (x7 == -1796721022);
  return -1252582623;
}

void f518(float x0)
{
  check (x0 == 0x1.87ebf6p+4F);
}

long long f519(float x0, long long x1, char * x2, long long x3, long long x4)
{
  check (x0 == 0x1.52246p+3F);
  check (x1 == 2039224081777953098);
  check (strcmp(x2, "dn") == 0);
  check (x3 == -4975445541805959130);
  check (x4 == -4682581940285213606);
  return -6024073579480704461;
}

void f520(int x0)
{
  check (x0 == 594117695);
}

void f521(float x0, char * x1, float x2, float x3, int x4, int x5, long long x6, int x7, int x8)
{
  check (x0 == 0x1.511b38p+4F);
  check (strcmp(x1, "bb") == 0);
  check (x2 == -0x1.321b14p+4F);
  check (x3 == 0x1.7fb062p+5F);
  check (x4 == 756390340);
  check (x5 == 310222479);
  check (x6 == 4944139713862884875);
  check (x7 == -358113743);
  check (x8 == 853787389);
}

void f522(double x0, int x1, int x2, float x3, long long x4, int x5)
{
  check (x0 == 0x1.73920278b74bcp+4);
  check (x1 == -2022097331);
  check (x2 == 1607956844);
  check (x3 == -0x1.5e81a4p+4F);
  check (x4 == -7974028319228599482);
  check (x5 == 1013553401);
}

void f523(float x0, long long x1, long long x2, long long x3, int x4, char * x5, long long x6, char * x7, double x8, float x9, long long x10)
{
  check (x0 == -0x1.0638ap+5F);
  check (x1 == 8867666783332234338);
  check (x2 == -1058549665537082104);
  check (x3 == -2494377479410752542);
  check (x4 == 52272281);
  check (strcmp(x5, "j") == 0);
  check (x6 == -3883739186517850515);
  check (strcmp(x7, "gv") == 0);
  check (x8 == -0x1.21b37c1d22c88p+4);
  check (x9 == 0x1.90ad78p+2F);
  check (x10 == 3253394525880958574);
}

void f524(float x0, long long x1, int x2, long long x3, double x4, float x5, float x6, int x7, float x8, int x9, float x10)
{
  check (x0 == 0x1.80601ep+0F);
  check (x1 == -4471488142621784991);
  check (x2 == -1985133508);
  check (x3 == 1525173756882330153);
  check (x4 == 0x1.6c5aa050b28c8p+2);
  check (x5 == -0x1.865974p+5F);
  check (x6 == 0x1.663068p+4F);
  check (x7 == -1315512781);
  check (x8 == -0x1.681664p+4F);
  check (x9 == 20507477);
  check (x10 == -0x1.ec3c38p+2F);
}

void f525(float x0, float x1, char * x2, int x3, float x4, double x5, char * x6, long long x7, double x8, long long x9, float x10)
{
  check (x0 == 0x1.0f8c18p+3F);
  check (x1 == 0x1.fbf942p+4F);
  check (strcmp(x2, "tm") == 0);
  check (x3 == 1619776955);
  check (x4 == -0x1.216858p+5F);
  check (x5 == 0x1.34172ce431154p+3);
  check (strcmp(x6, "qm") == 0);
  check (x7 == 4977780903326251522);
  check (x8 == 0x1.a417f499e8af4p+4);
  check (x9 == 2849690230756390761);
  check (x10 == -0x1.1ba6fcp+2F);
}

unsigned char f526(float x0, long long x1)
{
  check (x0 == -0x1.d3499ap+4F);
  check (x1 == -727368709358862763);
  return -147835319;
}

void f527(double x0, int x1, float x2)
{
  check (x0 == 0x1.5c31655620ef8p+4);
  check (x1 == 1733646970);
  check (x2 == -0x1.192b54p+5F);
}

void f528(int x0, long long x1, float x2, int x3, int x4, int x5, char * x6, double x7, double x8, long long x9)
{
  check (x0 == 1051327808);
  check (x1 == 8896495890301113775);
  check (x2 == 0x1.27336p+5F);
  check (x3 == -1109099889);
  check (x4 == -253384857);
  check (x5 == -1203809056);
  check (strcmp(x6, "") == 0);
  check (x7 == -0x1.234043f613459p+5);
  check (x8 == 0x1.7213f43192a2p+1);
  check (x9 == 7517532879021348602);
}

void f529(char * x0, double x1, int x2, int x3)
{
  check (strcmp(x0, "lg") == 0);
  check (x1 == -0x1.1e9697847b54p+5);
  check (x2 == 248067405);
  check (x3 == 1529258124);
}

char * f530(long long x0, int x1, float x2, float x3, char * x4, char * x5)
{
  check (x0 == -8323744167675232247);
  check (x1 == 3539557);
  check (x2 == 0x1.2b898cp+4F);
  check (x3 == -0x1.c54a56p+4F);
  check (strcmp(x4, "") == 0);
  check (strcmp(x5, "") == 0);
  return "vs";
}

void f531(float x0, float x1, double x2)
{
  check (x0 == -0x1.897ec4p+5F);
  check (x1 == 0x1.6608ccp+5F);
  check (x2 == -0x1.77d83fa40a0c2p+5);
}

unsigned char f532(double x0, float x1, int x2, long long x3, char * x4)
{
  check (x0 == -0x1.6b7b39a785432p+5);
  check (x1 == -0x1.951856p+4F);
  check (x2 == 61376882);
  check (x3 == -7129689785282767157);
  check (strcmp(x4, "t") == 0);
  return -312375806;
}

short f533(char * x0, double x1, float x2, float x3)
{
  check (strcmp(x0, "c") == 0);
  check (x1 == -0x1.6aa11f911e2f8p+5);
  check (x2 == 0x1.361012p+3F);
  check (x3 == 0x1.0d8d9ap+4F);
  return -293264755;
}

void f534(int x0, long long x1, int x2, float x3, double x4)
{
  check (x0 == -1620928346);
  check (x1 == 7524473795724813784);
  check (x2 == -839017892);
  check (x3 == -0x1.4bdc34p+5F);
  check (x4 == -0x1.3ed35756a7bc6p+5);
}

void f535(double x0, int x1, float x2)
{
  check (x0 == -0x1.773e1c7e18283p+5);
  check (x1 == -473758487);
  check (x2 == -0x1.3a0a18p+3F);
}

void f536(long long x0)
{
  check (x0 == -3689935021998155578);
}

signed char f537(long long x0, float x1, char * x2, long long x3, float x4)
{
  check (x0 == 1398323741464381415);
  check (x1 == -0x1.843584p+4F);
  check (strcmp(x2, "qg") == 0);
  check (x3 == -8605761392389449299);
  check (x4 == -0x1.625724p+4F);
  return -173789152;
}

void f538(long long x0, long long x1, int x2, int x3, char * x4, long long x5, int x6, char * x7, long long x8, double x9, double x10)
{
  check (x0 == -1061043664957308148);
  check (x1 == -5188058153224787100);
  check (x2 == -955839746);
  check (x3 == -1500036888);
  check (strcmp(x4, "of") == 0);
  check (x5 == 1224517765054574935);
  check (x6 == -1440297770);
  check (strcmp(x7, "zk") == 0);
  check (x8 == 858960512713830799);
  check (x9 == -0x1.1d107faf04177p+5);
  check (x10 == 0x1.66da11bea89bp+4);
}

void f539(void)
{
}

float f540(float x0, float x1, double x2, char * x3, int x4, double x5, double x6, double x7, double x8, long long x9)
{
  check (x0 == -0x1.d97a86p+4F);
  check (x1 == 0x1.93382cp+0F);
  check (x2 == -0x1.869e2f82d8e9p+1);
  check (strcmp(x3, "cf") == 0);
  check (x4 == 1939102842);
  check (x5 == 0x1.259bdb9007ed8p+3);
  check (x6 == 0x1.4f16c4c7cac12p+5);
  check (x7 == 0x1.53aacbc09c0d8p+5);
  check (x8 == 0x1.3e81bddde188cp+3);
  check (x9 == 1737315470974778600);
  return -0x1.ae2e90395eff8p+2;
}

signed char f541(long long x0, int x1, float x2, float x3, long long x4, double x5, long long x6, float x7, long long x8, long long x9, int x10)
{
  check (x0 == -6107247553883553599);
  check (x1 == -1187430870);
  check (x2 == 0x1.82b27ap+2F);
  check (x3 == 0x1.25635ep+5F);
  check (x4 == 3584888379560353437);
  check (x5 == 0x1.f9a52049c5ddcp+4);
  check (x6 == -7271757314634038136);
  check (x7 == 0x1.42af5ap+5F);
  check (x8 == -5259724462422026812);
  check (x9 == 1993371616088053228);
  check (x10 == -268846204);
  return -465241074;
}

unsigned char f542(void)
{
  return 297945025;
}

double f543(long long x0, double x1, double x2, double x3, long long x4)
{
  check (x0 == 6092416632768946379);
  check (x1 == 0x1.7d1c1c9be7a4cp+4);
  check (x2 == 0x1.79173f8c9ea24p+3);
  check (x3 == 0x1.0b9667c4f4a2ep+5);
  check (x4 == -7028803195288194686);
  return -0x1.7dc83d2aa4a8ap+5;
}

void f544(float x0, double x1, int x2, int x3, char * x4)
{
  check (x0 == -0x1.7a446cp+2F);
  check (x1 == -0x1.0120d2028ad2cp+4);
  check (x2 == 1991695855);
  check (x3 == 2022210740);
  check (strcmp(x4, "cl") == 0);
}

void f545(float x0, int x1, int x2, int x3)
{
  check (x0 == -0x1.fd32cap-2F);
  check (x1 == 701263490);
  check (x2 == -1193353038);
  check (x3 == -754944049);
}

double f546(long long x0, double x1, double x2, float x3, float x4, long long x5, long long x6, char * x7, double x8)
{
  check (x0 == -7353881956544791761);
  check (x1 == -0x1.84e2465fe8d32p+4);
  check (x2 == -0x1.0d5fab396fe5ap+5);
  check (x3 == 0x1.2bd858p+5F);
  check (x4 == -0x1.73daeap+5F);
  check (x5 == -1136559164783185314);
  check (x6 == -101686533257630134);
  check (strcmp(x7, "") == 0);
  check (x8 == 0x1.7c11c5f4d302p+4);
  return 0x1.7eef73f35cbe4p+3;
}

short f547(float x0, float x1)
{
  check (x0 == -0x1.f9465ep+4F);
  check (x1 == 0x1.2f7a22p+5F);
  return 314796330;
}

void f548(float x0, char * x1, float x2, char * x3, long long x4, double x5, float x6, char * x7, int x8)
{
  check (x0 == 0x1.8d69ap-6F);
  check (strcmp(x1, "us") == 0);
  check (x2 == -0x1.65dbap+4F);
  check (strcmp(x3, "c") == 0);
  check (x4 == -966813187099612790);
  check (x5 == -0x1.796bd3b1c029ep+5);
  check (x6 == 0x1.009676p+5F);
  check (strcmp(x7, "") == 0);
  check (x8 == -2101710871);
}

void f549(char * x0, float x1, float x2, double x3, char * x4, long long x5, char * x6, long long x7, double x8, double x9)
{
  check (strcmp(x0, "j") == 0);
  check (x1 == 0x1.04b72p+5F);
  check (x2 == -0x1.076872p-1F);
  check (x3 == 0x1.30fb1e0389b8ep+5);
  check (strcmp(x4, "") == 0);
  check (x5 == 3416104647319543681);
  check (strcmp(x6, "hy") == 0);
  check (x7 == 6206777574884090205);
  check (x8 == 0x1.43645f4ffc4a8p+2);
  check (x9 == -0x1.f7c14a905e08p+3);
}

void f550(double x0, int x1, long long x2, char * x3)
{
  check (x0 == -0x1.60dfc4b265e94p+3);
  check (x1 == 1329043803);
  check (x2 == 3584683022813771067);
  check (strcmp(x3, "") == 0);
}

void f551(int x0, double x1, char * x2, int x3, float x4, int x5, int x6, double x7, int x8, double x9)
{
  check (x0 == -248692641);
  check (x1 == 0x1.23bc0a350500cp+5);
  check (strcmp(x2, "td") == 0);
  check (x3 == -2065597432);
  check (x4 == -0x1.6a8c88p+4F);
  check (x5 == -123928978);
  check (x6 == 1201511381);
  check (x7 == 0x1.daddecac8b424p+4);
  check (x8 == 976121653);
  check (x9 == 0x1.db202bd19605p+1);
}

void f552(char * x0, float x1, long long x2, float x3, float x4, long long x5)
{
  check (strcmp(x0, "fp") == 0);
  check (x1 == -0x1.c3ebdep+3F);
  check (x2 == -1065251822184682022);
  check (x3 == 0x1.1fd184p+0F);
  check (x4 == -0x1.362e6ap+5F);
  check (x5 == 595987680625648363);
}

void f553(void)
{
}

char * f554(int x0, float x1)
{
  check (x0 == 328173379);
  check (x1 == 0x1.53db42p+5F);
  return "s";
}

void f555(double x0)
{
  check (x0 == -0x1.91e8eff92cc58p+3);
}

void f556(float x0, int x1, long long x2, char * x3, char * x4, double x5, int x6, int x7, char * x8)
{
  check (x0 == -0x1.8a2596p+5F);
  check (x1 == 1791038992);
  check (x2 == -1801134832682844197);
  check (strcmp(x3, "l") == 0);
  check (strcmp(x4, "my") == 0);
  check (x5 == 0x1.147c840300cd8p+2);
  check (x6 == -1836854489);
  check (x7 == -80879754);
  check (strcmp(x8, "") == 0);
}

short f557(double x0, float x1, char * x2, long long x3, char * x4, char * x5, float x6, int x7, float x8)
{
  check (x0 == -0x1.6a1ee34a1e40bp+4);
  check (x1 == 0x1.7aefaep+5F);
  check (strcmp(x2, "wy") == 0);
  check (x3 == 7108726636692390957);
  check (strcmp(x4, "") == 0);
  check (strcmp(x5, "w") == 0);
  check (x6 == 0x1.f9915cp+2F);
  check (x7 == 615671392);
  check (x8 == 0x1.7bd484p+2F);
  return -113271508;
}

void f558(double x0, char * x1, char * x2, int x3, int x4, long long x5, double x6, long long x7, long long x8)
{
  check (x0 == 0x1.cc535593a37p-1);
  check (strcmp(x1, "") == 0);
  check (strcmp(x2, "ju") == 0);
  check (x3 == -855497432);
  check (x4 == -526359235);
  check (x5 == 7033283413284996910);
  check (x6 == 0x1.d798d4f755d6cp+4);
  check (x7 == -669039527848643395);
  check (x8 == -853485197148289335);
}

long long f559(int x0, int x1, float x2, int x3, double x4, int x5, float x6, int x7)
{
  check (x0 == 1876995153);
  check (x1 == 478433905);
  check (x2 == -0x1.412a48p+4F);
  check (x3 == 114096267);
  check (x4 == -0x1.8412eadf5d43p+1);
  check (x5 == 918512718);
  check (x6 == 0x1.5babfcp+5F);
  check (x7 == -561510178);
  return 5018512878203312559;
}

void f560(float x0, double x1, int x2, float x3, char * x4, char * x5, long long x6, int x7)
{
  check (x0 == -0x1.d737d8p+4F);
  check (x1 == -0x1.83654aaec03edp+4);
  check (x2 == 586238580);
  check (x3 == -0x1.57693ap+3F);
  check (strcmp(x4, "") == 0);
  check (strcmp(x5, "mf") == 0);
  check (x6 == -7937690199877501642);
  check (x7 == -1367782567);
}

double f561(int x0, float x1, double x2, int x3, float x4, int x5, double x6, double x7, double x8, long long x9, long long x10)
{
  check (x0 == -13164507);
  check (x1 == -0x1.fc9ecep+3F);
  check (x2 == -0x1.d6d6616c19045p+4);
  check (x3 == -1989578044);
  check (x4 == 0x1.7fd41ap+4F);
  check (x5 == 1291740401);
  check (x6 == 0x1.0e10e51c40d3p+3);
  check (x7 == -0x1.6c0a15ba4a24cp+4);
  check (x8 == 0x1.80ab6e5cb4024p+5);
  check (x9 == 6006767172140742084);
  check (x10 == -7933281861204681482);
  return 0x1.9317c8e4d4194p+4;
}

void f562(long long x0, long long x1, float x2, double x3, float x4, long long x5)
{
  check (x0 == 8428144610430738939);
  check (x1 == 4262459113639870837);
  check (x2 == 0x1.143d38p+5F);
  check (x3 == 0x1.899e209224fcep+5);
  check (x4 == 0x1.28e196p+1F);
  check (x5 == 7311003213175721503);
}

signed char f563(int x0, char * x1)
{
  check (x0 == 1234309900);
  check (strcmp(x1, "") == 0);
  return -296251468;
}

void f564(double x0, float x1, double x2, long long x3, double x4, long long x5, float x6, char * x7, char * x8)
{
  check (x0 == -0x1.fec47073dcbep+4);
  check (x1 == 0x1.04e8a6p+5F);
  check (x2 == -0x1.dcb35aeae477ap+4);
  check (x3 == 2811174495189676234);
  check (x4 == 0x1.4ffbb48158bccp+4);
  check (x5 == 64359326072775618);
  check (x6 == -0x1.7e7694p+1F);
  check (strcmp(x7, "sn") == 0);
  check (strcmp(x8, "d") == 0);
}

void f565(double x0, int x1, int x2, long long x3, char * x4, int x5, double x6, int x7)
{
  check (x0 == 0x1.70ae74466f658p+3);
  check (x1 == 368277356);
  check (x2 == 289923933);
  check (x3 == 6106546032584976700);
  check (strcmp(x4, "k") == 0);
  check (x5 == 1374300560);
  check (x6 == -0x1.352e1c4cbcd4ep+5);
  check (x7 == -240799484);
}

unsigned char f566(void)
{
  return 354526270;
}

void f567(long long x0, char * x1, float x2, double x3, long long x4, char * x5, float x6, float x7, double x8, float x9)
{
  check (x0 == 6978604483068644444);
  check (strcmp(x1, "") == 0);
  check (x2 == -0x1.5c7286p+5F);
  check (x3 == 0x1.62912803413b8p+3);
  check (x4 == 6704474645156904863);
  check (strcmp(x5, "js") == 0);
  check (x6 == -0x1.f32f48p+4F);
  check (x7 == 0x1.d3a25ap+2F);
  check (x8 == 0x1.f6734dcb7bce4p+4);
  check (x9 == -0x1.655396p+5F);
}

int f568(void)
{
  return -136765204;
}

signed char f569(float x0)
{
  check (x0 == 0x1.4a00f8p+5F);
  return 435299177;
}

void f570(void)
{
}

signed char f571(float x0, char * x1, long long x2, char * x3)
{
  check (x0 == -0x1.da2abep+3F);
  check (strcmp(x1, "j") == 0);
  check (x2 == -2387678148920063269);
  check (strcmp(x3, "") == 0);
  return 7824701;
}

double f572(float x0, float x1, float x2, float x3, float x4)
{
  check (x0 == 0x1.cdecbap+4F);
  check (x1 == -0x1.6ef1bap+4F);
  check (x2 == 0x1.efdbf8p+2F);
  check (x3 == 0x1.65ed6p+5F);
  check (x4 == -0x1.5a8ba8p+5F);
  return 0x1.8859b20a17efp+2;
}

char * f573(double x0, char * x1, float x2, float x3, double x4, int x5)
{
  check (x0 == 0x1.96ff714565198p+4);
  check (strcmp(x1, "u") == 0);
  check (x2 == 0x1.5461cp+5F);
  check (x3 == -0x1.05e2fp+5F);
  check (x4 == -0x1.cb49d5c3887bbp+4);
  check (x5 == 2102608899);
  return "";
}

signed char f574(long long x0, double x1, double x2, int x3, int x4)
{
  check (x0 == -6487226970465101703);
  check (x1 == -0x1.6229e7b7353fcp+3);
  check (x2 == 0x1.16ef47c97690ap+5);
  check (x3 == 2067529404);
  check (x4 == -1929476764);
  return -185440087;
}

short f575(int x0, float x1, char * x2, float x3, double x4, int x5, float x6, float x7, long long x8)
{
  check (x0 == -1188818329);
  check (x1 == 0x1.bbe65ap+3F);
  check (strcmp(x2, "lo") == 0);
  check (x3 == 0x1.22d9bp+4F);
  check (x4 == 0x1.929e5fe09c308p+4);
  check (x5 == -1943870514);
  check (x6 == -0x1.29fdap+2F);
  check (x7 == 0x1.65ea08p+1F);
  check (x8 == -8640028402293863422);
  return 356572429;
}

unsigned short f576(float x0, long long x1, double x2, char * x3, float x4, long long x5, int x6, long long x7, char * x8, float x9)
{
  check (x0 == -0x1.6236ccp+3F);
  check (x1 == -4322798192665085918);
  check (x2 == -0x1.323d5200d129dp+4);
  check (strcmp(x3, "pb") == 0);
  check (x4 == -0x1.a01902p+2F);
  check (x5 == -8528865572715881798);
  check (x6 == 2038727821);
  check (x7 == -8457734237494366509);
  check (strcmp(x8, "cq") == 0);
  check (x9 == 0x1.fd1466p+4F);
  return 367503100;
}

void f577(double x0, int x1, char * x2, double x3, double x4, float x5, float x6, char * x7, float x8, double x9, char * x10)
{
  check (x0 == -0x1.b5e1913f93701p+4);
  check (x1 == -671370294);
  check (strcmp(x2, "io") == 0);
  check (x3 == -0x1.cb0422ea7c4p-1);
  check (x4 == 0x1.45de6753f56p-1);
  check (x5 == 0x1.d7977cp+4F);
  check (x6 == -0x1.b4507ep+3F);
  check (strcmp(x7, "d") == 0);
  check (x8 == -0x1.b6e0ep+4F);
  check (x9 == 0x1.b784a6393bf88p+3);
  check (strcmp(x10, "np") == 0);
}

int f578(float x0, long long x1, long long x2, char * x3, long long x4, long long x5, float x6, double x7, int x8, long long x9)
{
  check (x0 == 0x1.9cbdccp+2F);
  check (x1 == -4469734996351914479);
  check (x2 == 5913172784525976162);
  check (strcmp(x3, "ac") == 0);
  check (x4 == -497964490111820241);
  check (x5 == 5780156002101510432);
  check (x6 == 0x1.80c4e2p+5F);
  check (x7 == 0x1.5fe6a93905708p+2);
  check (x8 == 557174);
  check (x9 == 6546294627533504707);
  return -90914645;
}

char * f579(char * x0, char * x1)
{
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "") == 0);
  return "";
}

void f580(double x0, double x1, int x2, double x3, double x4, double x5, long long x6, float x7, char * x8, long long x9, int x10)
{
  check (x0 == -0x1.479997c67fb39p+4);
  check (x1 == 0x1.74cc8e36112b8p+5);
  check (x2 == -1178665603);
  check (x3 == -0x1.6f3fbbbae3de5p+4);
  check (x4 == -0x1.713d06a6d1057p+5);
  check (x5 == -0x1.6d1871e7d3ca2p+5);
  check (x6 == 3522032378087610617);
  check (x7 == 0x1.2bd3eep+5F);
  check (strcmp(x8, "uk") == 0);
  check (x9 == -7055732739573761145);
  check (x10 == 804809727);
}

void f581(char * x0, double x1, char * x2, float x3, float x4, long long x5, long long x6, float x7, long long x8, char * x9)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -0x1.cf73910c23888p+2);
  check (strcmp(x2, "e") == 0);
  check (x3 == 0x1.e0214cp+4F);
  check (x4 == -0x1.3afba8p+5F);
  check (x5 == 2899113414305591902);
  check (x6 == -244890149434916113);
  check (x7 == -0x1.02a792p+5F);
  check (x8 == -8105517686113547038);
  check (strcmp(x9, "") == 0);
}

float f582(float x0, char * x1, double x2, double x3, int x4, char * x5, char * x6, char * x7, int x8)
{
  check (x0 == -0x1.317378p+4F);
  check (strcmp(x1, "h") == 0);
  check (x2 == 0x1.89eb0392e3dap+4);
  check (x3 == -0x1.b040d826ae194p+3);
  check (x4 == 2000264774);
  check (strcmp(x5, "r") == 0);
  check (strcmp(x6, "") == 0);
  check (strcmp(x7, "dl") == 0);
  check (x8 == 954296379);
  return 0x1.529081b4d3f1p+4;
}

void f583(double x0, char * x1, int x2, long long x3, char * x4, char * x5, int x6)
{
  check (x0 == 0x1.1ce26aa8a328p+2);
  check (strcmp(x1, "") == 0);
  check (x2 == 1000887201);
  check (x3 == -5415049164684641419);
  check (strcmp(x4, "h") == 0);
  check (strcmp(x5, "e") == 0);
  check (x6 == 222337941);
}

short f584(double x0, int x1, char * x2, char * x3)
{
  check (x0 == 0x1.043ebec3ea45p+4);
  check (x1 == -639424147);
  check (strcmp(x2, "n") == 0);
  check (strcmp(x3, "u") == 0);
  return 39520742;
}

void f585(char * x0, double x1, long long x2, int x3, long long x4)
{
  check (strcmp(x0, "hz") == 0);
  check (x1 == 0x1.1dab10a8a933cp+5);
  check (x2 == 3144701184001031377);
  check (x3 == -179494216);
  check (x4 == 1019342578353337666);
}

unsigned char f586(float x0, float x1)
{
  check (x0 == -0x1.86d7ap+3F);
  check (x1 == 0x1.29f438p+4F);
  return 139545294;
}

float f587(float x0, double x1, int x2, char * x3, int x4, long long x5)
{
  check (x0 == -0x1.8cac3ap+5F);
  check (x1 == 0x1.ffe8c7e40d14p+3);
  check (x2 == -1822832947);
  check (strcmp(x3, "iy") == 0);
  check (x4 == 1383654419);
  check (x5 == -6009196197034523138);
  return 0x1.54fd15612afe8p+5;
}

unsigned char f588(long long x0, float x1, char * x2, float x3, long long x4, float x5, long long x6, double x7, float x8)
{
  check (x0 == -672066508484807980);
  check (x1 == 0x1.0d97f8p+5F);
  check (strcmp(x2, "e") == 0);
  check (x3 == 0x1.88904ap+5F);
  check (x4 == -3702065995274095582);
  check (x5 == 0x1.f97e98p+1F);
  check (x6 == -4546257682687061361);
  check (x7 == -0x1.315b6e33a907p+2);
  check (x8 == 0x1.54046p+4F);
  return -28112979;
}

void f589(void)
{
}

void f590(int x0, long long x1, float x2, float x3, double x4, char * x5, int x6, char * x7, double x8)
{
  check (x0 == 1647446815);
  check (x1 == -6193541702350543972);
  check (x2 == -0x1.c26ccep+0F);
  check (x3 == -0x1.27c50cp+5F);
  check (x4 == 0x1.5705c9c32577p+3);
  check (strcmp(x5, "nc") == 0);
  check (x6 == 1396577773);
  check (strcmp(x7, "dz") == 0);
  check (x8 == -0x1.2603da5fbc78cp+3);
}

void f591(double x0, char * x1)
{
  check (x0 == -0x1.47ef58393593p+3);
  check (strcmp(x1, "nj") == 0);
}

signed char f592(float x0, long long x1, int x2, double x3, double x4, int x5, float x6, double x7, double x8, char * x9)
{
  check (x0 == 0x1.e1782ap+4F);
  check (x1 == -8636781894588509441);
  check (x2 == 2080628675);
  check (x3 == 0x1.0c83ea44ef2ccp+3);
  check (x4 == -0x1.4ecadd98eed12p+4);
  check (x5 == 1061570977);
  check (x6 == -0x1.af95c6p+4F);
  check (x7 == -0x1.217c61238a4ep+0);
  check (x8 == 0x1.8c86ba8e0da84p+4);
  check (strcmp(x9, "mk") == 0);
  return 465546976;
}

void f593(int x0, int x1, float x2, float x3, long long x4, float x5, char * x6, long long x7, char * x8)
{
  check (x0 == 1223263787);
  check (x1 == -522320639);
  check (x2 == -0x1.5a519ep+5F);
  check (x3 == 0x1.852ac8p+5F);
  check (x4 == -6679959592138048818);
  check (x5 == -0x1.8fd01ep+2F);
  check (strcmp(x6, "o") == 0);
  check (x7 == -6580894557441556500);
  check (strcmp(x8, "") == 0);
}

unsigned short f594(char * x0, int x1, char * x2, char * x3)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -36754431);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "kt") == 0);
  return 271549481;
}

char * f595(int x0, long long x1, float x2, long long x3, long long x4, long long x5)
{
  check (x0 == 20689923);
  check (x1 == -6793204995839088479);
  check (x2 == 0x1.b89c22p+2F);
  check (x3 == 1823197732795040851);
  check (x4 == -5342623837261931317);
  check (x5 == -3179585446669022524);
  return "ak";
}

float f596(int x0)
{
  check (x0 == 661188811);
  return 0x1.4a84bae08d14p+2;
}

short f597(char * x0, int x1, float x2, char * x3, char * x4, float x5, int x6)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 715241575);
  check (x2 == -0x1.c94046p+3F);
  check (strcmp(x3, "") == 0);
  check (strcmp(x4, "") == 0);
  check (x5 == 0x1.8c0a1ep+5F);
  check (x6 == 1147229647);
  return -495744477;
}

double f598(float x0, long long x1, float x2, float x3, int x4, double x5, double x6, int x7)
{
  check (x0 == 0x1.bb577cp+4F);
  check (x1 == 5804960579956464227);
  check (x2 == 0x1.7cd214p+4F);
  check (x3 == -0x1.ba4f64p+4F);
  check (x4 == 283919166);
  check (x5 == -0x1.c48b316dcfd53p+4);
  check (x6 == 0x1.31db3f1306ae4p+4);
  check (x7 == 1024358491);
  return 0x1.0deabbef9a76ep+5;
}

void f599(char * x0)
{
  check (strcmp(x0, "") == 0);
}

int f600(char * x0, double x1, double x2, double x3, char * x4, int x5, double x6)
{
  check (strcmp(x0, "g") == 0);
  check (x1 == -0x1.727c85f966d58p+3);
  check (x2 == -0x1.745dc01edf28bp+4);
  check (x3 == -0x1.405908500cbcbp+5);
  check (strcmp(x4, "ge") == 0);
  check (x5 == 428387906);
  check (x6 == -0x1.19f194a74c1fep+5);
  return 2108828258;
}

int f601(double x0)
{
  check (x0 == 0x1.22175248e3aacp+5);
  return -1994242441;
}

long long f602(long long x0, double x1, char * x2)
{
  check (x0 == -4651413786473581743);
  check (x1 == -0x1.2b0f4e197b92ep+5);
  check (strcmp(x2, "") == 0);
  return 6979294995977466608;
}

void f603(float x0, double x1, double x2, float x3, long long x4, double x5, float x6, int x7, float x8)
{
  check (x0 == 0x1.4b506ap+5F);
  check (x1 == 0x1.58f4e554576fp+4);
  check (x2 == 0x1.5b9fdefbb0b98p+5);
  check (x3 == 0x1.90c2dcp+3F);
  check (x4 == 6725733412238426186);
  check (x5 == -0x1.33a3529057478p+2);
  check (x6 == 0x1.1d79ecp+5F);
  check (x7 == 383753980);
  check (x8 == -0x1.de2b7cp+4F);
}

void f604(double x0, int x1, int x2)
{
  check (x0 == -0x1.d08f5455b12p-4);
  check (x1 == 441072712);
  check (x2 == 856357263);
}

void f605(char * x0, int x1, float x2, double x3, long long x4, char * x5, long long x6, long long x7, long long x8, int x9, long long x10)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -250837378);
  check (x2 == -0x1.8358c2p+5F);
  check (x3 == -0x1.58e8b4ca6726bp+5);
  check (x4 == 4123087585576314030);
  check (strcmp(x5, "") == 0);
  check (x6 == -7607916146038228202);
  check (x7 == -6771824141246043025);
  check (x8 == -8754731885722361916);
  check (x9 == -1875098857);
  check (x10 == 8472638601732504315);
}

float f606(float x0, char * x1, long long x2, int x3, double x4, double x5, char * x6, char * x7, long long x8)
{
  check (x0 == -0x1.576f68p+3F);
  check (strcmp(x1, "hg") == 0);
  check (x2 == -1271933644624608232);
  check (x3 == -355198478);
  check (x4 == 0x1.a6df71722fcfcp+3);
  check (x5 == -0x1.e82ad9982be3p+3);
  check (strcmp(x6, "") == 0);
  check (strcmp(x7, "a") == 0);
  check (x8 == 5140410438253330899);
  return 0x1.581676a73f13cp+4;
}

unsigned short f607(double x0, int x1, float x2, long long x3, float x4, float x5, long long x6, float x7, long long x8)
{
  check (x0 == -0x1.09e30bbd6916p+3);
  check (x1 == -1054843870);
  check (x2 == 0x1.5e26aep+5F);
  check (x3 == 4372544526439175886);
  check (x4 == -0x1.ba267ap+2F);
  check (x5 == -0x1.e7a2e6p+4F);
  check (x6 == 6145434359693148261);
  check (x7 == -0x1.0a9886p+5F);
  check (x8 == -7073683458416284407);
  return 244707090;
}

void f608(double x0, double x1, long long x2, char * x3, double x4, int x5)
{
  check (x0 == -0x1.43946451b7cbbp+5);
  check (x1 == 0x1.df69f42b39f8cp+4);
  check (x2 == 7451405530300462992);
  check (strcmp(x3, "un") == 0);
  check (x4 == -0x1.5ec4aee59670cp+4);
  check (x5 == -686638696);
}

void f609(double x0, long long x1, int x2, double x3, char * x4)
{
  check (x0 == 0x1.4dd2a41b35a9p+4);
  check (x1 == -6314838181792323321);
  check (x2 == -365489945);
  check (x3 == -0x1.22a29edc406cp+4);
  check (strcmp(x4, "") == 0);
}

void f610(int x0, char * x1, char * x2, long long x3, int x4, float x5, float x6, int x7, double x8)
{
  check (x0 == 1011388350);
  check (strcmp(x1, "ve") == 0);
  check (strcmp(x2, "jw") == 0);
  check (x3 == 3160242178770228362);
  check (x4 == -1166505584);
  check (x5 == -0x1.e4920ep+3F);
  check (x6 == -0x1.04d59ep+2F);
  check (x7 == -234701678);
  check (x8 == -0x1.2679a90ce906cp+3);
}

char * f611(float x0, long long x1, double x2, char * x3, long long x4, char * x5)
{
  check (x0 == -0x1.e87b4p-2F);
  check (x1 == 6444370021550533112);
  check (x2 == -0x1.85d80fdf6983ap+5);
  check (strcmp(x3, "j") == 0);
  check (x4 == -1843885667625270636);
  check (strcmp(x5, "ap") == 0);
  return "";
}

char * f612(double x0, double x1, char * x2, int x3, double x4, long long x5, char * x6)
{
  check (x0 == 0x1.a6d211b16e26cp+4);
  check (x1 == -0x1.5761b0314aafap+5);
  check (strcmp(x2, "c") == 0);
  check (x3 == -1680481053);
  check (x4 == 0x1.1318b380889d8p+3);
  check (x5 == 3373796530957811749);
  check (strcmp(x6, "") == 0);
  return "";
}

float f613(double x0, double x1, float x2, double x3, char * x4)
{
  check (x0 == 0x1.6d5a2f4eb11fp+4);
  check (x1 == -0x1.e96d9e0608ebp+2);
  check (x2 == 0x1.33af72p+5F);
  check (x3 == -0x1.80693308cf091p+5);
  check (strcmp(x4, "fe") == 0);
  return -0x1.04cac1a01c298p+3;
}

void f614(int x0, long long x1, long long x2, int x3, char * x4, char * x5, char * x6)
{
  check (x0 == -2146486795);
  check (x1 == 1326287294608105708);
  check (x2 == 1657842945390348681);
  check (x3 == -1984348035);
  check (strcmp(x4, "lw") == 0);
  check (strcmp(x5, "") == 0);
  check (strcmp(x6, "r") == 0);
}

long long f615(int x0, double x1, char * x2, long long x3, int x4, char * x5, long long x6, char * x7, char * x8, char * x9)
{
  check (x0 == 691077784);
  check (x1 == 0x1.c090ccaf241e8p+3);
  check (strcmp(x2, "") == 0);
  check (x3 == 2160425362983490652);
  check (x4 == 100560592);
  check (strcmp(x5, "nj") == 0);
  check (x6 == -3433288070052020237);
  check (strcmp(x7, "") == 0);
  check (strcmp(x8, "") == 0);
  check (strcmp(x9, "h") == 0);
  return 4985806275768597288;
}

void f616(long long x0, int x1, char * x2, char * x3, long long x4, char * x5, long long x6, int x7)
{
  check (x0 == 2737871326558314550);
  check (x1 == 663341417);
  check (strcmp(x2, "l") == 0);
  check (strcmp(x3, "ey") == 0);
  check (x4 == -6015583168144663709);
  check (strcmp(x5, "qc") == 0);
  check (x6 == -941426339155173482);
  check (x7 == -278545374);
}

void f617(char * x0, char * x1, long long x2, float x3, float x4, float x5, double x6, int x7)
{
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "") == 0);
  check (x2 == 7306972208340649303);
  check (x3 == 0x1.7f5eb4p+5F);
  check (x4 == 0x1.d4113ep+4F);
  check (x5 == 0x1.388b16p+5F);
  check (x6 == -0x1.d1b0365a16f4cp+3);
  check (x7 == 1628637997);
}

char * f618(double x0, long long x1, char * x2, long long x3)
{
  check (x0 == 0x1.d7a8b33c5d44p-1);
  check (x1 == 1852878568987487711);
  check (strcmp(x2, "uh") == 0);
  check (x3 == -2640660287949457463);
  return "rc";
}

void f619(float x0, int x1, int x2)
{
  check (x0 == -0x1.d76206p+4F);
  check (x1 == 1275943182);
  check (x2 == -644024723);
}

void f620(long long x0, double x1, char * x2, double x3, long long x4, double x5, double x6, double x7, double x8, long long x9, float x10)
{
  check (x0 == 1624890013460032996);
  check (x1 == 0x1.26224b76aeba6p+5);
  check (strcmp(x2, "t") == 0);
  check (x3 == 0x1.25ed8594413bp+3);
  check (x4 == 4461390300839427587);
  check (x5 == 0x1.e7a5953cf9f9cp+4);
  check (x6 == 0x1.da088e415c9cp+1);
  check (x7 == -0x1.a6f16653ab9b7p+4);
  check (x8 == -0x1.2ba65766a7e06p+5);
  check (x9 == -8314938491221024549);
  check (x10 == 0x1.6f7d2ep+4F);
}

void f621(long long x0, long long x1, float x2, long long x3, double x4, long long x5, char * x6, long long x7, char * x8, float x9)
{
  check (x0 == -3682061705242852838);
  check (x1 == 1464030997663272324);
  check (x2 == 0x1.b50132p+3F);
  check (x3 == -8793789110595534137);
  check (x4 == -0x1.5f3cabf50d678p+3);
  check (x5 == -5706280082493837267);
  check (strcmp(x6, "") == 0);
  check (x7 == -2793853872888321768);
  check (strcmp(x8, "vm") == 0);
  check (x9 == 0x1.25ed7ap+5F);
}

void f622(int x0)
{
  check (x0 == -1866606684);
}

void f623(float x0, float x1, char * x2, long long x3, int x4, int x5, double x6, double x7)
{
  check (x0 == 0x1.364596p+4F);
  check (x1 == 0x1.827984p+5F);
  check (strcmp(x2, "x") == 0);
  check (x3 == -5420219619867047354);
  check (x4 == -477050668);
  check (x5 == -366819612);
  check (x6 == 0x1.2c9eb18da7148p+2);
  check (x7 == 0x1.674325519c684p+5);
}

void f624(char * x0, float x1, double x2, long long x3, long long x4, char * x5, float x6)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -0x1.fe910ap+4F);
  check (x2 == 0x1.dd2c795626c18p+4);
  check (x3 == -9031198963589321964);
  check (x4 == 4326138230415157863);
  check (strcmp(x5, "z") == 0);
  check (x6 == 0x1.db58e6p+1F);
}

void f625(double x0, float x1, long long x2, double x3, float x4, char * x5, double x6, float x7, char * x8, long long x9)
{
  check (x0 == 0x1.299f32bfba7b6p+5);
  check (x1 == 0x1.1da982p+5F);
  check (x2 == 4221418338584319135);
  check (x3 == 0x1.2189500a1458p+1);
  check (x4 == 0x1.f13d5ap+4F);
  check (strcmp(x5, "qj") == 0);
  check (x6 == 0x1.ba1695458daacp+3);
  check (x7 == -0x1.5f6526p+4F);
  check (strcmp(x8, "tl") == 0);
  check (x9 == 1153298645289316560);
}

unsigned short f626(double x0, float x1)
{
  check (x0 == 0x1.06763190e0dp+2);
  check (x1 == 0x1.106aep+4F);
  return -231925460;
}

int f627(int x0, int x1, char * x2, double x3, char * x4, int x5, int x6, char * x7, int x8, float x9, int x10)
{
  check (x0 == 1812928875);
  check (x1 == -213920401);
  check (strcmp(x2, "") == 0);
  check (x3 == 0x1.8933edc72242p+5);
  check (strcmp(x4, "ok") == 0);
  check (x5 == 1001325934);
  check (x6 == -901563535);
  check (strcmp(x7, "") == 0);
  check (x8 == -1913824044);
  check (x9 == -0x1.176138p+1F);
  check (x10 == 415709930);
  return 410597311;
}

long long f628(int x0, long long x1, double x2, long long x3, float x4)
{
  check (x0 == -1010136654);
  check (x1 == 6987418178592761831);
  check (x2 == 0x1.a02b4b4be5c1p+1);
  check (x3 == -1253106241536373353);
  check (x4 == 0x1.e33368p+3F);
  return 2919225142824789557;
}

void f629(long long x0, long long x1, char * x2, float x3, int x4, double x5, double x6, long long x7, int x8)
{
  check (x0 == 7374410342318604943);
  check (x1 == -3410829991425784129);
  check (strcmp(x2, "y") == 0);
  check (x3 == 0x1.5ba716p+5F);
  check (x4 == 743959999);
  check (x5 == -0x1.3b365d394f227p+5);
  check (x6 == 0x1.7c2daca90a574p+5);
  check (x7 == -3706722183241536999);
  check (x8 == -1804395782);
}

float f630(float x0, int x1, char * x2, int x3, long long x4, double x5, long long x6, int x7)
{
  check (x0 == -0x1.5e1b1ap+4F);
  check (x1 == 616424224);
  check (strcmp(x2, "i") == 0);
  check (x3 == -1805784697);
  check (x4 == 515190876182715617);
  check (x5 == -0x1.6d82c349161b8p+5);
  check (x6 == -5612381956116404776);
  check (x7 == 1286099778);
  return -0x1.8172a17bcf3b5p+5;
}

void f631(int x0, char * x1, char * x2, int x3, char * x4, char * x5, int x6, double x7)
{
  check (x0 == -392511167);
  check (strcmp(x1, "jv") == 0);
  check (strcmp(x2, "") == 0);
  check (x3 == -716985395);
  check (strcmp(x4, "u") == 0);
  check (strcmp(x5, "") == 0);
  check (x6 == 1100663272);
  check (x7 == -0x1.8b320cf8ef1f9p+4);
}

float f632(long long x0, char * x1, double x2, float x3, float x4, int x5, float x6, int x7, float x8)
{
  check (x0 == -8925483899174900365);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.6a24571126d4cp+5);
  check (x3 == -0x1.2d45d8p+5F);
  check (x4 == 0x1.3b5dcep+3F);
  check (x5 == -1166732810);
  check (x6 == 0x1.7ca73ap+3F);
  check (x7 == 1440799273);
  check (x8 == -0x1.7d5a5p+3F);
  return -0x1.88b403ec07fdap+5;
}

double f633(double x0, double x1, long long x2, int x3, int x4, char * x5, double x6, double x7, char * x8, long long x9, float x10)
{
  check (x0 == 0x1.c186cb0eac5p-2);
  check (x1 == 0x1.9b0626b273f4p+0);
  check (x2 == 8803619334588561153);
  check (x3 == -895073124);
  check (x4 == 87285227);
  check (strcmp(x5, "") == 0);
  check (x6 == 0x1.3c5b17f7abe96p+5);
  check (x7 == -0x1.e1d59d02928a8p+2);
  check (strcmp(x8, "t") == 0);
  check (x9 == 80169928239179683);
  check (x10 == 0x1.17e63ep+5F);
  return -0x1.7865a307cfab8p+2;
}

void f634(void)
{
}

void f635(char * x0, float x1, double x2)
{
  check (strcmp(x0, "cs") == 0);
  check (x1 == 0x1.7e3798p+5F);
  check (x2 == -0x1.39ce2211b366ap+5);
}

void f636(long long x0, long long x1, char * x2, double x3, int x4, char * x5, int x6)
{
  check (x0 == 721030682315969090);
  check (x1 == -9002882471829477816);
  check (strcmp(x2, "") == 0);
  check (x3 == -0x1.0356e9fbdeda4p+5);
  check (x4 == -1531829680);
  check (strcmp(x5, "") == 0);
  check (x6 == 213748582);
}

void f637(int x0, char * x1, int x2)
{
  check (x0 == 257034477);
  check (strcmp(x1, "x") == 0);
  check (x2 == -402030556);
}

void f638(int x0, float x1)
{
  check (x0 == -31482340);
  check (x1 == -0x1.45125ep+4F);
}

int f639(int x0, char * x1, char * x2, double x3, long long x4, double x5, long long x6, long long x7, char * x8, char * x9)
{
  check (x0 == -735811671);
  check (strcmp(x1, "br") == 0);
  check (strcmp(x2, "fp") == 0);
  check (x3 == -0x1.57204ea415a37p+5);
  check (x4 == -6621485387607570811);
  check (x5 == -0x1.9dee936cd4014p+4);
  check (x6 == -349267266136703484);
  check (x7 == 9063278725064809328);
  check (strcmp(x8, "gv") == 0);
  check (strcmp(x9, "kz") == 0);
  return 24018104;
}

void f640(double x0, long long x1)
{
  check (x0 == 0x1.4654dfb1306cep+5);
  check (x1 == -2452123380446311748);
}

void f641(long long x0, int x1, char * x2, float x3, long long x4)
{
  check (x0 == -4907197581510418685);
  check (x1 == 1651806001);
  check (strcmp(x2, "tm") == 0);
  check (x3 == 0x1.ce9e72p+2F);
  check (x4 == -535540722280560155);
}

void f642(float x0)
{
  check (x0 == 0x1.382e5p-3F);
}

void f643(long long x0, long long x1, long long x2)
{
  check (x0 == 2573554687282185598);
  check (x1 == 3494431209994382574);
  check (x2 == -262321080772358460);
}

void f644(char * x0, long long x1, char * x2, int x3)
{
  check (strcmp(x0, "w") == 0);
  check (x1 == -7122082711786443347);
  check (strcmp(x2, "kz") == 0);
  check (x3 == 1127815057);
}

void f645(double x0, double x1, int x2, double x3, char * x4, char * x5, float x6, char * x7)
{
  check (x0 == 0x1.159c8eb0370c6p+5);
  check (x1 == -0x1.f9d277662cec5p+4);
  check (x2 == 1109473262);
  check (x3 == 0x1.2fe769976ee34p+4);
  check (strcmp(x4, "h") == 0);
  check (strcmp(x5, "o") == 0);
  check (x6 == 0x1.07bf6p+4F);
  check (strcmp(x7, "hv") == 0);
}

void f646(int x0, int x1, long long x2, long long x3, long long x4, float x5, double x6, int x7)
{
  check (x0 == 1658991097);
  check (x1 == -922601002);
  check (x2 == -454079097059809050);
  check (x3 == 3521337281645937716);
  check (x4 == 8661343488704502164);
  check (x5 == -0x1.13a384p+4F);
  check (x6 == 0x1.b76c0fdf48f3p+4);
  check (x7 == 1950491693);
}

void f647(char * x0)
{
  check (strcmp(x0, "") == 0);
}

void f648(float x0, double x1)
{
  check (x0 == 0x1.1ca06p+5F);
  check (x1 == -0x1.0adc6519a6d02p+5);
}

void f649(double x0, long long x1, int x2)
{
  check (x0 == -0x1.1bf9e1d9ec208p+2);
  check (x1 == -88950668625353680);
  check (x2 == -175427726);
}

long long f650(long long x0, char * x1, char * x2, double x3, long long x4, long long x5, double x6, long long x7, long long x8, long long x9, char * x10)
{
  check (x0 == 156046783529380308);
  check (strcmp(x1, "") == 0);
  check (strcmp(x2, "") == 0);
  check (x3 == 0x1.6be4dc52c68c2p+5);
  check (x4 == 1657700695359116681);
  check (x5 == 6679380730827117933);
  check (x6 == -0x1.62a29410d269dp+5);
  check (x7 == -6164490098793787208);
  check (x8 == 3147609220359657188);
  check (x9 == -8038447891117919371);
  check (strcmp(x10, "") == 0);
  return -2099031022923076293;
}

char * f651(char * x0, int x1, int x2, int x3, double x4)
{
  check (strcmp(x0, "ak") == 0);
  check (x1 == -1739094799);
  check (x2 == -271824525);
  check (x3 == -732045677);
  check (x4 == -0x1.8fe169cd34a2fp+5);
  return "w";
}

char * f652(int x0, long long x1, long long x2, char * x3, double x4)
{
  check (x0 == 1640182751);
  check (x1 == -1103692418744767008);
  check (x2 == -8610868504437457704);
  check (strcmp(x3, "b") == 0);
  check (x4 == 0x1.f3233307e787p+4);
  return "xs";
}

long long f653(long long x0, int x1, char * x2, char * x3)
{
  check (x0 == 2680042224106538125);
  check (x1 == -14248543);
  check (strcmp(x2, "z") == 0);
  check (strcmp(x3, "") == 0);
  return -2761618418451379101;
}

void f654(float x0, float x1, double x2, float x3, char * x4)
{
  check (x0 == 0x1.4e18e2p+2F);
  check (x1 == 0x1.42926ep+4F);
  check (x2 == -0x1.b3789e23f105ep+4);
  check (x3 == 0x1.5915dep+5F);
  check (strcmp(x4, "b") == 0);
}

long long f655(char * x0, float x1, int x2, long long x3, double x4, int x5, long long x6, long long x7, long long x8)
{
  check (strcmp(x0, "b") == 0);
  check (x1 == 0x1.4d324ap+3F);
  check (x2 == 1124005398);
  check (x3 == -5550380184391856595);
  check (x4 == 0x1.d5a1dc93c0bep+0);
  check (x5 == 466213520);
  check (x6 == -2820210030227968869);
  check (x7 == 2597474720408398161);
  check (x8 == 7918565000898428915);
  return 2299891876988547765;
}

float f656(char * x0, float x1, char * x2, long long x3, int x4, long long x5, float x6, double x7, char * x8, long long x9, float x10)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 0x1.e8f89p+1F);
  check (strcmp(x2, "ip") == 0);
  check (x3 == -8364395190729036746);
  check (x4 == 1401073037);
  check (x5 == 6458047051715120622);
  check (x6 == 0x1.465d0ep+5F);
  check (x7 == -0x1.aff50d7e75208p+3);
  check (strcmp(x8, "") == 0);
  check (x9 == 973009646830365618);
  check (x10 == 0x1.57a43ep+4F);
  return 0x1.753194d6b2ef2p+5;
}

void f657(double x0, int x1, float x2, char * x3, long long x4, int x5, long long x6, char * x7, char * x8, int x9, long long x10)
{
  check (x0 == -0x1.52a99e313403ep+5);
  check (x1 == 723376230);
  check (x2 == -0x1.d1b7eap+3F);
  check (strcmp(x3, "") == 0);
  check (x4 == -6779394217995128306);
  check (x5 == -1308246211);
  check (x6 == -4427019453621036844);
  check (strcmp(x7, "") == 0);
  check (strcmp(x8, "g") == 0);
  check (x9 == -937675400);
  check (x10 == 134260537135894618);
}

unsigned char f658(long long x0, char * x1, int x2, double x3, long long x4)
{
  check (x0 == 1922521098585988945);
  check (strcmp(x1, "") == 0);
  check (x2 == -1934437900);
  check (x3 == 0x1.bd18742e01aep+0);
  check (x4 == -1914535239326376454);
  return -46952195;
}

double f659(double x0, char * x1, double x2, double x3, float x4, float x5)
{
  check (x0 == -0x1.1126f588174e1p+5);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.7078c9d53b9c4p+4);
  check (x3 == 0x1.98d8732463448p+4);
  check (x4 == 0x1.1eb0c8p+3F);
  check (x5 == 0x1.4a4dc6p+4F);
  return 0x1.18ef99dc57782p+5;
}

unsigned short f660(double x0, double x1, float x2, long long x3)
{
  check (x0 == 0x1.0ea1b705a4aap+4);
  check (x1 == -0x1.a507f060420fcp+4);
  check (x2 == -0x1.cf1316p+4F);
  check (x3 == 4207542828300427714);
  return -99261022;
}

void f661(float x0, double x1, double x2, long long x3)
{
  check (x0 == -0x1.72d048p+3F);
  check (x1 == 0x1.cccee482b4a94p+4);
  check (x2 == -0x1.b9e0b470e7d2dp+4);
  check (x3 == -9003653671084911240);
}

void f662(void)
{
}

unsigned short f663(char * x0)
{
  check (strcmp(x0, "z") == 0);
  return -381831997;
}

void f664(int x0, int x1)
{
  check (x0 == -657192802);
  check (x1 == 758998198);
}

void f665(double x0, char * x1, float x2, float x3, char * x4, int x5, long long x6, float x7, int x8, char * x9)
{
  check (x0 == 0x1.33dc0ecd877bep+5);
  check (strcmp(x1, "ac") == 0);
  check (x2 == -0x1.70ca34p+4F);
  check (x3 == 0x1.1f4442p+5F);
  check (strcmp(x4, "") == 0);
  check (x5 == -2085516630);
  check (x6 == 3185321189926806823);
  check (x7 == 0x1.c93658p+4F);
  check (x8 == 97702899);
  check (strcmp(x9, "vr") == 0);
}

void f666(double x0, char * x1, long long x2, long long x3, char * x4)
{
  check (x0 == 0x1.cc5925897abb8p+3);
  check (strcmp(x1, "ga") == 0);
  check (x2 == -5578757459018333728);
  check (x3 == 6594643821592793736);
  check (strcmp(x4, "") == 0);
}

void f667(long long x0, float x1)
{
  check (x0 == -5571789386906641658);
  check (x1 == 0x1.1c91bcp+5F);
}

char * f668(float x0, float x1, int x2, char * x3, int x4, double x5, double x6, long long x7, int x8, int x9, char * x10)
{
  check (x0 == -0x1.c69334p+0F);
  check (x1 == 0x1.010a48p+4F);
  check (x2 == 321924011);
  check (strcmp(x3, "") == 0);
  check (x4 == -1823994727);
  check (x5 == 0x1.def740763b02p+0);
  check (x6 == -0x1.45b28212085c2p+5);
  check (x7 == -6020577877959721464);
  check (x8 == -1073518671);
  check (x9 == -822163387);
  check (strcmp(x10, "") == 0);
  return "x";
}

signed char f669(void)
{
  return 529326426;
}

void f670(float x0, float x1, double x2, double x3, long long x4, double x5, float x6, char * x7, double x8, int x9, float x10)
{
  check (x0 == -0x1.83a5d2p+5F);
  check (x1 == 0x1.41833ap+2F);
  check (x2 == -0x1.080307fa1a09dp+5);
  check (x3 == -0x1.977d47fd6ee6p+1);
  check (x4 == 9215842884093907692);
  check (x5 == 0x1.6761eb3a92896p+5);
  check (x6 == 0x1.da954p+4F);
  check (strcmp(x7, "bc") == 0);
  check (x8 == 0x1.6ac8af6670d1p+5);
  check (x9 == -1343211364);
  check (x10 == 0x1.6ed2d8p+5F);
}

void f671(char * x0, long long x1, float x2, char * x3, double x4, double x5)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 7822038628949301765);
  check (x2 == -0x1.343ce6p+5F);
  check (strcmp(x3, "") == 0);
  check (x4 == -0x1.3a42fc17afdap+5);
  check (x5 == -0x1.7f5d224486169p+4);
}

long long f672(char * x0, long long x1, int x2, double x3, char * x4, int x5, float x6, int x7)
{
  check (strcmp(x0, "ph") == 0);
  check (x1 == -2839165031188514118);
  check (x2 == 107680420);
  check (x3 == 0x1.16c80bd07977p+4);
  check (strcmp(x4, "ah") == 0);
  check (x5 == 512265851);
  check (x6 == 0x1.d0a026p+4F);
  check (x7 == -782829879);
  return 2830096809659467978;
}

void f673(char * x0, long long x1, int x2, char * x3, int x4, int x5)
{
  check (strcmp(x0, "q") == 0);
  check (x1 == 4900081967001717422);
  check (x2 == 53761227);
  check (strcmp(x3, "") == 0);
  check (x4 == 225731355);
  check (x5 == 1976384321);
}

long long f674(double x0, char * x1, double x2, double x3, long long x4, int x5)
{
  check (x0 == 0x1.b8936cc5c9e18p+3);
  check (strcmp(x1, "u") == 0);
  check (x2 == 0x1.0f6185dd9b984p+3);
  check (x3 == -0x1.bd0a586a8addcp+3);
  check (x4 == -3651739576773170887);
  check (x5 == 2018796669);
  return -9144516666895674801;
}

unsigned char f675(double x0, float x1, int x2, int x3, long long x4, char * x5, double x6, long long x7)
{
  check (x0 == -0x1.098e1c72c4b4ep+5);
  check (x1 == 0x1.25d102p+2F);
  check (x2 == -988451417);
  check (x3 == -1209340391);
  check (x4 == 7570057974671283611);
  check (strcmp(x5, "a") == 0);
  check (x6 == -0x1.0d1cd9a277648p+5);
  check (x7 == 8174651140489100427);
  return 439211397;
}

signed char f676(double x0, long long x1, int x2, char * x3, double x4, double x5, double x6)
{
  check (x0 == 0x1.a6332ed1048a8p+4);
  check (x1 == 4750280955996531018);
  check (x2 == 733057397);
  check (strcmp(x3, "ll") == 0);
  check (x4 == -0x1.58c562652e5c8p+2);
  check (x5 == 0x1.a6c82bbb1788p+4);
  check (x6 == 0x1.6aaca31f6bceap+5);
  return 480952434;
}

void f677(double x0, float x1, double x2)
{
  check (x0 == 0x1.4a9d5ef8d3bp+2);
  check (x1 == -0x1.15036p+4F);
  check (x2 == 0x1.0d0a37228a25cp+4);
}

void f678(float x0, char * x1, long long x2, double x3, int x4, double x5, float x6)
{
  check (x0 == -0x1.c0e02p+3F);
  check (strcmp(x1, "f") == 0);
  check (x2 == 8689003462595601756);
  check (x3 == 0x1.65ddb98b54208p+2);
  check (x4 == -656540893);
  check (x5 == -0x1.fc1ba17d51d44p+4);
  check (x6 == 0x1.6a5468p+5F);
}

int f679(void)
{
  return 1171175008;
}

int f680(char * x0, char * x1, double x2, int x3, char * x4, long long x5, char * x6)
{
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "") == 0);
  check (x2 == -0x1.24db25e22a22fp+4);
  check (x3 == 1682076335);
  check (strcmp(x4, "u") == 0);
  check (x5 == 4402704071085339108);
  check (strcmp(x6, "d") == 0);
  return -1698676422;
}

void f681(long long x0, long long x1, char * x2, double x3, int x4)
{
  check (x0 == 4478839833669253610);
  check (x1 == 6247072333298560943);
  check (strcmp(x2, "qz") == 0);
  check (x3 == 0x1.f9ba88972266p+4);
  check (x4 == -405935961);
}

signed char f682(double x0, float x1, long long x2, float x3, long long x4, float x5, long long x6, char * x7)
{
  check (x0 == -0x1.4f028874c3afdp+4);
  check (x1 == 0x1.2eafd6p+5F);
  check (x2 == -696310937192593567);
  check (x3 == 0x1.81f56ap+5F);
  check (x4 == 4833801246695419283);
  check (x5 == -0x1.d201c4p+3F);
  check (x6 == -5096875918908974670);
  check (strcmp(x7, "b") == 0);
  return -134014301;
}

void f683(char * x0, long long x1, float x2, float x3, double x4, long long x5, double x6, long long x7, float x8, float x9)
{
  check (strcmp(x0, "wm") == 0);
  check (x1 == -5011995327023601448);
  check (x2 == 0x1.753884p+3F);
  check (x3 == -0x1.890324p+5F);
  check (x4 == -0x1.e6f68341f8307p+4);
  check (x5 == -5464741362459437164);
  check (x6 == -0x1.7f09ea06f5ef2p+5);
  check (x7 == 6623064473180791821);
  check (x8 == -0x1.a53154p+4F);
  check (x9 == -0x1.3865dap+5F);
}

void f684(float x0, char * x1, float x2, int x3, char * x4, char * x5, int x6, long long x7)
{
  check (x0 == -0x1.b59caap+4F);
  check (strcmp(x1, "ay") == 0);
  check (x2 == 0x1.68bc56p+5F);
  check (x3 == -460809587);
  check (strcmp(x4, "kk") == 0);
  check (strcmp(x5, "o") == 0);
  check (x6 == 1550428113);
  check (x7 == -3265270614658774949);
}

void f685(float x0, int x1, float x2, char * x3, char * x4, float x5, double x6, double x7, char * x8, char * x9, float x10)
{
  check (x0 == 0x1.34121ep+4F);
  check (x1 == 968918246);
  check (x2 == 0x1.79b26cp+5F);
  check (strcmp(x3, "xo") == 0);
  check (strcmp(x4, "") == 0);
  check (x5 == 0x1.1b4a42p+5F);
  check (x6 == 0x1.de2a25bcc503p+4);
  check (x7 == 0x1.75ea337c1b0ep+3);
  check (strcmp(x8, "q") == 0);
  check (strcmp(x9, "l") == 0);
  check (x10 == -0x1.9a7c36p+4F);
}

void f686(long long x0, float x1, float x2, int x3, char * x4, long long x5)
{
  check (x0 == 1144826049388598776);
  check (x1 == -0x1.96ee54p+4F);
  check (x2 == 0x1.35714p+4F);
  check (x3 == 1889118866);
  check (strcmp(x4, "j") == 0);
  check (x5 == -2780089519800044462);
}

int f687(int x0, float x1, char * x2, float x3, double x4, char * x5, int x6, int x7)
{
  check (x0 == -1119155783);
  check (x1 == 0x1.2a1da6p+5F);
  check (strcmp(x2, "m") == 0);
  check (x3 == -0x1.328bd2p+4F);
  check (x4 == 0x1.e13544e12138p-1);
  check (strcmp(x5, "ky") == 0);
  check (x6 == -1931132488);
  check (x7 == -1981902166);
  return -984917413;
}

unsigned char f688(char * x0, long long x1, float x2, char * x3, float x4, int x5, float x6, double x7, long long x8, float x9)
{
  check (strcmp(x0, "c") == 0);
  check (x1 == 2850504136917469162);
  check (x2 == -0x1.59c514p+5F);
  check (strcmp(x3, "l") == 0);
  check (x4 == 0x1.9ae44cp+4F);
  check (x5 == -1763326749);
  check (x6 == 0x1.3d6018p+5F);
  check (x7 == 0x1.8e7bc9a64d424p+4);
  check (x8 == 5251974603605088227);
  check (x9 == 0x1.055098p-1F);
  return -239283507;
}

signed char f689(float x0, int x1, int x2, double x3, long long x4, float x5)
{
  check (x0 == 0x1.6339p+5F);
  check (x1 == -1857321782);
  check (x2 == -1858346008);
  check (x3 == -0x1.fd91cfce01e4bp+4);
  check (x4 == -4796693542923114781);
  check (x5 == -0x1.50bdeep+4F);
  return 514367309;
}

int f690(char * x0)
{
  check (strcmp(x0, "kn") == 0);
  return 2107419217;
}

void f691(float x0, double x1, double x2)
{
  check (x0 == -0x1.084fc6p+5F);
  check (x1 == 0x1.6c41aa35e218p+0);
  check (x2 == -0x1.48655f3d86368p+3);
}

void f692(char * x0, long long x1)
{
  check (strcmp(x0, "sc") == 0);
  check (x1 == -619358086288791266);
}

float f693(char * x0, int x1, char * x2)
{
  check (strcmp(x0, "zp") == 0);
  check (x1 == 2143000020);
  check (strcmp(x2, "xr") == 0);
  return 0x1.e4202559395d8p+2;
}

void f694(char * x0, char * x1, int x2, double x3, char * x4, float x5)
{
  check (strcmp(x0, "v") == 0);
  check (strcmp(x1, "z") == 0);
  check (x2 == -792596204);
  check (x3 == -0x1.7d0a20ed26c8p-1);
  check (strcmp(x4, "") == 0);
  check (x5 == 0x1.2955fep+5F);
}

void f695(long long x0, char * x1, long long x2, double x3, double x4, long long x5, int x6, double x7, double x8, int x9)
{
  check (x0 == 3494315375049271052);
  check (strcmp(x1, "x") == 0);
  check (x2 == -7545481984853835281);
  check (x3 == -0x1.1d0b50e4013ebp+5);
  check (x4 == 0x1.f9f777cd73d7cp+4);
  check (x5 == 101426644266383714);
  check (x6 == -1552686791);
  check (x7 == 0x1.25fecf5c6df3p+5);
  check (x8 == -0x1.5f389c8460eeap+5);
  check (x9 == -602781272);
}

void f696(void)
{
}

void f697(double x0, double x1, int x2, int x3, int x4, char * x5, long long x6, double x7)
{
  check (x0 == -0x1.a27224df58583p+4);
  check (x1 == -0x1.485be0721214bp+4);
  check (x2 == 2064491316);
  check (x3 == 738626010);
  check (x4 == -2083580528);
  check (strcmp(x5, "") == 0);
  check (x6 == -1051521141164062127);
  check (x7 == 0x1.3cd1f8f3f9af4p+5);
}

void f698(double x0, double x1, long long x2, long long x3, char * x4)
{
  check (x0 == 0x1.37efb38abcdc2p+5);
  check (x1 == -0x1.e3652561198aep+4);
  check (x2 == -8870679788652031637);
  check (x3 == -8574939730439535384);
  check (strcmp(x4, "n") == 0);
}

long long f699(long long x0, double x1, double x2, char * x3, double x4, float x5, int x6, double x7, long long x8, char * x9, int x10)
{
  check (x0 == -7376180305536731766);
  check (x1 == 0x1.714b74e50d50cp+4);
  check (x2 == 0x1.b392b2e3d36b4p+3);
  check (strcmp(x3, "h") == 0);
  check (x4 == 0x1.1cedcc4a03974p+4);
  check (x5 == -0x1.74a522p+3F);
  check (x6 == 1576401914);
  check (x7 == 0x1.39f63cf79dd7cp+4);
  check (x8 == -6266582760155735617);
  check (strcmp(x9, "f") == 0);
  check (x10 == -494357883);
  return 2371837968856802687;
}

void f700(char * x0, int x1, long long x2)
{
  check (strcmp(x0, "dh") == 0);
  check (x1 == 764628381);
  check (x2 == -8083161649322145816);
}

unsigned short f701(double x0, double x1, float x2)
{
  check (x0 == 0x1.166ff57b507bap+5);
  check (x1 == 0x1.a386eb81db9e8p+4);
  check (x2 == -0x1.02e346p+5F);
  return 297928560;
}

unsigned short f702(long long x0)
{
  check (x0 == -7423856577700084903);
  return -34450494;
}

void f703(char * x0, int x1)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -2044765118);
}

void f704(float x0, double x1, float x2, char * x3, float x4, char * x5, float x6, int x7, char * x8)
{
  check (x0 == 0x1.ff1d0ap+4F);
  check (x1 == 0x1.e0e6721bdfd98p+2);
  check (x2 == -0x1.8ca676p+5F);
  check (strcmp(x3, "n") == 0);
  check (x4 == -0x1.b76fc2p+2F);
  check (strcmp(x5, "uz") == 0);
  check (x6 == 0x1.c6a87ep+4F);
  check (x7 == 401583619);
  check (strcmp(x8, "km") == 0);
}

unsigned char f705(double x0, double x1, double x2, char * x3, int x4, long long x5, int x6)
{
  check (x0 == 0x1.b00b119de9db4p+4);
  check (x1 == -0x1.c32a105039d1p+1);
  check (x2 == -0x1.8a30cbad4ce42p+5);
  check (strcmp(x3, "") == 0);
  check (x4 == -208201576);
  check (x5 == 4700724359637073565);
  check (x6 == 296025486);
  return 496876218;
}

void f706(int x0, char * x1, float x2, char * x3)
{
  check (x0 == -666284138);
  check (strcmp(x1, "x") == 0);
  check (x2 == -0x1.f20c6ep+4F);
  check (strcmp(x3, "") == 0);
}

void f707(long long x0, float x1, char * x2, int x3, float x4)
{
  check (x0 == -4771395930333343896);
  check (x1 == 0x1.20d3dp+3F);
  check (strcmp(x2, "f") == 0);
  check (x3 == -240396841);
  check (x4 == -0x1.c44326p+4F);
}

void f708(float x0)
{
  check (x0 == 0x1.6ed2p+5F);
}

double f709(void)
{
  return -0x1.8afcc51e4dc68p+3;
}

void f710(int x0, char * x1, long long x2, long long x3, float x4)
{
  check (x0 == -2026195856);
  check (strcmp(x1, "") == 0);
  check (x2 == 4214394447110180078);
  check (x3 == -5958836228855725351);
  check (x4 == -0x1.1f3a04p+5F);
}

unsigned short f711(char * x0, float x1, int x2, long long x3, double x4, int x5, long long x6)
{
  check (strcmp(x0, "no") == 0);
  check (x1 == 0x1.53085p+3F);
  check (x2 == 1472566389);
  check (x3 == 2129183519152010017);
  check (x4 == 0x1.64998d366ead8p+4);
  check (x5 == -1323026899);
  check (x6 == -2415317846140792682);
  return -148806226;
}

char * f712(void)
{
  return "";
}

float f713(double x0, float x1, float x2, float x3, char * x4, char * x5, long long x6, long long x7, double x8, int x9)
{
  check (x0 == -0x1.f445a6941c038p+2);
  check (x1 == 0x1.4f8cb6p+5F);
  check (x2 == 0x1.28f742p+4F);
  check (x3 == -0x1.d67d5ap+3F);
  check (strcmp(x4, "m") == 0);
  check (strcmp(x5, "") == 0);
  check (x6 == -8291232492584418580);
  check (x7 == -6858658574779208092);
  check (x8 == -0x1.7235489f1c5e2p+5);
  check (x9 == -1288195121);
  return -0x1.d24f4823989d5p+4;
}

char * f714(double x0, int x1, int x2, int x3, char * x4, double x5)
{
  check (x0 == -0x1.0d4fd5feb922p+1);
  check (x1 == -343976392);
  check (x2 == -1749941223);
  check (x3 == -1079719014);
  check (strcmp(x4, "") == 0);
  check (x5 == -0x1.dac9e5e7d878p+1);
  return "jv";
}

float f715(int x0, char * x1, char * x2, long long x3)
{
  check (x0 == -428909306);
  check (strcmp(x1, "") == 0);
  check (strcmp(x2, "") == 0);
  check (x3 == 7181706216596319577);
  return -0x1.21bc3375fe7e6p+5;
}

char * f716(float x0, int x1)
{
  check (x0 == 0x1.c339dep+3F);
  check (x1 == -2098633458);
  return "vl";
}

int f717(float x0, double x1, int x2, int x3, double x4, long long x5, double x6, char * x7, double x8, int x9)
{
  check (x0 == 0x1.4675fap+5F);
  check (x1 == -0x1.32709f6dfda7p+2);
  check (x2 == 545537380);
  check (x3 == -1594565747);
  check (x4 == -0x1.7239df9ce4db1p+4);
  check (x5 == -4403746134495228845);
  check (x6 == -0x1.d9cac77edf738p+4);
  check (strcmp(x7, "eh") == 0);
  check (x8 == -0x1.54add567cd667p+5);
  check (x9 == -295418997);
  return -164880897;
}

unsigned char f718(int x0, float x1, char * x2, char * x3, char * x4, long long x5, long long x6, int x7)
{
  check (x0 == -913669043);
  check (x1 == 0x1.82d13ep+2F);
  check (strcmp(x2, "w") == 0);
  check (strcmp(x3, "xn") == 0);
  check (strcmp(x4, "xs") == 0);
  check (x5 == 7245759750714444307);
  check (x6 == -3626760882798210088);
  check (x7 == -1688016434);
  return -84215250;
}

void f719(char * x0)
{
  check (strcmp(x0, "") == 0);
}

signed char f720(long long x0, float x1, int x2, long long x3, long long x4, float x5)
{
  check (x0 == -7302998367745747016);
  check (x1 == 0x1.2429bp+5F);
  check (x2 == -68546152);
  check (x3 == -461655491113207654);
  check (x4 == -490600668167066820);
  check (x5 == -0x1.ae8264p+4F);
  return 385018867;
}

signed char f721(char * x0, long long x1, long long x2, double x3, double x4, char * x5, int x6, int x7)
{
  check (strcmp(x0, "ky") == 0);
  check (x1 == -1919451539907617005);
  check (x2 == -4020931826548225844);
  check (x3 == 0x1.d0b76d9507034p+4);
  check (x4 == 0x1.227889bcaaf4cp+3);
  check (strcmp(x5, "") == 0);
  check (x6 == -1099044011);
  check (x7 == -277461744);
  return 287459131;
}

void f722(char * x0, char * x1, long long x2, int x3, int x4, double x5, char * x6, double x7)
{
  check (strcmp(x0, "wb") == 0);
  check (strcmp(x1, "w") == 0);
  check (x2 == 4186064088710404635);
  check (x3 == -628411715);
  check (x4 == 231572965);
  check (x5 == 0x1.cdb860a71dcd8p+3);
  check (strcmp(x6, "e") == 0);
  check (x7 == 0x1.16c78da8bf6f4p+4);
}

double f723(char * x0, float x1, int x2)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 0x1.98a398p+4F);
  check (x2 == 276732313);
  return -0x1.29d1c6e9f58p-4;
}

long long f724(double x0, long long x1, char * x2, int x3, float x4)
{
  check (x0 == 0x1.7ddc4d0c53cp+4);
  check (x1 == -1389139239892506449);
  check (strcmp(x2, "") == 0);
  check (x3 == -1920393367);
  check (x4 == 0x1.89b1cap+5F);
  return 531025132759234563;
}

unsigned short f725(char * x0, double x1, char * x2, double x3, int x4)
{
  check (strcmp(x0, "og") == 0);
  check (x1 == 0x1.6a869988e83aap+5);
  check (strcmp(x2, "q") == 0);
  check (x3 == 0x1.2d8f7cf0b58bp+4);
  check (x4 == -777167050);
  return 331329423;
}

float f726(float x0, double x1, long long x2, char * x3, float x4, float x5)
{
  check (x0 == -0x1.83536p+3F);
  check (x1 == 0x1.57bc4ea3f1374p+3);
  check (x2 == -8670558370469767670);
  check (strcmp(x3, "") == 0);
  check (x4 == 0x1.a5abd6p+3F);
  check (x5 == -0x1.0490e8p+5F);
  return -0x1.56f2af271e4dap+4;
}

void f727(char * x0, long long x1, char * x2, char * x3, long long x4, char * x5, float x6, int x7, char * x8, long long x9, float x10)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 3597387870720388596);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "") == 0);
  check (x4 == -9100642254613773564);
  check (strcmp(x5, "") == 0);
  check (x6 == -0x1.6b3acp+4F);
  check (x7 == -714025561);
  check (strcmp(x8, "") == 0);
  check (x9 == 6593047330670613933);
  check (x10 == 0x1.72f53cp+5F);
}

void f728(long long x0, double x1, long long x2, float x3, double x4, double x5, double x6, char * x7, long long x8, int x9)
{
  check (x0 == -461484480248249345);
  check (x1 == 0x1.4f38bb2b7721p+5);
  check (x2 == -4967336260432716161);
  check (x3 == -0x1.812bap+5F);
  check (x4 == -0x1.95292386e145p+4);
  check (x5 == -0x1.4b6b5abd153b2p+5);
  check (x6 == -0x1.6bd144acf59b6p+5);
  check (strcmp(x7, "h") == 0);
  check (x8 == -467336352232171551);
  check (x9 == -309587190);
}

void f729(int x0, double x1, double x2, char * x3, long long x4, char * x5)
{
  check (x0 == -42372531);
  check (x1 == 0x1.20ab6c0a2652cp+3);
  check (x2 == 0x1.27dd5e40a9b74p+5);
  check (strcmp(x3, "na") == 0);
  check (x4 == -4075351236231536785);
  check (strcmp(x5, "qp") == 0);
}

unsigned char f730(long long x0, double x1, int x2, int x3, char * x4, double x5, char * x6, char * x7)
{
  check (x0 == 7031249241693917138);
  check (x1 == 0x1.029d36fcfd12cp+3);
  check (x2 == 425861138);
  check (x3 == 595938393);
  check (strcmp(x4, "") == 0);
  check (x5 == -0x1.2ee7054f6b8b5p+4);
  check (strcmp(x6, "t") == 0);
  check (strcmp(x7, "") == 0);
  return -75759435;
}

int f731(int x0, double x1, char * x2, long long x3, float x4, long long x5, double x6, long long x7, float x8, char * x9)
{
  check (x0 == 818672954);
  check (x1 == 0x1.2e27408a7edfcp+4);
  check (strcmp(x2, "is") == 0);
  check (x3 == 4094309789082780794);
  check (x4 == 0x1.0839e8p+5F);
  check (x5 == -5699900513737073179);
  check (x6 == 0x1.5ef2ce7f2bda2p+5);
  check (x7 == 8699848388696650387);
  check (x8 == -0x1.750df4p+5F);
  check (strcmp(x9, "b") == 0);
  return -845257859;
}

void f732(long long x0, float x1, float x2, char * x3, int x4, float x5, int x6, float x7)
{
  check (x0 == -7936177746241009067);
  check (x1 == 0x1.1309cap+4F);
  check (x2 == -0x1.09ff88p+5F);
  check (strcmp(x3, "") == 0);
  check (x4 == -601191800);
  check (x5 == 0x1.232c8ep+4F);
  check (x6 == -46389118);
  check (x7 == 0x1.bcddfap+4F);
}

int f733(double x0, int x1, char * x2, char * x3, float x4)
{
  check (x0 == -0x1.567b6059acd8p-1);
  check (x1 == 1836431751);
  check (strcmp(x2, "dt") == 0);
  check (strcmp(x3, "z") == 0);
  check (x4 == 0x1.a7b378p+4F);
  return 1017531477;
}

long long f734(long long x0, char * x1, int x2, int x3, int x4, double x5, double x6, double x7)
{
  check (x0 == -1435420103488812986);
  check (strcmp(x1, "en") == 0);
  check (x2 == 945649323);
  check (x3 == 504650794);
  check (x4 == -1594306678);
  check (x5 == 0x1.68378216be2ep+1);
  check (x6 == -0x1.dcfeba3339244p+4);
  check (x7 == -0x1.398be97a85693p+4);
  return 6235321514747808804;
}

void f735(void)
{
}

void f736(double x0, long long x1, int x2, double x3, long long x4, float x5, double x6, int x7)
{
  check (x0 == 0x1.13b0ee65dd7eap+5);
  check (x1 == 3560850157008858492);
  check (x2 == -1307429454);
  check (x3 == -0x1.b607074fc6135p+4);
  check (x4 == -2696263098524387465);
  check (x5 == -0x1.c64a6p+4F);
  check (x6 == 0x1.c3c2a8f652c54p+4);
  check (x7 == -1971432245);
}

long long f737(double x0)
{
  check (x0 == -0x1.be8b1b899fd2p+1);
  return -4289867085074861558;
}

void f738(char * x0, long long x1, char * x2, long long x3)
{
  check (strcmp(x0, "il") == 0);
  check (x1 == -18170578092968140);
  check (strcmp(x2, "") == 0);
  check (x3 == -7990156624476339288);
}

unsigned short f739(float x0, char * x1, long long x2, long long x3, int x4, int x5, long long x6, long long x7, double x8)
{
  check (x0 == -0x1.2d008ap+5F);
  check (strcmp(x1, "jn") == 0);
  check (x2 == -1567491520469665108);
  check (x3 == 7886592798951736564);
  check (x4 == 1867458335);
  check (x5 == -1502016409);
  check (x6 == 7325215673044656214);
  check (x7 == -2166657887964084638);
  check (x8 == 0x1.b0477cb19cec4p+4);
  return -418191397;
}

void f740(double x0, float x1, float x2, double x3, double x4, int x5)
{
  check (x0 == -0x1.942bceb4166ep+0);
  check (x1 == -0x1.7270fep+2F);
  check (x2 == 0x1.8ee75p+3F);
  check (x3 == -0x1.5df94b804b4f4p+5);
  check (x4 == 0x1.a9d4e2a3c607p+1);
  check (x5 == -1571514110);
}

void f741(int x0, int x1, float x2, float x3, int x4, double x5, char * x6, char * x7)
{
  check (x0 == -1759095417);
  check (x1 == -1206403139);
  check (x2 == -0x1.79c26p+5F);
  check (x3 == -0x1.cd01dap+4F);
  check (x4 == 1032990550);
  check (x5 == -0x1.c41f408786a2p+2);
  check (strcmp(x6, "wm") == 0);
  check (strcmp(x7, "t") == 0);
}

void f742(char * x0, char * x1, double x2, float x3, int x4, double x5, int x6)
{
  check (strcmp(x0, "") == 0);
  check (strcmp(x1, "c") == 0);
  check (x2 == 0x1.53b03677fe674p+3);
  check (x3 == 0x1.b739bcp+1F);
  check (x4 == 387257426);
  check (x5 == -0x1.8107f428ac99p+1);
  check (x6 == -175526916);
}

void f743(long long x0, double x1, long long x2, float x3, int x4)
{
  check (x0 == -8178753904396014556);
  check (x1 == -0x1.c8800835e2605p+4);
  check (x2 == -7076846071543095869);
  check (x3 == 0x1.5ac8e6p+5F);
  check (x4 == -1731415960);
}

unsigned char f744(int x0, int x1, float x2, int x3, int x4, double x5, int x6, long long x7, double x8)
{
  check (x0 == -644535622);
  check (x1 == -1364192628);
  check (x2 == -0x1.403e5p+3F);
  check (x3 == 62194362);
  check (x4 == -299507073);
  check (x5 == -0x1.c888b1b2bb75ap+4);
  check (x6 == -1254031691);
  check (x7 == 591600377083463078);
  check (x8 == -0x1.d8569c2d727f1p+4);
  return -534783229;
}

void f745(double x0, float x1, char * x2, int x3, double x4, float x5, double x6, int x7)
{
  check (x0 == 0x1.058da97b036fp+1);
  check (x1 == 0x1.ec26dp+4F);
  check (strcmp(x2, "") == 0);
  check (x3 == 767616693);
  check (x4 == 0x1.4638b4916f61p+2);
  check (x5 == 0x1.ee89dap+3F);
  check (x6 == 0x1.46e91030ecdccp+3);
  check (x7 == 808813962);
}

float f746(long long x0, char * x1, char * x2, long long x3, char * x4, double x5, int x6, char * x7, char * x8, char * x9)
{
  check (x0 == -5564098697449360585);
  check (strcmp(x1, "rd") == 0);
  check (strcmp(x2, "lw") == 0);
  check (x3 == -2990167971635270760);
  check (strcmp(x4, "") == 0);
  check (x5 == 0x1.e0fbd85795c5cp+4);
  check (x6 == 776353019);
  check (strcmp(x7, "") == 0);
  check (strcmp(x8, "") == 0);
  check (strcmp(x9, "p") == 0);
  return 0x1.cce302dfbea04p+4;
}

signed char f747(int x0, char * x1, char * x2, float x3)
{
  check (x0 == 571478508);
  check (strcmp(x1, "") == 0);
  check (strcmp(x2, "n") == 0);
  check (x3 == 0x1.969dfep+3F);
  return -340161095;
}

signed char f748(char * x0, float x1, int x2, float x3)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -0x1.1ec72cp+3F);
  check (x2 == -469275987);
  check (x3 == -0x1.7c197ap+0F);
  return -45938933;
}

void f749(char * x0, long long x1, int x2, char * x3, double x4, int x5, int x6, int x7)
{
  check (strcmp(x0, "sm") == 0);
  check (x1 == -5471388232951685900);
  check (x2 == -1824206262);
  check (strcmp(x3, "xr") == 0);
  check (x4 == -0x1.40f8f0ca769acp+4);
  check (x5 == 621839940);
  check (x6 == -1860519216);
  check (x7 == 1834437044);
}

void f750(float x0, char * x1, int x2, double x3, float x4)
{
  check (x0 == 0x1.7c70bap+5F);
  check (strcmp(x1, "nh") == 0);
  check (x2 == 754018202);
  check (x3 == -0x1.61d269f2a60f7p+5);
  check (x4 == -0x1.4b1c6p+5F);
}

void f751(double x0, char * x1, int x2, double x3, double x4, char * x5)
{
  check (x0 == 0x1.cd1d7c7d45608p+4);
  check (strcmp(x1, "v") == 0);
  check (x2 == 1603556444);
  check (x3 == 0x1.2d3bb1a242aap+1);
  check (x4 == 0x1.bfade10763374p+4);
  check (strcmp(x5, "l") == 0);
}

void f752(double x0, float x1, double x2, double x3)
{
  check (x0 == -0x1.41c84f10792c1p+4);
  check (x1 == -0x1.9b5468p+4F);
  check (x2 == -0x1.70bcd4255cc6dp+4);
  check (x3 == -0x1.833c8f1f9be08p+5);
}

double f753(void)
{
  return 0x1.2ff86914c0368p+4;
}

void f754(char * x0, int x1, double x2, int x3, float x4)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -1438594084);
  check (x2 == 0x1.918803162afcp+2);
  check (x3 == -766116400);
  check (x4 == -0x1.a46024p+4F);
}

signed char f755(double x0, double x1, int x2, float x3)
{
  check (x0 == -0x1.9c981cd42395bp+4);
  check (x1 == 0x1.22185cea3523p+3);
  check (x2 == -1950283454);
  check (x3 == -0x1.7df248p+4F);
  return 102568235;
}

int f756(int x0, float x1, char * x2, int x3)
{
  check (x0 == 541772266);
  check (x1 == 0x1.85bf1cp-2F);
  check (strcmp(x2, "") == 0);
  check (x3 == 1082491246);
  return 2014074411;
}

unsigned char f757(int x0, float x1, char * x2, double x3, long long x4)
{
  check (x0 == 484416525);
  check (x1 == 0x1.16d04p+5F);
  check (strcmp(x2, "i") == 0);
  check (x3 == -0x1.0d68a00f2628p+2);
  check (x4 == 4169206621767172089);
  return -120249337;
}

void f758(double x0, long long x1, float x2, double x3, float x4, float x5, int x6, float x7)
{
  check (x0 == 0x1.1955523f04fp+2);
  check (x1 == 8310344355305523420);
  check (x2 == 0x1.e5ab3ap+4F);
  check (x3 == 0x1.47b6e538d2416p+5);
  check (x4 == -0x1.46d8e8p+5F);
  check (x5 == -0x1.93940ap+3F);
  check (x6 == -1520671528);
  check (x7 == -0x1.48b5b6p+5F);
}

void f759(int x0, long long x1, char * x2)
{
  check (x0 == -1620016505);
  check (x1 == -6349788528149129095);
  check (strcmp(x2, "lw") == 0);
}

signed char f760(float x0, float x1, char * x2, char * x3, float x4, long long x5, char * x6, long long x7)
{
  check (x0 == 0x1.8ba12ep+5F);
  check (x1 == 0x1.3d1fc4p+5F);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "") == 0);
  check (x4 == 0x1.4cac44p+5F);
  check (x5 == 4249666250919759945);
  check (strcmp(x6, "o") == 0);
  check (x7 == 5876123328478202475);
  return -417996701;
}

char * f761(double x0, float x1)
{
  check (x0 == 0x1.70fd5ebb18b46p+5);
  check (x1 == -0x1.4ad2bp+5F);
  return "lg";
}

unsigned char f762(long long x0, double x1, int x2, long long x3, int x4)
{
  check (x0 == -112556469689314213);
  check (x1 == 0x1.5842d466d43a4p+5);
  check (x2 == -814646840);
  check (x3 == 151423322851051330);
  check (x4 == 1862431828);
  return 253603159;
}

void f763(int x0, double x1, double x2, float x3, long long x4, long long x5, char * x6)
{
  check (x0 == 226230441);
  check (x1 == -0x1.35b9efbde358fp+5);
  check (x2 == 0x1.7fd4b98f713fcp+4);
  check (x3 == 0x1.7b1ebap+4F);
  check (x4 == 8915411899499230738);
  check (x5 == 6337645651338999556);
  check (strcmp(x6, "ip") == 0);
}

void f764(double x0, float x1, char * x2, char * x3, int x4, long long x5, float x6, int x7, int x8, int x9)
{
  check (x0 == -0x1.0c23f184f92a6p+5);
  check (x1 == 0x1.8cf70ap+4F);
  check (strcmp(x2, "l") == 0);
  check (strcmp(x3, "p") == 0);
  check (x4 == -576964012);
  check (x5 == 6974996503024177380);
  check (x6 == -0x1.389846p+4F);
  check (x7 == -547674395);
  check (x8 == 1116871844);
  check (x9 == 116033938);
}

void f765(float x0, int x1, float x2, float x3, int x4)
{
  check (x0 == -0x1.30598cp+2F);
  check (x1 == 624950012);
  check (x2 == -0x1.53b274p+5F);
  check (x3 == 0x1.688904p+5F);
  check (x4 == 314313778);
}

void f766(float x0, long long x1, float x2, long long x3, float x4, long long x5, float x6)
{
  check (x0 == 0x1.916ee6p+4F);
  check (x1 == 8482715492362192915);
  check (x2 == 0x1.75ea46p+5F);
  check (x3 == -382155908849846081);
  check (x4 == 0x1.5679fep+5F);
  check (x5 == 3997940097955667033);
  check (x6 == 0x1.c2601cp+3F);
}

long long f767(float x0, int x1, float x2, double x3, long long x4, double x5, double x6)
{
  check (x0 == 0x1.82d55ep+2F);
  check (x1 == 916043783);
  check (x2 == 0x1.eeac34p+2F);
  check (x3 == -0x1.96e61e7cafa58p+3);
  check (x4 == -5521338882720881273);
  check (x5 == -0x1.8f198c1b5ffadp+4);
  check (x6 == -0x1.c5f620cbb193p+2);
  return 1651289650223424365;
}

signed char f768(long long x0, int x1, long long x2, double x3, double x4)
{
  check (x0 == -6140177283195441627);
  check (x1 == -290907145);
  check (x2 == 6499948599412342196);
  check (x3 == -0x1.9a674a92f943cp+3);
  check (x4 == -0x1.34fc8e7b6aep+2);
  return 243238972;
}

void f769(char * x0, float x1, float x2, long long x3, char * x4, char * x5, long long x6, long long x7)
{
  check (strcmp(x0, "x") == 0);
  check (x1 == -0x1.f5b9e2p+1F);
  check (x2 == -0x1.521a34p+2F);
  check (x3 == -2195469846005911650);
  check (strcmp(x4, "") == 0);
  check (strcmp(x5, "r") == 0);
  check (x6 == 2050285094488922771);
  check (x7 == 2582965507208882820);
}

void f770(char * x0, long long x1, float x2, float x3, char * x4, char * x5, float x6)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 733878790102082196);
  check (x2 == -0x1.7edf5p+4F);
  check (x3 == -0x1.0333d6p+1F);
  check (strcmp(x4, "") == 0);
  check (strcmp(x5, "ro") == 0);
  check (x6 == -0x1.e6b56p+3F);
}

void f771(char * x0, long long x1, long long x2, long long x3, int x4, float x5)
{
  check (strcmp(x0, "ja") == 0);
  check (x1 == -8580452957776928631);
  check (x2 == 7551253078661079189);
  check (x3 == -3096887836211969871);
  check (x4 == -866300376);
  check (x5 == -0x1.8ffc2p+5F);
}

short f772(float x0)
{
  check (x0 == 0x1.268758p+4F);
  return 94778159;
}

void f773(long long x0, long long x1, char * x2, char * x3, double x4, int x5, int x6, int x7, double x8, long long x9)
{
  check (x0 == 3746714279648075138);
  check (x1 == -7765691591148172923);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "m") == 0);
  check (x4 == 0x1.ccb183052b1bp+4);
  check (x5 == 345655732);
  check (x6 == -1225501847);
  check (x7 == -1385858462);
  check (x8 == 0x1.59d07d4484344p+4);
  check (x9 == -5068816186302177969);
}

short f774(int x0, long long x1, float x2, double x3, float x4, int x5, char * x6, int x7)
{
  check (x0 == 642316485);
  check (x1 == -4176953204287430749);
  check (x2 == 0x1.25b96p+5F);
  check (x3 == -0x1.66392a38e98dp+1);
  check (x4 == -0x1.96ff2p+4F);
  check (x5 == 945447832);
  check (strcmp(x6, "tg") == 0);
  check (x7 == -610881620);
  return -162135737;
}

void f775(float x0, float x1, char * x2)
{
  check (x0 == -0x1.3b91f2p+5F);
  check (x1 == 0x1.2dfd04p+4F);
  check (strcmp(x2, "p") == 0);
}

void f776(void)
{
}

double f777(int x0)
{
  check (x0 == 1321363793);
  return 0x1.a22f4f94f391p+1;
}

float f778(void)
{
  return 0x1.eb64e72106278p+4;
}

unsigned short f779(long long x0)
{
  check (x0 == -2195258560322172453);
  return 223337836;
}

void f780(long long x0, char * x1, int x2, char * x3, double x4, int x5, char * x6, long long x7, float x8)
{
  check (x0 == 9159517181826829385);
  check (strcmp(x1, "xn") == 0);
  check (x2 == -144099797);
  check (strcmp(x3, "op") == 0);
  check (x4 == 0x1.3bd80b59ba924p+3);
  check (x5 == 483493017);
  check (strcmp(x6, "b") == 0);
  check (x7 == 2701097138697027612);
  check (x8 == -0x1.3998f8p+5F);
}

void f781(long long x0, long long x1, char * x2, long long x3, double x4, double x5, long long x6, int x7)
{
  check (x0 == -5383175227743470451);
  check (x1 == 2189022040572435127);
  check (strcmp(x2, "sw") == 0);
  check (x3 == -3356544786841404308);
  check (x4 == -0x1.9ab8ed49b8468p+3);
  check (x5 == -0x1.29f7d05ed5b48p+2);
  check (x6 == 7388660772947968617);
  check (x7 == 173731394);
}

int f782(int x0, double x1, double x2)
{
  check (x0 == 1342095235);
  check (x1 == -0x1.5aba189b6e1dp+5);
  check (x2 == 0x1.8d9a70bda2fbcp+5);
  return -1614640134;
}

void f783(long long x0, float x1, long long x2, float x3, float x4, double x5, long long x6, char * x7, long long x8, double x9)
{
  check (x0 == 3658730263521897646);
  check (x1 == -0x1.583cf6p+2F);
  check (x2 == -762252738820688586);
  check (x3 == -0x1.08cc38p+5F);
  check (x4 == 0x1.420ab8p+3F);
  check (x5 == -0x1.dd89e8be48f9cp+4);
  check (x6 == -7698359155154004701);
  check (strcmp(x7, "") == 0);
  check (x8 == -4837571043377909583);
  check (x9 == -0x1.88c6b0ef10d91p+5);
}

void f784(long long x0, char * x1, double x2, double x3)
{
  check (x0 == -586433137811365420);
  check (strcmp(x1, "ec") == 0);
  check (x2 == 0x1.a450f8d3a123p+4);
  check (x3 == 0x1.105380a4ce35ep+5);
}

float f785(char * x0)
{
  check (strcmp(x0, "o") == 0);
  return -0x1.dfd0acae70293p+4;
}

double f786(char * x0, int x1)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 1134722767);
  return -0x1.85240733e0911p+5;
}

void f787(long long x0, double x1, char * x2, double x3, long long x4, float x5)
{
  check (x0 == -5089208056666740400);
  check (x1 == -0x1.0299adaacdep+1);
  check (strcmp(x2, "y") == 0);
  check (x3 == 0x1.22e071350790cp+4);
  check (x4 == 7825952741526164361);
  check (x5 == 0x1.30aac2p+5F);
}

void f788(char * x0, long long x1, long long x2, float x3, double x4, long long x5, float x6, long long x7, double x8)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -7315699486770342807);
  check (x2 == -2282836788059700974);
  check (x3 == 0x1.6e83d2p+2F);
  check (x4 == -0x1.1e2ec1bb46ae2p+5);
  check (x5 == 3275105333968491987);
  check (x6 == -0x1.6115d2p+5F);
  check (x7 == 4532822945314332555);
  check (x8 == -0x1.b059a8bc7983p+1);
}

void f789(void)
{
}

int f790(int x0, char * x1, double x2, double x3, double x4, int x5, int x6, float x7, double x8, char * x9)
{
  check (x0 == -1590757241);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.52b3b9bc5da78p+3);
  check (x3 == 0x1.6eab768bf95d4p+3);
  check (x4 == -0x1.f0919d73ec5a8p+3);
  check (x5 == -543258928);
  check (x6 == 1554173480);
  check (x7 == -0x1.6c4a06p+0F);
  check (x8 == 0x1.aa76291e3e478p+4);
  check (strcmp(x9, "rv") == 0);
  return 1109161288;
}

float f791(double x0, float x1, float x2, int x3, double x4, char * x5, long long x6, double x7, int x8, float x9)
{
  check (x0 == -0x1.272312d5b1fbdp+5);
  check (x1 == 0x1.fd5124p+3F);
  check (x2 == -0x1.e10c12p+2F);
  check (x3 == -261216639);
  check (x4 == 0x1.0d6da7ac8c0d8p+3);
  check (strcmp(x5, "") == 0);
  check (x6 == -8280878902247320408);
  check (x7 == -0x1.07fda0d5e994ap+4);
  check (x8 == -1381252731);
  check (x9 == -0x1.0f42e6p+4F);
  return 0x1.44560317925acp+5;
}

float f792(void)
{
  return -0x1.7c1705dbc3756p+4;
}

char * f793(double x0)
{
  check (x0 == 0x1.f67fefeaa6d18p+2);
  return "id";
}

long long f794(double x0, float x1)
{
  check (x0 == 0x1.ff7526516d734p+4);
  check (x1 == 0x1.49f9d8p+5F);
  return 779798107511314629;
}

void f795(long long x0, long long x1, char * x2)
{
  check (x0 == -5064066873906159058);
  check (x1 == -2786278437797658304);
  check (strcmp(x2, "") == 0);
}

void f796(int x0, double x1)
{
  check (x0 == -1064028575);
  check (x1 == -0x1.88ea028b7b252p+5);
}

void f797(float x0, char * x1, long long x2, int x3)
{
  check (x0 == 0x1.ba4228p+3F);
  check (strcmp(x1, "x") == 0);
  check (x2 == 3823687016323376035);
  check (x3 == -949981575);
}

void f798(long long x0, int x1, float x2, double x3, float x4, char * x5, double x6, int x7, char * x8)
{
  check (x0 == -3298259187330559108);
  check (x1 == 981809093);
  check (x2 == -0x1.4c5dd2p+5F);
  check (x3 == -0x1.6ebdad3744483p+5);
  check (x4 == -0x1.4dafdcp+5F);
  check (strcmp(x5, "a") == 0);
  check (x6 == -0x1.175e131ae5ce7p+5);
  check (x7 == -1841168763);
  check (strcmp(x8, "") == 0);
}

float f799(int x0, float x1)
{
  check (x0 == 1104355363);
  check (x1 == 0x1.26ef7p+5F);
  return -0x1.9c00b55f5f85ap+4;
}

void f800(long long x0, float x1, double x2)
{
  check (x0 == -4438325502208871440);
  check (x1 == -0x1.2f4984p+5F);
  check (x2 == -0x1.2080bc6d1cf4dp+5);
}

unsigned short f801(void)
{
  return 227908814;
}

void f802(float x0, long long x1, int x2, int x3, char * x4, char * x5, int x6, double x7)
{
  check (x0 == 0x1.5c9c58p+5F);
  check (x1 == -7971007743378436273);
  check (x2 == -802622102);
  check (x3 == -1015063333);
  check (strcmp(x4, "f") == 0);
  check (strcmp(x5, "") == 0);
  check (x6 == 717880731);
  check (x7 == -0x1.59a3b73c9a9e6p+5);
}

void f803(void)
{
}

void f804(int x0, int x1, int x2, char * x3, int x4)
{
  check (x0 == -1548073484);
  check (x1 == 971088147);
  check (x2 == 1310307708);
  check (strcmp(x3, "o") == 0);
  check (x4 == -1810631331);
}

void f805(void)
{
}

long long f806(float x0, int x1, float x2, int x3, double x4, float x5, float x6)
{
  check (x0 == 0x1.00f87ep+5F);
  check (x1 == 1431002145);
  check (x2 == 0x1.9632c8p+3F);
  check (x3 == 1837631332);
  check (x4 == -0x1.2538e9e40ebcp+2);
  check (x5 == -0x1.5d383cp+4F);
  check (x6 == -0x1.e6667ap+4F);
  return -1196731127726268288;
}

unsigned char f807(char * x0, int x1, char * x2, long long x3, char * x4, long long x5, long long x6, int x7, char * x8, double x9, long long x10)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -1589761881);
  check (strcmp(x2, "im") == 0);
  check (x3 == 6838838319401205344);
  check (strcmp(x4, "sj") == 0);
  check (x5 == -7903661603535612455);
  check (x6 == 9003263696869382472);
  check (x7 == -1619565363);
  check (strcmp(x8, "r") == 0);
  check (x9 == -0x1.d8bf141020478p+2);
  check (x10 == -1364964126876223084);
  return 309565294;
}

void f808(double x0, long long x1, float x2, float x3, char * x4, int x5, double x6, float x7, float x8, int x9)
{
  check (x0 == -0x1.863576e9d657cp+4);
  check (x1 == 8117073938869951663);
  check (x2 == 0x1.d164a8p+4F);
  check (x3 == -0x1.84a4fcp+5F);
  check (strcmp(x4, "xv") == 0);
  check (x5 == 141993168);
  check (x6 == -0x1.95c268164c398p+3);
  check (x7 == 0x1.7db732p+3F);
  check (x8 == 0x1.b7263p+4F);
  check (x9 == -347995018);
}

void f809(char * x0, char * x1, long long x2, double x3, float x4, float x5)
{
  check (strcmp(x0, "tv") == 0);
  check (strcmp(x1, "b") == 0);
  check (x2 == 1486680866424042762);
  check (x3 == 0x1.0280449d5c108p+5);
  check (x4 == 0x1.30a33p+4F);
  check (x5 == 0x1.495f3cp+5F);
}

float f810(double x0, float x1, double x2, int x3)
{
  check (x0 == 0x1.e05866031c0acp+4);
  check (x1 == 0x1.e6cd7cp+4F);
  check (x2 == -0x1.3c1789ea35f8ap+5);
  check (x3 == -1072056760);
  return -0x1.3207f30e7b0edp+5;
}

unsigned char f811(void)
{
  return -127589952;
}

char * f812(long long x0, long long x1, float x2, double x3, int x4, float x5)
{
  check (x0 == -1770364705766099551);
  check (x1 == 8214329941618885868);
  check (x2 == 0x1.15cff2p+2F);
  check (x3 == -0x1.58a5271c6e5dp+5);
  check (x4 == 1085092104);
  check (x5 == -0x1.6d329p+1F);
  return "";
}

unsigned char f813(long long x0, int x1, int x2, long long x3, char * x4, char * x5, char * x6, double x7, float x8, char * x9, char * x10)
{
  check (x0 == 1829450013869637312);
  check (x1 == 1092809248);
  check (x2 == 2071298591);
  check (x3 == 6752608868674379438);
  check (strcmp(x4, "eu") == 0);
  check (strcmp(x5, "di") == 0);
  check (strcmp(x6, "pg") == 0);
  check (x7 == -0x1.c8a257562179p+2);
  check (x8 == -0x1.3f42b2p+3F);
  check (strcmp(x9, "lq") == 0);
  check (strcmp(x10, "") == 0);
  return -237312613;
}

signed char f814(long long x0, double x1, double x2, char * x3, double x4, float x5, float x6, char * x7, double x8)
{
  check (x0 == -8046525426970221834);
  check (x1 == -0x1.145a0ef6ea90ap+5);
  check (x2 == -0x1.63141a52b350bp+5);
  check (strcmp(x3, "h") == 0);
  check (x4 == 0x1.c3701a81e83p+4);
  check (x5 == -0x1.d255bp+3F);
  check (x6 == 0x1.956848p+4F);
  check (strcmp(x7, "") == 0);
  check (x8 == -0x1.897e9a54d5984p+3);
  return -249301055;
}

char * f815(double x0, int x1, int x2, long long x3, float x4, int x5, char * x6)
{
  check (x0 == -0x1.feed409dcaa13p+4);
  check (x1 == 726982612);
  check (x2 == -874679864);
  check (x3 == -4826381314121441090);
  check (x4 == 0x1.268fbp+3F);
  check (x5 == 120031615);
  check (strcmp(x6, "zt") == 0);
  return "v";
}

void f816(char * x0)
{
  check (strcmp(x0, "") == 0);
}

short f817(double x0, float x1)
{
  check (x0 == -0x1.0db43bf9b907p+5);
  check (x1 == -0x1.3e72fp+5F);
  return 56160042;
}

void f818(float x0, int x1, char * x2, char * x3, char * x4, double x5)
{
  check (x0 == 0x1.777cbp+3F);
  check (x1 == -548874152);
  check (strcmp(x2, "c") == 0);
  check (strcmp(x3, "s") == 0);
  check (strcmp(x4, "ic") == 0);
  check (x5 == -0x1.58f844d968ffap+4);
}

short f819(int x0, long long x1, int x2, float x3)
{
  check (x0 == -1411809494);
  check (x1 == 5410897577737955533);
  check (x2 == 1500564103);
  check (x3 == -0x1.e499a4p+3F);
  return -338961736;
}

void f820(char * x0, float x1, long long x2, char * x3, int x4, long long x5, double x6)
{
  check (strcmp(x0, "s") == 0);
  check (x1 == 0x1.293c96p+4F);
  check (x2 == -1766277041554936180);
  check (strcmp(x3, "xl") == 0);
  check (x4 == 403742771);
  check (x5 == 5201456196349807378);
  check (x6 == 0x1.f8f10446e045p+4);
}

void f821(double x0, char * x1, int x2, long long x3)
{
  check (x0 == -0x1.72894accb8437p+5);
  check (strcmp(x1, "x") == 0);
  check (x2 == -1345273455);
  check (x3 == 6219540297639864963);
}

void f822(float x0)
{
  check (x0 == -0x1.0f4042p+4F);
}

void f823(float x0, int x1, double x2, char * x3, int x4, char * x5)
{
  check (x0 == -0x1.6ce2a8p+5F);
  check (x1 == 2008430727);
  check (x2 == -0x1.7c2802cd99e5ep+5);
  check (strcmp(x3, "zj") == 0);
  check (x4 == -69733286);
  check (strcmp(x5, "r") == 0);
}

void f824(long long x0)
{
  check (x0 == 4034572877824064164);
}

unsigned short f825(char * x0)
{
  check (strcmp(x0, "v") == 0);
  return -504676439;
}

void f826(float x0, long long x1, float x2, long long x3)
{
  check (x0 == 0x1.b5262p-2F);
  check (x1 == -3449321290575507291);
  check (x2 == -0x1.47dc4p+5F);
  check (x3 == 5371107002236083960);
}

void f827(double x0, int x1, float x2, long long x3, float x4)
{
  check (x0 == 0x1.6b04696e1881cp+4);
  check (x1 == 1812589243);
  check (x2 == -0x1.ad5d6cp+4F);
  check (x3 == -6832354984686082239);
  check (x4 == 0x1.7cf5ecp+3F);
}

void f828(double x0, int x1, char * x2, double x3, float x4, char * x5)
{
  check (x0 == -0x1.58b657974cf0dp+4);
  check (x1 == 244953010);
  check (strcmp(x2, "q") == 0);
  check (x3 == -0x1.0915d03d8283p+3);
  check (x4 == -0x1.7a2348p+5F);
  check (strcmp(x5, "ad") == 0);
}

void f829(float x0, char * x1, long long x2, long long x3, int x4, int x5, long long x6, int x7, double x8)
{
  check (x0 == -0x1.7661e4p+5F);
  check (strcmp(x1, "fv") == 0);
  check (x2 == -2425869244969490231);
  check (x3 == 4052350698377283552);
  check (x4 == 1351187923);
  check (x5 == -953636182);
  check (x6 == -3346768091876526334);
  check (x7 == -1301708619);
  check (x8 == -0x1.b05ff04838e9cp+3);
}

unsigned short f830(float x0, char * x1, char * x2, char * x3, int x4, long long x5, double x6, char * x7)
{
  check (x0 == 0x1.f09e72p+3F);
  check (strcmp(x1, "rw") == 0);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "") == 0);
  check (x4 == -581389998);
  check (x5 == -8102496600985539800);
  check (x6 == 0x1.e2d28b8151e6p+3);
  check (strcmp(x7, "ev") == 0);
  return 183860105;
}

void f831(float x0, char * x1, long long x2, long long x3, long long x4, char * x5, float x6, int x7, double x8, float x9)
{
  check (x0 == -0x1.2a184p+5F);
  check (strcmp(x1, "") == 0);
  check (x2 == -247483365999987242);
  check (x3 == 764537077410662);
  check (x4 == 6725424127452256704);
  check (strcmp(x5, "o") == 0);
  check (x6 == 0x1.3672a2p+4F);
  check (x7 == 692530128);
  check (x8 == 0x1.1262957c1894p+5);
  check (x9 == 0x1.71949cp+3F);
}

void f832(long long x0, long long x1, double x2, long long x3, float x4, long long x5)
{
  check (x0 == -3459792654184079361);
  check (x1 == -5101190882443680307);
  check (x2 == -0x1.101f48f604072p+4);
  check (x3 == 1480078745351155385);
  check (x4 == -0x1.b8c9a8p+2F);
  check (x5 == 131239646152875578);
}

void f833(long long x0, long long x1, char * x2, double x3)
{
  check (x0 == -2676661765287544960);
  check (x1 == -2950463006323671709);
  check (strcmp(x2, "z") == 0);
  check (x3 == 0x1.ab326a1155394p+3);
}

void f834(double x0, long long x1, double x2, long long x3, float x4, double x5, float x6, int x7, float x8)
{
  check (x0 == -0x1.2f09e5b707a1ep+4);
  check (x1 == 4337537870870156605);
  check (x2 == -0x1.d1f96d886adp-3);
  check (x3 == 2130713337298332517);
  check (x4 == 0x1.821c12p+5F);
  check (x5 == -0x1.06debece9f29p+3);
  check (x6 == -0x1.1287dep+3F);
  check (x7 == 81799896);
  check (x8 == 0x1.72bcf6p+5F);
}

signed char f835(int x0, long long x1)
{
  check (x0 == -520725076);
  check (x1 == -5523720437646673030);
  return 322449424;
}

long long f836(char * x0, int x1, double x2, char * x3, int x4, int x5, long long x6, int x7)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -625320957);
  check (x2 == 0x1.1aa9d4757bb7cp+4);
  check (strcmp(x3, "bs") == 0);
  check (x4 == 2027270162);
  check (x5 == -1145445923);
  check (x6 == -245139832763243504);
  check (x7 == -1991081556);
  return -3375601568554227481;
}

double f837(double x0, long long x1, long long x2, long long x3, double x4, long long x5, double x6, double x7)
{
  check (x0 == 0x1.839701acf1098p+5);
  check (x1 == -1139108323176646199);
  check (x2 == 4083867511713434942);
  check (x3 == -7757445142144787460);
  check (x4 == -0x1.0233101bcce8ap+4);
  check (x5 == -5028268041588923476);
  check (x6 == 0x1.0ead23053e27p+4);
  check (x7 == -0x1.c8cd53fbd2993p+4);
  return -0x1.09e008c317889p+5;
}

signed char f838(double x0, char * x1, int x2, double x3, char * x4, float x5, char * x6)
{
  check (x0 == 0x1.6d963666dd2aep+5);
  check (strcmp(x1, "z") == 0);
  check (x2 == 1427610071);
  check (x3 == -0x1.57177ddae7b46p+5);
  check (strcmp(x4, "") == 0);
  check (x5 == 0x1.80bd18p+2F);
  check (strcmp(x6, "") == 0);
  return -424721380;
}

void f839(void)
{
}

void f840(double x0, double x1, float x2, float x3, float x4, int x5)
{
  check (x0 == -0x1.5312beb49607fp+4);
  check (x1 == -0x1.30ac0642f4a1cp+3);
  check (x2 == -0x1.4cfd36p+4F);
  check (x3 == 0x1.189476p+5F);
  check (x4 == -0x1.b271bap+4F);
  check (x5 == -950896432);
}

void f841(char * x0, double x1, float x2, float x3, int x4, int x5, int x6, char * x7, int x8, long long x9, float x10)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 0x1.3c95ba4f09d64p+3);
  check (x2 == 0x1.c0c328p+3F);
  check (x3 == 0x1.8fb5a4p+4F);
  check (x4 == 1908975104);
  check (x5 == -105745093);
  check (x6 == 1090196921);
  check (strcmp(x7, "") == 0);
  check (x8 == -1454252246);
  check (x9 == -7292777206674232171);
  check (x10 == -0x1.0ebc24p+5F);
}

short f842(double x0, char * x1, double x2, double x3, int x4, float x5, long long x6, long long x7)
{
  check (x0 == -0x1.8d05933b7ab2ep+5);
  check (strcmp(x1, "") == 0);
  check (x2 == -0x1.58e6a2c564ddp+3);
  check (x3 == 0x1.24c7473a01bd2p+5);
  check (x4 == 1448498223);
  check (x5 == -0x1.963d52p+4F);
  check (x6 == -5874616703280485656);
  check (x7 == 910208228928336757);
  return 144127968;
}

void f843(char * x0, long long x1, int x2, float x3)
{
  check (strcmp(x0, "pf") == 0);
  check (x1 == -5359720914691890955);
  check (x2 == -107880661);
  check (x3 == 0x1.09191ep+5F);
}

unsigned short f844(double x0, long long x1, char * x2, float x3, int x4, long long x5, int x6, double x7, float x8)
{
  check (x0 == 0x1.7ed9ece57cd8ep+5);
  check (x1 == -8013775107814888734);
  check (strcmp(x2, "sg") == 0);
  check (x3 == 0x1.01eb78p+5F);
  check (x4 == 1224569730);
  check (x5 == 7774612738340171328);
  check (x6 == 2046414756);
  check (x7 == 0x1.15d6bd60bfdc6p+5);
  check (x8 == -0x1.45e98cp+0F);
  return 68121184;
}

signed char f845(double x0, int x1, double x2)
{
  check (x0 == 0x1.2f240463c4978p+4);
  check (x1 == 1922958182);
  check (x2 == 0x1.77ea6b74b717p+4);
  return -331455675;
}

void f846(void)
{
}

void f847(double x0, char * x1, int x2)
{
  check (x0 == -0x1.3b44dfe05a1bp+5);
  check (strcmp(x1, "sm") == 0);
  check (x2 == -611999151);
}

void f848(int x0, char * x1, int x2, double x3, int x4, char * x5, double x6, long long x7, int x8, double x9, int x10)
{
  check (x0 == -558405896);
  check (strcmp(x1, "") == 0);
  check (x2 == -1555328641);
  check (x3 == 0x1.0d8418e72bd6cp+5);
  check (x4 == -1079881638);
  check (strcmp(x5, "") == 0);
  check (x6 == 0x1.fe9fff48eb4e4p+4);
  check (x7 == -1570032224626514390);
  check (x8 == 861449493);
  check (x9 == -0x1.c06f83a90a99p+2);
  check (x10 == 526517187);
}

unsigned short f849(char * x0, double x1, char * x2, long long x3, double x4, char * x5)
{
  check (strcmp(x0, "x") == 0);
  check (x1 == -0x1.6128e9b9c17eap+4);
  check (strcmp(x2, "b") == 0);
  check (x3 == 1138902070332422790);
  check (x4 == -0x1.f6fa6a2c62606p+4);
  check (strcmp(x5, "") == 0);
  return -153664137;
}

double f850(float x0, int x1, int x2)
{
  check (x0 == 0x1.0cf2ap+4F);
  check (x1 == -803754728);
  check (x2 == 7124874);
  return 0x1.fdc20b9c8e97p+3;
}

float f851(char * x0)
{
  check (strcmp(x0, "gn") == 0);
  return 0x1.689afef5d6a44p+5;
}

unsigned char f852(char * x0, double x1)
{
  check (strcmp(x0, "ts") == 0);
  check (x1 == 0x1.238802904462p+5);
  return -213140381;
}

int f853(int x0, int x1, float x2, int x3, float x4, long long x5, long long x6, double x7, double x8, int x9)
{
  check (x0 == 515341926);
  check (x1 == -1860971214);
  check (x2 == -0x1.45d426p+5F);
  check (x3 == 750931182);
  check (x4 == -0x1.8fe944p+5F);
  check (x5 == -1150862592157861352);
  check (x6 == 8171331784233314274);
  check (x7 == 0x1.52d530fbd82c8p+2);
  check (x8 == -0x1.bfd265ad4ef8dp+4);
  check (x9 == 149608997);
  return -1480505480;
}

void f854(int x0, int x1, double x2)
{
  check (x0 == -1334759686);
  check (x1 == 497545491);
  check (x2 == 0x1.7c3c219567b94p+5);
}

void f855(float x0, double x1)
{
  check (x0 == 0x1.239ebep+5F);
  check (x1 == 0x1.256848868e75p+3);
}

double f856(int x0, char * x1, long long x2, float x3)
{
  check (x0 == -771937132);
  check (strcmp(x1, "ry") == 0);
  check (x2 == 4040619702412822684);
  check (x3 == 0x1.0b767p+2F);
  return 0x1.6e47f5e772cf8p+3;
}

short f857(long long x0, long long x1, int x2, int x3, double x4, char * x5, double x6, char * x7, long long x8)
{
  check (x0 == -4691332300301051343);
  check (x1 == 4690807434123943483);
  check (x2 == 1820153989);
  check (x3 == 903568965);
  check (x4 == -0x1.f93ad6ea99a9p+4);
  check (strcmp(x5, "xp") == 0);
  check (x6 == -0x1.9639cf8ac7c7cp+3);
  check (strcmp(x7, "q") == 0);
  check (x8 == 2851604057760065252);
  return 124612994;
}

void f858(int x0, float x1, double x2, float x3, long long x4, float x5, char * x6, char * x7, long long x8, float x9, int x10)
{
  check (x0 == -1050697107);
  check (x1 == 0x1.49f386p+5F);
  check (x2 == 0x1.e7efb10195274p+4);
  check (x3 == -0x1.7e190cp+5F);
  check (x4 == -7749849798186912956);
  check (x5 == -0x1.557b82p+5F);
  check (strcmp(x6, "o") == 0);
  check (strcmp(x7, "fd") == 0);
  check (x8 == -396150207398090682);
  check (x9 == 0x1.72f5cp+3F);
  check (x10 == 240879558);
}

char * f859(double x0)
{
  check (x0 == 0x1.204a51ca68ea8p+4);
  return "u";
}

signed char f860(long long x0, float x1, float x2, float x3, double x4, double x5, float x6, int x7)
{
  check (x0 == -6179818123857351661);
  check (x1 == 0x1.d1294ep+4F);
  check (x2 == 0x1.000006p-3F);
  check (x3 == -0x1.aa199p+0F);
  check (x4 == -0x1.73ffb5bfcbc08p+5);
  check (x5 == 0x1.77b83567872bcp+5);
  check (x6 == 0x1.18e152p+3F);
  check (x7 == -1909807372);
  return -22682121;
}

void f861(int x0, float x1)
{
  check (x0 == 244509094);
  check (x1 == -0x1.59ab76p+2F);
}

void f862(long long x0, long long x1, float x2, float x3, float x4, int x5, long long x6)
{
  check (x0 == 8927856377232355405);
  check (x1 == -4657642202948041763);
  check (x2 == 0x1.cbf60ep+3F);
  check (x3 == 0x1.e36b2p+4F);
  check (x4 == 0x1.74a2d2p+3F);
  check (x5 == 2110945498);
  check (x6 == 777501587982027349);
}

unsigned char f863(double x0, float x1)
{
  check (x0 == -0x1.ae1d803c6df98p+3);
  check (x1 == 0x1.d0ae56p+4F);
  return 333613330;
}

void f864(void)
{
}

void f865(int x0, int x1)
{
  check (x0 == -658567922);
  check (x1 == 143960784);
}

void f866(char * x0, int x1, float x2, long long x3, int x4, char * x5, float x6, int x7, float x8, float x9)
{
  check (strcmp(x0, "ig") == 0);
  check (x1 == -213558217);
  check (x2 == 0x1.a41eecp+3F);
  check (x3 == 5593926311399131027);
  check (x4 == 1351570675);
  check (strcmp(x5, "ib") == 0);
  check (x6 == -0x1.2df8fcp+4F);
  check (x7 == 1621347045);
  check (x8 == 0x1.bc41a2p+3F);
  check (x9 == -0x1.6f1ed6p+5F);
}

void f867(char * x0, double x1, float x2, long long x3)
{
  check (strcmp(x0, "ce") == 0);
  check (x1 == -0x1.5ae92ba7fa10ep+4);
  check (x2 == -0x1.1a4a88p+5F);
  check (x3 == 2638565851646001785);
}

void f868(char * x0)
{
  check (strcmp(x0, "u") == 0);
}

void f869(char * x0, double x1, char * x2, int x3, char * x4, double x5, char * x6, int x7, long long x8)
{
  check (strcmp(x0, "") == 0);
  check (x1 == 0x1.c6644249bb63p+3);
  check (strcmp(x2, "ik") == 0);
  check (x3 == -1167404195);
  check (strcmp(x4, "km") == 0);
  check (x5 == 0x1.fed077ad25a9p+4);
  check (strcmp(x6, "") == 0);
  check (x7 == -222053476);
  check (x8 == -4394534971716941124);
}

int f870(char * x0, double x1, long long x2, int x3)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -0x1.c9eb02682e57p+1);
  check (x2 == 9076425064247153765);
  check (x3 == 2067144261);
  return -1834315133;
}

void f871(long long x0)
{
  check (x0 == -3743705664185492699);
}

void f872(float x0, char * x1, float x2, float x3, int x4)
{
  check (x0 == -0x1.0a02ep+4F);
  check (strcmp(x1, "kd") == 0);
  check (x2 == 0x1.669c4p+5F);
  check (x3 == -0x1.4d45bp+5F);
  check (x4 == -420101495);
}

void f873(char * x0, char * x1, long long x2, double x3, char * x4, int x5, int x6, float x7, char * x8, char * x9)
{
  check (strcmp(x0, "lw") == 0);
  check (strcmp(x1, "") == 0);
  check (x2 == 3788247615926648726);
  check (x3 == 0x1.6e6c8cb99656p+3);
  check (strcmp(x4, "") == 0);
  check (x5 == -2103722223);
  check (x6 == -777238423);
  check (x7 == 0x1.669b1ep+5F);
  check (strcmp(x8, "o") == 0);
  check (strcmp(x9, "") == 0);
}

int f874(char * x0, char * x1, double x2)
{
  check (strcmp(x0, "j") == 0);
  check (strcmp(x1, "") == 0);
  check (x2 == 0x1.14e4ce7e598acp+3);
  return -1481223426;
}

int f875(long long x0, int x1, int x2, char * x3, float x4, char * x5, float x6)
{
  check (x0 == -5239875721579740148);
  check (x1 == -1635621204);
  check (x2 == -1764782236);
  check (strcmp(x3, "m") == 0);
  check (x4 == -0x1.4c6baep+4F);
  check (strcmp(x5, "x") == 0);
  check (x6 == -0x1.e38e4p+4F);
  return 1897100905;
}

int f876(char * x0, long long x1)
{
  check (strcmp(x0, "w") == 0);
  check (x1 == -1017899302790885832);
  return -176678215;
}

short f877(double x0, float x1, long long x2, long long x3, double x4, char * x5, long long x6, char * x7, long long x8, double x9)
{
  check (x0 == -0x1.a402b97d26d9cp+3);
  check (x1 == 0x1.4c9ba6p+5F);
  check (x2 == -1618582805333264312);
  check (x3 == -2111173562457170729);
  check (x4 == 0x1.6d86ed18fc018p+3);
  check (strcmp(x5, "e") == 0);
  check (x6 == -5835270319391887635);
  check (strcmp(x7, "y") == 0);
  check (x8 == 170486075799396288);
  check (x9 == 0x1.cb89616cd1aep+3);
  return -375820547;
}

void f878(float x0, double x1, int x2, double x3, int x4, long long x5)
{
  check (x0 == -0x1.92ccdcp+4F);
  check (x1 == 0x1.d9a110cfe1aep+3);
  check (x2 == 843248153);
  check (x3 == 0x1.bf6f0b50dbc78p+4);
  check (x4 == -1630605678);
  check (x5 == -3551820415930537204);
}

void f879(char * x0, char * x1, float x2, int x3, long long x4)
{
  check (strcmp(x0, "vb") == 0);
  check (strcmp(x1, "") == 0);
  check (x2 == -0x1.d39b52p+4F);
  check (x3 == -540178546);
  check (x4 == 9220487526464789609);
}

void f880(double x0, char * x1, int x2, char * x3)
{
  check (x0 == -0x1.ebd0bb9358f5p+3);
  check (strcmp(x1, "") == 0);
  check (x2 == 536713531);
  check (strcmp(x3, "nw") == 0);
}

void f881(void)
{
}

int f882(float x0)
{
  check (x0 == 0x1.2a0dbep+0F);
  return 336258132;
}

void f883(double x0, long long x1)
{
  check (x0 == 0x1.c488d954a6974p+4);
  check (x1 == 585616867225905703);
}

void f884(long long x0, char * x1)
{
  check (x0 == -8918611777954991308);
  check (strcmp(x1, "") == 0);
}

void f885(float x0)
{
  check (x0 == -0x1.b8d806p+4F);
}

unsigned char f886(int x0, char * x1, long long x2, long long x3, float x4, long long x5, float x6, double x7, float x8, int x9)
{
  check (x0 == 150770032);
  check (strcmp(x1, "r") == 0);
  check (x2 == -5118713274917623970);
  check (x3 == 4305780758304240906);
  check (x4 == 0x1.412d6cp+4F);
  check (x5 == -3183950244501470655);
  check (x6 == 0x1.5013f8p+5F);
  check (x7 == -0x1.582bbc4c98dccp+4);
  check (x8 == 0x1.f29216p+1F);
  check (x9 == -1925607369);
  return -522859600;
}

void f887(void)
{
}

float f888(double x0, char * x1, long long x2, long long x3, long long x4, int x5, long long x6)
{
  check (x0 == 0x1.81e52638d9808p+4);
  check (strcmp(x1, "") == 0);
  check (x2 == 2424120821920988422);
  check (x3 == 7383977670089605577);
  check (x4 == -5850972608992761469);
  check (x5 == -1912741063);
  check (x6 == 2805642219292892723);
  return 0x1.5a5645474efp+4;
}

long long f889(float x0, long long x1, double x2, long long x3, long long x4, double x5, int x6, double x7, double x8, float x9, int x10)
{
  check (x0 == 0x1.043e72p+4F);
  check (x1 == -4857765425189679978);
  check (x2 == -0x1.17ff0784ee08cp+5);
  check (x3 == 7069401775769908531);
  check (x4 == 6842800105220457250);
  check (x5 == 0x1.b80ad7f399b58p+2);
  check (x6 == 1079442871);
  check (x7 == -0x1.8104c1603f356p+5);
  check (x8 == -0x1.8eeea47eb541p+3);
  check (x9 == -0x1.657c64p+5F);
  check (x10 == 192316513);
  return -5746221358603426678;
}

void f890(char * x0)
{
  check (strcmp(x0, "") == 0);
}

void f891(double x0, int x1, float x2, long long x3, float x4)
{
  check (x0 == 0x1.c5d383f9a002p+0);
  check (x1 == -223166002);
  check (x2 == -0x1.45cc8cp+5F);
  check (x3 == 150370906060416310);
  check (x4 == 0x1.4c1ddp+5F);
}

char * f892(long long x0, int x1, long long x2, float x3, int x4, int x5, double x6)
{
  check (x0 == 2006782639062100641);
  check (x1 == -416427089);
  check (x2 == 2868580125326523885);
  check (x3 == -0x1.5420a8p+1F);
  check (x4 == -1585876838);
  check (x5 == -1276800099);
  check (x6 == -0x1.988351fb001cp+1);
  return "";
}

char * f893(float x0, long long x1, float x2, int x3)
{
  check (x0 == 0x1.28c2p+4F);
  check (x1 == 7582969178821155840);
  check (x2 == -0x1.52ff0cp+0F);
  check (x3 == -725722876);
  return "";
}

unsigned short f894(long long x0, int x1, long long x2)
{
  check (x0 == -3936354747560077868);
  check (x1 == -1367911873);
  check (x2 == 3214319360900201481);
  return -77947482;
}

void f895(int x0, double x1, long long x2, long long x3, float x4, int x5, double x6, double x7, float x8, double x9, int x10)
{
  check (x0 == -275271311);
  check (x1 == 0x1.8f176c4709c9ap+5);
  check (x2 == -4390948521351229682);
  check (x3 == -8093103300582402205);
  check (x4 == -0x1.48c4fp+3F);
  check (x5 == -34402090);
  check (x6 == -0x1.3db35f93821cap+5);
  check (x7 == -0x1.759296c4d686ep+4);
  check (x8 == 0x1.6f253p+5F);
  check (x9 == 0x1.32a7c6e29b53cp+5);
  check (x10 == 1886701179);
}

void f896(long long x0, float x1, long long x2, double x3, char * x4, float x5)
{
  check (x0 == 994564336601689501);
  check (x1 == 0x1.1d923p+5F);
  check (x2 == 7791722256667529060);
  check (x3 == -0x1.e53b09b36fd66p+4);
  check (strcmp(x4, "tr") == 0);
  check (x5 == -0x1.e11088p+4F);
}

void f897(char * x0, float x1, int x2, long long x3, double x4, int x5)
{
  check (strcmp(x0, "q") == 0);
  check (x1 == 0x1.0f3cccp+5F);
  check (x2 == -1107306677);
  check (x3 == 4209063472830267978);
  check (x4 == -0x1.d35f71713d37cp+3);
  check (x5 == -1796014899);
}

int f898(char * x0, char * x1)
{
  check (strcmp(x0, "vu") == 0);
  check (strcmp(x1, "") == 0);
  return 1282023088;
}

char * f899(int x0, long long x1)
{
  check (x0 == 1059883812);
  check (x1 == -7206068211191531783);
  return "";
}

void f900(float x0)
{
  check (x0 == -0x1.8c55a2p+5F);
}

void f901(int x0, float x1, char * x2, char * x3, double x4, double x5, long long x6, float x7, int x8, int x9)
{
  check (x0 == 391446890);
  check (x1 == 0x1.cfab36p+4F);
  check (strcmp(x2, "") == 0);
  check (strcmp(x3, "") == 0);
  check (x4 == -0x1.fe18449463b9fp+4);
  check (x5 == -0x1.0aa3ee83f6e66p+4);
  check (x6 == -4627844753732015515);
  check (x7 == 0x1.943f06p+4F);
  check (x8 == 1018520118);
  check (x9 == -1207116149);
}

void f902(void)
{
}

signed char f903(float x0, float x1, char * x2)
{
  check (x0 == -0x1.11379cp+3F);
  check (x1 == -0x1.61432ep+5F);
  check (strcmp(x2, "") == 0);
  return -496879417;
}

void f904(float x0, double x1, char * x2, float x3, double x4, double x5)
{
  check (x0 == 0x1.8874p+5F);
  check (x1 == -0x1.12bc2d0b37a2cp+4);
  check (strcmp(x2, "qe") == 0);
  check (x3 == 0x1.650f1ap+5F);
  check (x4 == 0x1.05e75d4b50a98p+4);
  check (x5 == -0x1.2f4b8eb970883p+5);
}

int f905(long long x0, float x1, char * x2, double x3, double x4, double x5, int x6)
{
  check (x0 == 4156285888677321556);
  check (x1 == 0x1.848f32p+5F);
  check (strcmp(x2, "us") == 0);
  check (x3 == 0x1.2514de569b972p+5);
  check (x4 == -0x1.f8e920d918e48p+3);
  check (x5 == -0x1.fece2ae34eb08p+3);
  check (x6 == 627543581);
  return 120727122;
}

void f906(double x0, float x1, char * x2, float x3, int x4, char * x5, double x6)
{
  check (x0 == -0x1.674282e3ae065p+5);
  check (x1 == -0x1.1b5d9cp+5F);
  check (strcmp(x2, "mg") == 0);
  check (x3 == -0x1.299dc8p+4F);
  check (x4 == -1834192665);
  check (strcmp(x5, "") == 0);
  check (x6 == 0x1.f447ef5625ef8p+4);
}

float f907(double x0, double x1, char * x2, float x3, double x4, double x5, long long x6, long long x7)
{
  check (x0 == -0x1.b2e1636eac39p+1);
  check (x1 == -0x1.f79af0fc7edf6p+4);
  check (strcmp(x2, "e") == 0);
  check (x3 == -0x1.72b352p+5F);
  check (x4 == 0x1.a986af0b5b658p+4);
  check (x5 == -0x1.8df12b6892b3p+3);
  check (x6 == 1927172882496963631);
  check (x7 == 1881738861561805212);
  return -0x1.421456603d9dp+4;
}

void f908(char * x0, char * x1)
{
  check (strcmp(x0, "u") == 0);
  check (strcmp(x1, "") == 0);
}

short f909(int x0)
{
  check (x0 == -1990191353);
  return 285582128;
}

void f910(char * x0)
{
  check (strcmp(x0, "") == 0);
}

long long f911(long long x0, int x1, long long x2, float x3, char * x4, int x5, int x6)
{
  check (x0 == -618625183169091885);
  check (x1 == -702968197);
  check (x2 == 7509454858955511547);
  check (x3 == 0x1.69945cp+5F);
  check (strcmp(x4, "m") == 0);
  check (x5 == 663574653);
  check (x6 == -1545360814);
  return 1287780292406983608;
}

void f912(int x0, char * x1, int x2)
{
  check (x0 == 55773943);
  check (strcmp(x1, "") == 0);
  check (x2 == 435706122);
}

void f913(int x0, double x1)
{
  check (x0 == -946617799);
  check (x1 == 0x1.c9ee10f24855p+2);
}

void f914(float x0, double x1)
{
  check (x0 == 0x1.aa146p+4F);
  check (x1 == 0x1.ee6ffbc6da26p+0);
}

void f915(float x0, long long x1, int x2, long long x3, long long x4)
{
  check (x0 == 0x1.f1305ep+1F);
  check (x1 == 3695267263264053686);
  check (x2 == -1710866234);
  check (x3 == -6232490480648844681);
  check (x4 == 3607500200840641504);
}

short f916(char * x0, double x1, long long x2)
{
  check (strcmp(x0, "dx") == 0);
  check (x1 == -0x1.464124fbf8c4dp+5);
  check (x2 == -8576173029004686167);
  return 58583133;
}

int f917(char * x0, float x1, int x2)
{
  check (strcmp(x0, "gz") == 0);
  check (x1 == 0x1.5b2272p+5F);
  check (x2 == 1523920409);
  return 1440209601;
}

void f918(long long x0, int x1, float x2, double x3, int x4, long long x5, float x6)
{
  check (x0 == -3023042967722714389);
  check (x1 == -2039896299);
  check (x2 == 0x1.9f8258p+4F);
  check (x3 == -0x1.5afb2aefb0702p+4);
  check (x4 == -1260781545);
  check (x5 == 6757479923712449351);
  check (x6 == -0x1.0d277ep+4F);
}

int f919(char * x0, float x1, double x2, double x3, float x4, char * x5, long long x6, char * x7, char * x8, double x9, long long x10)
{
  check (strcmp(x0, "") == 0);
  check (x1 == -0x1.1b765p+4F);
  check (x2 == -0x1.e79477b1cefe8p+4);
  check (x3 == 0x1.9aa8fe96c9f08p+3);
  check (x4 == -0x1.77316ap+5F);
  check (strcmp(x5, "") == 0);
  check (x6 == -6041627031329776775);
  check (strcmp(x7, "p") == 0);
  check (strcmp(x8, "") == 0);
  check (x9 == -0x1.23db07a380cfp+1);
  check (x10 == 1044190138764007161);
  return 309810381;
}

void f920(long long x0, int x1, char * x2, float x3, double x4, float x5, int x6, int x7, double x8, int x9)
{
  check (x0 == 7846242801004324174);
  check (x1 == 1866800586);
  check (strcmp(x2, "gu") == 0);
  check (x3 == -0x1.779ef8p+2F);
  check (x4 == -0x1.0d67087590236p+5);
  check (x5 == -0x1.cb937ep+3F);
  check (x6 == 457947584);
  check (x7 == 417502295);
  check (x8 == 0x1.3f4f4276ccfep+5);
  check (x9 == -1047595018);
}

