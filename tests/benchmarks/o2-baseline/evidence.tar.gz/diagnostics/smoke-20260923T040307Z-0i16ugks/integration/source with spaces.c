#include "value.h"
#include <math.h>
int main(void) { volatile double value = NUMBER; return (int)sqrt(value) - 3; }
