#ifdef REMOVE_ME
#error -U failed
#endif
#ifndef NUMBER
#error -D failed
#endif
