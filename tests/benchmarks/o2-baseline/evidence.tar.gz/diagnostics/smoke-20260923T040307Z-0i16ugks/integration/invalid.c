int main( { this is invalid C; }
