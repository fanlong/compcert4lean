# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/framework-t4pgn99a/test_cross_file_private_names_and_objects/second.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/framework-t4pgn99a/test_cross_file_private_names_and_objects/second.c"
static int value=3; static int local(void){return value;} extern int global; int read(void); int main(void){return read()+local()+global-10;}
