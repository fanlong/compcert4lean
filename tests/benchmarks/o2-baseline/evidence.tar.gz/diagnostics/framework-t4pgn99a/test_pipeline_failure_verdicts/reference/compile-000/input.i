# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/framework-t4pgn99a/test_pipeline_failure_verdicts/reference/regression/reference.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/framework-t4pgn99a/test_pipeline_failure_verdicts/reference/regression/reference.c"
int main(void){return 0;}
