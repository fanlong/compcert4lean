# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/framework-t4pgn99a/test_archive_order_and_failure_preservation/provider.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/framework-t4pgn99a/test_archive_order_and_failure_preservation/provider.c"
int value(void){return 7;}
