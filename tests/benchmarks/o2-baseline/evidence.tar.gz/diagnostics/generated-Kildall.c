// Lean compiler output
// Module: CompCert4Lean.Backend.Kildall
// Imports: public import Init public meta import Init public import CompCert4Lean.Foundation.Logic public import CompCert4Lean.Foundation.Numbers public import CompCert4Lean.Foundation.Recursion public import CompCert4Lean.Lib.Coqlib public import CompCert4Lean.Lib.Heaps public import CompCert4Lean.Lib.Iteration public import CompCert4Lean.Lib.Lattice public import CompCert4Lean.Lib.Maps
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_get___redArg(lean_object*, lean_object*);
lean_object* lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_set___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_fold___redArg(lean_object*, lean_object*, lean_object*);
uint8_t lp_compcert4lean_CompCert4Lean_Foundation_Numbers_Rocq_Coq_Numbers_BinNums_instDecidableEqPositive_decEq(lean_object*, lean_object*);
lean_object* lp_compcert4lean_CompCert4Lean_Lib_Maps_PMap_get___redArg(lean_object*, lean_object*);
lean_object* lp_compcert4lean_CompCert4Lean_Lib_Maps_PMap_set___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_compcert4lean_CompCert4Lean_Lib_Maps_PMap_init___redArg(lean_object*);
lean_object* lp_compcert4lean_CompCert4Lean_Lib_Iteration_PrimIter_iterate___redArg(lean_object*, lean_object*);
lean_object* lp_compcert4lean_CompCert4Lean_Lib_Heaps_PHeap_insert(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lp_compcert4lean_CompCert4Lean_Lib_Heaps_SplayHeapSet_R_findMin___redArg(lean_object*);
lean_object* lp_compcert4lean_CompCert4Lean_Lib_Heaps_SplayHeapSet_R_deleteMin___redArg(lean_object*);
uint8_t lp_compcert4lean_CompCert4Lean_Lib_Coqlib_plt(lean_object*, lean_object*);
lean_object* lp_compcert4lean_CompCert4Lean_Lib_Heaps_SplayHeapSet_R_findMax___redArg(lean_object*);
lean_object* lp_compcert4lean_CompCert4Lean_Lib_Heaps_SplayHeapSet_R_deleteMax___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_x2eL___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_x2eL___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_x2eL(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_x2eL___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_L___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_L___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_L(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_L___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_propagate__succ(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_propagate__succ__list(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_step___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_step(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__from___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__from(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__nodeset___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__nodeset(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__nodeset___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__nodeset___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__nodeset(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__allnodes___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__allnodes(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__allnodes___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__allnodes___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__allnodes(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_successors__list(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_successors__list___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_add__successors(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_make__predecessors___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_make__predecessors___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_make__predecessors(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_x2eL___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_x2eL___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_x2eL(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_x2eL___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_L___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_L___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_L(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_L___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_compcert4lean_List_any___at___00CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_List_any___at___00CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_compcert4lean_List_any___at___00CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_List_any___at___00CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_exit__points___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_exit__points___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_exit__points(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg___lam__0___boxed(lean_object*);
static const lean_closure_object lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg___closed__0 = (const lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint__allnodes___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint__allnodes(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_x2eL(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_x2eL___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_L(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_L___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_propagate__successors___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_propagate__successors(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_propagate__successors___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_step___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_step(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_step___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_is__basic__block__head(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_is__basic__block__head___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__map___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__map___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__map(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__map___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__list___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__list___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__list___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__list(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_fixpoint___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_fixpoint(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_predecessors___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_predecessors(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___lam__1(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___lam__2(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___lam__0___boxed, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__0 = (const lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__0_value;
static const lean_closure_object lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_compcert4lean_CompCert4Lean_Lib_Heaps_PHeap_insert, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__1 = (const lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__1_value;
static const lean_closure_object lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___lam__1, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__2 = (const lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__2_value;
static const lean_closure_object lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___lam__2, .m_arity = 4, .m_num_fixed = 2, .m_objs = {((lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__3 = (const lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__3_value;
static const lean_ctor_object lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*4 + 0, .m_other = 4, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__1_value),((lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__2_value),((lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__3_value)}};
static const lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__4 = (const lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__4_value;
LEAN_EXPORT const lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward = (const lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__4_value;
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_empty;
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_add(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_pick(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_all__nodes___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_all__nodes(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward___lam__1(lean_object*);
static const lean_closure_object lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward___lam__1, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward___closed__0 = (const lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward___closed__0_value;
static const lean_ctor_object lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*4 + 0, .m_other = 4, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__1_value),((lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward___closed__0_value),((lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__3_value)}};
static const lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward___closed__1 = (const lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward___closed__1_value;
LEAN_EXPORT const lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward = (const lean_object*)&lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward___closed__1_value;
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_empty;
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_add(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_pick(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_all__nodes___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_all__nodes(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_NodeSetBackward_raw__heap__size___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_NodeSetBackward_raw__heap__size___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_NodeSetBackward_raw__heap__size(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_NodeSetBackward_raw__heap__size___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Lib_Maps_PTree_map__filter1_go_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Lib_Maps_PTree_map__filter1_go_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Dataflow__Solver_propagate__succ__list_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Dataflow__Solver_propagate__succ__list_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_successors__list_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_successors__list_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_match__1_splitter___redArg(uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_match__1_splitter(lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_x2eL___redArg(lean_object* v_LAT_1_){
_start:
{
lean_inc_ref(v_LAT_1_);
return v_LAT_1_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_x2eL___redArg___boxed(lean_object* v_LAT_2_){
_start:
{
lean_object* v_res_3_; 
v_res_3_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_x2eL___redArg(v_LAT_2_);
lean_dec_ref(v_LAT_2_);
return v_res_3_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_x2eL(lean_object* v_LAT_4_, lean_object* v___NS_5_){
_start:
{
lean_inc_ref(v_LAT_4_);
return v_LAT_4_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_x2eL___boxed(lean_object* v_LAT_6_, lean_object* v___NS_7_){
_start:
{
lean_object* v_res_8_; 
v_res_8_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_x2eL(v_LAT_6_, v___NS_7_);
lean_dec_ref(v___NS_7_);
lean_dec_ref(v_LAT_6_);
return v_res_8_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_L___redArg(lean_object* v_LAT_9_){
_start:
{
lean_inc_ref(v_LAT_9_);
return v_LAT_9_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_L___redArg___boxed(lean_object* v_LAT_10_){
_start:
{
lean_object* v_res_11_; 
v_res_11_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_L___redArg(v_LAT_10_);
lean_dec_ref(v_LAT_10_);
return v_res_11_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_L(lean_object* v_LAT_12_, lean_object* v___NS_13_){
_start:
{
lean_inc_ref(v_LAT_12_);
return v_LAT_12_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_L___boxed(lean_object* v_LAT_14_, lean_object* v___NS_15_){
_start:
{
lean_object* v_res_16_; 
v_res_16_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_L(v_LAT_14_, v___NS_15_);
lean_dec_ref(v___NS_15_);
lean_dec_ref(v_LAT_14_);
return v_res_16_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value___redArg(lean_object* v_LAT_17_, lean_object* v_n_18_, lean_object* v_s_19_){
_start:
{
lean_object* v_aval_20_; lean_object* v___x_21_; 
v_aval_20_ = lean_ctor_get(v_s_19_, 0);
lean_inc(v_aval_20_);
lean_dec_ref(v_s_19_);
v___x_21_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_get___redArg(v_n_18_, v_aval_20_);
if (lean_obj_tag(v___x_21_) == 0)
{
lean_object* v_bot_22_; 
v_bot_22_ = lean_ctor_get(v_LAT_17_, 0);
lean_inc(v_bot_22_);
return v_bot_22_;
}
else
{
lean_object* v_val_23_; 
v_val_23_ = lean_ctor_get(v___x_21_, 0);
lean_inc(v_val_23_);
lean_dec_ref_known(v___x_21_, 1);
return v_val_23_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value___redArg___boxed(lean_object* v_LAT_24_, lean_object* v_n_25_, lean_object* v_s_26_){
_start:
{
lean_object* v_res_27_; 
v_res_27_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value___redArg(v_LAT_24_, v_n_25_, v_s_26_);
lean_dec(v_n_25_);
lean_dec_ref(v_LAT_24_);
return v_res_27_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value(lean_object* v_LAT_28_, lean_object* v_NS_29_, lean_object* v_n_30_, lean_object* v_s_31_){
_start:
{
lean_object* v___x_32_; 
v___x_32_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value___redArg(v_LAT_28_, v_n_30_, v_s_31_);
return v___x_32_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value___boxed(lean_object* v_LAT_33_, lean_object* v_NS_34_, lean_object* v_n_35_, lean_object* v_s_36_){
_start:
{
lean_object* v_res_37_; 
v_res_37_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value(v_LAT_33_, v_NS_34_, v_n_35_, v_s_36_);
lean_dec(v_n_35_);
lean_dec_ref(v_NS_34_);
lean_dec_ref(v_LAT_33_);
return v_res_37_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_propagate__succ(lean_object* v_LAT_38_, lean_object* v_NS_39_, lean_object* v_s_40_, lean_object* v_out_41_, lean_object* v_n_42_){
_start:
{
lean_object* v_aval_43_; lean_object* v_worklist_44_; lean_object* v___x_45_; 
v_aval_43_ = lean_ctor_get(v_s_40_, 0);
v_worklist_44_ = lean_ctor_get(v_s_40_, 1);
lean_inc(v_aval_43_);
v___x_45_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_get___redArg(v_n_42_, v_aval_43_);
if (lean_obj_tag(v___x_45_) == 0)
{
lean_object* v___x_47_; uint8_t v_isShared_48_; uint8_t v_isSharedCheck_55_; 
lean_inc(v_worklist_44_);
lean_inc(v_aval_43_);
lean_dec_ref(v_LAT_38_);
v_isSharedCheck_55_ = !lean_is_exclusive(v_s_40_);
if (v_isSharedCheck_55_ == 0)
{
lean_object* v_unused_56_; lean_object* v_unused_57_; 
v_unused_56_ = lean_ctor_get(v_s_40_, 1);
lean_dec(v_unused_56_);
v_unused_57_ = lean_ctor_get(v_s_40_, 0);
lean_dec(v_unused_57_);
v___x_47_ = v_s_40_;
v_isShared_48_ = v_isSharedCheck_55_;
goto v_resetjp_46_;
}
else
{
lean_dec(v_s_40_);
v___x_47_ = lean_box(0);
v_isShared_48_ = v_isSharedCheck_55_;
goto v_resetjp_46_;
}
v_resetjp_46_:
{
lean_object* v_add_49_; lean_object* v___x_50_; lean_object* v___x_51_; lean_object* v___x_53_; 
v_add_49_ = lean_ctor_get(v_NS_39_, 1);
lean_inc(v_add_49_);
lean_dec_ref(v_NS_39_);
lean_inc(v_n_42_);
v___x_50_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_set___redArg(v_n_42_, v_out_41_, v_aval_43_);
v___x_51_ = lean_apply_2(v_add_49_, v_n_42_, v_worklist_44_);
if (v_isShared_48_ == 0)
{
lean_ctor_set(v___x_47_, 1, v___x_51_);
lean_ctor_set(v___x_47_, 0, v___x_50_);
v___x_53_ = v___x_47_;
goto v_reusejp_52_;
}
else
{
lean_object* v_reuseFailAlloc_54_; 
v_reuseFailAlloc_54_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_54_, 0, v___x_50_);
lean_ctor_set(v_reuseFailAlloc_54_, 1, v___x_51_);
v___x_53_ = v_reuseFailAlloc_54_;
goto v_reusejp_52_;
}
v_reusejp_52_:
{
return v___x_53_;
}
}
}
else
{
lean_object* v_val_58_; lean_object* v_lub_59_; lean_object* v_beq_60_; lean_object* v_newl_61_; lean_object* v___x_62_; uint8_t v___x_63_; 
v_val_58_ = lean_ctor_get(v___x_45_, 0);
lean_inc_n(v_val_58_, 2);
lean_dec_ref_known(v___x_45_, 1);
v_lub_59_ = lean_ctor_get(v_LAT_38_, 1);
lean_inc(v_lub_59_);
v_beq_60_ = lean_ctor_get(v_LAT_38_, 2);
lean_inc_ref(v_beq_60_);
lean_dec_ref(v_LAT_38_);
v_newl_61_ = lean_apply_2(v_lub_59_, v_val_58_, v_out_41_);
lean_inc(v_newl_61_);
v___x_62_ = lean_apply_2(v_beq_60_, v_val_58_, v_newl_61_);
v___x_63_ = lean_unbox(v___x_62_);
if (v___x_63_ == 0)
{
lean_object* v___x_65_; uint8_t v_isShared_66_; uint8_t v_isSharedCheck_73_; 
lean_inc(v_worklist_44_);
lean_inc(v_aval_43_);
v_isSharedCheck_73_ = !lean_is_exclusive(v_s_40_);
if (v_isSharedCheck_73_ == 0)
{
lean_object* v_unused_74_; lean_object* v_unused_75_; 
v_unused_74_ = lean_ctor_get(v_s_40_, 1);
lean_dec(v_unused_74_);
v_unused_75_ = lean_ctor_get(v_s_40_, 0);
lean_dec(v_unused_75_);
v___x_65_ = v_s_40_;
v_isShared_66_ = v_isSharedCheck_73_;
goto v_resetjp_64_;
}
else
{
lean_dec(v_s_40_);
v___x_65_ = lean_box(0);
v_isShared_66_ = v_isSharedCheck_73_;
goto v_resetjp_64_;
}
v_resetjp_64_:
{
lean_object* v_add_67_; lean_object* v___x_68_; lean_object* v___x_69_; lean_object* v___x_71_; 
v_add_67_ = lean_ctor_get(v_NS_39_, 1);
lean_inc(v_add_67_);
lean_dec_ref(v_NS_39_);
lean_inc(v_n_42_);
v___x_68_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_set___redArg(v_n_42_, v_newl_61_, v_aval_43_);
v___x_69_ = lean_apply_2(v_add_67_, v_n_42_, v_worklist_44_);
if (v_isShared_66_ == 0)
{
lean_ctor_set(v___x_65_, 1, v___x_69_);
lean_ctor_set(v___x_65_, 0, v___x_68_);
v___x_71_ = v___x_65_;
goto v_reusejp_70_;
}
else
{
lean_object* v_reuseFailAlloc_72_; 
v_reuseFailAlloc_72_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_72_, 0, v___x_68_);
lean_ctor_set(v_reuseFailAlloc_72_, 1, v___x_69_);
v___x_71_ = v_reuseFailAlloc_72_;
goto v_reusejp_70_;
}
v_reusejp_70_:
{
return v___x_71_;
}
}
}
else
{
lean_dec(v_newl_61_);
lean_dec(v_n_42_);
lean_dec_ref(v_NS_39_);
return v_s_40_;
}
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_propagate__succ__list(lean_object* v_LAT_76_, lean_object* v_NS_77_, lean_object* v_s_78_, lean_object* v_out_79_, lean_object* v_x_80_){
_start:
{
if (lean_obj_tag(v_x_80_) == 0)
{
lean_dec(v_out_79_);
lean_dec_ref(v_NS_77_);
lean_dec_ref(v_LAT_76_);
return v_s_78_;
}
else
{
lean_object* v_head_81_; lean_object* v_tail_82_; lean_object* v___x_83_; 
v_head_81_ = lean_ctor_get(v_x_80_, 0);
lean_inc(v_head_81_);
v_tail_82_ = lean_ctor_get(v_x_80_, 1);
lean_inc(v_tail_82_);
lean_dec_ref_known(v_x_80_, 2);
lean_inc(v_out_79_);
lean_inc_ref(v_NS_77_);
lean_inc_ref(v_LAT_76_);
v___x_83_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_propagate__succ(v_LAT_76_, v_NS_77_, v_s_78_, v_out_79_, v_head_81_);
v_s_78_ = v___x_83_;
v_x_80_ = v_tail_82_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_step___redArg(lean_object* v_LAT_85_, lean_object* v_NS_86_, lean_object* v_code_87_, lean_object* v_successors_88_, lean_object* v_transf_89_, lean_object* v_s_90_){
_start:
{
lean_object* v_pick_91_; lean_object* v_aval_92_; lean_object* v_worklist_93_; lean_object* v___x_94_; 
v_pick_91_ = lean_ctor_get(v_NS_86_, 2);
v_aval_92_ = lean_ctor_get(v_s_90_, 0);
v_worklist_93_ = lean_ctor_get(v_s_90_, 1);
lean_inc_ref(v_pick_91_);
lean_inc(v_worklist_93_);
v___x_94_ = lean_apply_1(v_pick_91_, v_worklist_93_);
if (lean_obj_tag(v___x_94_) == 0)
{
lean_object* v_bot_95_; lean_object* v___x_96_; lean_object* v___x_97_; 
lean_inc(v_aval_92_);
lean_dec_ref(v_s_90_);
lean_dec(v_transf_89_);
lean_dec_ref(v_successors_88_);
lean_dec(v_code_87_);
lean_dec_ref(v_NS_86_);
v_bot_95_ = lean_ctor_get(v_LAT_85_, 0);
lean_inc(v_bot_95_);
lean_dec_ref(v_LAT_85_);
v___x_96_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_96_, 0, v_bot_95_);
lean_ctor_set(v___x_96_, 1, v_aval_92_);
v___x_97_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_97_, 0, v___x_96_);
return v___x_97_;
}
else
{
lean_object* v_val_98_; lean_object* v___x_100_; uint8_t v_isShared_101_; uint8_t v_isSharedCheck_136_; 
v_val_98_ = lean_ctor_get(v___x_94_, 0);
v_isSharedCheck_136_ = !lean_is_exclusive(v___x_94_);
if (v_isSharedCheck_136_ == 0)
{
v___x_100_ = v___x_94_;
v_isShared_101_ = v_isSharedCheck_136_;
goto v_resetjp_99_;
}
else
{
lean_inc(v_val_98_);
lean_dec(v___x_94_);
v___x_100_ = lean_box(0);
v_isShared_101_ = v_isSharedCheck_136_;
goto v_resetjp_99_;
}
v_resetjp_99_:
{
lean_object* v_fst_102_; lean_object* v_snd_103_; lean_object* v___x_105_; uint8_t v_isShared_106_; uint8_t v_isSharedCheck_135_; 
v_fst_102_ = lean_ctor_get(v_val_98_, 0);
v_snd_103_ = lean_ctor_get(v_val_98_, 1);
v_isSharedCheck_135_ = !lean_is_exclusive(v_val_98_);
if (v_isSharedCheck_135_ == 0)
{
v___x_105_ = v_val_98_;
v_isShared_106_ = v_isSharedCheck_135_;
goto v_resetjp_104_;
}
else
{
lean_inc(v_snd_103_);
lean_inc(v_fst_102_);
lean_dec(v_val_98_);
v___x_105_ = lean_box(0);
v_isShared_106_ = v_isSharedCheck_135_;
goto v_resetjp_104_;
}
v_resetjp_104_:
{
lean_object* v___x_107_; 
v___x_107_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_get___redArg(v_fst_102_, v_code_87_);
if (lean_obj_tag(v___x_107_) == 0)
{
lean_object* v___x_109_; uint8_t v_isShared_110_; uint8_t v_isSharedCheck_117_; 
lean_inc(v_aval_92_);
lean_del_object(v___x_105_);
lean_dec(v_fst_102_);
lean_dec(v_transf_89_);
lean_dec_ref(v_successors_88_);
lean_dec_ref(v_NS_86_);
lean_dec_ref(v_LAT_85_);
v_isSharedCheck_117_ = !lean_is_exclusive(v_s_90_);
if (v_isSharedCheck_117_ == 0)
{
lean_object* v_unused_118_; lean_object* v_unused_119_; 
v_unused_118_ = lean_ctor_get(v_s_90_, 1);
lean_dec(v_unused_118_);
v_unused_119_ = lean_ctor_get(v_s_90_, 0);
lean_dec(v_unused_119_);
v___x_109_ = v_s_90_;
v_isShared_110_ = v_isSharedCheck_117_;
goto v_resetjp_108_;
}
else
{
lean_dec(v_s_90_);
v___x_109_ = lean_box(0);
v_isShared_110_ = v_isSharedCheck_117_;
goto v_resetjp_108_;
}
v_resetjp_108_:
{
lean_object* v___x_112_; 
if (v_isShared_110_ == 0)
{
lean_ctor_set(v___x_109_, 1, v_snd_103_);
v___x_112_ = v___x_109_;
goto v_reusejp_111_;
}
else
{
lean_object* v_reuseFailAlloc_116_; 
v_reuseFailAlloc_116_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_116_, 0, v_aval_92_);
lean_ctor_set(v_reuseFailAlloc_116_, 1, v_snd_103_);
v___x_112_ = v_reuseFailAlloc_116_;
goto v_reusejp_111_;
}
v_reusejp_111_:
{
lean_object* v___x_114_; 
if (v_isShared_101_ == 0)
{
lean_ctor_set(v___x_100_, 0, v___x_112_);
v___x_114_ = v___x_100_;
goto v_reusejp_113_;
}
else
{
lean_object* v_reuseFailAlloc_115_; 
v_reuseFailAlloc_115_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_115_, 0, v___x_112_);
v___x_114_ = v_reuseFailAlloc_115_;
goto v_reusejp_113_;
}
v_reusejp_113_:
{
return v___x_114_;
}
}
}
}
else
{
lean_object* v_val_120_; lean_object* v___x_122_; uint8_t v_isShared_123_; uint8_t v_isSharedCheck_134_; 
lean_del_object(v___x_100_);
v_val_120_ = lean_ctor_get(v___x_107_, 0);
v_isSharedCheck_134_ = !lean_is_exclusive(v___x_107_);
if (v_isSharedCheck_134_ == 0)
{
v___x_122_ = v___x_107_;
v_isShared_123_ = v_isSharedCheck_134_;
goto v_resetjp_121_;
}
else
{
lean_inc(v_val_120_);
lean_dec(v___x_107_);
v___x_122_ = lean_box(0);
v_isShared_123_ = v_isSharedCheck_134_;
goto v_resetjp_121_;
}
v_resetjp_121_:
{
lean_object* v___x_125_; 
lean_inc(v_aval_92_);
if (v_isShared_106_ == 0)
{
lean_ctor_set(v___x_105_, 0, v_aval_92_);
v___x_125_ = v___x_105_;
goto v_reusejp_124_;
}
else
{
lean_object* v_reuseFailAlloc_133_; 
v_reuseFailAlloc_133_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_133_, 0, v_aval_92_);
lean_ctor_set(v_reuseFailAlloc_133_, 1, v_snd_103_);
v___x_125_ = v_reuseFailAlloc_133_;
goto v_reusejp_124_;
}
v_reusejp_124_:
{
lean_object* v___x_126_; lean_object* v___x_127_; lean_object* v___x_128_; lean_object* v___x_129_; lean_object* v___x_131_; 
v___x_126_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value___redArg(v_LAT_85_, v_fst_102_, v_s_90_);
v___x_127_ = lean_apply_2(v_transf_89_, v_fst_102_, v___x_126_);
v___x_128_ = lean_apply_1(v_successors_88_, v_val_120_);
v___x_129_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_propagate__succ__list(v_LAT_85_, v_NS_86_, v___x_125_, v___x_127_, v___x_128_);
if (v_isShared_123_ == 0)
{
lean_ctor_set(v___x_122_, 0, v___x_129_);
v___x_131_ = v___x_122_;
goto v_reusejp_130_;
}
else
{
lean_object* v_reuseFailAlloc_132_; 
v_reuseFailAlloc_132_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_132_, 0, v___x_129_);
v___x_131_ = v_reuseFailAlloc_132_;
goto v_reusejp_130_;
}
v_reusejp_130_:
{
return v___x_131_;
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_step(lean_object* v_A_137_, lean_object* v_LAT_138_, lean_object* v_NS_139_, lean_object* v_code_140_, lean_object* v_successors_141_, lean_object* v_transf_142_, lean_object* v_s_143_){
_start:
{
lean_object* v___x_144_; 
v___x_144_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_step___redArg(v_LAT_138_, v_NS_139_, v_code_140_, v_successors_141_, v_transf_142_, v_s_143_);
return v___x_144_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__from___redArg(lean_object* v_LAT_145_, lean_object* v_NS_146_, lean_object* v_code_147_, lean_object* v_successors_148_, lean_object* v_transf_149_, lean_object* v_start_150_){
_start:
{
lean_object* v___x_151_; lean_object* v___x_152_; 
v___x_151_ = lean_alloc_closure((void*)(lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_step), 7, 6);
lean_closure_set(v___x_151_, 0, lean_box(0));
lean_closure_set(v___x_151_, 1, v_LAT_145_);
lean_closure_set(v___x_151_, 2, v_NS_146_);
lean_closure_set(v___x_151_, 3, v_code_147_);
lean_closure_set(v___x_151_, 4, v_successors_148_);
lean_closure_set(v___x_151_, 5, v_transf_149_);
v___x_152_ = lp_compcert4lean_CompCert4Lean_Lib_Iteration_PrimIter_iterate___redArg(v___x_151_, v_start_150_);
return v___x_152_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__from(lean_object* v_A_153_, lean_object* v_LAT_154_, lean_object* v_NS_155_, lean_object* v_code_156_, lean_object* v_successors_157_, lean_object* v_transf_158_, lean_object* v_start_159_){
_start:
{
lean_object* v___x_160_; 
v___x_160_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__from___redArg(v_LAT_154_, v_NS_155_, v_code_156_, v_successors_157_, v_transf_158_, v_start_159_);
return v___x_160_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state___redArg(lean_object* v_NS_161_, lean_object* v_enode_162_, lean_object* v_eval_163_){
_start:
{
lean_object* v_empty_164_; lean_object* v_add_165_; lean_object* v___x_166_; lean_object* v___x_167_; lean_object* v___x_168_; lean_object* v___x_169_; 
v_empty_164_ = lean_ctor_get(v_NS_161_, 0);
lean_inc(v_empty_164_);
v_add_165_ = lean_ctor_get(v_NS_161_, 1);
lean_inc(v_add_165_);
lean_dec_ref(v_NS_161_);
v___x_166_ = lean_box(0);
lean_inc(v_enode_162_);
v___x_167_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_set___redArg(v_enode_162_, v_eval_163_, v___x_166_);
v___x_168_ = lean_apply_2(v_add_165_, v_enode_162_, v_empty_164_);
v___x_169_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_169_, 0, v___x_167_);
lean_ctor_set(v___x_169_, 1, v___x_168_);
return v___x_169_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state(lean_object* v_LAT_170_, lean_object* v_NS_171_, lean_object* v_enode_172_, lean_object* v_eval_173_){
_start:
{
lean_object* v___x_174_; 
v___x_174_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state___redArg(v_NS_171_, v_enode_172_, v_eval_173_);
return v___x_174_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state___boxed(lean_object* v_LAT_175_, lean_object* v_NS_176_, lean_object* v_enode_177_, lean_object* v_eval_178_){
_start:
{
lean_object* v_res_179_; 
v_res_179_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state(v_LAT_175_, v_NS_176_, v_enode_177_, v_eval_178_);
lean_dec_ref(v_LAT_175_);
return v_res_179_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint___redArg(lean_object* v_LAT_180_, lean_object* v_NS_181_, lean_object* v_code_182_, lean_object* v_successors_183_, lean_object* v_transf_184_, lean_object* v_enode_185_, lean_object* v_eval_186_){
_start:
{
lean_object* v___x_187_; lean_object* v___x_188_; 
lean_inc_ref(v_NS_181_);
v___x_187_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state___redArg(v_NS_181_, v_enode_185_, v_eval_186_);
v___x_188_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__from___redArg(v_LAT_180_, v_NS_181_, v_code_182_, v_successors_183_, v_transf_184_, v___x_187_);
return v___x_188_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint(lean_object* v_A_189_, lean_object* v_LAT_190_, lean_object* v_NS_191_, lean_object* v_code_192_, lean_object* v_successors_193_, lean_object* v_transf_194_, lean_object* v_enode_195_, lean_object* v_eval_196_){
_start:
{
lean_object* v___x_197_; 
v___x_197_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint___redArg(v_LAT_190_, v_NS_191_, v_code_192_, v_successors_193_, v_transf_194_, v_enode_195_, v_eval_196_);
return v___x_197_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__nodeset___redArg(lean_object* v_enodes_198_){
_start:
{
lean_object* v___x_199_; lean_object* v___x_200_; 
v___x_199_ = lean_box(0);
v___x_200_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_200_, 0, v___x_199_);
lean_ctor_set(v___x_200_, 1, v_enodes_198_);
return v___x_200_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__nodeset(lean_object* v_LAT_201_, lean_object* v_NS_202_, lean_object* v_enodes_203_){
_start:
{
lean_object* v___x_204_; 
v___x_204_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__nodeset___redArg(v_enodes_203_);
return v___x_204_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__nodeset___boxed(lean_object* v_LAT_205_, lean_object* v_NS_206_, lean_object* v_enodes_207_){
_start:
{
lean_object* v_res_208_; 
v_res_208_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__nodeset(v_LAT_205_, v_NS_206_, v_enodes_207_);
lean_dec_ref(v_NS_206_);
lean_dec_ref(v_LAT_205_);
return v_res_208_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__nodeset___redArg(lean_object* v_LAT_209_, lean_object* v_NS_210_, lean_object* v_code_211_, lean_object* v_successors_212_, lean_object* v_transf_213_, lean_object* v_enodes_214_){
_start:
{
lean_object* v___x_215_; lean_object* v___x_216_; 
v___x_215_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__nodeset___redArg(v_enodes_214_);
v___x_216_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__from___redArg(v_LAT_209_, v_NS_210_, v_code_211_, v_successors_212_, v_transf_213_, v___x_215_);
return v___x_216_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__nodeset(lean_object* v_A_217_, lean_object* v_LAT_218_, lean_object* v_NS_219_, lean_object* v_code_220_, lean_object* v_successors_221_, lean_object* v_transf_222_, lean_object* v_enodes_223_){
_start:
{
lean_object* v___x_224_; 
v___x_224_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__nodeset___redArg(v_LAT_218_, v_NS_219_, v_code_220_, v_successors_221_, v_transf_222_, v_enodes_223_);
return v___x_224_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__allnodes___redArg(lean_object* v_NS_225_, lean_object* v_code_226_){
_start:
{
lean_object* v_all__nodes_227_; lean_object* v___x_228_; lean_object* v___x_229_; lean_object* v___x_230_; 
v_all__nodes_227_ = lean_ctor_get(v_NS_225_, 3);
lean_inc(v_all__nodes_227_);
lean_dec_ref(v_NS_225_);
v___x_228_ = lean_box(0);
v___x_229_ = lean_apply_2(v_all__nodes_227_, lean_box(0), v_code_226_);
v___x_230_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_230_, 0, v___x_228_);
lean_ctor_set(v___x_230_, 1, v___x_229_);
return v___x_230_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__allnodes(lean_object* v_A_231_, lean_object* v_LAT_232_, lean_object* v_NS_233_, lean_object* v_code_234_){
_start:
{
lean_object* v___x_235_; 
v___x_235_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__allnodes___redArg(v_NS_233_, v_code_234_);
return v___x_235_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__allnodes___boxed(lean_object* v_A_236_, lean_object* v_LAT_237_, lean_object* v_NS_238_, lean_object* v_code_239_){
_start:
{
lean_object* v_res_240_; 
v_res_240_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__allnodes(v_A_236_, v_LAT_237_, v_NS_238_, v_code_239_);
lean_dec_ref(v_LAT_237_);
return v_res_240_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__allnodes___redArg(lean_object* v_LAT_241_, lean_object* v_NS_242_, lean_object* v_code_243_, lean_object* v_successors_244_, lean_object* v_transf_245_){
_start:
{
lean_object* v___x_246_; lean_object* v___x_247_; 
lean_inc(v_code_243_);
lean_inc_ref(v_NS_242_);
v___x_246_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_start__state__allnodes___redArg(v_NS_242_, v_code_243_);
v___x_247_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__from___redArg(v_LAT_241_, v_NS_242_, v_code_243_, v_successors_244_, v_transf_245_, v___x_246_);
return v___x_247_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__allnodes(lean_object* v_A_248_, lean_object* v_LAT_249_, lean_object* v_NS_250_, lean_object* v_code_251_, lean_object* v_successors_252_, lean_object* v_transf_253_){
_start:
{
lean_object* v___x_254_; 
v___x_254_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__allnodes___redArg(v_LAT_249_, v_NS_250_, v_code_251_, v_successors_252_, v_transf_253_);
return v___x_254_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_successors__list(lean_object* v_successors_255_, lean_object* v_pc_256_){
_start:
{
lean_object* v___x_257_; 
v___x_257_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_get___redArg(v_pc_256_, v_successors_255_);
if (lean_obj_tag(v___x_257_) == 0)
{
lean_object* v___x_258_; 
v___x_258_ = lean_box(0);
return v___x_258_;
}
else
{
lean_object* v_val_259_; 
v_val_259_ = lean_ctor_get(v___x_257_, 0);
lean_inc(v_val_259_);
lean_dec_ref_known(v___x_257_, 1);
return v_val_259_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_successors__list___boxed(lean_object* v_successors_260_, lean_object* v_pc_261_){
_start:
{
lean_object* v_res_262_; 
v_res_262_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_successors__list(v_successors_260_, v_pc_261_);
lean_dec(v_pc_261_);
return v_res_262_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_add__successors(lean_object* v_pred_263_, lean_object* v_src_264_, lean_object* v_x_265_){
_start:
{
if (lean_obj_tag(v_x_265_) == 0)
{
lean_dec(v_src_264_);
return v_pred_263_;
}
else
{
lean_object* v_head_266_; lean_object* v_tail_267_; lean_object* v___x_269_; uint8_t v_isShared_270_; uint8_t v_isSharedCheck_277_; 
v_head_266_ = lean_ctor_get(v_x_265_, 0);
v_tail_267_ = lean_ctor_get(v_x_265_, 1);
v_isSharedCheck_277_ = !lean_is_exclusive(v_x_265_);
if (v_isSharedCheck_277_ == 0)
{
v___x_269_ = v_x_265_;
v_isShared_270_ = v_isSharedCheck_277_;
goto v_resetjp_268_;
}
else
{
lean_inc(v_tail_267_);
lean_inc(v_head_266_);
lean_dec(v_x_265_);
v___x_269_ = lean_box(0);
v_isShared_270_ = v_isSharedCheck_277_;
goto v_resetjp_268_;
}
v_resetjp_268_:
{
lean_object* v___x_271_; lean_object* v___x_273_; 
lean_inc(v_pred_263_);
v___x_271_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_successors__list(v_pred_263_, v_head_266_);
lean_inc(v_src_264_);
if (v_isShared_270_ == 0)
{
lean_ctor_set(v___x_269_, 1, v___x_271_);
lean_ctor_set(v___x_269_, 0, v_src_264_);
v___x_273_ = v___x_269_;
goto v_reusejp_272_;
}
else
{
lean_object* v_reuseFailAlloc_276_; 
v_reuseFailAlloc_276_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_276_, 0, v_src_264_);
lean_ctor_set(v_reuseFailAlloc_276_, 1, v___x_271_);
v___x_273_ = v_reuseFailAlloc_276_;
goto v_reusejp_272_;
}
v_reusejp_272_:
{
lean_object* v___x_274_; 
v___x_274_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_set___redArg(v_head_266_, v___x_273_, v_pred_263_);
v_pred_263_ = v___x_274_;
v_x_265_ = v_tail_267_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_make__predecessors___redArg___lam__0(lean_object* v_successors_278_, lean_object* v_pred_279_, lean_object* v_pc_280_, lean_object* v_instr_281_){
_start:
{
lean_object* v___x_282_; lean_object* v___x_283_; 
v___x_282_ = lean_apply_1(v_successors_278_, v_instr_281_);
v___x_283_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_add__successors(v_pred_279_, v_pc_280_, v___x_282_);
return v___x_283_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_make__predecessors___redArg(lean_object* v_code_284_, lean_object* v_successors_285_){
_start:
{
lean_object* v___f_286_; lean_object* v___x_287_; lean_object* v___x_288_; 
v___f_286_ = lean_alloc_closure((void*)(lp_compcert4lean_CompCert4Lean_Backend_Kildall_make__predecessors___redArg___lam__0), 4, 1);
lean_closure_set(v___f_286_, 0, v_successors_285_);
v___x_287_ = lean_box(0);
v___x_288_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_fold___redArg(v___f_286_, v_code_284_, v___x_287_);
return v___x_288_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_make__predecessors(lean_object* v_A_289_, lean_object* v_code_290_, lean_object* v_successors_291_){
_start:
{
lean_object* v___x_292_; 
v___x_292_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_make__predecessors___redArg(v_code_290_, v_successors_291_);
return v___x_292_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_x2eL___redArg(lean_object* v_LAT_293_){
_start:
{
lean_inc_ref(v_LAT_293_);
return v_LAT_293_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_x2eL___redArg___boxed(lean_object* v_LAT_294_){
_start:
{
lean_object* v_res_295_; 
v_res_295_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_x2eL___redArg(v_LAT_294_);
lean_dec_ref(v_LAT_294_);
return v_res_295_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_x2eL(lean_object* v_LAT_296_, lean_object* v___NS_297_){
_start:
{
lean_inc_ref(v_LAT_296_);
return v_LAT_296_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_x2eL___boxed(lean_object* v_LAT_298_, lean_object* v___NS_299_){
_start:
{
lean_object* v_res_300_; 
v_res_300_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_x2eL(v_LAT_298_, v___NS_299_);
lean_dec_ref(v___NS_299_);
lean_dec_ref(v_LAT_298_);
return v_res_300_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_L___redArg(lean_object* v_LAT_301_){
_start:
{
lean_inc_ref(v_LAT_301_);
return v_LAT_301_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_L___redArg___boxed(lean_object* v_LAT_302_){
_start:
{
lean_object* v_res_303_; 
v_res_303_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_L___redArg(v_LAT_302_);
lean_dec_ref(v_LAT_302_);
return v_res_303_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_L(lean_object* v_LAT_304_, lean_object* v___NS_305_){
_start:
{
lean_inc_ref(v_LAT_304_);
return v_LAT_304_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_L___boxed(lean_object* v_LAT_306_, lean_object* v___NS_307_){
_start:
{
lean_object* v_res_308_; 
v_res_308_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_L(v_LAT_306_, v___NS_307_);
lean_dec_ref(v___NS_307_);
lean_dec_ref(v_LAT_306_);
return v_res_308_;
}
}
LEAN_EXPORT uint8_t lp_compcert4lean_List_any___at___00CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_spec__0___redArg(lean_object* v_code_309_, lean_object* v_pc_310_, lean_object* v_x_311_){
_start:
{
if (lean_obj_tag(v_x_311_) == 0)
{
uint8_t v___x_312_; 
lean_dec(v_code_309_);
v___x_312_ = 0;
return v___x_312_;
}
else
{
lean_object* v_head_313_; lean_object* v_tail_314_; lean_object* v___x_315_; 
v_head_313_ = lean_ctor_get(v_x_311_, 0);
v_tail_314_ = lean_ctor_get(v_x_311_, 1);
lean_inc(v_code_309_);
v___x_315_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_get___redArg(v_head_313_, v_code_309_);
if (lean_obj_tag(v___x_315_) == 0)
{
v_x_311_ = v_tail_314_;
goto _start;
}
else
{
uint8_t v___x_317_; 
lean_dec_ref_known(v___x_315_, 1);
v___x_317_ = lp_compcert4lean_CompCert4Lean_Lib_Coqlib_plt(v_head_313_, v_pc_310_);
if (v___x_317_ == 0)
{
uint8_t v___x_318_; 
lean_dec(v_code_309_);
v___x_318_ = 1;
return v___x_318_;
}
else
{
v_x_311_ = v_tail_314_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_List_any___at___00CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_spec__0___redArg___boxed(lean_object* v_code_320_, lean_object* v_pc_321_, lean_object* v_x_322_){
_start:
{
uint8_t v_res_323_; lean_object* v_r_324_; 
v_res_323_ = lp_compcert4lean_List_any___at___00CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_spec__0___redArg(v_code_320_, v_pc_321_, v_x_322_);
lean_dec(v_x_322_);
lean_dec(v_pc_321_);
v_r_324_ = lean_box(v_res_323_);
return v_r_324_;
}
}
LEAN_EXPORT uint8_t lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node___redArg(lean_object* v_code_325_, lean_object* v_successors_326_, lean_object* v_pc_327_, lean_object* v_instr_328_){
_start:
{
lean_object* v___x_329_; uint8_t v___x_330_; 
v___x_329_ = lean_apply_1(v_successors_326_, v_instr_328_);
v___x_330_ = lp_compcert4lean_List_any___at___00CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_spec__0___redArg(v_code_325_, v_pc_327_, v___x_329_);
lean_dec(v___x_329_);
return v___x_330_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node___redArg___boxed(lean_object* v_code_331_, lean_object* v_successors_332_, lean_object* v_pc_333_, lean_object* v_instr_334_){
_start:
{
uint8_t v_res_335_; lean_object* v_r_336_; 
v_res_335_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node___redArg(v_code_331_, v_successors_332_, v_pc_333_, v_instr_334_);
lean_dec(v_pc_333_);
v_r_336_ = lean_box(v_res_335_);
return v_r_336_;
}
}
LEAN_EXPORT uint8_t lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node(lean_object* v_A_337_, lean_object* v_code_338_, lean_object* v_successors_339_, lean_object* v_pc_340_, lean_object* v_instr_341_){
_start:
{
uint8_t v___x_342_; 
v___x_342_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node___redArg(v_code_338_, v_successors_339_, v_pc_340_, v_instr_341_);
return v___x_342_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node___boxed(lean_object* v_A_343_, lean_object* v_code_344_, lean_object* v_successors_345_, lean_object* v_pc_346_, lean_object* v_instr_347_){
_start:
{
uint8_t v_res_348_; lean_object* v_r_349_; 
v_res_348_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node(v_A_343_, v_code_344_, v_successors_345_, v_pc_346_, v_instr_347_);
lean_dec(v_pc_346_);
v_r_349_ = lean_box(v_res_348_);
return v_r_349_;
}
}
LEAN_EXPORT uint8_t lp_compcert4lean_List_any___at___00CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_spec__0(lean_object* v_A_350_, lean_object* v_code_351_, lean_object* v_pc_352_, lean_object* v_x_353_){
_start:
{
uint8_t v___x_354_; 
v___x_354_ = lp_compcert4lean_List_any___at___00CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_spec__0___redArg(v_code_351_, v_pc_352_, v_x_353_);
return v___x_354_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_List_any___at___00CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_spec__0___boxed(lean_object* v_A_355_, lean_object* v_code_356_, lean_object* v_pc_357_, lean_object* v_x_358_){
_start:
{
uint8_t v_res_359_; lean_object* v_r_360_; 
v_res_359_ = lp_compcert4lean_List_any___at___00CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_spec__0(v_A_355_, v_code_356_, v_pc_357_, v_x_358_);
lean_dec(v_x_358_);
lean_dec(v_pc_357_);
v_r_360_ = lean_box(v_res_359_);
return v_r_360_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_exit__points___redArg___lam__0(lean_object* v_code_361_, lean_object* v_successors_362_, lean_object* v_add_363_, lean_object* v_ep_364_, lean_object* v_pc_365_, lean_object* v_instr_366_){
_start:
{
uint8_t v___x_367_; 
v___x_367_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node___redArg(v_code_361_, v_successors_362_, v_pc_365_, v_instr_366_);
if (v___x_367_ == 0)
{
lean_object* v___x_368_; 
v___x_368_ = lean_apply_2(v_add_363_, v_pc_365_, v_ep_364_);
return v___x_368_;
}
else
{
lean_dec(v_pc_365_);
lean_dec(v_add_363_);
return v_ep_364_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_exit__points___redArg(lean_object* v_NS_369_, lean_object* v_code_370_, lean_object* v_successors_371_){
_start:
{
lean_object* v_empty_372_; lean_object* v_add_373_; lean_object* v___f_374_; lean_object* v___x_375_; 
v_empty_372_ = lean_ctor_get(v_NS_369_, 0);
lean_inc(v_empty_372_);
v_add_373_ = lean_ctor_get(v_NS_369_, 1);
lean_inc(v_add_373_);
lean_dec_ref(v_NS_369_);
lean_inc(v_code_370_);
v___f_374_ = lean_alloc_closure((void*)(lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_exit__points___redArg___lam__0), 6, 3);
lean_closure_set(v___f_374_, 0, v_code_370_);
lean_closure_set(v___f_374_, 1, v_successors_371_);
lean_closure_set(v___f_374_, 2, v_add_373_);
v___x_375_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_fold___redArg(v___f_374_, v_code_370_, v_empty_372_);
return v___x_375_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_exit__points(lean_object* v_A_376_, lean_object* v_NS_377_, lean_object* v_code_378_, lean_object* v_successors_379_){
_start:
{
lean_object* v___x_380_; 
v___x_380_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_exit__points___redArg(v_NS_377_, v_code_378_, v_successors_379_);
return v___x_380_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg___lam__0(lean_object* v_l_381_){
_start:
{
lean_inc(v_l_381_);
return v_l_381_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg___lam__0___boxed(lean_object* v_l_382_){
_start:
{
lean_object* v_res_383_; 
v_res_383_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg___lam__0(v_l_382_);
lean_dec(v_l_382_);
return v_res_383_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg(lean_object* v_LAT_385_, lean_object* v_NS_386_, lean_object* v_code_387_, lean_object* v_successors_388_, lean_object* v_transf_389_){
_start:
{
lean_object* v___f_390_; lean_object* v___x_391_; lean_object* v___x_392_; lean_object* v___x_393_; 
v___f_390_ = ((lean_object*)(lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg___closed__0));
lean_inc_ref(v_successors_388_);
lean_inc(v_code_387_);
v___x_391_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_make__predecessors___redArg(v_code_387_, v_successors_388_);
lean_inc_ref(v_NS_386_);
v___x_392_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_exit__points___redArg(v_NS_386_, v_code_387_, v_successors_388_);
v___x_393_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__nodeset___redArg(v_LAT_385_, v_NS_386_, v___x_391_, v___f_390_, v_transf_389_, v___x_392_);
return v___x_393_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint(lean_object* v_A_394_, lean_object* v_LAT_395_, lean_object* v_NS_396_, lean_object* v_code_397_, lean_object* v_successors_398_, lean_object* v_transf_399_){
_start:
{
lean_object* v___x_400_; 
v___x_400_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg(v_LAT_395_, v_NS_396_, v_code_397_, v_successors_398_, v_transf_399_);
return v___x_400_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint__allnodes___redArg(lean_object* v_LAT_401_, lean_object* v_NS_402_, lean_object* v_code_403_, lean_object* v_successors_404_, lean_object* v_transf_405_){
_start:
{
lean_object* v___f_406_; lean_object* v___x_407_; lean_object* v___x_408_; 
v___f_406_ = ((lean_object*)(lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint___redArg___closed__0));
v___x_407_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_make__predecessors___redArg(v_code_403_, v_successors_404_);
v___x_408_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Dataflow__Solver_fixpoint__allnodes___redArg(v_LAT_401_, v_NS_402_, v___x_407_, v___f_406_, v_transf_405_);
return v___x_408_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint__allnodes(lean_object* v_A_409_, lean_object* v_LAT_410_, lean_object* v_NS_411_, lean_object* v_code_412_, lean_object* v_successors_413_, lean_object* v_transf_414_){
_start:
{
lean_object* v___x_415_; 
v___x_415_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_fixpoint__allnodes___redArg(v_LAT_410_, v_NS_411_, v_code_412_, v_successors_413_, v_transf_414_);
return v___x_415_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_x2eL(lean_object* v_LAT_416_){
_start:
{
lean_inc(v_LAT_416_);
return v_LAT_416_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_x2eL___boxed(lean_object* v_LAT_417_){
_start:
{
lean_object* v_res_418_; 
v_res_418_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_x2eL(v_LAT_417_);
lean_dec(v_LAT_417_);
return v_res_418_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_L(lean_object* v_LAT_419_){
_start:
{
lean_inc(v_LAT_419_);
return v_LAT_419_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_L___boxed(lean_object* v_LAT_420_){
_start:
{
lean_object* v_res_421_; 
v_res_421_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_L(v_LAT_420_);
lean_dec(v_LAT_420_);
return v_res_421_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_propagate__successors___redArg(lean_object* v_bb_422_, lean_object* v_succs_423_, lean_object* v_l_424_, lean_object* v_st_425_){
_start:
{
if (lean_obj_tag(v_succs_423_) == 0)
{
lean_dec(v_l_424_);
lean_dec_ref(v_bb_422_);
return v_st_425_;
}
else
{
lean_object* v_head_426_; lean_object* v_tail_427_; lean_object* v___x_429_; uint8_t v_isShared_430_; uint8_t v_isSharedCheck_448_; 
v_head_426_ = lean_ctor_get(v_succs_423_, 0);
v_tail_427_ = lean_ctor_get(v_succs_423_, 1);
v_isSharedCheck_448_ = !lean_is_exclusive(v_succs_423_);
if (v_isSharedCheck_448_ == 0)
{
v___x_429_ = v_succs_423_;
v_isShared_430_ = v_isSharedCheck_448_;
goto v_resetjp_428_;
}
else
{
lean_inc(v_tail_427_);
lean_inc(v_head_426_);
lean_dec(v_succs_423_);
v___x_429_ = lean_box(0);
v_isShared_430_ = v_isSharedCheck_448_;
goto v_resetjp_428_;
}
v_resetjp_428_:
{
lean_object* v___x_431_; uint8_t v___x_432_; 
lean_inc_ref(v_bb_422_);
lean_inc(v_head_426_);
v___x_431_ = lean_apply_1(v_bb_422_, v_head_426_);
v___x_432_ = lean_unbox(v___x_431_);
if (v___x_432_ == 0)
{
lean_object* v_aval_433_; lean_object* v_worklist_434_; lean_object* v___x_436_; uint8_t v_isShared_437_; uint8_t v_isSharedCheck_446_; 
v_aval_433_ = lean_ctor_get(v_st_425_, 0);
v_worklist_434_ = lean_ctor_get(v_st_425_, 1);
v_isSharedCheck_446_ = !lean_is_exclusive(v_st_425_);
if (v_isSharedCheck_446_ == 0)
{
v___x_436_ = v_st_425_;
v_isShared_437_ = v_isSharedCheck_446_;
goto v_resetjp_435_;
}
else
{
lean_inc(v_worklist_434_);
lean_inc(v_aval_433_);
lean_dec(v_st_425_);
v___x_436_ = lean_box(0);
v_isShared_437_ = v_isSharedCheck_446_;
goto v_resetjp_435_;
}
v_resetjp_435_:
{
lean_object* v___x_438_; lean_object* v___x_440_; 
lean_inc(v_l_424_);
lean_inc(v_head_426_);
v___x_438_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PMap_set___redArg(v_head_426_, v_l_424_, v_aval_433_);
if (v_isShared_430_ == 0)
{
lean_ctor_set(v___x_429_, 1, v_worklist_434_);
v___x_440_ = v___x_429_;
goto v_reusejp_439_;
}
else
{
lean_object* v_reuseFailAlloc_445_; 
v_reuseFailAlloc_445_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_445_, 0, v_head_426_);
lean_ctor_set(v_reuseFailAlloc_445_, 1, v_worklist_434_);
v___x_440_ = v_reuseFailAlloc_445_;
goto v_reusejp_439_;
}
v_reusejp_439_:
{
lean_object* v___x_442_; 
if (v_isShared_437_ == 0)
{
lean_ctor_set(v___x_436_, 1, v___x_440_);
lean_ctor_set(v___x_436_, 0, v___x_438_);
v___x_442_ = v___x_436_;
goto v_reusejp_441_;
}
else
{
lean_object* v_reuseFailAlloc_444_; 
v_reuseFailAlloc_444_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_444_, 0, v___x_438_);
lean_ctor_set(v_reuseFailAlloc_444_, 1, v___x_440_);
v___x_442_ = v_reuseFailAlloc_444_;
goto v_reusejp_441_;
}
v_reusejp_441_:
{
v_succs_423_ = v_tail_427_;
v_st_425_ = v___x_442_;
goto _start;
}
}
}
}
else
{
lean_del_object(v___x_429_);
lean_dec(v_head_426_);
v_succs_423_ = v_tail_427_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_propagate__successors(lean_object* v_LAT_449_, lean_object* v_bb_450_, lean_object* v_succs_451_, lean_object* v_l_452_, lean_object* v_st_453_){
_start:
{
lean_object* v___x_454_; 
v___x_454_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_propagate__successors___redArg(v_bb_450_, v_succs_451_, v_l_452_, v_st_453_);
return v___x_454_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_propagate__successors___boxed(lean_object* v_LAT_455_, lean_object* v_bb_456_, lean_object* v_succs_457_, lean_object* v_l_458_, lean_object* v_st_459_){
_start:
{
lean_object* v_res_460_; 
v_res_460_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_propagate__successors(v_LAT_455_, v_bb_456_, v_succs_457_, v_l_458_, v_st_459_);
lean_dec(v_LAT_455_);
return v_res_460_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_step___redArg(lean_object* v_code_461_, lean_object* v_successors_462_, lean_object* v_transf_463_, lean_object* v_bb_464_, lean_object* v_st_465_){
_start:
{
lean_object* v_worklist_466_; 
v_worklist_466_ = lean_ctor_get(v_st_465_, 1);
if (lean_obj_tag(v_worklist_466_) == 0)
{
lean_object* v_aval_467_; lean_object* v___x_468_; 
lean_dec_ref(v_bb_464_);
lean_dec(v_transf_463_);
lean_dec_ref(v_successors_462_);
lean_dec(v_code_461_);
v_aval_467_ = lean_ctor_get(v_st_465_, 0);
lean_inc_ref(v_aval_467_);
lean_dec_ref(v_st_465_);
v___x_468_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_468_, 0, v_aval_467_);
return v___x_468_;
}
else
{
lean_object* v_aval_469_; lean_object* v___x_471_; uint8_t v_isShared_472_; uint8_t v_isSharedCheck_495_; 
lean_inc_ref(v_worklist_466_);
v_aval_469_ = lean_ctor_get(v_st_465_, 0);
v_isSharedCheck_495_ = !lean_is_exclusive(v_st_465_);
if (v_isSharedCheck_495_ == 0)
{
lean_object* v_unused_496_; 
v_unused_496_ = lean_ctor_get(v_st_465_, 1);
lean_dec(v_unused_496_);
v___x_471_ = v_st_465_;
v_isShared_472_ = v_isSharedCheck_495_;
goto v_resetjp_470_;
}
else
{
lean_inc(v_aval_469_);
lean_dec(v_st_465_);
v___x_471_ = lean_box(0);
v_isShared_472_ = v_isSharedCheck_495_;
goto v_resetjp_470_;
}
v_resetjp_470_:
{
lean_object* v_head_473_; lean_object* v_tail_474_; lean_object* v___x_475_; 
v_head_473_ = lean_ctor_get(v_worklist_466_, 0);
lean_inc(v_head_473_);
v_tail_474_ = lean_ctor_get(v_worklist_466_, 1);
lean_inc(v_tail_474_);
lean_dec_ref_known(v_worklist_466_, 2);
v___x_475_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_get___redArg(v_head_473_, v_code_461_);
if (lean_obj_tag(v___x_475_) == 0)
{
lean_object* v___x_477_; 
lean_dec(v_head_473_);
lean_dec_ref(v_bb_464_);
lean_dec(v_transf_463_);
lean_dec_ref(v_successors_462_);
if (v_isShared_472_ == 0)
{
lean_ctor_set(v___x_471_, 1, v_tail_474_);
v___x_477_ = v___x_471_;
goto v_reusejp_476_;
}
else
{
lean_object* v_reuseFailAlloc_479_; 
v_reuseFailAlloc_479_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_479_, 0, v_aval_469_);
lean_ctor_set(v_reuseFailAlloc_479_, 1, v_tail_474_);
v___x_477_ = v_reuseFailAlloc_479_;
goto v_reusejp_476_;
}
v_reusejp_476_:
{
lean_object* v___x_478_; 
v___x_478_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_478_, 0, v___x_477_);
return v___x_478_;
}
}
else
{
lean_object* v_val_480_; lean_object* v___x_482_; uint8_t v_isShared_483_; uint8_t v_isSharedCheck_494_; 
v_val_480_ = lean_ctor_get(v___x_475_, 0);
v_isSharedCheck_494_ = !lean_is_exclusive(v___x_475_);
if (v_isSharedCheck_494_ == 0)
{
v___x_482_ = v___x_475_;
v_isShared_483_ = v_isSharedCheck_494_;
goto v_resetjp_481_;
}
else
{
lean_inc(v_val_480_);
lean_dec(v___x_475_);
v___x_482_ = lean_box(0);
v_isShared_483_ = v_isSharedCheck_494_;
goto v_resetjp_481_;
}
v_resetjp_481_:
{
lean_object* v___x_484_; lean_object* v___x_485_; lean_object* v___x_486_; lean_object* v___x_488_; 
v___x_484_ = lean_apply_1(v_successors_462_, v_val_480_);
lean_inc_ref(v_aval_469_);
v___x_485_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PMap_get___redArg(v_head_473_, v_aval_469_);
v___x_486_ = lean_apply_2(v_transf_463_, v_head_473_, v___x_485_);
if (v_isShared_472_ == 0)
{
lean_ctor_set(v___x_471_, 1, v_tail_474_);
v___x_488_ = v___x_471_;
goto v_reusejp_487_;
}
else
{
lean_object* v_reuseFailAlloc_493_; 
v_reuseFailAlloc_493_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_493_, 0, v_aval_469_);
lean_ctor_set(v_reuseFailAlloc_493_, 1, v_tail_474_);
v___x_488_ = v_reuseFailAlloc_493_;
goto v_reusejp_487_;
}
v_reusejp_487_:
{
lean_object* v___x_489_; lean_object* v___x_491_; 
v___x_489_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_propagate__successors___redArg(v_bb_464_, v___x_484_, v___x_486_, v___x_488_);
if (v_isShared_483_ == 0)
{
lean_ctor_set(v___x_482_, 0, v___x_489_);
v___x_491_ = v___x_482_;
goto v_reusejp_490_;
}
else
{
lean_object* v_reuseFailAlloc_492_; 
v_reuseFailAlloc_492_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_492_, 0, v___x_489_);
v___x_491_ = v_reuseFailAlloc_492_;
goto v_reusejp_490_;
}
v_reusejp_490_:
{
return v___x_491_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_step(lean_object* v_A_497_, lean_object* v_LAT_498_, lean_object* v_code_499_, lean_object* v_successors_500_, lean_object* v_transf_501_, lean_object* v_bb_502_, lean_object* v_st_503_){
_start:
{
lean_object* v___x_504_; 
v___x_504_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_step___redArg(v_code_499_, v_successors_500_, v_transf_501_, v_bb_502_, v_st_503_);
return v___x_504_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_step___boxed(lean_object* v_A_505_, lean_object* v_LAT_506_, lean_object* v_code_507_, lean_object* v_successors_508_, lean_object* v_transf_509_, lean_object* v_bb_510_, lean_object* v_st_511_){
_start:
{
lean_object* v_res_512_; 
v_res_512_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_step(v_A_505_, v_LAT_506_, v_code_507_, v_successors_508_, v_transf_509_, v_bb_510_, v_st_511_);
lean_dec(v_LAT_506_);
return v_res_512_;
}
}
LEAN_EXPORT uint8_t lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_is__basic__block__head(lean_object* v_entrypoint_513_, lean_object* v_preds_514_, lean_object* v_pc_515_){
_start:
{
uint8_t v___x_516_; 
v___x_516_ = lp_compcert4lean_CompCert4Lean_Foundation_Numbers_Rocq_Coq_Numbers_BinNums_instDecidableEqPositive_decEq(v_pc_515_, v_entrypoint_513_);
if (v___x_516_ == 0)
{
lean_object* v___x_517_; 
v___x_517_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_successors__list(v_preds_514_, v_pc_515_);
if (lean_obj_tag(v___x_517_) == 0)
{
return v___x_516_;
}
else
{
lean_object* v_tail_518_; 
v_tail_518_ = lean_ctor_get(v___x_517_, 1);
lean_inc(v_tail_518_);
if (lean_obj_tag(v_tail_518_) == 0)
{
lean_object* v_head_519_; uint8_t v___x_520_; 
v_head_519_ = lean_ctor_get(v___x_517_, 0);
lean_inc(v_head_519_);
lean_dec_ref_known(v___x_517_, 2);
v___x_520_ = lp_compcert4lean_CompCert4Lean_Foundation_Numbers_Rocq_Coq_Numbers_BinNums_instDecidableEqPositive_decEq(v_head_519_, v_pc_515_);
lean_dec(v_head_519_);
return v___x_520_;
}
else
{
uint8_t v___x_521_; 
lean_dec_ref_known(v_tail_518_, 2);
lean_dec_ref_known(v___x_517_, 2);
v___x_521_ = 1;
return v___x_521_;
}
}
}
else
{
lean_dec(v_preds_514_);
return v___x_516_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_is__basic__block__head___boxed(lean_object* v_entrypoint_522_, lean_object* v_preds_523_, lean_object* v_pc_524_){
_start:
{
uint8_t v_res_525_; lean_object* v_r_526_; 
v_res_525_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_is__basic__block__head(v_entrypoint_522_, v_preds_523_, v_pc_524_);
lean_dec(v_pc_524_);
lean_dec(v_entrypoint_522_);
v_r_526_ = lean_box(v_res_525_);
return v_r_526_;
}
}
LEAN_EXPORT uint8_t lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__map___redArg(lean_object* v_entrypoint_527_, lean_object* v_code_528_, lean_object* v_successors_529_, lean_object* v_pc_530_){
_start:
{
lean_object* v___x_531_; uint8_t v___x_532_; 
v___x_531_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_make__predecessors___redArg(v_code_528_, v_successors_529_);
v___x_532_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_is__basic__block__head(v_entrypoint_527_, v___x_531_, v_pc_530_);
return v___x_532_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__map___redArg___boxed(lean_object* v_entrypoint_533_, lean_object* v_code_534_, lean_object* v_successors_535_, lean_object* v_pc_536_){
_start:
{
uint8_t v_res_537_; lean_object* v_r_538_; 
v_res_537_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__map___redArg(v_entrypoint_533_, v_code_534_, v_successors_535_, v_pc_536_);
lean_dec(v_pc_536_);
lean_dec(v_entrypoint_533_);
v_r_538_ = lean_box(v_res_537_);
return v_r_538_;
}
}
LEAN_EXPORT uint8_t lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__map(lean_object* v_A_539_, lean_object* v_entrypoint_540_, lean_object* v_code_541_, lean_object* v_successors_542_, lean_object* v_pc_543_){
_start:
{
uint8_t v___x_544_; 
v___x_544_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__map___redArg(v_entrypoint_540_, v_code_541_, v_successors_542_, v_pc_543_);
return v___x_544_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__map___boxed(lean_object* v_A_545_, lean_object* v_entrypoint_546_, lean_object* v_code_547_, lean_object* v_successors_548_, lean_object* v_pc_549_){
_start:
{
uint8_t v_res_550_; lean_object* v_r_551_; 
v_res_550_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__map(v_A_545_, v_entrypoint_546_, v_code_547_, v_successors_548_, v_pc_549_);
lean_dec(v_pc_549_);
lean_dec(v_entrypoint_546_);
v_r_551_ = lean_box(v_res_550_);
return v_r_551_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__list___redArg___lam__0(lean_object* v_bb_552_, lean_object* v_l_553_, lean_object* v_pc_554_, lean_object* v_x_555_){
_start:
{
lean_object* v___x_556_; uint8_t v___x_557_; 
lean_inc(v_pc_554_);
v___x_556_ = lean_apply_1(v_bb_552_, v_pc_554_);
v___x_557_ = lean_unbox(v___x_556_);
if (v___x_557_ == 0)
{
lean_dec(v_pc_554_);
return v_l_553_;
}
else
{
lean_object* v___x_558_; 
v___x_558_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_558_, 0, v_pc_554_);
lean_ctor_set(v___x_558_, 1, v_l_553_);
return v___x_558_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__list___redArg___lam__0___boxed(lean_object* v_bb_559_, lean_object* v_l_560_, lean_object* v_pc_561_, lean_object* v_x_562_){
_start:
{
lean_object* v_res_563_; 
v_res_563_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__list___redArg___lam__0(v_bb_559_, v_l_560_, v_pc_561_, v_x_562_);
lean_dec(v_x_562_);
return v_res_563_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__list___redArg(lean_object* v_bb_564_, lean_object* v_code_565_){
_start:
{
lean_object* v___f_566_; lean_object* v___x_567_; lean_object* v___x_568_; 
v___f_566_ = lean_alloc_closure((void*)(lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__list___redArg___lam__0___boxed), 4, 1);
lean_closure_set(v___f_566_, 0, v_bb_564_);
v___x_567_ = lean_box(0);
v___x_568_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_fold___redArg(v___f_566_, v_code_565_, v___x_567_);
return v___x_568_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__list(lean_object* v_A_569_, lean_object* v_bb_570_, lean_object* v_code_571_){
_start:
{
lean_object* v___x_572_; 
v___x_572_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__list___redArg(v_bb_570_, v_code_571_);
return v___x_572_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_fixpoint___redArg(lean_object* v_LAT_573_, lean_object* v_code_574_, lean_object* v_successors_575_, lean_object* v_transf_576_, lean_object* v_entrypoint_577_){
_start:
{
lean_object* v_bb_578_; lean_object* v___x_579_; lean_object* v___x_580_; lean_object* v___x_581_; lean_object* v___x_582_; lean_object* v___x_583_; 
lean_inc_ref(v_successors_575_);
lean_inc_n(v_code_574_, 2);
v_bb_578_ = lean_alloc_closure((void*)(lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__map___boxed), 5, 4);
lean_closure_set(v_bb_578_, 0, lean_box(0));
lean_closure_set(v_bb_578_, 1, v_entrypoint_577_);
lean_closure_set(v_bb_578_, 2, v_code_574_);
lean_closure_set(v_bb_578_, 3, v_successors_575_);
lean_inc_ref(v_bb_578_);
lean_inc(v_LAT_573_);
v___x_579_ = lean_alloc_closure((void*)(lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_step___boxed), 7, 6);
lean_closure_set(v___x_579_, 0, lean_box(0));
lean_closure_set(v___x_579_, 1, v_LAT_573_);
lean_closure_set(v___x_579_, 2, v_code_574_);
lean_closure_set(v___x_579_, 3, v_successors_575_);
lean_closure_set(v___x_579_, 4, v_transf_576_);
lean_closure_set(v___x_579_, 5, v_bb_578_);
v___x_580_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PMap_init___redArg(v_LAT_573_);
v___x_581_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_basic__block__list___redArg(v_bb_578_, v_code_574_);
v___x_582_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_582_, 0, v___x_580_);
lean_ctor_set(v___x_582_, 1, v___x_581_);
v___x_583_ = lp_compcert4lean_CompCert4Lean_Lib_Iteration_PrimIter_iterate___redArg(v___x_579_, v___x_582_);
return v___x_583_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_fixpoint(lean_object* v_A_584_, lean_object* v_LAT_585_, lean_object* v_code_586_, lean_object* v_successors_587_, lean_object* v_transf_588_, lean_object* v_entrypoint_589_){
_start:
{
lean_object* v___x_590_; 
v___x_590_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_fixpoint___redArg(v_LAT_585_, v_code_586_, v_successors_587_, v_transf_588_, v_entrypoint_589_);
return v___x_590_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_predecessors___redArg(lean_object* v_code_591_, lean_object* v_successors_592_){
_start:
{
lean_object* v___x_593_; 
v___x_593_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_make__predecessors___redArg(v_code_591_, v_successors_592_);
return v___x_593_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_BBlock__solver_predecessors(lean_object* v_A_594_, lean_object* v_code_595_, lean_object* v_successors_596_){
_start:
{
lean_object* v___x_597_; 
v___x_597_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_make__predecessors___redArg(v_code_595_, v_successors_596_);
return v___x_597_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___lam__0(lean_object* v_s_598_, lean_object* v_pc_599_, lean_object* v_x_600_){
_start:
{
lean_object* v___x_601_; 
v___x_601_ = lp_compcert4lean_CompCert4Lean_Lib_Heaps_PHeap_insert(v_pc_599_, v_s_598_);
return v___x_601_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___lam__0___boxed(lean_object* v_s_602_, lean_object* v_pc_603_, lean_object* v_x_604_){
_start:
{
lean_object* v_res_605_; 
v_res_605_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___lam__0(v_s_602_, v_pc_603_, v_x_604_);
lean_dec(v_x_604_);
return v_res_605_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___lam__1(lean_object* v_s_606_){
_start:
{
lean_object* v___x_607_; 
v___x_607_ = lp_compcert4lean_CompCert4Lean_Lib_Heaps_SplayHeapSet_R_findMax___redArg(v_s_606_);
if (lean_obj_tag(v___x_607_) == 0)
{
lean_object* v___x_608_; 
lean_dec(v_s_606_);
v___x_608_ = lean_box(0);
return v___x_608_;
}
else
{
lean_object* v_val_609_; lean_object* v___x_611_; uint8_t v_isShared_612_; uint8_t v_isSharedCheck_618_; 
v_val_609_ = lean_ctor_get(v___x_607_, 0);
v_isSharedCheck_618_ = !lean_is_exclusive(v___x_607_);
if (v_isSharedCheck_618_ == 0)
{
v___x_611_ = v___x_607_;
v_isShared_612_ = v_isSharedCheck_618_;
goto v_resetjp_610_;
}
else
{
lean_inc(v_val_609_);
lean_dec(v___x_607_);
v___x_611_ = lean_box(0);
v_isShared_612_ = v_isSharedCheck_618_;
goto v_resetjp_610_;
}
v_resetjp_610_:
{
lean_object* v___x_613_; lean_object* v___x_614_; lean_object* v___x_616_; 
v___x_613_ = lp_compcert4lean_CompCert4Lean_Lib_Heaps_SplayHeapSet_R_deleteMax___redArg(v_s_606_);
v___x_614_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_614_, 0, v_val_609_);
lean_ctor_set(v___x_614_, 1, v___x_613_);
if (v_isShared_612_ == 0)
{
lean_ctor_set(v___x_611_, 0, v___x_614_);
v___x_616_ = v___x_611_;
goto v_reusejp_615_;
}
else
{
lean_object* v_reuseFailAlloc_617_; 
v_reuseFailAlloc_617_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_617_, 0, v___x_614_);
v___x_616_ = v_reuseFailAlloc_617_;
goto v_reusejp_615_;
}
v_reusejp_615_:
{
return v___x_616_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___lam__2(lean_object* v___f_619_, lean_object* v___x_620_, lean_object* v_A_621_, lean_object* v_code_622_){
_start:
{
lean_object* v___x_623_; 
v___x_623_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_fold___redArg(v___f_619_, v_code_622_, v___x_620_);
return v___x_623_;
}
}
static lean_object* _init_lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_empty(void){
_start:
{
lean_object* v___x_636_; 
v___x_636_ = lean_box(0);
return v___x_636_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_add(lean_object* v_n_637_, lean_object* v_s_638_){
_start:
{
lean_object* v___x_639_; 
v___x_639_ = lp_compcert4lean_CompCert4Lean_Lib_Heaps_PHeap_insert(v_n_637_, v_s_638_);
return v___x_639_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_pick(lean_object* v_s_640_){
_start:
{
lean_object* v___x_641_; 
v___x_641_ = lp_compcert4lean_CompCert4Lean_Lib_Heaps_SplayHeapSet_R_findMax___redArg(v_s_640_);
if (lean_obj_tag(v___x_641_) == 0)
{
lean_object* v___x_642_; 
lean_dec(v_s_640_);
v___x_642_ = lean_box(0);
return v___x_642_;
}
else
{
lean_object* v_val_643_; lean_object* v___x_645_; uint8_t v_isShared_646_; uint8_t v_isSharedCheck_652_; 
v_val_643_ = lean_ctor_get(v___x_641_, 0);
v_isSharedCheck_652_ = !lean_is_exclusive(v___x_641_);
if (v_isSharedCheck_652_ == 0)
{
v___x_645_ = v___x_641_;
v_isShared_646_ = v_isSharedCheck_652_;
goto v_resetjp_644_;
}
else
{
lean_inc(v_val_643_);
lean_dec(v___x_641_);
v___x_645_ = lean_box(0);
v_isShared_646_ = v_isSharedCheck_652_;
goto v_resetjp_644_;
}
v_resetjp_644_:
{
lean_object* v___x_647_; lean_object* v___x_648_; lean_object* v___x_650_; 
v___x_647_ = lp_compcert4lean_CompCert4Lean_Lib_Heaps_SplayHeapSet_R_deleteMax___redArg(v_s_640_);
v___x_648_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_648_, 0, v_val_643_);
lean_ctor_set(v___x_648_, 1, v___x_647_);
if (v_isShared_646_ == 0)
{
lean_ctor_set(v___x_645_, 0, v___x_648_);
v___x_650_ = v___x_645_;
goto v_reusejp_649_;
}
else
{
lean_object* v_reuseFailAlloc_651_; 
v_reuseFailAlloc_651_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_651_, 0, v___x_648_);
v___x_650_ = v_reuseFailAlloc_651_;
goto v_reusejp_649_;
}
v_reusejp_649_:
{
return v___x_650_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_all__nodes___redArg(lean_object* v_code_653_){
_start:
{
lean_object* v___f_654_; lean_object* v___x_655_; lean_object* v___x_656_; 
v___f_654_ = ((lean_object*)(lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__0));
v___x_655_ = lean_box(0);
v___x_656_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_fold___redArg(v___f_654_, v_code_653_, v___x_655_);
return v___x_656_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_all__nodes(lean_object* v_A_657_, lean_object* v_code_658_){
_start:
{
lean_object* v___x_659_; 
v___x_659_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_all__nodes___redArg(v_code_658_);
return v___x_659_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward___lam__1(lean_object* v_s_660_){
_start:
{
lean_object* v___x_661_; 
v___x_661_ = lp_compcert4lean_CompCert4Lean_Lib_Heaps_SplayHeapSet_R_findMin___redArg(v_s_660_);
if (lean_obj_tag(v___x_661_) == 0)
{
lean_object* v___x_662_; 
lean_dec(v_s_660_);
v___x_662_ = lean_box(0);
return v___x_662_;
}
else
{
lean_object* v_val_663_; lean_object* v___x_665_; uint8_t v_isShared_666_; uint8_t v_isSharedCheck_672_; 
v_val_663_ = lean_ctor_get(v___x_661_, 0);
v_isSharedCheck_672_ = !lean_is_exclusive(v___x_661_);
if (v_isSharedCheck_672_ == 0)
{
v___x_665_ = v___x_661_;
v_isShared_666_ = v_isSharedCheck_672_;
goto v_resetjp_664_;
}
else
{
lean_inc(v_val_663_);
lean_dec(v___x_661_);
v___x_665_ = lean_box(0);
v_isShared_666_ = v_isSharedCheck_672_;
goto v_resetjp_664_;
}
v_resetjp_664_:
{
lean_object* v___x_667_; lean_object* v___x_668_; lean_object* v___x_670_; 
v___x_667_ = lp_compcert4lean_CompCert4Lean_Lib_Heaps_SplayHeapSet_R_deleteMin___redArg(v_s_660_);
v___x_668_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_668_, 0, v_val_663_);
lean_ctor_set(v___x_668_, 1, v___x_667_);
if (v_isShared_666_ == 0)
{
lean_ctor_set(v___x_665_, 0, v___x_668_);
v___x_670_ = v___x_665_;
goto v_reusejp_669_;
}
else
{
lean_object* v_reuseFailAlloc_671_; 
v_reuseFailAlloc_671_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_671_, 0, v___x_668_);
v___x_670_ = v_reuseFailAlloc_671_;
goto v_reusejp_669_;
}
v_reusejp_669_:
{
return v___x_670_;
}
}
}
}
}
static lean_object* _init_lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_empty(void){
_start:
{
lean_object* v___x_680_; 
v___x_680_ = lean_box(0);
return v___x_680_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_add(lean_object* v_n_681_, lean_object* v_s_682_){
_start:
{
lean_object* v___x_683_; 
v___x_683_ = lp_compcert4lean_CompCert4Lean_Lib_Heaps_PHeap_insert(v_n_681_, v_s_682_);
return v___x_683_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_pick(lean_object* v_s_684_){
_start:
{
lean_object* v___x_685_; 
v___x_685_ = lp_compcert4lean_CompCert4Lean_Lib_Heaps_SplayHeapSet_R_findMin___redArg(v_s_684_);
if (lean_obj_tag(v___x_685_) == 0)
{
lean_object* v___x_686_; 
lean_dec(v_s_684_);
v___x_686_ = lean_box(0);
return v___x_686_;
}
else
{
lean_object* v_val_687_; lean_object* v___x_689_; uint8_t v_isShared_690_; uint8_t v_isSharedCheck_696_; 
v_val_687_ = lean_ctor_get(v___x_685_, 0);
v_isSharedCheck_696_ = !lean_is_exclusive(v___x_685_);
if (v_isSharedCheck_696_ == 0)
{
v___x_689_ = v___x_685_;
v_isShared_690_ = v_isSharedCheck_696_;
goto v_resetjp_688_;
}
else
{
lean_inc(v_val_687_);
lean_dec(v___x_685_);
v___x_689_ = lean_box(0);
v_isShared_690_ = v_isSharedCheck_696_;
goto v_resetjp_688_;
}
v_resetjp_688_:
{
lean_object* v___x_691_; lean_object* v___x_692_; lean_object* v___x_694_; 
v___x_691_ = lp_compcert4lean_CompCert4Lean_Lib_Heaps_SplayHeapSet_R_deleteMin___redArg(v_s_684_);
v___x_692_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_692_, 0, v_val_687_);
lean_ctor_set(v___x_692_, 1, v___x_691_);
if (v_isShared_690_ == 0)
{
lean_ctor_set(v___x_689_, 0, v___x_692_);
v___x_694_ = v___x_689_;
goto v_reusejp_693_;
}
else
{
lean_object* v_reuseFailAlloc_695_; 
v_reuseFailAlloc_695_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_695_, 0, v___x_692_);
v___x_694_ = v_reuseFailAlloc_695_;
goto v_reusejp_693_;
}
v_reusejp_693_:
{
return v___x_694_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_all__nodes___redArg(lean_object* v_code_697_){
_start:
{
lean_object* v___f_698_; lean_object* v___x_699_; lean_object* v___x_700_; 
v___f_698_ = ((lean_object*)(lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward___closed__0));
v___x_699_ = lean_box(0);
v___x_700_ = lp_compcert4lean_CompCert4Lean_Lib_Maps_PTree_fold___redArg(v___f_698_, v_code_697_, v___x_699_);
return v___x_700_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_all__nodes(lean_object* v_A_701_, lean_object* v_code_702_){
_start:
{
lean_object* v___x_703_; 
v___x_703_ = lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_all__nodes___redArg(v_code_702_);
return v___x_703_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_NodeSetBackward_raw__heap__size___redArg(lean_object* v_x_704_){
_start:
{
if (lean_obj_tag(v_x_704_) == 0)
{
lean_object* v___x_705_; 
v___x_705_ = lean_unsigned_to_nat(0u);
return v___x_705_;
}
else
{
lean_object* v_l_706_; lean_object* v_r_707_; lean_object* v___x_708_; lean_object* v___x_709_; lean_object* v___x_710_; lean_object* v___x_711_; lean_object* v___x_712_; 
v_l_706_ = lean_ctor_get(v_x_704_, 0);
v_r_707_ = lean_ctor_get(v_x_704_, 2);
v___x_708_ = lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_NodeSetBackward_raw__heap__size___redArg(v_l_706_);
v___x_709_ = lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_NodeSetBackward_raw__heap__size___redArg(v_r_707_);
v___x_710_ = lean_nat_add(v___x_708_, v___x_709_);
lean_dec(v___x_709_);
lean_dec(v___x_708_);
v___x_711_ = lean_unsigned_to_nat(1u);
v___x_712_ = lean_nat_add(v___x_710_, v___x_711_);
lean_dec(v___x_710_);
return v___x_712_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_NodeSetBackward_raw__heap__size___redArg___boxed(lean_object* v_x_713_){
_start:
{
lean_object* v_res_714_; 
v_res_714_ = lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_NodeSetBackward_raw__heap__size___redArg(v_x_713_);
lean_dec(v_x_713_);
return v_res_714_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_NodeSetBackward_raw__heap__size(lean_object* v_E_715_, lean_object* v_x_716_){
_start:
{
lean_object* v___x_717_; 
v___x_717_ = lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_NodeSetBackward_raw__heap__size___redArg(v_x_716_);
return v___x_717_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_NodeSetBackward_raw__heap__size___boxed(lean_object* v_E_718_, lean_object* v_x_719_){
_start:
{
lean_object* v_res_720_; 
v_res_720_ = lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_NodeSetBackward_raw__heap__size(v_E_718_, v_x_719_);
lean_dec(v_x_719_);
lean_dec_ref(v_E_718_);
return v_res_720_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Lib_Maps_PTree_map__filter1_go_match__1_splitter___redArg(lean_object* v_x_721_, lean_object* v_h__1_722_, lean_object* v_h__2_723_){
_start:
{
if (lean_obj_tag(v_x_721_) == 0)
{
lean_object* v___x_724_; lean_object* v___x_725_; 
lean_dec(v_h__1_722_);
v___x_724_ = lean_box(0);
v___x_725_ = lean_apply_1(v_h__2_723_, v___x_724_);
return v___x_725_;
}
else
{
lean_object* v_val_726_; lean_object* v___x_727_; 
lean_dec(v_h__2_723_);
v_val_726_ = lean_ctor_get(v_x_721_, 0);
lean_inc(v_val_726_);
lean_dec_ref_known(v_x_721_, 1);
v___x_727_ = lean_apply_1(v_h__1_722_, v_val_726_);
return v___x_727_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Lib_Maps_PTree_map__filter1_go_match__1_splitter(lean_object* v_B_728_, lean_object* v_motive_729_, lean_object* v_x_730_, lean_object* v_h__1_731_, lean_object* v_h__2_732_){
_start:
{
if (lean_obj_tag(v_x_730_) == 0)
{
lean_object* v___x_733_; lean_object* v___x_734_; 
lean_dec(v_h__1_731_);
v___x_733_ = lean_box(0);
v___x_734_ = lean_apply_1(v_h__2_732_, v___x_733_);
return v___x_734_;
}
else
{
lean_object* v_val_735_; lean_object* v___x_736_; 
lean_dec(v_h__2_732_);
v_val_735_ = lean_ctor_get(v_x_730_, 0);
lean_inc(v_val_735_);
lean_dec_ref_known(v_x_730_, 1);
v___x_736_ = lean_apply_1(v_h__1_731_, v_val_735_);
return v___x_736_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Dataflow__Solver_propagate__succ__list_match__1_splitter___redArg(lean_object* v_x_737_, lean_object* v_h__1_738_, lean_object* v_h__2_739_){
_start:
{
if (lean_obj_tag(v_x_737_) == 0)
{
lean_object* v___x_740_; lean_object* v___x_741_; 
lean_dec(v_h__2_739_);
v___x_740_ = lean_box(0);
v___x_741_ = lean_apply_1(v_h__1_738_, v___x_740_);
return v___x_741_;
}
else
{
lean_object* v_head_742_; lean_object* v_tail_743_; lean_object* v___x_744_; 
lean_dec(v_h__1_738_);
v_head_742_ = lean_ctor_get(v_x_737_, 0);
lean_inc(v_head_742_);
v_tail_743_ = lean_ctor_get(v_x_737_, 1);
lean_inc(v_tail_743_);
lean_dec_ref_known(v_x_737_, 2);
v___x_744_ = lean_apply_2(v_h__2_739_, v_head_742_, v_tail_743_);
return v___x_744_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Dataflow__Solver_propagate__succ__list_match__1_splitter(lean_object* v_motive_745_, lean_object* v_x_746_, lean_object* v_h__1_747_, lean_object* v_h__2_748_){
_start:
{
if (lean_obj_tag(v_x_746_) == 0)
{
lean_object* v___x_749_; lean_object* v___x_750_; 
lean_dec(v_h__2_748_);
v___x_749_ = lean_box(0);
v___x_750_ = lean_apply_1(v_h__1_747_, v___x_749_);
return v___x_750_;
}
else
{
lean_object* v_head_751_; lean_object* v_tail_752_; lean_object* v___x_753_; 
lean_dec(v_h__1_747_);
v_head_751_ = lean_ctor_get(v_x_746_, 0);
lean_inc(v_head_751_);
v_tail_752_ = lean_ctor_get(v_x_746_, 1);
lean_inc(v_tail_752_);
lean_dec_ref_known(v_x_746_, 2);
v___x_753_ = lean_apply_2(v_h__2_748_, v_head_751_, v_tail_752_);
return v___x_753_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_successors__list_match__1_splitter___redArg(lean_object* v_x_754_, lean_object* v_h__1_755_, lean_object* v_h__2_756_){
_start:
{
if (lean_obj_tag(v_x_754_) == 0)
{
lean_object* v___x_757_; lean_object* v___x_758_; 
lean_dec(v_h__2_756_);
v___x_757_ = lean_box(0);
v___x_758_ = lean_apply_1(v_h__1_755_, v___x_757_);
return v___x_758_;
}
else
{
lean_object* v_val_759_; lean_object* v___x_760_; 
lean_dec(v_h__1_755_);
v_val_759_ = lean_ctor_get(v_x_754_, 0);
lean_inc(v_val_759_);
lean_dec_ref_known(v_x_754_, 1);
v___x_760_ = lean_apply_1(v_h__2_756_, v_val_759_);
return v___x_760_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_successors__list_match__1_splitter(lean_object* v_motive_761_, lean_object* v_x_762_, lean_object* v_h__1_763_, lean_object* v_h__2_764_){
_start:
{
if (lean_obj_tag(v_x_762_) == 0)
{
lean_object* v___x_765_; lean_object* v___x_766_; 
lean_dec(v_h__2_764_);
v___x_765_ = lean_box(0);
v___x_766_ = lean_apply_1(v_h__1_763_, v___x_765_);
return v___x_766_;
}
else
{
lean_object* v_val_767_; lean_object* v___x_768_; 
lean_dec(v_h__1_763_);
v_val_767_ = lean_ctor_get(v_x_762_, 0);
lean_inc(v_val_767_);
lean_dec_ref_known(v_x_762_, 1);
v___x_768_ = lean_apply_1(v_h__2_764_, v_val_767_);
return v___x_768_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value_match__1_splitter___redArg(lean_object* v_x_769_, lean_object* v_h__1_770_, lean_object* v_h__2_771_){
_start:
{
if (lean_obj_tag(v_x_769_) == 0)
{
lean_object* v___x_772_; lean_object* v___x_773_; 
lean_dec(v_h__2_771_);
v___x_772_ = lean_box(0);
v___x_773_ = lean_apply_1(v_h__1_770_, v___x_772_);
return v___x_773_;
}
else
{
lean_object* v_val_774_; lean_object* v___x_775_; 
lean_dec(v_h__1_770_);
v_val_774_ = lean_ctor_get(v_x_769_, 0);
lean_inc(v_val_774_);
lean_dec_ref_known(v_x_769_, 1);
v___x_775_ = lean_apply_1(v_h__2_771_, v_val_774_);
return v___x_775_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value_match__1_splitter(lean_object* v_LAT_776_, lean_object* v_motive_777_, lean_object* v_x_778_, lean_object* v_h__1_779_, lean_object* v_h__2_780_){
_start:
{
if (lean_obj_tag(v_x_778_) == 0)
{
lean_object* v___x_781_; lean_object* v___x_782_; 
lean_dec(v_h__2_780_);
v___x_781_ = lean_box(0);
v___x_782_ = lean_apply_1(v_h__1_779_, v___x_781_);
return v___x_782_;
}
else
{
lean_object* v_val_783_; lean_object* v___x_784_; 
lean_dec(v_h__1_779_);
v_val_783_ = lean_ctor_get(v_x_778_, 0);
lean_inc(v_val_783_);
lean_dec_ref_known(v_x_778_, 1);
v___x_784_ = lean_apply_1(v_h__2_780_, v_val_783_);
return v___x_784_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value_match__1_splitter___boxed(lean_object* v_LAT_785_, lean_object* v_motive_786_, lean_object* v_x_787_, lean_object* v_h__1_788_, lean_object* v_h__2_789_){
_start:
{
lean_object* v_res_790_; 
v_res_790_ = lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Dataflow__Solver_abstr__value_match__1_splitter(v_LAT_785_, v_motive_786_, v_x_787_, v_h__1_788_, v_h__2_789_);
lean_dec_ref(v_LAT_785_);
return v_res_790_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_match__1_splitter___redArg(uint8_t v_x_791_, lean_object* v_h__1_792_, lean_object* v_h__2_793_){
_start:
{
if (v_x_791_ == 0)
{
lean_object* v___x_794_; 
lean_dec(v_h__2_793_);
v___x_794_ = lean_apply_1(v_h__1_792_, lean_box(0));
return v___x_794_;
}
else
{
lean_object* v___x_795_; 
lean_dec(v_h__1_792_);
v___x_795_ = lean_apply_1(v_h__2_793_, lean_box(0));
return v___x_795_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_match__1_splitter___redArg___boxed(lean_object* v_x_796_, lean_object* v_h__1_797_, lean_object* v_h__2_798_){
_start:
{
uint8_t v_x_24__boxed_799_; lean_object* v_res_800_; 
v_x_24__boxed_799_ = lean_unbox(v_x_796_);
v_res_800_ = lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_match__1_splitter___redArg(v_x_24__boxed_799_, v_h__1_797_, v_h__2_798_);
return v_res_800_;
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_match__1_splitter(lean_object* v_pc_801_, lean_object* v_s_802_, lean_object* v_motive_803_, uint8_t v_x_804_, lean_object* v_h__1_805_, lean_object* v_h__2_806_){
_start:
{
if (v_x_804_ == 0)
{
lean_object* v___x_807_; 
lean_dec(v_h__2_806_);
v___x_807_ = lean_apply_1(v_h__1_805_, lean_box(0));
return v___x_807_;
}
else
{
lean_object* v___x_808_; 
lean_dec(v_h__1_805_);
v___x_808_ = lean_apply_1(v_h__2_806_, lean_box(0));
return v___x_808_;
}
}
}
LEAN_EXPORT lean_object* lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_match__1_splitter___boxed(lean_object* v_pc_809_, lean_object* v_s_810_, lean_object* v_motive_811_, lean_object* v_x_812_, lean_object* v_h__1_813_, lean_object* v_h__2_814_){
_start:
{
uint8_t v_x_31__boxed_815_; lean_object* v_res_816_; 
v_x_31__boxed_815_ = lean_unbox(v_x_812_);
v_res_816_ = lp_compcert4lean___private_CompCert4Lean_Backend_Kildall_0__CompCert4Lean_Backend_Kildall_Backward__Dataflow__Solver_sequential__node_match__1_splitter(v_pc_809_, v_s_810_, v_motive_811_, v_x_31__boxed_815_, v_h__1_813_, v_h__2_814_);
lean_dec(v_s_810_);
lean_dec(v_pc_809_);
return v_res_816_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_compcert4lean_CompCert4Lean_Foundation_Logic(uint8_t builtin);
lean_object* initialize_compcert4lean_CompCert4Lean_Foundation_Numbers(uint8_t builtin);
lean_object* initialize_compcert4lean_CompCert4Lean_Foundation_Recursion(uint8_t builtin);
lean_object* initialize_compcert4lean_CompCert4Lean_Lib_Coqlib(uint8_t builtin);
lean_object* initialize_compcert4lean_CompCert4Lean_Lib_Heaps(uint8_t builtin);
lean_object* initialize_compcert4lean_CompCert4Lean_Lib_Iteration(uint8_t builtin);
lean_object* initialize_compcert4lean_CompCert4Lean_Lib_Lattice(uint8_t builtin);
lean_object* initialize_compcert4lean_CompCert4Lean_Lib_Maps(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_compcert4lean_CompCert4Lean_Backend_Kildall(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_compcert4lean_CompCert4Lean_Foundation_Logic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_compcert4lean_CompCert4Lean_Foundation_Numbers(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_compcert4lean_CompCert4Lean_Foundation_Recursion(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_compcert4lean_CompCert4Lean_Lib_Coqlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_compcert4lean_CompCert4Lean_Lib_Heaps(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_compcert4lean_CompCert4Lean_Lib_Iteration(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_compcert4lean_CompCert4Lean_Lib_Lattice(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_compcert4lean_CompCert4Lean_Lib_Maps(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_empty = _init_lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_empty();
lean_mark_persistent(lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetForward_empty);
lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_empty = _init_lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_empty();
lean_mark_persistent(lp_compcert4lean_CompCert4Lean_Backend_Kildall_NodeSetBackward_empty);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
