# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/optimization-m0xrkdng/inline.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/optimization-m0xrkdng/inline.c"
static inline int declared(int value){return value+1;}
static __attribute__((noinline)) int kept(int value){return value+2;}
static int once(int value){return declared(value)+3;}
int main(void){return once(4)+kept(5)-15;}
