static inline int declared(int value){return value+1;}
static __attribute__((noinline)) int kept(int value){return value+2;}
static int once(int value){return declared(value)+3;}
int main(void){return once(4)+kept(5)-15;}
