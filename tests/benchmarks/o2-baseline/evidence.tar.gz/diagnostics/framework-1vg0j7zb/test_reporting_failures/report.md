# Small-test correctness report

Target: Linux System V x86-64, O0, iterated register coalescing allocator.

Run complete: True.

Counts: pass=0, fail=1, timeout=0, unavailable=0, excluded=0

Pipeline counts: {"lean": {"fail": 1, "pass": 0, "timeout": 0, "unavailable": 0}, "reference": {"fail": 0, "pass": 0, "timeout": 0, "unavailable": 1}}

Compiler failures remain failures. Reference/harness failures make a check unavailable.

| Case | Verdict | Lean | CompCert |
| --- | --- | --- | --- |
| deliberate/fail | fail | fail | unavailable |

## Failures and unavailable checks

### deliberate/fail / lean

Category: None

```text
wrong stdout
```

### deliberate/fail / reference

Category: None

```text
reference failed
```

## Justified exclusions


Commands, flags, timings, versions, hashes and artifact locations: `results.json`.
