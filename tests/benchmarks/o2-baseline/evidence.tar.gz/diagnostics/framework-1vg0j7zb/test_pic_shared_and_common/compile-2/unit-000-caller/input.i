# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/framework-1vg0j7zb/test_pic_shared_and_common/caller.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/framework-1vg0j7zb/test_pic_shared_and_common/caller.c"
int outside=5; int sum(void); int main(void){return sum()-12;}
