#include <stdio.h>
int main(void){FILE *out=fopen("image", "w"); fputs("wrong", out); fclose(out); return 0;}