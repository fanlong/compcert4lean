# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/optimization-pjuk17p7/printer-profile/source.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/optimization-pjuk17p7/printer-profile/source.c"
int main(void){return 0;}
