# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/framework-bwuiwl4p/test_pipeline_failure_verdicts/invalid/regression/invalid.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/framework-bwuiwl4p/test_pipeline_failure_verdicts/invalid/regression/invalid.c"
int main( {
