# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/framework-bwuiwl4p/test_cross_file_private_names_and_objects/first.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/framework-bwuiwl4p/test_cross_file_private_names_and_objects/first.c"
static int value=2; static int local(void){return value;} int global=5; int read(void){return local();}
