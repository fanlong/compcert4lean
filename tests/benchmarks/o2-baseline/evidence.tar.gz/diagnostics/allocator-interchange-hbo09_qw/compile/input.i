# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/allocator-interchange-hbo09_qw/reserved.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/allocator-interchange-hbo09_qw/reserved.c"
#pragma reserve_register R12
#pragma reserve_register RBX
#pragma reserve_register R12
int main(void){return 0;}
