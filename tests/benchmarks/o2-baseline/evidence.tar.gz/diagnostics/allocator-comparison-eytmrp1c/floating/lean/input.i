# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/allocator-comparison-eytmrp1c/floating/floating.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/allocator-comparison-eytmrp1c/floating/floating.c"
extern volatile double values[24]; double sum(void){double value0=values[0];double value1=values[1];double value2=values[2];double value3=values[3];double value4=values[4];double value5=values[5];double value6=values[6];double value7=values[7];double value8=values[8];double value9=values[9];double value10=values[10];double value11=values[11];double value12=values[12];double value13=values[13];double value14=values[14];double value15=values[15];double value16=values[16];double value17=values[17];double value18=values[18];double value19=values[19];double value20=values[20];double value21=values[21];double value22=values[22];double value23=values[23];return value0+value1+value2+value3+value4+value5+value6+value7+value8+value9+value10+value11+value12+value13+value14+value15+value16+value17+value18+value19+value20+value21+value22+value23;}
