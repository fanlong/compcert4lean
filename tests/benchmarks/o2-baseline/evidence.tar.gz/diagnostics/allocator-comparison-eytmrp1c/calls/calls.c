extern int opaque(int); int across(int a, int b){int c=opaque(a); return a+b+c;}
