# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/allocator-comparison-eytmrp1c/calls/calls.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/allocator-comparison-eytmrp1c/calls/calls.c"
extern int opaque(int); int across(int a, int b){int c=opaque(a); return a+b+c;}
