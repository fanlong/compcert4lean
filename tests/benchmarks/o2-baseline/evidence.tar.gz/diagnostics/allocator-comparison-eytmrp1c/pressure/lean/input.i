# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/allocator-comparison-eytmrp1c/pressure/pressure.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/allocator-comparison-eytmrp1c/pressure/pressure.c"
extern volatile int values[24]; int sum(void){int value0=values[0];int value1=values[1];int value2=values[2];int value3=values[3];int value4=values[4];int value5=values[5];int value6=values[6];int value7=values[7];int value8=values[8];int value9=values[9];int value10=values[10];int value11=values[11];int value12=values[12];int value13=values[13];int value14=values[14];int value15=values[15];int value16=values[16];int value17=values[17];int value18=values[18];int value19=values[19];int value20=values[20];int value21=values[21];int value22=values[22];int value23=values[23];return value0+value1+value2+value3+value4+value5+value6+value7+value8+value9+value10+value11+value12+value13+value14+value15+value16+value17+value18+value19+value20+value21+value22+value23;}
