# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/allocator-comparison-eytmrp1c/copy/copy.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/allocator-comparison-eytmrp1c/copy/copy.c"
int copy(int a){int b=a; int c=b; int d=c; return d;}
