int copy(int a){int b=a; int c=b; int d=c; return d;}
