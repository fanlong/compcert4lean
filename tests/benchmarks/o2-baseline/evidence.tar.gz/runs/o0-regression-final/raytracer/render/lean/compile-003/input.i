# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c"


# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/config.h" 1
# 1 "/usr/include/math.h" 1 3 4
# 27 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 28 "/usr/include/math.h" 2 3 4









# 1 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libm-simd-decl-stubs.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 2 3 4
# 38 "/usr/include/math.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4

# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 41 "/usr/include/math.h" 2 3 4
# 157 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/flt-eval-method.h" 1 3 4
# 158 "/usr/include/math.h" 2 3 4
# 170 "/usr/include/math.h" 3 4
typedef float float_t;
typedef double double_t;
# 376 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/fp-logb.h" 1 3 4
# 377 "/usr/include/math.h" 2 3 4
# 419 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/fp-fast.h" 1 3 4
# 420 "/usr/include/math.h" 2 3 4
# 443 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-macros.h" 1 3 4
# 444 "/usr/include/math.h" 2 3 4





# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassify (double __value)
     ;


extern int __signbit (double __value)
     ;



extern int __isinf (double __value)
  ;


extern int __finite (double __value)
  ;


extern int __isnan (double __value)
  ;


extern int __iseqsig (double __x, double __y) ;


extern int __issignaling (double __value)
     ;
# 450 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double acos (double __x) ; extern double __acos (double __x) ;

 extern double asin (double __x) ; extern double __asin (double __x) ;

 extern double atan (double __x) ; extern double __atan (double __x) ;

 extern double atan2 (double __y, double __x) ; extern double __atan2 (double __y, double __x) ;


 extern double cos (double __x) ; extern double __cos (double __x) ;

 extern double sin (double __x) ; extern double __sin (double __x) ;

 extern double tan (double __x) ; extern double __tan (double __x) ;
# 93 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double cosh (double __x) ; extern double __cosh (double __x) ;

 extern double sinh (double __x) ; extern double __sinh (double __x) ;

 extern double tanh (double __x) ; extern double __tanh (double __x) ;
# 107 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double acosh (double __x) ; extern double __acosh (double __x) ;

 extern double asinh (double __x) ; extern double __asinh (double __x) ;

 extern double atanh (double __x) ; extern double __atanh (double __x) ;





 extern double exp (double __x) ; extern double __exp (double __x) ;


extern double frexp (double __x, int *__exponent) ; extern double __frexp (double __x, int *__exponent) ;


extern double ldexp (double __x, int __exponent) ; extern double __ldexp (double __x, int __exponent) ;


 extern double log (double __x) ; extern double __log (double __x) ;


 extern double log10 (double __x) ; extern double __log10 (double __x) ;


extern double modf (double __x, double *__iptr) ; extern double __modf (double __x, double *__iptr) ;
# 156 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double expm1 (double __x) ; extern double __expm1 (double __x) ;


 extern double log1p (double __x) ; extern double __log1p (double __x) ;


extern double logb (double __x) ; extern double __logb (double __x) ;




 extern double exp2 (double __x) ; extern double __exp2 (double __x) ;


 extern double log2 (double __x) ; extern double __log2 (double __x) ;






 extern double pow (double __x, double __y) ; extern double __pow (double __x, double __y) ;


extern double sqrt (double __x) ; extern double __sqrt (double __x) ;



 extern double hypot (double __x, double __y) ; extern double __hypot (double __x, double __y) ;




 extern double cbrt (double __x) ; extern double __cbrt (double __x) ;
# 213 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double ceil (double __x) ;


extern double fabs (double __x) ;


extern double floor (double __x) ;


extern double fmod (double __x, double __y) ; extern double __fmod (double __x, double __y) ;
# 252 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double copysign (double __x, double __y) ;




extern double nan (const char *__tagb) ; extern double __nan (const char *__tagb) ;
# 285 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double erf (double) ; extern double __erf (double) ;
 extern double erfc (double) ; extern double __erfc (double) ;
extern double lgamma (double) ; extern double __lgamma (double) ;




extern double tgamma (double) ; extern double __tgamma (double) ;
# 313 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double rint (double __x) ; extern double __rint (double __x) ;


extern double nextafter (double __x, double __y) ; extern double __nextafter (double __x, double __y) ;

extern double nexttoward (double __x, long double __y) ; extern double __nexttoward (double __x, long double __y) ;
# 329 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double remainder (double __x, double __y) ; extern double __remainder (double __x, double __y) ;



extern double scalbn (double __x, int __n) ; extern double __scalbn (double __x, int __n) ;



extern int ilogb (double __x) ; extern int __ilogb (double __x) ;
# 347 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double scalbln (double __x, long int __n) ; extern double __scalbln (double __x, long int __n) ;



extern double nearbyint (double __x) ; extern double __nearbyint (double __x) ;



extern double round (double __x) ;



extern double trunc (double __x) ;




extern double remquo (double __x, double __y, int *__quo) ; extern double __remquo (double __x, double __y, int *__quo) ;






extern long int lrint (double __x) ; extern long int __lrint (double __x) ;

extern long long int llrint (double __x) ; extern long long int __llrint (double __x) ;



extern long int lround (double __x) ; extern long int __lround (double __x) ;

extern long long int llround (double __x) ; extern long long int __llround (double __x) ;



extern double fdim (double __x, double __y) ; extern double __fdim (double __x, double __y) ;



extern double fmax (double __x, double __y) ;


extern double fmin (double __x, double __y) ;



extern double fma (double __x, double __y, double __z) ; extern double __fma (double __x, double __y, double __z) ;
# 451 "/usr/include/math.h" 2 3 4
# 466 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyf (float __value)
     ;


extern int __signbitf (float __value)
     ;



extern int __isinff (float __value)
  ;


extern int __finitef (float __value)
  ;


extern int __isnanf (float __value)
  ;


extern int __iseqsigf (float __x, float __y) ;


extern int __issignalingf (float __value)
     ;
# 467 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float acosf (float __x) ; extern float __acosf (float __x) ;

 extern float asinf (float __x) ; extern float __asinf (float __x) ;

 extern float atanf (float __x) ; extern float __atanf (float __x) ;

 extern float atan2f (float __y, float __x) ; extern float __atan2f (float __y, float __x) ;


 extern float cosf (float __x) ; extern float __cosf (float __x) ;

 extern float sinf (float __x) ; extern float __sinf (float __x) ;

 extern float tanf (float __x) ; extern float __tanf (float __x) ;
# 93 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float coshf (float __x) ; extern float __coshf (float __x) ;

 extern float sinhf (float __x) ; extern float __sinhf (float __x) ;

 extern float tanhf (float __x) ; extern float __tanhf (float __x) ;
# 107 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float acoshf (float __x) ; extern float __acoshf (float __x) ;

 extern float asinhf (float __x) ; extern float __asinhf (float __x) ;

 extern float atanhf (float __x) ; extern float __atanhf (float __x) ;





 extern float expf (float __x) ; extern float __expf (float __x) ;


extern float frexpf (float __x, int *__exponent) ; extern float __frexpf (float __x, int *__exponent) ;


extern float ldexpf (float __x, int __exponent) ; extern float __ldexpf (float __x, int __exponent) ;


 extern float logf (float __x) ; extern float __logf (float __x) ;


 extern float log10f (float __x) ; extern float __log10f (float __x) ;


extern float modff (float __x, float *__iptr) ; extern float __modff (float __x, float *__iptr) ;
# 156 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float expm1f (float __x) ; extern float __expm1f (float __x) ;


 extern float log1pf (float __x) ; extern float __log1pf (float __x) ;


extern float logbf (float __x) ; extern float __logbf (float __x) ;




 extern float exp2f (float __x) ; extern float __exp2f (float __x) ;


 extern float log2f (float __x) ; extern float __log2f (float __x) ;






 extern float powf (float __x, float __y) ; extern float __powf (float __x, float __y) ;


extern float sqrtf (float __x) ; extern float __sqrtf (float __x) ;



 extern float hypotf (float __x, float __y) ; extern float __hypotf (float __x, float __y) ;




 extern float cbrtf (float __x) ; extern float __cbrtf (float __x) ;
# 213 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float ceilf (float __x) ;


extern float fabsf (float __x) ;


extern float floorf (float __x) ;


extern float fmodf (float __x, float __y) ; extern float __fmodf (float __x, float __y) ;
# 252 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float copysignf (float __x, float __y) ;




extern float nanf (const char *__tagb) ; extern float __nanf (const char *__tagb) ;
# 285 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float erff (float) ; extern float __erff (float) ;
 extern float erfcf (float) ; extern float __erfcf (float) ;
extern float lgammaf (float) ; extern float __lgammaf (float) ;




extern float tgammaf (float) ; extern float __tgammaf (float) ;
# 313 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float rintf (float __x) ; extern float __rintf (float __x) ;


extern float nextafterf (float __x, float __y) ; extern float __nextafterf (float __x, float __y) ;

extern float nexttowardf (float __x, long double __y) ; extern float __nexttowardf (float __x, long double __y) ;
# 329 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float remainderf (float __x, float __y) ; extern float __remainderf (float __x, float __y) ;



extern float scalbnf (float __x, int __n) ; extern float __scalbnf (float __x, int __n) ;



extern int ilogbf (float __x) ; extern int __ilogbf (float __x) ;
# 347 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float scalblnf (float __x, long int __n) ; extern float __scalblnf (float __x, long int __n) ;



extern float nearbyintf (float __x) ; extern float __nearbyintf (float __x) ;



extern float roundf (float __x) ;



extern float truncf (float __x) ;




extern float remquof (float __x, float __y, int *__quo) ; extern float __remquof (float __x, float __y, int *__quo) ;






extern long int lrintf (float __x) ; extern long int __lrintf (float __x) ;

extern long long int llrintf (float __x) ; extern long long int __llrintf (float __x) ;



extern long int lroundf (float __x) ; extern long int __lroundf (float __x) ;

extern long long int llroundf (float __x) ; extern long long int __llroundf (float __x) ;



extern float fdimf (float __x, float __y) ; extern float __fdimf (float __x, float __y) ;



extern float fmaxf (float __x, float __y) ;


extern float fminf (float __x, float __y) ;



extern float fmaf (float __x, float __y, float __z) ; extern float __fmaf (float __x, float __y, float __z) ;
# 468 "/usr/include/math.h" 2 3 4
# 535 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyl (long double __value)
     ;


extern int __signbitl (long double __value)
     ;



extern int __isinfl (long double __value)
  ;


extern int __finitel (long double __value)
  ;


extern int __isnanl (long double __value)
  ;


extern int __iseqsigl (long double __x, long double __y) ;


extern int __issignalingl (long double __value)
     ;
# 536 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double acosl (long double __x) ; extern long double __acosl (long double __x) ;

 extern long double asinl (long double __x) ; extern long double __asinl (long double __x) ;

 extern long double atanl (long double __x) ; extern long double __atanl (long double __x) ;

 extern long double atan2l (long double __y, long double __x) ; extern long double __atan2l (long double __y, long double __x) ;


 extern long double cosl (long double __x) ; extern long double __cosl (long double __x) ;

 extern long double sinl (long double __x) ; extern long double __sinl (long double __x) ;

 extern long double tanl (long double __x) ; extern long double __tanl (long double __x) ;
# 93 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double coshl (long double __x) ; extern long double __coshl (long double __x) ;

 extern long double sinhl (long double __x) ; extern long double __sinhl (long double __x) ;

 extern long double tanhl (long double __x) ; extern long double __tanhl (long double __x) ;
# 107 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double acoshl (long double __x) ; extern long double __acoshl (long double __x) ;

 extern long double asinhl (long double __x) ; extern long double __asinhl (long double __x) ;

 extern long double atanhl (long double __x) ; extern long double __atanhl (long double __x) ;





 extern long double expl (long double __x) ; extern long double __expl (long double __x) ;


extern long double frexpl (long double __x, int *__exponent) ; extern long double __frexpl (long double __x, int *__exponent) ;


extern long double ldexpl (long double __x, int __exponent) ; extern long double __ldexpl (long double __x, int __exponent) ;


 extern long double logl (long double __x) ; extern long double __logl (long double __x) ;


 extern long double log10l (long double __x) ; extern long double __log10l (long double __x) ;


extern long double modfl (long double __x, long double *__iptr) ; extern long double __modfl (long double __x, long double *__iptr) ;
# 156 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double expm1l (long double __x) ; extern long double __expm1l (long double __x) ;


 extern long double log1pl (long double __x) ; extern long double __log1pl (long double __x) ;


extern long double logbl (long double __x) ; extern long double __logbl (long double __x) ;




 extern long double exp2l (long double __x) ; extern long double __exp2l (long double __x) ;


 extern long double log2l (long double __x) ; extern long double __log2l (long double __x) ;






 extern long double powl (long double __x, long double __y) ; extern long double __powl (long double __x, long double __y) ;


extern long double sqrtl (long double __x) ; extern long double __sqrtl (long double __x) ;



 extern long double hypotl (long double __x, long double __y) ; extern long double __hypotl (long double __x, long double __y) ;




 extern long double cbrtl (long double __x) ; extern long double __cbrtl (long double __x) ;
# 213 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double ceill (long double __x) ;


extern long double fabsl (long double __x) ;


extern long double floorl (long double __x) ;


extern long double fmodl (long double __x, long double __y) ; extern long double __fmodl (long double __x, long double __y) ;
# 252 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double copysignl (long double __x, long double __y) ;




extern long double nanl (const char *__tagb) ; extern long double __nanl (const char *__tagb) ;
# 285 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double erfl (long double) ; extern long double __erfl (long double) ;
 extern long double erfcl (long double) ; extern long double __erfcl (long double) ;
extern long double lgammal (long double) ; extern long double __lgammal (long double) ;




extern long double tgammal (long double) ; extern long double __tgammal (long double) ;
# 313 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double rintl (long double __x) ; extern long double __rintl (long double __x) ;


extern long double nextafterl (long double __x, long double __y) ; extern long double __nextafterl (long double __x, long double __y) ;

extern long double nexttowardl (long double __x, long double __y) ; extern long double __nexttowardl (long double __x, long double __y) ;
# 329 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double remainderl (long double __x, long double __y) ; extern long double __remainderl (long double __x, long double __y) ;



extern long double scalbnl (long double __x, int __n) ; extern long double __scalbnl (long double __x, int __n) ;



extern int ilogbl (long double __x) ; extern int __ilogbl (long double __x) ;
# 347 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double scalblnl (long double __x, long int __n) ; extern long double __scalblnl (long double __x, long int __n) ;



extern long double nearbyintl (long double __x) ; extern long double __nearbyintl (long double __x) ;



extern long double roundl (long double __x) ;



extern long double truncl (long double __x) ;




extern long double remquol (long double __x, long double __y, int *__quo) ; extern long double __remquol (long double __x, long double __y, int *__quo) ;






extern long int lrintl (long double __x) ; extern long int __lrintl (long double __x) ;

extern long long int llrintl (long double __x) ; extern long long int __llrintl (long double __x) ;



extern long int lroundl (long double __x) ; extern long int __lroundl (long double __x) ;

extern long long int llroundl (long double __x) ; extern long long int __llroundl (long double __x) ;



extern long double fdiml (long double __x, long double __y) ; extern long double __fdiml (long double __x, long double __y) ;



extern long double fmaxl (long double __x, long double __y) ;


extern long double fminl (long double __x, long double __y) ;



extern long double fmal (long double __x, long double __y, long double __z) ; extern long double __fmal (long double __x, long double __y, long double __z) ;
# 537 "/usr/include/math.h" 2 3 4
# 1071 "/usr/include/math.h" 3 4
enum
  {
    FP_NAN =

      0,
    FP_INFINITE =

      1,
    FP_ZERO =

      2,
    FP_SUBNORMAL =

      3,
    FP_NORMAL =

      4
  };
# 1609 "/usr/include/math.h" 3 4

# 2 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/config.h" 2
# 1 "/usr/include/assert.h" 1 3 4
# 94 "/usr/include/assert.h" 3 4



extern void __assert_fail (const char *__assertion, const char *__file,
      unsigned int __line, const char *__function)
     ;


extern void __assert_perror_fail (int __errnum, const char *__file,
      unsigned int __line, const char *__function)
     ;




extern void __assert (const char *__assertion, const char *__file, int __line)
     ;
# 120 "/usr/include/assert.h" 3 4

# 3 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/config.h" 2
# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1
# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h"

# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h"
typedef unsigned long size_t;
# 76 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h"
typedef signed long ptrdiff_t;
# 98 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h"
typedef int wchar_t;
# 122 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h"
typedef long long max_align_t;
# 4 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/config.h" 2
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 29 "/usr/include/stdio.h" 2 3 4









# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 39 "/usr/include/stdio.h" 2 3 4


# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 1 3 4
# 43 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 3 4

# 43 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 42 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 45 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 46 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 47 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 48 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 2 3 4

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2:24;

  char _short_backupbuf[1];
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;

  int _unused3;

  __uint64_t _total_written;




  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
# 49 "/usr/include/stdio.h" 2 3 4
# 89 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;
# 133 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 134 "/usr/include/stdio.h" 2 3 4
# 153 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) ;

extern int rename (const char *__old, const char *__new) ;
# 191 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) ;
# 201 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  ;
# 218 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) ;
# 243 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 271 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *restrict __filename,
      const char *restrict __modes)
  ;




extern FILE *freopen (const char *restrict __filename,
        const char *restrict __modes,
        FILE *restrict __stream) ;
# 341 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *restrict __stream, char *restrict __buf)
  ;



extern int setvbuf (FILE *restrict __stream, char *restrict __buf,
      int __modes, size_t __n) ;
# 364 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *restrict __stream,
      const char *restrict __format, ...) ;




extern int printf (const char *restrict __format, ...);

extern int sprintf (char *restrict __s,
      const char *restrict __format, ...) ;





extern int vfprintf (FILE *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;




extern int vprintf (const char *restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;



extern int snprintf (char *restrict __s, size_t __maxlen,
       const char *restrict __format, ...)
     ;

extern int vsnprintf (char *restrict __s, size_t __maxlen,
        const char *restrict __format, __gnuc_va_list __arg)
     ;
# 429 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *restrict __stream,
     const char *restrict __format, ...) ;




extern int scanf (const char *restrict __format, ...) ;

extern int sscanf (const char *restrict __s,
     const char *restrict __format, ...) ;
# 479 "/usr/include/stdio.h" 3 4
extern int __isoc99_fscanf (FILE *restrict __stream,
       const char *restrict __format, ...)
  ;
extern int __isoc99_scanf (const char *restrict __format, ...) ;
extern int __isoc99_sscanf (const char *restrict __s,
       const char *restrict __format, ...) ;
# 497 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *restrict __s, const char *restrict __format,
      __gnuc_va_list __arg)
     ;





extern int vscanf (const char *restrict __format, __gnuc_va_list __arg)
     ;


extern int vsscanf (const char *restrict __s,
      const char *restrict __format, __gnuc_va_list __arg)
     ;
# 561 "/usr/include/stdio.h" 3 4
extern int __isoc99_vfscanf (FILE *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
extern int __isoc99_vscanf (const char *restrict __format,
       __gnuc_va_list __arg) ;
extern int __isoc99_vsscanf (const char *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
# 582 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) ;
extern int getc (FILE *__stream) ;





extern int getchar (void);
# 615 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) ;
extern int putc (int __c, FILE *__stream) ;





extern int putchar (int __c);
# 658 "/usr/include/stdio.h" 3 4
extern char *fgets (char *restrict __s, int __n, FILE *restrict __stream)
     ;
# 671 "/usr/include/stdio.h" 3 4
extern char *gets (char *__s) ;
# 711 "/usr/include/stdio.h" 3 4
extern int fputs (const char *restrict __s, FILE *restrict __stream)
  ;





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) ;






extern size_t fread (void *restrict __ptr, size_t __size,
       size_t __n, FILE *restrict __stream)
  ;




extern size_t fwrite (const void *restrict __ptr, size_t __size,
        size_t __n, FILE *restrict __s) ;
# 773 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  ;




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream) ;
# 823 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *restrict __stream, fpos_t *restrict __pos)
  ;




extern int fsetpos (FILE *__stream, const fpos_t *__pos) ;
# 854 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) ;

extern int feof (FILE *__stream) ;

extern int ferror (FILE *__stream) ;
# 872 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) ;
# 953 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 977 "/usr/include/stdio.h" 3 4

# 5 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/config.h" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4


# 63 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





 typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 102 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) ;



extern double atof (const char *__nptr)
     ;

extern int atoi (const char *__nptr)
     ;

extern long int atol (const char *__nptr)
     ;



 extern long long int atoll (const char *__nptr)
     ;



extern double strtod (const char *restrict __nptr,
        char **restrict __endptr)
     ;



extern float strtof (const char *restrict __nptr,
       char **restrict __endptr) ;

extern long double strtold (const char *restrict __nptr,
       char **restrict __endptr)
     ;
# 181 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *restrict __nptr,
   char **restrict __endptr, int __base)
     ;

extern unsigned long int strtoul (const char *restrict __nptr,
      char **restrict __endptr, int __base)
     ;
# 204 "/usr/include/stdlib.h" 3 4

extern long long int strtoll (const char *restrict __nptr,
         char **restrict __endptr, int __base)
     ;


extern unsigned long long int strtoull (const char *restrict __nptr,
     char **restrict __endptr, int __base)
     ;
# 577 "/usr/include/stdlib.h" 3 4
extern int rand (void) ;

extern void srand (unsigned int __seed) ;
# 676 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size)
     ;

extern void *calloc (size_t __nmemb, size_t __size)
     ;






extern void *realloc (void *__ptr, size_t __size)
     ;


extern void free (void *__ptr) ;
# 752 "/usr/include/stdlib.h" 3 4
extern void abort (void) ;



extern int atexit (void (*__func) (void)) ;
# 778 "/usr/include/stdlib.h" 3 4
extern void exit (int __status) ;
# 790 "/usr/include/stdlib.h" 3 4
extern void _Exit (int __status) ;




extern char *getenv (const char *__name) ;
# 945 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 970 "/usr/include/stdlib.h" 3 4
typedef int (*__compar_fn_t) (const void *, const void *);
# 982 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     ;
# 998 "/usr/include/stdlib.h" 3 4
extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) ;
# 1008 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) ;
extern long int labs (long int __x) ;


 extern long long int llabs (long long int __x)
     ;
# 1026 "/usr/include/stdlib.h" 3 4
extern div_t div (int __numer, int __denom)
     ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     ;


 extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     ;
# 1096 "/usr/include/stdlib.h" 3 4
extern int mblen (const char *__s, size_t __n) ;


extern int mbtowc (wchar_t *restrict __pwc,
     const char *restrict __s, size_t __n) ;


extern int wctomb (char *__s, wchar_t __wchar) ;



extern size_t mbstowcs (wchar_t *restrict __pwcs,
   const char *restrict __s, size_t __n)
    ;

extern size_t wcstombs (char *restrict __s,
   const wchar_t *restrict __pwcs, size_t __n)
    
 
  ;
# 1202 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1203 "/usr/include/stdlib.h" 2 3 4
# 1214 "/usr/include/stdlib.h" 3 4

# 6 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/config.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4


# 37 "/usr/include/string.h" 3 4
# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 38 "/usr/include/string.h" 2 3 4
# 47 "/usr/include/string.h" 3 4
extern void *memcpy (void *restrict __dest, const void *restrict __src,
       size_t __n) ;


extern void *memmove (void *__dest, const void *__src, size_t __n)
     ;
# 65 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) ;
# 75 "/usr/include/string.h" 3 4
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     ;
# 91 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     ;
# 118 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      ;
# 156 "/usr/include/string.h" 3 4
extern char *strcpy (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncpy (char *restrict __dest,
        const char *restrict __src, size_t __n)
     ;


extern char *strcat (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncat (char *restrict __dest, const char *restrict __src,
        size_t __n) ;


extern int strcmp (const char *__s1, const char *__s2)
     ;

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     ;


extern int strcoll (const char *__s1, const char *__s2)
     ;

extern size_t strxfrm (char *restrict __dest,
         const char *restrict __src, size_t __n)
    ;
# 261 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     ;
# 292 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     ;
# 316 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     ;


extern size_t strspn (const char *__s, const char *__accept)
     ;
# 346 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     ;
# 377 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     ;
# 388 "/usr/include/string.h" 3 4
extern char *strtok (char *restrict __s, const char *restrict __delim)
     ;



extern char *__strtok_r (char *restrict __s,
    const char *restrict __delim,
    char **restrict __save_ptr)
     ;
# 439 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     ;
# 451 "/usr/include/string.h" 3 4
extern char *strerror (int __errnum) ;
# 584 "/usr/include/string.h" 3 4

# 7 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/config.h" 2
# 15 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/config.h"

# 15 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/config.h"
typedef double flt;


void arena_init(void);
void arena_clear(void);
void * arena_alloc(int size);
# 4 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/arrays.h" 1


struct array {
  int size;
  int capacity;
  void * data;
};

struct array * alloc_array(int eltsize, int initialsize);

void grow_array(int eltsize, struct array * arr);

struct array * copy_array(int eltsize, struct array * arr, int extrasize);
# 5 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/gml.h" 1


enum operation {
    Identifier,
    Binder,
    Boolean,
    Integer,
    Real,
    String,
    Array,
    Function,
    Op_acos,
    Op_addi,
    Op_addf,
    Op_apply,
    Op_asin,
    Op_clampf,
    Op_cone,
    Op_cos,
    Op_cube,
    Op_cylinder,
    Op_difference,
    Op_divi,
    Op_divf,
    Op_eqi,
    Op_eqf,
    Op_floor,
    Op_frac,
    Op_get,
    Op_getx,
    Op_gety,
    Op_getz,
    Op_if,
    Op_intersect,
    Op_length,
    Op_lessi,
    Op_lessf,
    Op_light,
    Op_modi,
    Op_muli,
    Op_mulf,
    Op_negi,
    Op_negf,
    Op_plane,
    Op_point,
    Op_pointlight,
    Op_real,
    Op_render,
    Op_rotatex,
    Op_rotatey,
    Op_rotatez,
    Op_scale,
    Op_sin,
    Op_sphere,
    Op_spotlight,
    Op_sqrt,
    Op_subi,
    Op_subf,
    Op_translate,
    Op_union,
    Op_uscale,
    Op_print
};

struct tok {
  enum operation tag;
  union {
    char * s;
    int i;
    flt d;
    struct array * a;
  } u;
};
# 6 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/point.h" 1
struct point {
  flt x, y, z;
};

static inline flt dist2(struct point * p1, struct point * p2)
{
  flt dx = p2->x - p1->x;
  flt dy = p2->y - p1->y;
  flt dz = p2->z - p1->z;
  return dx * dx + dy * dy + dz * dz;
}
# 7 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/vector.h" 1
struct vector {
  flt dx, dy, dz;
};

flt dotproduct(struct vector * a, struct vector * b);
void between(struct point * p, struct point * q,
                     struct vector * v);
void opposite(struct vector * v,
                      struct vector * w);
void point_along(struct point * p, struct vector * v,
                 flt ac,
                         struct point * q);
void product(struct vector * a, struct vector * b,
                     struct vector * v);
flt vlength2(struct vector * a);
flt vlength(struct vector * a);

void vscale(struct vector * a, flt s,
                    struct vector * v);
void vnormalize(struct vector * a, struct vector * v);
void vsub(struct vector * a, struct vector * b,
                  struct vector * v);
# 8 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.h" 1


struct closure {
  struct array * code;
  struct array * env;
};

struct surface_characteristics {
  flt x, y, z;
  flt kd;
  flt ks;
  flt phong;
};

void execute_program(struct array * toklist);

void surface_function(struct closure clos, int face, flt u, flt v,
                              struct surface_characteristics * sc);
# 9 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/object.h" 1
struct object {
  enum { Cone, Cube, Cylinder, Plane, Sphere,
         Union, Intersection, Difference } kind;

  struct closure surf;
  struct matrix * world2obj, * obj2world;
  flt max_scale_applied;

  struct object * o1, * o2;

  struct point center;
  flt radius;
};

struct object * cone(struct closure c);
struct object * cube(struct closure c);
struct object * cylinder(struct closure c);
struct object * plane(struct closure c);
struct object * sphere(struct closure c);

struct object * orotatex(struct object * o1, flt a);
struct object * orotatey(struct object * o1, flt a);
struct object * orotatez(struct object * o1, flt a);
struct object * oscale(struct object * o1, flt sx, flt sy, flt sz);
struct object * otranslate(struct object * o1,
                           flt tx, flt ty, flt tz);
struct object * ouscale(struct object * o1, flt s);

struct object * odifference(struct object * o1, struct object * o2);
struct object * ointersect(struct object * o1, struct object * o2);
struct object * ounion(struct object * o1, struct object * o2);

void normal_vector(struct object * obj, struct point * p, int face,
                           struct vector * n);
# 10 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/light.h" 1
struct light {
  enum { Directional, Pointlight, Spot } kind;
  union {
    struct {
      struct point dir;
      struct point col;
    } directional;
    struct {
      struct point orig;
      struct point col;
    } point;
    struct {
      struct point orig;
      struct point at;
      struct point col;
      flt cutoff, exponent;
      struct vector unit;
    } spot;
  } u;
};

struct light * dirlight(struct point * dir, struct point * c);
struct light * pointlight(struct point * orig, struct point * c);
struct light * spotlight(struct point * pos, struct point * at,
                         struct point * c, flt a, flt cutoff);

void color_from_lights(struct object * obj,
                       struct point * p,
                       struct vector * v,
                       struct vector * n,
                       flt kd, flt ks, flt phong,
                       struct light ** lights,
                               struct point * il);
# 11 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/render.h" 1
void render(struct point * amb,
            int numlights,
            struct light ** lights,
            struct object * scene,
            int depth,
            flt fov,
            int wid,
            int ht,
            char * filename);
# 12 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 2

struct value {
  enum { B, I, R, S, Arr, Clos, Point, Obj, Light } tag;
  union {
    int i;
    flt r;
    char * s;
    struct array * arr;
    struct closure clos;
    struct point * point;
    struct object * obj;
    struct light * light;
  } u;
};

struct binding {
  char * name;
  int mutable;
  struct value val;
};



static int lookup(struct array * env, char * name, struct value * res)
{
  int i;
  for (i = env->size - 1; i >= 0; i--) {
    struct binding * b = &(((struct binding *) (env)->data)[i]);
    if (name == b->name) {
      *res = b->val;
      return 1;
    }
  }
  return 0;
}



static void assign(struct array * env, char * name, struct value * newval)
{
  int i;
  struct binding * b;
  for (i = env->size - 1; i >= 0; i--) {
    b = &(((struct binding *) (env)->data)[i]);
    if (! b->mutable) break;
    if (name == b->name) {
      b->val = *newval;
      return;
    }
  }
  if ((env)->size >= (env)->capacity) grow_array(sizeof(struct binding), (env)); (env)->size++;
  b = &(((struct binding *) (env)->data)[env->size - 1]);
  b->name = name;
  b->mutable = 1;
  b->val = *newval;
}



static struct array * snapshot_env(struct array * env)
{
  int i;
  struct array * nenv = copy_array(sizeof(struct binding), env, 10);
  for (i = 0; i < nenv->size; i++)
    (((struct binding *) (nenv)->data)[i]).mutable = 0;
  return nenv;
}



static inline flt degrees_to_radians(flt d)
{ return d * (3.14159265358979323846 / 180.0); }

static inline flt radians_to_degrees(flt d)
{ return d * (180.0 / 3.14159265358979323846); }

static inline flt deg_cos(flt a)
{ return cos(degrees_to_radians(a)); }

static inline flt deg_sin(flt a)
{ return sin(degrees_to_radians(a)); }

static inline flt deg_acos(flt a)
{ return radians_to_degrees(acos(a)); }

static inline flt deg_asin(flt a)
{ return radians_to_degrees(asin(a)); }

static inline flt clampf(flt r)
{
  if (r < 0.0) return 0.0;
  if (r > 1.0) return 1.0;
  return r;
}



static char * operator_names [] = {
  "<Identifier>", "<Binder>", "<Boolean>", "<Integer>", "<Real>",
  "<String>", "<Array>", "<Function>", "acos", "addi", "addf", "apply",
  "asin", "clampf", "cone", "cos", "cube", "cylinder", "difference",
  "divi", "divf", "eqi", "eqf", "floor", "frac", "get", "getx", "gety",
  "getz", "if", "intersect", "length", "lessi", "lessf", "light",
  "modi", "muli", "mulf", "negi", "negf", "plane", "point",
  "pointlight", "real", "render", "rotatex", "rotatey", "rotatez",
  "scale", "sin", "sphere", "spotlight", "sqrt", "subi", "subf",
  "translate", "union", "uscale", "print",
};



static struct light ** light_array(struct array * arr)
{
  int sz = arr->size;
  struct light ** l = arena_alloc((sz + 1) * sizeof(struct light *));
  int i;
  for (i = 0; i < sz; i++) {
    struct value * v = &(((struct value *) (arr)->data)[i]);
    if (v->tag != Light) {
      fprintf(
# 131 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 3 4
             stderr
# 131 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c"
                   , "Light expected in array argument to `render'\n");
      exit(2);
    }
    l[i] = v->u.light;
  }
  l[sz] = ((void *) 0);
  return l;
}



static void print_value(struct value * s)
{
  switch (s->tag) {
  case B:
    printf("%s\n", s->u.i ? "true" : "false"); break;
  case I:
    printf("%d\n", s->u.i); break;
  case R:
    printf("%e\n", s->u.r); break;
  case S:
    printf("\"%s\"\n", s->u.s); break;
  case Arr:
    printf("array\n"); break;
  case Clos:
    printf("closure\n"); break;
  case Point:
    printf("point %e %e %e\n",
           s->u.point->x, s->u.point->y, s->u.point->z);
    break;
  case Obj:
    printf("object\n"); break;
  case Light:
    printf("light\n"); break;
  }
}






static struct value main_stack[10000];
static struct value surface_stack[1000];
# 184 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c"
static struct value * execute_list(struct array * code,
                                   struct array * env,
                                   struct value * bos,
                                   struct value * tos,
                                   struct value * sp)
{
  int i;
  struct tok * t;

  for (i = 0; i < code->size; i++) {
    t = &(((struct tok *) (code)->data)[i]);
    switch (t->tag) {
    case Identifier:
      if (--sp < bos) goto stack_overflow;
      if (! lookup(env, t->u.s, sp)) {
        fprintf(
# 199 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 3 4
               stderr
# 199 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c"
                     , "Unbound identifier %s\n", t->u.s);
        exit(2);
      }
      break;
    case Binder:
      if (sp + (1) > tos) goto stack_underflow;
      assign(env, t->u.s, sp);
      sp++;
      break;
    case Boolean:
      if (--sp < bos) goto stack_overflow;
      sp[0].tag = B; sp[0].u.i = t->u.i;
      break;
    case Integer:
      if (--sp < bos) goto stack_overflow;
      sp[0].tag = I; sp[0].u.i = t->u.i;
      break;
    case Real:
      if (--sp < bos) goto stack_overflow;
      sp[0].tag = R; sp[0].u.r = t->u.d;
      break;
    case String:
      if (--sp < bos) goto stack_overflow;
      sp[0].tag = S; sp[0].u.s = t->u.s;
      break;
    case Array: {
      struct value * esp = execute_list(t->u.a, env, bos, sp, sp);
      int sz = sp - esp;
      struct array * a = alloc_array(sizeof(struct value), sz);
      int j;
      a->size = sz;
      for (j = 0; j < sz; j++) (((struct value *) (a)->data)[j] = (sp[-1-j]));
      if (--sp < bos) goto stack_overflow;
      sp[0].tag = Arr; sp[0].u.arr = a;
      break;
    }
    case Function:
      if (--sp < bos) goto stack_overflow;
      sp[0].tag = Clos;
      sp[0].u.clos.code = t->u.a;
      sp[0].u.clos.env = snapshot_env(env);
      break;
    case Op_acos:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != R) goto type_error;
      sp[0].u.r = deg_acos(sp[0].u.r);
      break;
    case Op_addi:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != I) goto type_error;
      if (sp[0].tag != I) goto type_error;
      sp[1].u.i = sp[1].u.i + sp[0].u.i;
      sp += 1;
      break;
    case Op_addf:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != R) goto type_error;
      if (sp[0].tag != R) goto type_error;
      sp[1].u.r = sp[1].u.r + sp[0].u.r;
      sp += 1;
      break;
    case Op_apply:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != Clos) goto type_error;
      sp = execute_list(sp[0].u.clos.code, sp[0].u.clos.env, bos, tos, sp + 1);
      break;
    case Op_asin:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != R) goto type_error;
      sp[0].u.r = deg_asin(sp[0].u.r);
      break;
    case Op_clampf:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != R) goto type_error;
      sp[0].u.r = clampf(sp[0].u.r);
      break;
    case Op_cone:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != Clos) goto type_error;
      sp[0].tag = Obj;
      sp[0].u.obj = cone(sp[0].u.clos);
      break;
    case Op_cos:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != R) goto type_error;
      sp[0].u.r = deg_cos(sp[0].u.r);
      break;
    case Op_cube:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != Clos) goto type_error;
      sp[0].tag = Obj;
      sp[0].u.obj = cube(sp[0].u.clos);
      break;
    case Op_cylinder:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != Clos) goto type_error;
      sp[0].tag = Obj;
      sp[0].u.obj = cylinder(sp[0].u.clos);
      break;
    case Op_difference:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != Obj) goto type_error;
      if (sp[0].tag != Obj) goto type_error;
      sp[1].u.obj = odifference(sp[1].u.obj, sp[0].u.obj);
      sp += 1;
      break;
    case Op_divi:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != I) goto type_error;
      if (sp[0].tag != I) goto type_error;
      if (sp[0].u.i == 0) goto division_by_zero;
      sp[1].u.i = sp[1].u.i / sp[0].u.i;
      sp += 1;
      break;
    case Op_divf:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != R) goto type_error;
      if (sp[0].tag != R) goto type_error;
      sp[1].u.r = sp[1].u.r / sp[0].u.r;
      sp += 1;
      break;
    case Op_eqi:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != I) goto type_error;
      if (sp[0].tag != I) goto type_error;
      sp[1].tag = B;
      sp[1].u.i = (sp[1].u.i == sp[0].u.i);
      sp += 1;
      break;
    case Op_eqf:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != R) goto type_error;
      if (sp[0].tag != R) goto type_error;
      sp[1].tag = B;
      sp[1].u.i = (sp[1].u.r == sp[0].u.r);
      sp += 1;
      break;
    case Op_floor:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != R) goto type_error;
      sp[0].tag = I;
      sp[0].u.i = (int) floor(sp[0].u.r);
      break;
    case Op_frac: {
      double rem;
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != R) goto type_error;
      sp[0].u.r = modf(sp[0].u.r, &rem);
      break;
    }
    case Op_get: {
      struct array * a;
      int idx;
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != Arr) goto type_error;
      if (sp[0].tag != I) goto type_error;
      a = sp[1].u.arr;
      idx = sp[0].u.i;
      if (idx < 0 || idx >= a->size) goto bound_error;
      sp[1] = (((struct value *) (a)->data)[idx]);
      sp++;
      break;
    }
    case Op_getx:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != Point) goto type_error;
      sp[0].tag = R;
      sp[0].u.r = sp[0].u.point->x;
      break;
    case Op_gety:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != Point) goto type_error;
      sp[0].tag = R;
      sp[0].u.r = sp[0].u.point->y;
      break;
    case Op_getz:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != Point) goto type_error;
      sp[0].tag = R;
      sp[0].u.r = sp[0].u.point->z;
      break;
    case Op_if:
      if (sp + (3) > tos) goto stack_underflow;
      if (sp[2].tag != B) goto type_error;
      if (sp[1].tag != Clos) goto type_error;
      if (sp[0].tag != Clos) goto type_error;
      if (sp[2].u.i)
        sp = execute_list(sp[1].u.clos.code, sp[1].u.clos.env, bos, tos, sp + 3);
      else
        sp = execute_list(sp[0].u.clos.code, sp[0].u.clos.env, bos, tos, sp + 3);
      break;
    case Op_intersect:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != Obj) goto type_error;
      if (sp[0].tag != Obj) goto type_error;
      sp[1].u.obj = ointersect(sp[1].u.obj, sp[0].u.obj);
      sp += 1;
      break;
    case Op_length:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != Arr) goto type_error;
      sp[0].tag = I;
      sp[0].u.i = sp[0].u.arr->size;
      break;
    case Op_lessi:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != I) goto type_error;
      if (sp[0].tag != I) goto type_error;
      sp[1].tag = B;
      sp[1].u.i = (sp[1].u.i < sp[0].u.i);
      sp += 1;
      break;
    case Op_lessf:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != R) goto type_error;
      if (sp[0].tag != R) goto type_error;
      sp[1].tag = B;
      sp[1].u.i = (sp[1].u.r < sp[0].u.r);
      sp += 1;
      break;
    case Op_light:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != Point) goto type_error;
      if (sp[0].tag != Point) goto type_error;
      sp[1].tag = Light;
      sp[1].u.light = dirlight(sp[1].u.point, sp[0].u.point);
      sp += 1;
      break;
    case Op_modi:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != I) goto type_error;
      if (sp[0].tag != I) goto type_error;
      if (sp[0].u.i == 0) goto division_by_zero;
      sp[1].u.i = sp[1].u.i % sp[0].u.i;
      sp += 1;
      break;
    case Op_muli:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != I) goto type_error;
      if (sp[0].tag != I) goto type_error;
      sp[1].u.i = sp[1].u.i * sp[0].u.i;
      sp += 1;
      break;
    case Op_mulf:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != R) goto type_error;
      if (sp[0].tag != R) goto type_error;
      sp[1].u.r = sp[1].u.r * sp[0].u.r;
      sp += 1;
      break;
    case Op_negi:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != I) goto type_error;
      sp[0].u.i = - sp[0].u.i;
      break;
    case Op_negf:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != R) goto type_error;
      sp[0].u.r = - sp[0].u.r;
      break;
    case Op_plane:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != Clos) goto type_error;
      sp[0].tag = Obj;
      sp[0].u.obj = plane(sp[0].u.clos);
      break;
    case Op_point: {
      struct point * p;
      if (sp + (3) > tos) goto stack_underflow;
      if (sp[2].tag != R) goto type_error;
      if (sp[1].tag != R) goto type_error;
      if (sp[0].tag != R) goto type_error;
      p = arena_alloc(sizeof(struct point));
      p->x = sp[2].u.r;
      p->y = sp[1].u.r;
      p->z = sp[0].u.r;
      sp += 2;
      sp[0].tag = Point;
      sp[0].u.point = p;
      break;
    }
    case Op_pointlight:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != Point) goto type_error;
      if (sp[0].tag != Point) goto type_error;
      sp[1].tag = Light;
      sp[1].u.light = pointlight(sp[1].u.point, sp[0].u.point);
      sp += 1;
      break;
    case Op_real:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != I) goto type_error;
      sp[0].tag = R;
      sp[0].u.r = (flt) sp[0].u.i;
      break;
    case Op_render:
      if (sp + (8) > tos) goto stack_underflow;
      if (sp[0].tag != S) goto type_error;
      if (sp[1].tag != I) goto type_error;
      if (sp[2].tag != I) goto type_error;
      if (sp[3].tag != R) goto type_error;
      if (sp[4].tag != I) goto type_error;
      if (sp[5].tag != Obj) goto type_error;
      if (sp[6].tag != Arr) goto type_error;
      if (sp[7].tag != Point) goto type_error;
      render(sp[7].u.point,
             sp[6].u.arr->size,
             light_array(sp[6].u.arr),
             sp[5].u.obj,
             sp[4].u.i,
             degrees_to_radians(sp[3].u.r),
             sp[2].u.i,
             sp[1].u.i,
             sp[0].u.s);
      sp += 8;
      break;
    case Op_rotatex:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != Obj) goto type_error;
      if (sp[0].tag != R) goto type_error;
      sp[1].u.obj = orotatex(sp[1].u.obj, degrees_to_radians(sp[0].u.r));
      sp += 1;
      break;
    case Op_rotatey:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != Obj) goto type_error;
      if (sp[0].tag != R) goto type_error;
      sp[1].u.obj = orotatey(sp[1].u.obj, degrees_to_radians(sp[0].u.r));
      sp += 1;
      break;
    case Op_rotatez:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != Obj) goto type_error;
      if (sp[0].tag != R) goto type_error;
      sp[1].u.obj = orotatez(sp[1].u.obj, degrees_to_radians(sp[0].u.r));
      sp += 1;
      break;
    case Op_scale:
      if (sp + (4) > tos) goto stack_underflow;
      if (sp[3].tag != Obj) goto type_error;
      if (sp[2].tag != R) goto type_error;
      if (sp[1].tag != R) goto type_error;
      if (sp[0].tag != R) goto type_error;
      sp[3].u.obj = oscale(sp[3].u.obj, sp[2].u.r, sp[1].u.r, sp[0].u.r);
      sp += 3;
      break;
    case Op_sin:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != R) goto type_error;
      sp[0].u.r = deg_sin(sp[0].u.r);
      break;
    case Op_sphere:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != Clos) goto type_error;
      sp[0].tag = Obj;
      sp[0].u.obj = sphere(sp[0].u.clos);
      break;
    case Op_spotlight:
      if (sp + (5) > tos) goto stack_underflow;
      if (sp[4].tag != Point) goto type_error;
      if (sp[3].tag != Point) goto type_error;
      if (sp[2].tag != Point) goto type_error;
      if (sp[1].tag != R) goto type_error;
      if (sp[0].tag != R) goto type_error;
      sp[4].tag = Light;
      sp[4].u.light = spotlight(sp[4].u.point, sp[3].u.point, sp[2].u.point,
                                degrees_to_radians(sp[1].u.r), sp[0].u.r);
      sp += 4;
      break;
    case Op_sqrt:
      if (sp + (1) > tos) goto stack_underflow;
      if (sp[0].tag != R) goto type_error;
      if (sp[0].u.r < 0) goto negative_sqrt;
      sp[0].u.r = sqrt(sp[0].u.r);
      break;
    case Op_subi:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != I) goto type_error;
      if (sp[0].tag != I) goto type_error;
      sp[1].u.i = sp[1].u.i - sp[0].u.i;
      sp += 1;
      break;
    case Op_subf:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != R) goto type_error;
      if (sp[0].tag != R) goto type_error;
      sp[1].u.r = sp[1].u.r - sp[0].u.r;
      sp += 1;
      break;
    case Op_translate:
      if (sp + (4) > tos) goto stack_underflow;
      if (sp[3].tag != Obj) goto type_error;
      if (sp[2].tag != R) goto type_error;
      if (sp[1].tag != R) goto type_error;
      if (sp[0].tag != R) goto type_error;
      sp[3].u.obj = otranslate(sp[3].u.obj, sp[2].u.r, sp[1].u.r, sp[0].u.r);
      sp += 3;
      break;
    case Op_union:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != Obj) goto type_error;
      if (sp[0].tag != Obj) goto type_error;
      sp[1].u.obj = ounion(sp[1].u.obj, sp[0].u.obj);
      sp += 1;
      break;
    case Op_uscale:
      if (sp + (2) > tos) goto stack_underflow;
      if (sp[1].tag != Obj) goto type_error;
      if (sp[0].tag != R) goto type_error;
      sp[1].u.obj = ouscale(sp[1].u.obj, sp[0].u.r);
      sp += 1;
      break;
    case Op_print:
      if (sp + (1) > tos) goto stack_underflow;
      print_value(sp);
      sp += 1;
      break;
    }
  }
  return sp;

 stack_overflow:
  fprintf(
# 621 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 3 4
         stderr
# 621 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c"
               , "Stack overflow\n");
  goto print_context;
 stack_underflow:
  fprintf(
# 624 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 3 4
         stderr
# 624 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c"
               , "Stack underflow\n");
  goto print_context;
 type_error:
  fprintf(
# 627 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 3 4
         stderr
# 627 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c"
               , "Type error\n");
  goto print_context;
 division_by_zero:
  fprintf(
# 630 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 3 4
         stderr
# 630 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c"
               , "Division by zero\n");
  goto print_context;
 bound_error:
  fprintf(
# 633 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 3 4
         stderr
# 633 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c"
               , "Out-of-bound array access\n");
  goto print_context;
 negative_sqrt:
  fprintf(
# 636 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 3 4
         stderr
# 636 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c"
               , "Square root of negative number\n");
 print_context:
  fprintf(
# 638 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 3 4
         stderr
# 638 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c"
               , "(operation: %s, PC: %d)\n", operator_names[t->tag], i);
  exit(2);
}



void surface_function(struct closure clos, int face, flt u, flt v,
                              struct surface_characteristics * sc)
{
  struct value * sp;
  sp = surface_stack + 1000 - 3;
  sp[2].tag = I;
  sp[2].u.i = face;
  sp[1].tag = R;
  sp[1].u.i = u;
  sp[0].tag = R;
  sp[0].u.i = v;
  sp =
    execute_list(clos.code, clos.env, surface_stack,
                 surface_stack + 1000, sp);
  if (sp != surface_stack + 1000 - 4 ||
      sp[0].tag != R ||
      sp[1].tag != R ||
      sp[2].tag != R ||
      sp[3].tag != Point) {
    fprintf(
# 663 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c" 3 4
           stderr
# 663 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/raytracer/render/lean/raytracer/eval.c"
                 , "Wrong result for surface function\n");
    exit(2);
  }
  sc->x = sp[3].u.point->x;
  sc->y = sp[3].u.point->y;
  sc->z = sp[3].u.point->z;
  sc->kd = sp[2].u.r;
  sc->ks = sp[1].u.r;
  sc->phong = sp[0].u.r;
}



void execute_program(struct array * toklist)
{
  execute_list(toklist, alloc_array(sizeof(struct binding), 50),
               main_stack,
               main_stack + 10000,
               main_stack + 10000);
}
