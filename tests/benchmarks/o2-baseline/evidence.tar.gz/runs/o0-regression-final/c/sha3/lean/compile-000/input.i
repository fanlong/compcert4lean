# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/c/sha3/lean/c/sha3.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/c/sha3/lean/c/sha3.c"




# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 29 "/usr/include/stdio.h" 2 3 4









# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4

# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef unsigned long size_t;
# 39 "/usr/include/stdio.h" 2 3 4


# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 1 3 4
# 43 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 42 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 45 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 46 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 47 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 48 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 2 3 4

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2:24;

  char _short_backupbuf[1];
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;

  int _unused3;

  __uint64_t _total_written;




  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
# 49 "/usr/include/stdio.h" 2 3 4
# 89 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;
# 133 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 134 "/usr/include/stdio.h" 2 3 4
# 153 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) ;

extern int rename (const char *__old, const char *__new) ;
# 191 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) ;
# 201 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  ;
# 218 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) ;
# 243 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 271 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *restrict __filename,
      const char *restrict __modes)
  ;




extern FILE *freopen (const char *restrict __filename,
        const char *restrict __modes,
        FILE *restrict __stream) ;
# 341 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *restrict __stream, char *restrict __buf)
  ;



extern int setvbuf (FILE *restrict __stream, char *restrict __buf,
      int __modes, size_t __n) ;
# 364 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *restrict __stream,
      const char *restrict __format, ...) ;




extern int printf (const char *restrict __format, ...);

extern int sprintf (char *restrict __s,
      const char *restrict __format, ...) ;





extern int vfprintf (FILE *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;




extern int vprintf (const char *restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;



extern int snprintf (char *restrict __s, size_t __maxlen,
       const char *restrict __format, ...)
     ;

extern int vsnprintf (char *restrict __s, size_t __maxlen,
        const char *restrict __format, __gnuc_va_list __arg)
     ;
# 429 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *restrict __stream,
     const char *restrict __format, ...) ;




extern int scanf (const char *restrict __format, ...) ;

extern int sscanf (const char *restrict __s,
     const char *restrict __format, ...) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 445 "/usr/include/stdio.h" 2 3 4
# 479 "/usr/include/stdio.h" 3 4
extern int __isoc99_fscanf (FILE *restrict __stream,
       const char *restrict __format, ...)
  ;
extern int __isoc99_scanf (const char *restrict __format, ...) ;
extern int __isoc99_sscanf (const char *restrict __s,
       const char *restrict __format, ...) ;
# 497 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *restrict __s, const char *restrict __format,
      __gnuc_va_list __arg)
     ;





extern int vscanf (const char *restrict __format, __gnuc_va_list __arg)
     ;


extern int vsscanf (const char *restrict __s,
      const char *restrict __format, __gnuc_va_list __arg)
     ;
# 561 "/usr/include/stdio.h" 3 4
extern int __isoc99_vfscanf (FILE *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
extern int __isoc99_vscanf (const char *restrict __format,
       __gnuc_va_list __arg) ;
extern int __isoc99_vsscanf (const char *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
# 582 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) ;
extern int getc (FILE *__stream) ;





extern int getchar (void);
# 615 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) ;
extern int putc (int __c, FILE *__stream) ;





extern int putchar (int __c);
# 658 "/usr/include/stdio.h" 3 4
extern char *fgets (char *restrict __s, int __n, FILE *restrict __stream)
     ;
# 671 "/usr/include/stdio.h" 3 4
extern char *gets (char *__s) ;
# 711 "/usr/include/stdio.h" 3 4
extern int fputs (const char *restrict __s, FILE *restrict __stream)
  ;





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) ;






extern size_t fread (void *restrict __ptr, size_t __size,
       size_t __n, FILE *restrict __stream)
  ;




extern size_t fwrite (const void *restrict __ptr, size_t __size,
        size_t __n, FILE *restrict __s) ;
# 773 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  ;




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream) ;
# 823 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *restrict __stream, fpos_t *restrict __pos)
  ;




extern int fsetpos (FILE *__stream, const fpos_t *__pos) ;
# 854 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) ;

extern int feof (FILE *__stream) ;

extern int ferror (FILE *__stream) ;
# 872 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) ;
# 953 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 977 "/usr/include/stdio.h" 3 4

# 6 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/c/sha3/lean/c/sha3.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4


# 37 "/usr/include/string.h" 3 4
# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 38 "/usr/include/string.h" 2 3 4
# 47 "/usr/include/string.h" 3 4
extern void *memcpy (void *restrict __dest, const void *restrict __src,
       size_t __n) ;


extern void *memmove (void *__dest, const void *__src, size_t __n)
     ;
# 65 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) ;
# 75 "/usr/include/string.h" 3 4
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     ;
# 91 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     ;
# 118 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      ;
# 156 "/usr/include/string.h" 3 4
extern char *strcpy (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncpy (char *restrict __dest,
        const char *restrict __src, size_t __n)
     ;


extern char *strcat (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncat (char *restrict __dest, const char *restrict __src,
        size_t __n) ;


extern int strcmp (const char *__s1, const char *__s2)
     ;

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     ;


extern int strcoll (const char *__s1, const char *__s2)
     ;

extern size_t strxfrm (char *restrict __dest,
         const char *restrict __src, size_t __n)
    ;
# 261 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     ;
# 292 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     ;
# 316 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     ;


extern size_t strspn (const char *__s, const char *__accept)
     ;
# 346 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     ;
# 377 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     ;
# 388 "/usr/include/string.h" 3 4
extern char *strtok (char *restrict __s, const char *restrict __delim)
     ;



extern char *__strtok_r (char *restrict __s,
    const char *restrict __delim,
    char **restrict __save_ptr)
     ;
# 439 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     ;
# 451 "/usr/include/string.h" 3 4
extern char *strerror (int __errnum) ;
# 584 "/usr/include/string.h" 3 4

# 7 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/c/sha3/lean/c/sha3.c" 2


# 8 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/c/sha3/lean/c/sha3.c"
typedef unsigned long long uint64;
typedef unsigned char uint8;





const uint64 keccakf_rndc[24] =
{
    0x0000000000000001, 0x0000000000008082, 0x800000000000808a,
    0x8000000080008000, 0x000000000000808b, 0x0000000080000001,
    0x8000000080008081, 0x8000000000008009, 0x000000000000008a,
    0x0000000000000088, 0x0000000080008009, 0x000000008000000a,
    0x000000008000808b, 0x800000000000008b, 0x8000000000008089,
    0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
    0x000000000000800a, 0x800000008000000a, 0x8000000080008081,
    0x8000000000008080, 0x0000000080000001, 0x8000000080008008
};

const int keccakf_rotc[24] =
{
    1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 2, 14,
    27, 41, 56, 8, 25, 43, 62, 18, 39, 61, 20, 44
};

const int keccakf_piln[24] =
{
    10, 7, 11, 17, 18, 3, 5, 16, 8, 21, 24, 4,
    15, 23, 19, 13, 12, 2, 20, 14, 22, 9, 6, 1
};



void keccakf(uint64 st[25])
{
    int j, round;
    uint64 t, bc[5];

    for (round = 0; round < 24; round++) {





      bc[0] = st[0] ^ st[0 + 5] ^ st[0 + 10] ^ st[0 + 15] ^ st[0 + 20]; bc[1] = st[1] ^ st[1 + 5] ^ st[1 + 10] ^ st[1 + 15] ^ st[1 + 20]; bc[2] = st[2] ^ st[2 + 5] ^ st[2 + 10] ^ st[2 + 15] ^ st[2 + 20]; bc[3] = st[3] ^ st[3 + 5] ^ st[3 + 10] ^ st[3 + 15] ^ st[3 + 20]; bc[4] = st[4] ^ st[4 + 5] ^ st[4 + 10] ^ st[4 + 15] ^ st[4 + 20];
# 62 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/c/sha3/lean/c/sha3.c"
      t = bc[(0 + 4) % 5] ^ (((bc[(0 + 1) % 5]) << (1)) | ((bc[(0 + 1) % 5]) >> (64 - (1)))); st[0 + 0] ^= t; st[5 + 0] ^= t; st[10 + 0] ^= t; st[15 + 0] ^= t; st[20 + 0] ^= t; t = bc[(1 + 4) % 5] ^ (((bc[(1 + 1) % 5]) << (1)) | ((bc[(1 + 1) % 5]) >> (64 - (1)))); st[0 + 1] ^= t; st[5 + 1] ^= t; st[10 + 1] ^= t; st[15 + 1] ^= t; st[20 + 1] ^= t; t = bc[(2 + 4) % 5] ^ (((bc[(2 + 1) % 5]) << (1)) | ((bc[(2 + 1) % 5]) >> (64 - (1)))); st[0 + 2] ^= t; st[5 + 2] ^= t; st[10 + 2] ^= t; st[15 + 2] ^= t; st[20 + 2] ^= t; t = bc[(3 + 4) % 5] ^ (((bc[(3 + 1) % 5]) << (1)) | ((bc[(3 + 1) % 5]) >> (64 - (1)))); st[0 + 3] ^= t; st[5 + 3] ^= t; st[10 + 3] ^= t; st[15 + 3] ^= t; st[20 + 3] ^= t; t = bc[(4 + 4) % 5] ^ (((bc[(4 + 1) % 5]) << (1)) | ((bc[(4 + 1) % 5]) >> (64 - (1)))); st[0 + 4] ^= t; st[5 + 4] ^= t; st[10 + 4] ^= t; st[15 + 4] ^= t; st[20 + 4] ^= t;
# 73 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/c/sha3/lean/c/sha3.c"
        t = st[1];
        j = keccakf_piln[0]; bc[0] = st[j]; st[j] = (((t) << (1)) | ((t) >> (64 - (1)))); t = bc[0]; j = keccakf_piln[1]; bc[0] = st[j]; st[j] = (((t) << (3)) | ((t) >> (64 - (3)))); t = bc[0]; j = keccakf_piln[2]; bc[0] = st[j]; st[j] = (((t) << (6)) | ((t) >> (64 - (6)))); t = bc[0]; j = keccakf_piln[3]; bc[0] = st[j]; st[j] = (((t) << (10)) | ((t) >> (64 - (10)))); t = bc[0];
        j = keccakf_piln[4]; bc[0] = st[j]; st[j] = (((t) << (15)) | ((t) >> (64 - (15)))); t = bc[0]; j = keccakf_piln[5]; bc[0] = st[j]; st[j] = (((t) << (21)) | ((t) >> (64 - (21)))); t = bc[0]; j = keccakf_piln[6]; bc[0] = st[j]; st[j] = (((t) << (28)) | ((t) >> (64 - (28)))); t = bc[0]; j = keccakf_piln[7]; bc[0] = st[j]; st[j] = (((t) << (36)) | ((t) >> (64 - (36)))); t = bc[0];
        j = keccakf_piln[8]; bc[0] = st[j]; st[j] = (((t) << (45)) | ((t) >> (64 - (45)))); t = bc[0]; j = keccakf_piln[9]; bc[0] = st[j]; st[j] = (((t) << (55)) | ((t) >> (64 - (55)))); t = bc[0]; j = keccakf_piln[10]; bc[0] = st[j]; st[j] = (((t) << (2)) | ((t) >> (64 - (2)))); t = bc[0]; j = keccakf_piln[11]; bc[0] = st[j]; st[j] = (((t) << (14)) | ((t) >> (64 - (14)))); t = bc[0];
        j = keccakf_piln[12]; bc[0] = st[j]; st[j] = (((t) << (27)) | ((t) >> (64 - (27)))); t = bc[0]; j = keccakf_piln[13]; bc[0] = st[j]; st[j] = (((t) << (41)) | ((t) >> (64 - (41)))); t = bc[0]; j = keccakf_piln[14]; bc[0] = st[j]; st[j] = (((t) << (56)) | ((t) >> (64 - (56)))); t = bc[0]; j = keccakf_piln[15]; bc[0] = st[j]; st[j] = (((t) << (8)) | ((t) >> (64 - (8)))); t = bc[0];
        j = keccakf_piln[16]; bc[0] = st[j]; st[j] = (((t) << (25)) | ((t) >> (64 - (25)))); t = bc[0]; j = keccakf_piln[17]; bc[0] = st[j]; st[j] = (((t) << (43)) | ((t) >> (64 - (43)))); t = bc[0]; j = keccakf_piln[18]; bc[0] = st[j]; st[j] = (((t) << (62)) | ((t) >> (64 - (62)))); t = bc[0]; j = keccakf_piln[19]; bc[0] = st[j]; st[j] = (((t) << (18)) | ((t) >> (64 - (18)))); t = bc[0];
        j = keccakf_piln[20]; bc[0] = st[j]; st[j] = (((t) << (39)) | ((t) >> (64 - (39)))); t = bc[0]; j = keccakf_piln[21]; bc[0] = st[j]; st[j] = (((t) << (61)) | ((t) >> (64 - (61)))); t = bc[0]; j = keccakf_piln[22]; bc[0] = st[j]; st[j] = (((t) << (20)) | ((t) >> (64 - (20)))); t = bc[0]; j = keccakf_piln[23]; bc[0] = st[j]; st[j] = (((t) << (44)) | ((t) >> (64 - (44)))); t = bc[0];
# 88 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/c/sha3/lean/c/sha3.c"
        for (j = 0; j < 25; j += 5) {
          bc[0] = st[j + 0]; bc[1] = st[j + 1]; bc[2] = st[j + 2]; bc[3] = st[j + 3]; bc[4] = st[j + 4];
          st[j + 0] ^= (~bc[(0 + 1) % 5]) & bc[(0 + 2) % 5]; st[j + 1] ^= (~bc[(1 + 1) % 5]) & bc[(1 + 2) % 5]; st[j + 2] ^= (~bc[(2 + 1) % 5]) & bc[(2 + 2) % 5]; st[j + 3] ^= (~bc[(3 + 1) % 5]) & bc[(3 + 2) % 5]; st[j + 4] ^= (~bc[(4 + 1) % 5]) & bc[(4 + 2) % 5];
        }


        st[0] ^= keccakf_rndc[round];
    }
}



static inline uint64 get64le(const uint8 *p)
{
  unsigned int l = p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24);
  unsigned int h = p[4] | (p[5] << 8) | (p[6] << 16) | (p[7] << 24);
  return l | ((uint64) h << 32);
}



static inline void set64le(uint8 * p, uint64 x)
{
  p[0] = x; p[1] = x >> 8; p[2] = x >> 16; p[3] = x >> 24;
  p[4] = x >> 32; p[5] = x >> 40; p[6] = x >> 48; p[7] = x >> 56;
}



void keccak(const uint8 *in, int inlen, uint8 *md, int mdlen)
{
    uint64 st[25];
    uint8 temp[144];
    int i, rsiz, rsizw;

    rsiz = 200 - 2 * mdlen;
    rsizw = rsiz / 8;

    memset(st, 0, sizeof(st));

    for ( ; inlen >= rsiz; inlen -= rsiz, in += rsiz) {
        for (i = 0; i < rsizw; i++)
          st[i] ^= get64le(in + i * 8);
        keccakf(st);
    }


    memcpy(temp, in, inlen);
    temp[inlen++] = 1;
    memset(temp + inlen, 0, rsiz - inlen);
    temp[rsiz - 1] |= 0x80;

    for (i = 0; i < rsizw; i++)
      st[i] ^= get64le(temp + i * 8);

    keccakf(st);

    for(i = 0; i < 8; i++)
      set64le(temp + i * 8, st[i]);

    memcpy (md, temp, mdlen);
}



typedef struct {
    int mdlen;
    char *msgstr;
    uint8 md[64];
} test_triplet_t;

test_triplet_t testvec[4] = {
  {
    28, "Keccak-224 Test Hash", {
      0x30, 0x04, 0x5B, 0x34, 0x94, 0x6E, 0x1B, 0x2E,
      0x09, 0x16, 0x13, 0x36, 0x2F, 0xD2, 0x2A, 0xA0,
      0x8E, 0x2B, 0xEA, 0xFE, 0xC5, 0xE8, 0xDA, 0xEE,
      0x42, 0xC2, 0xE6, 0x65 }
  }, {
    32, "Keccak-256 Test Hash", {
      0xA8, 0xD7, 0x1B, 0x07, 0xF4, 0xAF, 0x26, 0xA4,
      0xFF, 0x21, 0x02, 0x7F, 0x62, 0xFF, 0x60, 0x26,
      0x7F, 0xF9, 0x55, 0xC9, 0x63, 0xF0, 0x42, 0xC4,
      0x6D, 0xA5, 0x2E, 0xE3, 0xCF, 0xAF, 0x3D, 0x3C }
  }, {
    48, "Keccak-384 Test Hash", {
      0xE2, 0x13, 0xFD, 0x74, 0xAF, 0x0C, 0x5F, 0xF9,
      0x1B, 0x42, 0x3C, 0x8B, 0xCE, 0xEC, 0xD7, 0x01,
      0xF8, 0xDD, 0x64, 0xEC, 0x18, 0xFD, 0x6F, 0x92,
      0x60, 0xFC, 0x9E, 0xC1, 0xED, 0xBD, 0x22, 0x30,
      0xA6, 0x90, 0x86, 0x65, 0xBC, 0xD9, 0xFB, 0xF4,
      0x1A, 0x99, 0xA1, 0x8A, 0x7D, 0x9E, 0x44, 0x6E }
  }, {
    64, "Keccak-512 Test Hash", {
      0x96, 0xEE, 0x47, 0x18, 0xDC, 0xBA, 0x3C, 0x74,
      0x61, 0x9B, 0xA1, 0xFA, 0x7F, 0x57, 0xDF, 0xE7,
      0x76, 0x9D, 0x3F, 0x66, 0x98, 0xA8, 0xB3, 0x3F,
      0xA1, 0x01, 0x83, 0x89, 0x70, 0xA1, 0x31, 0xE6,
      0x21, 0xCC, 0xFD, 0x05, 0xFE, 0xFF, 0xBC, 0x11,
      0x80, 0xF2, 0x63, 0xC2, 0x7F, 0x1A, 0xDA, 0xB4,
      0x60, 0x95, 0xD6, 0xF1, 0x25, 0x33, 0x14, 0x72,
      0x4B, 0x5C, 0xBF, 0x78, 0x28, 0x65, 0x8E, 0x6A }
  }
};




int main()
{
  static uint8 data[100000];
  int i;
  uint8 md[64];



  for (i = 0; i < 4; i++) {

    keccak((uint8 *) testvec[i].msgstr,
           strlen(testvec[i].msgstr),
           md, testvec[i].mdlen);

    printf("SHA-3 %d %s\n",
           testvec[i].mdlen * 8,
           memcmp(md, testvec[i].md, testvec[i].mdlen) == 0 ? "passed" : "FAILED");

  }


  for (i = 0; i < 100000; i++) data[i] = i;
  for (i = 0; i < 25; i++)
    keccak(data, 100000, md, 64);

  return 0;
}
