# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/extasm/lean/regression/extasm.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/extasm/lean/regression/extasm.c"



int clobbers(int x, int z)
{
  int y;
  asm("TEST0 out:%0 in:%1" : "=r"(y) : "r"(x) : "cc"

      , "rax", "rdx", "rbx"
# 19 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/extasm/lean/regression/extasm.c"
);
  return y + z;
}
# 33 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/extasm/lean/regression/extasm.c"
int main()
{
  int x;
  void * y;
  long long z;
  double f;
  float sf;
  char c[16];


  asm("TEST1 %%");

  asm("TEST2 in:%0" : : "r" (x));
  asm("TEST3 in:%0,%1" : : "r" (x), "r" (f));

  asm("TEST4 out:%0" : "=r" (x));

  asm("TEST5 out:%0 in:%1" : "=r" (f) : "r" (y));

  asm("TEST6 in:%0" : : "m" (c[2]));
  asm("TEST7 out:%0 in:%1,%2" : "=r"(x) : "m" (c[0]), "r" (y));

  asm("TEST8 out:%0 in:%1" : "=m" (c[4]) : "r" (f));

  asm("TEST9 in:%0,%1,%2" : : "r"(x), "i"(sizeof(x) + 2), "r"(y));
# 73 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/extasm/lean/regression/extasm.c"
  asm("TEST12 a:%[a] b:%[b] c:%[c]" : : [a]"i"(12), [b]"i"(34), [c]"i"(56));
  asm("TEST13 a:%[a] x:%[x]" : [x]"=r"(x) : [a]"i"(78));
  asm("TEST14 a:%[a] in2:%1 c:%[c]" : : [a]"i"(12), "i"(34), [c]"i"(56));




  asm("TEST15 int32 %0" : : "r" (x));

  asm("TEST15 int64 %0" : : "r" (z));



  asm("TEST15 float64 %0" : : "r" (f));
  asm("TEST15 float32 %0" : : "r" (sf));






  return 0;
}
