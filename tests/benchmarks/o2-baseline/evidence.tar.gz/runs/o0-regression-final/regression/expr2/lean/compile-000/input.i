# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/expr2/lean/regression/expr2.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/expr2/lean/regression/expr2.c"
extern int f(int);

void g(int x)
{
  if (x > 0) {
    (void) f(x - 1);
  }
}
