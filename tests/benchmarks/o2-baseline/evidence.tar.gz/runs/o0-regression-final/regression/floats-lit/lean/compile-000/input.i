# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/floats-lit/lean/regression/floats-lit.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/floats-lit/lean/regression/floats-lit.c"
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 29 "/usr/include/stdio.h" 2 3 4









# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4

# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef unsigned long size_t;
# 39 "/usr/include/stdio.h" 2 3 4


# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 1 3 4
# 43 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 42 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 45 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 46 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 47 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 48 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 2 3 4

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2:24;

  char _short_backupbuf[1];
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;

  int _unused3;

  __uint64_t _total_written;




  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
# 49 "/usr/include/stdio.h" 2 3 4
# 89 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;
# 133 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 134 "/usr/include/stdio.h" 2 3 4
# 153 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) ;

extern int rename (const char *__old, const char *__new) ;
# 191 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) ;
# 201 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  ;
# 218 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) ;
# 243 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 271 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *restrict __filename,
      const char *restrict __modes)
  ;




extern FILE *freopen (const char *restrict __filename,
        const char *restrict __modes,
        FILE *restrict __stream) ;
# 341 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *restrict __stream, char *restrict __buf)
  ;



extern int setvbuf (FILE *restrict __stream, char *restrict __buf,
      int __modes, size_t __n) ;
# 364 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *restrict __stream,
      const char *restrict __format, ...) ;




extern int printf (const char *restrict __format, ...);

extern int sprintf (char *restrict __s,
      const char *restrict __format, ...) ;





extern int vfprintf (FILE *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;




extern int vprintf (const char *restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;



extern int snprintf (char *restrict __s, size_t __maxlen,
       const char *restrict __format, ...)
     ;

extern int vsnprintf (char *restrict __s, size_t __maxlen,
        const char *restrict __format, __gnuc_va_list __arg)
     ;
# 429 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *restrict __stream,
     const char *restrict __format, ...) ;




extern int scanf (const char *restrict __format, ...) ;

extern int sscanf (const char *restrict __s,
     const char *restrict __format, ...) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 445 "/usr/include/stdio.h" 2 3 4
# 479 "/usr/include/stdio.h" 3 4
extern int __isoc99_fscanf (FILE *restrict __stream,
       const char *restrict __format, ...)
  ;
extern int __isoc99_scanf (const char *restrict __format, ...) ;
extern int __isoc99_sscanf (const char *restrict __s,
       const char *restrict __format, ...) ;
# 497 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *restrict __s, const char *restrict __format,
      __gnuc_va_list __arg)
     ;





extern int vscanf (const char *restrict __format, __gnuc_va_list __arg)
     ;


extern int vsscanf (const char *restrict __s,
      const char *restrict __format, __gnuc_va_list __arg)
     ;
# 561 "/usr/include/stdio.h" 3 4
extern int __isoc99_vfscanf (FILE *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
extern int __isoc99_vscanf (const char *restrict __format,
       __gnuc_va_list __arg) ;
extern int __isoc99_vsscanf (const char *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
# 582 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) ;
extern int getc (FILE *__stream) ;





extern int getchar (void);
# 615 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) ;
extern int putc (int __c, FILE *__stream) ;





extern int putchar (int __c);
# 658 "/usr/include/stdio.h" 3 4
extern char *fgets (char *restrict __s, int __n, FILE *restrict __stream)
     ;
# 671 "/usr/include/stdio.h" 3 4
extern char *gets (char *__s) ;
# 711 "/usr/include/stdio.h" 3 4
extern int fputs (const char *restrict __s, FILE *restrict __stream)
  ;





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) ;






extern size_t fread (void *restrict __ptr, size_t __size,
       size_t __n, FILE *restrict __stream)
  ;




extern size_t fwrite (const void *restrict __ptr, size_t __size,
        size_t __n, FILE *restrict __s) ;
# 773 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  ;




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream) ;
# 823 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *restrict __stream, fpos_t *restrict __pos)
  ;




extern int fsetpos (FILE *__stream, const fpos_t *__pos) ;
# 854 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) ;

extern int feof (FILE *__stream) ;

extern int ferror (FILE *__stream) ;
# 872 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) ;
# 953 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 977 "/usr/include/stdio.h" 3 4

# 2 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/floats-lit/lean/regression/floats-lit.c" 2


# 3 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/floats-lit/lean/regression/floats-lit.c"
int error = 0;

void dbl(double x, unsigned long long bits)
{
  union { double d; unsigned long long i; } u;
  u.d = x;
  if (u.i != bits) {
    printf("Error: expected 0x%016llx, got 0x%016llx\n", bits, u.i);
    error = 1;
  }
}

void sng(float x, unsigned int bits)
{
  union { float f; unsigned int i; } u;
  u.f = x;
  if (u.i != bits) {
    printf("Error: expected 0x%08x, got 0x%08x\n", bits, u.i);
    error = 1;
  }
}

void testdbl(void)
{
  printf("--- Double-precision test\n");
  dbl(0.0, 0ULL);
  dbl((-0.0), 0x8000000000000000ULL);


  dbl(0x1p-3, 0x3fc0000000000000ULL);
  dbl(0x1.1p-3, 0x3fc1000000000000ULL);
  dbl(0x1.2p-3, 0x3fc2000000000000ULL);
  dbl(0x1.3p-3, 0x3fc3000000000000ULL);
  dbl(0x1.4p-3, 0x3fc4000000000000ULL);
  dbl(0x1.5p-3, 0x3fc5000000000000ULL);
  dbl(0x1.6p-3, 0x3fc6000000000000ULL);
  dbl(0x1.7p-3, 0x3fc7000000000000ULL);
  dbl(0x1.8p-3, 0x3fc8000000000000ULL);
  dbl(0x1.9p-3, 0x3fc9000000000000ULL);
  dbl(0x1.ap-3, 0x3fca000000000000ULL);
  dbl(0x1.bp-3, 0x3fcb000000000000ULL);
  dbl(0x1.cp-3, 0x3fcc000000000000ULL);
  dbl(0x1.dp-3, 0x3fcd000000000000ULL);
  dbl(0x1.ep-3, 0x3fce000000000000ULL);
  dbl(0x1.fp-3, 0x3fcf000000000000ULL);
  dbl(0x1p-2, 0x3fd0000000000000ULL);
  dbl(0x1.1p-2, 0x3fd1000000000000ULL);
  dbl(0x1.2p-2, 0x3fd2000000000000ULL);
  dbl(0x1.3p-2, 0x3fd3000000000000ULL);
  dbl(0x1.4p-2, 0x3fd4000000000000ULL);
  dbl(0x1.5p-2, 0x3fd5000000000000ULL);
  dbl(0x1.6p-2, 0x3fd6000000000000ULL);
  dbl(0x1.7p-2, 0x3fd7000000000000ULL);
  dbl(0x1.8p-2, 0x3fd8000000000000ULL);
  dbl(0x1.9p-2, 0x3fd9000000000000ULL);
  dbl(0x1.ap-2, 0x3fda000000000000ULL);
  dbl(0x1.bp-2, 0x3fdb000000000000ULL);
  dbl(0x1.cp-2, 0x3fdc000000000000ULL);
  dbl(0x1.dp-2, 0x3fdd000000000000ULL);
  dbl(0x1.ep-2, 0x3fde000000000000ULL);
  dbl(0x1.fp-2, 0x3fdf000000000000ULL);
  dbl(0x1p-1, 0x3fe0000000000000ULL);
  dbl(0x1.1p-1, 0x3fe1000000000000ULL);
  dbl(0x1.2p-1, 0x3fe2000000000000ULL);
  dbl(0x1.3p-1, 0x3fe3000000000000ULL);
  dbl(0x1.4p-1, 0x3fe4000000000000ULL);
  dbl(0x1.5p-1, 0x3fe5000000000000ULL);
  dbl(0x1.6p-1, 0x3fe6000000000000ULL);
  dbl(0x1.7p-1, 0x3fe7000000000000ULL);
  dbl(0x1.8p-1, 0x3fe8000000000000ULL);
  dbl(0x1.9p-1, 0x3fe9000000000000ULL);
  dbl(0x1.ap-1, 0x3fea000000000000ULL);
  dbl(0x1.bp-1, 0x3feb000000000000ULL);
  dbl(0x1.cp-1, 0x3fec000000000000ULL);
  dbl(0x1.dp-1, 0x3fed000000000000ULL);
  dbl(0x1.ep-1, 0x3fee000000000000ULL);
  dbl(0x1.fp-1, 0x3fef000000000000ULL);
  dbl(0x1p+0, 0x3ff0000000000000ULL);
  dbl(0x1.1p+0, 0x3ff1000000000000ULL);
  dbl(0x1.2p+0, 0x3ff2000000000000ULL);
  dbl(0x1.3p+0, 0x3ff3000000000000ULL);
  dbl(0x1.4p+0, 0x3ff4000000000000ULL);
  dbl(0x1.5p+0, 0x3ff5000000000000ULL);
  dbl(0x1.6p+0, 0x3ff6000000000000ULL);
  dbl(0x1.7p+0, 0x3ff7000000000000ULL);
  dbl(0x1.8p+0, 0x3ff8000000000000ULL);
  dbl(0x1.9p+0, 0x3ff9000000000000ULL);
  dbl(0x1.ap+0, 0x3ffa000000000000ULL);
  dbl(0x1.bp+0, 0x3ffb000000000000ULL);
  dbl(0x1.cp+0, 0x3ffc000000000000ULL);
  dbl(0x1.dp+0, 0x3ffd000000000000ULL);
  dbl(0x1.ep+0, 0x3ffe000000000000ULL);
  dbl(0x1.fp+0, 0x3fff000000000000ULL);
  dbl(0x1p+1, 0x4000000000000000ULL);
  dbl(0x1.1p+1, 0x4001000000000000ULL);
  dbl(0x1.2p+1, 0x4002000000000000ULL);
  dbl(0x1.3p+1, 0x4003000000000000ULL);
  dbl(0x1.4p+1, 0x4004000000000000ULL);
  dbl(0x1.5p+1, 0x4005000000000000ULL);
  dbl(0x1.6p+1, 0x4006000000000000ULL);
  dbl(0x1.7p+1, 0x4007000000000000ULL);
  dbl(0x1.8p+1, 0x4008000000000000ULL);
  dbl(0x1.9p+1, 0x4009000000000000ULL);
  dbl(0x1.ap+1, 0x400a000000000000ULL);
  dbl(0x1.bp+1, 0x400b000000000000ULL);
  dbl(0x1.cp+1, 0x400c000000000000ULL);
  dbl(0x1.dp+1, 0x400d000000000000ULL);
  dbl(0x1.ep+1, 0x400e000000000000ULL);
  dbl(0x1.fp+1, 0x400f000000000000ULL);
  dbl(0x1p+2, 0x4010000000000000ULL);
  dbl(0x1.1p+2, 0x4011000000000000ULL);
  dbl(0x1.2p+2, 0x4012000000000000ULL);
  dbl(0x1.3p+2, 0x4013000000000000ULL);
  dbl(0x1.4p+2, 0x4014000000000000ULL);
  dbl(0x1.5p+2, 0x4015000000000000ULL);
  dbl(0x1.6p+2, 0x4016000000000000ULL);
  dbl(0x1.7p+2, 0x4017000000000000ULL);
  dbl(0x1.8p+2, 0x4018000000000000ULL);
  dbl(0x1.9p+2, 0x4019000000000000ULL);
  dbl(0x1.ap+2, 0x401a000000000000ULL);
  dbl(0x1.bp+2, 0x401b000000000000ULL);
  dbl(0x1.cp+2, 0x401c000000000000ULL);
  dbl(0x1.dp+2, 0x401d000000000000ULL);
  dbl(0x1.ep+2, 0x401e000000000000ULL);
  dbl(0x1.fp+2, 0x401f000000000000ULL);
  dbl(0x1p+3, 0x4020000000000000ULL);
  dbl(0x1.1p+3, 0x4021000000000000ULL);
  dbl(0x1.2p+3, 0x4022000000000000ULL);
  dbl(0x1.3p+3, 0x4023000000000000ULL);
  dbl(0x1.4p+3, 0x4024000000000000ULL);
  dbl(0x1.5p+3, 0x4025000000000000ULL);
  dbl(0x1.6p+3, 0x4026000000000000ULL);
  dbl(0x1.7p+3, 0x4027000000000000ULL);
  dbl(0x1.8p+3, 0x4028000000000000ULL);
  dbl(0x1.9p+3, 0x4029000000000000ULL);
  dbl(0x1.ap+3, 0x402a000000000000ULL);
  dbl(0x1.bp+3, 0x402b000000000000ULL);
  dbl(0x1.cp+3, 0x402c000000000000ULL);
  dbl(0x1.dp+3, 0x402d000000000000ULL);
  dbl(0x1.ep+3, 0x402e000000000000ULL);
  dbl(0x1.fp+3, 0x402f000000000000ULL);
  dbl(0x1p+4, 0x4030000000000000ULL);
  dbl(0x1.1p+4, 0x4031000000000000ULL);
  dbl(0x1.2p+4, 0x4032000000000000ULL);
  dbl(0x1.3p+4, 0x4033000000000000ULL);
  dbl(0x1.4p+4, 0x4034000000000000ULL);
  dbl(0x1.5p+4, 0x4035000000000000ULL);
  dbl(0x1.6p+4, 0x4036000000000000ULL);
  dbl(0x1.7p+4, 0x4037000000000000ULL);
  dbl(0x1.8p+4, 0x4038000000000000ULL);
  dbl(0x1.9p+4, 0x4039000000000000ULL);
  dbl(0x1.ap+4, 0x403a000000000000ULL);
  dbl(0x1.bp+4, 0x403b000000000000ULL);
  dbl(0x1.cp+4, 0x403c000000000000ULL);
  dbl(0x1.dp+4, 0x403d000000000000ULL);
  dbl(0x1.ep+4, 0x403e000000000000ULL);
  dbl(0x1.fp+4, 0x403f000000000000ULL);
  dbl((-0x1p-3), 0xbfc0000000000000ULL);
  dbl((-0x1.1p-3), 0xbfc1000000000000ULL);
  dbl((-0x1.2p-3), 0xbfc2000000000000ULL);
  dbl((-0x1.3p-3), 0xbfc3000000000000ULL);
  dbl((-0x1.4p-3), 0xbfc4000000000000ULL);
  dbl((-0x1.5p-3), 0xbfc5000000000000ULL);
  dbl((-0x1.6p-3), 0xbfc6000000000000ULL);
  dbl((-0x1.7p-3), 0xbfc7000000000000ULL);
  dbl((-0x1.8p-3), 0xbfc8000000000000ULL);
  dbl((-0x1.9p-3), 0xbfc9000000000000ULL);
  dbl((-0x1.ap-3), 0xbfca000000000000ULL);
  dbl((-0x1.bp-3), 0xbfcb000000000000ULL);
  dbl((-0x1.cp-3), 0xbfcc000000000000ULL);
  dbl((-0x1.dp-3), 0xbfcd000000000000ULL);
  dbl((-0x1.ep-3), 0xbfce000000000000ULL);
  dbl((-0x1.fp-3), 0xbfcf000000000000ULL);
  dbl((-0x1p-2), 0xbfd0000000000000ULL);
  dbl((-0x1.1p-2), 0xbfd1000000000000ULL);
  dbl((-0x1.2p-2), 0xbfd2000000000000ULL);
  dbl((-0x1.3p-2), 0xbfd3000000000000ULL);
  dbl((-0x1.4p-2), 0xbfd4000000000000ULL);
  dbl((-0x1.5p-2), 0xbfd5000000000000ULL);
  dbl((-0x1.6p-2), 0xbfd6000000000000ULL);
  dbl((-0x1.7p-2), 0xbfd7000000000000ULL);
  dbl((-0x1.8p-2), 0xbfd8000000000000ULL);
  dbl((-0x1.9p-2), 0xbfd9000000000000ULL);
  dbl((-0x1.ap-2), 0xbfda000000000000ULL);
  dbl((-0x1.bp-2), 0xbfdb000000000000ULL);
  dbl((-0x1.cp-2), 0xbfdc000000000000ULL);
  dbl((-0x1.dp-2), 0xbfdd000000000000ULL);
  dbl((-0x1.ep-2), 0xbfde000000000000ULL);
  dbl((-0x1.fp-2), 0xbfdf000000000000ULL);
  dbl((-0x1p-1), 0xbfe0000000000000ULL);
  dbl((-0x1.1p-1), 0xbfe1000000000000ULL);
  dbl((-0x1.2p-1), 0xbfe2000000000000ULL);
  dbl((-0x1.3p-1), 0xbfe3000000000000ULL);
  dbl((-0x1.4p-1), 0xbfe4000000000000ULL);
  dbl((-0x1.5p-1), 0xbfe5000000000000ULL);
  dbl((-0x1.6p-1), 0xbfe6000000000000ULL);
  dbl((-0x1.7p-1), 0xbfe7000000000000ULL);
  dbl((-0x1.8p-1), 0xbfe8000000000000ULL);
  dbl((-0x1.9p-1), 0xbfe9000000000000ULL);
  dbl((-0x1.ap-1), 0xbfea000000000000ULL);
  dbl((-0x1.bp-1), 0xbfeb000000000000ULL);
  dbl((-0x1.cp-1), 0xbfec000000000000ULL);
  dbl((-0x1.dp-1), 0xbfed000000000000ULL);
  dbl((-0x1.ep-1), 0xbfee000000000000ULL);
  dbl((-0x1.fp-1), 0xbfef000000000000ULL);
  dbl((-0x1p+0), 0xbff0000000000000ULL);
  dbl((-0x1.1p+0), 0xbff1000000000000ULL);
  dbl((-0x1.2p+0), 0xbff2000000000000ULL);
  dbl((-0x1.3p+0), 0xbff3000000000000ULL);
  dbl((-0x1.4p+0), 0xbff4000000000000ULL);
  dbl((-0x1.5p+0), 0xbff5000000000000ULL);
  dbl((-0x1.6p+0), 0xbff6000000000000ULL);
  dbl((-0x1.7p+0), 0xbff7000000000000ULL);
  dbl((-0x1.8p+0), 0xbff8000000000000ULL);
  dbl((-0x1.9p+0), 0xbff9000000000000ULL);
  dbl((-0x1.ap+0), 0xbffa000000000000ULL);
  dbl((-0x1.bp+0), 0xbffb000000000000ULL);
  dbl((-0x1.cp+0), 0xbffc000000000000ULL);
  dbl((-0x1.dp+0), 0xbffd000000000000ULL);
  dbl((-0x1.ep+0), 0xbffe000000000000ULL);
  dbl((-0x1.fp+0), 0xbfff000000000000ULL);
  dbl((-0x1p+1), 0xc000000000000000ULL);
  dbl((-0x1.1p+1), 0xc001000000000000ULL);
  dbl((-0x1.2p+1), 0xc002000000000000ULL);
  dbl((-0x1.3p+1), 0xc003000000000000ULL);
  dbl((-0x1.4p+1), 0xc004000000000000ULL);
  dbl((-0x1.5p+1), 0xc005000000000000ULL);
  dbl((-0x1.6p+1), 0xc006000000000000ULL);
  dbl((-0x1.7p+1), 0xc007000000000000ULL);
  dbl((-0x1.8p+1), 0xc008000000000000ULL);
  dbl((-0x1.9p+1), 0xc009000000000000ULL);
  dbl((-0x1.ap+1), 0xc00a000000000000ULL);
  dbl((-0x1.bp+1), 0xc00b000000000000ULL);
  dbl((-0x1.cp+1), 0xc00c000000000000ULL);
  dbl((-0x1.dp+1), 0xc00d000000000000ULL);
  dbl((-0x1.ep+1), 0xc00e000000000000ULL);
  dbl((-0x1.fp+1), 0xc00f000000000000ULL);
  dbl((-0x1p+2), 0xc010000000000000ULL);
  dbl((-0x1.1p+2), 0xc011000000000000ULL);
  dbl((-0x1.2p+2), 0xc012000000000000ULL);
  dbl((-0x1.3p+2), 0xc013000000000000ULL);
  dbl((-0x1.4p+2), 0xc014000000000000ULL);
  dbl((-0x1.5p+2), 0xc015000000000000ULL);
  dbl((-0x1.6p+2), 0xc016000000000000ULL);
  dbl((-0x1.7p+2), 0xc017000000000000ULL);
  dbl((-0x1.8p+2), 0xc018000000000000ULL);
  dbl((-0x1.9p+2), 0xc019000000000000ULL);
  dbl((-0x1.ap+2), 0xc01a000000000000ULL);
  dbl((-0x1.bp+2), 0xc01b000000000000ULL);
  dbl((-0x1.cp+2), 0xc01c000000000000ULL);
  dbl((-0x1.dp+2), 0xc01d000000000000ULL);
  dbl((-0x1.ep+2), 0xc01e000000000000ULL);
  dbl((-0x1.fp+2), 0xc01f000000000000ULL);
  dbl((-0x1p+3), 0xc020000000000000ULL);
  dbl((-0x1.1p+3), 0xc021000000000000ULL);
  dbl((-0x1.2p+3), 0xc022000000000000ULL);
  dbl((-0x1.3p+3), 0xc023000000000000ULL);
  dbl((-0x1.4p+3), 0xc024000000000000ULL);
  dbl((-0x1.5p+3), 0xc025000000000000ULL);
  dbl((-0x1.6p+3), 0xc026000000000000ULL);
  dbl((-0x1.7p+3), 0xc027000000000000ULL);
  dbl((-0x1.8p+3), 0xc028000000000000ULL);
  dbl((-0x1.9p+3), 0xc029000000000000ULL);
  dbl((-0x1.ap+3), 0xc02a000000000000ULL);
  dbl((-0x1.bp+3), 0xc02b000000000000ULL);
  dbl((-0x1.cp+3), 0xc02c000000000000ULL);
  dbl((-0x1.dp+3), 0xc02d000000000000ULL);
  dbl((-0x1.ep+3), 0xc02e000000000000ULL);
  dbl((-0x1.fp+3), 0xc02f000000000000ULL);
  dbl((-0x1p+4), 0xc030000000000000ULL);
  dbl((-0x1.1p+4), 0xc031000000000000ULL);
  dbl((-0x1.2p+4), 0xc032000000000000ULL);
  dbl((-0x1.3p+4), 0xc033000000000000ULL);
  dbl((-0x1.4p+4), 0xc034000000000000ULL);
  dbl((-0x1.5p+4), 0xc035000000000000ULL);
  dbl((-0x1.6p+4), 0xc036000000000000ULL);
  dbl((-0x1.7p+4), 0xc037000000000000ULL);
  dbl((-0x1.8p+4), 0xc038000000000000ULL);
  dbl((-0x1.9p+4), 0xc039000000000000ULL);
  dbl((-0x1.ap+4), 0xc03a000000000000ULL);
  dbl((-0x1.bp+4), 0xc03b000000000000ULL);
  dbl((-0x1.cp+4), 0xc03c000000000000ULL);
  dbl((-0x1.dp+4), 0xc03d000000000000ULL);
  dbl((-0x1.ep+4), 0xc03e000000000000ULL);
  dbl((-0x1.fp+4), 0xc03f000000000000ULL);
}

void testsng(void)
{
  printf("--- Single-precision test\n");
  sng(0x0p+0, 0x0U);
  sng(-0x0p+0, 0x80000000U);
  sng(0x1p-3, 0x3e000000U);
  sng(0x1.1p-3, 0x3e080000U);
  sng(0x1.2p-3, 0x3e100000U);
  sng(0x1.3p-3, 0x3e180000U);
  sng(0x1.4p-3, 0x3e200000U);
  sng(0x1.5p-3, 0x3e280000U);
  sng(0x1.6p-3, 0x3e300000U);
  sng(0x1.7p-3, 0x3e380000U);
  sng(0x1.8p-3, 0x3e400000U);
  sng(0x1.9p-3, 0x3e480000U);
  sng(0x1.ap-3, 0x3e500000U);
  sng(0x1.bp-3, 0x3e580000U);
  sng(0x1.cp-3, 0x3e600000U);
  sng(0x1.dp-3, 0x3e680000U);
  sng(0x1.ep-3, 0x3e700000U);
  sng(0x1.fp-3, 0x3e780000U);
  sng(0x1p-2, 0x3e800000U);
  sng(0x1.1p-2, 0x3e880000U);
  sng(0x1.2p-2, 0x3e900000U);
  sng(0x1.3p-2, 0x3e980000U);
  sng(0x1.4p-2, 0x3ea00000U);
  sng(0x1.5p-2, 0x3ea80000U);
  sng(0x1.6p-2, 0x3eb00000U);
  sng(0x1.7p-2, 0x3eb80000U);
  sng(0x1.8p-2, 0x3ec00000U);
  sng(0x1.9p-2, 0x3ec80000U);
  sng(0x1.ap-2, 0x3ed00000U);
  sng(0x1.bp-2, 0x3ed80000U);
  sng(0x1.cp-2, 0x3ee00000U);
  sng(0x1.dp-2, 0x3ee80000U);
  sng(0x1.ep-2, 0x3ef00000U);
  sng(0x1.fp-2, 0x3ef80000U);
  sng(0x1p-1, 0x3f000000U);
  sng(0x1.1p-1, 0x3f080000U);
  sng(0x1.2p-1, 0x3f100000U);
  sng(0x1.3p-1, 0x3f180000U);
  sng(0x1.4p-1, 0x3f200000U);
  sng(0x1.5p-1, 0x3f280000U);
  sng(0x1.6p-1, 0x3f300000U);
  sng(0x1.7p-1, 0x3f380000U);
  sng(0x1.8p-1, 0x3f400000U);
  sng(0x1.9p-1, 0x3f480000U);
  sng(0x1.ap-1, 0x3f500000U);
  sng(0x1.bp-1, 0x3f580000U);
  sng(0x1.cp-1, 0x3f600000U);
  sng(0x1.dp-1, 0x3f680000U);
  sng(0x1.ep-1, 0x3f700000U);
  sng(0x1.fp-1, 0x3f780000U);
  sng(0x1p+0, 0x3f800000U);
  sng(0x1.1p+0, 0x3f880000U);
  sng(0x1.2p+0, 0x3f900000U);
  sng(0x1.3p+0, 0x3f980000U);
  sng(0x1.4p+0, 0x3fa00000U);
  sng(0x1.5p+0, 0x3fa80000U);
  sng(0x1.6p+0, 0x3fb00000U);
  sng(0x1.7p+0, 0x3fb80000U);
  sng(0x1.8p+0, 0x3fc00000U);
  sng(0x1.9p+0, 0x3fc80000U);
  sng(0x1.ap+0, 0x3fd00000U);
  sng(0x1.bp+0, 0x3fd80000U);
  sng(0x1.cp+0, 0x3fe00000U);
  sng(0x1.dp+0, 0x3fe80000U);
  sng(0x1.ep+0, 0x3ff00000U);
  sng(0x1.fp+0, 0x3ff80000U);
  sng(0x1p+1, 0x40000000U);
  sng(0x1.1p+1, 0x40080000U);
  sng(0x1.2p+1, 0x40100000U);
  sng(0x1.3p+1, 0x40180000U);
  sng(0x1.4p+1, 0x40200000U);
  sng(0x1.5p+1, 0x40280000U);
  sng(0x1.6p+1, 0x40300000U);
  sng(0x1.7p+1, 0x40380000U);
  sng(0x1.8p+1, 0x40400000U);
  sng(0x1.9p+1, 0x40480000U);
  sng(0x1.ap+1, 0x40500000U);
  sng(0x1.bp+1, 0x40580000U);
  sng(0x1.cp+1, 0x40600000U);
  sng(0x1.dp+1, 0x40680000U);
  sng(0x1.ep+1, 0x40700000U);
  sng(0x1.fp+1, 0x40780000U);
  sng(0x1p+2, 0x40800000U);
  sng(0x1.1p+2, 0x40880000U);
  sng(0x1.2p+2, 0x40900000U);
  sng(0x1.3p+2, 0x40980000U);
  sng(0x1.4p+2, 0x40a00000U);
  sng(0x1.5p+2, 0x40a80000U);
  sng(0x1.6p+2, 0x40b00000U);
  sng(0x1.7p+2, 0x40b80000U);
  sng(0x1.8p+2, 0x40c00000U);
  sng(0x1.9p+2, 0x40c80000U);
  sng(0x1.ap+2, 0x40d00000U);
  sng(0x1.bp+2, 0x40d80000U);
  sng(0x1.cp+2, 0x40e00000U);
  sng(0x1.dp+2, 0x40e80000U);
  sng(0x1.ep+2, 0x40f00000U);
  sng(0x1.fp+2, 0x40f80000U);
  sng(0x1p+3, 0x41000000U);
  sng(0x1.1p+3, 0x41080000U);
  sng(0x1.2p+3, 0x41100000U);
  sng(0x1.3p+3, 0x41180000U);
  sng(0x1.4p+3, 0x41200000U);
  sng(0x1.5p+3, 0x41280000U);
  sng(0x1.6p+3, 0x41300000U);
  sng(0x1.7p+3, 0x41380000U);
  sng(0x1.8p+3, 0x41400000U);
  sng(0x1.9p+3, 0x41480000U);
  sng(0x1.ap+3, 0x41500000U);
  sng(0x1.bp+3, 0x41580000U);
  sng(0x1.cp+3, 0x41600000U);
  sng(0x1.dp+3, 0x41680000U);
  sng(0x1.ep+3, 0x41700000U);
  sng(0x1.fp+3, 0x41780000U);
  sng(0x1p+4, 0x41800000U);
  sng(0x1.1p+4, 0x41880000U);
  sng(0x1.2p+4, 0x41900000U);
  sng(0x1.3p+4, 0x41980000U);
  sng(0x1.4p+4, 0x41a00000U);
  sng(0x1.5p+4, 0x41a80000U);
  sng(0x1.6p+4, 0x41b00000U);
  sng(0x1.7p+4, 0x41b80000U);
  sng(0x1.8p+4, 0x41c00000U);
  sng(0x1.9p+4, 0x41c80000U);
  sng(0x1.ap+4, 0x41d00000U);
  sng(0x1.bp+4, 0x41d80000U);
  sng(0x1.cp+4, 0x41e00000U);
  sng(0x1.dp+4, 0x41e80000U);
  sng(0x1.ep+4, 0x41f00000U);
  sng(0x1.fp+4, 0x41f80000U);
  sng(-0x1p-3, 0xbe000000U);
  sng(-0x1.1p-3, 0xbe080000U);
  sng(-0x1.2p-3, 0xbe100000U);
  sng(-0x1.3p-3, 0xbe180000U);
  sng(-0x1.4p-3, 0xbe200000U);
  sng(-0x1.5p-3, 0xbe280000U);
  sng(-0x1.6p-3, 0xbe300000U);
  sng(-0x1.7p-3, 0xbe380000U);
  sng(-0x1.8p-3, 0xbe400000U);
  sng(-0x1.9p-3, 0xbe480000U);
  sng(-0x1.ap-3, 0xbe500000U);
  sng(-0x1.bp-3, 0xbe580000U);
  sng(-0x1.cp-3, 0xbe600000U);
  sng(-0x1.dp-3, 0xbe680000U);
  sng(-0x1.ep-3, 0xbe700000U);
  sng(-0x1.fp-3, 0xbe780000U);
  sng(-0x1p-2, 0xbe800000U);
  sng(-0x1.1p-2, 0xbe880000U);
  sng(-0x1.2p-2, 0xbe900000U);
  sng(-0x1.3p-2, 0xbe980000U);
  sng(-0x1.4p-2, 0xbea00000U);
  sng(-0x1.5p-2, 0xbea80000U);
  sng(-0x1.6p-2, 0xbeb00000U);
  sng(-0x1.7p-2, 0xbeb80000U);
  sng(-0x1.8p-2, 0xbec00000U);
  sng(-0x1.9p-2, 0xbec80000U);
  sng(-0x1.ap-2, 0xbed00000U);
  sng(-0x1.bp-2, 0xbed80000U);
  sng(-0x1.cp-2, 0xbee00000U);
  sng(-0x1.dp-2, 0xbee80000U);
  sng(-0x1.ep-2, 0xbef00000U);
  sng(-0x1.fp-2, 0xbef80000U);
  sng(-0x1p-1, 0xbf000000U);
  sng(-0x1.1p-1, 0xbf080000U);
  sng(-0x1.2p-1, 0xbf100000U);
  sng(-0x1.3p-1, 0xbf180000U);
  sng(-0x1.4p-1, 0xbf200000U);
  sng(-0x1.5p-1, 0xbf280000U);
  sng(-0x1.6p-1, 0xbf300000U);
  sng(-0x1.7p-1, 0xbf380000U);
  sng(-0x1.8p-1, 0xbf400000U);
  sng(-0x1.9p-1, 0xbf480000U);
  sng(-0x1.ap-1, 0xbf500000U);
  sng(-0x1.bp-1, 0xbf580000U);
  sng(-0x1.cp-1, 0xbf600000U);
  sng(-0x1.dp-1, 0xbf680000U);
  sng(-0x1.ep-1, 0xbf700000U);
  sng(-0x1.fp-1, 0xbf780000U);
  sng(-0x1p+0, 0xbf800000U);
  sng(-0x1.1p+0, 0xbf880000U);
  sng(-0x1.2p+0, 0xbf900000U);
  sng(-0x1.3p+0, 0xbf980000U);
  sng(-0x1.4p+0, 0xbfa00000U);
  sng(-0x1.5p+0, 0xbfa80000U);
  sng(-0x1.6p+0, 0xbfb00000U);
  sng(-0x1.7p+0, 0xbfb80000U);
  sng(-0x1.8p+0, 0xbfc00000U);
  sng(-0x1.9p+0, 0xbfc80000U);
  sng(-0x1.ap+0, 0xbfd00000U);
  sng(-0x1.bp+0, 0xbfd80000U);
  sng(-0x1.cp+0, 0xbfe00000U);
  sng(-0x1.dp+0, 0xbfe80000U);
  sng(-0x1.ep+0, 0xbff00000U);
  sng(-0x1.fp+0, 0xbff80000U);
  sng(-0x1p+1, 0xc0000000U);
  sng(-0x1.1p+1, 0xc0080000U);
  sng(-0x1.2p+1, 0xc0100000U);
  sng(-0x1.3p+1, 0xc0180000U);
  sng(-0x1.4p+1, 0xc0200000U);
  sng(-0x1.5p+1, 0xc0280000U);
  sng(-0x1.6p+1, 0xc0300000U);
  sng(-0x1.7p+1, 0xc0380000U);
  sng(-0x1.8p+1, 0xc0400000U);
  sng(-0x1.9p+1, 0xc0480000U);
  sng(-0x1.ap+1, 0xc0500000U);
  sng(-0x1.bp+1, 0xc0580000U);
  sng(-0x1.cp+1, 0xc0600000U);
  sng(-0x1.dp+1, 0xc0680000U);
  sng(-0x1.ep+1, 0xc0700000U);
  sng(-0x1.fp+1, 0xc0780000U);
  sng(-0x1p+2, 0xc0800000U);
  sng(-0x1.1p+2, 0xc0880000U);
  sng(-0x1.2p+2, 0xc0900000U);
  sng(-0x1.3p+2, 0xc0980000U);
  sng(-0x1.4p+2, 0xc0a00000U);
  sng(-0x1.5p+2, 0xc0a80000U);
  sng(-0x1.6p+2, 0xc0b00000U);
  sng(-0x1.7p+2, 0xc0b80000U);
  sng(-0x1.8p+2, 0xc0c00000U);
  sng(-0x1.9p+2, 0xc0c80000U);
  sng(-0x1.ap+2, 0xc0d00000U);
  sng(-0x1.bp+2, 0xc0d80000U);
  sng(-0x1.cp+2, 0xc0e00000U);
  sng(-0x1.dp+2, 0xc0e80000U);
  sng(-0x1.ep+2, 0xc0f00000U);
  sng(-0x1.fp+2, 0xc0f80000U);
  sng(-0x1p+3, 0xc1000000U);
  sng(-0x1.1p+3, 0xc1080000U);
  sng(-0x1.2p+3, 0xc1100000U);
  sng(-0x1.3p+3, 0xc1180000U);
  sng(-0x1.4p+3, 0xc1200000U);
  sng(-0x1.5p+3, 0xc1280000U);
  sng(-0x1.6p+3, 0xc1300000U);
  sng(-0x1.7p+3, 0xc1380000U);
  sng(-0x1.8p+3, 0xc1400000U);
  sng(-0x1.9p+3, 0xc1480000U);
  sng(-0x1.ap+3, 0xc1500000U);
  sng(-0x1.bp+3, 0xc1580000U);
  sng(-0x1.cp+3, 0xc1600000U);
  sng(-0x1.dp+3, 0xc1680000U);
  sng(-0x1.ep+3, 0xc1700000U);
  sng(-0x1.fp+3, 0xc1780000U);
  sng(-0x1p+4, 0xc1800000U);
  sng(-0x1.1p+4, 0xc1880000U);
  sng(-0x1.2p+4, 0xc1900000U);
  sng(-0x1.3p+4, 0xc1980000U);
  sng(-0x1.4p+4, 0xc1a00000U);
  sng(-0x1.5p+4, 0xc1a80000U);
  sng(-0x1.6p+4, 0xc1b00000U);
  sng(-0x1.7p+4, 0xc1b80000U);
  sng(-0x1.8p+4, 0xc1c00000U);
  sng(-0x1.9p+4, 0xc1c80000U);
  sng(-0x1.ap+4, 0xc1d00000U);
  sng(-0x1.bp+4, 0xc1d80000U);
  sng(-0x1.cp+4, 0xc1e00000U);
  sng(-0x1.dp+4, 0xc1e80000U);
  sng(-0x1.ep+4, 0xc1f00000U);
  sng(-0x1.fp+4, 0xc1f80000U);
}


int main()
{
  testdbl();
  testsng();
  return error;
}
