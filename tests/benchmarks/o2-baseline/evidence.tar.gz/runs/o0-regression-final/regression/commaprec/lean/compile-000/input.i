# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/commaprec/lean/regression/commaprec.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/commaprec/lean/regression/commaprec.c"
extern int f(int, int);

int g(int y) {
  int z = (y++, 0);
  return f((z = 1, z), y+2);
}
