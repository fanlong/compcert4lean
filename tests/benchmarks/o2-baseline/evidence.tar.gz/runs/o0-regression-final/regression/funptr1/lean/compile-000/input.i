# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/funptr1/lean/regression/funptr1.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/regression/funptr1/lean/regression/funptr1.c"
int (*pf)(void);
int f(void) {

   pf = &f;
   pf = ***f;
   pf();
   (****pf)();
   (***************f)();
   return 0;
}
