# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/staticlayout/lean/abi/staticlayout.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/staticlayout/lean/abi/staticlayout.c"
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 29 "/usr/include/stdio.h" 2 3 4









# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4

# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef unsigned long size_t;
# 39 "/usr/include/stdio.h" 2 3 4


# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 1 3 4
# 43 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 42 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 45 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 46 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 47 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 48 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 2 3 4

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2:24;

  char _short_backupbuf[1];
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;

  int _unused3;

  __uint64_t _total_written;




  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
# 49 "/usr/include/stdio.h" 2 3 4
# 89 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;
# 133 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 134 "/usr/include/stdio.h" 2 3 4
# 153 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) ;

extern int rename (const char *__old, const char *__new) ;
# 191 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) ;
# 201 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  ;
# 218 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) ;
# 243 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 271 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *restrict __filename,
      const char *restrict __modes)
  ;




extern FILE *freopen (const char *restrict __filename,
        const char *restrict __modes,
        FILE *restrict __stream) ;
# 341 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *restrict __stream, char *restrict __buf)
  ;



extern int setvbuf (FILE *restrict __stream, char *restrict __buf,
      int __modes, size_t __n) ;
# 364 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *restrict __stream,
      const char *restrict __format, ...) ;




extern int printf (const char *restrict __format, ...);

extern int sprintf (char *restrict __s,
      const char *restrict __format, ...) ;





extern int vfprintf (FILE *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;




extern int vprintf (const char *restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;



extern int snprintf (char *restrict __s, size_t __maxlen,
       const char *restrict __format, ...)
     ;

extern int vsnprintf (char *restrict __s, size_t __maxlen,
        const char *restrict __format, __gnuc_va_list __arg)
     ;
# 429 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *restrict __stream,
     const char *restrict __format, ...) ;




extern int scanf (const char *restrict __format, ...) ;

extern int sscanf (const char *restrict __s,
     const char *restrict __format, ...) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 445 "/usr/include/stdio.h" 2 3 4
# 479 "/usr/include/stdio.h" 3 4
extern int __isoc99_fscanf (FILE *restrict __stream,
       const char *restrict __format, ...)
  ;
extern int __isoc99_scanf (const char *restrict __format, ...) ;
extern int __isoc99_sscanf (const char *restrict __s,
       const char *restrict __format, ...) ;
# 497 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *restrict __s, const char *restrict __format,
      __gnuc_va_list __arg)
     ;





extern int vscanf (const char *restrict __format, __gnuc_va_list __arg)
     ;


extern int vsscanf (const char *restrict __s,
      const char *restrict __format, __gnuc_va_list __arg)
     ;
# 561 "/usr/include/stdio.h" 3 4
extern int __isoc99_vfscanf (FILE *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
extern int __isoc99_vscanf (const char *restrict __format,
       __gnuc_va_list __arg) ;
extern int __isoc99_vsscanf (const char *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
# 582 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) ;
extern int getc (FILE *__stream) ;





extern int getchar (void);
# 615 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) ;
extern int putc (int __c, FILE *__stream) ;





extern int putchar (int __c);
# 658 "/usr/include/stdio.h" 3 4
extern char *fgets (char *restrict __s, int __n, FILE *restrict __stream)
     ;
# 671 "/usr/include/stdio.h" 3 4
extern char *gets (char *__s) ;
# 711 "/usr/include/stdio.h" 3 4
extern int fputs (const char *restrict __s, FILE *restrict __stream)
  ;





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) ;






extern size_t fread (void *restrict __ptr, size_t __size,
       size_t __n, FILE *restrict __stream)
  ;




extern size_t fwrite (const void *restrict __ptr, size_t __size,
        size_t __n, FILE *restrict __s) ;
# 773 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  ;




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream) ;
# 823 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *restrict __stream, fpos_t *restrict __pos)
  ;




extern int fsetpos (FILE *__stream, const fpos_t *__pos) ;
# 854 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) ;

extern int feof (FILE *__stream) ;

extern int ferror (FILE *__stream) ;
# 872 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) ;
# 953 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 977 "/usr/include/stdio.h" 3 4

# 2 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/staticlayout/lean/abi/staticlayout.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/staticlayout/lean/abi/../endian.h" 1
# 3 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/staticlayout/lean/abi/staticlayout.c" 2


# 4 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/staticlayout/lean/abi/staticlayout.c"
static inline int bit(void * p, unsigned bitno)
{
  unsigned byteno = bitno / 8;



  unsigned bit_in_byte = bitno & 7;

  return (((unsigned char *) p)[byteno] >> bit_in_byte) & 1;
}

void print_prologue(char * name, size_t al, size_t sz)
{
  printf("%s: align %d, sizeof %d, layout", name, (int)al, (int)sz);
}
# 45 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/staticlayout/lean/abi/staticlayout.c"
void print_contents(size_t sz, void * p)
{
  printf(" - ");
  for (int i = 0; i < sz; i++) {
    printf("%02x", ((unsigned char *)p)[i]);
  }
}


void print_epilogue (void)
{
  printf("\n");
}
# 72 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/staticlayout/lean/abi/staticlayout.c"
int main()
{
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/staticlayout/lean/abi/layout.h" 1
{
struct i12s4ci4 {
  int a:12;
  short b:4;
  char c;
  int d:4;
};
static struct i12s4ci4 x1 = {-1, 0, 0, 0}; static struct i12s4ci4 x2 = {-1, -1, 0, 0}; static struct i12s4ci4 x3 = {-1, 0, -1, 0}; static struct i12s4ci4 x4 = {-1, -1, -1, -1}; print_prologue("i12s4ci4", _Alignof(struct i12s4ci4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i31i15ii5 {
  int a:31;
  int b:15;
  int c;
  int d:5;
};
static struct i31i15ii5 x1 = {-1, 0, 0, 0}; static struct i31i15ii5 x2 = {-1, -1, 0, 0}; static struct i31i15ii5 x3 = {-1, 0, -1, 0}; static struct i31i15ii5 x4 = {-1, -1, -1, -1}; print_prologue("i31i15ii5", _Alignof(struct i31i15ii5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7sii12 {
  int a:7;
  short b;
  int c;
  int d:12;
};
static struct i7sii12 x1 = {-1, 0, 0, 0}; static struct i7sii12 x2 = {-1, -1, 0, 0}; static struct i7sii12 x3 = {-1, 0, -1, 0}; static struct i7sii12 x4 = {-1, -1, -1, -1}; print_prologue("i7sii12", _Alignof(struct i7sii12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1c2i20s7 {
  char a:1;
  char b:2;
  int c:20;
  short d:7;
};
static struct c1c2i20s7 x1 = {-1, 0, 0, 0}; static struct c1c2i20s7 x2 = {-1, -1, 0, 0}; static struct c1c2i20s7 x3 = {-1, 0, -1, 0}; static struct c1c2i20s7 x4 = {-1, -1, -1, -1}; print_prologue("c1c2i20s7", _Alignof(struct c1c2i20s7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii1ii1 {
  int a;
  int b:1;
  int c;
  int d:1;
};
static struct ii1ii1 x1 = {-1, 0, 0, 0}; static struct ii1ii1 x2 = {-1, -1, 0, 0}; static struct ii1ii1 x3 = {-1, 0, -1, 0}; static struct ii1ii1 x4 = {-1, -1, -1, -1}; print_prologue("ii1ii1", _Alignof(struct ii1ii1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7i1c3i {
  char a:7;
  int b:1;
  char c:3;
  int d;
};
static struct c7i1c3i x1 = {-1, 0, 0, 0}; static struct c7i1c3i x2 = {-1, -1, 0, 0}; static struct c7i1c3i x3 = {-1, 0, -1, 0}; static struct c7i1c3i x4 = {-1, -1, -1, -1}; print_prologue("c7i1c3i", _Alignof(struct c7i1c3i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2bi11i {
  short a:2;
  _Bool b;
  int c:11;
  int d;
};
static struct s2bi11i x1 = {-1, 0, 0, 0}; static struct s2bi11i x2 = {-1, -1, 0, 0}; static struct s2bi11i x3 = {-1, 0, -1, 0}; static struct s2bi11i x4 = {-1, -1, -1, -1}; print_prologue("s2bi11i", _Alignof(struct s2bi11i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s7i30s5i3 {
  short a:7;
  int b:30;
  short c:5;
  int d:3;
};
static struct s7i30s5i3 x1 = {-1, 0, 0, 0}; static struct s7i30s5i3 x2 = {-1, -1, 0, 0}; static struct s7i30s5i3 x3 = {-1, 0, -1, 0}; static struct s7i30s5i3 x4 = {-1, -1, -1, -1}; print_prologue("s7i30s5i3", _Alignof(struct s7i30s5i3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1s12b1i1 {
  char a:1;
  short b:12;
  _Bool c:1;
  int d:1;
};
static struct c1s12b1i1 x1 = {-1, 0, 0, 0}; static struct c1s12b1i1 x2 = {-1, -1, 0, 0}; static struct c1s12b1i1 x3 = {-1, 0, -1, 0}; static struct c1s12b1i1 x4 = {-1, -1, -1, -1}; print_prologue("c1s12b1i1", _Alignof(struct c1s12b1i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i15is10i15 {
  int a:15;
  int b;
  short c:10;
  int d:15;
};
static struct i15is10i15 x1 = {-1, 0, 0, 0}; static struct i15is10i15 x2 = {-1, -1, 0, 0}; static struct i15is10i15 x3 = {-1, 0, -1, 0}; static struct i15is10i15 x4 = {-1, -1, -1, -1}; print_prologue("i15is10i15", _Alignof(struct i15is10i15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is1i1s1 {
  int a;
  short b:1;
  int c:1;
  short d:1;
};
static struct is1i1s1 x1 = {-1, 0, 0, 0}; static struct is1i1s1 x2 = {-1, -1, 0, 0}; static struct is1i1s1 x3 = {-1, 0, -1, 0}; static struct is1i1s1 x4 = {-1, -1, -1, -1}; print_prologue("is1i1s1", _Alignof(struct is1i1s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i15i10s10c2 {
  int a:15;
  int b:10;
  short c:10;
  char d:2;
};
static struct i15i10s10c2 x1 = {-1, 0, 0, 0}; static struct i15i10s10c2 x2 = {-1, -1, 0, 0}; static struct i15i10s10c2 x3 = {-1, 0, -1, 0}; static struct i15i10s10c2 x4 = {-1, -1, -1, -1}; print_prologue("i15i10s10c2", _Alignof(struct i15i10s10c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I31i4b1i9B1s {
  int :31;
  int a:4;
  _Bool b:1;
  int c:9;
  _Bool :1;
  short d;
};
static struct I31i4b1i9B1s x1 = {-1, 0, 0, 0}; static struct I31i4b1i9B1s x2 = {-1, -1, 0, 0}; static struct I31i4b1i9B1s x3 = {-1, 0, -1, 0}; static struct I31i4b1i9B1s x4 = {-1, -1, -1, -1}; print_prologue("I31i4b1i9B1s", _Alignof(struct I31i4b1i9B1s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5i6i2i14 {
  char a:5;
  int b:6;
  int c:2;
  int d:14;
};
static struct c5i6i2i14 x1 = {-1, 0, 0, 0}; static struct c5i6i2i14 x2 = {-1, -1, 0, 0}; static struct c5i6i2i14 x3 = {-1, 0, -1, 0}; static struct c5i6i2i14 x4 = {-1, -1, -1, -1}; print_prologue("c5i6i2i14", _Alignof(struct c5i6i2i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i13b1c6s6 {
  int a:13;
  _Bool b:1;
  char c:6;
  short d:6;
};
static struct i13b1c6s6 x1 = {-1, 0, 0, 0}; static struct i13b1c6s6 x2 = {-1, -1, 0, 0}; static struct i13b1c6s6 x3 = {-1, 0, -1, 0}; static struct i13b1c6s6 x4 = {-1, -1, -1, -1}; print_prologue("i13b1c6s6", _Alignof(struct i13b1c6s6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1B1c3i5b {
  _Bool a:1;
  _Bool :1;
  char b:3;
  int c:5;
  _Bool d;
};
static struct b1B1c3i5b x1 = {-1, 0, 0, 0}; static struct b1B1c3i5b x2 = {-1, -1, 0, 0}; static struct b1B1c3i5b x3 = {-1, 0, -1, 0}; static struct b1B1c3i5b x4 = {-1, -1, -1, -1}; print_prologue("b1B1c3i5b", _Alignof(struct b1B1c3i5b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct si9i21s2 {
  short a;
  int b:9;
  int c:21;
  short d:2;
};
static struct si9i21s2 x1 = {-1, 0, 0, 0}; static struct si9i21s2 x2 = {-1, -1, 0, 0}; static struct si9i21s2 x3 = {-1, 0, -1, 0}; static struct si9i21s2 x4 = {-1, -1, -1, -1}; print_prologue("si9i21s2", _Alignof(struct si9i21s2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S0csc2c1 {
  short :0;
  char a;
  short b;
  char c:2;
  char d:1;
};
static struct S0csc2c1 x1 = {-1, 0, 0, 0}; static struct S0csc2c1 x2 = {-1, -1, 0, 0}; static struct S0csc2c1 x3 = {-1, 0, -1, 0}; static struct S0csc2c1 x4 = {-1, -1, -1, -1}; print_prologue("S0csc2c1", _Alignof(struct S0csc2c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2I2b1b1i1 {
  int a:2;
  int :2;
  _Bool b:1;
  _Bool c:1;
  int d:1;
};
static struct i2I2b1b1i1 x1 = {-1, 0, 0, 0}; static struct i2I2b1b1i1 x2 = {-1, -1, 0, 0}; static struct i2I2b1b1i1 x3 = {-1, 0, -1, 0}; static struct i2I2b1b1i1 x4 = {-1, -1, -1, -1}; print_prologue("i2I2b1b1i1", _Alignof(struct i2I2b1b1i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2ii2b {
  char a:2;
  int b;
  int c:2;
  _Bool d;
};
static struct c2ii2b x1 = {-1, 0, 0, 0}; static struct c2ii2b x2 = {-1, -1, 0, 0}; static struct c2ii2b x3 = {-1, 0, -1, 0}; static struct c2ii2b x4 = {-1, -1, -1, -1}; print_prologue("c2ii2b", _Alignof(struct c2ii2b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2s5cc {
  short a:2;
  short b:5;
  char c;
  char d;
};
static struct s2s5cc x1 = {-1, 0, 0, 0}; static struct s2s5cc x2 = {-1, -1, 0, 0}; static struct s2s5cc x3 = {-1, 0, -1, 0}; static struct s2s5cc x4 = {-1, -1, -1, -1}; print_prologue("s2s5cc", _Alignof(struct s2s5cc), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C2I14b1i2ib {
  char :2;
  int :14;
  _Bool a:1;
  int b:2;
  int c;
  _Bool d;
};
static struct C2I14b1i2ib x1 = {-1, 0, 0, 0}; static struct C2I14b1i2ib x2 = {-1, -1, 0, 0}; static struct C2I14b1i2ib x3 = {-1, 0, -1, 0}; static struct C2I14b1i2ib x4 = {-1, -1, -1, -1}; print_prologue("C2I14b1i2ib", _Alignof(struct C2I14b1i2ib), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i27s7i4 {
  _Bool a:1;
  int b:27;
  short c:7;
  int d:4;
};
static struct b1i27s7i4 x1 = {-1, 0, 0, 0}; static struct b1i27s7i4 x2 = {-1, -1, 0, 0}; static struct b1i27s7i4 x3 = {-1, 0, -1, 0}; static struct b1i27s7i4 x4 = {-1, -1, -1, -1}; print_prologue("b1i27s7i4", _Alignof(struct b1i27s7i4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cis6i15 {
  char a;
  int b;
  short c:6;
  int d:15;
};
static struct cis6i15 x1 = {-1, 0, 0, 0}; static struct cis6i15 x2 = {-1, -1, 0, 0}; static struct cis6i15 x3 = {-1, 0, -1, 0}; static struct cis6i15 x4 = {-1, -1, -1, -1}; print_prologue("cis6i15", _Alignof(struct cis6i15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4i7c6c4 {
  short a:4;
  int b:7;
  char c:6;
  char d:4;
};
static struct s4i7c6c4 x1 = {-1, 0, 0, 0}; static struct s4i7c6c4 x2 = {-1, -1, 0, 0}; static struct s4i7c6c4 x3 = {-1, 0, -1, 0}; static struct s4i7c6c4 x4 = {-1, -1, -1, -1}; print_prologue("s4i7c6c4", _Alignof(struct s4i7c6c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i19sc4i22 {
  int a:19;
  short b;
  char c:4;
  int d:22;
};
static struct i19sc4i22 x1 = {-1, 0, 0, 0}; static struct i19sc4i22 x2 = {-1, -1, 0, 0}; static struct i19sc4i22 x3 = {-1, 0, -1, 0}; static struct i19sc4i22 x4 = {-1, -1, -1, -1}; print_prologue("i19sc4i22", _Alignof(struct i19sc4i22), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1sc4s5 {
  _Bool a:1;
  short b;
  char c:4;
  short d:5;
};
static struct b1sc4s5 x1 = {-1, 0, 0, 0}; static struct b1sc4s5 x2 = {-1, -1, 0, 0}; static struct b1sc4s5 x3 = {-1, 0, -1, 0}; static struct b1sc4s5 x4 = {-1, -1, -1, -1}; print_prologue("b1sc4s5", _Alignof(struct b1sc4s5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4b1ii2 {
  char a:4;
  _Bool b:1;
  int c;
  int d:2;
};
static struct c4b1ii2 x1 = {-1, 0, 0, 0}; static struct c4b1ii2 x2 = {-1, -1, 0, 0}; static struct c4b1ii2 x3 = {-1, 0, -1, 0}; static struct c4b1ii2 x4 = {-1, -1, -1, -1}; print_prologue("c4b1ii2", _Alignof(struct c4b1ii2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ciic1 {
  char a;
  int b;
  int c;
  char d:1;
};
static struct ciic1 x1 = {-1, 0, 0, 0}; static struct ciic1 x2 = {-1, -1, 0, 0}; static struct ciic1 x3 = {-1, 0, -1, 0}; static struct ciic1 x4 = {-1, -1, -1, -1}; print_prologue("ciic1", _Alignof(struct ciic1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i28b1c4c8 {
  int a:28;
  _Bool b:1;
  char c:4;
  char d:8;
};
static struct i28b1c4c8 x1 = {-1, 0, 0, 0}; static struct i28b1c4c8 x2 = {-1, -1, 0, 0}; static struct i28b1c4c8 x3 = {-1, 0, -1, 0}; static struct i28b1c4c8 x4 = {-1, -1, -1, -1}; print_prologue("i28b1c4c8", _Alignof(struct i28b1c4c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1s4ci1 {
  char a:1;
  short b:4;
  char c;
  int d:1;
};
static struct c1s4ci1 x1 = {-1, 0, 0, 0}; static struct c1s4ci1 x2 = {-1, -1, 0, 0}; static struct c1s4ci1 x3 = {-1, 0, -1, 0}; static struct c1s4ci1 x4 = {-1, -1, -1, -1}; print_prologue("c1s4ci1", _Alignof(struct c1s4ci1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sb1b1s5 {
  short a;
  _Bool b:1;
  _Bool c:1;
  short d:5;
};
static struct sb1b1s5 x1 = {-1, 0, 0, 0}; static struct sb1b1s5 x2 = {-1, -1, 0, 0}; static struct sb1b1s5 x3 = {-1, 0, -1, 0}; static struct sb1b1s5 x4 = {-1, -1, -1, -1}; print_prologue("sb1b1s5", _Alignof(struct sb1b1s5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i13i2I16b1s9 {
  int a:13;
  int b:2;
  int :16;
  _Bool c:1;
  short d:9;
};
static struct i13i2I16b1s9 x1 = {-1, 0, 0, 0}; static struct i13i2I16b1s9 x2 = {-1, -1, 0, 0}; static struct i13i2I16b1s9 x3 = {-1, 0, -1, 0}; static struct i13i2I16b1s9 x4 = {-1, -1, -1, -1}; print_prologue("i13i2I16b1s9", _Alignof(struct i13i2I16b1s9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1c5i {
  int a;
  _Bool b:1;
  char c:5;
  int d;
};
static struct ib1c5i x1 = {-1, 0, 0, 0}; static struct ib1c5i x2 = {-1, -1, 0, 0}; static struct ib1c5i x3 = {-1, 0, -1, 0}; static struct ib1c5i x4 = {-1, -1, -1, -1}; print_prologue("ib1c5i", _Alignof(struct ib1c5i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2i1b1i8 {
  short a:2;
  int b:1;
  _Bool c:1;
  int d:8;
};
static struct s2i1b1i8 x1 = {-1, 0, 0, 0}; static struct s2i1b1i8 x2 = {-1, -1, 0, 0}; static struct s2i1b1i8 x3 = {-1, 0, -1, 0}; static struct s2i1b1i8 x4 = {-1, -1, -1, -1}; print_prologue("s2i1b1i8", _Alignof(struct s2i1b1i8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2s6is5 {
  char a:2;
  short b:6;
  int c;
  short d:5;
};
static struct c2s6is5 x1 = {-1, 0, 0, 0}; static struct c2s6is5 x2 = {-1, -1, 0, 0}; static struct c2s6is5 x3 = {-1, 0, -1, 0}; static struct c2s6is5 x4 = {-1, -1, -1, -1}; print_prologue("c2s6is5", _Alignof(struct c2s6is5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i19ci5c1 {
  int a:19;
  char b;
  int c:5;
  char d:1;
};
static struct i19ci5c1 x1 = {-1, 0, 0, 0}; static struct i19ci5c1 x2 = {-1, -1, 0, 0}; static struct i19ci5c1 x3 = {-1, 0, -1, 0}; static struct i19ci5c1 x4 = {-1, -1, -1, -1}; print_prologue("i19ci5c1", _Alignof(struct i19ci5c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s3c1S10c5i5 {
  short a:3;
  char b:1;
  short :10;
  char c:5;
  int d:5;
};
static struct s3c1S10c5i5 x1 = {-1, 0, 0, 0}; static struct s3c1S10c5i5 x2 = {-1, -1, 0, 0}; static struct s3c1S10c5i5 x3 = {-1, 0, -1, 0}; static struct s3c1S10c5i5 x4 = {-1, -1, -1, -1}; print_prologue("s3c1S10c5i5", _Alignof(struct s3c1S10c5i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sI0S2s13c3i18 {
  short a;
  int :0;
  short :2;
  short b:13;
  char c:3;
  int d:18;
};
static struct sI0S2s13c3i18 x1 = {-1, 0, 0, 0}; static struct sI0S2s13c3i18 x2 = {-1, -1, 0, 0}; static struct sI0S2s13c3i18 x3 = {-1, 0, -1, 0}; static struct sI0S2s13c3i18 x4 = {-1, -1, -1, -1}; print_prologue("sI0S2s13c3i18", _Alignof(struct sI0S2s13c3i18), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1bic8 {
  char a:1;
  _Bool b;
  int c;
  char d:8;
};
static struct c1bic8 x1 = {-1, 0, 0, 0}; static struct c1bic8 x2 = {-1, -1, 0, 0}; static struct c1bic8 x3 = {-1, 0, -1, 0}; static struct c1bic8 x4 = {-1, -1, -1, -1}; print_prologue("c1bic8", _Alignof(struct c1bic8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s8I9b1c1S0i6 {
  short a:8;
  int :9;
  _Bool b:1;
  char c:1;
  short :0;
  int d:6;
};
static struct s8I9b1c1S0i6 x1 = {-1, 0, 0, 0}; static struct s8I9b1c1S0i6 x2 = {-1, -1, 0, 0}; static struct s8I9b1c1S0i6 x3 = {-1, 0, -1, 0}; static struct s8I9b1c1S0i6 x4 = {-1, -1, -1, -1}; print_prologue("s8I9b1c1S0i6", _Alignof(struct s8I9b1c1S0i6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I12ss12s8i {
  int :12;
  short a;
  short b:12;
  short c:8;
  int d;
};
static struct I12ss12s8i x1 = {-1, 0, 0, 0}; static struct I12ss12s8i x2 = {-1, -1, 0, 0}; static struct I12ss12s8i x3 = {-1, 0, -1, 0}; static struct I12ss12s8i x4 = {-1, -1, -1, -1}; print_prologue("I12ss12s8i", _Alignof(struct I12ss12s8i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ci1b1c1 {
  char a;
  int b:1;
  _Bool c:1;
  char d:1;
};
static struct ci1b1c1 x1 = {-1, 0, 0, 0}; static struct ci1b1c1 x2 = {-1, -1, 0, 0}; static struct ci1b1c1 x3 = {-1, 0, -1, 0}; static struct ci1b1c1 x4 = {-1, -1, -1, -1}; print_prologue("ci1b1c1", _Alignof(struct ci1b1c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4i3i7i17 {
  char a:4;
  int b:3;
  int c:7;
  int d:17;
};
static struct c4i3i7i17 x1 = {-1, 0, 0, 0}; static struct c4i3i7i17 x2 = {-1, -1, 0, 0}; static struct c4i3i7i17 x3 = {-1, 0, -1, 0}; static struct c4i3i7i17 x4 = {-1, -1, -1, -1}; print_prologue("c4i3i7i17", _Alignof(struct c4i3i7i17), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C8icii23 {
  char :8;
  int a;
  char b;
  int c;
  int d:23;
};
static struct C8icii23 x1 = {-1, 0, 0, 0}; static struct C8icii23 x2 = {-1, -1, 0, 0}; static struct C8icii23 x3 = {-1, 0, -1, 0}; static struct C8icii23 x4 = {-1, -1, -1, -1}; print_prologue("C8icii23", _Alignof(struct C8icii23), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s14S4i2si2 {
  short a:14;
  short :4;
  int b:2;
  short c;
  int d:2;
};
static struct s14S4i2si2 x1 = {-1, 0, 0, 0}; static struct s14S4i2si2 x2 = {-1, -1, 0, 0}; static struct s14S4i2si2 x3 = {-1, 0, -1, 0}; static struct s14S4i2si2 x4 = {-1, -1, -1, -1}; print_prologue("s14S4i2si2", _Alignof(struct s14S4i2si2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4ici2 {
  short a:4;
  int b;
  char c;
  int d:2;
};
static struct s4ici2 x1 = {-1, 0, 0, 0}; static struct s4ici2 x2 = {-1, -1, 0, 0}; static struct s4ici2 x3 = {-1, 0, -1, 0}; static struct s4ici2 x4 = {-1, -1, -1, -1}; print_prologue("s4ici2", _Alignof(struct s4ici2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1s5b1s {
  short a:1;
  short b:5;
  _Bool c:1;
  short d;
};
static struct s1s5b1s x1 = {-1, 0, 0, 0}; static struct s1s5b1s x2 = {-1, -1, 0, 0}; static struct s1s5b1s x3 = {-1, 0, -1, 0}; static struct s1s5b1s x4 = {-1, -1, -1, -1}; print_prologue("s1s5b1s", _Alignof(struct s1s5b1s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7c1C1i25c8 {
  char a:7;
  char b:1;
  char :1;
  int c:25;
  char d:8;
};
static struct c7c1C1i25c8 x1 = {-1, 0, 0, 0}; static struct c7c1C1i25c8 x2 = {-1, -1, 0, 0}; static struct c7c1C1i25c8 x3 = {-1, 0, -1, 0}; static struct c7c1C1i25c8 x4 = {-1, -1, -1, -1}; print_prologue("c7c1C1i25c8", _Alignof(struct c7c1C1i25c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s8i28c3s12 {
  short a:8;
  int b:28;
  char c:3;
  short d:12;
};
static struct s8i28c3s12 x1 = {-1, 0, 0, 0}; static struct s8i28c3s12 x2 = {-1, -1, 0, 0}; static struct s8i28c3s12 x3 = {-1, 0, -1, 0}; static struct s8i28c3s12 x4 = {-1, -1, -1, -1}; print_prologue("s8i28c3s12", _Alignof(struct s8i28c3s12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4i1s2i {
  char a:4;
  int b:1;
  short c:2;
  int d;
};
static struct c4i1s2i x1 = {-1, 0, 0, 0}; static struct c4i1s2i x2 = {-1, -1, 0, 0}; static struct c4i1s2i x3 = {-1, 0, -1, 0}; static struct c4i1s2i x4 = {-1, -1, -1, -1}; print_prologue("c4i1s2i", _Alignof(struct c4i1s2i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s5C0s2bb1 {
  short a:5;
  char :0;
  short b:2;
  _Bool c;
  _Bool d:1;
};
static struct s5C0s2bb1 x1 = {-1, 0, 0, 0}; static struct s5C0s2bb1 x2 = {-1, -1, 0, 0}; static struct s5C0s2bb1 x3 = {-1, 0, -1, 0}; static struct s5C0s2bb1 x4 = {-1, -1, -1, -1}; print_prologue("s5C0s2bb1", _Alignof(struct s5C0s2bb1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i30I0B1si14c5 {
  int a:30;
  int :0;
  _Bool :1;
  short b;
  int c:14;
  char d:5;
};
static struct i30I0B1si14c5 x1 = {-1, 0, 0, 0}; static struct i30I0B1si14c5 x2 = {-1, -1, 0, 0}; static struct i30I0B1si14c5 x3 = {-1, 0, -1, 0}; static struct i30I0B1si14c5 x4 = {-1, -1, -1, -1}; print_prologue("i30I0B1si14c5", _Alignof(struct i30I0B1si14c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1C4is1s13 {
  char a:1;
  char :4;
  int b;
  short c:1;
  short d:13;
};
static struct c1C4is1s13 x1 = {-1, 0, 0, 0}; static struct c1C4is1s13 x2 = {-1, -1, 0, 0}; static struct c1C4is1s13 x3 = {-1, 0, -1, 0}; static struct c1C4is1s13 x4 = {-1, -1, -1, -1}; print_prologue("c1C4is1s13", _Alignof(struct c1C4is1s13), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s8c6ic1 {
  short a:8;
  char b:6;
  int c;
  char d:1;
};
static struct s8c6ic1 x1 = {-1, 0, 0, 0}; static struct s8c6ic1 x2 = {-1, -1, 0, 0}; static struct s8c6ic1 x3 = {-1, 0, -1, 0}; static struct s8c6ic1 x4 = {-1, -1, -1, -1}; print_prologue("s8c6ic1", _Alignof(struct s8c6ic1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i29i1s3I0i1 {
  int a:29;
  int b:1;
  short c:3;
  int :0;
  int d:1;
};
static struct i29i1s3I0i1 x1 = {-1, 0, 0, 0}; static struct i29i1s3I0i1 x2 = {-1, -1, 0, 0}; static struct i29i1s3I0i1 x3 = {-1, 0, -1, 0}; static struct i29i1s3I0i1 x4 = {-1, -1, -1, -1}; print_prologue("i29i1s3I0i1", _Alignof(struct i29i1s3I0i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8c4s3i8 {
  char a:8;
  char b:4;
  short c:3;
  int d:8;
};
static struct c8c4s3i8 x1 = {-1, 0, 0, 0}; static struct c8c4s3i8 x2 = {-1, -1, 0, 0}; static struct c8c4s3i8 x3 = {-1, 0, -1, 0}; static struct c8c4s3i8 x4 = {-1, -1, -1, -1}; print_prologue("c8c4s3i8", _Alignof(struct c8c4s3i8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2i12ic4 {
  char a:2;
  int b:12;
  int c;
  char d:4;
};
static struct c2i12ic4 x1 = {-1, 0, 0, 0}; static struct c2i12ic4 x2 = {-1, -1, 0, 0}; static struct c2i12ic4 x3 = {-1, 0, -1, 0}; static struct c2i12ic4 x4 = {-1, -1, -1, -1}; print_prologue("c2i12ic4", _Alignof(struct c2i12ic4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is2s12c4 {
  int a;
  short b:2;
  short c:12;
  char d:4;
};
static struct is2s12c4 x1 = {-1, 0, 0, 0}; static struct is2s12c4 x2 = {-1, -1, 0, 0}; static struct is2s12c4 x3 = {-1, 0, -1, 0}; static struct is2s12c4 x4 = {-1, -1, -1, -1}; print_prologue("is2s12c4", _Alignof(struct is2s12c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct B1I3i9b1c4c6 {
  _Bool :1;
  int :3;
  int a:9;
  _Bool b:1;
  char c:4;
  char d:6;
};
static struct B1I3i9b1c4c6 x1 = {-1, 0, 0, 0}; static struct B1I3i9b1c4c6 x2 = {-1, -1, 0, 0}; static struct B1I3i9b1c4c6 x3 = {-1, 0, -1, 0}; static struct B1I3i9b1c4c6 x4 = {-1, -1, -1, -1}; print_prologue("B1I3i9b1c4c6", _Alignof(struct B1I3i9b1c4c6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3b1i7s4 {
  char a:3;
  _Bool b:1;
  int c:7;
  short d:4;
};
static struct c3b1i7s4 x1 = {-1, 0, 0, 0}; static struct c3b1i7s4 x2 = {-1, -1, 0, 0}; static struct c3b1i7s4 x3 = {-1, 0, -1, 0}; static struct c3b1i7s4 x4 = {-1, -1, -1, -1}; print_prologue("c3b1i7s4", _Alignof(struct c3b1i7s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i28i11c3s3 {
  int a:28;
  int b:11;
  char c:3;
  short d:3;
};
static struct i28i11c3s3 x1 = {-1, 0, 0, 0}; static struct i28i11c3s3 x2 = {-1, -1, 0, 0}; static struct i28i11c3s3 x3 = {-1, 0, -1, 0}; static struct i28i11c3s3 x4 = {-1, -1, -1, -1}; print_prologue("i28i11c3s3", _Alignof(struct i28i11c3s3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s5bb1b1 {
  short a:5;
  _Bool b;
  _Bool c:1;
  _Bool d:1;
};
static struct s5bb1b1 x1 = {-1, 0, 0, 0}; static struct s5bb1b1 x2 = {-1, -1, 0, 0}; static struct s5bb1b1 x3 = {-1, 0, -1, 0}; static struct s5bb1b1 x4 = {-1, -1, -1, -1}; print_prologue("s5bb1b1", _Alignof(struct s5bb1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1s16I32i31c6 {
  char a:1;
  short b:16;
  int :32;
  int c:31;
  char d:6;
};
static struct c1s16I32i31c6 x1 = {-1, 0, 0, 0}; static struct c1s16I32i31c6 x2 = {-1, -1, 0, 0}; static struct c1s16I32i31c6 x3 = {-1, 0, -1, 0}; static struct c1s16I32i31c6 x4 = {-1, -1, -1, -1}; print_prologue("c1s16I32i31c6", _Alignof(struct c1s16I32i31c6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C0ic7i9c3 {
  char :0;
  int a;
  char b:7;
  int c:9;
  char d:3;
};
static struct C0ic7i9c3 x1 = {-1, 0, 0, 0}; static struct C0ic7i9c3 x2 = {-1, -1, 0, 0}; static struct C0ic7i9c3 x3 = {-1, 0, -1, 0}; static struct C0ic7i9c3 x4 = {-1, -1, -1, -1}; print_prologue("C0ic7i9c3", _Alignof(struct C0ic7i9c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0i6i2c8i4 {
  int :0;
  int a:6;
  int b:2;
  char c:8;
  int d:4;
};
static struct I0i6i2c8i4 x1 = {-1, 0, 0, 0}; static struct I0i6i2c8i4 x2 = {-1, -1, 0, 0}; static struct I0i6i2c8i4 x3 = {-1, 0, -1, 0}; static struct I0i6i2c8i4 x4 = {-1, -1, -1, -1}; print_prologue("I0i6i2c8i4", _Alignof(struct I0i6i2c8i4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I7si1i19c3 {
  int :7;
  short a;
  int b:1;
  int c:19;
  char d:3;
};
static struct I7si1i19c3 x1 = {-1, 0, 0, 0}; static struct I7si1i19c3 x2 = {-1, -1, 0, 0}; static struct I7si1i19c3 x3 = {-1, 0, -1, 0}; static struct I7si1i19c3 x4 = {-1, -1, -1, -1}; print_prologue("I7si1i19c3", _Alignof(struct I7si1i19c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S3s16c1s11i {
  short :3;
  short a:16;
  char b:1;
  short c:11;
  int d;
};
static struct S3s16c1s11i x1 = {-1, 0, 0, 0}; static struct S3s16c1s11i x2 = {-1, -1, 0, 0}; static struct S3s16c1s11i x3 = {-1, 0, -1, 0}; static struct S3s16c1s11i x4 = {-1, -1, -1, -1}; print_prologue("S3s16c1s11i", _Alignof(struct S3s16c1s11i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4i18I9ic6 {
  short a:4;
  int b:18;
  int :9;
  int c;
  char d:6;
};
static struct s4i18I9ic6 x1 = {-1, 0, 0, 0}; static struct s4i18I9ic6 x2 = {-1, -1, 0, 0}; static struct s4i18I9ic6 x3 = {-1, 0, -1, 0}; static struct s4i18I9ic6 x4 = {-1, -1, -1, -1}; print_prologue("s4i18I9ic6", _Alignof(struct s4i18I9ic6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bi5ii14 {
  _Bool a;
  int b:5;
  int c;
  int d:14;
};
static struct bi5ii14 x1 = {-1, 0, 0, 0}; static struct bi5ii14 x2 = {-1, -1, 0, 0}; static struct bi5ii14 x3 = {-1, 0, -1, 0}; static struct bi5ii14 x4 = {-1, -1, -1, -1}; print_prologue("bi5ii14", _Alignof(struct bi5ii14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5s5c6s13 {
  char a:5;
  short b:5;
  char c:6;
  short d:13;
};
static struct c5s5c6s13 x1 = {-1, 0, 0, 0}; static struct c5s5c6s13 x2 = {-1, -1, 0, 0}; static struct c5s5c6s13 x3 = {-1, 0, -1, 0}; static struct c5s5c6s13 x4 = {-1, -1, -1, -1}; print_prologue("c5s5c6s13", _Alignof(struct c5s5c6s13), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sb1i20c2 {
  short a;
  _Bool b:1;
  int c:20;
  char d:2;
};
static struct sb1i20c2 x1 = {-1, 0, 0, 0}; static struct sb1i20c2 x2 = {-1, -1, 0, 0}; static struct sb1i20c2 x3 = {-1, 0, -1, 0}; static struct sb1i20c2 x4 = {-1, -1, -1, -1}; print_prologue("sb1i20c2", _Alignof(struct sb1i20c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i31b1i30i {
  int a:31;
  _Bool b:1;
  int c:30;
  int d;
};
static struct i31b1i30i x1 = {-1, 0, 0, 0}; static struct i31b1i30i x2 = {-1, -1, 0, 0}; static struct i31b1i30i x3 = {-1, 0, -1, 0}; static struct i31b1i30i x4 = {-1, -1, -1, -1}; print_prologue("i31b1i30i", _Alignof(struct i31b1i30i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5sB1si7 {
  int a:5;
  short b;
  _Bool :1;
  short c;
  int d:7;
};
static struct i5sB1si7 x1 = {-1, 0, 0, 0}; static struct i5sB1si7 x2 = {-1, -1, 0, 0}; static struct i5sB1si7 x3 = {-1, 0, -1, 0}; static struct i5sB1si7 x4 = {-1, -1, -1, -1}; print_prologue("i5sB1si7", _Alignof(struct i5sB1si7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1c2ii15 {
  _Bool a:1;
  char b:2;
  int c;
  int d:15;
};
static struct b1c2ii15 x1 = {-1, 0, 0, 0}; static struct b1c2ii15 x2 = {-1, -1, 0, 0}; static struct b1c2ii15 x3 = {-1, 0, -1, 0}; static struct b1c2ii15 x4 = {-1, -1, -1, -1}; print_prologue("b1c2ii15", _Alignof(struct b1c2ii15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct si24b1s3 {
  short a;
  int b:24;
  _Bool c:1;
  short d:3;
};
static struct si24b1s3 x1 = {-1, 0, 0, 0}; static struct si24b1s3 x2 = {-1, -1, 0, 0}; static struct si24b1s3 x3 = {-1, 0, -1, 0}; static struct si24b1s3 x4 = {-1, -1, -1, -1}; print_prologue("si24b1s3", _Alignof(struct si24b1s3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5isb1 {
  char a:5;
  int b;
  short c;
  _Bool d:1;
};
static struct c5isb1 x1 = {-1, 0, 0, 0}; static struct c5isb1 x2 = {-1, -1, 0, 0}; static struct c5isb1 x3 = {-1, 0, -1, 0}; static struct c5isb1 x4 = {-1, -1, -1, -1}; print_prologue("c5isb1", _Alignof(struct c5isb1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5i21i8c {
  char a:5;
  int b:21;
  int c:8;
  char d;
};
static struct c5i21i8c x1 = {-1, 0, 0, 0}; static struct c5i21i8c x2 = {-1, -1, 0, 0}; static struct c5i21i8c x3 = {-1, 0, -1, 0}; static struct c5i21i8c x4 = {-1, -1, -1, -1}; print_prologue("c5i21i8c", _Alignof(struct c5i21i8c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i1s8i29 {
  _Bool a:1;
  int b:1;
  short c:8;
  int d:29;
};
static struct b1i1s8i29 x1 = {-1, 0, 0, 0}; static struct b1i1s8i29 x2 = {-1, -1, 0, 0}; static struct b1i1s8i29 x3 = {-1, 0, -1, 0}; static struct b1i1s8i29 x4 = {-1, -1, -1, -1}; print_prologue("b1i1s8i29", _Alignof(struct b1i1s8i29), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i21c2s1i17 {
  int a:21;
  char b:2;
  short c:1;
  int d:17;
};
static struct i21c2s1i17 x1 = {-1, 0, 0, 0}; static struct i21c2s1i17 x2 = {-1, -1, 0, 0}; static struct i21c2s1i17 x3 = {-1, 0, -1, 0}; static struct i21c2s1i17 x4 = {-1, -1, -1, -1}; print_prologue("i21c2s1i17", _Alignof(struct i21c2s1i17), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1cs9c {
  char a:1;
  char b;
  short c:9;
  char d;
};
static struct c1cs9c x1 = {-1, 0, 0, 0}; static struct c1cs9c x2 = {-1, -1, 0, 0}; static struct c1cs9c x3 = {-1, 0, -1, 0}; static struct c1cs9c x4 = {-1, -1, -1, -1}; print_prologue("c1cs9c", _Alignof(struct c1cs9c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1ii2c {
  char a:1;
  int b;
  int c:2;
  char d;
};
static struct c1ii2c x1 = {-1, 0, 0, 0}; static struct c1ii2c x2 = {-1, -1, 0, 0}; static struct c1ii2c x3 = {-1, 0, -1, 0}; static struct c1ii2c x4 = {-1, -1, -1, -1}; print_prologue("c1ii2c", _Alignof(struct c1ii2c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct si15i19i1 {
  short a;
  int b:15;
  int c:19;
  int d:1;
};
static struct si15i19i1 x1 = {-1, 0, 0, 0}; static struct si15i19i1 x2 = {-1, -1, 0, 0}; static struct si15i19i1 x3 = {-1, 0, -1, 0}; static struct si15i19i1 x4 = {-1, -1, -1, -1}; print_prologue("si15i19i1", _Alignof(struct si15i19i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct B0b1ic3b1 {
  _Bool :0;
  _Bool a:1;
  int b;
  char c:3;
  _Bool d:1;
};
static struct B0b1ic3b1 x1 = {-1, 0, 0, 0}; static struct B0b1ic3b1 x2 = {-1, -1, 0, 0}; static struct B0b1ic3b1 x3 = {-1, 0, -1, 0}; static struct B0b1ic3b1 x4 = {-1, -1, -1, -1}; print_prologue("B0b1ic3b1", _Alignof(struct B0b1ic3b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i4i14c1i20 {
  int a:4;
  int b:14;
  char c:1;
  int d:20;
};
static struct i4i14c1i20 x1 = {-1, 0, 0, 0}; static struct i4i14c1i20 x2 = {-1, -1, 0, 0}; static struct i4i14c1i20 x3 = {-1, 0, -1, 0}; static struct i4i14c1i20 x4 = {-1, -1, -1, -1}; print_prologue("i4i14c1i20", _Alignof(struct i4i14c1i20), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7bc2s3 {
  int a:7;
  _Bool b;
  char c:2;
  short d:3;
};
static struct i7bc2s3 x1 = {-1, 0, 0, 0}; static struct i7bc2s3 x2 = {-1, -1, 0, 0}; static struct i7bc2s3 x3 = {-1, 0, -1, 0}; static struct i7bc2s3 x4 = {-1, -1, -1, -1}; print_prologue("i7bc2s3", _Alignof(struct i7bc2s3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i19I6is9c8 {
  int a:19;
  int :6;
  int b;
  short c:9;
  char d:8;
};
static struct i19I6is9c8 x1 = {-1, 0, 0, 0}; static struct i19I6is9c8 x2 = {-1, -1, 0, 0}; static struct i19I6is9c8 x3 = {-1, 0, -1, 0}; static struct i19I6is9c8 x4 = {-1, -1, -1, -1}; print_prologue("i19I6is9c8", _Alignof(struct i19I6is9c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1si4 {
  int a;
  _Bool b:1;
  short c;
  int d:4;
};
static struct ib1si4 x1 = {-1, 0, 0, 0}; static struct ib1si4 x2 = {-1, -1, 0, 0}; static struct ib1si4 x3 = {-1, 0, -1, 0}; static struct ib1si4 x4 = {-1, -1, -1, -1}; print_prologue("ib1si4", _Alignof(struct ib1si4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bi5bi16 {
  _Bool a;
  int b:5;
  _Bool c;
  int d:16;
};
static struct bi5bi16 x1 = {-1, 0, 0, 0}; static struct bi5bi16 x2 = {-1, -1, 0, 0}; static struct bi5bi16 x3 = {-1, 0, -1, 0}; static struct bi5bi16 x4 = {-1, -1, -1, -1}; print_prologue("bi5bi16", _Alignof(struct bi5bi16), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C4c1i4ci {
  char :4;
  char a:1;
  int b:4;
  char c;
  int d;
};
static struct C4c1i4ci x1 = {-1, 0, 0, 0}; static struct C4c1i4ci x2 = {-1, -1, 0, 0}; static struct C4c1i4ci x3 = {-1, 0, -1, 0}; static struct C4c1i4ci x4 = {-1, -1, -1, -1}; print_prologue("C4c1i4ci", _Alignof(struct C4c1i4ci), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3b1si5 {
  char a:3;
  _Bool b:1;
  short c;
  int d:5;
};
static struct c3b1si5 x1 = {-1, 0, 0, 0}; static struct c3b1si5 x2 = {-1, -1, 0, 0}; static struct c3b1si5 x3 = {-1, 0, -1, 0}; static struct c3b1si5 x4 = {-1, -1, -1, -1}; print_prologue("c3b1si5", _Alignof(struct c3b1si5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i9c4I5iB0i11 {
  int a:9;
  char b:4;
  int :5;
  int c;
  _Bool :0;
  int d:11;
};
static struct i9c4I5iB0i11 x1 = {-1, 0, 0, 0}; static struct i9c4I5iB0i11 x2 = {-1, -1, 0, 0}; static struct i9c4I5iB0i11 x3 = {-1, 0, -1, 0}; static struct i9c4I5iB0i11 x4 = {-1, -1, -1, -1}; print_prologue("i9c4I5iB0i11", _Alignof(struct i9c4I5iB0i11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bisi1 {
  _Bool a;
  int b;
  short c;
  int d:1;
};
static struct bisi1 x1 = {-1, 0, 0, 0}; static struct bisi1 x2 = {-1, -1, 0, 0}; static struct bisi1 x3 = {-1, 0, -1, 0}; static struct bisi1 x4 = {-1, -1, -1, -1}; print_prologue("bisi1", _Alignof(struct bisi1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i30i13i28s2 {
  int a:30;
  int b:13;
  int c:28;
  short d:2;
};
static struct i30i13i28s2 x1 = {-1, 0, 0, 0}; static struct i30i13i28s2 x2 = {-1, -1, 0, 0}; static struct i30i13i28s2 x3 = {-1, 0, -1, 0}; static struct i30i13i28s2 x4 = {-1, -1, -1, -1}; print_prologue("i30i13i28s2", _Alignof(struct i30i13i28s2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1c2c2c4 {
  _Bool a:1;
  char b:2;
  char c:2;
  char d:4;
};
static struct b1c2c2c4 x1 = {-1, 0, 0, 0}; static struct b1c2c2c4 x2 = {-1, -1, 0, 0}; static struct b1c2c2c4 x3 = {-1, 0, -1, 0}; static struct b1c2c2c4 x4 = {-1, -1, -1, -1}; print_prologue("b1c2c2c4", _Alignof(struct b1c2c2c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii2s14c3 {
  int a;
  int b:2;
  short c:14;
  char d:3;
};
static struct ii2s14c3 x1 = {-1, 0, 0, 0}; static struct ii2s14c3 x2 = {-1, -1, 0, 0}; static struct ii2s14c3 x3 = {-1, 0, -1, 0}; static struct ii2s14c3 x4 = {-1, -1, -1, -1}; print_prologue("ii2s14c3", _Alignof(struct ii2s14c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I5s2i2sc4 {
  int :5;
  short a:2;
  int b:2;
  short c;
  char d:4;
};
static struct I5s2i2sc4 x1 = {-1, 0, 0, 0}; static struct I5s2i2sc4 x2 = {-1, -1, 0, 0}; static struct I5s2i2sc4 x3 = {-1, 0, -1, 0}; static struct I5s2i2sc4 x4 = {-1, -1, -1, -1}; print_prologue("I5s2i2sc4", _Alignof(struct I5s2i2sc4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i28sii14 {
  int a:28;
  short b;
  int c;
  int d:14;
};
static struct i28sii14 x1 = {-1, 0, 0, 0}; static struct i28sii14 x2 = {-1, -1, 0, 0}; static struct i28sii14 x3 = {-1, 0, -1, 0}; static struct i28sii14 x4 = {-1, -1, -1, -1}; print_prologue("i28sii14", _Alignof(struct i28sii14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i23B1c7i7i11 {
  int a:23;
  _Bool :1;
  char b:7;
  int c:7;
  int d:11;
};
static struct i23B1c7i7i11 x1 = {-1, 0, 0, 0}; static struct i23B1c7i7i11 x2 = {-1, -1, 0, 0}; static struct i23B1c7i7i11 x3 = {-1, 0, -1, 0}; static struct i23B1c7i7i11 x4 = {-1, -1, -1, -1}; print_prologue("i23B1c7i7i11", _Alignof(struct i23B1c7i7i11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i4ib1s4 {
  int a:4;
  int b;
  _Bool c:1;
  short d:4;
};
static struct i4ib1s4 x1 = {-1, 0, 0, 0}; static struct i4ib1s4 x2 = {-1, -1, 0, 0}; static struct i4ib1s4 x3 = {-1, 0, -1, 0}; static struct i4ib1s4 x4 = {-1, -1, -1, -1}; print_prologue("i4ib1s4", _Alignof(struct i4ib1s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i30s12s13s {
  int a:30;
  short b:12;
  short c:13;
  short d;
};
static struct i30s12s13s x1 = {-1, 0, 0, 0}; static struct i30s12s13s x2 = {-1, -1, 0, 0}; static struct i30s12s13s x3 = {-1, 0, -1, 0}; static struct i30s12s13s x4 = {-1, -1, -1, -1}; print_prologue("i30s12s13s", _Alignof(struct i30s12s13s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s15s2si9 {
  short a:15;
  short b:2;
  short c;
  int d:9;
};
static struct s15s2si9 x1 = {-1, 0, 0, 0}; static struct s15s2si9 x2 = {-1, -1, 0, 0}; static struct s15s2si9 x3 = {-1, 0, -1, 0}; static struct s15s2si9 x4 = {-1, -1, -1, -1}; print_prologue("s15s2si9", _Alignof(struct s15s2si9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7sc7i2 {
  int a:7;
  short b;
  char c:7;
  int d:2;
};
static struct i7sc7i2 x1 = {-1, 0, 0, 0}; static struct i7sc7i2 x2 = {-1, -1, 0, 0}; static struct i7sc7i2 x3 = {-1, 0, -1, 0}; static struct i7sc7i2 x4 = {-1, -1, -1, -1}; print_prologue("i7sc7i2", _Alignof(struct i7sc7i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2b1I0i11i5 {
  int a:2;
  _Bool b:1;
  int :0;
  int c:11;
  int d:5;
};
static struct i2b1I0i11i5 x1 = {-1, 0, 0, 0}; static struct i2b1I0i11i5 x2 = {-1, -1, 0, 0}; static struct i2b1I0i11i5 x3 = {-1, 0, -1, 0}; static struct i2b1I0i11i5 x4 = {-1, -1, -1, -1}; print_prologue("i2b1I0i11i5", _Alignof(struct i2b1I0i11i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s10s14i14 {
  int a:2;
  short b:10;
  short c:14;
  int d:14;
};
static struct i2s10s14i14 x1 = {-1, 0, 0, 0}; static struct i2s10s14i14 x2 = {-1, -1, 0, 0}; static struct i2s10s14i14 x3 = {-1, 0, -1, 0}; static struct i2s10s14i14 x4 = {-1, -1, -1, -1}; print_prologue("i2s10s14i14", _Alignof(struct i2s10s14i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1c7b1s8 {
  char a:1;
  char b:7;
  _Bool c:1;
  short d:8;
};
static struct c1c7b1s8 x1 = {-1, 0, 0, 0}; static struct c1c7b1s8 x2 = {-1, -1, 0, 0}; static struct c1c7b1s8 x3 = {-1, 0, -1, 0}; static struct c1c7b1s8 x4 = {-1, -1, -1, -1}; print_prologue("c1c7b1s8", _Alignof(struct c1c7b1s8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s3c4c2i {
  short a:3;
  char b:4;
  char c:2;
  int d;
};
static struct s3c4c2i x1 = {-1, 0, 0, 0}; static struct s3c4c2i x2 = {-1, -1, 0, 0}; static struct s3c4c2i x3 = {-1, 0, -1, 0}; static struct s3c4c2i x4 = {-1, -1, -1, -1}; print_prologue("s3c4c2i", _Alignof(struct s3c4c2i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i14c2c7s1 {
  int a:14;
  char b:2;
  char c:7;
  short d:1;
};
static struct i14c2c7s1 x1 = {-1, 0, 0, 0}; static struct i14c2c7s1 x2 = {-1, -1, 0, 0}; static struct i14c2c7s1 x3 = {-1, 0, -1, 0}; static struct i14c2c7s1 x4 = {-1, -1, -1, -1}; print_prologue("i14c2c7s1", _Alignof(struct i14c2c7s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s8s3si11 {
  short a:8;
  short b:3;
  short c;
  int d:11;
};
static struct s8s3si11 x1 = {-1, 0, 0, 0}; static struct s8s3si11 x2 = {-1, -1, 0, 0}; static struct s8s3si11 x3 = {-1, 0, -1, 0}; static struct s8s3si11 x4 = {-1, -1, -1, -1}; print_prologue("s8s3si11", _Alignof(struct s8s3si11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1b1si3 {
  char a:1;
  _Bool b:1;
  short c;
  int d:3;
};
static struct c1b1si3 x1 = {-1, 0, 0, 0}; static struct c1b1si3 x2 = {-1, -1, 0, 0}; static struct c1b1si3 x3 = {-1, 0, -1, 0}; static struct c1b1si3 x4 = {-1, -1, -1, -1}; print_prologue("c1b1si3", _Alignof(struct c1b1si3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8B1i4i2i31 {
  char a:8;
  _Bool :1;
  int b:4;
  int c:2;
  int d:31;
};
static struct c8B1i4i2i31 x1 = {-1, 0, 0, 0}; static struct c8B1i4i2i31 x2 = {-1, -1, 0, 0}; static struct c8B1i4i2i31 x3 = {-1, 0, -1, 0}; static struct c8B1i4i2i31 x4 = {-1, -1, -1, -1}; print_prologue("c8B1i4i2i31", _Alignof(struct c8B1i4i2i31), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s10c4s9b1 {
  short a:10;
  char b:4;
  short c:9;
  _Bool d:1;
};
static struct s10c4s9b1 x1 = {-1, 0, 0, 0}; static struct s10c4s9b1 x2 = {-1, -1, 0, 0}; static struct s10c4s9b1 x3 = {-1, 0, -1, 0}; static struct s10c4s9b1 x4 = {-1, -1, -1, -1}; print_prologue("s10c4s9b1", _Alignof(struct s10c4s9b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i28c4i20i8 {
  int a:28;
  char b:4;
  int c:20;
  int d:8;
};
static struct i28c4i20i8 x1 = {-1, 0, 0, 0}; static struct i28c4i20i8 x2 = {-1, -1, 0, 0}; static struct i28c4i20i8 x3 = {-1, 0, -1, 0}; static struct i28c4i20i8 x4 = {-1, -1, -1, -1}; print_prologue("i28c4i20i8", _Alignof(struct i28c4i20i8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1i22i4i3 {
  char a:1;
  int b:22;
  int c:4;
  int d:3;
};
static struct c1i22i4i3 x1 = {-1, 0, 0, 0}; static struct c1i22i4i3 x2 = {-1, -1, 0, 0}; static struct c1i22i4i3 x3 = {-1, 0, -1, 0}; static struct c1i22i4i3 x4 = {-1, -1, -1, -1}; print_prologue("c1i22i4i3", _Alignof(struct c1i22i4i3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cs4i10i2 {
  char a;
  short b:4;
  int c:10;
  int d:2;
};
static struct cs4i10i2 x1 = {-1, 0, 0, 0}; static struct cs4i10i2 x2 = {-1, -1, 0, 0}; static struct cs4i10i2 x3 = {-1, 0, -1, 0}; static struct cs4i10i2 x4 = {-1, -1, -1, -1}; print_prologue("cs4i10i2", _Alignof(struct cs4i10i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ci16i16i2 {
  char a;
  int b:16;
  int c:16;
  int d:2;
};
static struct ci16i16i2 x1 = {-1, 0, 0, 0}; static struct ci16i16i2 x2 = {-1, -1, 0, 0}; static struct ci16i16i2 x3 = {-1, 0, -1, 0}; static struct ci16i16i2 x4 = {-1, -1, -1, -1}; print_prologue("ci16i16i2", _Alignof(struct ci16i16i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ci12i1s16 {
  char a;
  int b:12;
  int c:1;
  short d:16;
};
static struct ci12i1s16 x1 = {-1, 0, 0, 0}; static struct ci12i1s16 x2 = {-1, -1, 0, 0}; static struct ci12i1s16 x3 = {-1, 0, -1, 0}; static struct ci12i1s16 x4 = {-1, -1, -1, -1}; print_prologue("ci12i1s16", _Alignof(struct ci12i1s16), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i19b1i14i {
  int a:19;
  _Bool b:1;
  int c:14;
  int d;
};
static struct i19b1i14i x1 = {-1, 0, 0, 0}; static struct i19b1i14i x2 = {-1, -1, 0, 0}; static struct i19b1i14i x3 = {-1, 0, -1, 0}; static struct i19b1i14i x4 = {-1, -1, -1, -1}; print_prologue("i19b1i14i", _Alignof(struct i19b1i14i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii17i4i3 {
  int a;
  int b:17;
  int c:4;
  int d:3;
};
static struct ii17i4i3 x1 = {-1, 0, 0, 0}; static struct ii17i4i3 x2 = {-1, -1, 0, 0}; static struct ii17i4i3 x3 = {-1, 0, -1, 0}; static struct ii17i4i3 x4 = {-1, -1, -1, -1}; print_prologue("ii17i4i3", _Alignof(struct ii17i4i3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i15c2s3b {
  int a:15;
  char b:2;
  short c:3;
  _Bool d;
};
static struct i15c2s3b x1 = {-1, 0, 0, 0}; static struct i15c2s3b x2 = {-1, -1, 0, 0}; static struct i15c2s3b x3 = {-1, 0, -1, 0}; static struct i15c2s3b x4 = {-1, -1, -1, -1}; print_prologue("i15c2s3b", _Alignof(struct i15c2s3b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii16ic {
  int a;
  int b:16;
  int c;
  char d;
};
static struct ii16ic x1 = {-1, 0, 0, 0}; static struct ii16ic x2 = {-1, -1, 0, 0}; static struct ii16ic x3 = {-1, 0, -1, 0}; static struct ii16ic x4 = {-1, -1, -1, -1}; print_prologue("ii16ic", _Alignof(struct ii16ic), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s7i30c7i28 {
  short a:7;
  int b:30;
  char c:7;
  int d:28;
};
static struct s7i30c7i28 x1 = {-1, 0, 0, 0}; static struct s7i30c7i28 x2 = {-1, -1, 0, 0}; static struct s7i30c7i28 x3 = {-1, 0, -1, 0}; static struct s7i30c7i28 x4 = {-1, -1, -1, -1}; print_prologue("s7i30c7i28", _Alignof(struct s7i30c7i28), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i19ic2b {
  int a:19;
  int b;
  char c:2;
  _Bool d;
};
static struct i19ic2b x1 = {-1, 0, 0, 0}; static struct i19ic2b x2 = {-1, -1, 0, 0}; static struct i19ic2b x3 = {-1, 0, -1, 0}; static struct i19ic2b x4 = {-1, -1, -1, -1}; print_prologue("i19ic2b", _Alignof(struct i19ic2b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2c8ci1 {
  char a:2;
  char b:8;
  char c;
  int d:1;
};
static struct c2c8ci1 x1 = {-1, 0, 0, 0}; static struct c2c8ci1 x2 = {-1, -1, 0, 0}; static struct c2c8ci1 x3 = {-1, 0, -1, 0}; static struct c2c8ci1 x4 = {-1, -1, -1, -1}; print_prologue("c2c8ci1", _Alignof(struct c2c8ci1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct si23i5c2 {
  short a;
  int b:23;
  int c:5;
  char d:2;
};
static struct si23i5c2 x1 = {-1, 0, 0, 0}; static struct si23i5c2 x2 = {-1, -1, 0, 0}; static struct si23i5c2 x3 = {-1, 0, -1, 0}; static struct si23i5c2 x4 = {-1, -1, -1, -1}; print_prologue("si23i5c2", _Alignof(struct si23i5c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1I3cii {
  _Bool a:1;
  int :3;
  char b;
  int c;
  int d;
};
static struct b1I3cii x1 = {-1, 0, 0, 0}; static struct b1I3cii x2 = {-1, -1, 0, 0}; static struct b1I3cii x3 = {-1, 0, -1, 0}; static struct b1I3cii x4 = {-1, -1, -1, -1}; print_prologue("b1I3cii", _Alignof(struct b1I3cii), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1cc1s {
  _Bool a:1;
  char b;
  char c:1;
  short d;
};
static struct b1cc1s x1 = {-1, 0, 0, 0}; static struct b1cc1s x2 = {-1, -1, 0, 0}; static struct b1cc1s x3 = {-1, 0, -1, 0}; static struct b1cc1s x4 = {-1, -1, -1, -1}; print_prologue("b1cc1s", _Alignof(struct b1cc1s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i4bcs4 {
  int a:4;
  _Bool b;
  char c;
  short d:4;
};
static struct i4bcs4 x1 = {-1, 0, 0, 0}; static struct i4bcs4 x2 = {-1, -1, 0, 0}; static struct i4bcs4 x3 = {-1, 0, -1, 0}; static struct i4bcs4 x4 = {-1, -1, -1, -1}; print_prologue("i4bcs4", _Alignof(struct i4bcs4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2b1i17s {
  short a:2;
  _Bool b:1;
  int c:17;
  short d;
};
static struct s2b1i17s x1 = {-1, 0, 0, 0}; static struct s2b1i17s x2 = {-1, -1, 0, 0}; static struct s2b1i17s x3 = {-1, 0, -1, 0}; static struct s2b1i17s x4 = {-1, -1, -1, -1}; print_prologue("s2b1i17s", _Alignof(struct s2b1i17s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bi12i27s10 {
  _Bool a;
  int b:12;
  int c:27;
  short d:10;
};
static struct bi12i27s10 x1 = {-1, 0, 0, 0}; static struct bi12i27s10 x2 = {-1, -1, 0, 0}; static struct bi12i27s10 x3 = {-1, 0, -1, 0}; static struct bi12i27s10 x4 = {-1, -1, -1, -1}; print_prologue("bi12i27s10", _Alignof(struct bi12i27s10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s16s2b1i26 {
  short a:16;
  short b:2;
  _Bool c:1;
  int d:26;
};
static struct s16s2b1i26 x1 = {-1, 0, 0, 0}; static struct s16s2b1i26 x2 = {-1, -1, 0, 0}; static struct s16s2b1i26 x3 = {-1, 0, -1, 0}; static struct s16s2b1i26 x4 = {-1, -1, -1, -1}; print_prologue("s16s2b1i26", _Alignof(struct s16s2b1i26), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1i6s7c2 {
  int a:1;
  int b:6;
  short c:7;
  char d:2;
};
static struct i1i6s7c2 x1 = {-1, 0, 0, 0}; static struct i1i6s7c2 x2 = {-1, -1, 0, 0}; static struct i1i6s7c2 x3 = {-1, 0, -1, 0}; static struct i1i6s7c2 x4 = {-1, -1, -1, -1}; print_prologue("i1i6s7c2", _Alignof(struct i1i6s7c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2c3c4i {
  char a:2;
  char b:3;
  char c:4;
  int d;
};
static struct c2c3c4i x1 = {-1, 0, 0, 0}; static struct c2c3c4i x2 = {-1, -1, 0, 0}; static struct c2c3c4i x3 = {-1, 0, -1, 0}; static struct c2c3c4i x4 = {-1, -1, -1, -1}; print_prologue("c2c3c4i", _Alignof(struct c2c3c4i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i13ssi15 {
  int a:13;
  short b;
  short c;
  int d:15;
};
static struct i13ssi15 x1 = {-1, 0, 0, 0}; static struct i13ssi15 x2 = {-1, -1, 0, 0}; static struct i13ssi15 x3 = {-1, 0, -1, 0}; static struct i13ssi15 x4 = {-1, -1, -1, -1}; print_prologue("i13ssi15", _Alignof(struct i13ssi15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2b1ii4 {
  short a:2;
  _Bool b:1;
  int c;
  int d:4;
};
static struct s2b1ii4 x1 = {-1, 0, 0, 0}; static struct s2b1ii4 x2 = {-1, -1, 0, 0}; static struct s2b1ii4 x3 = {-1, 0, -1, 0}; static struct s2b1ii4 x4 = {-1, -1, -1, -1}; print_prologue("s2b1ii4", _Alignof(struct s2b1ii4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s6sss8 {
  short a:6;
  short b;
  short c;
  short d:8;
};
static struct s6sss8 x1 = {-1, 0, 0, 0}; static struct s6sss8 x2 = {-1, -1, 0, 0}; static struct s6sss8 x3 = {-1, 0, -1, 0}; static struct s6sss8 x4 = {-1, -1, -1, -1}; print_prologue("s6sss8", _Alignof(struct s6sss8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i12I0s2c7 {
  _Bool a:1;
  int b:12;
  int :0;
  short c:2;
  char d:7;
};
static struct b1i12I0s2c7 x1 = {-1, 0, 0, 0}; static struct b1i12I0s2c7 x2 = {-1, -1, 0, 0}; static struct b1i12I0s2c7 x3 = {-1, 0, -1, 0}; static struct b1i12I0s2c7 x4 = {-1, -1, -1, -1}; print_prologue("b1i12I0s2c7", _Alignof(struct b1i12I0s2c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1cc1b1 {
  _Bool a:1;
  char b;
  char c:1;
  _Bool d:1;
};
static struct b1cc1b1 x1 = {-1, 0, 0, 0}; static struct b1cc1b1 x2 = {-1, -1, 0, 0}; static struct b1cc1b1 x3 = {-1, 0, -1, 0}; static struct b1cc1b1 x4 = {-1, -1, -1, -1}; print_prologue("b1cc1b1", _Alignof(struct b1cc1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1sii31 {
  char a:1;
  short b;
  int c;
  int d:31;
};
static struct c1sii31 x1 = {-1, 0, 0, 0}; static struct c1sii31 x2 = {-1, -1, 0, 0}; static struct c1sii31 x3 = {-1, 0, -1, 0}; static struct c1sii31 x4 = {-1, -1, -1, -1}; print_prologue("c1sii31", _Alignof(struct c1sii31), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cc1s6i23 {
  char a;
  char b:1;
  short c:6;
  int d:23;
};
static struct cc1s6i23 x1 = {-1, 0, 0, 0}; static struct cc1s6i23 x2 = {-1, -1, 0, 0}; static struct cc1s6i23 x3 = {-1, 0, -1, 0}; static struct cc1s6i23 x4 = {-1, -1, -1, -1}; print_prologue("cc1s6i23", _Alignof(struct cc1s6i23), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s9s10b1i7 {
  short a:9;
  short b:10;
  _Bool c:1;
  int d:7;
};
static struct s9s10b1i7 x1 = {-1, 0, 0, 0}; static struct s9s10b1i7 x2 = {-1, -1, 0, 0}; static struct s9s10b1i7 x3 = {-1, 0, -1, 0}; static struct s9s10b1i7 x4 = {-1, -1, -1, -1}; print_prologue("s9s10b1i7", _Alignof(struct s9s10b1i7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5i5i9c8 {
  char a:5;
  int b:5;
  int c:9;
  char d:8;
};
static struct c5i5i9c8 x1 = {-1, 0, 0, 0}; static struct c5i5i9c8 x2 = {-1, -1, 0, 0}; static struct c5i5i9c8 x3 = {-1, 0, -1, 0}; static struct c5i5i9c8 x4 = {-1, -1, -1, -1}; print_prologue("c5i5i9c8", _Alignof(struct c5i5i9c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7i4i4i14 {
  int a:7;
  int b:4;
  int c:4;
  int d:14;
};
static struct i7i4i4i14 x1 = {-1, 0, 0, 0}; static struct i7i4i4i14 x2 = {-1, -1, 0, 0}; static struct i7i4i4i14 x3 = {-1, 0, -1, 0}; static struct i7i4i4i14 x4 = {-1, -1, -1, -1}; print_prologue("i7i4i4i14", _Alignof(struct i7i4i4i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8i1S0s6i29 {
  char a:8;
  int b:1;
  short :0;
  short c:6;
  int d:29;
};
static struct c8i1S0s6i29 x1 = {-1, 0, 0, 0}; static struct c8i1S0s6i29 x2 = {-1, -1, 0, 0}; static struct c8i1S0s6i29 x3 = {-1, 0, -1, 0}; static struct c8i1S0s6i29 x4 = {-1, -1, -1, -1}; print_prologue("c8i1S0s6i29", _Alignof(struct c8i1S0s6i29), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s13is16s8 {
  short a:13;
  int b;
  short c:16;
  short d:8;
};
static struct s13is16s8 x1 = {-1, 0, 0, 0}; static struct s13is16s8 x2 = {-1, -1, 0, 0}; static struct s13is16s8 x3 = {-1, 0, -1, 0}; static struct s13is16s8 x4 = {-1, -1, -1, -1}; print_prologue("s13is16s8", _Alignof(struct s13is16s8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i30c1cb1 {
  int a:30;
  char b:1;
  char c;
  _Bool d:1;
};
static struct i30c1cb1 x1 = {-1, 0, 0, 0}; static struct i30c1cb1 x2 = {-1, -1, 0, 0}; static struct i30c1cb1 x3 = {-1, 0, -1, 0}; static struct i30c1cb1 x4 = {-1, -1, -1, -1}; print_prologue("i30c1cb1", _Alignof(struct i30c1cb1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bb1s1i3 {
  _Bool a;
  _Bool b:1;
  short c:1;
  int d:3;
};
static struct bb1s1i3 x1 = {-1, 0, 0, 0}; static struct bb1s1i3 x2 = {-1, -1, 0, 0}; static struct bb1s1i3 x3 = {-1, 0, -1, 0}; static struct bb1s1i3 x4 = {-1, -1, -1, -1}; print_prologue("bb1s1i3", _Alignof(struct bb1s1i3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7ii2s4 {
  int a:7;
  int b;
  int c:2;
  short d:4;
};
static struct i7ii2s4 x1 = {-1, 0, 0, 0}; static struct i7ii2s4 x2 = {-1, -1, 0, 0}; static struct i7ii2s4 x3 = {-1, 0, -1, 0}; static struct i7ii2s4 x4 = {-1, -1, -1, -1}; print_prologue("i7ii2s4", _Alignof(struct i7ii2s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2cc3b {
  int a:2;
  char b;
  char c:3;
  _Bool d;
};
static struct i2cc3b x1 = {-1, 0, 0, 0}; static struct i2cc3b x2 = {-1, -1, 0, 0}; static struct i2cc3b x3 = {-1, 0, -1, 0}; static struct i2cc3b x4 = {-1, -1, -1, -1}; print_prologue("i2cc3b", _Alignof(struct i2cc3b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1s7i11b1 {
  _Bool a:1;
  short b:7;
  int c:11;
  _Bool d:1;
};
static struct b1s7i11b1 x1 = {-1, 0, 0, 0}; static struct b1s7i11b1 x2 = {-1, -1, 0, 0}; static struct b1s7i11b1 x3 = {-1, 0, -1, 0}; static struct b1s7i11b1 x4 = {-1, -1, -1, -1}; print_prologue("b1s7i11b1", _Alignof(struct b1s7i11b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s3s6i5i15 {
  short a:3;
  short b:6;
  int c:5;
  int d:15;
};
static struct s3s6i5i15 x1 = {-1, 0, 0, 0}; static struct s3s6i5i15 x2 = {-1, -1, 0, 0}; static struct s3s6i5i15 x3 = {-1, 0, -1, 0}; static struct s3s6i5i15 x4 = {-1, -1, -1, -1}; print_prologue("s3s6i5i15", _Alignof(struct s3s6i5i15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s3s3s2c {
  short a:3;
  short b:3;
  short c:2;
  char d;
};
static struct s3s3s2c x1 = {-1, 0, 0, 0}; static struct s3s3s2c x2 = {-1, -1, 0, 0}; static struct s3s3s2c x3 = {-1, 0, -1, 0}; static struct s3s3s2c x4 = {-1, -1, -1, -1}; print_prologue("s3s3s2c", _Alignof(struct s3s3s2c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1ii3c4 {
  int a:1;
  int b;
  int c:3;
  char d:4;
};
static struct i1ii3c4 x1 = {-1, 0, 0, 0}; static struct i1ii3c4 x2 = {-1, -1, 0, 0}; static struct i1ii3c4 x3 = {-1, 0, -1, 0}; static struct i1ii3c4 x4 = {-1, -1, -1, -1}; print_prologue("i1ii3c4", _Alignof(struct i1ii3c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s5i23i5 {
  int a:2;
  short b:5;
  int c:23;
  int d:5;
};
static struct i2s5i23i5 x1 = {-1, 0, 0, 0}; static struct i2s5i23i5 x2 = {-1, -1, 0, 0}; static struct i2s5i23i5 x3 = {-1, 0, -1, 0}; static struct i2s5i23i5 x4 = {-1, -1, -1, -1}; print_prologue("i2s5i23i5", _Alignof(struct i2s5i23i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5I0s4i4i21 {
  char a:5;
  int :0;
  short b:4;
  int c:4;
  int d:21;
};
static struct c5I0s4i4i21 x1 = {-1, 0, 0, 0}; static struct c5I0s4i4i21 x2 = {-1, -1, 0, 0}; static struct c5I0s4i4i21 x3 = {-1, 0, -1, 0}; static struct c5I0s4i4i21 x4 = {-1, -1, -1, -1}; print_prologue("c5I0s4i4i21", _Alignof(struct c5I0s4i4i21), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4bc2I5b1 {
  char a:4;
  _Bool b;
  char c:2;
  int :5;
  _Bool d:1;
};
static struct c4bc2I5b1 x1 = {-1, 0, 0, 0}; static struct c4bc2I5b1 x2 = {-1, -1, 0, 0}; static struct c4bc2I5b1 x3 = {-1, 0, -1, 0}; static struct c4bc2I5b1 x4 = {-1, -1, -1, -1}; print_prologue("c4bc2I5b1", _Alignof(struct c4bc2I5b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1s10c1i10 {
  short a:1;
  short b:10;
  char c:1;
  int d:10;
};
static struct s1s10c1i10 x1 = {-1, 0, 0, 0}; static struct s1s10c1i10 x2 = {-1, -1, 0, 0}; static struct s1s10c1i10 x3 = {-1, 0, -1, 0}; static struct s1s10c1i10 x4 = {-1, -1, -1, -1}; print_prologue("s1s10c1i10", _Alignof(struct s1s10c1i10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i21s3B1c7c {
  int a:21;
  short b:3;
  _Bool :1;
  char c:7;
  char d;
};
static struct i21s3B1c7c x1 = {-1, 0, 0, 0}; static struct i21s3B1c7c x2 = {-1, -1, 0, 0}; static struct i21s3B1c7c x3 = {-1, 0, -1, 0}; static struct i21s3B1c7c x4 = {-1, -1, -1, -1}; print_prologue("i21s3B1c7c", _Alignof(struct i21s3B1c7c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s9i11cC4i9 {
  short a:9;
  int b:11;
  char c;
  char :4;
  int d:9;
};
static struct s9i11cC4i9 x1 = {-1, 0, 0, 0}; static struct s9i11cC4i9 x2 = {-1, -1, 0, 0}; static struct s9i11cC4i9 x3 = {-1, 0, -1, 0}; static struct s9i11cC4i9 x4 = {-1, -1, -1, -1}; print_prologue("s9i11cC4i9", _Alignof(struct s9i11cC4i9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1i2ii4 {
  char a:1;
  int b:2;
  int c;
  int d:4;
};
static struct c1i2ii4 x1 = {-1, 0, 0, 0}; static struct c1i2ii4 x2 = {-1, -1, 0, 0}; static struct c1i2ii4 x3 = {-1, 0, -1, 0}; static struct c1i2ii4 x4 = {-1, -1, -1, -1}; print_prologue("c1i2ii4", _Alignof(struct c1i2ii4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C1i10i32ic2 {
  char :1;
  int a:10;
  int b:32;
  int c;
  char d:2;
};
static struct C1i10i32ic2 x1 = {-1, 0, 0, 0}; static struct C1i10i32ic2 x2 = {-1, -1, 0, 0}; static struct C1i10i32ic2 x3 = {-1, 0, -1, 0}; static struct C1i10i32ic2 x4 = {-1, -1, -1, -1}; print_prologue("C1i10i32ic2", _Alignof(struct C1i10i32ic2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s7s4bs3 {
  short a:7;
  short b:4;
  _Bool c;
  short d:3;
};
static struct s7s4bs3 x1 = {-1, 0, 0, 0}; static struct s7s4bs3 x2 = {-1, -1, 0, 0}; static struct s7s4bs3 x3 = {-1, 0, -1, 0}; static struct s7s4bs3 x4 = {-1, -1, -1, -1}; print_prologue("s7s4bs3", _Alignof(struct s7s4bs3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ci32sc {
  char a;
  int b:32;
  short c;
  char d;
};
static struct ci32sc x1 = {-1, 0, 0, 0}; static struct ci32sc x2 = {-1, -1, 0, 0}; static struct ci32sc x3 = {-1, 0, -1, 0}; static struct ci32sc x4 = {-1, -1, -1, -1}; print_prologue("ci32sc", _Alignof(struct ci32sc), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i5s15i1 {
  _Bool a:1;
  int b:5;
  short c:15;
  int d:1;
};
static struct b1i5s15i1 x1 = {-1, 0, 0, 0}; static struct b1i5s15i1 x2 = {-1, -1, 0, 0}; static struct b1i5s15i1 x3 = {-1, 0, -1, 0}; static struct b1i5s15i1 x4 = {-1, -1, -1, -1}; print_prologue("b1i5s15i1", _Alignof(struct b1i5s15i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s15s8s12 {
  int a:2;
  short b:15;
  short c:8;
  short d:12;
};
static struct i2s15s8s12 x1 = {-1, 0, 0, 0}; static struct i2s15s8s12 x2 = {-1, -1, 0, 0}; static struct i2s15s8s12 x3 = {-1, 0, -1, 0}; static struct i2s15s8s12 x4 = {-1, -1, -1, -1}; print_prologue("i2s15s8s12", _Alignof(struct i2s15s8s12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S4i3i1b1s {
  short :4;
  int a:3;
  int b:1;
  _Bool c:1;
  short d;
};
static struct S4i3i1b1s x1 = {-1, 0, 0, 0}; static struct S4i3i1b1s x2 = {-1, -1, 0, 0}; static struct S4i3i1b1s x3 = {-1, 0, -1, 0}; static struct S4i3i1b1s x4 = {-1, -1, -1, -1}; print_prologue("S4i3i1b1s", _Alignof(struct S4i3i1b1s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3i1s3i22 {
  char a:3;
  int b:1;
  short c:3;
  int d:22;
};
static struct c3i1s3i22 x1 = {-1, 0, 0, 0}; static struct c3i1s3i22 x2 = {-1, -1, 0, 0}; static struct c3i1s3i22 x3 = {-1, 0, -1, 0}; static struct c3i1s3i22 x4 = {-1, -1, -1, -1}; print_prologue("c3i1s3i22", _Alignof(struct c3i1s3i22), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i15s5c2i2 {
  int a:15;
  short b:5;
  char c:2;
  int d:2;
};
static struct i15s5c2i2 x1 = {-1, 0, 0, 0}; static struct i15s5c2i2 x2 = {-1, -1, 0, 0}; static struct i15s5c2i2 x3 = {-1, 0, -1, 0}; static struct i15s5c2i2 x4 = {-1, -1, -1, -1}; print_prologue("i15s5c2i2", _Alignof(struct i15s5c2i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i31cc6 {
  _Bool a:1;
  int b:31;
  char c;
  char d:6;
};
static struct b1i31cc6 x1 = {-1, 0, 0, 0}; static struct b1i31cc6 x2 = {-1, -1, 0, 0}; static struct b1i31cc6 x3 = {-1, 0, -1, 0}; static struct b1i31cc6 x4 = {-1, -1, -1, -1}; print_prologue("b1i31cc6", _Alignof(struct b1i31cc6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s8ii17I1i8 {
  short a:8;
  int b;
  int c:17;
  int :1;
  int d:8;
};
static struct s8ii17I1i8 x1 = {-1, 0, 0, 0}; static struct s8ii17I1i8 x2 = {-1, -1, 0, 0}; static struct s8ii17I1i8 x3 = {-1, 0, -1, 0}; static struct s8ii17I1i8 x4 = {-1, -1, -1, -1}; print_prologue("s8ii17I1i8", _Alignof(struct s8ii17I1i8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2ci2b1 {
  char a:2;
  char b;
  int c:2;
  _Bool d:1;
};
static struct c2ci2b1 x1 = {-1, 0, 0, 0}; static struct c2ci2b1 x2 = {-1, -1, 0, 0}; static struct c2ci2b1 x3 = {-1, 0, -1, 0}; static struct c2ci2b1 x4 = {-1, -1, -1, -1}; print_prologue("c2ci2b1", _Alignof(struct c2ci2b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1i20s {
  int a;
  _Bool b:1;
  int c:20;
  short d;
};
static struct ib1i20s x1 = {-1, 0, 0, 0}; static struct ib1i20s x2 = {-1, -1, 0, 0}; static struct ib1i20s x3 = {-1, 0, -1, 0}; static struct ib1i20s x4 = {-1, -1, -1, -1}; print_prologue("ib1i20s", _Alignof(struct ib1i20s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2i2s3I6s {
  short a:2;
  int b:2;
  short c:3;
  int :6;
  short d;
};
static struct s2i2s3I6s x1 = {-1, 0, 0, 0}; static struct s2i2s3I6s x2 = {-1, -1, 0, 0}; static struct s2i2s3I6s x3 = {-1, 0, -1, 0}; static struct s2i2s3I6s x4 = {-1, -1, -1, -1}; print_prologue("s2i2s3I6s", _Alignof(struct s2i2s3I6s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s13s14b1s {
  short a:13;
  short b:14;
  _Bool c:1;
  short d;
};
static struct s13s14b1s x1 = {-1, 0, 0, 0}; static struct s13s14b1s x2 = {-1, -1, 0, 0}; static struct s13s14b1s x3 = {-1, 0, -1, 0}; static struct s13s14b1s x4 = {-1, -1, -1, -1}; print_prologue("s13s14b1s", _Alignof(struct s13s14b1s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i29c8b1i5 {
  int a:29;
  char b:8;
  _Bool c:1;
  int d:5;
};
static struct i29c8b1i5 x1 = {-1, 0, 0, 0}; static struct i29c8b1i5 x2 = {-1, -1, 0, 0}; static struct i29c8b1i5 x3 = {-1, 0, -1, 0}; static struct i29c8b1i5 x4 = {-1, -1, -1, -1}; print_prologue("i29c8b1i5", _Alignof(struct i29c8b1i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1s2i1c {
  _Bool a:1;
  short b:2;
  int c:1;
  char d;
};
static struct b1s2i1c x1 = {-1, 0, 0, 0}; static struct b1s2i1c x2 = {-1, -1, 0, 0}; static struct b1s2i1c x3 = {-1, 0, -1, 0}; static struct b1s2i1c x4 = {-1, -1, -1, -1}; print_prologue("b1s2i1c", _Alignof(struct b1s2i1c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1c7s4c1 {
  _Bool a:1;
  char b:7;
  short c:4;
  char d:1;
};
static struct b1c7s4c1 x1 = {-1, 0, 0, 0}; static struct b1c7s4c1 x2 = {-1, -1, 0, 0}; static struct b1c7s4c1 x3 = {-1, 0, -1, 0}; static struct b1c7s4c1 x4 = {-1, -1, -1, -1}; print_prologue("b1c7s4c1", _Alignof(struct b1c7s4c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i6i12s5b {
  int a:6;
  int b:12;
  short c:5;
  _Bool d;
};
static struct i6i12s5b x1 = {-1, 0, 0, 0}; static struct i6i12s5b x2 = {-1, -1, 0, 0}; static struct i6i12s5b x3 = {-1, 0, -1, 0}; static struct i6i12s5b x4 = {-1, -1, -1, -1}; print_prologue("i6i12s5b", _Alignof(struct i6i12s5b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S6isB0i1i6 {
  short :6;
  int a;
  short b;
  _Bool :0;
  int c:1;
  int d:6;
};
static struct S6isB0i1i6 x1 = {-1, 0, 0, 0}; static struct S6isB0i1i6 x2 = {-1, -1, 0, 0}; static struct S6isB0i1i6 x3 = {-1, 0, -1, 0}; static struct S6isB0i1i6 x4 = {-1, -1, -1, -1}; print_prologue("S6isB0i1i6", _Alignof(struct S6isB0i1i6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s2i31c {
  int a:2;
  short b:2;
  int c:31;
  char d;
};
static struct i2s2i31c x1 = {-1, 0, 0, 0}; static struct i2s2i31c x2 = {-1, -1, 0, 0}; static struct i2s2i31c x3 = {-1, 0, -1, 0}; static struct i2s2i31c x4 = {-1, -1, -1, -1}; print_prologue("i2s2i31c", _Alignof(struct i2s2i31c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i28i13b1I8s6 {
  int a:28;
  int b:13;
  _Bool c:1;
  int :8;
  short d:6;
};
static struct i28i13b1I8s6 x1 = {-1, 0, 0, 0}; static struct i28i13b1I8s6 x2 = {-1, -1, 0, 0}; static struct i28i13b1I8s6 x3 = {-1, 0, -1, 0}; static struct i28i13b1I8s6 x4 = {-1, -1, -1, -1}; print_prologue("i28i13b1I8s6", _Alignof(struct i28i13b1I8s6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i30c7s5s2 {
  int a:30;
  char b:7;
  short c:5;
  short d:2;
};
static struct i30c7s5s2 x1 = {-1, 0, 0, 0}; static struct i30c7s5s2 x2 = {-1, -1, 0, 0}; static struct i30c7s5s2 x3 = {-1, 0, -1, 0}; static struct i30c7s5s2 x4 = {-1, -1, -1, -1}; print_prologue("i30c7s5s2", _Alignof(struct i30c7s5s2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7ci4i14 {
  int a:7;
  char b;
  int c:4;
  int d:14;
};
static struct i7ci4i14 x1 = {-1, 0, 0, 0}; static struct i7ci4i14 x2 = {-1, -1, 0, 0}; static struct i7ci4i14 x3 = {-1, 0, -1, 0}; static struct i7ci4i14 x4 = {-1, -1, -1, -1}; print_prologue("i7ci4i14", _Alignof(struct i7ci4i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cS0si6s8 {
  char a;
  short :0;
  short b;
  int c:6;
  short d:8;
};
static struct cS0si6s8 x1 = {-1, 0, 0, 0}; static struct cS0si6s8 x2 = {-1, -1, 0, 0}; static struct cS0si6s8 x3 = {-1, 0, -1, 0}; static struct cS0si6s8 x4 = {-1, -1, -1, -1}; print_prologue("cS0si6s8", _Alignof(struct cS0si6s8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8s5ic {
  char a:8;
  short b:5;
  int c;
  char d;
};
static struct c8s5ic x1 = {-1, 0, 0, 0}; static struct c8s5ic x2 = {-1, -1, 0, 0}; static struct c8s5ic x3 = {-1, 0, -1, 0}; static struct c8s5ic x4 = {-1, -1, -1, -1}; print_prologue("c8s5ic", _Alignof(struct c8s5ic), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ic7ic {
  int a;
  char b:7;
  int c;
  char d;
};
static struct ic7ic x1 = {-1, 0, 0, 0}; static struct ic7ic x2 = {-1, -1, 0, 0}; static struct ic7ic x3 = {-1, 0, -1, 0}; static struct ic7ic x4 = {-1, -1, -1, -1}; print_prologue("ic7ic", _Alignof(struct ic7ic), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i24I4i15c4i31 {
  int a:24;
  int :4;
  int b:15;
  char c:4;
  int d:31;
};
static struct i24I4i15c4i31 x1 = {-1, 0, 0, 0}; static struct i24I4i15c4i31 x2 = {-1, -1, 0, 0}; static struct i24I4i15c4i31 x3 = {-1, 0, -1, 0}; static struct i24I4i15c4i31 x4 = {-1, -1, -1, -1}; print_prologue("i24I4i15c4i31", _Alignof(struct i24I4i15c4i31), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1i25i11c {
  int a:1;
  int b:25;
  int c:11;
  char d;
};
static struct i1i25i11c x1 = {-1, 0, 0, 0}; static struct i1i25i11c x2 = {-1, -1, 0, 0}; static struct i1i25i11c x3 = {-1, 0, -1, 0}; static struct i1i25i11c x4 = {-1, -1, -1, -1}; print_prologue("i1i25i11c", _Alignof(struct i1i25i11c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C1i3c5ci {
  char :1;
  int a:3;
  char b:5;
  char c;
  int d;
};
static struct C1i3c5ci x1 = {-1, 0, 0, 0}; static struct C1i3c5ci x2 = {-1, -1, 0, 0}; static struct C1i3c5ci x3 = {-1, 0, -1, 0}; static struct C1i3c5ci x4 = {-1, -1, -1, -1}; print_prologue("C1i3c5ci", _Alignof(struct C1i3c5ci), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i2i1s9 {
  _Bool a:1;
  int b:2;
  int c:1;
  short d:9;
};
static struct b1i2i1s9 x1 = {-1, 0, 0, 0}; static struct b1i2i1s9 x2 = {-1, -1, 0, 0}; static struct b1i2i1s9 x3 = {-1, 0, -1, 0}; static struct b1i2i1s9 x4 = {-1, -1, -1, -1}; print_prologue("b1i2i1s9", _Alignof(struct b1i2i1s9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1bc3c5 {
  _Bool a:1;
  _Bool b;
  char c:3;
  char d:5;
};
static struct b1bc3c5 x1 = {-1, 0, 0, 0}; static struct b1bc3c5 x2 = {-1, -1, 0, 0}; static struct b1bc3c5 x3 = {-1, 0, -1, 0}; static struct b1bc3c5 x4 = {-1, -1, -1, -1}; print_prologue("b1bc3c5", _Alignof(struct b1bc3c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii3C2C0c6i2 {
  int a;
  int b:3;
  char :2;
  char :0;
  char c:6;
  int d:2;
};
static struct ii3C2C0c6i2 x1 = {-1, 0, 0, 0}; static struct ii3C2C0c6i2 x2 = {-1, -1, 0, 0}; static struct ii3C2C0c6i2 x3 = {-1, 0, -1, 0}; static struct ii3C2C0c6i2 x4 = {-1, -1, -1, -1}; print_prologue("ii3C2C0c6i2", _Alignof(struct ii3C2C0c6i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s6i7b1c4 {
  short a:6;
  int b:7;
  _Bool c:1;
  char d:4;
};
static struct s6i7b1c4 x1 = {-1, 0, 0, 0}; static struct s6i7b1c4 x2 = {-1, -1, 0, 0}; static struct s6i7b1c4 x3 = {-1, 0, -1, 0}; static struct s6i7b1c4 x4 = {-1, -1, -1, -1}; print_prologue("s6i7b1c4", _Alignof(struct s6i7b1c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ssss3 {
  short a;
  short b;
  short c;
  short d:3;
};
static struct ssss3 x1 = {-1, 0, 0, 0}; static struct ssss3 x2 = {-1, -1, 0, 0}; static struct ssss3 x3 = {-1, 0, -1, 0}; static struct ssss3 x4 = {-1, -1, -1, -1}; print_prologue("ssss3", _Alignof(struct ssss3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ss3s4b {
  short a;
  short b:3;
  short c:4;
  _Bool d;
};
static struct ss3s4b x1 = {-1, 0, 0, 0}; static struct ss3s4b x2 = {-1, -1, 0, 0}; static struct ss3s4b x3 = {-1, 0, -1, 0}; static struct ss3s4b x4 = {-1, -1, -1, -1}; print_prologue("ss3s4b", _Alignof(struct ss3s4b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iC3cc8c4 {
  int a;
  char :3;
  char b;
  char c:8;
  char d:4;
};
static struct iC3cc8c4 x1 = {-1, 0, 0, 0}; static struct iC3cc8c4 x2 = {-1, -1, 0, 0}; static struct iC3cc8c4 x3 = {-1, 0, -1, 0}; static struct iC3cc8c4 x4 = {-1, -1, -1, -1}; print_prologue("iC3cc8c4", _Alignof(struct iC3cc8c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1cc5c8 {
  int a:1;
  char b;
  char c:5;
  char d:8;
};
static struct i1cc5c8 x1 = {-1, 0, 0, 0}; static struct i1cc5c8 x2 = {-1, -1, 0, 0}; static struct i1cc5c8 x3 = {-1, 0, -1, 0}; static struct i1cc5c8 x4 = {-1, -1, -1, -1}; print_prologue("i1cc5c8", _Alignof(struct i1cc5c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1b1c5 {
  int a;
  _Bool b:1;
  _Bool c:1;
  char d:5;
};
static struct ib1b1c5 x1 = {-1, 0, 0, 0}; static struct ib1b1c5 x2 = {-1, -1, 0, 0}; static struct ib1b1c5 x3 = {-1, 0, -1, 0}; static struct ib1b1c5 x4 = {-1, -1, -1, -1}; print_prologue("ib1b1c5", _Alignof(struct ib1b1c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1s14si30 {
  _Bool a:1;
  short b:14;
  short c;
  int d:30;
};
static struct b1s14si30 x1 = {-1, 0, 0, 0}; static struct b1s14si30 x2 = {-1, -1, 0, 0}; static struct b1s14si30 x3 = {-1, 0, -1, 0}; static struct b1s14si30 x4 = {-1, -1, -1, -1}; print_prologue("b1s14si30", _Alignof(struct b1s14si30), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C1I0I3bi6i18i5 {
  char :1;
  int :0;
  int :3;
  _Bool a;
  int b:6;
  int c:18;
  int d:5;
};
static struct C1I0I3bi6i18i5 x1 = {-1, 0, 0, 0}; static struct C1I0I3bi6i18i5 x2 = {-1, -1, 0, 0}; static struct C1I0I3bi6i18i5 x3 = {-1, 0, -1, 0}; static struct C1I0I3bi6i18i5 x4 = {-1, -1, -1, -1}; print_prologue("C1I0I3bi6i18i5", _Alignof(struct C1I0I3bi6i18i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i15I19c1c8c5 {
  int a:15;
  int :19;
  char b:1;
  char c:8;
  char d:5;
};
static struct i15I19c1c8c5 x1 = {-1, 0, 0, 0}; static struct i15I19c1c8c5 x2 = {-1, -1, 0, 0}; static struct i15I19c1c8c5 x3 = {-1, 0, -1, 0}; static struct i15I19c1c8c5 x4 = {-1, -1, -1, -1}; print_prologue("i15I19c1c8c5", _Alignof(struct i15I19c1c8c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i4i6ci13 {
  int a:4;
  int b:6;
  char c;
  int d:13;
};
static struct i4i6ci13 x1 = {-1, 0, 0, 0}; static struct i4i6ci13 x2 = {-1, -1, 0, 0}; static struct i4i6ci13 x3 = {-1, 0, -1, 0}; static struct i4i6ci13 x4 = {-1, -1, -1, -1}; print_prologue("i4i6ci13", _Alignof(struct i4i6ci13), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6I4s8i17i {
  char a:6;
  int :4;
  short b:8;
  int c:17;
  int d;
};
static struct c6I4s8i17i x1 = {-1, 0, 0, 0}; static struct c6I4s8i17i x2 = {-1, -1, 0, 0}; static struct c6I4s8i17i x3 = {-1, 0, -1, 0}; static struct c6I4s8i17i x4 = {-1, -1, -1, -1}; print_prologue("c6I4s8i17i", _Alignof(struct c6I4s8i17i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5c1bC3i {
  char a:5;
  char b:1;
  _Bool c;
  char :3;
  int d;
};
static struct c5c1bC3i x1 = {-1, 0, 0, 0}; static struct c5c1bC3i x2 = {-1, -1, 0, 0}; static struct c5c1bC3i x3 = {-1, 0, -1, 0}; static struct c5c1bC3i x4 = {-1, -1, -1, -1}; print_prologue("c5c1bC3i", _Alignof(struct c5c1bC3i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sb1s8i10 {
  short a;
  _Bool b:1;
  short c:8;
  int d:10;
};
static struct sb1s8i10 x1 = {-1, 0, 0, 0}; static struct sb1s8i10 x2 = {-1, -1, 0, 0}; static struct sb1s8i10 x3 = {-1, 0, -1, 0}; static struct sb1s8i10 x4 = {-1, -1, -1, -1}; print_prologue("sb1s8i10", _Alignof(struct sb1s8i10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i17s5s3i14 {
  int a:17;
  short b:5;
  short c:3;
  int d:14;
};
static struct i17s5s3i14 x1 = {-1, 0, 0, 0}; static struct i17s5s3i14 x2 = {-1, -1, 0, 0}; static struct i17s5s3i14 x3 = {-1, 0, -1, 0}; static struct i17s5s3i14 x4 = {-1, -1, -1, -1}; print_prologue("i17s5s3i14", _Alignof(struct i17s5s3i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s8c1b1b1 {
  short a:8;
  char b:1;
  _Bool c:1;
  _Bool d:1;
};
static struct s8c1b1b1 x1 = {-1, 0, 0, 0}; static struct s8c1b1b1 x2 = {-1, -1, 0, 0}; static struct s8c1b1b1 x3 = {-1, 0, -1, 0}; static struct s8c1b1b1 x4 = {-1, -1, -1, -1}; print_prologue("s8c1b1b1", _Alignof(struct s8c1b1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3S0i2c1i {
  char a:3;
  short :0;
  int b:2;
  char c:1;
  int d;
};
static struct c3S0i2c1i x1 = {-1, 0, 0, 0}; static struct c3S0i2c1i x2 = {-1, -1, 0, 0}; static struct c3S0i2c1i x3 = {-1, 0, -1, 0}; static struct c3S0i2c1i x4 = {-1, -1, -1, -1}; print_prologue("c3S0i2c1i", _Alignof(struct c3S0i2c1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7i2i30s2 {
  char a:7;
  int b:2;
  int c:30;
  short d:2;
};
static struct c7i2i30s2 x1 = {-1, 0, 0, 0}; static struct c7i2i30s2 x2 = {-1, -1, 0, 0}; static struct c7i2i30s2 x3 = {-1, 0, -1, 0}; static struct c7i2i30s2 x4 = {-1, -1, -1, -1}; print_prologue("c7i2i30s2", _Alignof(struct c7i2i30s2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1C8ss9b {
  int a:1;
  char :8;
  short b;
  short c:9;
  _Bool d;
};
static struct i1C8ss9b x1 = {-1, 0, 0, 0}; static struct i1C8ss9b x2 = {-1, -1, 0, 0}; static struct i1C8ss9b x3 = {-1, 0, -1, 0}; static struct i1C8ss9b x4 = {-1, -1, -1, -1}; print_prologue("i1C8ss9b", _Alignof(struct i1C8ss9b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ci10c4b1 {
  char a;
  int b:10;
  char c:4;
  _Bool d:1;
};
static struct ci10c4b1 x1 = {-1, 0, 0, 0}; static struct ci10c4b1 x2 = {-1, -1, 0, 0}; static struct ci10c4b1 x3 = {-1, 0, -1, 0}; static struct ci10c4b1 x4 = {-1, -1, -1, -1}; print_prologue("ci10c4b1", _Alignof(struct ci10c4b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ic2B1cC0c7 {
  int a;
  char b:2;
  _Bool :1;
  char c;
  char :0;
  char d:7;
};
static struct ic2B1cC0c7 x1 = {-1, 0, 0, 0}; static struct ic2B1cC0c7 x2 = {-1, -1, 0, 0}; static struct ic2B1cC0c7 x3 = {-1, 0, -1, 0}; static struct ic2B1cC0c7 x4 = {-1, -1, -1, -1}; print_prologue("ic2B1cC0c7", _Alignof(struct ic2B1cC0c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5c6i3i {
  int a:5;
  char b:6;
  int c:3;
  int d;
};
static struct i5c6i3i x1 = {-1, 0, 0, 0}; static struct i5c6i3i x2 = {-1, -1, 0, 0}; static struct i5c6i3i x3 = {-1, 0, -1, 0}; static struct i5c6i3i x4 = {-1, -1, -1, -1}; print_prologue("i5c6i3i", _Alignof(struct i5c6i3i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i8bi7b {
  int a:8;
  _Bool b;
  int c:7;
  _Bool d;
};
static struct i8bi7b x1 = {-1, 0, 0, 0}; static struct i8bi7b x2 = {-1, -1, 0, 0}; static struct i8bi7b x3 = {-1, 0, -1, 0}; static struct i8bi7b x4 = {-1, -1, -1, -1}; print_prologue("i8bi7b", _Alignof(struct i8bi7b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is3bc5 {
  int a;
  short b:3;
  _Bool c;
  char d:5;
};
static struct is3bc5 x1 = {-1, 0, 0, 0}; static struct is3bc5 x2 = {-1, -1, 0, 0}; static struct is3bc5 x3 = {-1, 0, -1, 0}; static struct is3bc5 x4 = {-1, -1, -1, -1}; print_prologue("is3bc5", _Alignof(struct is3bc5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1I2s11c1c4 {
  char a:1;
  int :2;
  short b:11;
  char c:1;
  char d:4;
};
static struct c1I2s11c1c4 x1 = {-1, 0, 0, 0}; static struct c1I2s11c1c4 x2 = {-1, -1, 0, 0}; static struct c1I2s11c1c4 x3 = {-1, 0, -1, 0}; static struct c1I2s11c1c4 x4 = {-1, -1, -1, -1}; print_prologue("c1I2s11c1c4", _Alignof(struct c1I2s11c1c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1i10c5c1 {
  char a:1;
  int b:10;
  char c:5;
  char d:1;
};
static struct c1i10c5c1 x1 = {-1, 0, 0, 0}; static struct c1i10c5c1 x2 = {-1, -1, 0, 0}; static struct c1i10c5c1 x3 = {-1, 0, -1, 0}; static struct c1i10c5c1 x4 = {-1, -1, -1, -1}; print_prologue("c1i10c5c1", _Alignof(struct c1i10c5c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i12c2i4c8 {
  int a:12;
  char b:2;
  int c:4;
  char d:8;
};
static struct i12c2i4c8 x1 = {-1, 0, 0, 0}; static struct i12c2i4c8 x2 = {-1, -1, 0, 0}; static struct i12c2i4c8 x3 = {-1, 0, -1, 0}; static struct i12c2i4c8 x4 = {-1, -1, -1, -1}; print_prologue("i12c2i4c8", _Alignof(struct i12c2i4c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2i16c1i25 {
  short a:2;
  int b:16;
  char c:1;
  int d:25;
};
static struct s2i16c1i25 x1 = {-1, 0, 0, 0}; static struct s2i16c1i25 x2 = {-1, -1, 0, 0}; static struct s2i16c1i25 x3 = {-1, 0, -1, 0}; static struct s2i16c1i25 x4 = {-1, -1, -1, -1}; print_prologue("s2i16c1i25", _Alignof(struct s2i16c1i25), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iI12s4i10b1 {
  int a;
  int :12;
  short b:4;
  int c:10;
  _Bool d:1;
};
static struct iI12s4i10b1 x1 = {-1, 0, 0, 0}; static struct iI12s4i10b1 x2 = {-1, -1, 0, 0}; static struct iI12s4i10b1 x3 = {-1, 0, -1, 0}; static struct iI12s4i10b1 x4 = {-1, -1, -1, -1}; print_prologue("iI12s4i10b1", _Alignof(struct iI12s4i10b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4i1ii1 {
  short a:4;
  int b:1;
  int c;
  int d:1;
};
static struct s4i1ii1 x1 = {-1, 0, 0, 0}; static struct s4i1ii1 x2 = {-1, -1, 0, 0}; static struct s4i1ii1 x3 = {-1, 0, -1, 0}; static struct s4i1ii1 x4 = {-1, -1, -1, -1}; print_prologue("s4i1ii1", _Alignof(struct s4i1ii1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct si1b1i3 {
  short a;
  int b:1;
  _Bool c:1;
  int d:3;
};
static struct si1b1i3 x1 = {-1, 0, 0, 0}; static struct si1b1i3 x2 = {-1, -1, 0, 0}; static struct si1b1i3 x3 = {-1, 0, -1, 0}; static struct si1b1i3 x4 = {-1, -1, -1, -1}; print_prologue("si1b1i3", _Alignof(struct si1b1i3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sbi4c5 {
  short a;
  _Bool b;
  int c:4;
  char d:5;
};
static struct sbi4c5 x1 = {-1, 0, 0, 0}; static struct sbi4c5 x2 = {-1, -1, 0, 0}; static struct sbi4c5 x3 = {-1, 0, -1, 0}; static struct sbi4c5 x4 = {-1, -1, -1, -1}; print_prologue("sbi4c5", _Alignof(struct sbi4c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is15s7C2i {
  int a;
  short b:15;
  short c:7;
  char :2;
  int d;
};
static struct is15s7C2i x1 = {-1, 0, 0, 0}; static struct is15s7C2i x2 = {-1, -1, 0, 0}; static struct is15s7C2i x3 = {-1, 0, -1, 0}; static struct is15s7C2i x4 = {-1, -1, -1, -1}; print_prologue("is15s7C2i", _Alignof(struct is15s7C2i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i32c1cc6 {
  int a:32;
  char b:1;
  char c;
  char d:6;
};
static struct i32c1cc6 x1 = {-1, 0, 0, 0}; static struct i32c1cc6 x2 = {-1, -1, 0, 0}; static struct i32c1cc6 x3 = {-1, 0, -1, 0}; static struct i32c1cc6 x4 = {-1, -1, -1, -1}; print_prologue("i32c1cc6", _Alignof(struct i32c1cc6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1ic7c1 {
  _Bool a:1;
  int b;
  char c:7;
  char d:1;
};
static struct b1ic7c1 x1 = {-1, 0, 0, 0}; static struct b1ic7c1 x2 = {-1, -1, 0, 0}; static struct b1ic7c1 x3 = {-1, 0, -1, 0}; static struct b1ic7c1 x4 = {-1, -1, -1, -1}; print_prologue("b1ic7c1", _Alignof(struct b1ic7c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii15ib1 {
  int a;
  int b:15;
  int c;
  _Bool d:1;
};
static struct ii15ib1 x1 = {-1, 0, 0, 0}; static struct ii15ib1 x2 = {-1, -1, 0, 0}; static struct ii15ib1 x3 = {-1, 0, -1, 0}; static struct ii15ib1 x4 = {-1, -1, -1, -1}; print_prologue("ii15ib1", _Alignof(struct ii15ib1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i1is5 {
  _Bool a:1;
  int b:1;
  int c;
  short d:5;
};
static struct b1i1is5 x1 = {-1, 0, 0, 0}; static struct b1i1is5 x2 = {-1, -1, 0, 0}; static struct b1i1is5 x3 = {-1, 0, -1, 0}; static struct b1i1is5 x4 = {-1, -1, -1, -1}; print_prologue("b1i1is5", _Alignof(struct b1i1is5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7i9i8i1 {
  int a:7;
  int b:9;
  int c:8;
  int d:1;
};
static struct i7i9i8i1 x1 = {-1, 0, 0, 0}; static struct i7i9i8i1 x2 = {-1, -1, 0, 0}; static struct i7i9i8i1 x3 = {-1, 0, -1, 0}; static struct i7i9i8i1 x4 = {-1, -1, -1, -1}; print_prologue("i7i9i8i1", _Alignof(struct i7i9i8i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i3b1c3i4 {
  int a:3;
  _Bool b:1;
  char c:3;
  int d:4;
};
static struct i3b1c3i4 x1 = {-1, 0, 0, 0}; static struct i3b1c3i4 x2 = {-1, -1, 0, 0}; static struct i3b1c3i4 x3 = {-1, 0, -1, 0}; static struct i3b1c3i4 x4 = {-1, -1, -1, -1}; print_prologue("i3b1c3i4", _Alignof(struct i3b1c3i4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s9i29i3 {
  int a:2;
  short b:9;
  int c:29;
  int d:3;
};
static struct i2s9i29i3 x1 = {-1, 0, 0, 0}; static struct i2s9i29i3 x2 = {-1, -1, 0, 0}; static struct i2s9i29i3 x3 = {-1, 0, -1, 0}; static struct i2s9i29i3 x4 = {-1, -1, -1, -1}; print_prologue("i2s9i29i3", _Alignof(struct i2s9i29i3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1c3s6s5 {
  int a:1;
  char b:3;
  short c:6;
  short d:5;
};
static struct i1c3s6s5 x1 = {-1, 0, 0, 0}; static struct i1c3s6s5 x2 = {-1, -1, 0, 0}; static struct i1c3s6s5 x3 = {-1, 0, -1, 0}; static struct i1c3s6s5 x4 = {-1, -1, -1, -1}; print_prologue("i1c3s6s5", _Alignof(struct i1c3s6s5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4ic6c3 {
  char a:4;
  int b;
  char c:6;
  char d:3;
};
static struct c4ic6c3 x1 = {-1, 0, 0, 0}; static struct c4ic6c3 x2 = {-1, -1, 0, 0}; static struct c4ic6c3 x3 = {-1, 0, -1, 0}; static struct c4ic6c3 x4 = {-1, -1, -1, -1}; print_prologue("c4ic6c3", _Alignof(struct c4ic6c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i4c1c4 {
  _Bool a:1;
  int b:4;
  char c:1;
  char d:4;
};
static struct b1i4c1c4 x1 = {-1, 0, 0, 0}; static struct b1i4c1c4 x2 = {-1, -1, 0, 0}; static struct b1i4c1c4 x3 = {-1, 0, -1, 0}; static struct b1i4c1c4 x4 = {-1, -1, -1, -1}; print_prologue("b1i4c1c4", _Alignof(struct b1i4c1c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i23i2c6i28 {
  int a:23;
  int b:2;
  char c:6;
  int d:28;
};
static struct i23i2c6i28 x1 = {-1, 0, 0, 0}; static struct i23i2c6i28 x2 = {-1, -1, 0, 0}; static struct i23i2c6i28 x3 = {-1, 0, -1, 0}; static struct i23i2c6i28 x4 = {-1, -1, -1, -1}; print_prologue("i23i2c6i28", _Alignof(struct i23i2c6i28), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ic3sc2 {
  int a;
  char b:3;
  short c;
  char d:2;
};
static struct ic3sc2 x1 = {-1, 0, 0, 0}; static struct ic3sc2 x2 = {-1, -1, 0, 0}; static struct ic3sc2 x3 = {-1, 0, -1, 0}; static struct ic3sc2 x4 = {-1, -1, -1, -1}; print_prologue("ic3sc2", _Alignof(struct ic3sc2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i32c5c3i6 {
  int a:32;
  char b:5;
  char c:3;
  int d:6;
};
static struct i32c5c3i6 x1 = {-1, 0, 0, 0}; static struct i32c5c3i6 x2 = {-1, -1, 0, 0}; static struct i32c5c3i6 x3 = {-1, 0, -1, 0}; static struct i32c5c3i6 x4 = {-1, -1, -1, -1}; print_prologue("i32c5c3i6", _Alignof(struct i32c5c3i6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2ic4i4 {
  char a:2;
  int b;
  char c:4;
  int d:4;
};
static struct c2ic4i4 x1 = {-1, 0, 0, 0}; static struct c2ic4i4 x2 = {-1, -1, 0, 0}; static struct c2ic4i4 x3 = {-1, 0, -1, 0}; static struct c2ic4i4 x4 = {-1, -1, -1, -1}; print_prologue("c2ic4i4", _Alignof(struct c2ic4i4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i12b1i13s15 {
  int a:12;
  _Bool b:1;
  int c:13;
  short d:15;
};
static struct i12b1i13s15 x1 = {-1, 0, 0, 0}; static struct i12b1i13s15 x2 = {-1, -1, 0, 0}; static struct i12b1i13s15 x3 = {-1, 0, -1, 0}; static struct i12b1i13s15 x4 = {-1, -1, -1, -1}; print_prologue("i12b1i13s15", _Alignof(struct i12b1i13s15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i1s7c7 {
  _Bool a:1;
  int b:1;
  short c:7;
  char d:7;
};
static struct b1i1s7c7 x1 = {-1, 0, 0, 0}; static struct b1i1s7c7 x2 = {-1, -1, 0, 0}; static struct b1i1s7c7 x3 = {-1, 0, -1, 0}; static struct b1i1s7c7 x4 = {-1, -1, -1, -1}; print_prologue("b1i1s7c7", _Alignof(struct b1i1s7c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6S1s3cc2 {
  char a:6;
  short :1;
  short b:3;
  char c;
  char d:2;
};
static struct c6S1s3cc2 x1 = {-1, 0, 0, 0}; static struct c6S1s3cc2 x2 = {-1, -1, 0, 0}; static struct c6S1s3cc2 x3 = {-1, 0, -1, 0}; static struct c6S1s3cc2 x4 = {-1, -1, -1, -1}; print_prologue("c6S1s3cc2", _Alignof(struct c6S1s3cc2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1ii11b1 {
  _Bool a:1;
  int b;
  int c:11;
  _Bool d:1;
};
static struct b1ii11b1 x1 = {-1, 0, 0, 0}; static struct b1ii11b1 x2 = {-1, -1, 0, 0}; static struct b1ii11b1 x3 = {-1, 0, -1, 0}; static struct b1ii11b1 x4 = {-1, -1, -1, -1}; print_prologue("b1ii11b1", _Alignof(struct b1ii11b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i12c6b1b1 {
  int a:12;
  char b:6;
  _Bool c:1;
  _Bool d:1;
};
static struct i12c6b1b1 x1 = {-1, 0, 0, 0}; static struct i12c6b1b1 x2 = {-1, -1, 0, 0}; static struct i12c6b1b1 x3 = {-1, 0, -1, 0}; static struct i12c6b1b1 x4 = {-1, -1, -1, -1}; print_prologue("i12c6b1b1", _Alignof(struct i12c6b1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i6s7i {
  _Bool a:1;
  int b:6;
  short c:7;
  int d;
};
static struct b1i6s7i x1 = {-1, 0, 0, 0}; static struct b1i6s7i x2 = {-1, -1, 0, 0}; static struct b1i6s7i x3 = {-1, 0, -1, 0}; static struct b1i6s7i x4 = {-1, -1, -1, -1}; print_prologue("b1i6s7i", _Alignof(struct b1i6s7i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s11s16i10i {
  short a:11;
  short b:16;
  int c:10;
  int d;
};
static struct s11s16i10i x1 = {-1, 0, 0, 0}; static struct s11s16i10i x2 = {-1, -1, 0, 0}; static struct s11s16i10i x3 = {-1, 0, -1, 0}; static struct s11s16i10i x4 = {-1, -1, -1, -1}; print_prologue("s11s16i10i", _Alignof(struct s11s16i10i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2i17ii12 {
  int a:2;
  int b:17;
  int c;
  int d:12;
};
static struct i2i17ii12 x1 = {-1, 0, 0, 0}; static struct i2i17ii12 x2 = {-1, -1, 0, 0}; static struct i2i17ii12 x3 = {-1, 0, -1, 0}; static struct i2i17ii12 x4 = {-1, -1, -1, -1}; print_prologue("i2i17ii12", _Alignof(struct i2i17ii12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i13si14c7 {
  int a:13;
  short b;
  int c:14;
  char d:7;
};
static struct i13si14c7 x1 = {-1, 0, 0, 0}; static struct i13si14c7 x2 = {-1, -1, 0, 0}; static struct i13si14c7 x3 = {-1, 0, -1, 0}; static struct i13si14c7 x4 = {-1, -1, -1, -1}; print_prologue("i13si14c7", _Alignof(struct i13si14c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1s4s7s15 {
  char a:1;
  short b:4;
  short c:7;
  short d:15;
};
static struct c1s4s7s15 x1 = {-1, 0, 0, 0}; static struct c1s4s7s15 x2 = {-1, -1, 0, 0}; static struct c1s4s7s15 x3 = {-1, 0, -1, 0}; static struct c1s4s7s15 x4 = {-1, -1, -1, -1}; print_prologue("c1s4s7s15", _Alignof(struct c1s4s7s15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s14c2i3i2 {
  short a:14;
  char b:2;
  int c:3;
  int d:2;
};
static struct s14c2i3i2 x1 = {-1, 0, 0, 0}; static struct s14c2i3i2 x2 = {-1, -1, 0, 0}; static struct s14c2i3i2 x3 = {-1, 0, -1, 0}; static struct s14c2i3i2 x4 = {-1, -1, -1, -1}; print_prologue("s14c2i3i2", _Alignof(struct s14c2i3i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii21s6b1 {
  int a;
  int b:21;
  short c:6;
  _Bool d:1;
};
static struct ii21s6b1 x1 = {-1, 0, 0, 0}; static struct ii21s6b1 x2 = {-1, -1, 0, 0}; static struct ii21s6b1 x3 = {-1, 0, -1, 0}; static struct ii21s6b1 x4 = {-1, -1, -1, -1}; print_prologue("ii21s6b1", _Alignof(struct ii21s6b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i23b1b1c4 {
  int a:23;
  _Bool b:1;
  _Bool c:1;
  char d:4;
};
static struct i23b1b1c4 x1 = {-1, 0, 0, 0}; static struct i23b1b1c4 x2 = {-1, -1, 0, 0}; static struct i23b1b1c4 x3 = {-1, 0, -1, 0}; static struct i23b1b1c4 x4 = {-1, -1, -1, -1}; print_prologue("i23b1b1c4", _Alignof(struct i23b1b1c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iI0I1ci15c6 {
  int a;
  int :0;
  int :1;
  char b;
  int c:15;
  char d:6;
};
static struct iI0I1ci15c6 x1 = {-1, 0, 0, 0}; static struct iI0I1ci15c6 x2 = {-1, -1, 0, 0}; static struct iI0I1ci15c6 x3 = {-1, 0, -1, 0}; static struct iI0I1ci15c6 x4 = {-1, -1, -1, -1}; print_prologue("iI0I1ci15c6", _Alignof(struct iI0I1ci15c6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i1c8b1 {
  _Bool a:1;
  int b:1;
  char c:8;
  _Bool d:1;
};
static struct b1i1c8b1 x1 = {-1, 0, 0, 0}; static struct b1i1c8b1 x2 = {-1, -1, 0, 0}; static struct b1i1c8b1 x3 = {-1, 0, -1, 0}; static struct b1i1c8b1 x4 = {-1, -1, -1, -1}; print_prologue("b1i1c8b1", _Alignof(struct b1i1c8b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s5i2i11s {
  short a:5;
  int b:2;
  int c:11;
  short d;
};
static struct s5i2i11s x1 = {-1, 0, 0, 0}; static struct s5i2i11s x2 = {-1, -1, 0, 0}; static struct s5i2i11s x3 = {-1, 0, -1, 0}; static struct s5i2i11s x4 = {-1, -1, -1, -1}; print_prologue("s5i2i11s", _Alignof(struct s5i2i11s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1b1c8i25 {
  int a:1;
  _Bool b:1;
  char c:8;
  int d:25;
};
static struct i1b1c8i25 x1 = {-1, 0, 0, 0}; static struct i1b1c8i25 x2 = {-1, -1, 0, 0}; static struct i1b1c8i25 x3 = {-1, 0, -1, 0}; static struct i1b1c8i25 x4 = {-1, -1, -1, -1}; print_prologue("i1b1c8i25", _Alignof(struct i1b1c8i25), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cis3c {
  char a;
  int b;
  short c:3;
  char d;
};
static struct cis3c x1 = {-1, 0, 0, 0}; static struct cis3c x2 = {-1, -1, 0, 0}; static struct cis3c x3 = {-1, 0, -1, 0}; static struct cis3c x4 = {-1, -1, -1, -1}; print_prologue("cis3c", _Alignof(struct cis3c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii14ii {
  int a;
  int b:14;
  int c;
  int d;
};
static struct ii14ii x1 = {-1, 0, 0, 0}; static struct ii14ii x2 = {-1, -1, 0, 0}; static struct ii14ii x3 = {-1, 0, -1, 0}; static struct ii14ii x4 = {-1, -1, -1, -1}; print_prologue("ii14ii", _Alignof(struct ii14ii), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1b1c2I1c2 {
  int a:1;
  _Bool b:1;
  char c:2;
  int :1;
  char d:2;
};
static struct i1b1c2I1c2 x1 = {-1, 0, 0, 0}; static struct i1b1c2I1c2 x2 = {-1, -1, 0, 0}; static struct i1b1c2I1c2 x3 = {-1, 0, -1, 0}; static struct i1b1c2I1c2 x4 = {-1, -1, -1, -1}; print_prologue("i1b1c2I1c2", _Alignof(struct i1b1c2I1c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4ib1i {
  char a:4;
  int b;
  _Bool c:1;
  int d;
};
static struct c4ib1i x1 = {-1, 0, 0, 0}; static struct c4ib1i x2 = {-1, -1, 0, 0}; static struct c4ib1i x3 = {-1, 0, -1, 0}; static struct c4ib1i x4 = {-1, -1, -1, -1}; print_prologue("c4ib1i", _Alignof(struct c4ib1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1isi4 {
  _Bool a:1;
  int b;
  short c;
  int d:4;
};
static struct b1isi4 x1 = {-1, 0, 0, 0}; static struct b1isi4 x2 = {-1, -1, 0, 0}; static struct b1isi4 x3 = {-1, 0, -1, 0}; static struct b1isi4 x4 = {-1, -1, -1, -1}; print_prologue("b1isi4", _Alignof(struct b1isi4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i16c2s12i12 {
  int a:16;
  char b:2;
  short c:12;
  int d:12;
};
static struct i16c2s12i12 x1 = {-1, 0, 0, 0}; static struct i16c2s12i12 x2 = {-1, -1, 0, 0}; static struct i16c2s12i12 x3 = {-1, 0, -1, 0}; static struct i16c2s12i12 x4 = {-1, -1, -1, -1}; print_prologue("i16c2s12i12", _Alignof(struct i16c2s12i12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct B0s1I21c2ci {
  _Bool :0;
  short a:1;
  int :21;
  char b:2;
  char c;
  int d;
};
static struct B0s1I21c2ci x1 = {-1, 0, 0, 0}; static struct B0s1I21c2ci x2 = {-1, -1, 0, 0}; static struct B0s1I21c2ci x3 = {-1, 0, -1, 0}; static struct B0s1I21c2ci x4 = {-1, -1, -1, -1}; print_prologue("B0s1I21c2ci", _Alignof(struct B0s1I21c2ci), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i16s1i5b1 {
  int a:16;
  short b:1;
  int c:5;
  _Bool d:1;
};
static struct i16s1i5b1 x1 = {-1, 0, 0, 0}; static struct i16s1i5b1 x2 = {-1, -1, 0, 0}; static struct i16s1i5b1 x3 = {-1, 0, -1, 0}; static struct i16s1i5b1 x4 = {-1, -1, -1, -1}; print_prologue("i16s1i5b1", _Alignof(struct i16s1i5b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s8ii1C0s9 {
  short a:8;
  int b;
  int c:1;
  char :0;
  short d:9;
};
static struct s8ii1C0s9 x1 = {-1, 0, 0, 0}; static struct s8ii1C0s9 x2 = {-1, -1, 0, 0}; static struct s8ii1C0s9 x3 = {-1, 0, -1, 0}; static struct s8ii1C0s9 x4 = {-1, -1, -1, -1}; print_prologue("s8ii1C0s9", _Alignof(struct s8ii1C0s9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct B1i14c2si {
  _Bool :1;
  int a:14;
  char b:2;
  short c;
  int d;
};
static struct B1i14c2si x1 = {-1, 0, 0, 0}; static struct B1i14c2si x2 = {-1, -1, 0, 0}; static struct B1i14c2si x3 = {-1, 0, -1, 0}; static struct B1i14c2si x4 = {-1, -1, -1, -1}; print_prologue("B1i14c2si", _Alignof(struct B1i14c2si), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2i2i3s13 {
  char a:2;
  int b:2;
  int c:3;
  short d:13;
};
static struct c2i2i3s13 x1 = {-1, 0, 0, 0}; static struct c2i2i3s13 x2 = {-1, -1, 0, 0}; static struct c2i2i3s13 x3 = {-1, 0, -1, 0}; static struct c2i2i3s13 x4 = {-1, -1, -1, -1}; print_prologue("c2i2i3s13", _Alignof(struct c2i2i3s13), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii21i9c8 {
  int a;
  int b:21;
  int c:9;
  char d:8;
};
static struct ii21i9c8 x1 = {-1, 0, 0, 0}; static struct ii21i9c8 x2 = {-1, -1, 0, 0}; static struct ii21i9c8 x3 = {-1, 0, -1, 0}; static struct ii21i9c8 x4 = {-1, -1, -1, -1}; print_prologue("ii21i9c8", _Alignof(struct ii21i9c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I1I5s1b1i10s {
  int :1;
  int :5;
  short a:1;
  _Bool b:1;
  int c:10;
  short d;
};
static struct I1I5s1b1i10s x1 = {-1, 0, 0, 0}; static struct I1I5s1b1i10s x2 = {-1, -1, 0, 0}; static struct I1I5s1b1i10s x3 = {-1, 0, -1, 0}; static struct I1I5s1b1i10s x4 = {-1, -1, -1, -1}; print_prologue("I1I5s1b1i10s", _Alignof(struct I1I5s1b1i10s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bs6si24 {
  _Bool a;
  short b:6;
  short c;
  int d:24;
};
static struct bs6si24 x1 = {-1, 0, 0, 0}; static struct bs6si24 x2 = {-1, -1, 0, 0}; static struct bs6si24 x3 = {-1, 0, -1, 0}; static struct bs6si24 x4 = {-1, -1, -1, -1}; print_prologue("bs6si24", _Alignof(struct bs6si24), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i11cc5i14 {
  int a:11;
  char b;
  char c:5;
  int d:14;
};
static struct i11cc5i14 x1 = {-1, 0, 0, 0}; static struct i11cc5i14 x2 = {-1, -1, 0, 0}; static struct i11cc5i14 x3 = {-1, 0, -1, 0}; static struct i11cc5i14 x4 = {-1, -1, -1, -1}; print_prologue("i11cc5i14", _Alignof(struct i11cc5i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7ccb1 {
  int a:7;
  char b;
  char c;
  _Bool d:1;
};
static struct i7ccb1 x1 = {-1, 0, 0, 0}; static struct i7ccb1 x2 = {-1, -1, 0, 0}; static struct i7ccb1 x3 = {-1, 0, -1, 0}; static struct i7ccb1 x4 = {-1, -1, -1, -1}; print_prologue("i7ccb1", _Alignof(struct i7ccb1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1I30i16I0bi {
  int a:1;
  int :30;
  int b:16;
  int :0;
  _Bool c;
  int d;
};
static struct i1I30i16I0bi x1 = {-1, 0, 0, 0}; static struct i1I30i16I0bi x2 = {-1, -1, 0, 0}; static struct i1I30i16I0bi x3 = {-1, 0, -1, 0}; static struct i1I30i16I0bi x4 = {-1, -1, -1, -1}; print_prologue("i1I30i16I0bi", _Alignof(struct i1I30i16I0bi), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ccs7s {
  char a;
  char b;
  short c:7;
  short d;
};
static struct ccs7s x1 = {-1, 0, 0, 0}; static struct ccs7s x2 = {-1, -1, 0, 0}; static struct ccs7s x3 = {-1, 0, -1, 0}; static struct ccs7s x4 = {-1, -1, -1, -1}; print_prologue("ccs7s", _Alignof(struct ccs7s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i16b1si3 {
  int a:16;
  _Bool b:1;
  short c;
  int d:3;
};
static struct i16b1si3 x1 = {-1, 0, 0, 0}; static struct i16b1si3 x2 = {-1, -1, 0, 0}; static struct i16b1si3 x3 = {-1, 0, -1, 0}; static struct i16b1si3 x4 = {-1, -1, -1, -1}; print_prologue("i16b1si3", _Alignof(struct i16b1si3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s5cc1s7 {
  short a:5;
  char b;
  char c:1;
  short d:7;
};
static struct s5cc1s7 x1 = {-1, 0, 0, 0}; static struct s5cc1s7 x2 = {-1, -1, 0, 0}; static struct s5cc1s7 x3 = {-1, 0, -1, 0}; static struct s5cc1s7 x4 = {-1, -1, -1, -1}; print_prologue("s5cc1s7", _Alignof(struct s5cc1s7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii4b1b1 {
  int a;
  int b:4;
  _Bool c:1;
  _Bool d:1;
};
static struct ii4b1b1 x1 = {-1, 0, 0, 0}; static struct ii4b1b1 x2 = {-1, -1, 0, 0}; static struct ii4b1b1 x3 = {-1, 0, -1, 0}; static struct ii4b1b1 x4 = {-1, -1, -1, -1}; print_prologue("ii4b1b1", _Alignof(struct ii4b1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sC0S0B1c2b1i {
  short a;
  char :0;
  short :0;
  _Bool :1;
  char b:2;
  _Bool c:1;
  int d;
};
static struct sC0S0B1c2b1i x1 = {-1, 0, 0, 0}; static struct sC0S0B1c2b1i x2 = {-1, -1, 0, 0}; static struct sC0S0B1c2b1i x3 = {-1, 0, -1, 0}; static struct sC0S0B1c2b1i x4 = {-1, -1, -1, -1}; print_prologue("sC0S0B1c2b1i", _Alignof(struct sC0S0B1c2b1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cc2c7s3 {
  char a;
  char b:2;
  char c:7;
  short d:3;
};
static struct cc2c7s3 x1 = {-1, 0, 0, 0}; static struct cc2c7s3 x2 = {-1, -1, 0, 0}; static struct cc2c7s3 x3 = {-1, 0, -1, 0}; static struct cc2c7s3 x4 = {-1, -1, -1, -1}; print_prologue("cc2c7s3", _Alignof(struct cc2c7s3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s5s14i1c3 {
  short a:5;
  short b:14;
  int c:1;
  char d:3;
};
static struct s5s14i1c3 x1 = {-1, 0, 0, 0}; static struct s5s14i1c3 x2 = {-1, -1, 0, 0}; static struct s5s14i1c3 x3 = {-1, 0, -1, 0}; static struct s5s14i1c3 x4 = {-1, -1, -1, -1}; print_prologue("s5s14i1c3", _Alignof(struct s5s14i1c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ic1i2i31 {
  int a;
  char b:1;
  int c:2;
  int d:31;
};
static struct ic1i2i31 x1 = {-1, 0, 0, 0}; static struct ic1i2i31 x2 = {-1, -1, 0, 0}; static struct ic1i2i31 x3 = {-1, 0, -1, 0}; static struct ic1i2i31 x4 = {-1, -1, -1, -1}; print_prologue("ic1i2i31", _Alignof(struct ic1i2i31), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i10i2b1c8 {
  int a:10;
  int b:2;
  _Bool c:1;
  char d:8;
};
static struct i10i2b1c8 x1 = {-1, 0, 0, 0}; static struct i10i2b1c8 x2 = {-1, -1, 0, 0}; static struct i10i2b1c8 x3 = {-1, 0, -1, 0}; static struct i10i2b1c8 x4 = {-1, -1, -1, -1}; print_prologue("i10i2b1c8", _Alignof(struct i10i2b1c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i26ss12S11s3 {
  int a:26;
  short b;
  short c:12;
  short :11;
  short d:3;
};
static struct i26ss12S11s3 x1 = {-1, 0, 0, 0}; static struct i26ss12S11s3 x2 = {-1, -1, 0, 0}; static struct i26ss12S11s3 x3 = {-1, 0, -1, 0}; static struct i26ss12S11s3 x4 = {-1, -1, -1, -1}; print_prologue("i26ss12S11s3", _Alignof(struct i26ss12S11s3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cS9s2s4s4 {
  char a;
  short :9;
  short b:2;
  short c:4;
  short d:4;
};
static struct cS9s2s4s4 x1 = {-1, 0, 0, 0}; static struct cS9s2s4s4 x2 = {-1, -1, 0, 0}; static struct cS9s2s4s4 x3 = {-1, 0, -1, 0}; static struct cS9s2s4s4 x4 = {-1, -1, -1, -1}; print_prologue("cS9s2s4s4", _Alignof(struct cS9s2s4s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i26s3i2i16 {
  int a:26;
  short b:3;
  int c:2;
  int d:16;
};
static struct i26s3i2i16 x1 = {-1, 0, 0, 0}; static struct i26s3i2i16 x2 = {-1, -1, 0, 0}; static struct i26s3i2i16 x3 = {-1, 0, -1, 0}; static struct i26s3i2i16 x4 = {-1, -1, -1, -1}; print_prologue("i26s3i2i16", _Alignof(struct i26s3i2i16), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i30b1c3 {
  _Bool a:1;
  int b:30;
  _Bool c:1;
  char d:3;
};
static struct b1i30b1c3 x1 = {-1, 0, 0, 0}; static struct b1i30b1c3 x2 = {-1, -1, 0, 0}; static struct b1i30b1c3 x3 = {-1, 0, -1, 0}; static struct b1i30b1c3 x4 = {-1, -1, -1, -1}; print_prologue("b1i30b1c3", _Alignof(struct b1i30b1c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i20i3ci14 {
  int a:20;
  int b:3;
  char c;
  int d:14;
};
static struct i20i3ci14 x1 = {-1, 0, 0, 0}; static struct i20i3ci14 x2 = {-1, -1, 0, 0}; static struct i20i3ci14 x3 = {-1, 0, -1, 0}; static struct i20i3ci14 x4 = {-1, -1, -1, -1}; print_prologue("i20i3ci14", _Alignof(struct i20i3ci14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bic2c {
  _Bool a;
  int b;
  char c:2;
  char d;
};
static struct bic2c x1 = {-1, 0, 0, 0}; static struct bic2c x2 = {-1, -1, 0, 0}; static struct bic2c x3 = {-1, 0, -1, 0}; static struct bic2c x4 = {-1, -1, -1, -1}; print_prologue("bic2c", _Alignof(struct bic2c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7i2s1i9 {
  int a:7;
  int b:2;
  short c:1;
  int d:9;
};
static struct i7i2s1i9 x1 = {-1, 0, 0, 0}; static struct i7i2s1i9 x2 = {-1, -1, 0, 0}; static struct i7i2s1i9 x3 = {-1, 0, -1, 0}; static struct i7i2s1i9 x4 = {-1, -1, -1, -1}; print_prologue("i7i2s1i9", _Alignof(struct i7i2s1i9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s12sii3 {
  short a:12;
  short b;
  int c;
  int d:3;
};
static struct s12sii3 x1 = {-1, 0, 0, 0}; static struct s12sii3 x2 = {-1, -1, 0, 0}; static struct s12sii3 x3 = {-1, 0, -1, 0}; static struct s12sii3 x4 = {-1, -1, -1, -1}; print_prologue("s12sii3", _Alignof(struct s12sii3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i25I10i12i1 {
  _Bool a:1;
  int b:25;
  int :10;
  int c:12;
  int d:1;
};
static struct b1i25I10i12i1 x1 = {-1, 0, 0, 0}; static struct b1i25I10i12i1 x2 = {-1, -1, 0, 0}; static struct b1i25I10i12i1 x3 = {-1, 0, -1, 0}; static struct b1i25I10i12i1 x4 = {-1, -1, -1, -1}; print_prologue("b1i25I10i12i1", _Alignof(struct b1i25I10i12i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is14s16c4 {
  int a;
  short b:14;
  short c:16;
  char d:4;
};
static struct is14s16c4 x1 = {-1, 0, 0, 0}; static struct is14s16c4 x2 = {-1, -1, 0, 0}; static struct is14s16c4 x3 = {-1, 0, -1, 0}; static struct is14s16c4 x4 = {-1, -1, -1, -1}; print_prologue("is14s16c4", _Alignof(struct is14s16c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C5bcc1c2 {
  char :5;
  _Bool a;
  char b;
  char c:1;
  char d:2;
};
static struct C5bcc1c2 x1 = {-1, 0, 0, 0}; static struct C5bcc1c2 x2 = {-1, -1, 0, 0}; static struct C5bcc1c2 x3 = {-1, 0, -1, 0}; static struct C5bcc1c2 x4 = {-1, -1, -1, -1}; print_prologue("C5bcc1c2", _Alignof(struct C5bcc1c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct B1S0b1cb1i {
  _Bool :1;
  short :0;
  _Bool a:1;
  char b;
  _Bool c:1;
  int d;
};
static struct B1S0b1cb1i x1 = {-1, 0, 0, 0}; static struct B1S0b1cb1i x2 = {-1, -1, 0, 0}; static struct B1S0b1cb1i x3 = {-1, 0, -1, 0}; static struct B1S0b1cb1i x4 = {-1, -1, -1, -1}; print_prologue("B1S0b1cb1i", _Alignof(struct B1S0b1cb1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i15c1is3 {
  int a:15;
  char b:1;
  int c;
  short d:3;
};
static struct i15c1is3 x1 = {-1, 0, 0, 0}; static struct i15c1is3 x2 = {-1, -1, 0, 0}; static struct i15c1is3 x3 = {-1, 0, -1, 0}; static struct i15c1is3 x4 = {-1, -1, -1, -1}; print_prologue("i15c1is3", _Alignof(struct i15c1is3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2s12c1s13 {
  short a:2;
  short b:12;
  char c:1;
  short d:13;
};
static struct s2s12c1s13 x1 = {-1, 0, 0, 0}; static struct s2s12c1s13 x2 = {-1, -1, 0, 0}; static struct s2s12c1s13 x3 = {-1, 0, -1, 0}; static struct s2s12c1s13 x4 = {-1, -1, -1, -1}; print_prologue("s2s12c1s13", _Alignof(struct s2s12c1s13), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2b1c2b1 {
  int a:2;
  _Bool b:1;
  char c:2;
  _Bool d:1;
};
static struct i2b1c2b1 x1 = {-1, 0, 0, 0}; static struct i2b1c2b1 x2 = {-1, -1, 0, 0}; static struct i2b1c2b1 x3 = {-1, 0, -1, 0}; static struct i2b1c2b1 x4 = {-1, -1, -1, -1}; print_prologue("i2b1c2b1", _Alignof(struct i2b1c2b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i23s8C0c4s8 {
  int a:23;
  short b:8;
  char :0;
  char c:4;
  short d:8;
};
static struct i23s8C0c4s8 x1 = {-1, 0, 0, 0}; static struct i23s8C0c4s8 x2 = {-1, -1, 0, 0}; static struct i23s8C0c4s8 x3 = {-1, 0, -1, 0}; static struct i23s8C0c4s8 x4 = {-1, -1, -1, -1}; print_prologue("i23s8C0c4s8", _Alignof(struct i23s8C0c4s8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1i12cs2 {
  int a:1;
  int b:12;
  char c;
  short d:2;
};
static struct i1i12cs2 x1 = {-1, 0, 0, 0}; static struct i1i12cs2 x2 = {-1, -1, 0, 0}; static struct i1i12cs2 x3 = {-1, 0, -1, 0}; static struct i1i12cs2 x4 = {-1, -1, -1, -1}; print_prologue("i1i12cs2", _Alignof(struct i1i12cs2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is9c2s7 {
  int a;
  short b:9;
  char c:2;
  short d:7;
};
static struct is9c2s7 x1 = {-1, 0, 0, 0}; static struct is9c2s7 x2 = {-1, -1, 0, 0}; static struct is9c2s7 x3 = {-1, 0, -1, 0}; static struct is9c2s7 x4 = {-1, -1, -1, -1}; print_prologue("is9c2s7", _Alignof(struct is9c2s7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i32s1si {
  int a:32;
  short b:1;
  short c;
  int d;
};
static struct i32s1si x1 = {-1, 0, 0, 0}; static struct i32s1si x2 = {-1, -1, 0, 0}; static struct i32s1si x3 = {-1, 0, -1, 0}; static struct i32s1si x4 = {-1, -1, -1, -1}; print_prologue("i32s1si", _Alignof(struct i32s1si), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0b1i7i2I0i {
  int :0;
  _Bool a:1;
  int b:7;
  int c:2;
  int :0;
  int d;
};
static struct I0b1i7i2I0i x1 = {-1, 0, 0, 0}; static struct I0b1i7i2I0i x2 = {-1, -1, 0, 0}; static struct I0b1i7i2I0i x3 = {-1, 0, -1, 0}; static struct I0b1i7i2I0i x4 = {-1, -1, -1, -1}; print_prologue("I0b1i7i2I0i", _Alignof(struct I0b1i7i2I0i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7C0s2b1i29 {
  int a:7;
  char :0;
  short b:2;
  _Bool c:1;
  int d:29;
};
static struct i7C0s2b1i29 x1 = {-1, 0, 0, 0}; static struct i7C0s2b1i29 x2 = {-1, -1, 0, 0}; static struct i7C0s2b1i29 x3 = {-1, 0, -1, 0}; static struct i7C0s2b1i29 x4 = {-1, -1, -1, -1}; print_prologue("i7C0s2b1i29", _Alignof(struct i7C0s2b1i29), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S5i32i13c6b1 {
  short :5;
  int a:32;
  int b:13;
  char c:6;
  _Bool d:1;
};
static struct S5i32i13c6b1 x1 = {-1, 0, 0, 0}; static struct S5i32i13c6b1 x2 = {-1, -1, 0, 0}; static struct S5i32i13c6b1 x3 = {-1, 0, -1, 0}; static struct S5i32i13c6b1 x4 = {-1, -1, -1, -1}; print_prologue("S5i32i13c6b1", _Alignof(struct S5i32i13c6b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2I0i15I0sc8 {
  char a:2;
  int :0;
  int b:15;
  int :0;
  short c;
  char d:8;
};
static struct c2I0i15I0sc8 x1 = {-1, 0, 0, 0}; static struct c2I0i15I0sc8 x2 = {-1, -1, 0, 0}; static struct c2I0i15I0sc8 x3 = {-1, 0, -1, 0}; static struct c2I0i15I0sc8 x4 = {-1, -1, -1, -1}; print_prologue("c2I0i15I0sc8", _Alignof(struct c2I0i15I0sc8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4c7i11i2 {
  short a:4;
  char b:7;
  int c:11;
  int d:2;
};
static struct s4c7i11i2 x1 = {-1, 0, 0, 0}; static struct s4c7i11i2 x2 = {-1, -1, 0, 0}; static struct s4c7i11i2 x3 = {-1, 0, -1, 0}; static struct s4c7i11i2 x4 = {-1, -1, -1, -1}; print_prologue("s4c7i11i2", _Alignof(struct s4c7i11i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1b1c4i9 {
  short a:1;
  _Bool b:1;
  char c:4;
  int d:9;
};
static struct s1b1c4i9 x1 = {-1, 0, 0, 0}; static struct s1b1c4i9 x2 = {-1, -1, 0, 0}; static struct s1b1c4i9 x3 = {-1, 0, -1, 0}; static struct s1b1c4i9 x4 = {-1, -1, -1, -1}; print_prologue("s1b1c4i9", _Alignof(struct s1b1c4i9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii3i8c3 {
  int a;
  int b:3;
  int c:8;
  char d:3;
};
static struct ii3i8c3 x1 = {-1, 0, 0, 0}; static struct ii3i8c3 x2 = {-1, -1, 0, 0}; static struct ii3i8c3 x3 = {-1, 0, -1, 0}; static struct ii3i8c3 x4 = {-1, -1, -1, -1}; print_prologue("ii3i8c3", _Alignof(struct ii3i8c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s3i7c4i1 {
  short a:3;
  int b:7;
  char c:4;
  int d:1;
};
static struct s3i7c4i1 x1 = {-1, 0, 0, 0}; static struct s3i7c4i1 x2 = {-1, -1, 0, 0}; static struct s3i7c4i1 x3 = {-1, 0, -1, 0}; static struct s3i7c4i1 x4 = {-1, -1, -1, -1}; print_prologue("s3i7c4i1", _Alignof(struct s3i7c4i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i11s3c7i15 {
  int a:11;
  short b:3;
  char c:7;
  int d:15;
};
static struct i11s3c7i15 x1 = {-1, 0, 0, 0}; static struct i11s3c7i15 x2 = {-1, -1, 0, 0}; static struct i11s3c7i15 x3 = {-1, 0, -1, 0}; static struct i11s3c7i15 x4 = {-1, -1, -1, -1}; print_prologue("i11s3c7i15", _Alignof(struct i11s3c7i15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i4ib1c {
  int a:4;
  int b;
  _Bool c:1;
  char d;
};
static struct i4ib1c x1 = {-1, 0, 0, 0}; static struct i4ib1c x2 = {-1, -1, 0, 0}; static struct i4ib1c x3 = {-1, 0, -1, 0}; static struct i4ib1c x4 = {-1, -1, -1, -1}; print_prologue("i4ib1c", _Alignof(struct i4ib1c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4C0i14b1C0i {
  char a:4;
  char :0;
  int b:14;
  _Bool c:1;
  char :0;
  int d;
};
static struct c4C0i14b1C0i x1 = {-1, 0, 0, 0}; static struct c4C0i14b1C0i x2 = {-1, -1, 0, 0}; static struct c4C0i14b1C0i x3 = {-1, 0, -1, 0}; static struct c4C0i14b1C0i x4 = {-1, -1, -1, -1}; print_prologue("c4C0i14b1C0i", _Alignof(struct c4C0i14b1C0i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i12i28bc7 {
  int a:12;
  int b:28;
  _Bool c;
  char d:7;
};
static struct i12i28bc7 x1 = {-1, 0, 0, 0}; static struct i12i28bc7 x2 = {-1, -1, 0, 0}; static struct i12i28bc7 x3 = {-1, 0, -1, 0}; static struct i12i28bc7 x4 = {-1, -1, -1, -1}; print_prologue("i12i28bc7", _Alignof(struct i12i28bc7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i16s4i4b1 {
  int a:16;
  short b:4;
  int c:4;
  _Bool d:1;
};
static struct i16s4i4b1 x1 = {-1, 0, 0, 0}; static struct i16s4i4b1 x2 = {-1, -1, 0, 0}; static struct i16s4i4b1 x3 = {-1, 0, -1, 0}; static struct i16s4i4b1 x4 = {-1, -1, -1, -1}; print_prologue("i16s4i4b1", _Alignof(struct i16s4i4b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ic8s3c2 {
  int a;
  char b:8;
  short c:3;
  char d:2;
};
static struct ic8s3c2 x1 = {-1, 0, 0, 0}; static struct ic8s3c2 x2 = {-1, -1, 0, 0}; static struct ic8s3c2 x3 = {-1, 0, -1, 0}; static struct ic8s3c2 x4 = {-1, -1, -1, -1}; print_prologue("ic8s3c2", _Alignof(struct ic8s3c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S1b1i13c1S0i {
  short :1;
  _Bool a:1;
  int b:13;
  char c:1;
  short :0;
  int d;
};
static struct S1b1i13c1S0i x1 = {-1, 0, 0, 0}; static struct S1b1i13c1S0i x2 = {-1, -1, 0, 0}; static struct S1b1i13c1S0i x3 = {-1, 0, -1, 0}; static struct S1b1i13c1S0i x4 = {-1, -1, -1, -1}; print_prologue("S1b1i13c1S0i", _Alignof(struct S1b1i13c1S0i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1c7i32s11 {
  _Bool a:1;
  char b:7;
  int c:32;
  short d:11;
};
static struct b1c7i32s11 x1 = {-1, 0, 0, 0}; static struct b1c7i32s11 x2 = {-1, -1, 0, 0}; static struct b1c7i32s11 x3 = {-1, 0, -1, 0}; static struct b1c7i32s11 x4 = {-1, -1, -1, -1}; print_prologue("b1c7i32s11", _Alignof(struct b1c7i32s11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s2si6 {
  int a:2;
  short b:2;
  short c;
  int d:6;
};
static struct i2s2si6 x1 = {-1, 0, 0, 0}; static struct i2s2si6 x2 = {-1, -1, 0, 0}; static struct i2s2si6 x3 = {-1, 0, -1, 0}; static struct i2s2si6 x4 = {-1, -1, -1, -1}; print_prologue("i2s2si6", _Alignof(struct i2s2si6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1S0c6I3bi14 {
  _Bool a:1;
  short :0;
  char b:6;
  int :3;
  _Bool c;
  int d:14;
};
static struct b1S0c6I3bi14 x1 = {-1, 0, 0, 0}; static struct b1S0c6I3bi14 x2 = {-1, -1, 0, 0}; static struct b1S0c6I3bi14 x3 = {-1, 0, -1, 0}; static struct b1S0c6I3bi14 x4 = {-1, -1, -1, -1}; print_prologue("b1S0c6I3bi14", _Alignof(struct b1S0c6I3bi14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i13I0C0b1i15c3 {
  int a:13;
  int :0;
  char :0;
  _Bool b:1;
  int c:15;
  char d:3;
};
static struct i13I0C0b1i15c3 x1 = {-1, 0, 0, 0}; static struct i13I0C0b1i15c3 x2 = {-1, -1, 0, 0}; static struct i13I0C0b1i15c3 x3 = {-1, 0, -1, 0}; static struct i13I0C0b1i15c3 x4 = {-1, -1, -1, -1}; print_prologue("i13I0C0b1i15c3", _Alignof(struct i13I0C0b1i15c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ss1c1c5 {
  short a;
  short b:1;
  char c:1;
  char d:5;
};
static struct ss1c1c5 x1 = {-1, 0, 0, 0}; static struct ss1c1c5 x2 = {-1, -1, 0, 0}; static struct ss1c1c5 x3 = {-1, 0, -1, 0}; static struct ss1c1c5 x4 = {-1, -1, -1, -1}; print_prologue("ss1c1c5", _Alignof(struct ss1c1c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2i27s2s14 {
  int a:2;
  int b:27;
  short c:2;
  short d:14;
};
static struct i2i27s2s14 x1 = {-1, 0, 0, 0}; static struct i2i27s2s14 x2 = {-1, -1, 0, 0}; static struct i2i27s2s14 x3 = {-1, 0, -1, 0}; static struct i2i27s2s14 x4 = {-1, -1, -1, -1}; print_prologue("i2i27s2s14", _Alignof(struct i2i27s2s14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8s6i30s15 {
  char a:8;
  short b:6;
  int c:30;
  short d:15;
};
static struct c8s6i30s15 x1 = {-1, 0, 0, 0}; static struct c8s6i30s15 x2 = {-1, -1, 0, 0}; static struct c8s6i30s15 x3 = {-1, 0, -1, 0}; static struct c8s6i30s15 x4 = {-1, -1, -1, -1}; print_prologue("c8s6i30s15", _Alignof(struct c8s6i30s15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6si2c5 {
  char a:6;
  short b;
  int c:2;
  char d:5;
};
static struct c6si2c5 x1 = {-1, 0, 0, 0}; static struct c6si2c5 x2 = {-1, -1, 0, 0}; static struct c6si2c5 x3 = {-1, 0, -1, 0}; static struct c6si2c5 x4 = {-1, -1, -1, -1}; print_prologue("c6si2c5", _Alignof(struct c6si2c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I28i14I1i31b1i18 {
  int :28;
  int a:14;
  int :1;
  int b:31;
  _Bool c:1;
  int d:18;
};
static struct I28i14I1i31b1i18 x1 = {-1, 0, 0, 0}; static struct I28i14I1i31b1i18 x2 = {-1, -1, 0, 0}; static struct I28i14I1i31b1i18 x3 = {-1, 0, -1, 0}; static struct I28i14I1i31b1i18 x4 = {-1, -1, -1, -1}; print_prologue("I28i14I1i31b1i18", _Alignof(struct I28i14I1i31b1i18), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1sc1b {
  int a:1;
  short b;
  char c:1;
  _Bool d;
};
static struct i1sc1b x1 = {-1, 0, 0, 0}; static struct i1sc1b x2 = {-1, -1, 0, 0}; static struct i1sc1b x3 = {-1, 0, -1, 0}; static struct i1sc1b x4 = {-1, -1, -1, -1}; print_prologue("i1sc1b", _Alignof(struct i1sc1b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s14i2c1s1 {
  short a:14;
  int b:2;
  char c:1;
  short d:1;
};
static struct s14i2c1s1 x1 = {-1, 0, 0, 0}; static struct s14i2c1s1 x2 = {-1, -1, 0, 0}; static struct s14i2c1s1 x3 = {-1, 0, -1, 0}; static struct s14i2c1s1 x4 = {-1, -1, -1, -1}; print_prologue("s14i2c1s1", _Alignof(struct s14i2c1s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cI9s3S0c7s {
  char a;
  int :9;
  short b:3;
  short :0;
  char c:7;
  short d;
};
static struct cI9s3S0c7s x1 = {-1, 0, 0, 0}; static struct cI9s3S0c7s x2 = {-1, -1, 0, 0}; static struct cI9s3S0c7s x3 = {-1, 0, -1, 0}; static struct cI9s3S0c7s x4 = {-1, -1, -1, -1}; print_prologue("cI9s3S0c7s", _Alignof(struct cI9s3S0c7s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i8ic4c {
  int a:8;
  int b;
  char c:4;
  char d;
};
static struct i8ic4c x1 = {-1, 0, 0, 0}; static struct i8ic4c x2 = {-1, -1, 0, 0}; static struct i8ic4c x3 = {-1, 0, -1, 0}; static struct i8ic4c x4 = {-1, -1, -1, -1}; print_prologue("i8ic4c", _Alignof(struct i8ic4c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S14c1ii27i17 {
  short :14;
  char a:1;
  int b;
  int c:27;
  int d:17;
};
static struct S14c1ii27i17 x1 = {-1, 0, 0, 0}; static struct S14c1ii27i17 x2 = {-1, -1, 0, 0}; static struct S14c1ii27i17 x3 = {-1, 0, -1, 0}; static struct S14c1ii27i17 x4 = {-1, -1, -1, -1}; print_prologue("S14c1ii27i17", _Alignof(struct S14c1ii27i17), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1b1s8s {
  char a:1;
  _Bool b:1;
  short c:8;
  short d;
};
static struct c1b1s8s x1 = {-1, 0, 0, 0}; static struct c1b1s8s x2 = {-1, -1, 0, 0}; static struct c1b1s8s x3 = {-1, 0, -1, 0}; static struct c1b1s8s x4 = {-1, -1, -1, -1}; print_prologue("c1b1s8s", _Alignof(struct c1b1s8s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i6i5s8i14 {
  int a:6;
  int b:5;
  short c:8;
  int d:14;
};
static struct i6i5s8i14 x1 = {-1, 0, 0, 0}; static struct i6i5s8i14 x2 = {-1, -1, 0, 0}; static struct i6i5s8i14 x3 = {-1, 0, -1, 0}; static struct i6i5s8i14 x4 = {-1, -1, -1, -1}; print_prologue("i6i5s8i14", _Alignof(struct i6i5s8i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7i2i1c1 {
  char a:7;
  int b:2;
  int c:1;
  char d:1;
};
static struct c7i2i1c1 x1 = {-1, 0, 0, 0}; static struct c7i2i1c1 x2 = {-1, -1, 0, 0}; static struct c7i2i1c1 x3 = {-1, 0, -1, 0}; static struct c7i2i1c1 x4 = {-1, -1, -1, -1}; print_prologue("c7i2i1c1", _Alignof(struct c7i2i1c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4s3s5I0s {
  short a:4;
  short b:3;
  short c:5;
  int :0;
  short d;
};
static struct s4s3s5I0s x1 = {-1, 0, 0, 0}; static struct s4s3s5I0s x2 = {-1, -1, 0, 0}; static struct s4s3s5I0s x3 = {-1, 0, -1, 0}; static struct s4s3s5I0s x4 = {-1, -1, -1, -1}; print_prologue("s4s3s5I0s", _Alignof(struct s4s3s5I0s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i8cc3c7 {
  int a:8;
  char b;
  char c:3;
  char d:7;
};
static struct i8cc3c7 x1 = {-1, 0, 0, 0}; static struct i8cc3c7 x2 = {-1, -1, 0, 0}; static struct i8cc3c7 x3 = {-1, 0, -1, 0}; static struct i8cc3c7 x4 = {-1, -1, -1, -1}; print_prologue("i8cc3c7", _Alignof(struct i8cc3c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cB1i29b1i4 {
  char a;
  _Bool :1;
  int b:29;
  _Bool c:1;
  int d:4;
};
static struct cB1i29b1i4 x1 = {-1, 0, 0, 0}; static struct cB1i29b1i4 x2 = {-1, -1, 0, 0}; static struct cB1i29b1i4 x3 = {-1, 0, -1, 0}; static struct cB1i29b1i4 x4 = {-1, -1, -1, -1}; print_prologue("cB1i29b1i4", _Alignof(struct cB1i29b1i4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s11s10i2 {
  int a:2;
  short b:11;
  short c:10;
  int d:2;
};
static struct i2s11s10i2 x1 = {-1, 0, 0, 0}; static struct i2s11s10i2 x2 = {-1, -1, 0, 0}; static struct i2s11s10i2 x3 = {-1, 0, -1, 0}; static struct i2s11s10i2 x4 = {-1, -1, -1, -1}; print_prologue("i2s11s10i2", _Alignof(struct i2s11s10i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sc1s1s13 {
  short a;
  char b:1;
  short c:1;
  short d:13;
};
static struct sc1s1s13 x1 = {-1, 0, 0, 0}; static struct sc1s1s13 x2 = {-1, -1, 0, 0}; static struct sc1s1s13 x3 = {-1, 0, -1, 0}; static struct sc1s1s13 x4 = {-1, -1, -1, -1}; print_prologue("sc1s1s13", _Alignof(struct sc1s1s13), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct si7i8i30 {
  short a;
  int b:7;
  int c:8;
  int d:30;
};
static struct si7i8i30 x1 = {-1, 0, 0, 0}; static struct si7i8i30 x2 = {-1, -1, 0, 0}; static struct si7i8i30 x3 = {-1, 0, -1, 0}; static struct si7i8i30 x4 = {-1, -1, -1, -1}; print_prologue("si7i8i30", _Alignof(struct si7i8i30), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1b1i3c {
  _Bool a:1;
  _Bool b:1;
  int c:3;
  char d;
};
static struct b1b1i3c x1 = {-1, 0, 0, 0}; static struct b1b1i3c x2 = {-1, -1, 0, 0}; static struct b1b1i3c x3 = {-1, 0, -1, 0}; static struct b1b1i3c x4 = {-1, -1, -1, -1}; print_prologue("b1b1i3c", _Alignof(struct b1b1i3c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is4i2c {
  int a;
  short b:4;
  int c:2;
  char d;
};
static struct is4i2c x1 = {-1, 0, 0, 0}; static struct is4i2c x2 = {-1, -1, 0, 0}; static struct is4i2c x3 = {-1, 0, -1, 0}; static struct is4i2c x4 = {-1, -1, -1, -1}; print_prologue("is4i2c", _Alignof(struct is4i2c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4i4i9S0b1 {
  char a:4;
  int b:4;
  int c:9;
  short :0;
  _Bool d:1;
};
static struct c4i4i9S0b1 x1 = {-1, 0, 0, 0}; static struct c4i4i9S0b1 x2 = {-1, -1, 0, 0}; static struct c4i4i9S0b1 x3 = {-1, 0, -1, 0}; static struct c4i4i9S0b1 x4 = {-1, -1, -1, -1}; print_prologue("c4i4i9S0b1", _Alignof(struct c4i4i9S0b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1i32s8I1i9 {
  char a:1;
  int b:32;
  short c:8;
  int :1;
  int d:9;
};
static struct c1i32s8I1i9 x1 = {-1, 0, 0, 0}; static struct c1i32s8I1i9 x2 = {-1, -1, 0, 0}; static struct c1i32s8I1i9 x3 = {-1, 0, -1, 0}; static struct c1i32s8I1i9 x4 = {-1, -1, -1, -1}; print_prologue("c1i32s8I1i9", _Alignof(struct c1i32s8I1i9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8i8s3I0I0s12 {
  char a:8;
  int b:8;
  short c:3;
  int :0;
  int :0;
  short d:12;
};
static struct c8i8s3I0I0s12 x1 = {-1, 0, 0, 0}; static struct c8i8s3I0I0s12 x2 = {-1, -1, 0, 0}; static struct c8i8s3I0I0s12 x3 = {-1, 0, -1, 0}; static struct c8i8s3I0I0s12 x4 = {-1, -1, -1, -1}; print_prologue("c8i8s3I0I0s12", _Alignof(struct c8i8s3I0I0s12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1c5i22I12I23i {
  char a:1;
  char b:5;
  int c:22;
  int :12;
  int :23;
  int d;
};
static struct c1c5i22I12I23i x1 = {-1, 0, 0, 0}; static struct c1c5i22I12I23i x2 = {-1, -1, 0, 0}; static struct c1c5i22I12I23i x3 = {-1, 0, -1, 0}; static struct c1c5i22I12I23i x4 = {-1, -1, -1, -1}; print_prologue("c1c5i22I12I23i", _Alignof(struct c1c5i22I12I23i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i28s14cs {
  int a:28;
  short b:14;
  char c;
  short d;
};
static struct i28s14cs x1 = {-1, 0, 0, 0}; static struct i28s14cs x2 = {-1, -1, 0, 0}; static struct i28s14cs x3 = {-1, 0, -1, 0}; static struct i28s14cs x4 = {-1, -1, -1, -1}; print_prologue("i28s14cs", _Alignof(struct i28s14cs), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s11s5i14i {
  short a:11;
  short b:5;
  int c:14;
  int d;
};
static struct s11s5i14i x1 = {-1, 0, 0, 0}; static struct s11s5i14i x2 = {-1, -1, 0, 0}; static struct s11s5i14i x3 = {-1, 0, -1, 0}; static struct s11s5i14i x4 = {-1, -1, -1, -1}; print_prologue("s11s5i14i", _Alignof(struct s11s5i14i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5s2c1c1 {
  char a:5;
  short b:2;
  char c:1;
  char d:1;
};
static struct c5s2c1c1 x1 = {-1, 0, 0, 0}; static struct c5s2c1c1 x2 = {-1, -1, 0, 0}; static struct c5s2c1c1 x3 = {-1, 0, -1, 0}; static struct c5s2c1c1 x4 = {-1, -1, -1, -1}; print_prologue("c5s2c1c1", _Alignof(struct c5s2c1c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii5i14s5 {
  int a;
  int b:5;
  int c:14;
  short d:5;
};
static struct ii5i14s5 x1 = {-1, 0, 0, 0}; static struct ii5i14s5 x2 = {-1, -1, 0, 0}; static struct ii5i14s5 x3 = {-1, 0, -1, 0}; static struct ii5i14s5 x4 = {-1, -1, -1, -1}; print_prologue("ii5i14s5", _Alignof(struct ii5i14s5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2i10i25I0B1I1I7s7 {
  char a:2;
  int b:10;
  int c:25;
  int :0;
  _Bool :1;
  int :1;
  int :7;
  short d:7;
};
static struct c2i10i25I0B1I1I7s7 x1 = {-1, 0, 0, 0}; static struct c2i10i25I0B1I1I7s7 x2 = {-1, -1, 0, 0}; static struct c2i10i25I0B1I1I7s7 x3 = {-1, 0, -1, 0}; static struct c2i10i25I0B1I1I7s7 x4 = {-1, -1, -1, -1}; print_prologue("c2i10i25I0B1I1I7s7", _Alignof(struct c2i10i25I0B1I1I7s7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s14i7i1s8 {
  short a:14;
  int b:7;
  int c:1;
  short d:8;
};
static struct s14i7i1s8 x1 = {-1, 0, 0, 0}; static struct s14i7i1s8 x2 = {-1, -1, 0, 0}; static struct s14i7i1s8 x3 = {-1, 0, -1, 0}; static struct s14i7i1s8 x4 = {-1, -1, -1, -1}; print_prologue("s14i7i1s8", _Alignof(struct s14i7i1s8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cc3i32C0c5 {
  char a;
  char b:3;
  int c:32;
  char :0;
  char d:5;
};
static struct cc3i32C0c5 x1 = {-1, 0, 0, 0}; static struct cc3i32C0c5 x2 = {-1, -1, 0, 0}; static struct cc3i32C0c5 x3 = {-1, 0, -1, 0}; static struct cc3i32C0c5 x4 = {-1, -1, -1, -1}; print_prologue("cc3i32C0c5", _Alignof(struct cc3i32C0c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1s5ic3 {
  _Bool a:1;
  short b:5;
  int c;
  char d:3;
};
static struct b1s5ic3 x1 = {-1, 0, 0, 0}; static struct b1s5ic3 x2 = {-1, -1, 0, 0}; static struct b1s5ic3 x3 = {-1, 0, -1, 0}; static struct b1s5ic3 x4 = {-1, -1, -1, -1}; print_prologue("b1s5ic3", _Alignof(struct b1s5ic3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C0i22s1i14s5 {
  char :0;
  int a:22;
  short b:1;
  int c:14;
  short d:5;
};
static struct C0i22s1i14s5 x1 = {-1, 0, 0, 0}; static struct C0i22s1i14s5 x2 = {-1, -1, 0, 0}; static struct C0i22s1i14s5 x3 = {-1, 0, -1, 0}; static struct C0i22s1i14s5 x4 = {-1, -1, -1, -1}; print_prologue("C0i22s1i14s5", _Alignof(struct C0i22s1i14s5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i4i1c1s {
  int a:4;
  int b:1;
  char c:1;
  short d;
};
static struct i4i1c1s x1 = {-1, 0, 0, 0}; static struct i4i1c1s x2 = {-1, -1, 0, 0}; static struct i4i1c1s x3 = {-1, 0, -1, 0}; static struct i4i1c1s x4 = {-1, -1, -1, -1}; print_prologue("i4i1c1s", _Alignof(struct i4i1c1s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S0iii32i {
  short :0;
  int a;
  int b;
  int c:32;
  int d;
};
static struct S0iii32i x1 = {-1, 0, 0, 0}; static struct S0iii32i x2 = {-1, -1, 0, 0}; static struct S0iii32i x3 = {-1, 0, -1, 0}; static struct S0iii32i x4 = {-1, -1, -1, -1}; print_prologue("S0iii32i", _Alignof(struct S0iii32i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1c8c4 {
  int a;
  _Bool b:1;
  char c:8;
  char d:4;
};
static struct ib1c8c4 x1 = {-1, 0, 0, 0}; static struct ib1c8c4 x2 = {-1, -1, 0, 0}; static struct ib1c8c4 x3 = {-1, 0, -1, 0}; static struct ib1c8c4 x4 = {-1, -1, -1, -1}; print_prologue("ib1c8c4", _Alignof(struct ib1c8c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s11i12i1 {
  int a:2;
  short b:11;
  int c:12;
  int d:1;
};
static struct i2s11i12i1 x1 = {-1, 0, 0, 0}; static struct i2s11i12i1 x2 = {-1, -1, 0, 0}; static struct i2s11i12i1 x3 = {-1, 0, -1, 0}; static struct i2s11i12i1 x4 = {-1, -1, -1, -1}; print_prologue("i2s11i12i1", _Alignof(struct i2s11i12i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2i14i14i30 {
  int a:2;
  int b:14;
  int c:14;
  int d:30;
};
static struct i2i14i14i30 x1 = {-1, 0, 0, 0}; static struct i2i14i14i30 x2 = {-1, -1, 0, 0}; static struct i2i14i14i30 x3 = {-1, 0, -1, 0}; static struct i2i14i14i30 x4 = {-1, -1, -1, -1}; print_prologue("i2i14i14i30", _Alignof(struct i2i14i14i30), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i4c7i6I0c3 {
  int a:4;
  char b:7;
  int c:6;
  int :0;
  char d:3;
};
static struct i4c7i6I0c3 x1 = {-1, 0, 0, 0}; static struct i4c7i6I0c3 x2 = {-1, -1, 0, 0}; static struct i4c7i6I0c3 x3 = {-1, 0, -1, 0}; static struct i4c7i6I0c3 x4 = {-1, -1, -1, -1}; print_prologue("i4c7i6I0c3", _Alignof(struct i4c7i6I0c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is14s1b1 {
  int a;
  short b:14;
  short c:1;
  _Bool d:1;
};
static struct is14s1b1 x1 = {-1, 0, 0, 0}; static struct is14s1b1 x2 = {-1, -1, 0, 0}; static struct is14s1b1 x3 = {-1, 0, -1, 0}; static struct is14s1b1 x4 = {-1, -1, -1, -1}; print_prologue("is14s1b1", _Alignof(struct is14s1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i8i1s16c8 {
  int a:8;
  int b:1;
  short c:16;
  char d:8;
};
static struct i8i1s16c8 x1 = {-1, 0, 0, 0}; static struct i8i1s16c8 x2 = {-1, -1, 0, 0}; static struct i8i1s16c8 x3 = {-1, 0, -1, 0}; static struct i8i1s16c8 x4 = {-1, -1, -1, -1}; print_prologue("i8i1s16c8", _Alignof(struct i8i1s16c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3i2s3s13 {
  char a:3;
  int b:2;
  short c:3;
  short d:13;
};
static struct c3i2s3s13 x1 = {-1, 0, 0, 0}; static struct c3i2s3s13 x2 = {-1, -1, 0, 0}; static struct c3i2s3s13 x3 = {-1, 0, -1, 0}; static struct c3i2s3s13 x4 = {-1, -1, -1, -1}; print_prologue("c3i2s3s13", _Alignof(struct c3i2s3s13), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i29I0i2c1c5 {
  int a:29;
  int :0;
  int b:2;
  char c:1;
  char d:5;
};
static struct i29I0i2c1c5 x1 = {-1, 0, 0, 0}; static struct i29I0i2c1c5 x2 = {-1, -1, 0, 0}; static struct i29I0i2c1c5 x3 = {-1, 0, -1, 0}; static struct i29I0i2c1c5 x4 = {-1, -1, -1, -1}; print_prologue("i29I0i2c1c5", _Alignof(struct i29I0i2c1c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i19i22i23I0i1 {
  int a:19;
  int b:22;
  int c:23;
  int :0;
  int d:1;
};
static struct i19i22i23I0i1 x1 = {-1, 0, 0, 0}; static struct i19i22i23I0i1 x2 = {-1, -1, 0, 0}; static struct i19i22i23I0i1 x3 = {-1, 0, -1, 0}; static struct i19i22i23I0i1 x4 = {-1, -1, -1, -1}; print_prologue("i19i22i23I0i1", _Alignof(struct i19i22i23I0i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S0s3scC6s8 {
  short :0;
  short a:3;
  short b;
  char c;
  char :6;
  short d:8;
};
static struct S0s3scC6s8 x1 = {-1, 0, 0, 0}; static struct S0s3scC6s8 x2 = {-1, -1, 0, 0}; static struct S0s3scC6s8 x3 = {-1, 0, -1, 0}; static struct S0s3scC6s8 x4 = {-1, -1, -1, -1}; print_prologue("S0s3scC6s8", _Alignof(struct S0s3scC6s8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7i7C1s15i5 {
  int a:7;
  int b:7;
  char :1;
  short c:15;
  int d:5;
};
static struct i7i7C1s15i5 x1 = {-1, 0, 0, 0}; static struct i7i7C1s15i5 x2 = {-1, -1, 0, 0}; static struct i7i7C1s15i5 x3 = {-1, 0, -1, 0}; static struct i7i7C1s15i5 x4 = {-1, -1, -1, -1}; print_prologue("i7i7C1s15i5", _Alignof(struct i7i7C1s15i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I1b1ii4i7 {
  int :1;
  _Bool a:1;
  int b;
  int c:4;
  int d:7;
};
static struct I1b1ii4i7 x1 = {-1, 0, 0, 0}; static struct I1b1ii4i7 x2 = {-1, -1, 0, 0}; static struct I1b1ii4i7 x3 = {-1, 0, -1, 0}; static struct I1b1ii4i7 x4 = {-1, -1, -1, -1}; print_prologue("I1b1ii4i7", _Alignof(struct I1b1ii4i7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ci16i7i {
  char a;
  int b:16;
  int c:7;
  int d;
};
static struct ci16i7i x1 = {-1, 0, 0, 0}; static struct ci16i7i x2 = {-1, -1, 0, 0}; static struct ci16i7i x3 = {-1, 0, -1, 0}; static struct ci16i7i x4 = {-1, -1, -1, -1}; print_prologue("ci16i7i", _Alignof(struct ci16i7i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ic1b1c6 {
  int a;
  char b:1;
  _Bool c:1;
  char d:6;
};
static struct ic1b1c6 x1 = {-1, 0, 0, 0}; static struct ic1b1c6 x2 = {-1, -1, 0, 0}; static struct ic1b1c6 x3 = {-1, 0, -1, 0}; static struct ic1b1c6 x4 = {-1, -1, -1, -1}; print_prologue("ic1b1c6", _Alignof(struct ic1b1c6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1cc3c {
  _Bool a:1;
  char b;
  char c:3;
  char d;
};
static struct b1cc3c x1 = {-1, 0, 0, 0}; static struct b1cc3c x2 = {-1, -1, 0, 0}; static struct b1cc3c x3 = {-1, 0, -1, 0}; static struct b1cc3c x4 = {-1, -1, -1, -1}; print_prologue("b1cc3c", _Alignof(struct b1cc3c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7s5ci5 {
  int a:7;
  short b:5;
  char c;
  int d:5;
};
static struct i7s5ci5 x1 = {-1, 0, 0, 0}; static struct i7s5ci5 x2 = {-1, -1, 0, 0}; static struct i7s5ci5 x3 = {-1, 0, -1, 0}; static struct i7s5ci5 x4 = {-1, -1, -1, -1}; print_prologue("i7s5ci5", _Alignof(struct i7s5ci5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3i21i27c5 {
  char a:3;
  int b:21;
  int c:27;
  char d:5;
};
static struct c3i21i27c5 x1 = {-1, 0, 0, 0}; static struct c3i21i27c5 x2 = {-1, -1, 0, 0}; static struct c3i21i27c5 x3 = {-1, 0, -1, 0}; static struct c3i21i27c5 x4 = {-1, -1, -1, -1}; print_prologue("c3i21i27c5", _Alignof(struct c3i21i27c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s3i13s7i {
  short a:3;
  int b:13;
  short c:7;
  int d;
};
static struct s3i13s7i x1 = {-1, 0, 0, 0}; static struct s3i13s7i x2 = {-1, -1, 0, 0}; static struct s3i13s7i x3 = {-1, 0, -1, 0}; static struct s3i13s7i x4 = {-1, -1, -1, -1}; print_prologue("s3i13s7i", _Alignof(struct s3i13s7i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i3S15ii6s7 {
  int a:3;
  short :15;
  int b;
  int c:6;
  short d:7;
};
static struct i3S15ii6s7 x1 = {-1, 0, 0, 0}; static struct i3S15ii6s7 x2 = {-1, -1, 0, 0}; static struct i3S15ii6s7 x3 = {-1, 0, -1, 0}; static struct i3S15ii6s7 x4 = {-1, -1, -1, -1}; print_prologue("i3S15ii6s7", _Alignof(struct i3S15ii6s7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7i3cs8 {
  int a:7;
  int b:3;
  char c;
  short d:8;
};
static struct i7i3cs8 x1 = {-1, 0, 0, 0}; static struct i7i3cs8 x2 = {-1, -1, 0, 0}; static struct i7i3cs8 x3 = {-1, 0, -1, 0}; static struct i7i3cs8 x4 = {-1, -1, -1, -1}; print_prologue("i7i3cs8", _Alignof(struct i7i3cs8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct isci23 {
  int a;
  short b;
  char c;
  int d:23;
};
static struct isci23 x1 = {-1, 0, 0, 0}; static struct isci23 x2 = {-1, -1, 0, 0}; static struct isci23 x3 = {-1, 0, -1, 0}; static struct isci23 x4 = {-1, -1, -1, -1}; print_prologue("isci23", _Alignof(struct isci23), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cs14cb1 {
  char a;
  short b:14;
  char c;
  _Bool d:1;
};
static struct cs14cb1 x1 = {-1, 0, 0, 0}; static struct cs14cb1 x2 = {-1, -1, 0, 0}; static struct cs14cb1 x3 = {-1, 0, -1, 0}; static struct cs14cb1 x4 = {-1, -1, -1, -1}; print_prologue("cs14cb1", _Alignof(struct cs14cb1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8c6cb {
  char a:8;
  char b:6;
  char c;
  _Bool d;
};
static struct c8c6cb x1 = {-1, 0, 0, 0}; static struct c8c6cb x2 = {-1, -1, 0, 0}; static struct c8c6cb x3 = {-1, 0, -1, 0}; static struct c8c6cb x4 = {-1, -1, -1, -1}; print_prologue("c8c6cb", _Alignof(struct c8c6cb), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5ic2i14 {
  char a:5;
  int b;
  char c:2;
  int d:14;
};
static struct c5ic2i14 x1 = {-1, 0, 0, 0}; static struct c5ic2i14 x2 = {-1, -1, 0, 0}; static struct c5ic2i14 x3 = {-1, 0, -1, 0}; static struct c5ic2i14 x4 = {-1, -1, -1, -1}; print_prologue("c5ic2i14", _Alignof(struct c5ic2i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iis3i2 {
  int a;
  int b;
  short c:3;
  int d:2;
};
static struct iis3i2 x1 = {-1, 0, 0, 0}; static struct iis3i2 x2 = {-1, -1, 0, 0}; static struct iis3i2 x3 = {-1, 0, -1, 0}; static struct iis3i2 x4 = {-1, -1, -1, -1}; print_prologue("iis3i2", _Alignof(struct iis3i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5b1c2I15i7 {
  int a:5;
  _Bool b:1;
  char c:2;
  int :15;
  int d:7;
};
static struct i5b1c2I15i7 x1 = {-1, 0, 0, 0}; static struct i5b1c2I15i7 x2 = {-1, -1, 0, 0}; static struct i5b1c2I15i7 x3 = {-1, 0, -1, 0}; static struct i5b1c2I15i7 x4 = {-1, -1, -1, -1}; print_prologue("i5b1c2I15i7", _Alignof(struct i5b1c2I15i7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s6C0i1ib1 {
  short a:6;
  char :0;
  int b:1;
  int c;
  _Bool d:1;
};
static struct s6C0i1ib1 x1 = {-1, 0, 0, 0}; static struct s6C0i1ib1 x2 = {-1, -1, 0, 0}; static struct s6C0i1ib1 x3 = {-1, 0, -1, 0}; static struct s6C0i1ib1 x4 = {-1, -1, -1, -1}; print_prologue("s6C0i1ib1", _Alignof(struct s6C0i1ib1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8ii19i2 {
  char a:8;
  int b;
  int c:19;
  int d:2;
};
static struct c8ii19i2 x1 = {-1, 0, 0, 0}; static struct c8ii19i2 x2 = {-1, -1, 0, 0}; static struct c8ii19i2 x3 = {-1, 0, -1, 0}; static struct c8ii19i2 x4 = {-1, -1, -1, -1}; print_prologue("c8ii19i2", _Alignof(struct c8ii19i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i17b1s8i {
  int a:17;
  _Bool b:1;
  short c:8;
  int d;
};
static struct i17b1s8i x1 = {-1, 0, 0, 0}; static struct i17b1s8i x2 = {-1, -1, 0, 0}; static struct i17b1s8i x3 = {-1, 0, -1, 0}; static struct i17b1s8i x4 = {-1, -1, -1, -1}; print_prologue("i17b1s8i", _Alignof(struct i17b1s8i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1i4b1s6 {
  char a:1;
  int b:4;
  _Bool c:1;
  short d:6;
};
static struct c1i4b1s6 x1 = {-1, 0, 0, 0}; static struct c1i4b1s6 x2 = {-1, -1, 0, 0}; static struct c1i4b1s6 x3 = {-1, 0, -1, 0}; static struct c1i4b1s6 x4 = {-1, -1, -1, -1}; print_prologue("c1i4b1s6", _Alignof(struct c1i4b1s6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7s6cI8c1 {
  char a:7;
  short b:6;
  char c;
  int :8;
  char d:1;
};
static struct c7s6cI8c1 x1 = {-1, 0, 0, 0}; static struct c7s6cI8c1 x2 = {-1, -1, 0, 0}; static struct c7s6cI8c1 x3 = {-1, 0, -1, 0}; static struct c7s6cI8c1 x4 = {-1, -1, -1, -1}; print_prologue("c7s6cI8c1", _Alignof(struct c7s6cI8c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1i12i5c4 {
  int a:1;
  int b:12;
  int c:5;
  char d:4;
};
static struct i1i12i5c4 x1 = {-1, 0, 0, 0}; static struct i1i12i5c4 x2 = {-1, -1, 0, 0}; static struct i1i12i5c4 x3 = {-1, 0, -1, 0}; static struct i1i12i5c4 x4 = {-1, -1, -1, -1}; print_prologue("i1i12i5c4", _Alignof(struct i1i12i5c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii11S16ci {
  int a;
  int b:11;
  short :16;
  char c;
  int d;
};
static struct ii11S16ci x1 = {-1, 0, 0, 0}; static struct ii11S16ci x2 = {-1, -1, 0, 0}; static struct ii11S16ci x3 = {-1, 0, -1, 0}; static struct ii11S16ci x4 = {-1, -1, -1, -1}; print_prologue("ii11S16ci", _Alignof(struct ii11S16ci), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sis8i31 {
  short a;
  int b;
  short c:8;
  int d:31;
};
static struct sis8i31 x1 = {-1, 0, 0, 0}; static struct sis8i31 x2 = {-1, -1, 0, 0}; static struct sis8i31 x3 = {-1, 0, -1, 0}; static struct sis8i31 x4 = {-1, -1, -1, -1}; print_prologue("sis8i31", _Alignof(struct sis8i31), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1s5s14 {
  int a;
  _Bool b:1;
  short c:5;
  short d:14;
};
static struct ib1s5s14 x1 = {-1, 0, 0, 0}; static struct ib1s5s14 x2 = {-1, -1, 0, 0}; static struct ib1s5s14 x3 = {-1, 0, -1, 0}; static struct ib1s5s14 x4 = {-1, -1, -1, -1}; print_prologue("ib1s5s14", _Alignof(struct ib1s5s14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2c3s7b {
  int a:2;
  char b:3;
  short c:7;
  _Bool d;
};
static struct i2c3s7b x1 = {-1, 0, 0, 0}; static struct i2c3s7b x2 = {-1, -1, 0, 0}; static struct i2c3s7b x3 = {-1, 0, -1, 0}; static struct i2c3s7b x4 = {-1, -1, -1, -1}; print_prologue("i2c3s7b", _Alignof(struct i2c3s7b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i6c3b {
  _Bool a:1;
  int b:6;
  char c:3;
  _Bool d;
};
static struct b1i6c3b x1 = {-1, 0, 0, 0}; static struct b1i6c3b x2 = {-1, -1, 0, 0}; static struct b1i6c3b x3 = {-1, 0, -1, 0}; static struct b1i6c3b x4 = {-1, -1, -1, -1}; print_prologue("b1i6c3b", _Alignof(struct b1i6c3b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0b1s9c2c {
  int :0;
  _Bool a:1;
  short b:9;
  char c:2;
  char d;
};
static struct I0b1s9c2c x1 = {-1, 0, 0, 0}; static struct I0b1s9c2c x2 = {-1, -1, 0, 0}; static struct I0b1s9c2c x3 = {-1, 0, -1, 0}; static struct I0b1s9c2c x4 = {-1, -1, -1, -1}; print_prologue("I0b1s9c2c", _Alignof(struct I0b1s9c2c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1s7i3i31 {
  _Bool a:1;
  short b:7;
  int c:3;
  int d:31;
};
static struct b1s7i3i31 x1 = {-1, 0, 0, 0}; static struct b1s7i3i31 x2 = {-1, -1, 0, 0}; static struct b1s7i3i31 x3 = {-1, 0, -1, 0}; static struct b1s7i3i31 x4 = {-1, -1, -1, -1}; print_prologue("b1s7i3i31", _Alignof(struct b1s7i3i31), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s3ii9i2 {
  short a:3;
  int b;
  int c:9;
  int d:2;
};
static struct s3ii9i2 x1 = {-1, 0, 0, 0}; static struct s3ii9i2 x2 = {-1, -1, 0, 0}; static struct s3ii9i2 x3 = {-1, 0, -1, 0}; static struct s3ii9i2 x4 = {-1, -1, -1, -1}; print_prologue("s3ii9i2", _Alignof(struct s3ii9i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cI29i27iI0b1 {
  char a;
  int :29;
  int b:27;
  int c;
  int :0;
  _Bool d:1;
};
static struct cI29i27iI0b1 x1 = {-1, 0, 0, 0}; static struct cI29i27iI0b1 x2 = {-1, -1, 0, 0}; static struct cI29i27iI0b1 x3 = {-1, 0, -1, 0}; static struct cI29i27iI0b1 x4 = {-1, -1, -1, -1}; print_prologue("cI29i27iI0b1", _Alignof(struct cI29i27iI0b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1ssI14s5 {
  _Bool a:1;
  short b;
  short c;
  int :14;
  short d:5;
};
static struct b1ssI14s5 x1 = {-1, 0, 0, 0}; static struct b1ssI14s5 x2 = {-1, -1, 0, 0}; static struct b1ssI14s5 x3 = {-1, 0, -1, 0}; static struct b1ssI14s5 x4 = {-1, -1, -1, -1}; print_prologue("b1ssI14s5", _Alignof(struct b1ssI14s5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct csi2s {
  char a;
  short b;
  int c:2;
  short d;
};
static struct csi2s x1 = {-1, 0, 0, 0}; static struct csi2s x2 = {-1, -1, 0, 0}; static struct csi2s x3 = {-1, 0, -1, 0}; static struct csi2s x4 = {-1, -1, -1, -1}; print_prologue("csi2s", _Alignof(struct csi2s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I5bs10c8s7 {
  int :5;
  _Bool a;
  short b:10;
  char c:8;
  short d:7;
};
static struct I5bs10c8s7 x1 = {-1, 0, 0, 0}; static struct I5bs10c8s7 x2 = {-1, -1, 0, 0}; static struct I5bs10c8s7 x3 = {-1, 0, -1, 0}; static struct I5bs10c8s7 x4 = {-1, -1, -1, -1}; print_prologue("I5bs10c8s7", _Alignof(struct I5bs10c8s7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7i1I28i15I0C0i6 {
  char a:7;
  int b:1;
  int :28;
  int c:15;
  int :0;
  char :0;
  int d:6;
};
static struct c7i1I28i15I0C0i6 x1 = {-1, 0, 0, 0}; static struct c7i1I28i15I0C0i6 x2 = {-1, -1, 0, 0}; static struct c7i1I28i15I0C0i6 x3 = {-1, 0, -1, 0}; static struct c7i1I28i15I0C0i6 x4 = {-1, -1, -1, -1}; print_prologue("c7i1I28i15I0C0i6", _Alignof(struct c7i1I28i15I0C0i6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2i16s5b1 {
  int a:2;
  int b:16;
  short c:5;
  _Bool d:1;
};
static struct i2i16s5b1 x1 = {-1, 0, 0, 0}; static struct i2i16s5b1 x2 = {-1, -1, 0, 0}; static struct i2i16s5b1 x3 = {-1, 0, -1, 0}; static struct i2i16s5b1 x4 = {-1, -1, -1, -1}; print_prologue("i2i16s5b1", _Alignof(struct i2i16s5b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1i2i {
  int a;
  _Bool b:1;
  int c:2;
  int d;
};
static struct ib1i2i x1 = {-1, 0, 0, 0}; static struct ib1i2i x2 = {-1, -1, 0, 0}; static struct ib1i2i x3 = {-1, 0, -1, 0}; static struct ib1i2i x4 = {-1, -1, -1, -1}; print_prologue("ib1i2i", _Alignof(struct ib1i2i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8b1i26I0c1 {
  char a:8;
  _Bool b:1;
  int c:26;
  int :0;
  char d:1;
};
static struct c8b1i26I0c1 x1 = {-1, 0, 0, 0}; static struct c8b1i26I0c1 x2 = {-1, -1, 0, 0}; static struct c8b1i26I0c1 x3 = {-1, 0, -1, 0}; static struct c8b1i26I0c1 x4 = {-1, -1, -1, -1}; print_prologue("c8b1i26I0c1", _Alignof(struct c8b1i26I0c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i10c1sc1 {
  int a:10;
  char b:1;
  short c;
  char d:1;
};
static struct i10c1sc1 x1 = {-1, 0, 0, 0}; static struct i10c1sc1 x2 = {-1, -1, 0, 0}; static struct i10c1sc1 x3 = {-1, 0, -1, 0}; static struct i10c1sc1 x4 = {-1, -1, -1, -1}; print_prologue("i10c1sc1", _Alignof(struct i10c1sc1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2i4c8I12s9 {
  int a:2;
  int b:4;
  char c:8;
  int :12;
  short d:9;
};
static struct i2i4c8I12s9 x1 = {-1, 0, 0, 0}; static struct i2i4c8I12s9 x2 = {-1, -1, 0, 0}; static struct i2i4c8I12s9 x3 = {-1, 0, -1, 0}; static struct i2i4c8I12s9 x4 = {-1, -1, -1, -1}; print_prologue("i2i4c8I12s9", _Alignof(struct i2i4c8I12s9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C0c2i9i4b1 {
  char :0;
  char a:2;
  int b:9;
  int c:4;
  _Bool d:1;
};
static struct C0c2i9i4b1 x1 = {-1, 0, 0, 0}; static struct C0c2i9i4b1 x2 = {-1, -1, 0, 0}; static struct C0c2i9i4b1 x3 = {-1, 0, -1, 0}; static struct C0c2i9i4b1 x4 = {-1, -1, -1, -1}; print_prologue("C0c2i9i4b1", _Alignof(struct C0c2i9i4b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C0ic2ib1 {
  char :0;
  int a;
  char b:2;
  int c;
  _Bool d:1;
};
static struct C0ic2ib1 x1 = {-1, 0, 0, 0}; static struct C0ic2ib1 x2 = {-1, -1, 0, 0}; static struct C0ic2ib1 x3 = {-1, 0, -1, 0}; static struct C0ic2ib1 x4 = {-1, -1, -1, -1}; print_prologue("C0ic2ib1", _Alignof(struct C0ic2ib1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4s5i2i {
  short a:4;
  short b:5;
  int c:2;
  int d;
};
static struct s4s5i2i x1 = {-1, 0, 0, 0}; static struct s4s5i2i x2 = {-1, -1, 0, 0}; static struct s4s5i2i x3 = {-1, 0, -1, 0}; static struct s4s5i2i x4 = {-1, -1, -1, -1}; print_prologue("s4s5i2i", _Alignof(struct s4s5i2i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i25c3i11c {
  int a:25;
  char b:3;
  int c:11;
  char d;
};
static struct i25c3i11c x1 = {-1, 0, 0, 0}; static struct i25c3i11c x2 = {-1, -1, 0, 0}; static struct i25c3i11c x3 = {-1, 0, -1, 0}; static struct i25c3i11c x4 = {-1, -1, -1, -1}; print_prologue("i25c3i11c", _Alignof(struct i25c3i11c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i17i8i25c {
  int a:17;
  int b:8;
  int c:25;
  char d;
};
static struct i17i8i25c x1 = {-1, 0, 0, 0}; static struct i17i8i25c x2 = {-1, -1, 0, 0}; static struct i17i8i25c x3 = {-1, 0, -1, 0}; static struct i17i8i25c x4 = {-1, -1, -1, -1}; print_prologue("i17i8i25c", _Alignof(struct i17i8i25c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I3is5c4c6 {
  int :3;
  int a;
  short b:5;
  char c:4;
  char d:6;
};
static struct I3is5c4c6 x1 = {-1, 0, 0, 0}; static struct I3is5c4c6 x2 = {-1, -1, 0, 0}; static struct I3is5c4c6 x3 = {-1, 0, -1, 0}; static struct I3is5c4c6 x4 = {-1, -1, -1, -1}; print_prologue("I3is5c4c6", _Alignof(struct I3is5c4c6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7i7s16s {
  char a:7;
  int b:7;
  short c:16;
  short d;
};
static struct c7i7s16s x1 = {-1, 0, 0, 0}; static struct c7i7s16s x2 = {-1, -1, 0, 0}; static struct c7i7s16s x3 = {-1, 0, -1, 0}; static struct c7i7s16s x4 = {-1, -1, -1, -1}; print_prologue("c7i7s16s", _Alignof(struct c7i7s16s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sc5i1i11 {
  short a;
  char b:5;
  int c:1;
  int d:11;
};
static struct sc5i1i11 x1 = {-1, 0, 0, 0}; static struct sc5i1i11 x2 = {-1, -1, 0, 0}; static struct sc5i1i11 x3 = {-1, 0, -1, 0}; static struct sc5i1i11 x4 = {-1, -1, -1, -1}; print_prologue("sc5i1i11", _Alignof(struct sc5i1i11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i14s7s11s7 {
  int a:14;
  short b:7;
  short c:11;
  short d:7;
};
static struct i14s7s11s7 x1 = {-1, 0, 0, 0}; static struct i14s7s11s7 x2 = {-1, -1, 0, 0}; static struct i14s7s11s7 x3 = {-1, 0, -1, 0}; static struct i14s7s11s7 x4 = {-1, -1, -1, -1}; print_prologue("i14s7s11s7", _Alignof(struct i14s7s11s7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ci1c1c1 {
  char a;
  int b:1;
  char c:1;
  char d:1;
};
static struct ci1c1c1 x1 = {-1, 0, 0, 0}; static struct ci1c1c1 x2 = {-1, -1, 0, 0}; static struct ci1c1c1 x3 = {-1, 0, -1, 0}; static struct ci1c1c1 x4 = {-1, -1, -1, -1}; print_prologue("ci1c1c1", _Alignof(struct ci1c1c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s12C1s7c5s11 {
  short a:12;
  char :1;
  short b:7;
  char c:5;
  short d:11;
};
static struct s12C1s7c5s11 x1 = {-1, 0, 0, 0}; static struct s12C1s7c5s11 x2 = {-1, -1, 0, 0}; static struct s12C1s7c5s11 x3 = {-1, 0, -1, 0}; static struct s12C1s7c5s11 x4 = {-1, -1, -1, -1}; print_prologue("s12C1s7c5s11", _Alignof(struct s12C1s7c5s11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i9cC2ss8 {
  int a:9;
  char b;
  char :2;
  short c;
  short d:8;
};
static struct i9cC2ss8 x1 = {-1, 0, 0, 0}; static struct i9cC2ss8 x2 = {-1, -1, 0, 0}; static struct i9cC2ss8 x3 = {-1, 0, -1, 0}; static struct i9cC2ss8 x4 = {-1, -1, -1, -1}; print_prologue("i9cC2ss8", _Alignof(struct i9cC2ss8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2cb1s16 {
  char a:2;
  char b;
  _Bool c:1;
  short d:16;
};
static struct c2cb1s16 x1 = {-1, 0, 0, 0}; static struct c2cb1s16 x2 = {-1, -1, 0, 0}; static struct c2cb1s16 x3 = {-1, 0, -1, 0}; static struct c2cb1s16 x4 = {-1, -1, -1, -1}; print_prologue("c2cb1s16", _Alignof(struct c2cb1s16), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1S0s12b1i6 {
  _Bool a:1;
  short :0;
  short b:12;
  _Bool c:1;
  int d:6;
};
static struct b1S0s12b1i6 x1 = {-1, 0, 0, 0}; static struct b1S0s12b1i6 x2 = {-1, -1, 0, 0}; static struct b1S0s12b1i6 x3 = {-1, 0, -1, 0}; static struct b1S0s12b1i6 x4 = {-1, -1, -1, -1}; print_prologue("b1S0s12b1i6", _Alignof(struct b1S0s12b1i6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i14i14i9s1 {
  int a:14;
  int b:14;
  int c:9;
  short d:1;
};
static struct i14i14i9s1 x1 = {-1, 0, 0, 0}; static struct i14i14i9s1 x2 = {-1, -1, 0, 0}; static struct i14i14i9s1 x3 = {-1, 0, -1, 0}; static struct i14i14i9s1 x4 = {-1, -1, -1, -1}; print_prologue("i14i14i9s1", _Alignof(struct i14i14i9s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cc6cB0i7 {
  char a;
  char b:6;
  char c;
  _Bool :0;
  int d:7;
};
static struct cc6cB0i7 x1 = {-1, 0, 0, 0}; static struct cc6cB0i7 x2 = {-1, -1, 0, 0}; static struct cc6cB0i7 x3 = {-1, 0, -1, 0}; static struct cc6cB0i7 x4 = {-1, -1, -1, -1}; print_prologue("cc6cB0i7", _Alignof(struct cc6cB0i7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0b1i32c8b1 {
  int :0;
  _Bool a:1;
  int b:32;
  char c:8;
  _Bool d:1;
};
static struct I0b1i32c8b1 x1 = {-1, 0, 0, 0}; static struct I0b1i32c8b1 x2 = {-1, -1, 0, 0}; static struct I0b1i32c8b1 x3 = {-1, 0, -1, 0}; static struct I0b1i32c8b1 x4 = {-1, -1, -1, -1}; print_prologue("I0b1i32c8b1", _Alignof(struct I0b1i32c8b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1i4I0s4i16 {
  int a:1;
  int b:4;
  int :0;
  short c:4;
  int d:16;
};
static struct i1i4I0s4i16 x1 = {-1, 0, 0, 0}; static struct i1i4I0s4i16 x2 = {-1, -1, 0, 0}; static struct i1i4I0s4i16 x3 = {-1, 0, -1, 0}; static struct i1i4I0s4i16 x4 = {-1, -1, -1, -1}; print_prologue("i1i4I0s4i16", _Alignof(struct i1i4I0s4i16), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3I0B1c4sb {
  char a:3;
  int :0;
  _Bool :1;
  char b:4;
  short c;
  _Bool d;
};
static struct c3I0B1c4sb x1 = {-1, 0, 0, 0}; static struct c3I0B1c4sb x2 = {-1, -1, 0, 0}; static struct c3I0B1c4sb x3 = {-1, 0, -1, 0}; static struct c3I0B1c4sb x4 = {-1, -1, -1, -1}; print_prologue("c3I0B1c4sb", _Alignof(struct c3I0B1c4sb), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i25i6i5s1 {
  int a:25;
  int b:6;
  int c:5;
  short d:1;
};
static struct i25i6i5s1 x1 = {-1, 0, 0, 0}; static struct i25i6i5s1 x2 = {-1, -1, 0, 0}; static struct i25i6i5s1 x3 = {-1, 0, -1, 0}; static struct i25i6i5s1 x4 = {-1, -1, -1, -1}; print_prologue("i25i6i5s1", _Alignof(struct i25i6i5s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1ic6s1 {
  int a:1;
  int b;
  char c:6;
  short d:1;
};
static struct i1ic6s1 x1 = {-1, 0, 0, 0}; static struct i1ic6s1 x2 = {-1, -1, 0, 0}; static struct i1ic6s1 x3 = {-1, 0, -1, 0}; static struct i1ic6s1 x4 = {-1, -1, -1, -1}; print_prologue("i1ic6s1", _Alignof(struct i1ic6s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i3b1s7s5 {
  int a:3;
  _Bool b:1;
  short c:7;
  short d:5;
};
static struct i3b1s7s5 x1 = {-1, 0, 0, 0}; static struct i3b1s7s5 x2 = {-1, -1, 0, 0}; static struct i3b1s7s5 x3 = {-1, 0, -1, 0}; static struct i3b1s7s5 x4 = {-1, -1, -1, -1}; print_prologue("i3b1s7s5", _Alignof(struct i3b1s7s5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s13i13s4 {
  int a:2;
  short b:13;
  int c:13;
  short d:4;
};
static struct i2s13i13s4 x1 = {-1, 0, 0, 0}; static struct i2s13i13s4 x2 = {-1, -1, 0, 0}; static struct i2s13i13s4 x3 = {-1, 0, -1, 0}; static struct i2s13i13s4 x4 = {-1, -1, -1, -1}; print_prologue("i2s13i13s4", _Alignof(struct i2s13i13s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iii11s {
  int a;
  int b;
  int c:11;
  short d;
};
static struct iii11s x1 = {-1, 0, 0, 0}; static struct iii11s x2 = {-1, -1, 0, 0}; static struct iii11s x3 = {-1, 0, -1, 0}; static struct iii11s x4 = {-1, -1, -1, -1}; print_prologue("iii11s", _Alignof(struct iii11s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s2i27s1 {
  int a:2;
  short b:2;
  int c:27;
  short d:1;
};
static struct i2s2i27s1 x1 = {-1, 0, 0, 0}; static struct i2s2i27s1 x2 = {-1, -1, 0, 0}; static struct i2s2i27s1 x3 = {-1, 0, -1, 0}; static struct i2s2i27s1 x4 = {-1, -1, -1, -1}; print_prologue("i2s2i27s1", _Alignof(struct i2s2i27s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct si1i22i1 {
  short a;
  int b:1;
  int c:22;
  int d:1;
};
static struct si1i22i1 x1 = {-1, 0, 0, 0}; static struct si1i22i1 x2 = {-1, -1, 0, 0}; static struct si1i22i1 x3 = {-1, 0, -1, 0}; static struct si1i22i1 x4 = {-1, -1, -1, -1}; print_prologue("si1i22i1", _Alignof(struct si1i22i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s7I2b1c7i29 {
  short a:7;
  int :2;
  _Bool b:1;
  char c:7;
  int d:29;
};
static struct s7I2b1c7i29 x1 = {-1, 0, 0, 0}; static struct s7I2b1c7i29 x2 = {-1, -1, 0, 0}; static struct s7I2b1c7i29 x3 = {-1, 0, -1, 0}; static struct s7I2b1c7i29 x4 = {-1, -1, -1, -1}; print_prologue("s7I2b1c7i29", _Alignof(struct s7I2b1c7i29), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C0i11I0B0ii2c3 {
  char :0;
  int a:11;
  int :0;
  _Bool :0;
  int b;
  int c:2;
  char d:3;
};
static struct C0i11I0B0ii2c3 x1 = {-1, 0, 0, 0}; static struct C0i11I0B0ii2c3 x2 = {-1, -1, 0, 0}; static struct C0i11I0B0ii2c3 x3 = {-1, 0, -1, 0}; static struct C0i11I0B0ii2c3 x4 = {-1, -1, -1, -1}; print_prologue("C0i11I0B0ii2c3", _Alignof(struct C0i11I0B0ii2c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cb1I7i8i22 {
  char a;
  _Bool b:1;
  int :7;
  int c:8;
  int d:22;
};
static struct cb1I7i8i22 x1 = {-1, 0, 0, 0}; static struct cb1I7i8i22 x2 = {-1, -1, 0, 0}; static struct cb1I7i8i22 x3 = {-1, 0, -1, 0}; static struct cb1I7i8i22 x4 = {-1, -1, -1, -1}; print_prologue("cb1I7i8i22", _Alignof(struct cb1I7i8i22), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s12b1bi {
  short a:12;
  _Bool b:1;
  _Bool c;
  int d;
};
static struct s12b1bi x1 = {-1, 0, 0, 0}; static struct s12b1bi x2 = {-1, -1, 0, 0}; static struct s12b1bi x3 = {-1, 0, -1, 0}; static struct s12b1bi x4 = {-1, -1, -1, -1}; print_prologue("s12b1bi", _Alignof(struct s12b1bi), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I1i11c5s9C0i24 {
  int :1;
  int a:11;
  char b:5;
  short c:9;
  char :0;
  int d:24;
};
static struct I1i11c5s9C0i24 x1 = {-1, 0, 0, 0}; static struct I1i11c5s9C0i24 x2 = {-1, -1, 0, 0}; static struct I1i11c5s9C0i24 x3 = {-1, 0, -1, 0}; static struct I1i11c5s9C0i24 x4 = {-1, -1, -1, -1}; print_prologue("I1i11c5s9C0i24", _Alignof(struct I1i11c5s9C0i24), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i32cc3 {
  _Bool a:1;
  int b:32;
  char c;
  char d:3;
};
static struct b1i32cc3 x1 = {-1, 0, 0, 0}; static struct b1i32cc3 x2 = {-1, -1, 0, 0}; static struct b1i32cc3 x3 = {-1, 0, -1, 0}; static struct b1i32cc3 x4 = {-1, -1, -1, -1}; print_prologue("b1i32cc3", _Alignof(struct b1i32cc3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2c2c4i5 {
  char a:2;
  char b:2;
  char c:4;
  int d:5;
};
static struct c2c2c4i5 x1 = {-1, 0, 0, 0}; static struct c2c2c4i5 x2 = {-1, -1, 0, 0}; static struct c2c2c4i5 x3 = {-1, 0, -1, 0}; static struct c2c2c4i5 x4 = {-1, -1, -1, -1}; print_prologue("c2c2c4i5", _Alignof(struct c2c2c4i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C5c6I22c3I0sI0i {
  char :5;
  char a:6;
  int :22;
  char b:3;
  int :0;
  short c;
  int :0;
  int d;
};
static struct C5c6I22c3I0sI0i x1 = {-1, 0, 0, 0}; static struct C5c6I22c3I0sI0i x2 = {-1, -1, 0, 0}; static struct C5c6I22c3I0sI0i x3 = {-1, 0, -1, 0}; static struct C5c6I22c3I0sI0i x4 = {-1, -1, -1, -1}; print_prologue("C5c6I22c3I0sI0i", _Alignof(struct C5c6I22c3I0sI0i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8c2i2i10 {
  char a:8;
  char b:2;
  int c:2;
  int d:10;
};
static struct c8c2i2i10 x1 = {-1, 0, 0, 0}; static struct c8c2i2i10 x2 = {-1, -1, 0, 0}; static struct c8c2i2i10 x3 = {-1, 0, -1, 0}; static struct c8c2i2i10 x4 = {-1, -1, -1, -1}; print_prologue("c8c2i2i10", _Alignof(struct c8c2i2i10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s10I0s6i12s3 {
  short a:10;
  int :0;
  short b:6;
  int c:12;
  short d:3;
};
static struct s10I0s6i12s3 x1 = {-1, 0, 0, 0}; static struct s10I0s6i12s3 x2 = {-1, -1, 0, 0}; static struct s10I0s6i12s3 x3 = {-1, 0, -1, 0}; static struct s10I0s6i12s3 x4 = {-1, -1, -1, -1}; print_prologue("s10I0s6i12s3", _Alignof(struct s10I0s6i12s3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1i3is2 {
  short a:1;
  int b:3;
  int c;
  short d:2;
};
static struct s1i3is2 x1 = {-1, 0, 0, 0}; static struct s1i3is2 x2 = {-1, -1, 0, 0}; static struct s1i3is2 x3 = {-1, 0, -1, 0}; static struct s1i3is2 x4 = {-1, -1, -1, -1}; print_prologue("s1i3is2", _Alignof(struct s1i3is2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1s1i27I26c {
  _Bool a:1;
  short b:1;
  int c:27;
  int :26;
  char d;
};
static struct b1s1i27I26c x1 = {-1, 0, 0, 0}; static struct b1s1i27I26c x2 = {-1, -1, 0, 0}; static struct b1s1i27I26c x3 = {-1, 0, -1, 0}; static struct b1s1i27I26c x4 = {-1, -1, -1, -1}; print_prologue("b1s1i27I26c", _Alignof(struct b1s1i27I26c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i12i22ss6 {
  int a:12;
  int b:22;
  short c;
  short d:6;
};
static struct i12i22ss6 x1 = {-1, 0, 0, 0}; static struct i12i22ss6 x2 = {-1, -1, 0, 0}; static struct i12i22ss6 x3 = {-1, 0, -1, 0}; static struct i12i22ss6 x4 = {-1, -1, -1, -1}; print_prologue("i12i22ss6", _Alignof(struct i12i22ss6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s7i21ii27 {
  short a:7;
  int b:21;
  int c;
  int d:27;
};
static struct s7i21ii27 x1 = {-1, 0, 0, 0}; static struct s7i21ii27 x2 = {-1, -1, 0, 0}; static struct s7i21ii27 x3 = {-1, 0, -1, 0}; static struct s7i21ii27 x4 = {-1, -1, -1, -1}; print_prologue("s7i21ii27", _Alignof(struct s7i21ii27), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1c1i15C0b {
  int a:1;
  char b:1;
  int c:15;
  char :0;
  _Bool d;
};
static struct i1c1i15C0b x1 = {-1, 0, 0, 0}; static struct i1c1i15C0b x2 = {-1, -1, 0, 0}; static struct i1c1i15C0b x3 = {-1, 0, -1, 0}; static struct i1c1i15C0b x4 = {-1, -1, -1, -1}; print_prologue("i1c1i15C0b", _Alignof(struct i1c1i15C0b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5s5c3c5 {
  char a:5;
  short b:5;
  char c:3;
  char d:5;
};
static struct c5s5c3c5 x1 = {-1, 0, 0, 0}; static struct c5s5c3c5 x2 = {-1, -1, 0, 0}; static struct c5s5c3c5 x3 = {-1, 0, -1, 0}; static struct c5s5c3c5 x4 = {-1, -1, -1, -1}; print_prologue("c5s5c3c5", _Alignof(struct c5s5c3c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1c4bs2 {
  _Bool a:1;
  char b:4;
  _Bool c;
  short d:2;
};
static struct b1c4bs2 x1 = {-1, 0, 0, 0}; static struct b1c4bs2 x2 = {-1, -1, 0, 0}; static struct b1c4bs2 x3 = {-1, 0, -1, 0}; static struct b1c4bs2 x4 = {-1, -1, -1, -1}; print_prologue("b1c4bs2", _Alignof(struct b1c4bs2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii1b1c8 {
  int a;
  int b:1;
  _Bool c:1;
  char d:8;
};
static struct ii1b1c8 x1 = {-1, 0, 0, 0}; static struct ii1b1c8 x2 = {-1, -1, 0, 0}; static struct ii1b1c8 x3 = {-1, 0, -1, 0}; static struct ii1b1c8 x4 = {-1, -1, -1, -1}; print_prologue("ii1b1c8", _Alignof(struct ii1b1c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4c5si31 {
  char a:4;
  char b:5;
  short c;
  int d:31;
};
static struct c4c5si31 x1 = {-1, 0, 0, 0}; static struct c4c5si31 x2 = {-1, -1, 0, 0}; static struct c4c5si31 x3 = {-1, 0, -1, 0}; static struct c4c5si31 x4 = {-1, -1, -1, -1}; print_prologue("c4c5si31", _Alignof(struct c4c5si31), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ss13ss1 {
  short a;
  short b:13;
  short c;
  short d:1;
};
static struct ss13ss1 x1 = {-1, 0, 0, 0}; static struct ss13ss1 x2 = {-1, -1, 0, 0}; static struct ss13ss1 x3 = {-1, 0, -1, 0}; static struct ss13ss1 x4 = {-1, -1, -1, -1}; print_prologue("ss13ss1", _Alignof(struct ss13ss1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s8C1C0s4iC7i15 {
  short a:8;
  char :1;
  char :0;
  short b:4;
  int c;
  char :7;
  int d:15;
};
static struct s8C1C0s4iC7i15 x1 = {-1, 0, 0, 0}; static struct s8C1C0s4iC7i15 x2 = {-1, -1, 0, 0}; static struct s8C1C0s4iC7i15 x3 = {-1, 0, -1, 0}; static struct s8C1C0s4iC7i15 x4 = {-1, -1, -1, -1}; print_prologue("s8C1C0s4iC7i15", _Alignof(struct s8C1C0s4iC7i15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0i12b1i28i5 {
  int :0;
  int a:12;
  _Bool b:1;
  int c:28;
  int d:5;
};
static struct I0i12b1i28i5 x1 = {-1, 0, 0, 0}; static struct I0i12b1i28i5 x2 = {-1, -1, 0, 0}; static struct I0i12b1i28i5 x3 = {-1, 0, -1, 0}; static struct I0i12b1i28i5 x4 = {-1, -1, -1, -1}; print_prologue("I0i12b1i28i5", _Alignof(struct I0i12b1i28i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s5s15s12 {
  int a:2;
  short b:5;
  short c:15;
  short d:12;
};
static struct i2s5s15s12 x1 = {-1, 0, 0, 0}; static struct i2s5s15s12 x2 = {-1, -1, 0, 0}; static struct i2s5s15s12 x3 = {-1, 0, -1, 0}; static struct i2s5s15s12 x4 = {-1, -1, -1, -1}; print_prologue("i2s5s15s12", _Alignof(struct i2s5s15s12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s5s11i6i1 {
  short a:5;
  short b:11;
  int c:6;
  int d:1;
};
static struct s5s11i6i1 x1 = {-1, 0, 0, 0}; static struct s5s11i6i1 x2 = {-1, -1, 0, 0}; static struct s5s11i6i1 x3 = {-1, 0, -1, 0}; static struct s5s11i6i1 x4 = {-1, -1, -1, -1}; print_prologue("s5s11i6i1", _Alignof(struct s5s11i6i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s2s4s5 {
  int a:2;
  short b:2;
  short c:4;
  short d:5;
};
static struct i2s2s4s5 x1 = {-1, 0, 0, 0}; static struct i2s2s4s5 x2 = {-1, -1, 0, 0}; static struct i2s2s4s5 x3 = {-1, 0, -1, 0}; static struct i2s2s4s5 x4 = {-1, -1, -1, -1}; print_prologue("i2s2s4s5", _Alignof(struct i2s2s4s5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4i5sc8 {
  short a:4;
  int b:5;
  short c;
  char d:8;
};
static struct s4i5sc8 x1 = {-1, 0, 0, 0}; static struct s4i5sc8 x2 = {-1, -1, 0, 0}; static struct s4i5sc8 x3 = {-1, 0, -1, 0}; static struct s4i5sc8 x4 = {-1, -1, -1, -1}; print_prologue("s4i5sc8", _Alignof(struct s4i5sc8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s3i22i1i20 {
  short a:3;
  int b:22;
  int c:1;
  int d:20;
};
static struct s3i22i1i20 x1 = {-1, 0, 0, 0}; static struct s3i22i1i20 x2 = {-1, -1, 0, 0}; static struct s3i22i1i20 x3 = {-1, 0, -1, 0}; static struct s3i22i1i20 x4 = {-1, -1, -1, -1}; print_prologue("s3i22i1i20", _Alignof(struct s3i22i1i20), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4iic5 {
  char a:4;
  int b;
  int c;
  char d:5;
};
static struct c4iic5 x1 = {-1, 0, 0, 0}; static struct c4iic5 x2 = {-1, -1, 0, 0}; static struct c4iic5 x3 = {-1, 0, -1, 0}; static struct c4iic5 x4 = {-1, -1, -1, -1}; print_prologue("c4iic5", _Alignof(struct c4iic5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s7i25i12i2 {
  short a:7;
  int b:25;
  int c:12;
  int d:2;
};
static struct s7i25i12i2 x1 = {-1, 0, 0, 0}; static struct s7i25i12i2 x2 = {-1, -1, 0, 0}; static struct s7i25i12i2 x3 = {-1, 0, -1, 0}; static struct s7i25i12i2 x4 = {-1, -1, -1, -1}; print_prologue("s7i25i12i2", _Alignof(struct s7i25i12i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i13s1I0i2 {
  _Bool a:1;
  int b:13;
  short c:1;
  int :0;
  int d:2;
};
static struct b1i13s1I0i2 x1 = {-1, 0, 0, 0}; static struct b1i13s1I0i2 x2 = {-1, -1, 0, 0}; static struct b1i13s1I0i2 x3 = {-1, 0, -1, 0}; static struct b1i13s1I0i2 x4 = {-1, -1, -1, -1}; print_prologue("b1i13s1I0i2", _Alignof(struct b1i13s1I0i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s5c6s5b1 {
  short a:5;
  char b:6;
  short c:5;
  _Bool d:1;
};
static struct s5c6s5b1 x1 = {-1, 0, 0, 0}; static struct s5c6s5b1 x2 = {-1, -1, 0, 0}; static struct s5c6s5b1 x3 = {-1, 0, -1, 0}; static struct s5c6s5b1 x4 = {-1, -1, -1, -1}; print_prologue("s5c6s5b1", _Alignof(struct s5c6s5b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1c1b1c1 {
  _Bool a:1;
  char b:1;
  _Bool c:1;
  char d:1;
};
static struct b1c1b1c1 x1 = {-1, 0, 0, 0}; static struct b1c1b1c1 x2 = {-1, -1, 0, 0}; static struct b1c1b1c1 x3 = {-1, 0, -1, 0}; static struct b1c1b1c1 x4 = {-1, -1, -1, -1}; print_prologue("b1c1b1c1", _Alignof(struct b1c1b1c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i24i1is {
  int a:24;
  int b:1;
  int c;
  short d;
};
static struct i24i1is x1 = {-1, 0, 0, 0}; static struct i24i1is x2 = {-1, -1, 0, 0}; static struct i24i1is x3 = {-1, 0, -1, 0}; static struct i24i1is x4 = {-1, -1, -1, -1}; print_prologue("i24i1is", _Alignof(struct i24i1is), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1S0ii3s {
  char a:1;
  short :0;
  int b;
  int c:3;
  short d;
};
static struct c1S0ii3s x1 = {-1, 0, 0, 0}; static struct c1S0ii3s x2 = {-1, -1, 0, 0}; static struct c1S0ii3s x3 = {-1, 0, -1, 0}; static struct c1S0ii3s x4 = {-1, -1, -1, -1}; print_prologue("c1S0ii3s", _Alignof(struct c1S0ii3s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6i11c5i5 {
  char a:6;
  int b:11;
  char c:5;
  int d:5;
};
static struct c6i11c5i5 x1 = {-1, 0, 0, 0}; static struct c6i11c5i5 x2 = {-1, -1, 0, 0}; static struct c6i11c5i5 x3 = {-1, 0, -1, 0}; static struct c6i11c5i5 x4 = {-1, -1, -1, -1}; print_prologue("c6i11c5i5", _Alignof(struct c6i11c5i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7i24I19b1i1 {
  int a:7;
  int b:24;
  int :19;
  _Bool c:1;
  int d:1;
};
static struct i7i24I19b1i1 x1 = {-1, 0, 0, 0}; static struct i7i24I19b1i1 x2 = {-1, -1, 0, 0}; static struct i7i24I19b1i1 x3 = {-1, 0, -1, 0}; static struct i7i24I19b1i1 x4 = {-1, -1, -1, -1}; print_prologue("i7i24I19b1i1", _Alignof(struct i7i24I19b1i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1i4s13s1 {
  char a:1;
  int b:4;
  short c:13;
  short d:1;
};
static struct c1i4s13s1 x1 = {-1, 0, 0, 0}; static struct c1i4s13s1 x2 = {-1, -1, 0, 0}; static struct c1i4s13s1 x3 = {-1, 0, -1, 0}; static struct c1i4s13s1 x4 = {-1, -1, -1, -1}; print_prologue("c1i4s13s1", _Alignof(struct c1i4s13s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1S15i2S4i13 {
  int a;
  _Bool b:1;
  short :15;
  int c:2;
  short :4;
  int d:13;
};
static struct ib1S15i2S4i13 x1 = {-1, 0, 0, 0}; static struct ib1S15i2S4i13 x2 = {-1, -1, 0, 0}; static struct ib1S15i2S4i13 x3 = {-1, 0, -1, 0}; static struct ib1S15i2S4i13 x4 = {-1, -1, -1, -1}; print_prologue("ib1S15i2S4i13", _Alignof(struct ib1S15i2S4i13), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s7c5s5s12 {
  short a:7;
  char b:5;
  short c:5;
  short d:12;
};
static struct s7c5s5s12 x1 = {-1, 0, 0, 0}; static struct s7c5s5s12 x2 = {-1, -1, 0, 0}; static struct s7c5s5s12 x3 = {-1, 0, -1, 0}; static struct s7c5s5s12 x4 = {-1, -1, -1, -1}; print_prologue("s7c5s5s12", _Alignof(struct s7c5s5s12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1c4i1b1 {
  short a:1;
  char b:4;
  int c:1;
  _Bool d:1;
};
static struct s1c4i1b1 x1 = {-1, 0, 0, 0}; static struct s1c4i1b1 x2 = {-1, -1, 0, 0}; static struct s1c4i1b1 x3 = {-1, 0, -1, 0}; static struct s1c4i1b1 x4 = {-1, -1, -1, -1}; print_prologue("s1c4i1b1", _Alignof(struct s1c4i1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2cs4i11 {
  int a:2;
  char b;
  short c:4;
  int d:11;
};
static struct i2cs4i11 x1 = {-1, 0, 0, 0}; static struct i2cs4i11 x2 = {-1, -1, 0, 0}; static struct i2cs4i11 x3 = {-1, 0, -1, 0}; static struct i2cs4i11 x4 = {-1, -1, -1, -1}; print_prologue("i2cs4i11", _Alignof(struct i2cs4i11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7c7sc {
  int a:7;
  char b:7;
  short c;
  char d;
};
static struct i7c7sc x1 = {-1, 0, 0, 0}; static struct i7c7sc x2 = {-1, -1, 0, 0}; static struct i7c7sc x3 = {-1, 0, -1, 0}; static struct i7c7sc x4 = {-1, -1, -1, -1}; print_prologue("i7c7sc", _Alignof(struct i7c7sc), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iI1c2s4s6 {
  int a;
  int :1;
  char b:2;
  short c:4;
  short d:6;
};
static struct iI1c2s4s6 x1 = {-1, 0, 0, 0}; static struct iI1c2s4s6 x2 = {-1, -1, 0, 0}; static struct iI1c2s4s6 x3 = {-1, 0, -1, 0}; static struct iI1c2s4s6 x4 = {-1, -1, -1, -1}; print_prologue("iI1c2s4s6", _Alignof(struct iI1c2s4s6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1iI3b1b1 {
  _Bool a:1;
  int b;
  int :3;
  _Bool c:1;
  _Bool d:1;
};
static struct b1iI3b1b1 x1 = {-1, 0, 0, 0}; static struct b1iI3b1b1 x2 = {-1, -1, 0, 0}; static struct b1iI3b1b1 x3 = {-1, 0, -1, 0}; static struct b1iI3b1b1 x4 = {-1, -1, -1, -1}; print_prologue("b1iI3b1b1", _Alignof(struct b1iI3b1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I7c2i1i2s {
  int :7;
  char a:2;
  int b:1;
  int c:2;
  short d;
};
static struct I7c2i1i2s x1 = {-1, 0, 0, 0}; static struct I7c2i1i2s x2 = {-1, -1, 0, 0}; static struct I7c2i1i2s x3 = {-1, 0, -1, 0}; static struct I7c2i1i2s x4 = {-1, -1, -1, -1}; print_prologue("I7c2i1i2s", _Alignof(struct I7c2i1i2s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1c1is10 {
  int a:1;
  char b:1;
  int c;
  short d:10;
};
static struct i1c1is10 x1 = {-1, 0, 0, 0}; static struct i1c1is10 x2 = {-1, -1, 0, 0}; static struct i1c1is10 x3 = {-1, 0, -1, 0}; static struct i1c1is10 x4 = {-1, -1, -1, -1}; print_prologue("i1c1is10", _Alignof(struct i1c1is10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1bis {
  short a:1;
  _Bool b;
  int c;
  short d;
};
static struct s1bis x1 = {-1, 0, 0, 0}; static struct s1bis x2 = {-1, -1, 0, 0}; static struct s1bis x3 = {-1, 0, -1, 0}; static struct s1bis x4 = {-1, -1, -1, -1}; print_prologue("s1bis", _Alignof(struct s1bis), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I1C0i17s11i22i {
  int :1;
  char :0;
  int a:17;
  short b:11;
  int c:22;
  int d;
};
static struct I1C0i17s11i22i x1 = {-1, 0, 0, 0}; static struct I1C0i17s11i22i x2 = {-1, -1, 0, 0}; static struct I1C0i17s11i22i x3 = {-1, 0, -1, 0}; static struct I1C0i17s11i22i x4 = {-1, -1, -1, -1}; print_prologue("I1C0i17s11i22i", _Alignof(struct I1C0i17s11i22i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i13i2s15 {
  _Bool a:1;
  int b:13;
  int c:2;
  short d:15;
};
static struct b1i13i2s15 x1 = {-1, 0, 0, 0}; static struct b1i13i2s15 x2 = {-1, -1, 0, 0}; static struct b1i13i2s15 x3 = {-1, 0, -1, 0}; static struct b1i13i2s15 x4 = {-1, -1, -1, -1}; print_prologue("b1i13i2s15", _Alignof(struct b1i13i2s15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1s4s1 {
  int a;
  _Bool b:1;
  short c:4;
  short d:1;
};
static struct ib1s4s1 x1 = {-1, 0, 0, 0}; static struct ib1s4s1 x2 = {-1, -1, 0, 0}; static struct ib1s4s1 x3 = {-1, 0, -1, 0}; static struct ib1s4s1 x4 = {-1, -1, -1, -1}; print_prologue("ib1s4s1", _Alignof(struct ib1s4s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5i5i13S11i {
  char a:5;
  int b:5;
  int c:13;
  short :11;
  int d;
};
static struct c5i5i13S11i x1 = {-1, 0, 0, 0}; static struct c5i5i13S11i x2 = {-1, -1, 0, 0}; static struct c5i5i13S11i x3 = {-1, 0, -1, 0}; static struct c5i5i13S11i x4 = {-1, -1, -1, -1}; print_prologue("c5i5i13S11i", _Alignof(struct c5i5i13S11i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1b1c7b1 {
  _Bool a:1;
  _Bool b:1;
  char c:7;
  _Bool d:1;
};
static struct b1b1c7b1 x1 = {-1, 0, 0, 0}; static struct b1b1c7b1 x2 = {-1, -1, 0, 0}; static struct b1b1c7b1 x3 = {-1, 0, -1, 0}; static struct b1b1c7b1 x4 = {-1, -1, -1, -1}; print_prologue("b1b1c7b1", _Alignof(struct b1b1c7b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1ci9c7 {
  char a:1;
  char b;
  int c:9;
  char d:7;
};
static struct c1ci9c7 x1 = {-1, 0, 0, 0}; static struct c1ci9c7 x2 = {-1, -1, 0, 0}; static struct c1ci9c7 x3 = {-1, 0, -1, 0}; static struct c1ci9c7 x4 = {-1, -1, -1, -1}; print_prologue("c1ci9c7", _Alignof(struct c1ci9c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1b1s2i21 {
  int a:1;
  _Bool b:1;
  short c:2;
  int d:21;
};
static struct i1b1s2i21 x1 = {-1, 0, 0, 0}; static struct i1b1s2i21 x2 = {-1, -1, 0, 0}; static struct i1b1s2i21 x3 = {-1, 0, -1, 0}; static struct i1b1s2i21 x4 = {-1, -1, -1, -1}; print_prologue("i1b1s2i21", _Alignof(struct i1b1s2i21), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i31s5I0S0c5c {
  int a:31;
  short b:5;
  int :0;
  short :0;
  char c:5;
  char d;
};
static struct i31s5I0S0c5c x1 = {-1, 0, 0, 0}; static struct i31s5I0S0c5c x2 = {-1, -1, 0, 0}; static struct i31s5I0S0c5c x3 = {-1, 0, -1, 0}; static struct i31s5I0S0c5c x4 = {-1, -1, -1, -1}; print_prologue("i31s5I0S0c5c", _Alignof(struct i31s5I0S0c5c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i29cI3c {
  _Bool a:1;
  int b:29;
  char c;
  int :3;
  char d;
};
static struct b1i29cI3c x1 = {-1, 0, 0, 0}; static struct b1i29cI3c x2 = {-1, -1, 0, 0}; static struct b1i29cI3c x3 = {-1, 0, -1, 0}; static struct b1i29cI3c x4 = {-1, -1, -1, -1}; print_prologue("b1i29cI3c", _Alignof(struct b1i29cI3c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s8c5si14 {
  short a:8;
  char b:5;
  short c;
  int d:14;
};
static struct s8c5si14 x1 = {-1, 0, 0, 0}; static struct s8c5si14 x2 = {-1, -1, 0, 0}; static struct s8c5si14 x3 = {-1, 0, -1, 0}; static struct s8c5si14 x4 = {-1, -1, -1, -1}; print_prologue("s8c5si14", _Alignof(struct s8c5si14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iS4I0ii1i {
  int a;
  short :4;
  int :0;
  int b;
  int c:1;
  int d;
};
static struct iS4I0ii1i x1 = {-1, 0, 0, 0}; static struct iS4I0ii1i x2 = {-1, -1, 0, 0}; static struct iS4I0ii1i x3 = {-1, 0, -1, 0}; static struct iS4I0ii1i x4 = {-1, -1, -1, -1}; print_prologue("iS4I0ii1i", _Alignof(struct iS4I0ii1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ss16i4b1 {
  short a;
  short b:16;
  int c:4;
  _Bool d:1;
};
static struct ss16i4b1 x1 = {-1, 0, 0, 0}; static struct ss16i4b1 x2 = {-1, -1, 0, 0}; static struct ss16i4b1 x3 = {-1, 0, -1, 0}; static struct ss16i4b1 x4 = {-1, -1, -1, -1}; print_prologue("ss16i4b1", _Alignof(struct ss16i4b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s9c2c5I29c1 {
  short a:9;
  char b:2;
  char c:5;
  int :29;
  char d:1;
};
static struct s9c2c5I29c1 x1 = {-1, 0, 0, 0}; static struct s9c2c5I29c1 x2 = {-1, -1, 0, 0}; static struct s9c2c5I29c1 x3 = {-1, 0, -1, 0}; static struct s9c2c5I29c1 x4 = {-1, -1, -1, -1}; print_prologue("s9c2c5I29c1", _Alignof(struct s9c2c5I29c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cs9c7c8 {
  char a;
  short b:9;
  char c:7;
  char d:8;
};
static struct cs9c7c8 x1 = {-1, 0, 0, 0}; static struct cs9c7c8 x2 = {-1, -1, 0, 0}; static struct cs9c7c8 x3 = {-1, 0, -1, 0}; static struct cs9c7c8 x4 = {-1, -1, -1, -1}; print_prologue("cs9c7c8", _Alignof(struct cs9c7c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S6i20s6i3s4 {
  short :6;
  int a:20;
  short b:6;
  int c:3;
  short d:4;
};
static struct S6i20s6i3s4 x1 = {-1, 0, 0, 0}; static struct S6i20s6i3s4 x2 = {-1, -1, 0, 0}; static struct S6i20s6i3s4 x3 = {-1, 0, -1, 0}; static struct S6i20s6i3s4 x4 = {-1, -1, -1, -1}; print_prologue("S6i20s6i3s4", _Alignof(struct S6i20s6i3s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2i15i2i32 {
  char a:2;
  int b:15;
  int c:2;
  int d:32;
};
static struct c2i15i2i32 x1 = {-1, 0, 0, 0}; static struct c2i15i2i32 x2 = {-1, -1, 0, 0}; static struct c2i15i2i32 x3 = {-1, 0, -1, 0}; static struct c2i15i2i32 x4 = {-1, -1, -1, -1}; print_prologue("c2i15i2i32", _Alignof(struct c2i15i2i32), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1ii27i15 {
  int a:1;
  int b;
  int c:27;
  int d:15;
};
static struct i1ii27i15 x1 = {-1, 0, 0, 0}; static struct i1ii27i15 x2 = {-1, -1, 0, 0}; static struct i1ii27i15 x3 = {-1, 0, -1, 0}; static struct i1ii27i15 x4 = {-1, -1, -1, -1}; print_prologue("i1ii27i15", _Alignof(struct i1ii27i15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iiI0s2c3 {
  int a;
  int b;
  int :0;
  short c:2;
  char d:3;
};
static struct iiI0s2c3 x1 = {-1, 0, 0, 0}; static struct iiI0s2c3 x2 = {-1, -1, 0, 0}; static struct iiI0s2c3 x3 = {-1, 0, -1, 0}; static struct iiI0s2c3 x4 = {-1, -1, -1, -1}; print_prologue("iiI0s2c3", _Alignof(struct iiI0s2c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s3i7i2c3 {
  short a:3;
  int b:7;
  int c:2;
  char d:3;
};
static struct s3i7i2c3 x1 = {-1, 0, 0, 0}; static struct s3i7i2c3 x2 = {-1, -1, 0, 0}; static struct s3i7i2c3 x3 = {-1, 0, -1, 0}; static struct s3i7i2c3 x4 = {-1, -1, -1, -1}; print_prologue("s3i7i2c3", _Alignof(struct s3i7i2c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iC2C0ss2c1 {
  int a;
  char :2;
  char :0;
  short b;
  short c:2;
  char d:1;
};
static struct iC2C0ss2c1 x1 = {-1, 0, 0, 0}; static struct iC2C0ss2c1 x2 = {-1, -1, 0, 0}; static struct iC2C0ss2c1 x3 = {-1, 0, -1, 0}; static struct iC2C0ss2c1 x4 = {-1, -1, -1, -1}; print_prologue("iC2C0ss2c1", _Alignof(struct iC2C0ss2c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2b1s10i1 {
  int a:2;
  _Bool b:1;
  short c:10;
  int d:1;
};
static struct i2b1s10i1 x1 = {-1, 0, 0, 0}; static struct i2b1s10i1 x2 = {-1, -1, 0, 0}; static struct i2b1s10i1 x3 = {-1, 0, -1, 0}; static struct i2b1s10i1 x4 = {-1, -1, -1, -1}; print_prologue("i2b1s10i1", _Alignof(struct i2b1s10i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2b1i3i20 {
  char a:2;
  _Bool b:1;
  int c:3;
  int d:20;
};
static struct c2b1i3i20 x1 = {-1, 0, 0, 0}; static struct c2b1i3i20 x2 = {-1, -1, 0, 0}; static struct c2b1i3i20 x3 = {-1, 0, -1, 0}; static struct c2b1i3i20 x4 = {-1, -1, -1, -1}; print_prologue("c2b1i3i20", _Alignof(struct c2b1i3i20), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i8c4s3i16 {
  int a:8;
  char b:4;
  short c:3;
  int d:16;
};
static struct i8c4s3i16 x1 = {-1, 0, 0, 0}; static struct i8c4s3i16 x2 = {-1, -1, 0, 0}; static struct i8c4s3i16 x3 = {-1, 0, -1, 0}; static struct i8c4s3i16 x4 = {-1, -1, -1, -1}; print_prologue("i8c4s3i16", _Alignof(struct i8c4s3i16), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii6s5i {
  int a;
  int b:6;
  short c:5;
  int d;
};
static struct ii6s5i x1 = {-1, 0, 0, 0}; static struct ii6s5i x2 = {-1, -1, 0, 0}; static struct ii6s5i x3 = {-1, 0, -1, 0}; static struct ii6s5i x4 = {-1, -1, -1, -1}; print_prologue("ii6s5i", _Alignof(struct ii6s5i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i26s9c5c5 {
  int a:26;
  short b:9;
  char c:5;
  char d:5;
};
static struct i26s9c5c5 x1 = {-1, 0, 0, 0}; static struct i26s9c5c5 x2 = {-1, -1, 0, 0}; static struct i26s9c5c5 x3 = {-1, 0, -1, 0}; static struct i26s9c5c5 x4 = {-1, -1, -1, -1}; print_prologue("i26s9c5c5", _Alignof(struct i26s9c5c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6ii2i6 {
  char a:6;
  int b;
  int c:2;
  int d:6;
};
static struct c6ii2i6 x1 = {-1, 0, 0, 0}; static struct c6ii2i6 x2 = {-1, -1, 0, 0}; static struct c6ii2i6 x3 = {-1, 0, -1, 0}; static struct c6ii2i6 x4 = {-1, -1, -1, -1}; print_prologue("c6ii2i6", _Alignof(struct c6ii2i6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i28isc8 {
  int a:28;
  int b;
  short c;
  char d:8;
};
static struct i28isc8 x1 = {-1, 0, 0, 0}; static struct i28isc8 x2 = {-1, -1, 0, 0}; static struct i28isc8 x3 = {-1, 0, -1, 0}; static struct i28isc8 x4 = {-1, -1, -1, -1}; print_prologue("i28isc8", _Alignof(struct i28isc8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s15s10i2i {
  short a:15;
  short b:10;
  int c:2;
  int d;
};
static struct s15s10i2i x1 = {-1, 0, 0, 0}; static struct s15s10i2i x2 = {-1, -1, 0, 0}; static struct s15s10i2i x3 = {-1, 0, -1, 0}; static struct s15s10i2i x4 = {-1, -1, -1, -1}; print_prologue("s15s10i2i", _Alignof(struct s15s10i2i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i8i4i19i32 {
  int a:8;
  int b:4;
  int c:19;
  int d:32;
};
static struct i8i4i19i32 x1 = {-1, 0, 0, 0}; static struct i8i4i19i32 x2 = {-1, -1, 0, 0}; static struct i8i4i19i32 x3 = {-1, 0, -1, 0}; static struct i8i4i19i32 x4 = {-1, -1, -1, -1}; print_prologue("i8i4i19i32", _Alignof(struct i8i4i19i32), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1ci6i {
  char a:1;
  char b;
  int c:6;
  int d;
};
static struct c1ci6i x1 = {-1, 0, 0, 0}; static struct c1ci6i x2 = {-1, -1, 0, 0}; static struct c1ci6i x3 = {-1, 0, -1, 0}; static struct c1ci6i x4 = {-1, -1, -1, -1}; print_prologue("c1ci6i", _Alignof(struct c1ci6i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s9cs8 {
  int a:2;
  short b:9;
  char c;
  short d:8;
};
static struct i2s9cs8 x1 = {-1, 0, 0, 0}; static struct i2s9cs8 x2 = {-1, -1, 0, 0}; static struct i2s9cs8 x3 = {-1, 0, -1, 0}; static struct i2s9cs8 x4 = {-1, -1, -1, -1}; print_prologue("i2s9cs8", _Alignof(struct i2s9cs8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5i10s9c1 {
  int a:5;
  int b:10;
  short c:9;
  char d:1;
};
static struct i5i10s9c1 x1 = {-1, 0, 0, 0}; static struct i5i10s9c1 x2 = {-1, -1, 0, 0}; static struct i5i10s9c1 x3 = {-1, 0, -1, 0}; static struct i5i10s9c1 x4 = {-1, -1, -1, -1}; print_prologue("i5i10s9c1", _Alignof(struct i5i10s9c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s7i2s5i2 {
  short a:7;
  int b:2;
  short c:5;
  int d:2;
};
static struct s7i2s5i2 x1 = {-1, 0, 0, 0}; static struct s7i2s5i2 x2 = {-1, -1, 0, 0}; static struct s7i2s5i2 x3 = {-1, 0, -1, 0}; static struct s7i2s5i2 x4 = {-1, -1, -1, -1}; print_prologue("s7i2s5i2", _Alignof(struct s7i2s5i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i30c2bc3 {
  int a:30;
  char b:2;
  _Bool c;
  char d:3;
};
static struct i30c2bc3 x1 = {-1, 0, 0, 0}; static struct i30c2bc3 x2 = {-1, -1, 0, 0}; static struct i30c2bc3 x3 = {-1, 0, -1, 0}; static struct i30c2bc3 x4 = {-1, -1, -1, -1}; print_prologue("i30c2bc3", _Alignof(struct i30c2bc3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct si10iI1b1 {
  short a;
  int b:10;
  int c;
  int :1;
  _Bool d:1;
};
static struct si10iI1b1 x1 = {-1, 0, 0, 0}; static struct si10iI1b1 x2 = {-1, -1, 0, 0}; static struct si10iI1b1 x3 = {-1, 0, -1, 0}; static struct si10iI1b1 x4 = {-1, -1, -1, -1}; print_prologue("si10iI1b1", _Alignof(struct si10iI1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct B1cii6i26 {
  _Bool :1;
  char a;
  int b;
  int c:6;
  int d:26;
};
static struct B1cii6i26 x1 = {-1, 0, 0, 0}; static struct B1cii6i26 x2 = {-1, -1, 0, 0}; static struct B1cii6i26 x3 = {-1, 0, -1, 0}; static struct B1cii6i26 x4 = {-1, -1, -1, -1}; print_prologue("B1cii6i26", _Alignof(struct B1cii6i26), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C0b1i3B1I0c2i7 {
  char :0;
  _Bool a:1;
  int b:3;
  _Bool :1;
  int :0;
  char c:2;
  int d:7;
};
static struct C0b1i3B1I0c2i7 x1 = {-1, 0, 0, 0}; static struct C0b1i3B1I0c2i7 x2 = {-1, -1, 0, 0}; static struct C0b1i3B1I0c2i7 x3 = {-1, 0, -1, 0}; static struct C0b1i3B1I0c2i7 x4 = {-1, -1, -1, -1}; print_prologue("C0b1i3B1I0c2i7", _Alignof(struct C0b1i3B1I0c2i7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2B1c8i30i11 {
  short a:2;
  _Bool :1;
  char b:8;
  int c:30;
  int d:11;
};
static struct s2B1c8i30i11 x1 = {-1, 0, 0, 0}; static struct s2B1c8i30i11 x2 = {-1, -1, 0, 0}; static struct s2B1c8i30i11 x3 = {-1, 0, -1, 0}; static struct s2B1c8i30i11 x4 = {-1, -1, -1, -1}; print_prologue("s2B1c8i30i11", _Alignof(struct s2B1c8i30i11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i29c5i11c7 {
  int a:29;
  char b:5;
  int c:11;
  char d:7;
};
static struct i29c5i11c7 x1 = {-1, 0, 0, 0}; static struct i29c5i11c7 x2 = {-1, -1, 0, 0}; static struct i29c5i11c7 x3 = {-1, 0, -1, 0}; static struct i29c5i11c7 x4 = {-1, -1, -1, -1}; print_prologue("i29c5i11c7", _Alignof(struct i29c5i11c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i32b1ci {
  int a:32;
  _Bool b:1;
  char c;
  int d;
};
static struct i32b1ci x1 = {-1, 0, 0, 0}; static struct i32b1ci x2 = {-1, -1, 0, 0}; static struct i32b1ci x3 = {-1, 0, -1, 0}; static struct i32b1ci x4 = {-1, -1, -1, -1}; print_prologue("i32b1ci", _Alignof(struct i32b1ci), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i1c7i11 {
  _Bool a:1;
  int b:1;
  char c:7;
  int d:11;
};
static struct b1i1c7i11 x1 = {-1, 0, 0, 0}; static struct b1i1c7i11 x2 = {-1, -1, 0, 0}; static struct b1i1c7i11 x3 = {-1, 0, -1, 0}; static struct b1i1c7i11 x4 = {-1, -1, -1, -1}; print_prologue("b1i1c7i11", _Alignof(struct b1i1c7i11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5i2cb1 {
  char a:5;
  int b:2;
  char c;
  _Bool d:1;
};
static struct c5i2cb1 x1 = {-1, 0, 0, 0}; static struct c5i2cb1 x2 = {-1, -1, 0, 0}; static struct c5i2cb1 x3 = {-1, 0, -1, 0}; static struct c5i2cb1 x4 = {-1, -1, -1, -1}; print_prologue("c5i2cb1", _Alignof(struct c5i2cb1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s8S12i5S4i12b1 {
  short a:8;
  short :12;
  int b:5;
  short :4;
  int c:12;
  _Bool d:1;
};
static struct s8S12i5S4i12b1 x1 = {-1, 0, 0, 0}; static struct s8S12i5S4i12b1 x2 = {-1, -1, 0, 0}; static struct s8S12i5S4i12b1 x3 = {-1, 0, -1, 0}; static struct s8S12i5S4i12b1 x4 = {-1, -1, -1, -1}; print_prologue("s8S12i5S4i12b1", _Alignof(struct s8S12i5S4i12b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1c6B0s4 {
  int a;
  _Bool b:1;
  char c:6;
  _Bool :0;
  short d:4;
};
static struct ib1c6B0s4 x1 = {-1, 0, 0, 0}; static struct ib1c6B0s4 x2 = {-1, -1, 0, 0}; static struct ib1c6B0s4 x3 = {-1, 0, -1, 0}; static struct ib1c6B0s4 x4 = {-1, -1, -1, -1}; print_prologue("ib1c6B0s4", _Alignof(struct ib1c6B0s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4ib1c8 {
  char a:4;
  int b;
  _Bool c:1;
  char d:8;
};
static struct c4ib1c8 x1 = {-1, 0, 0, 0}; static struct c4ib1c8 x2 = {-1, -1, 0, 0}; static struct c4ib1c8 x3 = {-1, 0, -1, 0}; static struct c4ib1c8 x4 = {-1, -1, -1, -1}; print_prologue("c4ib1c8", _Alignof(struct c4ib1c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s12i14i10i6 {
  short a:12;
  int b:14;
  int c:10;
  int d:6;
};
static struct s12i14i10i6 x1 = {-1, 0, 0, 0}; static struct s12i14i10i6 x2 = {-1, -1, 0, 0}; static struct s12i14i10i6 x3 = {-1, 0, -1, 0}; static struct s12i14i10i6 x4 = {-1, -1, -1, -1}; print_prologue("s12i14i10i6", _Alignof(struct s12i14i10i6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii20s1i6 {
  int a;
  int b:20;
  short c:1;
  int d:6;
};
static struct ii20s1i6 x1 = {-1, 0, 0, 0}; static struct ii20s1i6 x2 = {-1, -1, 0, 0}; static struct ii20s1i6 x3 = {-1, 0, -1, 0}; static struct ii20s1i6 x4 = {-1, -1, -1, -1}; print_prologue("ii20s1i6", _Alignof(struct ii20s1i6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1b1b1c {
  char a:1;
  _Bool b:1;
  _Bool c:1;
  char d;
};
static struct c1b1b1c x1 = {-1, 0, 0, 0}; static struct c1b1b1c x2 = {-1, -1, 0, 0}; static struct c1b1b1c x3 = {-1, 0, -1, 0}; static struct c1b1b1c x4 = {-1, -1, -1, -1}; print_prologue("c1b1b1c", _Alignof(struct c1b1b1c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5b1s2i {
  int a:5;
  _Bool b:1;
  short c:2;
  int d;
};
static struct i5b1s2i x1 = {-1, 0, 0, 0}; static struct i5b1s2i x2 = {-1, -1, 0, 0}; static struct i5b1s2i x3 = {-1, 0, -1, 0}; static struct i5b1s2i x4 = {-1, -1, -1, -1}; print_prologue("i5b1s2i", _Alignof(struct i5b1s2i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2c3i2c1 {
  short a:2;
  char b:3;
  int c:2;
  char d:1;
};
static struct s2c3i2c1 x1 = {-1, 0, 0, 0}; static struct s2c3i2c1 x2 = {-1, -1, 0, 0}; static struct s2c3i2c1 x3 = {-1, 0, -1, 0}; static struct s2c3i2c1 x4 = {-1, -1, -1, -1}; print_prologue("s2c3i2c1", _Alignof(struct s2c3i2c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5ci1i19 {
  int a:5;
  char b;
  int c:1;
  int d:19;
};
static struct i5ci1i19 x1 = {-1, 0, 0, 0}; static struct i5ci1i19 x2 = {-1, -1, 0, 0}; static struct i5ci1i19 x3 = {-1, 0, -1, 0}; static struct i5ci1i19 x4 = {-1, -1, -1, -1}; print_prologue("i5ci1i19", _Alignof(struct i5ci1i19), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is4C8s6i {
  int a;
  short b:4;
  char :8;
  short c:6;
  int d;
};
static struct is4C8s6i x1 = {-1, 0, 0, 0}; static struct is4C8s6i x2 = {-1, -1, 0, 0}; static struct is4C8s6i x3 = {-1, 0, -1, 0}; static struct is4C8s6i x4 = {-1, -1, -1, -1}; print_prologue("is4C8s6i", _Alignof(struct is4C8s6i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bb1ii1 {
  _Bool a;
  _Bool b:1;
  int c;
  int d:1;
};
static struct bb1ii1 x1 = {-1, 0, 0, 0}; static struct bb1ii1 x2 = {-1, -1, 0, 0}; static struct bb1ii1 x3 = {-1, 0, -1, 0}; static struct bb1ii1 x4 = {-1, -1, -1, -1}; print_prologue("bb1ii1", _Alignof(struct bb1ii1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4s9i3c4 {
  char a:4;
  short b:9;
  int c:3;
  char d:4;
};
static struct c4s9i3c4 x1 = {-1, 0, 0, 0}; static struct c4s9i3c4 x2 = {-1, -1, 0, 0}; static struct c4s9i3c4 x3 = {-1, 0, -1, 0}; static struct c4s9i3c4 x4 = {-1, -1, -1, -1}; print_prologue("c4s9i3c4", _Alignof(struct c4s9i3c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3i17i14b {
  char a:3;
  int b:17;
  int c:14;
  _Bool d;
};
static struct c3i17i14b x1 = {-1, 0, 0, 0}; static struct c3i17i14b x2 = {-1, -1, 0, 0}; static struct c3i17i14b x3 = {-1, 0, -1, 0}; static struct c3i17i14b x4 = {-1, -1, -1, -1}; print_prologue("c3i17i14b", _Alignof(struct c3i17i14b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4s3s1S2c3 {
  char a:4;
  short b:3;
  short c:1;
  short :2;
  char d:3;
};
static struct c4s3s1S2c3 x1 = {-1, 0, 0, 0}; static struct c4s3s1S2c3 x2 = {-1, -1, 0, 0}; static struct c4s3s1S2c3 x3 = {-1, 0, -1, 0}; static struct c4s3s1S2c3 x4 = {-1, -1, -1, -1}; print_prologue("c4s3s1S2c3", _Alignof(struct c4s3s1S2c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i13s14i19i5 {
  int a:13;
  short b:14;
  int c:19;
  int d:5;
};
static struct i13s14i19i5 x1 = {-1, 0, 0, 0}; static struct i13s14i19i5 x2 = {-1, -1, 0, 0}; static struct i13s14i19i5 x3 = {-1, 0, -1, 0}; static struct i13s14i19i5 x4 = {-1, -1, -1, -1}; print_prologue("i13s14i19i5", _Alignof(struct i13s14i19i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii15i22i1 {
  int a;
  int b:15;
  int c:22;
  int d:1;
};
static struct ii15i22i1 x1 = {-1, 0, 0, 0}; static struct ii15i22i1 x2 = {-1, -1, 0, 0}; static struct ii15i22i1 x3 = {-1, 0, -1, 0}; static struct ii15i22i1 x4 = {-1, -1, -1, -1}; print_prologue("ii15i22i1", _Alignof(struct ii15i22i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6is3i26 {
  char a:6;
  int b;
  short c:3;
  int d:26;
};
static struct c6is3i26 x1 = {-1, 0, 0, 0}; static struct c6is3i26 x2 = {-1, -1, 0, 0}; static struct c6is3i26 x3 = {-1, 0, -1, 0}; static struct c6is3i26 x4 = {-1, -1, -1, -1}; print_prologue("c6is3i26", _Alignof(struct c6is3i26), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s6i1s8 {
  int a:2;
  short b:6;
  int c:1;
  short d:8;
};
static struct i2s6i1s8 x1 = {-1, 0, 0, 0}; static struct i2s6i1s8 x2 = {-1, -1, 0, 0}; static struct i2s6i1s8 x3 = {-1, 0, -1, 0}; static struct i2s6i1s8 x4 = {-1, -1, -1, -1}; print_prologue("i2s6i1s8", _Alignof(struct i2s6i1s8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i4c2s2i {
  int a:4;
  char b:2;
  short c:2;
  int d;
};
static struct i4c2s2i x1 = {-1, 0, 0, 0}; static struct i4c2s2i x2 = {-1, -1, 0, 0}; static struct i4c2s2i x3 = {-1, 0, -1, 0}; static struct i4c2s2i x4 = {-1, -1, -1, -1}; print_prologue("i4c2s2i", _Alignof(struct i4c2s2i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i11i4cs3 {
  int a:11;
  int b:4;
  char c;
  short d:3;
};
static struct i11i4cs3 x1 = {-1, 0, 0, 0}; static struct i11i4cs3 x2 = {-1, -1, 0, 0}; static struct i11i4cs3 x3 = {-1, 0, -1, 0}; static struct i11i4cs3 x4 = {-1, -1, -1, -1}; print_prologue("i11i4cs3", _Alignof(struct i11i4cs3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i9i14s11s {
  int a:9;
  int b:14;
  short c:11;
  short d;
};
static struct i9i14s11s x1 = {-1, 0, 0, 0}; static struct i9i14s11s x2 = {-1, -1, 0, 0}; static struct i9i14s11s x3 = {-1, 0, -1, 0}; static struct i9i14s11s x4 = {-1, -1, -1, -1}; print_prologue("i9i14s11s", _Alignof(struct i9i14s11s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7si1S7i1 {
  char a:7;
  short b;
  int c:1;
  short :7;
  int d:1;
};
static struct c7si1S7i1 x1 = {-1, 0, 0, 0}; static struct c7si1S7i1 x2 = {-1, -1, 0, 0}; static struct c7si1S7i1 x3 = {-1, 0, -1, 0}; static struct c7si1S7i1 x4 = {-1, -1, -1, -1}; print_prologue("c7si1S7i1", _Alignof(struct c7si1S7i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6cc1b {
  char a:6;
  char b;
  char c:1;
  _Bool d;
};
static struct c6cc1b x1 = {-1, 0, 0, 0}; static struct c6cc1b x2 = {-1, -1, 0, 0}; static struct c6cc1b x3 = {-1, 0, -1, 0}; static struct c6cc1b x4 = {-1, -1, -1, -1}; print_prologue("c6cc1b", _Alignof(struct c6cc1b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sc3b1s {
  short a;
  char b:3;
  _Bool c:1;
  short d;
};
static struct sc3b1s x1 = {-1, 0, 0, 0}; static struct sc3b1s x2 = {-1, -1, 0, 0}; static struct sc3b1s x3 = {-1, 0, -1, 0}; static struct sc3b1s x4 = {-1, -1, -1, -1}; print_prologue("sc3b1s", _Alignof(struct sc3b1s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ci11i2c2 {
  char a;
  int b:11;
  int c:2;
  char d:2;
};
static struct ci11i2c2 x1 = {-1, 0, 0, 0}; static struct ci11i2c2 x2 = {-1, -1, 0, 0}; static struct ci11i2c2 x3 = {-1, 0, -1, 0}; static struct ci11i2c2 x4 = {-1, -1, -1, -1}; print_prologue("ci11i2c2", _Alignof(struct ci11i2c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii19sc2 {
  int a;
  int b:19;
  short c;
  char d:2;
};
static struct ii19sc2 x1 = {-1, 0, 0, 0}; static struct ii19sc2 x2 = {-1, -1, 0, 0}; static struct ii19sc2 x3 = {-1, 0, -1, 0}; static struct ii19sc2 x4 = {-1, -1, -1, -1}; print_prologue("ii19sc2", _Alignof(struct ii19sc2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cc3ii1 {
  char a;
  char b:3;
  int c;
  int d:1;
};
static struct cc3ii1 x1 = {-1, 0, 0, 0}; static struct cc3ii1 x2 = {-1, -1, 0, 0}; static struct cc3ii1 x3 = {-1, 0, -1, 0}; static struct cc3ii1 x4 = {-1, -1, -1, -1}; print_prologue("cc3ii1", _Alignof(struct cc3ii1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i30i3i2i6 {
  int a:30;
  int b:3;
  int c:2;
  int d:6;
};
static struct i30i3i2i6 x1 = {-1, 0, 0, 0}; static struct i30i3i2i6 x2 = {-1, -1, 0, 0}; static struct i30i3i2i6 x3 = {-1, 0, -1, 0}; static struct i30i3i2i6 x4 = {-1, -1, -1, -1}; print_prologue("i30i3i2i6", _Alignof(struct i30i3i2i6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7b1I13is5 {
  char a:7;
  _Bool b:1;
  int :13;
  int c;
  short d:5;
};
static struct c7b1I13is5 x1 = {-1, 0, 0, 0}; static struct c7b1I13is5 x2 = {-1, -1, 0, 0}; static struct c7b1I13is5 x3 = {-1, 0, -1, 0}; static struct c7b1I13is5 x4 = {-1, -1, -1, -1}; print_prologue("c7b1I13is5", _Alignof(struct c7b1I13is5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0i2i2C4S3ic5 {
  int :0;
  int a:2;
  int b:2;
  char :4;
  short :3;
  int c;
  char d:5;
};
static struct I0i2i2C4S3ic5 x1 = {-1, 0, 0, 0}; static struct I0i2i2C4S3ic5 x2 = {-1, -1, 0, 0}; static struct I0i2i2C4S3ic5 x3 = {-1, 0, -1, 0}; static struct I0i2i2C4S3ic5 x4 = {-1, -1, -1, -1}; print_prologue("I0i2i2C4S3ic5", _Alignof(struct I0i2i2C4S3ic5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i18isI5b1 {
  int a:18;
  int b;
  short c;
  int :5;
  _Bool d:1;
};
static struct i18isI5b1 x1 = {-1, 0, 0, 0}; static struct i18isI5b1 x2 = {-1, -1, 0, 0}; static struct i18isI5b1 x3 = {-1, 0, -1, 0}; static struct i18isI5b1 x4 = {-1, -1, -1, -1}; print_prologue("i18isI5b1", _Alignof(struct i18isI5b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iis4i14 {
  int a;
  int b;
  short c:4;
  int d:14;
};
static struct iis4i14 x1 = {-1, 0, 0, 0}; static struct iis4i14 x2 = {-1, -1, 0, 0}; static struct iis4i14 x3 = {-1, 0, -1, 0}; static struct iis4i14 x4 = {-1, -1, -1, -1}; print_prologue("iis4i14", _Alignof(struct iis4i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1i10bs9 {
  char a:1;
  int b:10;
  _Bool c;
  short d:9;
};
static struct c1i10bs9 x1 = {-1, 0, 0, 0}; static struct c1i10bs9 x2 = {-1, -1, 0, 0}; static struct c1i10bs9 x3 = {-1, 0, -1, 0}; static struct c1i10bs9 x4 = {-1, -1, -1, -1}; print_prologue("c1i10bs9", _Alignof(struct c1i10bs9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sb1c4b1 {
  short a;
  _Bool b:1;
  char c:4;
  _Bool d:1;
};
static struct sb1c4b1 x1 = {-1, 0, 0, 0}; static struct sb1c4b1 x2 = {-1, -1, 0, 0}; static struct sb1c4b1 x3 = {-1, 0, -1, 0}; static struct sb1c4b1 x4 = {-1, -1, -1, -1}; print_prologue("sb1c4b1", _Alignof(struct sb1c4b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i13i7i19 {
  _Bool a:1;
  int b:13;
  int c:7;
  int d:19;
};
static struct b1i13i7i19 x1 = {-1, 0, 0, 0}; static struct b1i13i7i19 x2 = {-1, -1, 0, 0}; static struct b1i13i7i19 x3 = {-1, 0, -1, 0}; static struct b1i13i7i19 x4 = {-1, -1, -1, -1}; print_prologue("b1i13i7i19", _Alignof(struct b1i13i7i19), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1i7is1 {
  char a:1;
  int b:7;
  int c;
  short d:1;
};
static struct c1i7is1 x1 = {-1, 0, 0, 0}; static struct c1i7is1 x2 = {-1, -1, 0, 0}; static struct c1i7is1 x3 = {-1, 0, -1, 0}; static struct c1i7is1 x4 = {-1, -1, -1, -1}; print_prologue("c1i7is1", _Alignof(struct c1i7is1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I16s3i1i5s6 {
  int :16;
  short a:3;
  int b:1;
  int c:5;
  short d:6;
};
static struct I16s3i1i5s6 x1 = {-1, 0, 0, 0}; static struct I16s3i1i5s6 x2 = {-1, -1, 0, 0}; static struct I16s3i1i5s6 x3 = {-1, 0, -1, 0}; static struct I16s3i1i5s6 x4 = {-1, -1, -1, -1}; print_prologue("I16s3i1i5s6", _Alignof(struct I16s3i1i5s6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8sc7b {
  char a:8;
  short b;
  char c:7;
  _Bool d;
};
static struct c8sc7b x1 = {-1, 0, 0, 0}; static struct c8sc7b x2 = {-1, -1, 0, 0}; static struct c8sc7b x3 = {-1, 0, -1, 0}; static struct c8sc7b x4 = {-1, -1, -1, -1}; print_prologue("c8sc7b", _Alignof(struct c8sc7b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cs1b1c3 {
  char a;
  short b:1;
  _Bool c:1;
  char d:3;
};
static struct cs1b1c3 x1 = {-1, 0, 0, 0}; static struct cs1b1c3 x2 = {-1, -1, 0, 0}; static struct cs1b1c3 x3 = {-1, 0, -1, 0}; static struct cs1b1c3 x4 = {-1, -1, -1, -1}; print_prologue("cs1b1c3", _Alignof(struct cs1b1c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i12b1c5S3s5 {
  int a:12;
  _Bool b:1;
  char c:5;
  short :3;
  short d:5;
};
static struct i12b1c5S3s5 x1 = {-1, 0, 0, 0}; static struct i12b1c5S3s5 x2 = {-1, -1, 0, 0}; static struct i12b1c5S3s5 x3 = {-1, 0, -1, 0}; static struct i12b1c5S3s5 x4 = {-1, -1, -1, -1}; print_prologue("i12b1c5S3s5", _Alignof(struct i12b1c5S3s5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s15is13b1 {
  short a:15;
  int b;
  short c:13;
  _Bool d:1;
};
static struct s15is13b1 x1 = {-1, 0, 0, 0}; static struct s15is13b1 x2 = {-1, -1, 0, 0}; static struct s15is13b1 x3 = {-1, 0, -1, 0}; static struct s15is13b1 x4 = {-1, -1, -1, -1}; print_prologue("s15is13b1", _Alignof(struct s15is13b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7is5s12 {
  char a:7;
  int b;
  short c:5;
  short d:12;
};
static struct c7is5s12 x1 = {-1, 0, 0, 0}; static struct c7is5s12 x2 = {-1, -1, 0, 0}; static struct c7is5s12 x3 = {-1, 0, -1, 0}; static struct c7is5s12 x4 = {-1, -1, -1, -1}; print_prologue("c7is5s12", _Alignof(struct c7is5s12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1b1cs4 {
  _Bool a:1;
  _Bool b:1;
  char c;
  short d:4;
};
static struct b1b1cs4 x1 = {-1, 0, 0, 0}; static struct b1b1cs4 x2 = {-1, -1, 0, 0}; static struct b1b1cs4 x3 = {-1, 0, -1, 0}; static struct b1b1cs4 x4 = {-1, -1, -1, -1}; print_prologue("b1b1cs4", _Alignof(struct b1b1cs4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1cs1s3 {
  char a:1;
  char b;
  short c:1;
  short d:3;
};
static struct c1cs1s3 x1 = {-1, 0, 0, 0}; static struct c1cs1s3 x2 = {-1, -1, 0, 0}; static struct c1cs1s3 x3 = {-1, 0, -1, 0}; static struct c1cs1s3 x4 = {-1, -1, -1, -1}; print_prologue("c1cs1s3", _Alignof(struct c1cs1s3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i23sis6 {
  int a:23;
  short b;
  int c;
  short d:6;
};
static struct i23sis6 x1 = {-1, 0, 0, 0}; static struct i23sis6 x2 = {-1, -1, 0, 0}; static struct i23sis6 x3 = {-1, 0, -1, 0}; static struct i23sis6 x4 = {-1, -1, -1, -1}; print_prologue("i23sis6", _Alignof(struct i23sis6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I3C2i7i9c1i8 {
  int :3;
  char :2;
  int a:7;
  int b:9;
  char c:1;
  int d:8;
};
static struct I3C2i7i9c1i8 x1 = {-1, 0, 0, 0}; static struct I3C2i7i9c1i8 x2 = {-1, -1, 0, 0}; static struct I3C2i7i9c1i8 x3 = {-1, 0, -1, 0}; static struct I3C2i7i9c1i8 x4 = {-1, -1, -1, -1}; print_prologue("I3C2i7i9c1i8", _Alignof(struct I3C2i7i9c1i8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1b1c4i19 {
  char a:1;
  _Bool b:1;
  char c:4;
  int d:19;
};
static struct c1b1c4i19 x1 = {-1, 0, 0, 0}; static struct c1b1c4i19 x2 = {-1, -1, 0, 0}; static struct c1b1c4i19 x3 = {-1, 0, -1, 0}; static struct c1b1c4i19 x4 = {-1, -1, -1, -1}; print_prologue("c1b1c4i19", _Alignof(struct c1b1c4i19), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i15c1i9c3 {
  int a:15;
  char b:1;
  int c:9;
  char d:3;
};
static struct i15c1i9c3 x1 = {-1, 0, 0, 0}; static struct i15c1i9c3 x2 = {-1, -1, 0, 0}; static struct i15c1i9c3 x3 = {-1, 0, -1, 0}; static struct i15c1i9c3 x4 = {-1, -1, -1, -1}; print_prologue("i15c1i9c3", _Alignof(struct i15c1i9c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct si4i6c4 {
  short a;
  int b:4;
  int c:6;
  char d:4;
};
static struct si4i6c4 x1 = {-1, 0, 0, 0}; static struct si4i6c4 x2 = {-1, -1, 0, 0}; static struct si4i6c4 x3 = {-1, 0, -1, 0}; static struct si4i6c4 x4 = {-1, -1, -1, -1}; print_prologue("si4i6c4", _Alignof(struct si4i6c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7I3ii14s8 {
  char a:7;
  int :3;
  int b;
  int c:14;
  short d:8;
};
static struct c7I3ii14s8 x1 = {-1, 0, 0, 0}; static struct c7I3ii14s8 x2 = {-1, -1, 0, 0}; static struct c7I3ii14s8 x3 = {-1, 0, -1, 0}; static struct c7I3ii14s8 x4 = {-1, -1, -1, -1}; print_prologue("c7I3ii14s8", _Alignof(struct c7I3ii14s8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i27i8c6c5 {
  int a:27;
  int b:8;
  char c:6;
  char d:5;
};
static struct i27i8c6c5 x1 = {-1, 0, 0, 0}; static struct i27i8c6c5 x2 = {-1, -1, 0, 0}; static struct i27i8c6c5 x3 = {-1, 0, -1, 0}; static struct i27i8c6c5 x4 = {-1, -1, -1, -1}; print_prologue("i27i8c6c5", _Alignof(struct i27i8c6c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i31i5i13i7 {
  int a:31;
  int b:5;
  int c:13;
  int d:7;
};
static struct i31i5i13i7 x1 = {-1, 0, 0, 0}; static struct i31i5i13i7 x2 = {-1, -1, 0, 0}; static struct i31i5i13i7 x3 = {-1, 0, -1, 0}; static struct i31i5i13i7 x4 = {-1, -1, -1, -1}; print_prologue("i31i5i13i7", _Alignof(struct i31i5i13i7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s9i6s2 {
  int a:2;
  short b:9;
  int c:6;
  short d:2;
};
static struct i2s9i6s2 x1 = {-1, 0, 0, 0}; static struct i2s9i6s2 x2 = {-1, -1, 0, 0}; static struct i2s9i6s2 x3 = {-1, 0, -1, 0}; static struct i2s9i6s2 x4 = {-1, -1, -1, -1}; print_prologue("i2s9i6s2", _Alignof(struct i2s9i6s2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2c2i6b {
  int a:2;
  char b:2;
  int c:6;
  _Bool d;
};
static struct i2c2i6b x1 = {-1, 0, 0, 0}; static struct i2c2i6b x2 = {-1, -1, 0, 0}; static struct i2c2i6b x3 = {-1, 0, -1, 0}; static struct i2c2i6b x4 = {-1, -1, -1, -1}; print_prologue("i2c2i6b", _Alignof(struct i2c2i6b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S10i6i6C6i1i3 {
  short :10;
  int a:6;
  int b:6;
  char :6;
  int c:1;
  int d:3;
};
static struct S10i6i6C6i1i3 x1 = {-1, 0, 0, 0}; static struct S10i6i6C6i1i3 x2 = {-1, -1, 0, 0}; static struct S10i6i6C6i1i3 x3 = {-1, 0, -1, 0}; static struct S10i6i6C6i1i3 x4 = {-1, -1, -1, -1}; print_prologue("S10i6i6C6i1i3", _Alignof(struct S10i6i6C6i1i3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i13c1cc3 {
  int a:13;
  char b:1;
  char c;
  char d:3;
};
static struct i13c1cc3 x1 = {-1, 0, 0, 0}; static struct i13c1cc3 x2 = {-1, -1, 0, 0}; static struct i13c1cc3 x3 = {-1, 0, -1, 0}; static struct i13c1cc3 x4 = {-1, -1, -1, -1}; print_prologue("i13c1cc3", _Alignof(struct i13c1cc3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is15i4I0i19 {
  int a;
  short b:15;
  int c:4;
  int :0;
  int d:19;
};
static struct is15i4I0i19 x1 = {-1, 0, 0, 0}; static struct is15i4I0i19 x2 = {-1, -1, 0, 0}; static struct is15i4I0i19 x3 = {-1, 0, -1, 0}; static struct is15i4I0i19 x4 = {-1, -1, -1, -1}; print_prologue("is15i4I0i19", _Alignof(struct is15i4I0i19), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bc2i15s11 {
  _Bool a;
  char b:2;
  int c:15;
  short d:11;
};
static struct bc2i15s11 x1 = {-1, 0, 0, 0}; static struct bc2i15s11 x2 = {-1, -1, 0, 0}; static struct bc2i15s11 x3 = {-1, 0, -1, 0}; static struct bc2i15s11 x4 = {-1, -1, -1, -1}; print_prologue("bc2i15s11", _Alignof(struct bc2i15s11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bC7I0cc3s5 {
  _Bool a;
  char :7;
  int :0;
  char b;
  char c:3;
  short d:5;
};
static struct bC7I0cc3s5 x1 = {-1, 0, 0, 0}; static struct bC7I0cc3s5 x2 = {-1, -1, 0, 0}; static struct bC7I0cc3s5 x3 = {-1, 0, -1, 0}; static struct bC7I0cc3s5 x4 = {-1, -1, -1, -1}; print_prologue("bC7I0cc3s5", _Alignof(struct bC7I0cc3s5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s13iis6 {
  short a:13;
  int b;
  int c;
  short d:6;
};
static struct s13iis6 x1 = {-1, 0, 0, 0}; static struct s13iis6 x2 = {-1, -1, 0, 0}; static struct s13iis6 x3 = {-1, 0, -1, 0}; static struct s13iis6 x4 = {-1, -1, -1, -1}; print_prologue("s13iis6", _Alignof(struct s13iis6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i28S2bs4i32 {
  int a:28;
  short :2;
  _Bool b;
  short c:4;
  int d:32;
};
static struct i28S2bs4i32 x1 = {-1, 0, 0, 0}; static struct i28S2bs4i32 x2 = {-1, -1, 0, 0}; static struct i28S2bs4i32 x3 = {-1, 0, -1, 0}; static struct i28S2bs4i32 x4 = {-1, -1, -1, -1}; print_prologue("i28S2bs4i32", _Alignof(struct i28S2bs4i32), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cC8i1C6i12b {
  char a;
  char :8;
  int b:1;
  char :6;
  int c:12;
  _Bool d;
};
static struct cC8i1C6i12b x1 = {-1, 0, 0, 0}; static struct cC8i1C6i12b x2 = {-1, -1, 0, 0}; static struct cC8i1C6i12b x3 = {-1, 0, -1, 0}; static struct cC8i1C6i12b x4 = {-1, -1, -1, -1}; print_prologue("cC8i1C6i12b", _Alignof(struct cC8i1C6i12b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iii3s3 {
  int a;
  int b;
  int c:3;
  short d:3;
};
static struct iii3s3 x1 = {-1, 0, 0, 0}; static struct iii3s3 x2 = {-1, -1, 0, 0}; static struct iii3s3 x3 = {-1, 0, -1, 0}; static struct iii3s3 x4 = {-1, -1, -1, -1}; print_prologue("iii3s3", _Alignof(struct iii3s3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6c7s7i22 {
  char a:6;
  char b:7;
  short c:7;
  int d:22;
};
static struct c6c7s7i22 x1 = {-1, 0, 0, 0}; static struct c6c7s7i22 x2 = {-1, -1, 0, 0}; static struct c6c7s7i22 x3 = {-1, 0, -1, 0}; static struct c6c7s7i22 x4 = {-1, -1, -1, -1}; print_prologue("c6c7s7i22", _Alignof(struct c6c7s7i22), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I20i2iss7 {
  int :20;
  int a:2;
  int b;
  short c;
  short d:7;
};
static struct I20i2iss7 x1 = {-1, 0, 0, 0}; static struct I20i2iss7 x2 = {-1, -1, 0, 0}; static struct I20i2iss7 x3 = {-1, 0, -1, 0}; static struct I20i2iss7 x4 = {-1, -1, -1, -1}; print_prologue("I20i2iss7", _Alignof(struct I20i2iss7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cci26c {
  char a;
  char b;
  int c:26;
  char d;
};
static struct cci26c x1 = {-1, 0, 0, 0}; static struct cci26c x2 = {-1, -1, 0, 0}; static struct cci26c x3 = {-1, 0, -1, 0}; static struct cci26c x4 = {-1, -1, -1, -1}; print_prologue("cci26c", _Alignof(struct cci26c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i4c1is {
  int a:4;
  char b:1;
  int c;
  short d;
};
static struct i4c1is x1 = {-1, 0, 0, 0}; static struct i4c1is x2 = {-1, -1, 0, 0}; static struct i4c1is x3 = {-1, 0, -1, 0}; static struct i4c1is x4 = {-1, -1, -1, -1}; print_prologue("i4c1is", _Alignof(struct i4c1is), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i10i3i13c5 {
  int a:10;
  int b:3;
  int c:13;
  char d:5;
};
static struct i10i3i13c5 x1 = {-1, 0, 0, 0}; static struct i10i3i13c5 x2 = {-1, -1, 0, 0}; static struct i10i3i13c5 x3 = {-1, 0, -1, 0}; static struct i10i3i13c5 x4 = {-1, -1, -1, -1}; print_prologue("i10i3i13c5", _Alignof(struct i10i3i13c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i28s16b1b1 {
  int a:28;
  short b:16;
  _Bool c:1;
  _Bool d:1;
};
static struct i28s16b1b1 x1 = {-1, 0, 0, 0}; static struct i28s16b1b1 x2 = {-1, -1, 0, 0}; static struct i28s16b1b1 x3 = {-1, 0, -1, 0}; static struct i28s16b1b1 x4 = {-1, -1, -1, -1}; print_prologue("i28s16b1b1", _Alignof(struct i28s16b1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iiii3 {
  int a;
  int b;
  int c;
  int d:3;
};
static struct iiii3 x1 = {-1, 0, 0, 0}; static struct iiii3 x2 = {-1, -1, 0, 0}; static struct iiii3 x3 = {-1, 0, -1, 0}; static struct iiii3 x4 = {-1, -1, -1, -1}; print_prologue("iiii3", _Alignof(struct iiii3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i13si9i2 {
  int a:13;
  short b;
  int c:9;
  int d:2;
};
static struct i13si9i2 x1 = {-1, 0, 0, 0}; static struct i13si9i2 x2 = {-1, -1, 0, 0}; static struct i13si9i2 x3 = {-1, 0, -1, 0}; static struct i13si9i2 x4 = {-1, -1, -1, -1}; print_prologue("i13si9i2", _Alignof(struct i13si9i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s6i6i22s5 {
  short a:6;
  int b:6;
  int c:22;
  short d:5;
};
static struct s6i6i22s5 x1 = {-1, 0, 0, 0}; static struct s6i6i22s5 x2 = {-1, -1, 0, 0}; static struct s6i6i22s5 x3 = {-1, 0, -1, 0}; static struct s6i6i22s5 x4 = {-1, -1, -1, -1}; print_prologue("s6i6i22s5", _Alignof(struct s6i6i22s5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7b1S8s6S3I6i2 {
  char a:7;
  _Bool b:1;
  short :8;
  short c:6;
  short :3;
  int :6;
  int d:2;
};
static struct c7b1S8s6S3I6i2 x1 = {-1, 0, 0, 0}; static struct c7b1S8s6S3I6i2 x2 = {-1, -1, 0, 0}; static struct c7b1S8s6S3I6i2 x3 = {-1, 0, -1, 0}; static struct c7b1S8s6S3I6i2 x4 = {-1, -1, -1, -1}; print_prologue("c7b1S8s6S3I6i2", _Alignof(struct c7b1S8s6S3I6i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5i5si11 {
  int a:5;
  int b:5;
  short c;
  int d:11;
};
static struct i5i5si11 x1 = {-1, 0, 0, 0}; static struct i5i5si11 x2 = {-1, -1, 0, 0}; static struct i5i5si11 x3 = {-1, 0, -1, 0}; static struct i5i5si11 x4 = {-1, -1, -1, -1}; print_prologue("i5i5si11", _Alignof(struct i5i5si11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iI2s14i12c4 {
  int a;
  int :2;
  short b:14;
  int c:12;
  char d:4;
};
static struct iI2s14i12c4 x1 = {-1, 0, 0, 0}; static struct iI2s14i12c4 x2 = {-1, -1, 0, 0}; static struct iI2s14i12c4 x3 = {-1, 0, -1, 0}; static struct iI2s14i12c4 x4 = {-1, -1, -1, -1}; print_prologue("iI2s14i12c4", _Alignof(struct iI2s14i12c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is5c1b {
  int a;
  short b:5;
  char c:1;
  _Bool d;
};
static struct is5c1b x1 = {-1, 0, 0, 0}; static struct is5c1b x2 = {-1, -1, 0, 0}; static struct is5c1b x3 = {-1, 0, -1, 0}; static struct is5c1b x4 = {-1, -1, -1, -1}; print_prologue("is5c1b", _Alignof(struct is5c1b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iC1c5i32i {
  int a;
  char :1;
  char b:5;
  int c:32;
  int d;
};
static struct iC1c5i32i x1 = {-1, 0, 0, 0}; static struct iC1c5i32i x2 = {-1, -1, 0, 0}; static struct iC1c5i32i x3 = {-1, 0, -1, 0}; static struct iC1c5i32i x4 = {-1, -1, -1, -1}; print_prologue("iC1c5i32i", _Alignof(struct iC1c5i32i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6c3is9 {
  char a:6;
  char b:3;
  int c;
  short d:9;
};
static struct c6c3is9 x1 = {-1, 0, 0, 0}; static struct c6c3is9 x2 = {-1, -1, 0, 0}; static struct c6c3is9 x3 = {-1, 0, -1, 0}; static struct c6c3is9 x4 = {-1, -1, -1, -1}; print_prologue("c6c3is9", _Alignof(struct c6c3is9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ici15b1 {
  int a;
  char b;
  int c:15;
  _Bool d:1;
};
static struct ici15b1 x1 = {-1, 0, 0, 0}; static struct ici15b1 x2 = {-1, -1, 0, 0}; static struct ici15b1 x3 = {-1, 0, -1, 0}; static struct ici15b1 x4 = {-1, -1, -1, -1}; print_prologue("ici15b1", _Alignof(struct ici15b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i11s5b1i17 {
  int a:11;
  short b:5;
  _Bool c:1;
  int d:17;
};
static struct i11s5b1i17 x1 = {-1, 0, 0, 0}; static struct i11s5b1i17 x2 = {-1, -1, 0, 0}; static struct i11s5b1i17 x3 = {-1, 0, -1, 0}; static struct i11s5b1i17 x4 = {-1, -1, -1, -1}; print_prologue("i11s5b1i17", _Alignof(struct i11s5b1i17), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i12s5i10i13 {
  int a:12;
  short b:5;
  int c:10;
  int d:13;
};
static struct i12s5i10i13 x1 = {-1, 0, 0, 0}; static struct i12s5i10i13 x2 = {-1, -1, 0, 0}; static struct i12s5i10i13 x3 = {-1, 0, -1, 0}; static struct i12s5i10i13 x4 = {-1, -1, -1, -1}; print_prologue("i12s5i10i13", _Alignof(struct i12s5i10i13), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i22c3s1s2 {
  int a:22;
  char b:3;
  short c:1;
  short d:2;
};
static struct i22c3s1s2 x1 = {-1, 0, 0, 0}; static struct i22c3s1s2 x2 = {-1, -1, 0, 0}; static struct i22c3s1s2 x3 = {-1, 0, -1, 0}; static struct i22c3s1s2 x4 = {-1, -1, -1, -1}; print_prologue("i22c3s1s2", _Alignof(struct i22c3s1s2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1b1i3s9 {
  int a:1;
  _Bool b:1;
  int c:3;
  short d:9;
};
static struct i1b1i3s9 x1 = {-1, 0, 0, 0}; static struct i1b1i3s9 x2 = {-1, -1, 0, 0}; static struct i1b1i3s9 x3 = {-1, 0, -1, 0}; static struct i1b1i3s9 x4 = {-1, -1, -1, -1}; print_prologue("i1b1i3s9", _Alignof(struct i1b1i3s9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2i2i18s1 {
  int a:2;
  int b:2;
  int c:18;
  short d:1;
};
static struct i2i2i18s1 x1 = {-1, 0, 0, 0}; static struct i2i2i18s1 x2 = {-1, -1, 0, 0}; static struct i2i2i18s1 x3 = {-1, 0, -1, 0}; static struct i2i2i18s1 x4 = {-1, -1, -1, -1}; print_prologue("i2i2i18s1", _Alignof(struct i2i2i18s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bi1i1i {
  _Bool a;
  int b:1;
  int c:1;
  int d;
};
static struct bi1i1i x1 = {-1, 0, 0, 0}; static struct bi1i1i x2 = {-1, -1, 0, 0}; static struct bi1i1i x3 = {-1, 0, -1, 0}; static struct bi1i1i x4 = {-1, -1, -1, -1}; print_prologue("bi1i1i", _Alignof(struct bi1i1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1i1i14i1 {
  char a:1;
  int b:1;
  int c:14;
  int d:1;
};
static struct c1i1i14i1 x1 = {-1, 0, 0, 0}; static struct c1i1i14i1 x2 = {-1, -1, 0, 0}; static struct c1i1i14i1 x3 = {-1, 0, -1, 0}; static struct c1i1i14i1 x4 = {-1, -1, -1, -1}; print_prologue("c1i1i14i1", _Alignof(struct c1i1i14i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s6b1i1i {
  short a:6;
  _Bool b:1;
  int c:1;
  int d;
};
static struct s6b1i1i x1 = {-1, 0, 0, 0}; static struct s6b1i1i x2 = {-1, -1, 0, 0}; static struct s6b1i1i x3 = {-1, 0, -1, 0}; static struct s6b1i1i x4 = {-1, -1, -1, -1}; print_prologue("s6b1i1i", _Alignof(struct s6b1i1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2C0s1b1B1b {
  short a:2;
  char :0;
  short b:1;
  _Bool c:1;
  _Bool :1;
  _Bool d;
};
static struct s2C0s1b1B1b x1 = {-1, 0, 0, 0}; static struct s2C0s1b1B1b x2 = {-1, -1, 0, 0}; static struct s2C0s1b1B1b x3 = {-1, 0, -1, 0}; static struct s2C0s1b1B1b x4 = {-1, -1, -1, -1}; print_prologue("s2C0s1b1B1b", _Alignof(struct s2C0s1b1B1b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0I1s4ii2s16 {
  int :0;
  int :1;
  short a:4;
  int b;
  int c:2;
  short d:16;
};
static struct I0I1s4ii2s16 x1 = {-1, 0, 0, 0}; static struct I0I1s4ii2s16 x2 = {-1, -1, 0, 0}; static struct I0I1s4ii2s16 x3 = {-1, 0, -1, 0}; static struct I0I1s4ii2s16 x4 = {-1, -1, -1, -1}; print_prologue("I0I1s4ii2s16", _Alignof(struct I0I1s4ii2s16), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C4is14bi4 {
  char :4;
  int a;
  short b:14;
  _Bool c;
  int d:4;
};
static struct C4is14bi4 x1 = {-1, 0, 0, 0}; static struct C4is14bi4 x2 = {-1, -1, 0, 0}; static struct C4is14bi4 x3 = {-1, 0, -1, 0}; static struct C4is14bi4 x4 = {-1, -1, -1, -1}; print_prologue("C4is14bi4", _Alignof(struct C4is14bi4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6I7C0c6i18s1 {
  char a:6;
  int :7;
  char :0;
  char b:6;
  int c:18;
  short d:1;
};
static struct c6I7C0c6i18s1 x1 = {-1, 0, 0, 0}; static struct c6I7C0c6i18s1 x2 = {-1, -1, 0, 0}; static struct c6I7C0c6i18s1 x3 = {-1, 0, -1, 0}; static struct c6I7C0c6i18s1 x4 = {-1, -1, -1, -1}; print_prologue("c6I7C0c6i18s1", _Alignof(struct c6I7C0c6i18s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s5c2i20c6 {
  short a:5;
  char b:2;
  int c:20;
  char d:6;
};
static struct s5c2i20c6 x1 = {-1, 0, 0, 0}; static struct s5c2i20c6 x2 = {-1, -1, 0, 0}; static struct s5c2i20c6 x3 = {-1, 0, -1, 0}; static struct s5c2i20c6 x4 = {-1, -1, -1, -1}; print_prologue("s5c2i20c6", _Alignof(struct s5c2i20c6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s15s4ii {
  short a:15;
  short b:4;
  int c;
  int d;
};
static struct s15s4ii x1 = {-1, 0, 0, 0}; static struct s15s4ii x2 = {-1, -1, 0, 0}; static struct s15s4ii x3 = {-1, 0, -1, 0}; static struct s15s4ii x4 = {-1, -1, -1, -1}; print_prologue("s15s4ii", _Alignof(struct s15s4ii), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4s2i28i14 {
  char a:4;
  short b:2;
  int c:28;
  int d:14;
};
static struct c4s2i28i14 x1 = {-1, 0, 0, 0}; static struct c4s2i28i14 x2 = {-1, -1, 0, 0}; static struct c4s2i28i14 x3 = {-1, 0, -1, 0}; static struct c4s2i28i14 x4 = {-1, -1, -1, -1}; print_prologue("c4s2i28i14", _Alignof(struct c4s2i28i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ic8i29C0i {
  int a;
  char b:8;
  int c:29;
  char :0;
  int d;
};
static struct ic8i29C0i x1 = {-1, 0, 0, 0}; static struct ic8i29C0i x2 = {-1, -1, 0, 0}; static struct ic8i29C0i x3 = {-1, 0, -1, 0}; static struct ic8i29C0i x4 = {-1, -1, -1, -1}; print_prologue("ic8i29C0i", _Alignof(struct ic8i29C0i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1ii15i31 {
  short a:1;
  int b;
  int c:15;
  int d:31;
};
static struct s1ii15i31 x1 = {-1, 0, 0, 0}; static struct s1ii15i31 x2 = {-1, -1, 0, 0}; static struct s1ii15i31 x3 = {-1, 0, -1, 0}; static struct s1ii15i31 x4 = {-1, -1, -1, -1}; print_prologue("s1ii15i31", _Alignof(struct s1ii15i31), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0I12si2s5s9 {
  int :0;
  int :12;
  short a;
  int b:2;
  short c:5;
  short d:9;
};
static struct I0I12si2s5s9 x1 = {-1, 0, 0, 0}; static struct I0I12si2s5s9 x2 = {-1, -1, 0, 0}; static struct I0I12si2s5s9 x3 = {-1, 0, -1, 0}; static struct I0I12si2s5s9 x4 = {-1, -1, -1, -1}; print_prologue("I0I12si2s5s9", _Alignof(struct I0I12si2s5s9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1C7b1S3i2s4 {
  char a:1;
  char :7;
  _Bool b:1;
  short :3;
  int c:2;
  short d:4;
};
static struct c1C7b1S3i2s4 x1 = {-1, 0, 0, 0}; static struct c1C7b1S3i2s4 x2 = {-1, -1, 0, 0}; static struct c1C7b1S3i2s4 x3 = {-1, 0, -1, 0}; static struct c1C7b1S3i2s4 x4 = {-1, -1, -1, -1}; print_prologue("c1C7b1S3i2s4", _Alignof(struct c1C7b1S3i2s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3i13i25c1 {
  char a:3;
  int b:13;
  int c:25;
  char d:1;
};
static struct c3i13i25c1 x1 = {-1, 0, 0, 0}; static struct c3i13i25c1 x2 = {-1, -1, 0, 0}; static struct c3i13i25c1 x3 = {-1, 0, -1, 0}; static struct c3i13i25c1 x4 = {-1, -1, -1, -1}; print_prologue("c3i13i25c1", _Alignof(struct c3i13i25c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i24C0cc7I0s7 {
  int a:24;
  char :0;
  char b;
  char c:7;
  int :0;
  short d:7;
};
static struct i24C0cc7I0s7 x1 = {-1, 0, 0, 0}; static struct i24C0cc7I0s7 x2 = {-1, -1, 0, 0}; static struct i24C0cc7I0s7 x3 = {-1, 0, -1, 0}; static struct i24C0cc7I0s7 x4 = {-1, -1, -1, -1}; print_prologue("i24C0cc7I0s7", _Alignof(struct i24C0cc7I0s7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S10i5I26i26b1i {
  short :10;
  int a:5;
  int :26;
  int b:26;
  _Bool c:1;
  int d;
};
static struct S10i5I26i26b1i x1 = {-1, 0, 0, 0}; static struct S10i5I26i26b1i x2 = {-1, -1, 0, 0}; static struct S10i5I26i26b1i x3 = {-1, 0, -1, 0}; static struct S10i5I26i26b1i x4 = {-1, -1, -1, -1}; print_prologue("S10i5I26i26b1i", _Alignof(struct S10i5I26i26b1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s12I15ss2s5 {
  short a:12;
  int :15;
  short b;
  short c:2;
  short d:5;
};
static struct s12I15ss2s5 x1 = {-1, 0, 0, 0}; static struct s12I15ss2s5 x2 = {-1, -1, 0, 0}; static struct s12I15ss2s5 x3 = {-1, 0, -1, 0}; static struct s12I15ss2s5 x4 = {-1, -1, -1, -1}; print_prologue("s12I15ss2s5", _Alignof(struct s12I15ss2s5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I5ii1b1b {
  int :5;
  int a;
  int b:1;
  _Bool c:1;
  _Bool d;
};
static struct I5ii1b1b x1 = {-1, 0, 0, 0}; static struct I5ii1b1b x2 = {-1, -1, 0, 0}; static struct I5ii1b1b x3 = {-1, 0, -1, 0}; static struct I5ii1b1b x4 = {-1, -1, -1, -1}; print_prologue("I5ii1b1b", _Alignof(struct I5ii1b1b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I14i11C1s1i4c {
  int :14;
  int a:11;
  char :1;
  short b:1;
  int c:4;
  char d;
};
static struct I14i11C1s1i4c x1 = {-1, 0, 0, 0}; static struct I14i11C1s1i4c x2 = {-1, -1, 0, 0}; static struct I14i11C1s1i4c x3 = {-1, 0, -1, 0}; static struct I14i11C1s1i4c x4 = {-1, -1, -1, -1}; print_prologue("I14i11C1s1i4c", _Alignof(struct I14i11C1s1i4c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i29s8c3c4 {
  int a:29;
  short b:8;
  char c:3;
  char d:4;
};
static struct i29s8c3c4 x1 = {-1, 0, 0, 0}; static struct i29s8c3c4 x2 = {-1, -1, 0, 0}; static struct i29s8c3c4 x3 = {-1, 0, -1, 0}; static struct i29s8c3c4 x4 = {-1, -1, -1, -1}; print_prologue("i29s8c3c4", _Alignof(struct i29s8c3c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4s2s1i15 {
  char a:4;
  short b:2;
  short c:1;
  int d:15;
};
static struct c4s2s1i15 x1 = {-1, 0, 0, 0}; static struct c4s2s1i15 x2 = {-1, -1, 0, 0}; static struct c4s2s1i15 x3 = {-1, 0, -1, 0}; static struct c4s2s1i15 x4 = {-1, -1, -1, -1}; print_prologue("c4s2s1i15", _Alignof(struct c4s2s1i15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii9s2s1 {
  int a;
  int b:9;
  short c:2;
  short d:1;
};
static struct ii9s2s1 x1 = {-1, 0, 0, 0}; static struct ii9s2s1 x2 = {-1, -1, 0, 0}; static struct ii9s2s1 x3 = {-1, 0, -1, 0}; static struct ii9s2s1 x4 = {-1, -1, -1, -1}; print_prologue("ii9s2s1", _Alignof(struct ii9s2s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i28i11i4i30 {
  int a:28;
  int b:11;
  int c:4;
  int d:30;
};
static struct i28i11i4i30 x1 = {-1, 0, 0, 0}; static struct i28i11i4i30 x2 = {-1, -1, 0, 0}; static struct i28i11i4i30 x3 = {-1, 0, -1, 0}; static struct i28i11i4i30 x4 = {-1, -1, -1, -1}; print_prologue("i28i11i4i30", _Alignof(struct i28i11i4i30), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s9si1i28 {
  short a:9;
  short b;
  int c:1;
  int d:28;
};
static struct s9si1i28 x1 = {-1, 0, 0, 0}; static struct s9si1i28 x2 = {-1, -1, 0, 0}; static struct s9si1i28 x3 = {-1, 0, -1, 0}; static struct s9si1i28 x4 = {-1, -1, -1, -1}; print_prologue("s9si1i28", _Alignof(struct s9si1i28), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7s2C7I0c1b1 {
  char a:7;
  short b:2;
  char :7;
  int :0;
  char c:1;
  _Bool d:1;
};
static struct c7s2C7I0c1b1 x1 = {-1, 0, 0, 0}; static struct c7s2C7I0c1b1 x2 = {-1, -1, 0, 0}; static struct c7s2C7I0c1b1 x3 = {-1, 0, -1, 0}; static struct c7s2C7I0c1b1 x4 = {-1, -1, -1, -1}; print_prologue("c7s2C7I0c1b1", _Alignof(struct c7s2C7I0c1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5i11ii30 {
  char a:5;
  int b:11;
  int c;
  int d:30;
};
static struct c5i11ii30 x1 = {-1, 0, 0, 0}; static struct c5i11ii30 x2 = {-1, -1, 0, 0}; static struct c5i11ii30 x3 = {-1, 0, -1, 0}; static struct c5i11ii30 x4 = {-1, -1, -1, -1}; print_prologue("c5i11ii30", _Alignof(struct c5i11ii30), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2ii7b1 {
  int a:2;
  int b;
  int c:7;
  _Bool d:1;
};
static struct i2ii7b1 x1 = {-1, 0, 0, 0}; static struct i2ii7b1 x2 = {-1, -1, 0, 0}; static struct i2ii7b1 x3 = {-1, 0, -1, 0}; static struct i2ii7b1 x4 = {-1, -1, -1, -1}; print_prologue("i2ii7b1", _Alignof(struct i2ii7b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S10b1i4i1c6 {
  short :10;
  _Bool a:1;
  int b:4;
  int c:1;
  char d:6;
};
static struct S10b1i4i1c6 x1 = {-1, 0, 0, 0}; static struct S10b1i4i1c6 x2 = {-1, -1, 0, 0}; static struct S10b1i4i1c6 x3 = {-1, 0, -1, 0}; static struct S10b1i4i1c6 x4 = {-1, -1, -1, -1}; print_prologue("S10b1i4i1c6", _Alignof(struct S10b1i4i1c6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cs9s14s9 {
  char a;
  short b:9;
  short c:14;
  short d:9;
};
static struct cs9s14s9 x1 = {-1, 0, 0, 0}; static struct cs9s14s9 x2 = {-1, -1, 0, 0}; static struct cs9s14s9 x3 = {-1, 0, -1, 0}; static struct cs9s14s9 x4 = {-1, -1, -1, -1}; print_prologue("cs9s14s9", _Alignof(struct cs9s14s9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1i3b1i5 {
  short a:1;
  int b:3;
  _Bool c:1;
  int d:5;
};
static struct s1i3b1i5 x1 = {-1, 0, 0, 0}; static struct s1i3b1i5 x2 = {-1, -1, 0, 0}; static struct s1i3b1i5 x3 = {-1, 0, -1, 0}; static struct s1i3b1i5 x4 = {-1, -1, -1, -1}; print_prologue("s1i3b1i5", _Alignof(struct s1i3b1i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cbI27c3c2 {
  char a;
  _Bool b;
  int :27;
  char c:3;
  char d:2;
};
static struct cbI27c3c2 x1 = {-1, 0, 0, 0}; static struct cbI27c3c2 x2 = {-1, -1, 0, 0}; static struct cbI27c3c2 x3 = {-1, 0, -1, 0}; static struct cbI27c3c2 x4 = {-1, -1, -1, -1}; print_prologue("cbI27c3c2", _Alignof(struct cbI27c3c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7b1c3i28 {
  int a:7;
  _Bool b:1;
  char c:3;
  int d:28;
};
static struct i7b1c3i28 x1 = {-1, 0, 0, 0}; static struct i7b1c3i28 x2 = {-1, -1, 0, 0}; static struct i7b1c3i28 x3 = {-1, 0, -1, 0}; static struct i7b1c3i28 x4 = {-1, -1, -1, -1}; print_prologue("i7b1c3i28", _Alignof(struct i7b1c3i28), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2i22s8i2 {
  int a:2;
  int b:22;
  short c:8;
  int d:2;
};
static struct i2i22s8i2 x1 = {-1, 0, 0, 0}; static struct i2i22s8i2 x2 = {-1, -1, 0, 0}; static struct i2i22s8i2 x3 = {-1, 0, -1, 0}; static struct i2i22s8i2 x4 = {-1, -1, -1, -1}; print_prologue("i2i22s8i2", _Alignof(struct i2i22s8i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i12c7I0C5s2i28 {
  int a:12;
  char b:7;
  int :0;
  char :5;
  short c:2;
  int d:28;
};
static struct i12c7I0C5s2i28 x1 = {-1, 0, 0, 0}; static struct i12c7I0C5s2i28 x2 = {-1, -1, 0, 0}; static struct i12c7I0C5s2i28 x3 = {-1, 0, -1, 0}; static struct i12c7I0C5s2i28 x4 = {-1, -1, -1, -1}; print_prologue("i12c7I0C5s2i28", _Alignof(struct i12c7I0C5s2i28), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1iss3 {
  _Bool a:1;
  int b;
  short c;
  short d:3;
};
static struct b1iss3 x1 = {-1, 0, 0, 0}; static struct b1iss3 x2 = {-1, -1, 0, 0}; static struct b1iss3 x3 = {-1, 0, -1, 0}; static struct b1iss3 x4 = {-1, -1, -1, -1}; print_prologue("b1iss3", _Alignof(struct b1iss3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1c5c1s2 {
  int a:1;
  char b:5;
  char c:1;
  short d:2;
};
static struct i1c5c1s2 x1 = {-1, 0, 0, 0}; static struct i1c5c1s2 x2 = {-1, -1, 0, 0}; static struct i1c5c1s2 x3 = {-1, 0, -1, 0}; static struct i1c5c1s2 x4 = {-1, -1, -1, -1}; print_prologue("i1c5c1s2", _Alignof(struct i1c5c1s2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bi6i27b {
  _Bool a;
  int b:6;
  int c:27;
  _Bool d;
};
static struct bi6i27b x1 = {-1, 0, 0, 0}; static struct bi6i27b x2 = {-1, -1, 0, 0}; static struct bi6i27b x3 = {-1, 0, -1, 0}; static struct bi6i27b x4 = {-1, -1, -1, -1}; print_prologue("bi6i27b", _Alignof(struct bi6i27b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4c5sc {
  char a:4;
  char b:5;
  short c;
  char d;
};
static struct c4c5sc x1 = {-1, 0, 0, 0}; static struct c4c5sc x2 = {-1, -1, 0, 0}; static struct c4c5sc x3 = {-1, 0, -1, 0}; static struct c4c5sc x4 = {-1, -1, -1, -1}; print_prologue("c4c5sc", _Alignof(struct c4c5sc), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2ii1c4 {
  char a:2;
  int b;
  int c:1;
  char d:4;
};
static struct c2ii1c4 x1 = {-1, 0, 0, 0}; static struct c2ii1c4 x2 = {-1, -1, 0, 0}; static struct c2ii1c4 x3 = {-1, 0, -1, 0}; static struct c2ii1c4 x4 = {-1, -1, -1, -1}; print_prologue("c2ii1c4", _Alignof(struct c2ii1c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct isi13S3b1 {
  int a;
  short b;
  int c:13;
  short :3;
  _Bool d:1;
};
static struct isi13S3b1 x1 = {-1, 0, 0, 0}; static struct isi13S3b1 x2 = {-1, -1, 0, 0}; static struct isi13S3b1 x3 = {-1, 0, -1, 0}; static struct isi13S3b1 x4 = {-1, -1, -1, -1}; print_prologue("isi13S3b1", _Alignof(struct isi13S3b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i23i20ii1 {
  int a:23;
  int b:20;
  int c;
  int d:1;
};
static struct i23i20ii1 x1 = {-1, 0, 0, 0}; static struct i23i20ii1 x2 = {-1, -1, 0, 0}; static struct i23i20ii1 x3 = {-1, 0, -1, 0}; static struct i23i20ii1 x4 = {-1, -1, -1, -1}; print_prologue("i23i20ii1", _Alignof(struct i23i20ii1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2b1s1b {
  int a:2;
  _Bool b:1;
  short c:1;
  _Bool d;
};
static struct i2b1s1b x1 = {-1, 0, 0, 0}; static struct i2b1s1b x2 = {-1, -1, 0, 0}; static struct i2b1s1b x3 = {-1, 0, -1, 0}; static struct i2b1s1b x4 = {-1, -1, -1, -1}; print_prologue("i2b1s1b", _Alignof(struct i2b1s1b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ic1c3s2 {
  int a;
  char b:1;
  char c:3;
  short d:2;
};
static struct ic1c3s2 x1 = {-1, 0, 0, 0}; static struct ic1c3s2 x2 = {-1, -1, 0, 0}; static struct ic1c3s2 x3 = {-1, 0, -1, 0}; static struct ic1c3s2 x4 = {-1, -1, -1, -1}; print_prologue("ic1c3s2", _Alignof(struct ic1c3s2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1iI7c4i4 {
  _Bool a:1;
  int b;
  int :7;
  char c:4;
  int d:4;
};
static struct b1iI7c4i4 x1 = {-1, 0, 0, 0}; static struct b1iI7c4i4 x2 = {-1, -1, 0, 0}; static struct b1iI7c4i4 x3 = {-1, 0, -1, 0}; static struct b1iI7c4i4 x4 = {-1, -1, -1, -1}; print_prologue("b1iI7c4i4", _Alignof(struct b1iI7c4i4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S4ci13i4s1 {
  short :4;
  char a;
  int b:13;
  int c:4;
  short d:1;
};
static struct S4ci13i4s1 x1 = {-1, 0, 0, 0}; static struct S4ci13i4s1 x2 = {-1, -1, 0, 0}; static struct S4ci13i4s1 x3 = {-1, 0, -1, 0}; static struct S4ci13i4s1 x4 = {-1, -1, -1, -1}; print_prologue("S4ci13i4s1", _Alignof(struct S4ci13i4s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i13i8b1i2 {
  int a:13;
  int b:8;
  _Bool c:1;
  int d:2;
};
static struct i13i8b1i2 x1 = {-1, 0, 0, 0}; static struct i13i8b1i2 x2 = {-1, -1, 0, 0}; static struct i13i8b1i2 x3 = {-1, 0, -1, 0}; static struct i13i8b1i2 x4 = {-1, -1, -1, -1}; print_prologue("i13i8b1i2", _Alignof(struct i13i8b1i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5b1i10i20 {
  char a:5;
  _Bool b:1;
  int c:10;
  int d:20;
};
static struct c5b1i10i20 x1 = {-1, 0, 0, 0}; static struct c5b1i10i20 x2 = {-1, -1, 0, 0}; static struct c5b1i10i20 x3 = {-1, 0, -1, 0}; static struct c5b1i10i20 x4 = {-1, -1, -1, -1}; print_prologue("c5b1i10i20", _Alignof(struct c5b1i10i20), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i8ci4B0c2 {
  int a:8;
  char b;
  int c:4;
  _Bool :0;
  char d:2;
};
static struct i8ci4B0c2 x1 = {-1, 0, 0, 0}; static struct i8ci4B0c2 x2 = {-1, -1, 0, 0}; static struct i8ci4B0c2 x3 = {-1, 0, -1, 0}; static struct i8ci4B0c2 x4 = {-1, -1, -1, -1}; print_prologue("i8ci4B0c2", _Alignof(struct i8ci4B0c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i8ii2 {
  _Bool a:1;
  int b:8;
  int c;
  int d:2;
};
static struct b1i8ii2 x1 = {-1, 0, 0, 0}; static struct b1i8ii2 x2 = {-1, -1, 0, 0}; static struct b1i8ii2 x3 = {-1, 0, -1, 0}; static struct b1i8ii2 x4 = {-1, -1, -1, -1}; print_prologue("b1i8ii2", _Alignof(struct b1i8ii2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i6c5i18i3 {
  int a:6;
  char b:5;
  int c:18;
  int d:3;
};
static struct i6c5i18i3 x1 = {-1, 0, 0, 0}; static struct i6c5i18i3 x2 = {-1, -1, 0, 0}; static struct i6c5i18i3 x3 = {-1, 0, -1, 0}; static struct i6c5i18i3 x4 = {-1, -1, -1, -1}; print_prologue("i6c5i18i3", _Alignof(struct i6c5i18i3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6i26i11c8 {
  char a:6;
  int b:26;
  int c:11;
  char d:8;
};
static struct c6i26i11c8 x1 = {-1, 0, 0, 0}; static struct c6i26i11c8 x2 = {-1, -1, 0, 0}; static struct c6i26i11c8 x3 = {-1, 0, -1, 0}; static struct c6i26i11c8 x4 = {-1, -1, -1, -1}; print_prologue("c6i26i11c8", _Alignof(struct c6i26i11c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0i2b1i9b1 {
  int :0;
  int a:2;
  _Bool b:1;
  int c:9;
  _Bool d:1;
};
static struct I0i2b1i9b1 x1 = {-1, 0, 0, 0}; static struct I0i2b1i9b1 x2 = {-1, -1, 0, 0}; static struct I0i2b1i9b1 x3 = {-1, 0, -1, 0}; static struct I0i2b1i9b1 x4 = {-1, -1, -1, -1}; print_prologue("I0i2b1i9b1", _Alignof(struct I0i2b1i9b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2i9B1s1b1 {
  short a:2;
  int b:9;
  _Bool :1;
  short c:1;
  _Bool d:1;
};
static struct s2i9B1s1b1 x1 = {-1, 0, 0, 0}; static struct s2i9B1s1b1 x2 = {-1, -1, 0, 0}; static struct s2i9B1s1b1 x3 = {-1, 0, -1, 0}; static struct s2i9B1s1b1 x4 = {-1, -1, -1, -1}; print_prologue("s2i9B1s1b1", _Alignof(struct s2i9B1s1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii6b1i {
  int a;
  int b:6;
  _Bool c:1;
  int d;
};
static struct ii6b1i x1 = {-1, 0, 0, 0}; static struct ii6b1i x2 = {-1, -1, 0, 0}; static struct ii6b1i x3 = {-1, 0, -1, 0}; static struct ii6b1i x4 = {-1, -1, -1, -1}; print_prologue("ii6b1i", _Alignof(struct ii6b1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I4si22c1c1 {
  int :4;
  short a;
  int b:22;
  char c:1;
  char d:1;
};
static struct I4si22c1c1 x1 = {-1, 0, 0, 0}; static struct I4si22c1c1 x2 = {-1, -1, 0, 0}; static struct I4si22c1c1 x3 = {-1, 0, -1, 0}; static struct I4si22c1c1 x4 = {-1, -1, -1, -1}; print_prologue("I4si22c1c1", _Alignof(struct I4si22c1c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iis4i1 {
  int a;
  int b;
  short c:4;
  int d:1;
};
static struct iis4i1 x1 = {-1, 0, 0, 0}; static struct iis4i1 x2 = {-1, -1, 0, 0}; static struct iis4i1 x3 = {-1, 0, -1, 0}; static struct iis4i1 x4 = {-1, -1, -1, -1}; print_prologue("iis4i1", _Alignof(struct iis4i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i4i2C0I4i1b1 {
  int a:4;
  int b:2;
  char :0;
  int :4;
  int c:1;
  _Bool d:1;
};
static struct i4i2C0I4i1b1 x1 = {-1, 0, 0, 0}; static struct i4i2C0I4i1b1 x2 = {-1, -1, 0, 0}; static struct i4i2C0I4i1b1 x3 = {-1, 0, -1, 0}; static struct i4i2C0I4i1b1 x4 = {-1, -1, -1, -1}; print_prologue("i4i2C0I4i1b1", _Alignof(struct i4i2C0I4i1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1ci20i {
  _Bool a:1;
  char b;
  int c:20;
  int d;
};
static struct b1ci20i x1 = {-1, 0, 0, 0}; static struct b1ci20i x2 = {-1, -1, 0, 0}; static struct b1ci20i x3 = {-1, 0, -1, 0}; static struct b1ci20i x4 = {-1, -1, -1, -1}; print_prologue("b1ci20i", _Alignof(struct b1ci20i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ciis1 {
  char a;
  int b;
  int c;
  short d:1;
};
static struct ciis1 x1 = {-1, 0, 0, 0}; static struct ciis1 x2 = {-1, -1, 0, 0}; static struct ciis1 x3 = {-1, 0, -1, 0}; static struct ciis1 x4 = {-1, -1, -1, -1}; print_prologue("ciis1", _Alignof(struct ciis1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C2s2s14i4s4 {
  char :2;
  short a:2;
  short b:14;
  int c:4;
  short d:4;
};
static struct C2s2s14i4s4 x1 = {-1, 0, 0, 0}; static struct C2s2s14i4s4 x2 = {-1, -1, 0, 0}; static struct C2s2s14i4s4 x3 = {-1, 0, -1, 0}; static struct C2s2s14i4s4 x4 = {-1, -1, -1, -1}; print_prologue("C2s2s14i4s4", _Alignof(struct C2s2s14i4s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1s1c6S3i13 {
  short a:1;
  short b:1;
  char c:6;
  short :3;
  int d:13;
};
static struct s1s1c6S3i13 x1 = {-1, 0, 0, 0}; static struct s1s1c6S3i13 x2 = {-1, -1, 0, 0}; static struct s1s1c6S3i13 x3 = {-1, 0, -1, 0}; static struct s1s1c6S3i13 x4 = {-1, -1, -1, -1}; print_prologue("s1s1c6S3i13", _Alignof(struct s1s1c6S3i13), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2s11ib1 {
  short a:2;
  short b:11;
  int c;
  _Bool d:1;
};
static struct s2s11ib1 x1 = {-1, 0, 0, 0}; static struct s2s11ib1 x2 = {-1, -1, 0, 0}; static struct s2s11ib1 x3 = {-1, 0, -1, 0}; static struct s2s11ib1 x4 = {-1, -1, -1, -1}; print_prologue("s2s11ib1", _Alignof(struct s2s11ib1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s9S8s14s2c4 {
  short a:9;
  short :8;
  short b:14;
  short c:2;
  char d:4;
};
static struct s9S8s14s2c4 x1 = {-1, 0, 0, 0}; static struct s9S8s14s2c4 x2 = {-1, -1, 0, 0}; static struct s9S8s14s2c4 x3 = {-1, 0, -1, 0}; static struct s9S8s14s2c4 x4 = {-1, -1, -1, -1}; print_prologue("s9S8s14s2c4", _Alignof(struct s9S8s14s2c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bc4i22i5 {
  _Bool a;
  char b:4;
  int c:22;
  int d:5;
};
static struct bc4i22i5 x1 = {-1, 0, 0, 0}; static struct bc4i22i5 x2 = {-1, -1, 0, 0}; static struct bc4i22i5 x3 = {-1, 0, -1, 0}; static struct bc4i22i5 x4 = {-1, -1, -1, -1}; print_prologue("bc4i22i5", _Alignof(struct bc4i22i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1ii9s6 {
  int a:1;
  int b;
  int c:9;
  short d:6;
};
static struct i1ii9s6 x1 = {-1, 0, 0, 0}; static struct i1ii9s6 x2 = {-1, -1, 0, 0}; static struct i1ii9s6 x3 = {-1, 0, -1, 0}; static struct i1ii9s6 x4 = {-1, -1, -1, -1}; print_prologue("i1ii9s6", _Alignof(struct i1ii9s6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i20ic8i15 {
  int a:20;
  int b;
  char c:8;
  int d:15;
};
static struct i20ic8i15 x1 = {-1, 0, 0, 0}; static struct i20ic8i15 x2 = {-1, -1, 0, 0}; static struct i20ic8i15 x3 = {-1, 0, -1, 0}; static struct i20ic8i15 x4 = {-1, -1, -1, -1}; print_prologue("i20ic8i15", _Alignof(struct i20ic8i15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2c7is {
  int a:2;
  char b:7;
  int c;
  short d;
};
static struct i2c7is x1 = {-1, 0, 0, 0}; static struct i2c7is x2 = {-1, -1, 0, 0}; static struct i2c7is x3 = {-1, 0, -1, 0}; static struct i2c7is x4 = {-1, -1, -1, -1}; print_prologue("i2c7is", _Alignof(struct i2c7is), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s16i6c1i8 {
  short a:16;
  int b:6;
  char c:1;
  int d:8;
};
static struct s16i6c1i8 x1 = {-1, 0, 0, 0}; static struct s16i6c1i8 x2 = {-1, -1, 0, 0}; static struct s16i6c1i8 x3 = {-1, 0, -1, 0}; static struct s16i6c1i8 x4 = {-1, -1, -1, -1}; print_prologue("s16i6c1i8", _Alignof(struct s16i6c1i8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2is8c1 {
  int a:2;
  int b;
  short c:8;
  char d:1;
};
static struct i2is8c1 x1 = {-1, 0, 0, 0}; static struct i2is8c1 x2 = {-1, -1, 0, 0}; static struct i2is8c1 x3 = {-1, 0, -1, 0}; static struct i2is8c1 x4 = {-1, -1, -1, -1}; print_prologue("i2is8c1", _Alignof(struct i2is8c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i8s3I12i6i6 {
  int a:8;
  short b:3;
  int :12;
  int c:6;
  int d:6;
};
static struct i8s3I12i6i6 x1 = {-1, 0, 0, 0}; static struct i8s3I12i6i6 x2 = {-1, -1, 0, 0}; static struct i8s3I12i6i6 x3 = {-1, 0, -1, 0}; static struct i8s3I12i6i6 x4 = {-1, -1, -1, -1}; print_prologue("i8s3I12i6i6", _Alignof(struct i8s3I12i6i6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1c5ii {
  int a:1;
  char b:5;
  int c;
  int d;
};
static struct i1c5ii x1 = {-1, 0, 0, 0}; static struct i1c5ii x2 = {-1, -1, 0, 0}; static struct i1c5ii x3 = {-1, 0, -1, 0}; static struct i1c5ii x4 = {-1, -1, -1, -1}; print_prologue("i1c5ii", _Alignof(struct i1c5ii), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii17i2b1 {
  int a;
  int b:17;
  int c:2;
  _Bool d:1;
};
static struct ii17i2b1 x1 = {-1, 0, 0, 0}; static struct ii17i2b1 x2 = {-1, -1, 0, 0}; static struct ii17i2b1 x3 = {-1, 0, -1, 0}; static struct ii17i2b1 x4 = {-1, -1, -1, -1}; print_prologue("ii17i2b1", _Alignof(struct ii17i2b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1b1s10 {
  int a;
  _Bool b:1;
  _Bool c:1;
  short d:10;
};
static struct ib1b1s10 x1 = {-1, 0, 0, 0}; static struct ib1b1s10 x2 = {-1, -1, 0, 0}; static struct ib1b1s10 x3 = {-1, 0, -1, 0}; static struct ib1b1s10 x4 = {-1, -1, -1, -1}; print_prologue("ib1b1s10", _Alignof(struct ib1b1s10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s8c1b1C4i {
  short a:8;
  char b:1;
  _Bool c:1;
  char :4;
  int d;
};
static struct s8c1b1C4i x1 = {-1, 0, 0, 0}; static struct s8c1b1C4i x2 = {-1, -1, 0, 0}; static struct s8c1b1C4i x3 = {-1, 0, -1, 0}; static struct s8c1b1C4i x4 = {-1, -1, -1, -1}; print_prologue("s8c1b1C4i", _Alignof(struct s8c1b1C4i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s16I0s8ib1 {
  short a:16;
  int :0;
  short b:8;
  int c;
  _Bool d:1;
};
static struct s16I0s8ib1 x1 = {-1, 0, 0, 0}; static struct s16I0s8ib1 x2 = {-1, -1, 0, 0}; static struct s16I0s8ib1 x3 = {-1, 0, -1, 0}; static struct s16I0s8ib1 x4 = {-1, -1, -1, -1}; print_prologue("s16I0s8ib1", _Alignof(struct s16I0s8ib1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s16c1b1s9 {
  short a:16;
  char b:1;
  _Bool c:1;
  short d:9;
};
static struct s16c1b1s9 x1 = {-1, 0, 0, 0}; static struct s16c1b1s9 x2 = {-1, -1, 0, 0}; static struct s16c1b1s9 x3 = {-1, 0, -1, 0}; static struct s16c1b1s9 x4 = {-1, -1, -1, -1}; print_prologue("s16c1b1s9", _Alignof(struct s16c1b1s9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0cii20c5 {
  int :0;
  char a;
  int b;
  int c:20;
  char d:5;
};
static struct I0cii20c5 x1 = {-1, 0, 0, 0}; static struct I0cii20c5 x2 = {-1, -1, 0, 0}; static struct I0cii20c5 x3 = {-1, 0, -1, 0}; static struct I0cii20c5 x4 = {-1, -1, -1, -1}; print_prologue("I0cii20c5", _Alignof(struct I0cii20c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bc7c5i {
  _Bool a;
  char b:7;
  char c:5;
  int d;
};
static struct bc7c5i x1 = {-1, 0, 0, 0}; static struct bc7c5i x2 = {-1, -1, 0, 0}; static struct bc7c5i x3 = {-1, 0, -1, 0}; static struct bc7c5i x4 = {-1, -1, -1, -1}; print_prologue("bc7c5i", _Alignof(struct bc7c5i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s7b1ii10 {
  short a:7;
  _Bool b:1;
  int c;
  int d:10;
};
static struct s7b1ii10 x1 = {-1, 0, 0, 0}; static struct s7b1ii10 x2 = {-1, -1, 0, 0}; static struct s7b1ii10 x3 = {-1, 0, -1, 0}; static struct s7b1ii10 x4 = {-1, -1, -1, -1}; print_prologue("s7b1ii10", _Alignof(struct s7b1ii10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i25C1S0c2s6i7 {
  int a:25;
  char :1;
  short :0;
  char b:2;
  short c:6;
  int d:7;
};
static struct i25C1S0c2s6i7 x1 = {-1, 0, 0, 0}; static struct i25C1S0c2s6i7 x2 = {-1, -1, 0, 0}; static struct i25C1S0c2s6i7 x3 = {-1, 0, -1, 0}; static struct i25C1S0c2s6i7 x4 = {-1, -1, -1, -1}; print_prologue("i25C1S0c2s6i7", _Alignof(struct i25C1S0c2s6i7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i28s12c5b1 {
  int a:28;
  short b:12;
  char c:5;
  _Bool d:1;
};
static struct i28s12c5b1 x1 = {-1, 0, 0, 0}; static struct i28s12c5b1 x2 = {-1, -1, 0, 0}; static struct i28s12c5b1 x3 = {-1, 0, -1, 0}; static struct i28s12c5b1 x4 = {-1, -1, -1, -1}; print_prologue("i28s12c5b1", _Alignof(struct i28s12c5b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i15i5i2s4 {
  int a:15;
  int b:5;
  int c:2;
  short d:4;
};
static struct i15i5i2s4 x1 = {-1, 0, 0, 0}; static struct i15i5i2s4 x2 = {-1, -1, 0, 0}; static struct i15i5i2s4 x3 = {-1, 0, -1, 0}; static struct i15i5i2s4 x4 = {-1, -1, -1, -1}; print_prologue("i15i5i2s4", _Alignof(struct i15i5i2s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ciI6ii9 {
  char a;
  int b;
  int :6;
  int c;
  int d:9;
};
static struct ciI6ii9 x1 = {-1, 0, 0, 0}; static struct ciI6ii9 x2 = {-1, -1, 0, 0}; static struct ciI6ii9 x3 = {-1, 0, -1, 0}; static struct ciI6ii9 x4 = {-1, -1, -1, -1}; print_prologue("ciI6ii9", _Alignof(struct ciI6ii9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s7ib1 {
  int a:2;
  short b:7;
  int c;
  _Bool d:1;
};
static struct i2s7ib1 x1 = {-1, 0, 0, 0}; static struct i2s7ib1 x2 = {-1, -1, 0, 0}; static struct i2s7ib1 x3 = {-1, 0, -1, 0}; static struct i2s7ib1 x4 = {-1, -1, -1, -1}; print_prologue("i2s7ib1", _Alignof(struct i2s7ib1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i6S11c6s8I6i3 {
  int a:6;
  short :11;
  char b:6;
  short c:8;
  int :6;
  int d:3;
};
static struct i6S11c6s8I6i3 x1 = {-1, 0, 0, 0}; static struct i6S11c6s8I6i3 x2 = {-1, -1, 0, 0}; static struct i6S11c6s8I6i3 x3 = {-1, 0, -1, 0}; static struct i6S11c6s8I6i3 x4 = {-1, -1, -1, -1}; print_prologue("i6S11c6s8I6i3", _Alignof(struct i6S11c6s8I6i3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7C1c5ss8 {
  char a:7;
  char :1;
  char b:5;
  short c;
  short d:8;
};
static struct c7C1c5ss8 x1 = {-1, 0, 0, 0}; static struct c7C1c5ss8 x2 = {-1, -1, 0, 0}; static struct c7C1c5ss8 x3 = {-1, 0, -1, 0}; static struct c7C1c5ss8 x4 = {-1, -1, -1, -1}; print_prologue("c7C1c5ss8", _Alignof(struct c7C1c5ss8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5s8i25c2 {
  int a:5;
  short b:8;
  int c:25;
  char d:2;
};
static struct i5s8i25c2 x1 = {-1, 0, 0, 0}; static struct i5s8i25c2 x2 = {-1, -1, 0, 0}; static struct i5s8i25c2 x3 = {-1, 0, -1, 0}; static struct i5s8i25c2 x4 = {-1, -1, -1, -1}; print_prologue("i5s8i25c2", _Alignof(struct i5s8i25c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4s3ci1 {
  short a:4;
  short b:3;
  char c;
  int d:1;
};
static struct s4s3ci1 x1 = {-1, 0, 0, 0}; static struct s4s3ci1 x2 = {-1, -1, 0, 0}; static struct s4s3ci1 x3 = {-1, 0, -1, 0}; static struct s4s3ci1 x4 = {-1, -1, -1, -1}; print_prologue("s4s3ci1", _Alignof(struct s4s3ci1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is2c1s6 {
  int a;
  short b:2;
  char c:1;
  short d:6;
};
static struct is2c1s6 x1 = {-1, 0, 0, 0}; static struct is2c1s6 x2 = {-1, -1, 0, 0}; static struct is2c1s6 x3 = {-1, 0, -1, 0}; static struct is2c1s6 x4 = {-1, -1, -1, -1}; print_prologue("is2c1s6", _Alignof(struct is2c1s6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1i9c3c8 {
  short a:1;
  int b:9;
  char c:3;
  char d:8;
};
static struct s1i9c3c8 x1 = {-1, 0, 0, 0}; static struct s1i9c3c8 x2 = {-1, -1, 0, 0}; static struct s1i9c3c8 x3 = {-1, 0, -1, 0}; static struct s1i9c3c8 x4 = {-1, -1, -1, -1}; print_prologue("s1i9c3c8", _Alignof(struct s1i9c3c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2c3i19s6 {
  int a:2;
  char b:3;
  int c:19;
  short d:6;
};
static struct i2c3i19s6 x1 = {-1, 0, 0, 0}; static struct i2c3i19s6 x2 = {-1, -1, 0, 0}; static struct i2c3i19s6 x3 = {-1, 0, -1, 0}; static struct i2c3i19s6 x4 = {-1, -1, -1, -1}; print_prologue("i2c3i19s6", _Alignof(struct i2c3i19s6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i4c2s1c {
  int a:4;
  char b:2;
  short c:1;
  char d;
};
static struct i4c2s1c x1 = {-1, 0, 0, 0}; static struct i4c2s1c x2 = {-1, -1, 0, 0}; static struct i4c2s1c x3 = {-1, 0, -1, 0}; static struct i4c2s1c x4 = {-1, -1, -1, -1}; print_prologue("i4c2s1c", _Alignof(struct i4c2s1c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1ci27s {
  short a:1;
  char b;
  int c:27;
  short d;
};
static struct s1ci27s x1 = {-1, 0, 0, 0}; static struct s1ci27s x2 = {-1, -1, 0, 0}; static struct s1ci27s x3 = {-1, 0, -1, 0}; static struct s1ci27s x4 = {-1, -1, -1, -1}; print_prologue("s1ci27s", _Alignof(struct s1ci27s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7c1s3c2 {
  char a:7;
  char b:1;
  short c:3;
  char d:2;
};
static struct c7c1s3c2 x1 = {-1, 0, 0, 0}; static struct c7c1s3c2 x2 = {-1, -1, 0, 0}; static struct c7c1s3c2 x3 = {-1, 0, -1, 0}; static struct c7c1s3c2 x4 = {-1, -1, -1, -1}; print_prologue("c7c1s3c2", _Alignof(struct c7c1s3c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4i3s2I2i5 {
  char a:4;
  int b:3;
  short c:2;
  int :2;
  int d:5;
};
static struct c4i3s2I2i5 x1 = {-1, 0, 0, 0}; static struct c4i3s2I2i5 x2 = {-1, -1, 0, 0}; static struct c4i3s2I2i5 x3 = {-1, 0, -1, 0}; static struct c4i3s2I2i5 x4 = {-1, -1, -1, -1}; print_prologue("c4i3s2I2i5", _Alignof(struct c4i3s2I2i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2c1c1c3 {
  int a:2;
  char b:1;
  char c:1;
  char d:3;
};
static struct i2c1c1c3 x1 = {-1, 0, 0, 0}; static struct i2c1c1c3 x2 = {-1, -1, 0, 0}; static struct i2c1c1c3 x3 = {-1, 0, -1, 0}; static struct i2c1c1c3 x4 = {-1, -1, -1, -1}; print_prologue("i2c1c1c3", _Alignof(struct i2c1c1c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sci5c5 {
  short a;
  char b;
  int c:5;
  char d:5;
};
static struct sci5c5 x1 = {-1, 0, 0, 0}; static struct sci5c5 x2 = {-1, -1, 0, 0}; static struct sci5c5 x3 = {-1, 0, -1, 0}; static struct sci5c5 x4 = {-1, -1, -1, -1}; print_prologue("sci5c5", _Alignof(struct sci5c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7c1c3i {
  char a:7;
  char b:1;
  char c:3;
  int d;
};
static struct c7c1c3i x1 = {-1, 0, 0, 0}; static struct c7c1c3i x2 = {-1, -1, 0, 0}; static struct c7c1c3i x3 = {-1, 0, -1, 0}; static struct c7c1c3i x4 = {-1, -1, -1, -1}; print_prologue("c7c1c3i", _Alignof(struct c7c1c3i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0i13i28i13s2 {
  int :0;
  int a:13;
  int b:28;
  int c:13;
  short d:2;
};
static struct I0i13i28i13s2 x1 = {-1, 0, 0, 0}; static struct I0i13i28i13s2 x2 = {-1, -1, 0, 0}; static struct I0i13i28i13s2 x3 = {-1, 0, -1, 0}; static struct I0i13i28i13s2 x4 = {-1, -1, -1, -1}; print_prologue("I0i13i28i13s2", _Alignof(struct I0i13i28i13s2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1bS0i5b1 {
  char a:1;
  _Bool b;
  short :0;
  int c:5;
  _Bool d:1;
};
static struct c1bS0i5b1 x1 = {-1, 0, 0, 0}; static struct c1bS0i5b1 x2 = {-1, -1, 0, 0}; static struct c1bS0i5b1 x3 = {-1, 0, -1, 0}; static struct c1bS0i5b1 x4 = {-1, -1, -1, -1}; print_prologue("c1bS0i5b1", _Alignof(struct c1bS0i5b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bS0i4cc {
  _Bool a;
  short :0;
  int b:4;
  char c;
  char d;
};
static struct bS0i4cc x1 = {-1, 0, 0, 0}; static struct bS0i4cc x2 = {-1, -1, 0, 0}; static struct bS0i4cc x3 = {-1, 0, -1, 0}; static struct bS0i4cc x4 = {-1, -1, -1, -1}; print_prologue("bS0i4cc", _Alignof(struct bS0i4cc), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i15si6c7 {
  int a:15;
  short b;
  int c:6;
  char d:7;
};
static struct i15si6c7 x1 = {-1, 0, 0, 0}; static struct i15si6c7 x2 = {-1, -1, 0, 0}; static struct i15si6c7 x3 = {-1, 0, -1, 0}; static struct i15si6c7 x4 = {-1, -1, -1, -1}; print_prologue("i15si6c7", _Alignof(struct i15si6c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i6i15c3i {
  int a:6;
  int b:15;
  char c:3;
  int d;
};
static struct i6i15c3i x1 = {-1, 0, 0, 0}; static struct i6i15c3i x2 = {-1, -1, 0, 0}; static struct i6i15c3i x3 = {-1, 0, -1, 0}; static struct i6i15c3i x4 = {-1, -1, -1, -1}; print_prologue("i6i15c3i", _Alignof(struct i6i15c3i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ic4i29i {
  int a;
  char b:4;
  int c:29;
  int d;
};
static struct ic4i29i x1 = {-1, 0, 0, 0}; static struct ic4i29i x2 = {-1, -1, 0, 0}; static struct ic4i29i x3 = {-1, 0, -1, 0}; static struct ic4i29i x4 = {-1, -1, -1, -1}; print_prologue("ic4i29i", _Alignof(struct ic4i29i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8s4b1b1 {
  char a:8;
  short b:4;
  _Bool c:1;
  _Bool d:1;
};
static struct c8s4b1b1 x1 = {-1, 0, 0, 0}; static struct c8s4b1b1 x2 = {-1, -1, 0, 0}; static struct c8s4b1b1 x3 = {-1, 0, -1, 0}; static struct c8s4b1b1 x4 = {-1, -1, -1, -1}; print_prologue("c8s4b1b1", _Alignof(struct c8s4b1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s3i11s10c {
  short a:3;
  int b:11;
  short c:10;
  char d;
};
static struct s3i11s10c x1 = {-1, 0, 0, 0}; static struct s3i11s10c x2 = {-1, -1, 0, 0}; static struct s3i11s10c x3 = {-1, 0, -1, 0}; static struct s3i11s10c x4 = {-1, -1, -1, -1}; print_prologue("s3i11s10c", _Alignof(struct s3i11s10c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3c2cs3 {
  char a:3;
  char b:2;
  char c;
  short d:3;
};
static struct c3c2cs3 x1 = {-1, 0, 0, 0}; static struct c3c2cs3 x2 = {-1, -1, 0, 0}; static struct c3c2cs3 x3 = {-1, 0, -1, 0}; static struct c3c2cs3 x4 = {-1, -1, -1, -1}; print_prologue("c3c2cs3", _Alignof(struct c3c2cs3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6i5i10s {
  char a:6;
  int b:5;
  int c:10;
  short d;
};
static struct c6i5i10s x1 = {-1, 0, 0, 0}; static struct c6i5i10s x2 = {-1, -1, 0, 0}; static struct c6i5i10s x3 = {-1, 0, -1, 0}; static struct c6i5i10s x4 = {-1, -1, -1, -1}; print_prologue("c6i5i10s", _Alignof(struct c6i5i10s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2b1i14s2 {
  short a:2;
  _Bool b:1;
  int c:14;
  short d:2;
};
static struct s2b1i14s2 x1 = {-1, 0, 0, 0}; static struct s2b1i14s2 x2 = {-1, -1, 0, 0}; static struct s2b1i14s2 x3 = {-1, 0, -1, 0}; static struct s2b1i14s2 x4 = {-1, -1, -1, -1}; print_prologue("s2b1i14s2", _Alignof(struct s2b1i14s2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bb1i2C3s {
  _Bool a;
  _Bool b:1;
  int c:2;
  char :3;
  short d;
};
static struct bb1i2C3s x1 = {-1, 0, 0, 0}; static struct bb1i2C3s x2 = {-1, -1, 0, 0}; static struct bb1i2C3s x3 = {-1, 0, -1, 0}; static struct bb1i2C3s x4 = {-1, -1, -1, -1}; print_prologue("bb1i2C3s", _Alignof(struct bb1i2C3s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i4c1i {
  _Bool a:1;
  int b:4;
  char c:1;
  int d;
};
static struct b1i4c1i x1 = {-1, 0, 0, 0}; static struct b1i4c1i x2 = {-1, -1, 0, 0}; static struct b1i4c1i x3 = {-1, 0, -1, 0}; static struct b1i4c1i x4 = {-1, -1, -1, -1}; print_prologue("b1i4c1i", _Alignof(struct b1i4c1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i11I20i4si20 {
  int a:11;
  int :20;
  int b:4;
  short c;
  int d:20;
};
static struct i11I20i4si20 x1 = {-1, 0, 0, 0}; static struct i11I20i4si20 x2 = {-1, -1, 0, 0}; static struct i11I20i4si20 x3 = {-1, 0, -1, 0}; static struct i11I20i4si20 x4 = {-1, -1, -1, -1}; print_prologue("i11I20i4si20", _Alignof(struct i11I20i4si20), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i20I2si1s15 {
  int a:20;
  int :2;
  short b;
  int c:1;
  short d:15;
};
static struct i20I2si1s15 x1 = {-1, 0, 0, 0}; static struct i20I2si1s15 x2 = {-1, -1, 0, 0}; static struct i20I2si1s15 x3 = {-1, 0, -1, 0}; static struct i20I2si1s15 x4 = {-1, -1, -1, -1}; print_prologue("i20I2si1s15", _Alignof(struct i20I2si1s15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i31b1ii2 {
  int a:31;
  _Bool b:1;
  int c;
  int d:2;
};
static struct i31b1ii2 x1 = {-1, 0, 0, 0}; static struct i31b1ii2 x2 = {-1, -1, 0, 0}; static struct i31b1ii2 x3 = {-1, 0, -1, 0}; static struct i31b1ii2 x4 = {-1, -1, -1, -1}; print_prologue("i31b1ii2", _Alignof(struct i31b1ii2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7I0cs16i {
  char a:7;
  int :0;
  char b;
  short c:16;
  int d;
};
static struct c7I0cs16i x1 = {-1, 0, 0, 0}; static struct c7I0cs16i x2 = {-1, -1, 0, 0}; static struct c7I0cs16i x3 = {-1, 0, -1, 0}; static struct c7I0cs16i x4 = {-1, -1, -1, -1}; print_prologue("c7I0cs16i", _Alignof(struct c7I0cs16i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1S1ic3i1 {
  char a:1;
  short :1;
  int b;
  char c:3;
  int d:1;
};
static struct c1S1ic3i1 x1 = {-1, 0, 0, 0}; static struct c1S1ic3i1 x2 = {-1, -1, 0, 0}; static struct c1S1ic3i1 x3 = {-1, 0, -1, 0}; static struct c1S1ic3i1 x4 = {-1, -1, -1, -1}; print_prologue("c1S1ic3i1", _Alignof(struct c1S1ic3i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3s1i7i2 {
  char a:3;
  short b:1;
  int c:7;
  int d:2;
};
static struct c3s1i7i2 x1 = {-1, 0, 0, 0}; static struct c3s1i7i2 x2 = {-1, -1, 0, 0}; static struct c3s1i7i2 x3 = {-1, 0, -1, 0}; static struct c3s1i7i2 x4 = {-1, -1, -1, -1}; print_prologue("c3s1i7i2", _Alignof(struct c3s1i7i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii7I2i4b1 {
  int a;
  int b:7;
  int :2;
  int c:4;
  _Bool d:1;
};
static struct ii7I2i4b1 x1 = {-1, 0, 0, 0}; static struct ii7I2i4b1 x2 = {-1, -1, 0, 0}; static struct ii7I2i4b1 x3 = {-1, 0, -1, 0}; static struct ii7I2i4b1 x4 = {-1, -1, -1, -1}; print_prologue("ii7I2i4b1", _Alignof(struct ii7I2i4b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5isc6 {
  char a:5;
  int b;
  short c;
  char d:6;
};
static struct c5isc6 x1 = {-1, 0, 0, 0}; static struct c5isc6 x2 = {-1, -1, 0, 0}; static struct c5isc6 x3 = {-1, 0, -1, 0}; static struct c5isc6 x4 = {-1, -1, -1, -1}; print_prologue("c5isc6", _Alignof(struct c5isc6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7B0c7i9i7 {
  char a:7;
  _Bool :0;
  char b:7;
  int c:9;
  int d:7;
};
static struct c7B0c7i9i7 x1 = {-1, 0, 0, 0}; static struct c7B0c7i9i7 x2 = {-1, -1, 0, 0}; static struct c7B0c7i9i7 x3 = {-1, 0, -1, 0}; static struct c7B0c7i9i7 x4 = {-1, -1, -1, -1}; print_prologue("c7B0c7i9i7", _Alignof(struct c7B0c7i9i7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cs1i2c5 {
  char a;
  short b:1;
  int c:2;
  char d:5;
};
static struct cs1i2c5 x1 = {-1, 0, 0, 0}; static struct cs1i2c5 x2 = {-1, -1, 0, 0}; static struct cs1i2c5 x3 = {-1, 0, -1, 0}; static struct cs1i2c5 x4 = {-1, -1, -1, -1}; print_prologue("cs1i2c5", _Alignof(struct cs1i2c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5c8s2s6 {
  char a:5;
  char b:8;
  short c:2;
  short d:6;
};
static struct c5c8s2s6 x1 = {-1, 0, 0, 0}; static struct c5c8s2s6 x2 = {-1, -1, 0, 0}; static struct c5c8s2s6 x3 = {-1, 0, -1, 0}; static struct c5c8s2s6 x4 = {-1, -1, -1, -1}; print_prologue("c5c8s2s6", _Alignof(struct c5c8s2s6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ibi2i19 {
  int a;
  _Bool b;
  int c:2;
  int d:19;
};
static struct ibi2i19 x1 = {-1, 0, 0, 0}; static struct ibi2i19 x2 = {-1, -1, 0, 0}; static struct ibi2i19 x3 = {-1, 0, -1, 0}; static struct ibi2i19 x4 = {-1, -1, -1, -1}; print_prologue("ibi2i19", _Alignof(struct ibi2i19), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I10si28S8b1s {
  int :10;
  short a;
  int b:28;
  short :8;
  _Bool c:1;
  short d;
};
static struct I10si28S8b1s x1 = {-1, 0, 0, 0}; static struct I10si28S8b1s x2 = {-1, -1, 0, 0}; static struct I10si28S8b1s x3 = {-1, 0, -1, 0}; static struct I10si28S8b1s x4 = {-1, -1, -1, -1}; print_prologue("I10si28S8b1s", _Alignof(struct I10si28S8b1s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sb1i1S5s4 {
  short a;
  _Bool b:1;
  int c:1;
  short :5;
  short d:4;
};
static struct sb1i1S5s4 x1 = {-1, 0, 0, 0}; static struct sb1i1S5s4 x2 = {-1, -1, 0, 0}; static struct sb1i1S5s4 x3 = {-1, 0, -1, 0}; static struct sb1i1S5s4 x4 = {-1, -1, -1, -1}; print_prologue("sb1i1S5s4", _Alignof(struct sb1i1S5s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i13si25c {
  int a:13;
  short b;
  int c:25;
  char d;
};
static struct i13si25c x1 = {-1, 0, 0, 0}; static struct i13si25c x2 = {-1, -1, 0, 0}; static struct i13si25c x3 = {-1, 0, -1, 0}; static struct i13si25c x4 = {-1, -1, -1, -1}; print_prologue("i13si25c", _Alignof(struct i13si25c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s11s4si4 {
  short a:11;
  short b:4;
  short c;
  int d:4;
};
static struct s11s4si4 x1 = {-1, 0, 0, 0}; static struct s11s4si4 x2 = {-1, -1, 0, 0}; static struct s11s4si4 x3 = {-1, 0, -1, 0}; static struct s11s4si4 x4 = {-1, -1, -1, -1}; print_prologue("s11s4si4", _Alignof(struct s11s4si4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct B1s2s4i7S4s4 {
  _Bool :1;
  short a:2;
  short b:4;
  int c:7;
  short :4;
  short d:4;
};
static struct B1s2s4i7S4s4 x1 = {-1, 0, 0, 0}; static struct B1s2s4i7S4s4 x2 = {-1, -1, 0, 0}; static struct B1s2s4i7S4s4 x3 = {-1, 0, -1, 0}; static struct B1s2s4i7S4s4 x4 = {-1, -1, -1, -1}; print_prologue("B1s2s4i7S4s4", _Alignof(struct B1s2s4i7S4s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5is3i {
  char a:5;
  int b;
  short c:3;
  int d;
};
static struct c5is3i x1 = {-1, 0, 0, 0}; static struct c5is3i x2 = {-1, -1, 0, 0}; static struct c5is3i x3 = {-1, 0, -1, 0}; static struct c5is3i x4 = {-1, -1, -1, -1}; print_prologue("c5is3i", _Alignof(struct c5is3i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i8i23s9i31 {
  int a:8;
  int b:23;
  short c:9;
  int d:31;
};
static struct i8i23s9i31 x1 = {-1, 0, 0, 0}; static struct i8i23s9i31 x2 = {-1, -1, 0, 0}; static struct i8i23s9i31 x3 = {-1, 0, -1, 0}; static struct i8i23s9i31 x4 = {-1, -1, -1, -1}; print_prologue("i8i23s9i31", _Alignof(struct i8i23s9i31), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I13i5b1i15i1 {
  int :13;
  int a:5;
  _Bool b:1;
  int c:15;
  int d:1;
};
static struct I13i5b1i15i1 x1 = {-1, 0, 0, 0}; static struct I13i5b1i15i1 x2 = {-1, -1, 0, 0}; static struct I13i5b1i15i1 x3 = {-1, 0, -1, 0}; static struct I13i5b1i15i1 x4 = {-1, -1, -1, -1}; print_prologue("I13i5b1i15i1", _Alignof(struct I13i5b1i15i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i8i1cs16 {
  int a:8;
  int b:1;
  char c;
  short d:16;
};
static struct i8i1cs16 x1 = {-1, 0, 0, 0}; static struct i8i1cs16 x2 = {-1, -1, 0, 0}; static struct i8i1cs16 x3 = {-1, 0, -1, 0}; static struct i8i1cs16 x4 = {-1, -1, -1, -1}; print_prologue("i8i1cs16", _Alignof(struct i8i1cs16), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s12I26ibi4 {
  short a:12;
  int :26;
  int b;
  _Bool c;
  int d:4;
};
static struct s12I26ibi4 x1 = {-1, 0, 0, 0}; static struct s12I26ibi4 x2 = {-1, -1, 0, 0}; static struct s12I26ibi4 x3 = {-1, 0, -1, 0}; static struct s12I26ibi4 x4 = {-1, -1, -1, -1}; print_prologue("s12I26ibi4", _Alignof(struct s12I26ibi4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct si2I0ic5 {
  short a;
  int b:2;
  int :0;
  int c;
  char d:5;
};
static struct si2I0ic5 x1 = {-1, 0, 0, 0}; static struct si2I0ic5 x2 = {-1, -1, 0, 0}; static struct si2I0ic5 x3 = {-1, 0, -1, 0}; static struct si2I0ic5 x4 = {-1, -1, -1, -1}; print_prologue("si2I0ic5", _Alignof(struct si2I0ic5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i14bi20i5 {
  int a:14;
  _Bool b;
  int c:20;
  int d:5;
};
static struct i14bi20i5 x1 = {-1, 0, 0, 0}; static struct i14bi20i5 x2 = {-1, -1, 0, 0}; static struct i14bi20i5 x3 = {-1, 0, -1, 0}; static struct i14bi20i5 x4 = {-1, -1, -1, -1}; print_prologue("i14bi20i5", _Alignof(struct i14bi20i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0cc1i2s15 {
  int :0;
  char a;
  char b:1;
  int c:2;
  short d:15;
};
static struct I0cc1i2s15 x1 = {-1, 0, 0, 0}; static struct I0cc1i2s15 x2 = {-1, -1, 0, 0}; static struct I0cc1i2s15 x3 = {-1, 0, -1, 0}; static struct I0cc1i2s15 x4 = {-1, -1, -1, -1}; print_prologue("I0cc1i2s15", _Alignof(struct I0cc1i2s15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s11S0sc1i9 {
  short a:11;
  short :0;
  short b;
  char c:1;
  int d:9;
};
static struct s11S0sc1i9 x1 = {-1, 0, 0, 0}; static struct s11S0sc1i9 x2 = {-1, -1, 0, 0}; static struct s11S0sc1i9 x3 = {-1, 0, -1, 0}; static struct s11S0sc1i9 x4 = {-1, -1, -1, -1}; print_prologue("s11S0sc1i9", _Alignof(struct s11S0sc1i9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2c1s2b1 {
  short a:2;
  char b:1;
  short c:2;
  _Bool d:1;
};
static struct s2c1s2b1 x1 = {-1, 0, 0, 0}; static struct s2c1s2b1 x2 = {-1, -1, 0, 0}; static struct s2c1s2b1 x3 = {-1, 0, -1, 0}; static struct s2c1s2b1 x4 = {-1, -1, -1, -1}; print_prologue("s2c1s2b1", _Alignof(struct s2c1s2b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1b1c8i6 {
  char a:1;
  _Bool b:1;
  char c:8;
  int d:6;
};
static struct c1b1c8i6 x1 = {-1, 0, 0, 0}; static struct c1b1c8i6 x2 = {-1, -1, 0, 0}; static struct c1b1c8i6 x3 = {-1, 0, -1, 0}; static struct c1b1c8i6 x4 = {-1, -1, -1, -1}; print_prologue("c1b1c8i6", _Alignof(struct c1b1c8i6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i17C4ii13c1 {
  int a:17;
  char :4;
  int b;
  int c:13;
  char d:1;
};
static struct i17C4ii13c1 x1 = {-1, 0, 0, 0}; static struct i17C4ii13c1 x2 = {-1, -1, 0, 0}; static struct i17C4ii13c1 x3 = {-1, 0, -1, 0}; static struct i17C4ii13c1 x4 = {-1, -1, -1, -1}; print_prologue("i17C4ii13c1", _Alignof(struct i17C4ii13c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii1b1i10 {
  int a;
  int b:1;
  _Bool c:1;
  int d:10;
};
static struct ii1b1i10 x1 = {-1, 0, 0, 0}; static struct ii1b1i10 x2 = {-1, -1, 0, 0}; static struct ii1b1i10 x3 = {-1, 0, -1, 0}; static struct ii1b1i10 x4 = {-1, -1, -1, -1}; print_prologue("ii1b1i10", _Alignof(struct ii1b1i10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i18bs3i2 {
  int a:18;
  _Bool b;
  short c:3;
  int d:2;
};
static struct i18bs3i2 x1 = {-1, 0, 0, 0}; static struct i18bs3i2 x2 = {-1, -1, 0, 0}; static struct i18bs3i2 x3 = {-1, 0, -1, 0}; static struct i18bs3i2 x4 = {-1, -1, -1, -1}; print_prologue("i18bs3i2", _Alignof(struct i18bs3i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s6b1ii1 {
  short a:6;
  _Bool b:1;
  int c;
  int d:1;
};
static struct s6b1ii1 x1 = {-1, 0, 0, 0}; static struct s6b1ii1 x2 = {-1, -1, 0, 0}; static struct s6b1ii1 x3 = {-1, 0, -1, 0}; static struct s6b1ii1 x4 = {-1, -1, -1, -1}; print_prologue("s6b1ii1", _Alignof(struct s6b1ii1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s15b1S7c6I0i25 {
  short a:15;
  _Bool b:1;
  short :7;
  char c:6;
  int :0;
  int d:25;
};
static struct s15b1S7c6I0i25 x1 = {-1, 0, 0, 0}; static struct s15b1S7c6I0i25 x2 = {-1, -1, 0, 0}; static struct s15b1S7c6I0i25 x3 = {-1, 0, -1, 0}; static struct s15b1S7c6I0i25 x4 = {-1, -1, -1, -1}; print_prologue("s15b1S7c6I0i25", _Alignof(struct s15b1S7c6I0i25), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i20C8I1I5i15b1c1 {
  int a:20;
  char :8;
  int :1;
  int :5;
  int b:15;
  _Bool c:1;
  char d:1;
};
static struct i20C8I1I5i15b1c1 x1 = {-1, 0, 0, 0}; static struct i20C8I1I5i15b1c1 x2 = {-1, -1, 0, 0}; static struct i20C8I1I5i15b1c1 x3 = {-1, 0, -1, 0}; static struct i20C8I1I5i15b1c1 x4 = {-1, -1, -1, -1}; print_prologue("i20C8I1I5i15b1c1", _Alignof(struct i20C8I1I5i15b1c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i12c1I0s3s12 {
  int a:12;
  char b:1;
  int :0;
  short c:3;
  short d:12;
};
static struct i12c1I0s3s12 x1 = {-1, 0, 0, 0}; static struct i12c1I0s3s12 x2 = {-1, -1, 0, 0}; static struct i12c1I0s3s12 x3 = {-1, 0, -1, 0}; static struct i12c1I0s3s12 x4 = {-1, -1, -1, -1}; print_prologue("i12c1I0s3s12", _Alignof(struct i12c1I0s3s12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2b1i7C1i {
  char a:2;
  _Bool b:1;
  int c:7;
  char :1;
  int d;
};
static struct c2b1i7C1i x1 = {-1, 0, 0, 0}; static struct c2b1i7C1i x2 = {-1, -1, 0, 0}; static struct c2b1i7C1i x3 = {-1, 0, -1, 0}; static struct c2b1i7C1i x4 = {-1, -1, -1, -1}; print_prologue("c2b1i7C1i", _Alignof(struct c2b1i7C1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I6b1I25s12i5c1 {
  int :6;
  _Bool a:1;
  int :25;
  short b:12;
  int c:5;
  char d:1;
};
static struct I6b1I25s12i5c1 x1 = {-1, 0, 0, 0}; static struct I6b1I25s12i5c1 x2 = {-1, -1, 0, 0}; static struct I6b1I25s12i5c1 x3 = {-1, 0, -1, 0}; static struct I6b1I25s12i5c1 x4 = {-1, -1, -1, -1}; print_prologue("I6b1I25s12i5c1", _Alignof(struct I6b1I25s12i5c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4c3bi12 {
  short a:4;
  char b:3;
  _Bool c;
  int d:12;
};
static struct s4c3bi12 x1 = {-1, 0, 0, 0}; static struct s4c3bi12 x2 = {-1, -1, 0, 0}; static struct s4c3bi12 x3 = {-1, 0, -1, 0}; static struct s4c3bi12 x4 = {-1, -1, -1, -1}; print_prologue("s4c3bi12", _Alignof(struct s4c3bi12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i22b1si7 {
  int a:22;
  _Bool b:1;
  short c;
  int d:7;
};
static struct i22b1si7 x1 = {-1, 0, 0, 0}; static struct i22b1si7 x2 = {-1, -1, 0, 0}; static struct i22b1si7 x3 = {-1, 0, -1, 0}; static struct i22b1si7 x4 = {-1, -1, -1, -1}; print_prologue("i22b1si7", _Alignof(struct i22b1si7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i14i12i24i2 {
  int a:14;
  int b:12;
  int c:24;
  int d:2;
};
static struct i14i12i24i2 x1 = {-1, 0, 0, 0}; static struct i14i12i24i2 x2 = {-1, -1, 0, 0}; static struct i14i12i24i2 x3 = {-1, 0, -1, 0}; static struct i14i12i24i2 x4 = {-1, -1, -1, -1}; print_prologue("i14i12i24i2", _Alignof(struct i14i12i24i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i3s1ci {
  int a:3;
  short b:1;
  char c;
  int d;
};
static struct i3s1ci x1 = {-1, 0, 0, 0}; static struct i3s1ci x2 = {-1, -1, 0, 0}; static struct i3s1ci x3 = {-1, 0, -1, 0}; static struct i3s1ci x4 = {-1, -1, -1, -1}; print_prologue("i3s1ci", _Alignof(struct i3s1ci), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1b1c3 {
  int a;
  _Bool b:1;
  _Bool c:1;
  char d:3;
};
static struct ib1b1c3 x1 = {-1, 0, 0, 0}; static struct ib1b1c3 x2 = {-1, -1, 0, 0}; static struct ib1b1c3 x3 = {-1, 0, -1, 0}; static struct ib1b1c3 x4 = {-1, -1, -1, -1}; print_prologue("ib1b1c3", _Alignof(struct ib1b1c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2S6s4c7i12 {
  char a:2;
  short :6;
  short b:4;
  char c:7;
  int d:12;
};
static struct c2S6s4c7i12 x1 = {-1, 0, 0, 0}; static struct c2S6s4c7i12 x2 = {-1, -1, 0, 0}; static struct c2S6s4c7i12 x3 = {-1, 0, -1, 0}; static struct c2S6s4c7i12 x4 = {-1, -1, -1, -1}; print_prologue("c2S6s4c7i12", _Alignof(struct c2S6s4c7i12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S4i2b1i28s15 {
  short :4;
  int a:2;
  _Bool b:1;
  int c:28;
  short d:15;
};
static struct S4i2b1i28s15 x1 = {-1, 0, 0, 0}; static struct S4i2b1i28s15 x2 = {-1, -1, 0, 0}; static struct S4i2b1i28s15 x3 = {-1, 0, -1, 0}; static struct S4i2b1i28s15 x4 = {-1, -1, -1, -1}; print_prologue("S4i2b1i28s15", _Alignof(struct S4i2b1i28s15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1s7ii5 {
  _Bool a:1;
  short b:7;
  int c;
  int d:5;
};
static struct b1s7ii5 x1 = {-1, 0, 0, 0}; static struct b1s7ii5 x2 = {-1, -1, 0, 0}; static struct b1s7ii5 x3 = {-1, 0, -1, 0}; static struct b1s7ii5 x4 = {-1, -1, -1, -1}; print_prologue("b1s7ii5", _Alignof(struct b1s7ii5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ciii29 {
  char a;
  int b;
  int c;
  int d:29;
};
static struct ciii29 x1 = {-1, 0, 0, 0}; static struct ciii29 x2 = {-1, -1, 0, 0}; static struct ciii29 x3 = {-1, 0, -1, 0}; static struct ciii29 x4 = {-1, -1, -1, -1}; print_prologue("ciii29", _Alignof(struct ciii29), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c7sc1i8 {
  char a:7;
  short b;
  char c:1;
  int d:8;
};
static struct c7sc1i8 x1 = {-1, 0, 0, 0}; static struct c7sc1i8 x2 = {-1, -1, 0, 0}; static struct c7sc1i8 x3 = {-1, 0, -1, 0}; static struct c7sc1i8 x4 = {-1, -1, -1, -1}; print_prologue("c7sc1i8", _Alignof(struct c7sc1i8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii24b1i4 {
  int a;
  int b:24;
  _Bool c:1;
  int d:4;
};
static struct ii24b1i4 x1 = {-1, 0, 0, 0}; static struct ii24b1i4 x2 = {-1, -1, 0, 0}; static struct ii24b1i4 x3 = {-1, 0, -1, 0}; static struct ii24b1i4 x4 = {-1, -1, -1, -1}; print_prologue("ii24b1i4", _Alignof(struct ii24b1i4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6i31i4c2 {
  char a:6;
  int b:31;
  int c:4;
  char d:2;
};
static struct c6i31i4c2 x1 = {-1, 0, 0, 0}; static struct c6i31i4c2 x2 = {-1, -1, 0, 0}; static struct c6i31i4c2 x3 = {-1, 0, -1, 0}; static struct c6i31i4c2 x4 = {-1, -1, -1, -1}; print_prologue("c6i31i4c2", _Alignof(struct c6i31i4c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cbs5c4 {
  char a;
  _Bool b;
  short c:5;
  char d:4;
};
static struct cbs5c4 x1 = {-1, 0, 0, 0}; static struct cbs5c4 x2 = {-1, -1, 0, 0}; static struct cbs5c4 x3 = {-1, 0, -1, 0}; static struct cbs5c4 x4 = {-1, -1, -1, -1}; print_prologue("cbs5c4", _Alignof(struct cbs5c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1ci13 {
  int a;
  _Bool b:1;
  char c;
  int d:13;
};
static struct ib1ci13 x1 = {-1, 0, 0, 0}; static struct ib1ci13 x2 = {-1, -1, 0, 0}; static struct ib1ci13 x3 = {-1, 0, -1, 0}; static struct ib1ci13 x4 = {-1, -1, -1, -1}; print_prologue("ib1ci13", _Alignof(struct ib1ci13), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3I1i23I4C0i18i32 {
  char a:3;
  int :1;
  int b:23;
  int :4;
  char :0;
  int c:18;
  int d:32;
};
static struct c3I1i23I4C0i18i32 x1 = {-1, 0, 0, 0}; static struct c3I1i23I4C0i18i32 x2 = {-1, -1, 0, 0}; static struct c3I1i23I4C0i18i32 x3 = {-1, 0, -1, 0}; static struct c3I1i23I4C0i18i32 x4 = {-1, -1, -1, -1}; print_prologue("c3I1i23I4C0i18i32", _Alignof(struct c3I1i23I4C0i18i32), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cb1ib1 {
  char a;
  _Bool b:1;
  int c;
  _Bool d:1;
};
static struct cb1ib1 x1 = {-1, 0, 0, 0}; static struct cb1ib1 x2 = {-1, -1, 0, 0}; static struct cb1ib1 x3 = {-1, 0, -1, 0}; static struct cb1ib1 x4 = {-1, -1, -1, -1}; print_prologue("cb1ib1", _Alignof(struct cb1ib1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1S0bi6b1 {
  _Bool a:1;
  short :0;
  _Bool b;
  int c:6;
  _Bool d:1;
};
static struct b1S0bi6b1 x1 = {-1, 0, 0, 0}; static struct b1S0bi6b1 x2 = {-1, -1, 0, 0}; static struct b1S0bi6b1 x3 = {-1, 0, -1, 0}; static struct b1S0bi6b1 x4 = {-1, -1, -1, -1}; print_prologue("b1S0bi6b1", _Alignof(struct b1S0bi6b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2B1i26i10I10i20 {
  char a:2;
  _Bool :1;
  int b:26;
  int c:10;
  int :10;
  int d:20;
};
static struct c2B1i26i10I10i20 x1 = {-1, 0, 0, 0}; static struct c2B1i26i10I10i20 x2 = {-1, -1, 0, 0}; static struct c2B1i26i10I10i20 x3 = {-1, 0, -1, 0}; static struct c2B1i26i10I10i20 x4 = {-1, -1, -1, -1}; print_prologue("c2B1i26i10I10i20", _Alignof(struct c2B1i26i10I10i20), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i15i3S0i4I11I0c {
  int a:15;
  int b:3;
  short :0;
  int c:4;
  int :11;
  int :0;
  char d;
};
static struct i15i3S0i4I11I0c x1 = {-1, 0, 0, 0}; static struct i15i3S0i4I11I0c x2 = {-1, -1, 0, 0}; static struct i15i3S0i4I11I0c x3 = {-1, 0, -1, 0}; static struct i15i3S0i4I11I0c x4 = {-1, -1, -1, -1}; print_prologue("i15i3S0i4I11I0c", _Alignof(struct i15i3S0i4I11I0c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1ii22i {
  int a:1;
  int b;
  int c:22;
  int d;
};
static struct i1ii22i x1 = {-1, 0, 0, 0}; static struct i1ii22i x2 = {-1, -1, 0, 0}; static struct i1ii22i x3 = {-1, 0, -1, 0}; static struct i1ii22i x4 = {-1, -1, -1, -1}; print_prologue("i1ii22i", _Alignof(struct i1ii22i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i11ii {
  _Bool a:1;
  int b:11;
  int c;
  int d;
};
static struct b1i11ii x1 = {-1, 0, 0, 0}; static struct b1i11ii x2 = {-1, -1, 0, 0}; static struct b1i11ii x3 = {-1, 0, -1, 0}; static struct b1i11ii x4 = {-1, -1, -1, -1}; print_prologue("b1i11ii", _Alignof(struct b1i11ii), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i14i2c {
  _Bool a:1;
  int b:14;
  int c:2;
  char d;
};
static struct b1i14i2c x1 = {-1, 0, 0, 0}; static struct b1i14i2c x2 = {-1, -1, 0, 0}; static struct b1i14i2c x3 = {-1, 0, -1, 0}; static struct b1i14i2c x4 = {-1, -1, -1, -1}; print_prologue("b1i14i2c", _Alignof(struct b1i14i2c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct si1i1B0s {
  short a;
  int b:1;
  int c:1;
  _Bool :0;
  short d;
};
static struct si1i1B0s x1 = {-1, 0, 0, 0}; static struct si1i1B0s x2 = {-1, -1, 0, 0}; static struct si1i1B0s x3 = {-1, 0, -1, 0}; static struct si1i1B0s x4 = {-1, -1, -1, -1}; print_prologue("si1i1B0s", _Alignof(struct si1i1B0s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i6I0i1i16c6 {
  int a:6;
  int :0;
  int b:1;
  int c:16;
  char d:6;
};
static struct i6I0i1i16c6 x1 = {-1, 0, 0, 0}; static struct i6I0i1i16c6 x2 = {-1, -1, 0, 0}; static struct i6I0i1i16c6 x3 = {-1, 0, -1, 0}; static struct i6I0i1i16c6 x4 = {-1, -1, -1, -1}; print_prologue("i6I0i1i16c6", _Alignof(struct i6I0i1i16c6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i6i1i14c1 {
  int a:6;
  int b:1;
  int c:14;
  char d:1;
};
static struct i6i1i14c1 x1 = {-1, 0, 0, 0}; static struct i6i1i14c1 x2 = {-1, -1, 0, 0}; static struct i6i1i14c1 x3 = {-1, 0, -1, 0}; static struct i6i1i14c1 x4 = {-1, -1, -1, -1}; print_prologue("i6i1i14c1", _Alignof(struct i6i1i14c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i6s2s3c2 {
  int a:6;
  short b:2;
  short c:3;
  char d:2;
};
static struct i6s2s3c2 x1 = {-1, 0, 0, 0}; static struct i6s2s3c2 x2 = {-1, -1, 0, 0}; static struct i6s2s3c2 x3 = {-1, 0, -1, 0}; static struct i6s2s3c2 x4 = {-1, -1, -1, -1}; print_prologue("i6s2s3c2", _Alignof(struct i6s2s3c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4i1i8c {
  short a:4;
  int b:1;
  int c:8;
  char d;
};
static struct s4i1i8c x1 = {-1, 0, 0, 0}; static struct s4i1i8c x2 = {-1, -1, 0, 0}; static struct s4i1i8c x3 = {-1, 0, -1, 0}; static struct s4i1i8c x4 = {-1, -1, -1, -1}; print_prologue("s4i1i8c", _Alignof(struct s4i1i8c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sb1c2i2 {
  short a;
  _Bool b:1;
  char c:2;
  int d:2;
};
static struct sb1c2i2 x1 = {-1, 0, 0, 0}; static struct sb1c2i2 x2 = {-1, -1, 0, 0}; static struct sb1c2i2 x3 = {-1, 0, -1, 0}; static struct sb1c2i2 x4 = {-1, -1, -1, -1}; print_prologue("sb1c2i2", _Alignof(struct sb1c2i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i1i10i23 {
  _Bool a:1;
  int b:1;
  int c:10;
  int d:23;
};
static struct b1i1i10i23 x1 = {-1, 0, 0, 0}; static struct b1i1i10i23 x2 = {-1, -1, 0, 0}; static struct b1i1i10i23 x3 = {-1, 0, -1, 0}; static struct b1i1i10i23 x4 = {-1, -1, -1, -1}; print_prologue("b1i1i10i23", _Alignof(struct b1i1i10i23), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1i3s4i {
  int a:1;
  int b:3;
  short c:4;
  int d;
};
static struct i1i3s4i x1 = {-1, 0, 0, 0}; static struct i1i3s4i x2 = {-1, -1, 0, 0}; static struct i1i3s4i x3 = {-1, 0, -1, 0}; static struct i1i3s4i x4 = {-1, -1, -1, -1}; print_prologue("i1i3s4i", _Alignof(struct i1i3s4i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3i1ic5 {
  char a:3;
  int b:1;
  int c;
  char d:5;
};
static struct c3i1ic5 x1 = {-1, 0, 0, 0}; static struct c3i1ic5 x2 = {-1, -1, 0, 0}; static struct c3i1ic5 x3 = {-1, 0, -1, 0}; static struct c3i1ic5 x4 = {-1, -1, -1, -1}; print_prologue("c3i1ic5", _Alignof(struct c3i1ic5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5bi10C1i {
  int a:5;
  _Bool b;
  int c:10;
  char :1;
  int d;
};
static struct i5bi10C1i x1 = {-1, 0, 0, 0}; static struct i5bi10C1i x2 = {-1, -1, 0, 0}; static struct i5bi10C1i x3 = {-1, 0, -1, 0}; static struct i5bi10C1i x4 = {-1, -1, -1, -1}; print_prologue("i5bi10C1i", _Alignof(struct i5bi10C1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5b1i8i11 {
  int a:5;
  _Bool b:1;
  int c:8;
  int d:11;
};
static struct i5b1i8i11 x1 = {-1, 0, 0, 0}; static struct i5b1i8i11 x2 = {-1, -1, 0, 0}; static struct i5b1i8i11 x3 = {-1, 0, -1, 0}; static struct i5b1i8i11 x4 = {-1, -1, -1, -1}; print_prologue("i5b1i8i11", _Alignof(struct i5b1i8i11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8i1s14I22s13 {
  char a:8;
  int b:1;
  short c:14;
  int :22;
  short d:13;
};
static struct c8i1s14I22s13 x1 = {-1, 0, 0, 0}; static struct c8i1s14I22s13 x2 = {-1, -1, 0, 0}; static struct c8i1s14I22s13 x3 = {-1, 0, -1, 0}; static struct c8i1s14I22s13 x4 = {-1, -1, -1, -1}; print_prologue("c8i1s14I22s13", _Alignof(struct c8i1s14I22s13), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7i6c1c {
  int a:7;
  int b:6;
  char c:1;
  char d;
};
static struct i7i6c1c x1 = {-1, 0, 0, 0}; static struct i7i6c1c x2 = {-1, -1, 0, 0}; static struct i7i6c1c x3 = {-1, 0, -1, 0}; static struct i7i6c1c x4 = {-1, -1, -1, -1}; print_prologue("i7i6c1c", _Alignof(struct i7i6c1c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s3i1c6s6 {
  short a:3;
  int b:1;
  char c:6;
  short d:6;
};
static struct s3i1c6s6 x1 = {-1, 0, 0, 0}; static struct s3i1c6s6 x2 = {-1, -1, 0, 0}; static struct s3i1c6s6 x3 = {-1, 0, -1, 0}; static struct s3i1c6s6 x4 = {-1, -1, -1, -1}; print_prologue("s3i1c6s6", _Alignof(struct s3i1c6s6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cc1c4c1 {
  char a;
  char b:1;
  char c:4;
  char d:1;
};
static struct cc1c4c1 x1 = {-1, 0, 0, 0}; static struct cc1c4c1 x2 = {-1, -1, 0, 0}; static struct cc1c4c1 x3 = {-1, 0, -1, 0}; static struct cc1c4c1 x4 = {-1, -1, -1, -1}; print_prologue("cc1c4c1", _Alignof(struct cc1c4c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1i11c {
  int a;
  _Bool b:1;
  int c:11;
  char d;
};
static struct ib1i11c x1 = {-1, 0, 0, 0}; static struct ib1i11c x2 = {-1, -1, 0, 0}; static struct ib1i11c x3 = {-1, 0, -1, 0}; static struct ib1i11c x4 = {-1, -1, -1, -1}; print_prologue("ib1i11c", _Alignof(struct ib1i11c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2i5b1i8 {
  int a:2;
  int b:5;
  _Bool c:1;
  int d:8;
};
static struct i2i5b1i8 x1 = {-1, 0, 0, 0}; static struct i2i5b1i8 x2 = {-1, -1, 0, 0}; static struct i2i5b1i8 x3 = {-1, 0, -1, 0}; static struct i2i5b1i8 x4 = {-1, -1, -1, -1}; print_prologue("i2i5b1i8", _Alignof(struct i2i5b1i8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is3s9c7 {
  int a;
  short b:3;
  short c:9;
  char d:7;
};
static struct is3s9c7 x1 = {-1, 0, 0, 0}; static struct is3s9c7 x2 = {-1, -1, 0, 0}; static struct is3s9c7 x3 = {-1, 0, -1, 0}; static struct is3s9c7 x4 = {-1, -1, -1, -1}; print_prologue("is3s9c7", _Alignof(struct is3s9c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i23i1i3b1 {
  int a:23;
  int b:1;
  int c:3;
  _Bool d:1;
};
static struct i23i1i3b1 x1 = {-1, 0, 0, 0}; static struct i23i1i3b1 x2 = {-1, -1, 0, 0}; static struct i23i1i3b1 x3 = {-1, 0, -1, 0}; static struct i23i1i3b1 x4 = {-1, -1, -1, -1}; print_prologue("i23i1i3b1", _Alignof(struct i23i1i3b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S1i23b1i16c2 {
  short :1;
  int a:23;
  _Bool b:1;
  int c:16;
  char d:2;
};
static struct S1i23b1i16c2 x1 = {-1, 0, 0, 0}; static struct S1i23b1i16c2 x2 = {-1, -1, 0, 0}; static struct S1i23b1i16c2 x3 = {-1, 0, -1, 0}; static struct S1i23b1i16c2 x4 = {-1, -1, -1, -1}; print_prologue("S1i23b1i16c2", _Alignof(struct S1i23b1i16c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4sS12s8c5 {
  char a:4;
  short b;
  short :12;
  short c:8;
  char d:5;
};
static struct c4sS12s8c5 x1 = {-1, 0, 0, 0}; static struct c4sS12s8c5 x2 = {-1, -1, 0, 0}; static struct c4sS12s8c5 x3 = {-1, 0, -1, 0}; static struct c4sS12s8c5 x4 = {-1, -1, -1, -1}; print_prologue("c4sS12s8c5", _Alignof(struct c4sS12s8c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1i7ci14 {
  int a:1;
  int b:7;
  char c;
  int d:14;
};
static struct i1i7ci14 x1 = {-1, 0, 0, 0}; static struct i1i7ci14 x2 = {-1, -1, 0, 0}; static struct i1i7ci14 x3 = {-1, 0, -1, 0}; static struct i1i7ci14 x4 = {-1, -1, -1, -1}; print_prologue("i1i7ci14", _Alignof(struct i1i7ci14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i30S3s16sb1 {
  int a:30;
  short :3;
  short b:16;
  short c;
  _Bool d:1;
};
static struct i30S3s16sb1 x1 = {-1, 0, 0, 0}; static struct i30S3s16sb1 x2 = {-1, -1, 0, 0}; static struct i30S3s16sb1 x3 = {-1, 0, -1, 0}; static struct i30S3s16sb1 x4 = {-1, -1, -1, -1}; print_prologue("i30S3s16sb1", _Alignof(struct i30S3s16sb1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1b1b1b1 {
  int a:1;
  _Bool b:1;
  _Bool c:1;
  _Bool d:1;
};
static struct i1b1b1b1 x1 = {-1, 0, 0, 0}; static struct i1b1b1b1 x2 = {-1, -1, 0, 0}; static struct i1b1b1b1 x3 = {-1, 0, -1, 0}; static struct i1b1b1b1 x4 = {-1, -1, -1, -1}; print_prologue("i1b1b1b1", _Alignof(struct i1b1b1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ss6sc8 {
  short a;
  short b:6;
  short c;
  char d:8;
};
static struct ss6sc8 x1 = {-1, 0, 0, 0}; static struct ss6sc8 x2 = {-1, -1, 0, 0}; static struct ss6sc8 x3 = {-1, 0, -1, 0}; static struct ss6sc8 x4 = {-1, -1, -1, -1}; print_prologue("ss6sc8", _Alignof(struct ss6sc8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0ii4i17c7 {
  int :0;
  int a;
  int b:4;
  int c:17;
  char d:7;
};
static struct I0ii4i17c7 x1 = {-1, 0, 0, 0}; static struct I0ii4i17c7 x2 = {-1, -1, 0, 0}; static struct I0ii4i17c7 x3 = {-1, 0, -1, 0}; static struct I0ii4i17c7 x4 = {-1, -1, -1, -1}; print_prologue("I0ii4i17c7", _Alignof(struct I0ii4i17c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i26i14I23I10i20I22i19 {
  int a:26;
  int b:14;
  int :23;
  int :10;
  int c:20;
  int :22;
  int d:19;
};
static struct i26i14I23I10i20I22i19 x1 = {-1, 0, 0, 0}; static struct i26i14I23I10i20I22i19 x2 = {-1, -1, 0, 0}; static struct i26i14I23I10i20I22i19 x3 = {-1, 0, -1, 0}; static struct i26i14I23I10i20I22i19 x4 = {-1, -1, -1, -1}; print_prologue("i26i14I23I10i20I22i19", _Alignof(struct i26i14I23I10i20I22i19), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6b1is11 {
  char a:6;
  _Bool b:1;
  int c;
  short d:11;
};
static struct c6b1is11 x1 = {-1, 0, 0, 0}; static struct c6b1is11 x2 = {-1, -1, 0, 0}; static struct c6b1is11 x3 = {-1, 0, -1, 0}; static struct c6b1is11 x4 = {-1, -1, -1, -1}; print_prologue("c6b1is11", _Alignof(struct c6b1is11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i23i1i12s4 {
  int a:23;
  int b:1;
  int c:12;
  short d:4;
};
static struct i23i1i12s4 x1 = {-1, 0, 0, 0}; static struct i23i1i12s4 x2 = {-1, -1, 0, 0}; static struct i23i1i12s4 x3 = {-1, 0, -1, 0}; static struct i23i1i12s4 x4 = {-1, -1, -1, -1}; print_prologue("i23i1i12s4", _Alignof(struct i23i1i12s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i17ci29b1 {
  int a:17;
  char b;
  int c:29;
  _Bool d:1;
};
static struct i17ci29b1 x1 = {-1, 0, 0, 0}; static struct i17ci29b1 x2 = {-1, -1, 0, 0}; static struct i17ci29b1 x3 = {-1, 0, -1, 0}; static struct i17ci29b1 x4 = {-1, -1, -1, -1}; print_prologue("i17ci29b1", _Alignof(struct i17ci29b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C0i1s15I0is1 {
  char :0;
  int a:1;
  short b:15;
  int :0;
  int c;
  short d:1;
};
static struct C0i1s15I0is1 x1 = {-1, 0, 0, 0}; static struct C0i1s15I0is1 x2 = {-1, -1, 0, 0}; static struct C0i1s15I0is1 x3 = {-1, 0, -1, 0}; static struct C0i1s15I0is1 x4 = {-1, -1, -1, -1}; print_prologue("C0i1s15I0is1", _Alignof(struct C0i1s15I0is1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i28b1s2i11 {
  int a:28;
  _Bool b:1;
  short c:2;
  int d:11;
};
static struct i28b1s2i11 x1 = {-1, 0, 0, 0}; static struct i28b1s2i11 x2 = {-1, -1, 0, 0}; static struct i28b1s2i11 x3 = {-1, 0, -1, 0}; static struct i28b1s2i11 x4 = {-1, -1, -1, -1}; print_prologue("i28b1s2i11", _Alignof(struct i28b1s2i11), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct si5c6s3 {
  short a;
  int b:5;
  char c:6;
  short d:3;
};
static struct si5c6s3 x1 = {-1, 0, 0, 0}; static struct si5c6s3 x2 = {-1, -1, 0, 0}; static struct si5c6s3 x3 = {-1, 0, -1, 0}; static struct si5c6s3 x4 = {-1, -1, -1, -1}; print_prologue("si5c6s3", _Alignof(struct si5c6s3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3is12c1 {
  char a:3;
  int b;
  short c:12;
  char d:1;
};
static struct c3is12c1 x1 = {-1, 0, 0, 0}; static struct c3is12c1 x2 = {-1, -1, 0, 0}; static struct c3is12c1 x3 = {-1, 0, -1, 0}; static struct c3is12c1 x4 = {-1, -1, -1, -1}; print_prologue("c3is12c1", _Alignof(struct c3is12c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i3i7i8c4 {
  int a:3;
  int b:7;
  int c:8;
  char d:4;
};
static struct i3i7i8c4 x1 = {-1, 0, 0, 0}; static struct i3i7i8c4 x2 = {-1, -1, 0, 0}; static struct i3i7i8c4 x3 = {-1, 0, -1, 0}; static struct i3i7i8c4 x4 = {-1, -1, -1, -1}; print_prologue("i3i7i8c4", _Alignof(struct i3i7i8c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ci2i10b1 {
  char a;
  int b:2;
  int c:10;
  _Bool d:1;
};
static struct ci2i10b1 x1 = {-1, 0, 0, 0}; static struct ci2i10b1 x2 = {-1, -1, 0, 0}; static struct ci2i10b1 x3 = {-1, 0, -1, 0}; static struct ci2i10b1 x4 = {-1, -1, -1, -1}; print_prologue("ci2i10b1", _Alignof(struct ci2i10b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1I25i9bi3 {
  char a:1;
  int :25;
  int b:9;
  _Bool c;
  int d:3;
};
static struct c1I25i9bi3 x1 = {-1, 0, 0, 0}; static struct c1I25i9bi3 x2 = {-1, -1, 0, 0}; static struct c1I25i9bi3 x3 = {-1, 0, -1, 0}; static struct c1I25i9bi3 x4 = {-1, -1, -1, -1}; print_prologue("c1I25i9bi3", _Alignof(struct c1I25i9bi3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S6I0i14iB1c3s8 {
  short :6;
  int :0;
  int a:14;
  int b;
  _Bool :1;
  char c:3;
  short d:8;
};
static struct S6I0i14iB1c3s8 x1 = {-1, 0, 0, 0}; static struct S6I0i14iB1c3s8 x2 = {-1, -1, 0, 0}; static struct S6I0i14iB1c3s8 x3 = {-1, 0, -1, 0}; static struct S6I0i14iB1c3s8 x4 = {-1, -1, -1, -1}; print_prologue("S6I0i14iB1c3s8", _Alignof(struct S6I0i14iB1c3s8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ic2i4s7 {
  int a;
  char b:2;
  int c:4;
  short d:7;
};
static struct ic2i4s7 x1 = {-1, 0, 0, 0}; static struct ic2i4s7 x2 = {-1, -1, 0, 0}; static struct ic2i4s7 x3 = {-1, 0, -1, 0}; static struct ic2i4s7 x4 = {-1, -1, -1, -1}; print_prologue("ic2i4s7", _Alignof(struct ic2i4s7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1s2i28C1i4 {
  short a:1;
  short b:2;
  int c:28;
  char :1;
  int d:4;
};
static struct s1s2i28C1i4 x1 = {-1, 0, 0, 0}; static struct s1s2i28C1i4 x2 = {-1, -1, 0, 0}; static struct s1s2i28C1i4 x3 = {-1, 0, -1, 0}; static struct s1s2i28C1i4 x4 = {-1, -1, -1, -1}; print_prologue("s1s2i28C1i4", _Alignof(struct s1s2i28C1i4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i7si13 {
  _Bool a:1;
  int b:7;
  short c;
  int d:13;
};
static struct b1i7si13 x1 = {-1, 0, 0, 0}; static struct b1i7si13 x2 = {-1, -1, 0, 0}; static struct b1i7si13 x3 = {-1, 0, -1, 0}; static struct b1i7si13 x4 = {-1, -1, -1, -1}; print_prologue("b1i7si13", _Alignof(struct b1i7si13), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i6s2c1b1 {
  int a:6;
  short b:2;
  char c:1;
  _Bool d:1;
};
static struct i6s2c1b1 x1 = {-1, 0, 0, 0}; static struct i6s2c1b1 x2 = {-1, -1, 0, 0}; static struct i6s2c1b1 x3 = {-1, 0, -1, 0}; static struct i6s2c1b1 x4 = {-1, -1, -1, -1}; print_prologue("i6s2c1b1", _Alignof(struct i6s2c1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i18I2c1sc2 {
  int a:18;
  int :2;
  char b:1;
  short c;
  char d:2;
};
static struct i18I2c1sc2 x1 = {-1, 0, 0, 0}; static struct i18I2c1sc2 x2 = {-1, -1, 0, 0}; static struct i18I2c1sc2 x3 = {-1, 0, -1, 0}; static struct i18I2c1sc2 x4 = {-1, -1, -1, -1}; print_prologue("i18I2c1sc2", _Alignof(struct i18I2c1sc2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is9I0c8i {
  int a;
  short b:9;
  int :0;
  char c:8;
  int d;
};
static struct is9I0c8i x1 = {-1, 0, 0, 0}; static struct is9I0c8i x2 = {-1, -1, 0, 0}; static struct is9I0c8i x3 = {-1, 0, -1, 0}; static struct is9I0c8i x4 = {-1, -1, -1, -1}; print_prologue("is9I0c8i", _Alignof(struct is9I0c8i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4c5s8i12 {
  char a:4;
  char b:5;
  short c:8;
  int d:12;
};
static struct c4c5s8i12 x1 = {-1, 0, 0, 0}; static struct c4c5s8i12 x2 = {-1, -1, 0, 0}; static struct c4c5s8i12 x3 = {-1, 0, -1, 0}; static struct c4c5s8i12 x4 = {-1, -1, -1, -1}; print_prologue("c4c5s8i12", _Alignof(struct c4c5s8i12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s7i4i2s {
  short a:7;
  int b:4;
  int c:2;
  short d;
};
static struct s7i4i2s x1 = {-1, 0, 0, 0}; static struct s7i4i2s x2 = {-1, -1, 0, 0}; static struct s7i4i2s x3 = {-1, 0, -1, 0}; static struct s7i4i2s x4 = {-1, -1, -1, -1}; print_prologue("s7i4i2s", _Alignof(struct s7i4i2s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i25i9s1s {
  int a:25;
  int b:9;
  short c:1;
  short d;
};
static struct i25i9s1s x1 = {-1, 0, 0, 0}; static struct i25i9s1s x2 = {-1, -1, 0, 0}; static struct i25i9s1s x3 = {-1, 0, -1, 0}; static struct i25i9s1s x4 = {-1, -1, -1, -1}; print_prologue("i25i9s1s", _Alignof(struct i25i9s1s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0i20sbI14c4 {
  int :0;
  int a:20;
  short b;
  _Bool c;
  int :14;
  char d:4;
};
static struct I0i20sbI14c4 x1 = {-1, 0, 0, 0}; static struct I0i20sbI14c4 x2 = {-1, -1, 0, 0}; static struct I0i20sbI14c4 x3 = {-1, 0, -1, 0}; static struct I0i20sbI14c4 x4 = {-1, -1, -1, -1}; print_prologue("I0i20sbI14c4", _Alignof(struct I0i20sbI14c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bb1i14i21 {
  _Bool a;
  _Bool b:1;
  int c:14;
  int d:21;
};
static struct bb1i14i21 x1 = {-1, 0, 0, 0}; static struct bb1i14i21 x2 = {-1, -1, 0, 0}; static struct bb1i14i21 x3 = {-1, 0, -1, 0}; static struct bb1i14i21 x4 = {-1, -1, -1, -1}; print_prologue("bb1i14i21", _Alignof(struct bb1i14i21), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1ic5b {
  char a:1;
  int b;
  char c:5;
  _Bool d;
};
static struct c1ic5b x1 = {-1, 0, 0, 0}; static struct c1ic5b x2 = {-1, -1, 0, 0}; static struct c1ic5b x3 = {-1, 0, -1, 0}; static struct c1ic5b x4 = {-1, -1, -1, -1}; print_prologue("c1ic5b", _Alignof(struct c1ic5b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2i2s7i1 {
  char a:2;
  int b:2;
  short c:7;
  int d:1;
};
static struct c2i2s7i1 x1 = {-1, 0, 0, 0}; static struct c2i2s7i1 x2 = {-1, -1, 0, 0}; static struct c2i2s7i1 x3 = {-1, 0, -1, 0}; static struct c2i2s7i1 x4 = {-1, -1, -1, -1}; print_prologue("c2i2s7i1", _Alignof(struct c2i2s7i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i26b1bs2 {
  int a:26;
  _Bool b:1;
  _Bool c;
  short d:2;
};
static struct i26b1bs2 x1 = {-1, 0, 0, 0}; static struct i26b1bs2 x2 = {-1, -1, 0, 0}; static struct i26b1bs2 x3 = {-1, 0, -1, 0}; static struct i26b1bs2 x4 = {-1, -1, -1, -1}; print_prologue("i26b1bs2", _Alignof(struct i26b1bs2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7s3s12c5 {
  int a:7;
  short b:3;
  short c:12;
  char d:5;
};
static struct i7s3s12c5 x1 = {-1, 0, 0, 0}; static struct i7s3s12c5 x2 = {-1, -1, 0, 0}; static struct i7s3s12c5 x3 = {-1, 0, -1, 0}; static struct i7s3s12c5 x4 = {-1, -1, -1, -1}; print_prologue("i7s3s12c5", _Alignof(struct i7s3s12c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4i1i2c5 {
  short a:4;
  int b:1;
  int c:2;
  char d:5;
};
static struct s4i1i2c5 x1 = {-1, 0, 0, 0}; static struct s4i1i2c5 x2 = {-1, -1, 0, 0}; static struct s4i1i2c5 x3 = {-1, 0, -1, 0}; static struct s4i1i2c5 x4 = {-1, -1, -1, -1}; print_prologue("s4i1i2c5", _Alignof(struct s4i1i2c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1i4i4i19 {
  short a:1;
  int b:4;
  int c:4;
  int d:19;
};
static struct s1i4i4i19 x1 = {-1, 0, 0, 0}; static struct s1i4i4i19 x2 = {-1, -1, 0, 0}; static struct s1i4i4i19 x3 = {-1, 0, -1, 0}; static struct s1i4i4i19 x4 = {-1, -1, -1, -1}; print_prologue("s1i4i4i19", _Alignof(struct s1i4i4i19), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2i23c8c5 {
  int a:2;
  int b:23;
  char c:8;
  char d:5;
};
static struct i2i23c8c5 x1 = {-1, 0, 0, 0}; static struct i2i23c8c5 x2 = {-1, -1, 0, 0}; static struct i2i23c8c5 x3 = {-1, 0, -1, 0}; static struct i2i23c8c5 x4 = {-1, -1, -1, -1}; print_prologue("i2i23c8c5", _Alignof(struct i2i23c8c5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5sC8b1s9 {
  int a:5;
  short b;
  char :8;
  _Bool c:1;
  short d:9;
};
static struct i5sC8b1s9 x1 = {-1, 0, 0, 0}; static struct i5sC8b1s9 x2 = {-1, -1, 0, 0}; static struct i5sC8b1s9 x3 = {-1, 0, -1, 0}; static struct i5sC8b1s9 x4 = {-1, -1, -1, -1}; print_prologue("i5sC8b1s9", _Alignof(struct i5sC8b1s9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2i19c1i17 {
  short a:2;
  int b:19;
  char c:1;
  int d:17;
};
static struct s2i19c1i17 x1 = {-1, 0, 0, 0}; static struct s2i19c1i17 x2 = {-1, -1, 0, 0}; static struct s2i19c1i17 x3 = {-1, 0, -1, 0}; static struct s2i19c1i17 x4 = {-1, -1, -1, -1}; print_prologue("s2i19c1i17", _Alignof(struct s2i19c1i17), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1s3s10i7 {
  char a:1;
  short b:3;
  short c:10;
  int d:7;
};
static struct c1s3s10i7 x1 = {-1, 0, 0, 0}; static struct c1s3s10i7 x2 = {-1, -1, 0, 0}; static struct c1s3s10i7 x3 = {-1, 0, -1, 0}; static struct c1s3s10i7 x4 = {-1, -1, -1, -1}; print_prologue("c1s3s10i7", _Alignof(struct c1s3s10i7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4i4i21c {
  char a:4;
  int b:4;
  int c:21;
  char d;
};
static struct c4i4i21c x1 = {-1, 0, 0, 0}; static struct c4i4i21c x2 = {-1, -1, 0, 0}; static struct c4i4i21c x3 = {-1, 0, -1, 0}; static struct c4i4i21c x4 = {-1, -1, -1, -1}; print_prologue("c4i4i21c", _Alignof(struct c4i4i21c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1B1ci15i2 {
  short a:1;
  _Bool :1;
  char b;
  int c:15;
  int d:2;
};
static struct s1B1ci15i2 x1 = {-1, 0, 0, 0}; static struct s1B1ci15i2 x2 = {-1, -1, 0, 0}; static struct s1B1ci15i2 x3 = {-1, 0, -1, 0}; static struct s1B1ci15i2 x4 = {-1, -1, -1, -1}; print_prologue("s1B1ci15i2", _Alignof(struct s1B1ci15i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I2i2i3i22c {
  int :2;
  int a:2;
  int b:3;
  int c:22;
  char d;
};
static struct I2i2i3i22c x1 = {-1, 0, 0, 0}; static struct I2i2i3i22c x2 = {-1, -1, 0, 0}; static struct I2i2i3i22c x3 = {-1, 0, -1, 0}; static struct I2i2i3i22c x4 = {-1, -1, -1, -1}; print_prologue("I2i2i3i22c", _Alignof(struct I2i2i3i22c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i30C5i22i1s1 {
  int a:30;
  char :5;
  int b:22;
  int c:1;
  short d:1;
};
static struct i30C5i22i1s1 x1 = {-1, 0, 0, 0}; static struct i30C5i22i1s1 x2 = {-1, -1, 0, 0}; static struct i30C5i22i1s1 x3 = {-1, 0, -1, 0}; static struct i30C5i22i1s1 x4 = {-1, -1, -1, -1}; print_prologue("i30C5i22i1s1", _Alignof(struct i30C5i22i1s1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2i1i12I9i10 {
  int a:2;
  int b:1;
  int c:12;
  int :9;
  int d:10;
};
static struct i2i1i12I9i10 x1 = {-1, 0, 0, 0}; static struct i2i1i12I9i10 x2 = {-1, -1, 0, 0}; static struct i2i1i12I9i10 x3 = {-1, 0, -1, 0}; static struct i2i1i12I9i10 x4 = {-1, -1, -1, -1}; print_prologue("i2i1i12I9i10", _Alignof(struct i2i1i12I9i10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cs11B1i14c4 {
  char a;
  short b:11;
  _Bool :1;
  int c:14;
  char d:4;
};
static struct cs11B1i14c4 x1 = {-1, 0, 0, 0}; static struct cs11B1i14c4 x2 = {-1, -1, 0, 0}; static struct cs11B1i14c4 x3 = {-1, 0, -1, 0}; static struct cs11B1i14c4 x4 = {-1, -1, -1, -1}; print_prologue("cs11B1i14c4", _Alignof(struct cs11B1i14c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1cs14i24 {
  _Bool a:1;
  char b;
  short c:14;
  int d:24;
};
static struct b1cs14i24 x1 = {-1, 0, 0, 0}; static struct b1cs14i24 x2 = {-1, -1, 0, 0}; static struct b1cs14i24 x3 = {-1, 0, -1, 0}; static struct b1cs14i24 x4 = {-1, -1, -1, -1}; print_prologue("b1cs14i24", _Alignof(struct b1cs14i24), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1s16b1B1c6 {
  char a:1;
  short b:16;
  _Bool c:1;
  _Bool :1;
  char d:6;
};
static struct c1s16b1B1c6 x1 = {-1, 0, 0, 0}; static struct c1s16b1B1c6 x2 = {-1, -1, 0, 0}; static struct c1s16b1B1c6 x3 = {-1, 0, -1, 0}; static struct c1s16b1B1c6 x4 = {-1, -1, -1, -1}; print_prologue("c1s16b1B1c6", _Alignof(struct c1s16b1B1c6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bI11ic1i3 {
  _Bool a;
  int :11;
  int b;
  char c:1;
  int d:3;
};
static struct bI11ic1i3 x1 = {-1, 0, 0, 0}; static struct bI11ic1i3 x2 = {-1, -1, 0, 0}; static struct bI11ic1i3 x3 = {-1, 0, -1, 0}; static struct bI11ic1i3 x4 = {-1, -1, -1, -1}; print_prologue("bI11ic1i3", _Alignof(struct bI11ic1i3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i15I0ii1 {
  _Bool a:1;
  int b:15;
  int :0;
  int c;
  int d:1;
};
static struct b1i15I0ii1 x1 = {-1, 0, 0, 0}; static struct b1i15I0ii1 x2 = {-1, -1, 0, 0}; static struct b1i15I0ii1 x3 = {-1, 0, -1, 0}; static struct b1i15I0ii1 x4 = {-1, -1, -1, -1}; print_prologue("b1i15I0ii1", _Alignof(struct b1i15I0ii1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5i8s2i2 {
  int a:5;
  int b:8;
  short c:2;
  int d:2;
};
static struct i5i8s2i2 x1 = {-1, 0, 0, 0}; static struct i5i8s2i2 x2 = {-1, -1, 0, 0}; static struct i5i8s2i2 x3 = {-1, 0, -1, 0}; static struct i5i8s2i2 x4 = {-1, -1, -1, -1}; print_prologue("i5i8s2i2", _Alignof(struct i5i8s2i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sc1i2c4 {
  short a;
  char b:1;
  int c:2;
  char d:4;
};
static struct sc1i2c4 x1 = {-1, 0, 0, 0}; static struct sc1i2c4 x2 = {-1, -1, 0, 0}; static struct sc1i2c4 x3 = {-1, 0, -1, 0}; static struct sc1i2c4 x4 = {-1, -1, -1, -1}; print_prologue("sc1i2c4", _Alignof(struct sc1i2c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1c6I0S1s1i26 {
  int a:1;
  char b:6;
  int :0;
  short :1;
  short c:1;
  int d:26;
};
static struct i1c6I0S1s1i26 x1 = {-1, 0, 0, 0}; static struct i1c6I0S1s1i26 x2 = {-1, -1, 0, 0}; static struct i1c6I0S1s1i26 x3 = {-1, 0, -1, 0}; static struct i1c6I0S1s1i26 x4 = {-1, -1, -1, -1}; print_prologue("i1c6I0S1s1i26", _Alignof(struct i1c6I0S1s1i26), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7b1C7s3s7 {
  int a:7;
  _Bool b:1;
  char :7;
  short c:3;
  short d:7;
};
static struct i7b1C7s3s7 x1 = {-1, 0, 0, 0}; static struct i7b1C7s3s7 x2 = {-1, -1, 0, 0}; static struct i7b1C7s3s7 x3 = {-1, 0, -1, 0}; static struct i7b1C7s3s7 x4 = {-1, -1, -1, -1}; print_prologue("i7b1C7s3s7", _Alignof(struct i7b1C7s3s7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2i16c1b {
  char a:2;
  int b:16;
  char c:1;
  _Bool d;
};
static struct c2i16c1b x1 = {-1, 0, 0, 0}; static struct c2i16c1b x2 = {-1, -1, 0, 0}; static struct c2i16c1b x3 = {-1, 0, -1, 0}; static struct c2i16c1b x4 = {-1, -1, -1, -1}; print_prologue("c2i16c1b", _Alignof(struct c2i16c1b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s5i3i32c4 {
  short a:5;
  int b:3;
  int c:32;
  char d:4;
};
static struct s5i3i32c4 x1 = {-1, 0, 0, 0}; static struct s5i3i32c4 x2 = {-1, -1, 0, 0}; static struct s5i3i32c4 x3 = {-1, 0, -1, 0}; static struct s5i3i32c4 x4 = {-1, -1, -1, -1}; print_prologue("s5i3i32c4", _Alignof(struct s5i3i32c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2b1i1i7 {
  char a:2;
  _Bool b:1;
  int c:1;
  int d:7;
};
static struct c2b1i1i7 x1 = {-1, 0, 0, 0}; static struct c2b1i1i7 x2 = {-1, -1, 0, 0}; static struct c2b1i1i7 x3 = {-1, 0, -1, 0}; static struct c2b1i1i7 x4 = {-1, -1, -1, -1}; print_prologue("c2b1i1i7", _Alignof(struct c2b1i1i7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sS0s14i14i2 {
  short a;
  short :0;
  short b:14;
  int c:14;
  int d:2;
};
static struct sS0s14i14i2 x1 = {-1, 0, 0, 0}; static struct sS0s14i14i2 x2 = {-1, -1, 0, 0}; static struct sS0s14i14i2 x3 = {-1, 0, -1, 0}; static struct sS0s14i14i2 x4 = {-1, -1, -1, -1}; print_prologue("sS0s14i14i2", _Alignof(struct sS0s14i14i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i10s5c4i3 {
  int a:10;
  short b:5;
  char c:4;
  int d:3;
};
static struct i10s5c4i3 x1 = {-1, 0, 0, 0}; static struct i10s5c4i3 x2 = {-1, -1, 0, 0}; static struct i10s5c4i3 x3 = {-1, 0, -1, 0}; static struct i10s5c4i3 x4 = {-1, -1, -1, -1}; print_prologue("i10s5c4i3", _Alignof(struct i10s5c4i3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4is4i14 {
  char a:4;
  int b;
  short c:4;
  int d:14;
};
static struct c4is4i14 x1 = {-1, 0, 0, 0}; static struct c4is4i14 x2 = {-1, -1, 0, 0}; static struct c4is4i14 x3 = {-1, 0, -1, 0}; static struct c4is4i14 x4 = {-1, -1, -1, -1}; print_prologue("c4is4i14", _Alignof(struct c4is4i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i7ssi10 {
  int a:7;
  short b;
  short c;
  int d:10;
};
static struct i7ssi10 x1 = {-1, 0, 0, 0}; static struct i7ssi10 x2 = {-1, -1, 0, 0}; static struct i7ssi10 x3 = {-1, 0, -1, 0}; static struct i7ssi10 x4 = {-1, -1, -1, -1}; print_prologue("i7ssi10", _Alignof(struct i7ssi10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sc1S6c5i2 {
  short a;
  char b:1;
  short :6;
  char c:5;
  int d:2;
};
static struct sc1S6c5i2 x1 = {-1, 0, 0, 0}; static struct sc1S6c5i2 x2 = {-1, -1, 0, 0}; static struct sc1S6c5i2 x3 = {-1, 0, -1, 0}; static struct sc1S6c5i2 x4 = {-1, -1, -1, -1}; print_prologue("sc1S6c5i2", _Alignof(struct sc1S6c5i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cS1S4c4si8 {
  char a;
  short :1;
  short :4;
  char b:4;
  short c;
  int d:8;
};
static struct cS1S4c4si8 x1 = {-1, 0, 0, 0}; static struct cS1S4c4si8 x2 = {-1, -1, 0, 0}; static struct cS1S4c4si8 x3 = {-1, 0, -1, 0}; static struct cS1S4c4si8 x4 = {-1, -1, -1, -1}; print_prologue("cS1S4c4si8", _Alignof(struct cS1S4c4si8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i10i11b1b1 {
  int a:10;
  int b:11;
  _Bool c:1;
  _Bool d:1;
};
static struct i10i11b1b1 x1 = {-1, 0, 0, 0}; static struct i10i11b1b1 x2 = {-1, -1, 0, 0}; static struct i10i11b1b1 x3 = {-1, 0, -1, 0}; static struct i10i11b1b1 x4 = {-1, -1, -1, -1}; print_prologue("i10i11b1b1", _Alignof(struct i10i11b1b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i10ic7b1 {
  int a:10;
  int b;
  char c:7;
  _Bool d:1;
};
static struct i10ic7b1 x1 = {-1, 0, 0, 0}; static struct i10ic7b1 x2 = {-1, -1, 0, 0}; static struct i10ic7b1 x3 = {-1, 0, -1, 0}; static struct i10ic7b1 x4 = {-1, -1, -1, -1}; print_prologue("i10ic7b1", _Alignof(struct i10ic7b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i25i32i3s16 {
  int a:25;
  int b:32;
  int c:3;
  short d:16;
};
static struct i25i32i3s16 x1 = {-1, 0, 0, 0}; static struct i25i32i3s16 x2 = {-1, -1, 0, 0}; static struct i25i32i3s16 x3 = {-1, 0, -1, 0}; static struct i25i32i3s16 x4 = {-1, -1, -1, -1}; print_prologue("i25i32i3s16", _Alignof(struct i25i32i3s16), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S6C5S8c7s8I0s2i4 {
  short :6;
  char :5;
  short :8;
  char a:7;
  short b:8;
  int :0;
  short c:2;
  int d:4;
};
static struct S6C5S8c7s8I0s2i4 x1 = {-1, 0, 0, 0}; static struct S6C5S8c7s8I0s2i4 x2 = {-1, -1, 0, 0}; static struct S6C5S8c7s8I0s2i4 x3 = {-1, 0, -1, 0}; static struct S6C5S8c7s8I0s2i4 x4 = {-1, -1, -1, -1}; print_prologue("S6C5S8c7s8I0s2i4", _Alignof(struct S6C5S8c7s8I0s2i4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sc1s4s2 {
  short a;
  char b:1;
  short c:4;
  short d:2;
};
static struct sc1s4s2 x1 = {-1, 0, 0, 0}; static struct sc1s4s2 x2 = {-1, -1, 0, 0}; static struct sc1s4s2 x3 = {-1, 0, -1, 0}; static struct sc1s4s2 x4 = {-1, -1, -1, -1}; print_prologue("sc1s4s2", _Alignof(struct sc1s4s2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cb1s1c7 {
  char a;
  _Bool b:1;
  short c:1;
  char d:7;
};
static struct cb1s1c7 x1 = {-1, 0, 0, 0}; static struct cb1s1c7 x2 = {-1, -1, 0, 0}; static struct cb1s1c7 x3 = {-1, 0, -1, 0}; static struct cb1s1c7 x4 = {-1, -1, -1, -1}; print_prologue("cb1s1c7", _Alignof(struct cb1s1c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1ii1b {
  _Bool a:1;
  int b;
  int c:1;
  _Bool d;
};
static struct b1ii1b x1 = {-1, 0, 0, 0}; static struct b1ii1b x2 = {-1, -1, 0, 0}; static struct b1ii1b x3 = {-1, 0, -1, 0}; static struct b1ii1b x4 = {-1, -1, -1, -1}; print_prologue("b1ii1b", _Alignof(struct b1ii1b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii2i19i10 {
  int a;
  int b:2;
  int c:19;
  int d:10;
};
static struct ii2i19i10 x1 = {-1, 0, 0, 0}; static struct ii2i19i10 x2 = {-1, -1, 0, 0}; static struct ii2i19i10 x3 = {-1, 0, -1, 0}; static struct ii2i19i10 x4 = {-1, -1, -1, -1}; print_prologue("ii2i19i10", _Alignof(struct ii2i19i10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii2i9i {
  int a;
  int b:2;
  int c:9;
  int d;
};
static struct ii2i9i x1 = {-1, 0, 0, 0}; static struct ii2i9i x2 = {-1, -1, 0, 0}; static struct ii2i9i x3 = {-1, 0, -1, 0}; static struct ii2i9i x4 = {-1, -1, -1, -1}; print_prologue("ii2i9i", _Alignof(struct ii2i9i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s5ci32i2 {
  short a:5;
  char b;
  int c:32;
  int d:2;
};
static struct s5ci32i2 x1 = {-1, 0, 0, 0}; static struct s5ci32i2 x2 = {-1, -1, 0, 0}; static struct s5ci32i2 x3 = {-1, 0, -1, 0}; static struct s5ci32i2 x4 = {-1, -1, -1, -1}; print_prologue("s5ci32i2", _Alignof(struct s5ci32i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1iC7ii26 {
  short a:1;
  int b;
  char :7;
  int c;
  int d:26;
};
static struct s1iC7ii26 x1 = {-1, 0, 0, 0}; static struct s1iC7ii26 x2 = {-1, -1, 0, 0}; static struct s1iC7ii26 x3 = {-1, 0, -1, 0}; static struct s1iC7ii26 x4 = {-1, -1, -1, -1}; print_prologue("s1iC7ii26", _Alignof(struct s1iC7ii26), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1s12i19I31i14 {
  char a:1;
  short b:12;
  int c:19;
  int :31;
  int d:14;
};
static struct c1s12i19I31i14 x1 = {-1, 0, 0, 0}; static struct c1s12i19I31i14 x2 = {-1, -1, 0, 0}; static struct c1s12i19I31i14 x3 = {-1, 0, -1, 0}; static struct c1s12i19I31i14 x4 = {-1, -1, -1, -1}; print_prologue("c1s12i19I31i14", _Alignof(struct c1s12i19I31i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i14I13b1b1s14 {
  int a:14;
  int :13;
  _Bool b:1;
  _Bool c:1;
  short d:14;
};
static struct i14I13b1b1s14 x1 = {-1, 0, 0, 0}; static struct i14I13b1b1s14 x2 = {-1, -1, 0, 0}; static struct i14I13b1b1s14 x3 = {-1, 0, -1, 0}; static struct i14I13b1b1s14 x4 = {-1, -1, -1, -1}; print_prologue("i14I13b1b1s14", _Alignof(struct i14I13b1b1s14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3I1i2sc {
  char a:3;
  int :1;
  int b:2;
  short c;
  char d;
};
static struct c3I1i2sc x1 = {-1, 0, 0, 0}; static struct c3I1i2sc x2 = {-1, -1, 0, 0}; static struct c3I1i2sc x3 = {-1, 0, -1, 0}; static struct c3I1i2sc x4 = {-1, -1, -1, -1}; print_prologue("c3I1i2sc", _Alignof(struct c3I1i2sc), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1c1C0I26b1i2 {
  _Bool a:1;
  char b:1;
  char :0;
  int :26;
  _Bool c:1;
  int d:2;
};
static struct b1c1C0I26b1i2 x1 = {-1, 0, 0, 0}; static struct b1c1C0I26b1i2 x2 = {-1, -1, 0, 0}; static struct b1c1C0I26b1i2 x3 = {-1, 0, -1, 0}; static struct b1c1C0I26b1i2 x4 = {-1, -1, -1, -1}; print_prologue("b1c1C0I26b1i2", _Alignof(struct b1c1C0I26b1i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i13i2ii30 {
  int a:13;
  int b:2;
  int c;
  int d:30;
};
static struct i13i2ii30 x1 = {-1, 0, 0, 0}; static struct i13i2ii30 x2 = {-1, -1, 0, 0}; static struct i13i2ii30 x3 = {-1, 0, -1, 0}; static struct i13i2ii30 x4 = {-1, -1, -1, -1}; print_prologue("i13i2ii30", _Alignof(struct i13i2ii30), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii11ss10 {
  int a;
  int b:11;
  short c;
  short d:10;
};
static struct ii11ss10 x1 = {-1, 0, 0, 0}; static struct ii11ss10 x2 = {-1, -1, 0, 0}; static struct ii11ss10 x3 = {-1, 0, -1, 0}; static struct ii11ss10 x4 = {-1, -1, -1, -1}; print_prologue("ii11ss10", _Alignof(struct ii11ss10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ici27s {
  int a;
  char b;
  int c:27;
  short d;
};
static struct ici27s x1 = {-1, 0, 0, 0}; static struct ici27s x2 = {-1, -1, 0, 0}; static struct ici27s x3 = {-1, 0, -1, 0}; static struct ici27s x4 = {-1, -1, -1, -1}; print_prologue("ici27s", _Alignof(struct ici27s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1s8s3i32 {
  int a:1;
  short b:8;
  short c:3;
  int d:32;
};
static struct i1s8s3i32 x1 = {-1, 0, 0, 0}; static struct i1s8s3i32 x2 = {-1, -1, 0, 0}; static struct i1s8s3i32 x3 = {-1, 0, -1, 0}; static struct i1s8s3i32 x4 = {-1, -1, -1, -1}; print_prologue("i1s8s3i32", _Alignof(struct i1s8s3i32), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i15c2i7i {
  int a:15;
  char b:2;
  int c:7;
  int d;
};
static struct i15c2i7i x1 = {-1, 0, 0, 0}; static struct i15c2i7i x2 = {-1, -1, 0, 0}; static struct i15c2i7i x3 = {-1, 0, -1, 0}; static struct i15c2i7i x4 = {-1, -1, -1, -1}; print_prologue("i15c2i7i", _Alignof(struct i15c2i7i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S0i27s16i27c3 {
  short :0;
  int a:27;
  short b:16;
  int c:27;
  char d:3;
};
static struct S0i27s16i27c3 x1 = {-1, 0, 0, 0}; static struct S0i27s16i27c3 x2 = {-1, -1, 0, 0}; static struct S0i27s16i27c3 x3 = {-1, 0, -1, 0}; static struct S0i27s16i27c3 x4 = {-1, -1, -1, -1}; print_prologue("S0i27s16i27c3", _Alignof(struct S0i27s16i27c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ic2ii2 {
  int a;
  char b:2;
  int c;
  int d:2;
};
static struct ic2ii2 x1 = {-1, 0, 0, 0}; static struct ic2ii2 x2 = {-1, -1, 0, 0}; static struct ic2ii2 x3 = {-1, 0, -1, 0}; static struct ic2ii2 x4 = {-1, -1, -1, -1}; print_prologue("ic2ii2", _Alignof(struct ic2ii2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1i21s16b1 {
  short a:1;
  int b:21;
  short c:16;
  _Bool d:1;
};
static struct s1i21s16b1 x1 = {-1, 0, 0, 0}; static struct s1i21s16b1 x2 = {-1, -1, 0, 0}; static struct s1i21s16b1 x3 = {-1, 0, -1, 0}; static struct s1i21s16b1 x4 = {-1, -1, -1, -1}; print_prologue("s1i21s16b1", _Alignof(struct s1i21s16b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3s3s6s12 {
  char a:3;
  short b:3;
  short c:6;
  short d:12;
};
static struct c3s3s6s12 x1 = {-1, 0, 0, 0}; static struct c3s3s6s12 x2 = {-1, -1, 0, 0}; static struct c3s3s6s12 x3 = {-1, 0, -1, 0}; static struct c3s3s6s12 x4 = {-1, -1, -1, -1}; print_prologue("c3s3s6s12", _Alignof(struct c3s3s6s12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1sb1i22 {
  _Bool a:1;
  short b;
  _Bool c:1;
  int d:22;
};
static struct b1sb1i22 x1 = {-1, 0, 0, 0}; static struct b1sb1i22 x2 = {-1, -1, 0, 0}; static struct b1sb1i22 x3 = {-1, 0, -1, 0}; static struct b1sb1i22 x4 = {-1, -1, -1, -1}; print_prologue("b1sb1i22", _Alignof(struct b1sb1i22), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cs3c2c7 {
  char a;
  short b:3;
  char c:2;
  char d:7;
};
static struct cs3c2c7 x1 = {-1, 0, 0, 0}; static struct cs3c2c7 x2 = {-1, -1, 0, 0}; static struct cs3c2c7 x3 = {-1, 0, -1, 0}; static struct cs3c2c7 x4 = {-1, -1, -1, -1}; print_prologue("cs3c2c7", _Alignof(struct cs3c2c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1c6i10i9 {
  _Bool a:1;
  char b:6;
  int c:10;
  int d:9;
};
static struct b1c6i10i9 x1 = {-1, 0, 0, 0}; static struct b1c6i10i9 x2 = {-1, -1, 0, 0}; static struct b1c6i10i9 x3 = {-1, 0, -1, 0}; static struct b1c6i10i9 x4 = {-1, -1, -1, -1}; print_prologue("b1c6i10i9", _Alignof(struct b1c6i10i9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ici1i1 {
  int a;
  char b;
  int c:1;
  int d:1;
};
static struct ici1i1 x1 = {-1, 0, 0, 0}; static struct ici1i1 x2 = {-1, -1, 0, 0}; static struct ici1i1 x3 = {-1, 0, -1, 0}; static struct ici1i1 x4 = {-1, -1, -1, -1}; print_prologue("ici1i1", _Alignof(struct ici1i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i32C0i1s1c7 {
  int a:32;
  char :0;
  int b:1;
  short c:1;
  char d:7;
};
static struct i32C0i1s1c7 x1 = {-1, 0, 0, 0}; static struct i32C0i1s1c7 x2 = {-1, -1, 0, 0}; static struct i32C0i1s1c7 x3 = {-1, 0, -1, 0}; static struct i32C0i1s1c7 x4 = {-1, -1, -1, -1}; print_prologue("i32C0i1s1c7", _Alignof(struct i32C0i1s1c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i14I23s5si12 {
  int a:14;
  int :23;
  short b:5;
  short c;
  int d:12;
};
static struct i14I23s5si12 x1 = {-1, 0, 0, 0}; static struct i14I23s5si12 x2 = {-1, -1, 0, 0}; static struct i14I23s5si12 x3 = {-1, 0, -1, 0}; static struct i14I23s5si12 x4 = {-1, -1, -1, -1}; print_prologue("i14I23s5si12", _Alignof(struct i14I23s5si12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i14i2ic6 {
  int a:14;
  int b:2;
  int c;
  char d:6;
};
static struct i14i2ic6 x1 = {-1, 0, 0, 0}; static struct i14i2ic6 x2 = {-1, -1, 0, 0}; static struct i14i2ic6 x3 = {-1, 0, -1, 0}; static struct i14i2ic6 x4 = {-1, -1, -1, -1}; print_prologue("i14i2ic6", _Alignof(struct i14i2ic6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1c4i11i14 {
  char a:1;
  char b:4;
  int c:11;
  int d:14;
};
static struct c1c4i11i14 x1 = {-1, 0, 0, 0}; static struct c1c4i11i14 x2 = {-1, -1, 0, 0}; static struct c1c4i11i14 x3 = {-1, 0, -1, 0}; static struct c1c4i11i14 x4 = {-1, -1, -1, -1}; print_prologue("c1c4i11i14", _Alignof(struct c1c4i11i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bi5is6 {
  _Bool a;
  int b:5;
  int c;
  short d:6;
};
static struct bi5is6 x1 = {-1, 0, 0, 0}; static struct bi5is6 x2 = {-1, -1, 0, 0}; static struct bi5is6 x3 = {-1, 0, -1, 0}; static struct bi5is6 x4 = {-1, -1, -1, -1}; print_prologue("bi5is6", _Alignof(struct bi5is6), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct sc8is {
  short a;
  char b:8;
  int c;
  short d;
};
static struct sc8is x1 = {-1, 0, 0, 0}; static struct sc8is x2 = {-1, -1, 0, 0}; static struct sc8is x3 = {-1, 0, -1, 0}; static struct sc8is x4 = {-1, -1, -1, -1}; print_prologue("sc8is", _Alignof(struct sc8is), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ic3s4i27 {
  int a;
  char b:3;
  short c:4;
  int d:27;
};
static struct ic3s4i27 x1 = {-1, 0, 0, 0}; static struct ic3s4i27 x2 = {-1, -1, 0, 0}; static struct ic3s4i27 x3 = {-1, 0, -1, 0}; static struct ic3s4i27 x4 = {-1, -1, -1, -1}; print_prologue("ic3s4i27", _Alignof(struct ic3s4i27), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1I8s4c2b {
  short a:1;
  int :8;
  short b:4;
  char c:2;
  _Bool d;
};
static struct s1I8s4c2b x1 = {-1, 0, 0, 0}; static struct s1I8s4c2b x2 = {-1, -1, 0, 0}; static struct s1I8s4c2b x3 = {-1, 0, -1, 0}; static struct s1I8s4c2b x4 = {-1, -1, -1, -1}; print_prologue("s1I8s4c2b", _Alignof(struct s1I8s4c2b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i4c6ii1 {
  int a:4;
  char b:6;
  int c;
  int d:1;
};
static struct i4c6ii1 x1 = {-1, 0, 0, 0}; static struct i4c6ii1 x2 = {-1, -1, 0, 0}; static struct i4c6ii1 x3 = {-1, 0, -1, 0}; static struct i4c6ii1 x4 = {-1, -1, -1, -1}; print_prologue("i4c6ii1", _Alignof(struct i4c6ii1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ci5s4b1 {
  char a;
  int b:5;
  short c:4;
  _Bool d:1;
};
static struct ci5s4b1 x1 = {-1, 0, 0, 0}; static struct ci5s4b1 x2 = {-1, -1, 0, 0}; static struct ci5s4b1 x3 = {-1, 0, -1, 0}; static struct ci5s4b1 x4 = {-1, -1, -1, -1}; print_prologue("ci5s4b1", _Alignof(struct ci5s4b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ci2s10S9i2 {
  char a;
  int b:2;
  short c:10;
  short :9;
  int d:2;
};
static struct ci2s10S9i2 x1 = {-1, 0, 0, 0}; static struct ci2s10S9i2 x2 = {-1, -1, 0, 0}; static struct ci2s10S9i2 x3 = {-1, 0, -1, 0}; static struct ci2s10S9i2 x4 = {-1, -1, -1, -1}; print_prologue("ci2s10S9i2", _Alignof(struct ci2s10S9i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1s2i5c1 {
  char a:1;
  short b:2;
  int c:5;
  char d:1;
};
static struct c1s2i5c1 x1 = {-1, 0, 0, 0}; static struct c1s2i5c1 x2 = {-1, -1, 0, 0}; static struct c1s2i5c1 x3 = {-1, 0, -1, 0}; static struct c1s2i5c1 x4 = {-1, -1, -1, -1}; print_prologue("c1s2i5c1", _Alignof(struct c1s2i5c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i12s13i19s7 {
  int a:12;
  short b:13;
  int c:19;
  short d:7;
};
static struct i12s13i19s7 x1 = {-1, 0, 0, 0}; static struct i12s13i19s7 x2 = {-1, -1, 0, 0}; static struct i12s13i19s7 x3 = {-1, 0, -1, 0}; static struct i12s13i19s7 x4 = {-1, -1, -1, -1}; print_prologue("i12s13i19s7", _Alignof(struct i12s13i19s7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i11i26s7I19s {
  int a:11;
  int b:26;
  short c:7;
  int :19;
  short d;
};
static struct i11i26s7I19s x1 = {-1, 0, 0, 0}; static struct i11i26s7I19s x2 = {-1, -1, 0, 0}; static struct i11i26s7I19s x3 = {-1, 0, -1, 0}; static struct i11i26s7I19s x4 = {-1, -1, -1, -1}; print_prologue("i11i26s7I19s", _Alignof(struct i11i26s7I19s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2b1i11i {
  short a:2;
  _Bool b:1;
  int c:11;
  int d;
};
static struct s2b1i11i x1 = {-1, 0, 0, 0}; static struct s2b1i11i x2 = {-1, -1, 0, 0}; static struct s2b1i11i x3 = {-1, 0, -1, 0}; static struct s2b1i11i x4 = {-1, -1, -1, -1}; print_prologue("s2b1i11i", _Alignof(struct s2b1i11i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i3s2ii21 {
  int a:3;
  short b:2;
  int c;
  int d:21;
};
static struct i3s2ii21 x1 = {-1, 0, 0, 0}; static struct i3s2ii21 x2 = {-1, -1, 0, 0}; static struct i3s2ii21 x3 = {-1, 0, -1, 0}; static struct i3s2ii21 x4 = {-1, -1, -1, -1}; print_prologue("i3s2ii21", _Alignof(struct i3s2ii21), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2s9bi3 {
  short a:2;
  short b:9;
  _Bool c;
  int d:3;
};
static struct s2s9bi3 x1 = {-1, 0, 0, 0}; static struct s2s9bi3 x2 = {-1, -1, 0, 0}; static struct s2s9bi3 x3 = {-1, 0, -1, 0}; static struct s2s9bi3 x4 = {-1, -1, -1, -1}; print_prologue("s2s9bi3", _Alignof(struct s2s9bi3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i18c2b1i {
  int a:18;
  char b:2;
  _Bool c:1;
  int d;
};
static struct i18c2b1i x1 = {-1, 0, 0, 0}; static struct i18c2b1i x2 = {-1, -1, 0, 0}; static struct i18c2b1i x3 = {-1, 0, -1, 0}; static struct i18c2b1i x4 = {-1, -1, -1, -1}; print_prologue("i18c2b1i", _Alignof(struct i18c2b1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1c1s3b1 {
  _Bool a:1;
  char b:1;
  short c:3;
  _Bool d:1;
};
static struct b1c1s3b1 x1 = {-1, 0, 0, 0}; static struct b1c1s3b1 x2 = {-1, -1, 0, 0}; static struct b1c1s3b1 x3 = {-1, 0, -1, 0}; static struct b1c1s3b1 x4 = {-1, -1, -1, -1}; print_prologue("b1c1s3b1", _Alignof(struct b1c1s3b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iiI10I2b1s8 {
  int a;
  int b;
  int :10;
  int :2;
  _Bool c:1;
  short d:8;
};
static struct iiI10I2b1s8 x1 = {-1, 0, 0, 0}; static struct iiI10I2b1s8 x2 = {-1, -1, 0, 0}; static struct iiI10I2b1s8 x3 = {-1, 0, -1, 0}; static struct iiI10I2b1s8 x4 = {-1, -1, -1, -1}; print_prologue("iiI10I2b1s8", _Alignof(struct iiI10I2b1s8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s6I21s2ii14 {
  short a:6;
  int :21;
  short b:2;
  int c;
  int d:14;
};
static struct s6I21s2ii14 x1 = {-1, 0, 0, 0}; static struct s6I21s2ii14 x2 = {-1, -1, 0, 0}; static struct s6I21s2ii14 x3 = {-1, 0, -1, 0}; static struct s6I21s2ii14 x4 = {-1, -1, -1, -1}; print_prologue("s6I21s2ii14", _Alignof(struct s6I21s2ii14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5S1cs3c7 {
  char a:5;
  short :1;
  char b;
  short c:3;
  char d:7;
};
static struct c5S1cs3c7 x1 = {-1, 0, 0, 0}; static struct c5S1cs3c7 x2 = {-1, -1, 0, 0}; static struct c5S1cs3c7 x3 = {-1, 0, -1, 0}; static struct c5S1cs3c7 x4 = {-1, -1, -1, -1}; print_prologue("c5S1cs3c7", _Alignof(struct c5S1cs3c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iS0s6s9b1 {
  int a;
  short :0;
  short b:6;
  short c:9;
  _Bool d:1;
};
static struct iS0s6s9b1 x1 = {-1, 0, 0, 0}; static struct iS0s6s9b1 x2 = {-1, -1, 0, 0}; static struct iS0s6s9b1 x3 = {-1, 0, -1, 0}; static struct iS0s6s9b1 x4 = {-1, -1, -1, -1}; print_prologue("iS0s6s9b1", _Alignof(struct iS0s6s9b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2s5b1c3 {
  short a:2;
  short b:5;
  _Bool c:1;
  char d:3;
};
static struct s2s5b1c3 x1 = {-1, 0, 0, 0}; static struct s2s5b1c3 x2 = {-1, -1, 0, 0}; static struct s2s5b1c3 x3 = {-1, 0, -1, 0}; static struct s2s5b1c3 x4 = {-1, -1, -1, -1}; print_prologue("s2s5b1c3", _Alignof(struct s2s5b1c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i10c1c {
  _Bool a:1;
  int b:10;
  char c:1;
  char d;
};
static struct b1i10c1c x1 = {-1, 0, 0, 0}; static struct b1i10c1c x2 = {-1, -1, 0, 0}; static struct b1i10c1c x3 = {-1, 0, -1, 0}; static struct b1i10c1c x4 = {-1, -1, -1, -1}; print_prologue("b1i10c1c", _Alignof(struct b1i10c1c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4i11B1is {
  char a:4;
  int b:11;
  _Bool :1;
  int c;
  short d;
};
static struct c4i11B1is x1 = {-1, 0, 0, 0}; static struct c4i11B1is x2 = {-1, -1, 0, 0}; static struct c4i11B1is x3 = {-1, 0, -1, 0}; static struct c4i11B1is x4 = {-1, -1, -1, -1}; print_prologue("c4i11B1is", _Alignof(struct c4i11B1is), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct B0csbi1 {
  _Bool :0;
  char a;
  short b;
  _Bool c;
  int d:1;
};
static struct B0csbi1 x1 = {-1, 0, 0, 0}; static struct B0csbi1 x2 = {-1, -1, 0, 0}; static struct B0csbi1 x3 = {-1, 0, -1, 0}; static struct B0csbi1 x4 = {-1, -1, -1, -1}; print_prologue("B0csbi1", _Alignof(struct B0csbi1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct S3i1i13s1b {
  short :3;
  int a:1;
  int b:13;
  short c:1;
  _Bool d;
};
static struct S3i1i13s1b x1 = {-1, 0, 0, 0}; static struct S3i1i13s1b x2 = {-1, -1, 0, 0}; static struct S3i1i13s1b x3 = {-1, 0, -1, 0}; static struct S3i1i13s1b x4 = {-1, -1, -1, -1}; print_prologue("S3i1i13s1b", _Alignof(struct S3i1i13s1b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii2s7C1B0c1 {
  int a;
  int b:2;
  short c:7;
  char :1;
  _Bool :0;
  char d:1;
};
static struct ii2s7C1B0c1 x1 = {-1, 0, 0, 0}; static struct ii2s7C1B0c1 x2 = {-1, -1, 0, 0}; static struct ii2s7C1B0c1 x3 = {-1, 0, -1, 0}; static struct ii2s7C1B0c1 x4 = {-1, -1, -1, -1}; print_prologue("ii2s7C1B0c1", _Alignof(struct ii2s7C1B0c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i3i8i1I0i4 {
  int a:3;
  int b:8;
  int c:1;
  int :0;
  int d:4;
};
static struct i3i8i1I0i4 x1 = {-1, 0, 0, 0}; static struct i3i8i1I0i4 x2 = {-1, -1, 0, 0}; static struct i3i8i1I0i4 x3 = {-1, 0, -1, 0}; static struct i3i8i1I0i4 x4 = {-1, -1, -1, -1}; print_prologue("i3i8i1I0i4", _Alignof(struct i3i8i1I0i4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s3s5i1i1 {
  short a:3;
  short b:5;
  int c:1;
  int d:1;
};
static struct s3s5i1i1 x1 = {-1, 0, 0, 0}; static struct s3s5i1i1 x2 = {-1, -1, 0, 0}; static struct s3s5i1i1 x3 = {-1, 0, -1, 0}; static struct s3s5i1i1 x4 = {-1, -1, -1, -1}; print_prologue("s3s5i1i1", _Alignof(struct s3s5i1i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is7i1i2 {
  int a;
  short b:7;
  int c:1;
  int d:2;
};
static struct is7i1i2 x1 = {-1, 0, 0, 0}; static struct is7i1i2 x2 = {-1, -1, 0, 0}; static struct is7i1i2 x3 = {-1, 0, -1, 0}; static struct is7i1i2 x4 = {-1, -1, -1, -1}; print_prologue("is7i1i2", _Alignof(struct is7i1i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i14c7i7b1 {
  int a:14;
  char b:7;
  int c:7;
  _Bool d:1;
};
static struct i14c7i7b1 x1 = {-1, 0, 0, 0}; static struct i14c7i7b1 x2 = {-1, -1, 0, 0}; static struct i14c7i7b1 x3 = {-1, 0, -1, 0}; static struct i14c7i7b1 x4 = {-1, -1, -1, -1}; print_prologue("i14c7i7b1", _Alignof(struct i14c7i7b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c6bi7s16 {
  char a:6;
  _Bool b;
  int c:7;
  short d:16;
};
static struct c6bi7s16 x1 = {-1, 0, 0, 0}; static struct c6bi7s16 x2 = {-1, -1, 0, 0}; static struct c6bi7s16 x3 = {-1, 0, -1, 0}; static struct c6bi7s16 x4 = {-1, -1, -1, -1}; print_prologue("c6bi7s16", _Alignof(struct c6bi7s16), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1b1c2c {
  int a:1;
  _Bool b:1;
  char c:2;
  char d;
};
static struct i1b1c2c x1 = {-1, 0, 0, 0}; static struct i1b1c2c x2 = {-1, -1, 0, 0}; static struct i1b1c2c x3 = {-1, 0, -1, 0}; static struct i1b1c2c x4 = {-1, -1, -1, -1}; print_prologue("i1b1c2c", _Alignof(struct i1b1c2c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s15b1i1i14 {
  short a:15;
  _Bool b:1;
  int c:1;
  int d:14;
};
static struct s15b1i1i14 x1 = {-1, 0, 0, 0}; static struct s15b1i1i14 x2 = {-1, -1, 0, 0}; static struct s15b1i1i14 x3 = {-1, 0, -1, 0}; static struct s15b1i1i14 x4 = {-1, -1, -1, -1}; print_prologue("s15b1i1i14", _Alignof(struct s15b1i1i14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct B1I0i7is3b1 {
  _Bool :1;
  int :0;
  int a:7;
  int b;
  short c:3;
  _Bool d:1;
};
static struct B1I0i7is3b1 x1 = {-1, 0, 0, 0}; static struct B1I0i7is3b1 x2 = {-1, -1, 0, 0}; static struct B1I0i7is3b1 x3 = {-1, 0, -1, 0}; static struct B1I0i7is3b1 x4 = {-1, -1, -1, -1}; print_prologue("B1I0i7is3b1", _Alignof(struct B1I0i7is3b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i14b1cS0i5 {
  int a:14;
  _Bool b:1;
  char c;
  short :0;
  int d:5;
};
static struct i14b1cS0i5 x1 = {-1, 0, 0, 0}; static struct i14b1cS0i5 x2 = {-1, -1, 0, 0}; static struct i14b1cS0i5 x3 = {-1, 0, -1, 0}; static struct i14b1cS0i5 x4 = {-1, -1, -1, -1}; print_prologue("i14b1cS0i5", _Alignof(struct i14b1cS0i5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1c1c1i3 {
  short a:1;
  char b:1;
  char c:1;
  int d:3;
};
static struct s1c1c1i3 x1 = {-1, 0, 0, 0}; static struct s1c1c1i3 x2 = {-1, -1, 0, 0}; static struct s1c1c1i3 x3 = {-1, 0, -1, 0}; static struct s1c1c1i3 x4 = {-1, -1, -1, -1}; print_prologue("s1c1c1i3", _Alignof(struct s1c1c1i3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ic6s7S5c3 {
  int a;
  char b:6;
  short c:7;
  short :5;
  char d:3;
};
static struct ic6s7S5c3 x1 = {-1, 0, 0, 0}; static struct ic6s7S5c3 x2 = {-1, -1, 0, 0}; static struct ic6s7S5c3 x3 = {-1, 0, -1, 0}; static struct ic6s7S5c3 x4 = {-1, -1, -1, -1}; print_prologue("ic6s7S5c3", _Alignof(struct ic6s7S5c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i3b1i7 {
  _Bool a:1;
  int b:3;
  _Bool c:1;
  int d:7;
};
static struct b1i3b1i7 x1 = {-1, 0, 0, 0}; static struct b1i3b1i7 x2 = {-1, -1, 0, 0}; static struct b1i3b1i7 x3 = {-1, 0, -1, 0}; static struct b1i3b1i7 x4 = {-1, -1, -1, -1}; print_prologue("b1i3b1i7", _Alignof(struct b1i3b1i7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2s15i11c1 {
  int a:2;
  short b:15;
  int c:11;
  char d:1;
};
static struct i2s15i11c1 x1 = {-1, 0, 0, 0}; static struct i2s15i11c1 x2 = {-1, -1, 0, 0}; static struct i2s15i11c1 x3 = {-1, 0, -1, 0}; static struct i2s15i11c1 x4 = {-1, -1, -1, -1}; print_prologue("i2s15i11c1", _Alignof(struct i2s15i11c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct B1b1c2ic1 {
  _Bool :1;
  _Bool a:1;
  char b:2;
  int c;
  char d:1;
};
static struct B1b1c2ic1 x1 = {-1, 0, 0, 0}; static struct B1b1c2ic1 x2 = {-1, -1, 0, 0}; static struct B1b1c2ic1 x3 = {-1, 0, -1, 0}; static struct B1b1c2ic1 x4 = {-1, -1, -1, -1}; print_prologue("B1b1c2ic1", _Alignof(struct B1b1c2ic1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ccS0c5i2 {
  char a;
  char b;
  short :0;
  char c:5;
  int d:2;
};
static struct ccS0c5i2 x1 = {-1, 0, 0, 0}; static struct ccS0c5i2 x2 = {-1, -1, 0, 0}; static struct ccS0c5i2 x3 = {-1, 0, -1, 0}; static struct ccS0c5i2 x4 = {-1, -1, -1, -1}; print_prologue("ccS0c5i2", _Alignof(struct ccS0c5i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cb1i1I20s3 {
  char a;
  _Bool b:1;
  int c:1;
  int :20;
  short d:3;
};
static struct cb1i1I20s3 x1 = {-1, 0, 0, 0}; static struct cb1i1I20s3 x2 = {-1, -1, 0, 0}; static struct cb1i1I20s3 x3 = {-1, 0, -1, 0}; static struct cb1i1I20s3 x4 = {-1, -1, -1, -1}; print_prologue("cb1i1I20s3", _Alignof(struct cb1i1I20s3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5i2i14i1 {
  int a:5;
  int b:2;
  int c:14;
  int d:1;
};
static struct i5i2i14i1 x1 = {-1, 0, 0, 0}; static struct i5i2i14i1 x2 = {-1, -1, 0, 0}; static struct i5i2i14i1 x3 = {-1, 0, -1, 0}; static struct i5i2i14i1 x4 = {-1, -1, -1, -1}; print_prologue("i5i2i14i1", _Alignof(struct i5i2i14i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4C1ic8I14i7 {
  char a:4;
  char :1;
  int b;
  char c:8;
  int :14;
  int d:7;
};
static struct c4C1ic8I14i7 x1 = {-1, 0, 0, 0}; static struct c4C1ic8I14i7 x2 = {-1, -1, 0, 0}; static struct c4C1ic8I14i7 x3 = {-1, 0, -1, 0}; static struct c4C1ic8I14i7 x4 = {-1, -1, -1, -1}; print_prologue("c4C1ic8I14i7", _Alignof(struct c4C1ic8I14i7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1I28s1C4i31c3 {
  short a:1;
  int :28;
  short b:1;
  char :4;
  int c:31;
  char d:3;
};
static struct s1I28s1C4i31c3 x1 = {-1, 0, 0, 0}; static struct s1I28s1C4i31c3 x2 = {-1, -1, 0, 0}; static struct s1I28s1C4i31c3 x3 = {-1, 0, -1, 0}; static struct s1I28s1C4i31c3 x4 = {-1, -1, -1, -1}; print_prologue("s1I28s1C4i31c3", _Alignof(struct s1I28s1C4i31c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i12b1i2i {
  int a:12;
  _Bool b:1;
  int c:2;
  int d;
};
static struct i12b1i2i x1 = {-1, 0, 0, 0}; static struct i12b1i2i x2 = {-1, -1, 0, 0}; static struct i12b1i2i x3 = {-1, 0, -1, 0}; static struct i12b1i2i x4 = {-1, -1, -1, -1}; print_prologue("i12b1i2i", _Alignof(struct i12b1i2i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1s2si8 {
  _Bool a:1;
  short b:2;
  short c;
  int d:8;
};
static struct b1s2si8 x1 = {-1, 0, 0, 0}; static struct b1s2si8 x2 = {-1, -1, 0, 0}; static struct b1s2si8 x3 = {-1, 0, -1, 0}; static struct b1s2si8 x4 = {-1, -1, -1, -1}; print_prologue("b1s2si8", _Alignof(struct b1s2si8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i9i1i26b {
  int a:9;
  int b:1;
  int c:26;
  _Bool d;
};
static struct i9i1i26b x1 = {-1, 0, 0, 0}; static struct i9i1i26b x2 = {-1, -1, 0, 0}; static struct i9i1i26b x3 = {-1, 0, -1, 0}; static struct i9i1i26b x4 = {-1, -1, -1, -1}; print_prologue("i9i1i26b", _Alignof(struct i9i1i26b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c2i11c4c {
  char a:2;
  int b:11;
  char c:4;
  char d;
};
static struct c2i11c4c x1 = {-1, 0, 0, 0}; static struct c2i11c4c x2 = {-1, -1, 0, 0}; static struct c2i11c4c x3 = {-1, 0, -1, 0}; static struct c2i11c4c x4 = {-1, -1, -1, -1}; print_prologue("c2i11c4c", _Alignof(struct c2i11c4c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1i4s5i10 {
  int a:1;
  int b:4;
  short c:5;
  int d:10;
};
static struct i1i4s5i10 x1 = {-1, 0, 0, 0}; static struct i1i4s5i10 x2 = {-1, -1, 0, 0}; static struct i1i4s5i10 x3 = {-1, 0, -1, 0}; static struct i1i4s5i10 x4 = {-1, -1, -1, -1}; print_prologue("i1i4s5i10", _Alignof(struct i1i4s5i10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1i9c4 {
  int a;
  _Bool b:1;
  int c:9;
  char d:4;
};
static struct ib1i9c4 x1 = {-1, 0, 0, 0}; static struct ib1i9c4 x2 = {-1, -1, 0, 0}; static struct ib1i9c4 x3 = {-1, 0, -1, 0}; static struct ib1i9c4 x4 = {-1, -1, -1, -1}; print_prologue("ib1i9c4", _Alignof(struct ib1i9c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i20s4s4b1 {
  int a:20;
  short b:4;
  short c:4;
  _Bool d:1;
};
static struct i20s4s4b1 x1 = {-1, 0, 0, 0}; static struct i20s4s4b1 x2 = {-1, -1, 0, 0}; static struct i20s4s4b1 x3 = {-1, 0, -1, 0}; static struct i20s4s4b1 x4 = {-1, -1, -1, -1}; print_prologue("i20s4s4b1", _Alignof(struct i20s4s4b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii13I15b1c3 {
  int a;
  int b:13;
  int :15;
  _Bool c:1;
  char d:3;
};
static struct ii13I15b1c3 x1 = {-1, 0, 0, 0}; static struct ii13I15b1c3 x2 = {-1, -1, 0, 0}; static struct ii13I15b1c3 x3 = {-1, 0, -1, 0}; static struct ii13I15b1c3 x4 = {-1, -1, -1, -1}; print_prologue("ii13I15b1c3", _Alignof(struct ii13I15b1c3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct isi7s4 {
  int a;
  short b;
  int c:7;
  short d:4;
};
static struct isi7s4 x1 = {-1, 0, 0, 0}; static struct isi7s4 x2 = {-1, -1, 0, 0}; static struct isi7s4 x3 = {-1, 0, -1, 0}; static struct isi7s4 x4 = {-1, -1, -1, -1}; print_prologue("isi7s4", _Alignof(struct isi7s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I0i22i14ic {
  int :0;
  int a:22;
  int b:14;
  int c;
  char d;
};
static struct I0i22i14ic x1 = {-1, 0, 0, 0}; static struct I0i22i14ic x2 = {-1, -1, 0, 0}; static struct I0i22i14ic x3 = {-1, 0, -1, 0}; static struct I0i22i14ic x4 = {-1, -1, -1, -1}; print_prologue("I0i22i14ic", _Alignof(struct I0i22i14ic), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2i2c7i10 {
  int a:2;
  int b:2;
  char c:7;
  int d:10;
};
static struct i2i2c7i10 x1 = {-1, 0, 0, 0}; static struct i2i2c7i10 x2 = {-1, -1, 0, 0}; static struct i2i2c7i10 x3 = {-1, 0, -1, 0}; static struct i2i2c7i10 x4 = {-1, -1, -1, -1}; print_prologue("i2i2c7i10", _Alignof(struct i2i2c7i10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct si1b1s14 {
  short a;
  int b:1;
  _Bool c:1;
  short d:14;
};
static struct si1b1s14 x1 = {-1, 0, 0, 0}; static struct si1b1s14 x2 = {-1, -1, 0, 0}; static struct si1b1s14 x3 = {-1, 0, -1, 0}; static struct si1b1s14 x4 = {-1, -1, -1, -1}; print_prologue("si1b1s14", _Alignof(struct si1b1s14), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s12i26c7i10 {
  short a:12;
  int b:26;
  char c:7;
  int d:10;
};
static struct s12i26c7i10 x1 = {-1, 0, 0, 0}; static struct s12i26c7i10 x2 = {-1, -1, 0, 0}; static struct s12i26c7i10 x3 = {-1, 0, -1, 0}; static struct s12i26c7i10 x4 = {-1, -1, -1, -1}; print_prologue("s12i26c7i10", _Alignof(struct s12i26c7i10), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2i25i10c8 {
  short a:2;
  int b:25;
  int c:10;
  char d:8;
};
static struct s2i25i10c8 x1 = {-1, 0, 0, 0}; static struct s2i25i10c8 x2 = {-1, -1, 0, 0}; static struct s2i25i10c8 x3 = {-1, 0, -1, 0}; static struct s2i25i10c8 x4 = {-1, -1, -1, -1}; print_prologue("s2i25i10c8", _Alignof(struct s2i25i10c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i13c1i6b {
  int a:13;
  char b:1;
  int c:6;
  _Bool d;
};
static struct i13c1i6b x1 = {-1, 0, 0, 0}; static struct i13c1i6b x2 = {-1, -1, 0, 0}; static struct i13c1i6b x3 = {-1, 0, -1, 0}; static struct i13c1i6b x4 = {-1, -1, -1, -1}; print_prologue("i13c1i6b", _Alignof(struct i13c1i6b), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C3i3i28s2i27 {
  char :3;
  int a:3;
  int b:28;
  short c:2;
  int d:27;
};
static struct C3i3i28s2i27 x1 = {-1, 0, 0, 0}; static struct C3i3i28s2i27 x2 = {-1, -1, 0, 0}; static struct C3i3i28s2i27 x3 = {-1, 0, -1, 0}; static struct C3i3i28s2i27 x4 = {-1, -1, -1, -1}; print_prologue("C3i3i28s2i27", _Alignof(struct C3i3i28s2i27), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2ib1i {
  int a:2;
  int b;
  _Bool c:1;
  int d;
};
static struct i2ib1i x1 = {-1, 0, 0, 0}; static struct i2ib1i x2 = {-1, -1, 0, 0}; static struct i2ib1i x3 = {-1, 0, -1, 0}; static struct i2ib1i x4 = {-1, -1, -1, -1}; print_prologue("i2ib1i", _Alignof(struct i2ib1i), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1bi8i8 {
  char a:1;
  _Bool b;
  int c:8;
  int d:8;
};
static struct c1bi8i8 x1 = {-1, 0, 0, 0}; static struct c1bi8i8 x2 = {-1, -1, 0, 0}; static struct c1bi8i8 x3 = {-1, 0, -1, 0}; static struct c1bi8i8 x4 = {-1, -1, -1, -1}; print_prologue("c1bi8i8", _Alignof(struct c1bi8i8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i11i1i6c4 {
  int a:11;
  int b:1;
  int c:6;
  char d:4;
};
static struct i11i1i6c4 x1 = {-1, 0, 0, 0}; static struct i11i1i6c4 x2 = {-1, -1, 0, 0}; static struct i11i1i6c4 x3 = {-1, 0, -1, 0}; static struct i11i1i6c4 x4 = {-1, -1, -1, -1}; print_prologue("i11i1i6c4", _Alignof(struct i11i1i6c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c8c2i21c2 {
  char a:8;
  char b:2;
  int c:21;
  char d:2;
};
static struct c8c2i21c2 x1 = {-1, 0, 0, 0}; static struct c8c2i21c2 x2 = {-1, -1, 0, 0}; static struct c8c2i21c2 x3 = {-1, 0, -1, 0}; static struct c8c2i21c2 x4 = {-1, -1, -1, -1}; print_prologue("c8c2i21c2", _Alignof(struct c8c2i21c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cb1c6s9 {
  char a;
  _Bool b:1;
  char c:6;
  short d:9;
};
static struct cb1c6s9 x1 = {-1, 0, 0, 0}; static struct cb1c6s9 x2 = {-1, -1, 0, 0}; static struct cb1c6s9 x3 = {-1, 0, -1, 0}; static struct cb1c6s9 x4 = {-1, -1, -1, -1}; print_prologue("cb1c6s9", _Alignof(struct cb1c6s9), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s13sii22 {
  short a:13;
  short b;
  int c;
  int d:22;
};
static struct s13sii22 x1 = {-1, 0, 0, 0}; static struct s13sii22 x2 = {-1, -1, 0, 0}; static struct s13sii22 x3 = {-1, 0, -1, 0}; static struct s13sii22 x4 = {-1, -1, -1, -1}; print_prologue("s13sii22", _Alignof(struct s13sii22), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s10i10ii1 {
  short a:10;
  int b:10;
  int c;
  int d:1;
};
static struct s10i10ii1 x1 = {-1, 0, 0, 0}; static struct s10i10ii1 x2 = {-1, -1, 0, 0}; static struct s10i10ii1 x3 = {-1, 0, -1, 0}; static struct s10i10ii1 x4 = {-1, -1, -1, -1}; print_prologue("s10i10ii1", _Alignof(struct s10i10ii1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s1s16cs {
  short a:1;
  short b:16;
  char c;
  short d;
};
static struct s1s16cs x1 = {-1, 0, 0, 0}; static struct s1s16cs x2 = {-1, -1, 0, 0}; static struct s1s16cs x3 = {-1, 0, -1, 0}; static struct s1s16cs x4 = {-1, -1, -1, -1}; print_prologue("s1s16cs", _Alignof(struct s1s16cs), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i9I31i24ic4 {
  int a:9;
  int :31;
  int b:24;
  int c;
  char d:4;
};
static struct i9I31i24ic4 x1 = {-1, 0, 0, 0}; static struct i9I31i24ic4 x2 = {-1, -1, 0, 0}; static struct i9I31i24ic4 x3 = {-1, 0, -1, 0}; static struct i9I31i24ic4 x4 = {-1, -1, -1, -1}; print_prologue("i9I31i24ic4", _Alignof(struct i9I31i24ic4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ii2s8b1 {
  int a;
  int b:2;
  short c:8;
  _Bool d:1;
};
static struct ii2s8b1 x1 = {-1, 0, 0, 0}; static struct ii2s8b1 x2 = {-1, -1, 0, 0}; static struct ii2s8b1 x3 = {-1, 0, -1, 0}; static struct ii2s8b1 x4 = {-1, -1, -1, -1}; print_prologue("ii2s8b1", _Alignof(struct ii2s8b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i26c3sb {
  int a:26;
  char b:3;
  short c;
  _Bool d;
};
static struct i26c3sb x1 = {-1, 0, 0, 0}; static struct i26c3sb x2 = {-1, -1, 0, 0}; static struct i26c3sb x3 = {-1, 0, -1, 0}; static struct i26c3sb x4 = {-1, -1, -1, -1}; print_prologue("i26c3sb", _Alignof(struct i26c3sb), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i13C3cs14c {
  int a:13;
  char :3;
  char b;
  short c:14;
  char d;
};
static struct i13C3cs14c x1 = {-1, 0, 0, 0}; static struct i13C3cs14c x2 = {-1, -1, 0, 0}; static struct i13C3cs14c x3 = {-1, 0, -1, 0}; static struct i13C3cs14c x4 = {-1, -1, -1, -1}; print_prologue("i13C3cs14c", _Alignof(struct i13C3cs14c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct cs2i23s {
  char a;
  short b:2;
  int c:23;
  short d;
};
static struct cs2i23s x1 = {-1, 0, 0, 0}; static struct cs2i23s x2 = {-1, -1, 0, 0}; static struct cs2i23s x3 = {-1, 0, -1, 0}; static struct cs2i23s x4 = {-1, -1, -1, -1}; print_prologue("cs2i23s", _Alignof(struct cs2i23s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3ii2s15 {
  char a:3;
  int b;
  int c:2;
  short d:15;
};
static struct c3ii2s15 x1 = {-1, 0, 0, 0}; static struct c3ii2s15 x2 = {-1, -1, 0, 0}; static struct c3ii2s15 x3 = {-1, 0, -1, 0}; static struct c3ii2s15 x4 = {-1, -1, -1, -1}; print_prologue("c3ii2s15", _Alignof(struct c3ii2s15), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5i2S4S0i2i31 {
  char a:5;
  int b:2;
  short :4;
  short :0;
  int c:2;
  int d:31;
};
static struct c5i2S4S0i2i31 x1 = {-1, 0, 0, 0}; static struct c5i2S4S0i2i31 x2 = {-1, -1, 0, 0}; static struct c5i2S4S0i2i31 x3 = {-1, 0, -1, 0}; static struct c5i2S4S0i2i31 x4 = {-1, -1, -1, -1}; print_prologue("c5i2S4S0i2i31", _Alignof(struct c5i2S4S0i2i31), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i24bs2 {
  _Bool a:1;
  int b:24;
  _Bool c;
  short d:2;
};
static struct b1i24bs2 x1 = {-1, 0, 0, 0}; static struct b1i24bs2 x2 = {-1, -1, 0, 0}; static struct b1i24bs2 x3 = {-1, 0, -1, 0}; static struct b1i24bs2 x4 = {-1, -1, -1, -1}; print_prologue("b1i24bs2", _Alignof(struct b1i24bs2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i6i20c8s2 {
  int a:6;
  int b:20;
  char c:8;
  short d:2;
};
static struct i6i20c8s2 x1 = {-1, 0, 0, 0}; static struct i6i20c8s2 x2 = {-1, -1, 0, 0}; static struct i6i20c8s2 x3 = {-1, 0, -1, 0}; static struct i6i20c8s2 x4 = {-1, -1, -1, -1}; print_prologue("i6i20c8s2", _Alignof(struct i6i20c8s2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ss2i19i8 {
  short a;
  short b:2;
  int c:19;
  int d:8;
};
static struct ss2i19i8 x1 = {-1, 0, 0, 0}; static struct ss2i19i8 x2 = {-1, -1, 0, 0}; static struct ss2i19i8 x3 = {-1, 0, -1, 0}; static struct ss2i19i8 x4 = {-1, -1, -1, -1}; print_prologue("ss2i19i8", _Alignof(struct ss2i19i8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2i4bc4 {
  int a:2;
  int b:4;
  _Bool c;
  char d:4;
};
static struct i2i4bc4 x1 = {-1, 0, 0, 0}; static struct i2i4bc4 x2 = {-1, -1, 0, 0}; static struct i2i4bc4 x3 = {-1, 0, -1, 0}; static struct i2i4bc4 x4 = {-1, -1, -1, -1}; print_prologue("i2i4bc4", _Alignof(struct i2i4bc4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1i27s {
  int a;
  _Bool b:1;
  int c:27;
  short d;
};
static struct ib1i27s x1 = {-1, 0, 0, 0}; static struct ib1i27s x2 = {-1, -1, 0, 0}; static struct ib1i27s x3 = {-1, 0, -1, 0}; static struct ib1i27s x4 = {-1, -1, -1, -1}; print_prologue("ib1i27s", _Alignof(struct ib1i27s), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct I3i29s1c6i21 {
  int :3;
  int a:29;
  short b:1;
  char c:6;
  int d:21;
};
static struct I3i29s1c6i21 x1 = {-1, 0, 0, 0}; static struct I3i29s1c6i21 x2 = {-1, -1, 0, 0}; static struct I3i29s1c6i21 x3 = {-1, 0, -1, 0}; static struct I3i29s1c6i21 x4 = {-1, -1, -1, -1}; print_prologue("I3i29s1c6i21", _Alignof(struct I3i29s1c6i21), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i14isi2 {
  int a:14;
  int b;
  short c;
  int d:2;
};
static struct i14isi2 x1 = {-1, 0, 0, 0}; static struct i14isi2 x2 = {-1, -1, 0, 0}; static struct i14isi2 x3 = {-1, 0, -1, 0}; static struct i14isi2 x4 = {-1, -1, -1, -1}; print_prologue("i14isi2", _Alignof(struct i14isi2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i29iS10sS0c7 {
  int a:29;
  int b;
  short :10;
  short c;
  short :0;
  char d:7;
};
static struct i29iS10sS0c7 x1 = {-1, 0, 0, 0}; static struct i29iS10sS0c7 x2 = {-1, -1, 0, 0}; static struct i29iS10sS0c7 x3 = {-1, 0, -1, 0}; static struct i29iS10sS0c7 x4 = {-1, -1, -1, -1}; print_prologue("i29iS10sS0c7", _Alignof(struct i29iS10sS0c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1i1s4i1 {
  char a:1;
  int b:1;
  short c:4;
  int d:1;
};
static struct c1i1s4i1 x1 = {-1, 0, 0, 0}; static struct c1i1s4i1 x2 = {-1, -1, 0, 0}; static struct c1i1s4i1 x3 = {-1, 0, -1, 0}; static struct c1i1s4i1 x4 = {-1, -1, -1, -1}; print_prologue("c1i1s4i1", _Alignof(struct c1i1s4i1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c1s6c4c {
  char a:1;
  short b:6;
  char c:4;
  char d;
};
static struct c1s6c4c x1 = {-1, 0, 0, 0}; static struct c1s6c4c x2 = {-1, -1, 0, 0}; static struct c1s6c4c x3 = {-1, 0, -1, 0}; static struct c1s6c4c x4 = {-1, -1, -1, -1}; print_prologue("c1s6c4c", _Alignof(struct c1s6c4c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iii14c {
  int a;
  int b;
  int c:14;
  char d;
};
static struct iii14c x1 = {-1, 0, 0, 0}; static struct iii14c x2 = {-1, -1, 0, 0}; static struct iii14c x3 = {-1, 0, -1, 0}; static struct iii14c x4 = {-1, -1, -1, -1}; print_prologue("iii14c", _Alignof(struct iii14c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s8cs7s2 {
  short a:8;
  char b;
  short c:7;
  short d:2;
};
static struct s8cs7s2 x1 = {-1, 0, 0, 0}; static struct s8cs7s2 x2 = {-1, -1, 0, 0}; static struct s8cs7s2 x3 = {-1, 0, -1, 0}; static struct s8cs7s2 x4 = {-1, -1, -1, -1}; print_prologue("s8cs7s2", _Alignof(struct s8cs7s2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i1b1c2c1 {
  int a:1;
  _Bool b:1;
  char c:2;
  char d:1;
};
static struct i1b1c2c1 x1 = {-1, 0, 0, 0}; static struct i1b1c2c1 x2 = {-1, -1, 0, 0}; static struct i1b1c2c1 x3 = {-1, 0, -1, 0}; static struct i1b1c2c1 x4 = {-1, -1, -1, -1}; print_prologue("i1b1c2c1", _Alignof(struct i1b1c2c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s13b1bi12 {
  short a:13;
  _Bool b:1;
  _Bool c;
  int d:12;
};
static struct s13b1bi12 x1 = {-1, 0, 0, 0}; static struct s13b1bi12 x2 = {-1, -1, 0, 0}; static struct s13b1bi12 x3 = {-1, 0, -1, 0}; static struct s13b1bi12 x4 = {-1, -1, -1, -1}; print_prologue("s13b1bi12", _Alignof(struct s13b1bi12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i12i5c5s8 {
  int a:12;
  int b:5;
  char c:5;
  short d:8;
};
static struct i12i5c5s8 x1 = {-1, 0, 0, 0}; static struct i12i5c5s8 x2 = {-1, -1, 0, 0}; static struct i12i5c5s8 x3 = {-1, 0, -1, 0}; static struct i12i5c5s8 x4 = {-1, -1, -1, -1}; print_prologue("i12i5c5s8", _Alignof(struct i12i5c5s8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3ib1i17 {
  char a:3;
  int b;
  _Bool c:1;
  int d:17;
};
static struct c3ib1i17 x1 = {-1, 0, 0, 0}; static struct c3ib1i17 x2 = {-1, -1, 0, 0}; static struct c3ib1i17 x3 = {-1, 0, -1, 0}; static struct c3ib1i17 x4 = {-1, -1, -1, -1}; print_prologue("c3ib1i17", _Alignof(struct c3ib1i17), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct C0S6s3B1s13i1s3 {
  char :0;
  short :6;
  short a:3;
  _Bool :1;
  short b:13;
  int c:1;
  short d:3;
};
static struct C0S6s3B1s13i1s3 x1 = {-1, 0, 0, 0}; static struct C0S6s3B1s13i1s3 x2 = {-1, -1, 0, 0}; static struct C0S6s3B1s13i1s3 x3 = {-1, 0, -1, 0}; static struct C0S6s3B1s13i1s3 x4 = {-1, -1, -1, -1}; print_prologue("C0S6s3B1s13i1s3", _Alignof(struct C0S6s3B1s13i1s3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2b1c3c8 {
  int a:2;
  _Bool b:1;
  char c:3;
  char d:8;
};
static struct i2b1c3c8 x1 = {-1, 0, 0, 0}; static struct i2b1c3c8 x2 = {-1, -1, 0, 0}; static struct i2b1c3c8 x3 = {-1, 0, -1, 0}; static struct i2b1c3c8 x4 = {-1, -1, -1, -1}; print_prologue("i2b1c3c8", _Alignof(struct i2b1c3c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct bC0i11s10s12 {
  _Bool a;
  char :0;
  int b:11;
  short c:10;
  short d:12;
};
static struct bC0i11s10s12 x1 = {-1, 0, 0, 0}; static struct bC0i11s10s12 x2 = {-1, -1, 0, 0}; static struct bC0i11s10s12 x3 = {-1, 0, -1, 0}; static struct bC0i11s10s12 x4 = {-1, -1, -1, -1}; print_prologue("bC0i11s10s12", _Alignof(struct bC0i11s10s12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s12bis3 {
  short a:12;
  _Bool b;
  int c;
  short d:3;
};
static struct s12bis3 x1 = {-1, 0, 0, 0}; static struct s12bis3 x2 = {-1, -1, 0, 0}; static struct s12bis3 x3 = {-1, 0, -1, 0}; static struct s12bis3 x4 = {-1, -1, -1, -1}; print_prologue("s12bis3", _Alignof(struct s12bis3), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c5ci13c8 {
  char a:5;
  char b;
  int c:13;
  char d:8;
};
static struct c5ci13c8 x1 = {-1, 0, 0, 0}; static struct c5ci13c8 x2 = {-1, -1, 0, 0}; static struct c5ci13c8 x3 = {-1, 0, -1, 0}; static struct c5ci13c8 x4 = {-1, -1, -1, -1}; print_prologue("c5ci13c8", _Alignof(struct c5ci13c8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4s8ii {
  char a:4;
  short b:8;
  int c;
  int d;
};
static struct c4s8ii x1 = {-1, 0, 0, 0}; static struct c4s8ii x2 = {-1, -1, 0, 0}; static struct c4s8ii x3 = {-1, 0, -1, 0}; static struct c4s8ii x4 = {-1, -1, -1, -1}; print_prologue("c4s8ii", _Alignof(struct c4s8ii), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i2i10s5s4 {
  int a:2;
  int b:10;
  short c:5;
  short d:4;
};
static struct i2i10s5s4 x1 = {-1, 0, 0, 0}; static struct i2i10s5s4 x2 = {-1, -1, 0, 0}; static struct i2i10s5s4 x3 = {-1, 0, -1, 0}; static struct i2i10s5s4 x4 = {-1, -1, -1, -1}; print_prologue("i2i10s5s4", _Alignof(struct i2i10s5s4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c3c6b1c {
  char a:3;
  char b:6;
  _Bool c:1;
  char d;
};
static struct c3c6b1c x1 = {-1, 0, 0, 0}; static struct c3c6b1c x2 = {-1, -1, 0, 0}; static struct c3c6b1c x3 = {-1, 0, -1, 0}; static struct c3c6b1c x4 = {-1, -1, -1, -1}; print_prologue("c3c6b1c", _Alignof(struct c3c6b1c), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1i2c2 {
  int a;
  _Bool b:1;
  int c:2;
  char d:2;
};
static struct ib1i2c2 x1 = {-1, 0, 0, 0}; static struct ib1i2c2 x2 = {-1, -1, 0, 0}; static struct ib1i2c2 x3 = {-1, 0, -1, 0}; static struct ib1i2c2 x4 = {-1, -1, -1, -1}; print_prologue("ib1i2c2", _Alignof(struct ib1i2c2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct ib1S0s3i32 {
  int a;
  _Bool b:1;
  short :0;
  short c:3;
  int d:32;
};
static struct ib1S0s3i32 x1 = {-1, 0, 0, 0}; static struct ib1S0s3i32 x2 = {-1, -1, 0, 0}; static struct ib1S0s3i32 x3 = {-1, 0, -1, 0}; static struct ib1S0s3i32 x4 = {-1, -1, -1, -1}; print_prologue("ib1S0s3i32", _Alignof(struct ib1S0s3i32), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct iss1i8 {
  int a;
  short b;
  short c:1;
  int d:8;
};
static struct iss1i8 x1 = {-1, 0, 0, 0}; static struct iss1i8 x2 = {-1, -1, 0, 0}; static struct iss1i8 x3 = {-1, 0, -1, 0}; static struct iss1i8 x4 = {-1, -1, -1, -1}; print_prologue("iss1i8", _Alignof(struct iss1i8), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i6i6b1i7 {
  int a:6;
  int b:6;
  _Bool c:1;
  int d:7;
};
static struct i6i6b1i7 x1 = {-1, 0, 0, 0}; static struct i6i6b1i7 x2 = {-1, -1, 0, 0}; static struct i6i6b1i7 x3 = {-1, 0, -1, 0}; static struct i6i6b1i7 x4 = {-1, -1, -1, -1}; print_prologue("i6i6b1i7", _Alignof(struct i6i6b1i7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i11s9b1i12 {
  int a:11;
  short b:9;
  _Bool c:1;
  int d:12;
};
static struct i11s9b1i12 x1 = {-1, 0, 0, 0}; static struct i11s9b1i12 x2 = {-1, -1, 0, 0}; static struct i11s9b1i12 x3 = {-1, 0, -1, 0}; static struct i11s9b1i12 x4 = {-1, -1, -1, -1}; print_prologue("i11s9b1i12", _Alignof(struct i11s9b1i12), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4i3is5 {
  short a:4;
  int b:3;
  int c;
  short d:5;
};
static struct s4i3is5 x1 = {-1, 0, 0, 0}; static struct s4i3is5 x2 = {-1, -1, 0, 0}; static struct s4i3is5 x3 = {-1, 0, -1, 0}; static struct s4i3is5 x4 = {-1, -1, -1, -1}; print_prologue("s4i3is5", _Alignof(struct s4i3is5), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct c4i2s6b1 {
  char a:4;
  int b:2;
  short c:6;
  _Bool d:1;
};
static struct c4i2s6b1 x1 = {-1, 0, 0, 0}; static struct c4i2s6b1 x2 = {-1, -1, 0, 0}; static struct c4i2s6b1 x3 = {-1, 0, -1, 0}; static struct c4i2s6b1 x4 = {-1, -1, -1, -1}; print_prologue("c4i2s6b1", _Alignof(struct c4i2s6b1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s2I4c6c2c7 {
  short a:2;
  int :4;
  char b:6;
  char c:2;
  char d:7;
};
static struct s2I4c6c2c7 x1 = {-1, 0, 0, 0}; static struct s2I4c6c2c7 x2 = {-1, -1, 0, 0}; static struct s2I4c6c2c7 x3 = {-1, 0, -1, 0}; static struct s2I4c6c2c7 x4 = {-1, -1, -1, -1}; print_prologue("s2I4c6c2c7", _Alignof(struct s2I4c6c2c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct is15c6C0c1 {
  int a;
  short b:15;
  char c:6;
  char :0;
  char d:1;
};
static struct is15c6C0c1 x1 = {-1, 0, 0, 0}; static struct is15c6C0c1 x2 = {-1, -1, 0, 0}; static struct is15c6C0c1 x3 = {-1, 0, -1, 0}; static struct is15c6C0c1 x4 = {-1, -1, -1, -1}; print_prologue("is15c6C0c1", _Alignof(struct is15c6C0c1), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct i5s2b1c7 {
  int a:5;
  short b:2;
  _Bool c:1;
  char d:7;
};
static struct i5s2b1c7 x1 = {-1, 0, 0, 0}; static struct i5s2b1c7 x2 = {-1, -1, 0, 0}; static struct i5s2b1c7 x3 = {-1, 0, -1, 0}; static struct i5s2b1c7 x4 = {-1, -1, -1, -1}; print_prologue("i5s2b1c7", _Alignof(struct i5s2b1c7), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct s4s8c8c4 {
  short a:4;
  short b:8;
  char c:8;
  char d:4;
};
static struct s4s8c8c4 x1 = {-1, 0, 0, 0}; static struct s4s8c8c4 x2 = {-1, -1, 0, 0}; static struct s4s8c8c4 x3 = {-1, 0, -1, 0}; static struct s4s8c8c4 x4 = {-1, -1, -1, -1}; print_prologue("s4s8c8c4", _Alignof(struct s4s8c8c4), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
{
struct b1i20c1i2 {
  _Bool a:1;
  int b:20;
  char c:1;
  int d:2;
};
static struct b1i20c1i2 x1 = {-1, 0, 0, 0}; static struct b1i20c1i2 x2 = {-1, -1, 0, 0}; static struct b1i20c1i2 x3 = {-1, 0, -1, 0}; static struct b1i20c1i2 x4 = {-1, -1, -1, -1}; print_prologue("b1i20c1i2", _Alignof(struct b1i20c1i2), sizeof(x1)); print_contents(sizeof(x1), &x1); print_contents(sizeof(x2), &x2); print_contents(sizeof(x3), &x3); print_contents(sizeof(x4), &x4); print_epilogue();
}
# 75 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/staticlayout/lean/abi/staticlayout.c" 2
  return 0;
}
