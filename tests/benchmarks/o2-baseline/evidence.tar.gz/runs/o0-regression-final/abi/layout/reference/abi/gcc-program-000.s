	.file	"layout.c"
	.text
	.type	bit, @function
bit:
.LFB6:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -24(%rbp)
	movl	%esi, -28(%rbp)
	movl	-28(%rbp), %eax
	shrl	$3, %eax
	movl	%eax, -8(%rbp)
	movl	-28(%rbp), %eax
	andl	$7, %eax
	movl	%eax, -4(%rbp)
	movl	-8(%rbp), %edx
	movq	-24(%rbp), %rax
	addq	%rdx, %rax
	movzbl	(%rax), %eax
	movzbl	%al, %edx
	movl	-4(%rbp), %eax
	movl	%eax, %ecx
	sarl	%cl, %edx
	movl	%edx, %eax
	andl	$1, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	bit, .-bit
	.section	.rodata
	.align 8
.LC0:
	.string	"%s: align %d, sizeof %d, layout"
	.text
	.globl	print_prologue
	.type	print_prologue, @function
print_prologue:
.LFB7:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-24(%rbp), %rax
	movl	%eax, %ecx
	movq	-16(%rbp), %rax
	movl	%eax, %edx
	movq	-8(%rbp), %rax
	movq	%rax, %rsi
	movl	$.LC0, %edi
	movl	$0, %eax
	call	printf
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	print_prologue, .-print_prologue
	.section	.rodata
	.align 8
.LC1:
	.string	"/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/layout/reference/abi/layout.c"
.LC2:
	.string	"pos < 8 * sz"
.LC3:
	.string	" %u"
	.text
	.globl	print_next_field
	.type	print_next_field, @function
print_next_field:
.LFB8:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movl	%edi, %eax
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movb	%al, -4(%rbp)
	cmpb	$0, -4(%rbp)
	je	.L9
	movl	$0, pos.1(%rip)
.L9:
	movl	pos.1(%rip), %eax
	movl	%eax, %edx
	movq	-16(%rbp), %rax
	salq	$3, %rax
	cmpq	%rax, %rdx
	jb	.L6
	movl	$__PRETTY_FUNCTION__.0, %ecx
	movl	$30, %edx
	movl	$.LC1, %esi
	movl	$.LC2, %edi
	call	__assert_fail
.L6:
	movl	pos.1(%rip), %edx
	movq	-24(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	bit
	testl	%eax, %eax
	jne	.L14
	movl	pos.1(%rip), %eax
	addl	$1, %eax
	movl	%eax, pos.1(%rip)
	jmp	.L9
.L14:
	nop
	movl	pos.1(%rip), %eax
	movl	%eax, %esi
	movl	$.LC3, %edi
	movl	$0, %eax
	call	printf
	jmp	.L10
.L12:
	movl	pos.1(%rip), %eax
	addl	$1, %eax
	movl	%eax, pos.1(%rip)
.L10:
	movl	pos.1(%rip), %eax
	movl	%eax, %edx
	movq	-16(%rbp), %rax
	salq	$3, %rax
	cmpq	%rax, %rdx
	jnb	.L15
	movl	pos.1(%rip), %edx
	movq	-24(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	bit
	testl	%eax, %eax
	jne	.L12
.L15:
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	print_next_field, .-print_next_field
	.globl	print_epilogue
	.type	print_epilogue, @function
print_epilogue:
.LFB9:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movl	$10, %edi
	call	putchar
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	print_epilogue, .-print_epilogue
	.section	.rodata
.LC4:
	.string	"i12s4ci4"
.LC5:
	.string	"i31i15ii5"
.LC6:
	.string	"i7sii12"
.LC7:
	.string	"c1c2i20s7"
.LC8:
	.string	"ii1ii1"
.LC9:
	.string	"c7i1c3i"
.LC10:
	.string	"s2bi11i"
.LC11:
	.string	"s7i30s5i3"
.LC12:
	.string	"c1s12b1i1"
.LC13:
	.string	"i15is10i15"
.LC14:
	.string	"is1i1s1"
.LC15:
	.string	"i15i10s10c2"
.LC16:
	.string	"I31i4b1i9B1s"
.LC17:
	.string	"c5i6i2i14"
.LC18:
	.string	"i13b1c6s6"
.LC19:
	.string	"b1B1c3i5b"
.LC20:
	.string	"si9i21s2"
.LC21:
	.string	"S0csc2c1"
.LC22:
	.string	"i2I2b1b1i1"
.LC23:
	.string	"c2ii2b"
.LC24:
	.string	"s2s5cc"
.LC25:
	.string	"C2I14b1i2ib"
.LC26:
	.string	"b1i27s7i4"
.LC27:
	.string	"cis6i15"
.LC28:
	.string	"s4i7c6c4"
.LC29:
	.string	"i19sc4i22"
.LC30:
	.string	"b1sc4s5"
.LC31:
	.string	"c4b1ii2"
.LC32:
	.string	"ciic1"
.LC33:
	.string	"i28b1c4c8"
.LC34:
	.string	"c1s4ci1"
.LC35:
	.string	"sb1b1s5"
.LC36:
	.string	"i13i2I16b1s9"
.LC37:
	.string	"ib1c5i"
.LC38:
	.string	"s2i1b1i8"
.LC39:
	.string	"c2s6is5"
.LC40:
	.string	"i19ci5c1"
.LC41:
	.string	"s3c1S10c5i5"
.LC42:
	.string	"sI0S2s13c3i18"
.LC43:
	.string	"c1bic8"
.LC44:
	.string	"s8I9b1c1S0i6"
.LC45:
	.string	"I12ss12s8i"
.LC46:
	.string	"ci1b1c1"
.LC47:
	.string	"c4i3i7i17"
.LC48:
	.string	"C8icii23"
.LC49:
	.string	"s14S4i2si2"
.LC50:
	.string	"s4ici2"
.LC51:
	.string	"s1s5b1s"
.LC52:
	.string	"c7c1C1i25c8"
.LC53:
	.string	"s8i28c3s12"
.LC54:
	.string	"c4i1s2i"
.LC55:
	.string	"s5C0s2bb1"
.LC56:
	.string	"i30I0B1si14c5"
.LC57:
	.string	"c1C4is1s13"
.LC58:
	.string	"s8c6ic1"
.LC59:
	.string	"i29i1s3I0i1"
.LC60:
	.string	"c8c4s3i8"
.LC61:
	.string	"c2i12ic4"
.LC62:
	.string	"is2s12c4"
.LC63:
	.string	"B1I3i9b1c4c6"
.LC64:
	.string	"c3b1i7s4"
.LC65:
	.string	"i28i11c3s3"
.LC66:
	.string	"s5bb1b1"
.LC67:
	.string	"c1s16I32i31c6"
.LC68:
	.string	"C0ic7i9c3"
.LC69:
	.string	"I0i6i2c8i4"
.LC70:
	.string	"I7si1i19c3"
.LC71:
	.string	"S3s16c1s11i"
.LC72:
	.string	"s4i18I9ic6"
.LC73:
	.string	"bi5ii14"
.LC74:
	.string	"c5s5c6s13"
.LC75:
	.string	"sb1i20c2"
.LC76:
	.string	"i31b1i30i"
.LC77:
	.string	"i5sB1si7"
.LC78:
	.string	"b1c2ii15"
.LC79:
	.string	"si24b1s3"
.LC80:
	.string	"c5isb1"
.LC81:
	.string	"c5i21i8c"
.LC82:
	.string	"b1i1s8i29"
.LC83:
	.string	"i21c2s1i17"
.LC84:
	.string	"c1cs9c"
.LC85:
	.string	"c1ii2c"
.LC86:
	.string	"si15i19i1"
.LC87:
	.string	"B0b1ic3b1"
.LC88:
	.string	"i4i14c1i20"
.LC89:
	.string	"i7bc2s3"
.LC90:
	.string	"i19I6is9c8"
.LC91:
	.string	"ib1si4"
.LC92:
	.string	"bi5bi16"
.LC93:
	.string	"C4c1i4ci"
.LC94:
	.string	"c3b1si5"
.LC95:
	.string	"i9c4I5iB0i11"
.LC96:
	.string	"bisi1"
.LC97:
	.string	"i30i13i28s2"
.LC98:
	.string	"b1c2c2c4"
.LC99:
	.string	"ii2s14c3"
.LC100:
	.string	"I5s2i2sc4"
.LC101:
	.string	"i28sii14"
.LC102:
	.string	"i23B1c7i7i11"
.LC103:
	.string	"i4ib1s4"
.LC104:
	.string	"i30s12s13s"
.LC105:
	.string	"s15s2si9"
.LC106:
	.string	"i7sc7i2"
.LC107:
	.string	"i2b1I0i11i5"
.LC108:
	.string	"i2s10s14i14"
.LC109:
	.string	"c1c7b1s8"
.LC110:
	.string	"s3c4c2i"
.LC111:
	.string	"i14c2c7s1"
.LC112:
	.string	"s8s3si11"
.LC113:
	.string	"c1b1si3"
.LC114:
	.string	"c8B1i4i2i31"
.LC115:
	.string	"s10c4s9b1"
.LC116:
	.string	"i28c4i20i8"
.LC117:
	.string	"c1i22i4i3"
.LC118:
	.string	"cs4i10i2"
.LC119:
	.string	"ci16i16i2"
.LC120:
	.string	"ci12i1s16"
.LC121:
	.string	"i19b1i14i"
.LC122:
	.string	"ii17i4i3"
.LC123:
	.string	"i15c2s3b"
.LC124:
	.string	"ii16ic"
.LC125:
	.string	"s7i30c7i28"
.LC126:
	.string	"i19ic2b"
.LC127:
	.string	"c2c8ci1"
.LC128:
	.string	"si23i5c2"
.LC129:
	.string	"b1I3cii"
.LC130:
	.string	"b1cc1s"
.LC131:
	.string	"i4bcs4"
.LC132:
	.string	"s2b1i17s"
.LC133:
	.string	"bi12i27s10"
.LC134:
	.string	"s16s2b1i26"
.LC135:
	.string	"i1i6s7c2"
.LC136:
	.string	"c2c3c4i"
.LC137:
	.string	"i13ssi15"
.LC138:
	.string	"s2b1ii4"
.LC139:
	.string	"s6sss8"
.LC140:
	.string	"b1i12I0s2c7"
.LC141:
	.string	"b1cc1b1"
.LC142:
	.string	"c1sii31"
.LC143:
	.string	"cc1s6i23"
.LC144:
	.string	"s9s10b1i7"
.LC145:
	.string	"c5i5i9c8"
.LC146:
	.string	"i7i4i4i14"
.LC147:
	.string	"c8i1S0s6i29"
.LC148:
	.string	"s13is16s8"
.LC149:
	.string	"i30c1cb1"
.LC150:
	.string	"bb1s1i3"
.LC151:
	.string	"i7ii2s4"
.LC152:
	.string	"i2cc3b"
.LC153:
	.string	"b1s7i11b1"
.LC154:
	.string	"s3s6i5i15"
.LC155:
	.string	"s3s3s2c"
.LC156:
	.string	"i1ii3c4"
.LC157:
	.string	"i2s5i23i5"
.LC158:
	.string	"c5I0s4i4i21"
.LC159:
	.string	"c4bc2I5b1"
.LC160:
	.string	"s1s10c1i10"
.LC161:
	.string	"i21s3B1c7c"
.LC162:
	.string	"s9i11cC4i9"
.LC163:
	.string	"c1i2ii4"
.LC164:
	.string	"C1i10i32ic2"
.LC165:
	.string	"s7s4bs3"
.LC166:
	.string	"ci32sc"
.LC167:
	.string	"b1i5s15i1"
.LC168:
	.string	"i2s15s8s12"
.LC169:
	.string	"S4i3i1b1s"
.LC170:
	.string	"c3i1s3i22"
.LC171:
	.string	"i15s5c2i2"
.LC172:
	.string	"b1i31cc6"
.LC173:
	.string	"s8ii17I1i8"
.LC174:
	.string	"c2ci2b1"
.LC175:
	.string	"ib1i20s"
.LC176:
	.string	"s2i2s3I6s"
.LC177:
	.string	"s13s14b1s"
.LC178:
	.string	"i29c8b1i5"
.LC179:
	.string	"b1s2i1c"
.LC180:
	.string	"b1c7s4c1"
.LC181:
	.string	"i6i12s5b"
.LC182:
	.string	"S6isB0i1i6"
.LC183:
	.string	"i2s2i31c"
.LC184:
	.string	"i28i13b1I8s6"
.LC185:
	.string	"i30c7s5s2"
.LC186:
	.string	"i7ci4i14"
.LC187:
	.string	"cS0si6s8"
.LC188:
	.string	"c8s5ic"
.LC189:
	.string	"ic7ic"
.LC190:
	.string	"i24I4i15c4i31"
.LC191:
	.string	"i1i25i11c"
.LC192:
	.string	"C1i3c5ci"
.LC193:
	.string	"b1i2i1s9"
.LC194:
	.string	"b1bc3c5"
.LC195:
	.string	"ii3C2C0c6i2"
.LC196:
	.string	"s6i7b1c4"
.LC197:
	.string	"ssss3"
.LC198:
	.string	"ss3s4b"
.LC199:
	.string	"iC3cc8c4"
.LC200:
	.string	"i1cc5c8"
.LC201:
	.string	"ib1b1c5"
.LC202:
	.string	"b1s14si30"
.LC203:
	.string	"C1I0I3bi6i18i5"
.LC204:
	.string	"i15I19c1c8c5"
.LC205:
	.string	"i4i6ci13"
.LC206:
	.string	"c6I4s8i17i"
.LC207:
	.string	"c5c1bC3i"
.LC208:
	.string	"sb1s8i10"
.LC209:
	.string	"i17s5s3i14"
.LC210:
	.string	"s8c1b1b1"
.LC211:
	.string	"c3S0i2c1i"
.LC212:
	.string	"c7i2i30s2"
.LC213:
	.string	"i1C8ss9b"
.LC214:
	.string	"ci10c4b1"
.LC215:
	.string	"ic2B1cC0c7"
.LC216:
	.string	"i5c6i3i"
.LC217:
	.string	"i8bi7b"
.LC218:
	.string	"is3bc5"
.LC219:
	.string	"c1I2s11c1c4"
.LC220:
	.string	"c1i10c5c1"
.LC221:
	.string	"i12c2i4c8"
.LC222:
	.string	"s2i16c1i25"
.LC223:
	.string	"iI12s4i10b1"
.LC224:
	.string	"s4i1ii1"
.LC225:
	.string	"si1b1i3"
.LC226:
	.string	"sbi4c5"
.LC227:
	.string	"is15s7C2i"
.LC228:
	.string	"i32c1cc6"
.LC229:
	.string	"b1ic7c1"
.LC230:
	.string	"ii15ib1"
.LC231:
	.string	"b1i1is5"
.LC232:
	.string	"i7i9i8i1"
.LC233:
	.string	"i3b1c3i4"
.LC234:
	.string	"i2s9i29i3"
.LC235:
	.string	"i1c3s6s5"
.LC236:
	.string	"c4ic6c3"
.LC237:
	.string	"b1i4c1c4"
.LC238:
	.string	"i23i2c6i28"
.LC239:
	.string	"ic3sc2"
.LC240:
	.string	"i32c5c3i6"
.LC241:
	.string	"c2ic4i4"
.LC242:
	.string	"i12b1i13s15"
.LC243:
	.string	"b1i1s7c7"
.LC244:
	.string	"c6S1s3cc2"
.LC245:
	.string	"b1ii11b1"
.LC246:
	.string	"i12c6b1b1"
.LC247:
	.string	"b1i6s7i"
.LC248:
	.string	"s11s16i10i"
.LC249:
	.string	"i2i17ii12"
.LC250:
	.string	"i13si14c7"
.LC251:
	.string	"c1s4s7s15"
.LC252:
	.string	"s14c2i3i2"
.LC253:
	.string	"ii21s6b1"
.LC254:
	.string	"i23b1b1c4"
.LC255:
	.string	"iI0I1ci15c6"
.LC256:
	.string	"b1i1c8b1"
.LC257:
	.string	"s5i2i11s"
.LC258:
	.string	"i1b1c8i25"
.LC259:
	.string	"cis3c"
.LC260:
	.string	"ii14ii"
.LC261:
	.string	"i1b1c2I1c2"
.LC262:
	.string	"c4ib1i"
.LC263:
	.string	"b1isi4"
.LC264:
	.string	"i16c2s12i12"
.LC265:
	.string	"B0s1I21c2ci"
.LC266:
	.string	"i16s1i5b1"
.LC267:
	.string	"s8ii1C0s9"
.LC268:
	.string	"B1i14c2si"
.LC269:
	.string	"c2i2i3s13"
.LC270:
	.string	"ii21i9c8"
.LC271:
	.string	"I1I5s1b1i10s"
.LC272:
	.string	"bs6si24"
.LC273:
	.string	"i11cc5i14"
.LC274:
	.string	"i7ccb1"
.LC275:
	.string	"i1I30i16I0bi"
.LC276:
	.string	"ccs7s"
.LC277:
	.string	"i16b1si3"
.LC278:
	.string	"s5cc1s7"
.LC279:
	.string	"ii4b1b1"
.LC280:
	.string	"sC0S0B1c2b1i"
.LC281:
	.string	"cc2c7s3"
.LC282:
	.string	"s5s14i1c3"
.LC283:
	.string	"ic1i2i31"
.LC284:
	.string	"i10i2b1c8"
.LC285:
	.string	"i26ss12S11s3"
.LC286:
	.string	"cS9s2s4s4"
.LC287:
	.string	"i26s3i2i16"
.LC288:
	.string	"b1i30b1c3"
.LC289:
	.string	"i20i3ci14"
.LC290:
	.string	"bic2c"
.LC291:
	.string	"i7i2s1i9"
.LC292:
	.string	"s12sii3"
.LC293:
	.string	"b1i25I10i12i1"
.LC294:
	.string	"is14s16c4"
.LC295:
	.string	"C5bcc1c2"
.LC296:
	.string	"B1S0b1cb1i"
.LC297:
	.string	"i15c1is3"
.LC298:
	.string	"s2s12c1s13"
.LC299:
	.string	"i2b1c2b1"
.LC300:
	.string	"i23s8C0c4s8"
.LC301:
	.string	"i1i12cs2"
.LC302:
	.string	"is9c2s7"
.LC303:
	.string	"i32s1si"
.LC304:
	.string	"I0b1i7i2I0i"
.LC305:
	.string	"i7C0s2b1i29"
.LC306:
	.string	"S5i32i13c6b1"
.LC307:
	.string	"c2I0i15I0sc8"
.LC308:
	.string	"s4c7i11i2"
.LC309:
	.string	"s1b1c4i9"
.LC310:
	.string	"ii3i8c3"
.LC311:
	.string	"s3i7c4i1"
.LC312:
	.string	"i11s3c7i15"
.LC313:
	.string	"i4ib1c"
.LC314:
	.string	"c4C0i14b1C0i"
.LC315:
	.string	"i12i28bc7"
.LC316:
	.string	"i16s4i4b1"
.LC317:
	.string	"ic8s3c2"
.LC318:
	.string	"S1b1i13c1S0i"
.LC319:
	.string	"b1c7i32s11"
.LC320:
	.string	"i2s2si6"
.LC321:
	.string	"b1S0c6I3bi14"
.LC322:
	.string	"i13I0C0b1i15c3"
.LC323:
	.string	"ss1c1c5"
.LC324:
	.string	"i2i27s2s14"
.LC325:
	.string	"c8s6i30s15"
.LC326:
	.string	"c6si2c5"
.LC327:
	.string	"I28i14I1i31b1i18"
.LC328:
	.string	"i1sc1b"
.LC329:
	.string	"s14i2c1s1"
.LC330:
	.string	"cI9s3S0c7s"
.LC331:
	.string	"i8ic4c"
.LC332:
	.string	"S14c1ii27i17"
.LC333:
	.string	"c1b1s8s"
.LC334:
	.string	"i6i5s8i14"
.LC335:
	.string	"c7i2i1c1"
.LC336:
	.string	"s4s3s5I0s"
.LC337:
	.string	"i8cc3c7"
.LC338:
	.string	"cB1i29b1i4"
.LC339:
	.string	"i2s11s10i2"
.LC340:
	.string	"sc1s1s13"
.LC341:
	.string	"si7i8i30"
.LC342:
	.string	"b1b1i3c"
.LC343:
	.string	"is4i2c"
.LC344:
	.string	"c4i4i9S0b1"
.LC345:
	.string	"c1i32s8I1i9"
.LC346:
	.string	"c8i8s3I0I0s12"
.LC347:
	.string	"c1c5i22I12I23i"
.LC348:
	.string	"i28s14cs"
.LC349:
	.string	"s11s5i14i"
.LC350:
	.string	"c5s2c1c1"
.LC351:
	.string	"ii5i14s5"
.LC352:
	.string	"c2i10i25I0B1I1I7s7"
.LC353:
	.string	"s14i7i1s8"
.LC354:
	.string	"cc3i32C0c5"
.LC355:
	.string	"b1s5ic3"
.LC356:
	.string	"C0i22s1i14s5"
.LC357:
	.string	"i4i1c1s"
.LC358:
	.string	"S0iii32i"
.LC359:
	.string	"ib1c8c4"
.LC360:
	.string	"i2s11i12i1"
.LC361:
	.string	"i2i14i14i30"
.LC362:
	.string	"i4c7i6I0c3"
.LC363:
	.string	"is14s1b1"
.LC364:
	.string	"i8i1s16c8"
.LC365:
	.string	"c3i2s3s13"
.LC366:
	.string	"i29I0i2c1c5"
.LC367:
	.string	"i19i22i23I0i1"
.LC368:
	.string	"S0s3scC6s8"
.LC369:
	.string	"i7i7C1s15i5"
.LC370:
	.string	"I1b1ii4i7"
.LC371:
	.string	"ci16i7i"
.LC372:
	.string	"ic1b1c6"
.LC373:
	.string	"b1cc3c"
.LC374:
	.string	"i7s5ci5"
.LC375:
	.string	"c3i21i27c5"
.LC376:
	.string	"s3i13s7i"
.LC377:
	.string	"i3S15ii6s7"
.LC378:
	.string	"i7i3cs8"
.LC379:
	.string	"isci23"
.LC380:
	.string	"cs14cb1"
.LC381:
	.string	"c8c6cb"
.LC382:
	.string	"c5ic2i14"
.LC383:
	.string	"iis3i2"
.LC384:
	.string	"i5b1c2I15i7"
.LC385:
	.string	"s6C0i1ib1"
.LC386:
	.string	"c8ii19i2"
.LC387:
	.string	"i17b1s8i"
.LC388:
	.string	"c1i4b1s6"
.LC389:
	.string	"c7s6cI8c1"
.LC390:
	.string	"i1i12i5c4"
.LC391:
	.string	"ii11S16ci"
.LC392:
	.string	"sis8i31"
.LC393:
	.string	"ib1s5s14"
.LC394:
	.string	"i2c3s7b"
.LC395:
	.string	"b1i6c3b"
.LC396:
	.string	"I0b1s9c2c"
.LC397:
	.string	"b1s7i3i31"
.LC398:
	.string	"s3ii9i2"
.LC399:
	.string	"cI29i27iI0b1"
.LC400:
	.string	"b1ssI14s5"
.LC401:
	.string	"csi2s"
.LC402:
	.string	"I5bs10c8s7"
.LC403:
	.string	"c7i1I28i15I0C0i6"
.LC404:
	.string	"i2i16s5b1"
.LC405:
	.string	"ib1i2i"
.LC406:
	.string	"c8b1i26I0c1"
.LC407:
	.string	"i10c1sc1"
.LC408:
	.string	"i2i4c8I12s9"
.LC409:
	.string	"C0c2i9i4b1"
.LC410:
	.string	"C0ic2ib1"
.LC411:
	.string	"s4s5i2i"
.LC412:
	.string	"i25c3i11c"
.LC413:
	.string	"i17i8i25c"
.LC414:
	.string	"I3is5c4c6"
.LC415:
	.string	"c7i7s16s"
.LC416:
	.string	"sc5i1i11"
.LC417:
	.string	"i14s7s11s7"
.LC418:
	.string	"ci1c1c1"
.LC419:
	.string	"s12C1s7c5s11"
.LC420:
	.string	"i9cC2ss8"
.LC421:
	.string	"c2cb1s16"
.LC422:
	.string	"b1S0s12b1i6"
.LC423:
	.string	"i14i14i9s1"
.LC424:
	.string	"cc6cB0i7"
.LC425:
	.string	"I0b1i32c8b1"
.LC426:
	.string	"i1i4I0s4i16"
.LC427:
	.string	"c3I0B1c4sb"
.LC428:
	.string	"i25i6i5s1"
.LC429:
	.string	"i1ic6s1"
.LC430:
	.string	"i3b1s7s5"
.LC431:
	.string	"i2s13i13s4"
.LC432:
	.string	"iii11s"
.LC433:
	.string	"i2s2i27s1"
.LC434:
	.string	"si1i22i1"
.LC435:
	.string	"s7I2b1c7i29"
.LC436:
	.string	"C0i11I0B0ii2c3"
.LC437:
	.string	"cb1I7i8i22"
.LC438:
	.string	"s12b1bi"
.LC439:
	.string	"I1i11c5s9C0i24"
.LC440:
	.string	"b1i32cc3"
.LC441:
	.string	"c2c2c4i5"
.LC442:
	.string	"C5c6I22c3I0sI0i"
.LC443:
	.string	"c8c2i2i10"
.LC444:
	.string	"s10I0s6i12s3"
.LC445:
	.string	"s1i3is2"
.LC446:
	.string	"b1s1i27I26c"
.LC447:
	.string	"i12i22ss6"
.LC448:
	.string	"s7i21ii27"
.LC449:
	.string	"i1c1i15C0b"
.LC450:
	.string	"c5s5c3c5"
.LC451:
	.string	"b1c4bs2"
.LC452:
	.string	"ii1b1c8"
.LC453:
	.string	"c4c5si31"
.LC454:
	.string	"ss13ss1"
.LC455:
	.string	"s8C1C0s4iC7i15"
.LC456:
	.string	"I0i12b1i28i5"
.LC457:
	.string	"i2s5s15s12"
.LC458:
	.string	"s5s11i6i1"
.LC459:
	.string	"i2s2s4s5"
.LC460:
	.string	"s4i5sc8"
.LC461:
	.string	"s3i22i1i20"
.LC462:
	.string	"c4iic5"
.LC463:
	.string	"s7i25i12i2"
.LC464:
	.string	"b1i13s1I0i2"
.LC465:
	.string	"s5c6s5b1"
.LC466:
	.string	"b1c1b1c1"
.LC467:
	.string	"i24i1is"
.LC468:
	.string	"c1S0ii3s"
.LC469:
	.string	"c6i11c5i5"
.LC470:
	.string	"i7i24I19b1i1"
.LC471:
	.string	"c1i4s13s1"
.LC472:
	.string	"ib1S15i2S4i13"
.LC473:
	.string	"s7c5s5s12"
.LC474:
	.string	"s1c4i1b1"
.LC475:
	.string	"i2cs4i11"
.LC476:
	.string	"i7c7sc"
.LC477:
	.string	"iI1c2s4s6"
.LC478:
	.string	"b1iI3b1b1"
.LC479:
	.string	"I7c2i1i2s"
.LC480:
	.string	"i1c1is10"
.LC481:
	.string	"s1bis"
.LC482:
	.string	"I1C0i17s11i22i"
.LC483:
	.string	"b1i13i2s15"
.LC484:
	.string	"ib1s4s1"
.LC485:
	.string	"c5i5i13S11i"
.LC486:
	.string	"b1b1c7b1"
.LC487:
	.string	"c1ci9c7"
.LC488:
	.string	"i1b1s2i21"
.LC489:
	.string	"i31s5I0S0c5c"
.LC490:
	.string	"b1i29cI3c"
.LC491:
	.string	"s8c5si14"
.LC492:
	.string	"iS4I0ii1i"
.LC493:
	.string	"ss16i4b1"
.LC494:
	.string	"s9c2c5I29c1"
.LC495:
	.string	"cs9c7c8"
.LC496:
	.string	"S6i20s6i3s4"
.LC497:
	.string	"c2i15i2i32"
.LC498:
	.string	"i1ii27i15"
.LC499:
	.string	"iiI0s2c3"
.LC500:
	.string	"s3i7i2c3"
.LC501:
	.string	"iC2C0ss2c1"
.LC502:
	.string	"i2b1s10i1"
.LC503:
	.string	"c2b1i3i20"
.LC504:
	.string	"i8c4s3i16"
.LC505:
	.string	"ii6s5i"
.LC506:
	.string	"i26s9c5c5"
.LC507:
	.string	"c6ii2i6"
.LC508:
	.string	"i28isc8"
.LC509:
	.string	"s15s10i2i"
.LC510:
	.string	"i8i4i19i32"
.LC511:
	.string	"c1ci6i"
.LC512:
	.string	"i2s9cs8"
.LC513:
	.string	"i5i10s9c1"
.LC514:
	.string	"s7i2s5i2"
.LC515:
	.string	"i30c2bc3"
.LC516:
	.string	"si10iI1b1"
.LC517:
	.string	"B1cii6i26"
.LC518:
	.string	"C0b1i3B1I0c2i7"
.LC519:
	.string	"s2B1c8i30i11"
.LC520:
	.string	"i29c5i11c7"
.LC521:
	.string	"i32b1ci"
.LC522:
	.string	"b1i1c7i11"
.LC523:
	.string	"c5i2cb1"
.LC524:
	.string	"s8S12i5S4i12b1"
.LC525:
	.string	"ib1c6B0s4"
.LC526:
	.string	"c4ib1c8"
.LC527:
	.string	"s12i14i10i6"
.LC528:
	.string	"ii20s1i6"
.LC529:
	.string	"c1b1b1c"
.LC530:
	.string	"i5b1s2i"
.LC531:
	.string	"s2c3i2c1"
.LC532:
	.string	"i5ci1i19"
.LC533:
	.string	"is4C8s6i"
.LC534:
	.string	"bb1ii1"
.LC535:
	.string	"c4s9i3c4"
.LC536:
	.string	"c3i17i14b"
.LC537:
	.string	"c4s3s1S2c3"
.LC538:
	.string	"i13s14i19i5"
.LC539:
	.string	"ii15i22i1"
.LC540:
	.string	"c6is3i26"
.LC541:
	.string	"i2s6i1s8"
.LC542:
	.string	"i4c2s2i"
.LC543:
	.string	"i11i4cs3"
.LC544:
	.string	"i9i14s11s"
.LC545:
	.string	"c7si1S7i1"
.LC546:
	.string	"c6cc1b"
.LC547:
	.string	"sc3b1s"
.LC548:
	.string	"ci11i2c2"
.LC549:
	.string	"ii19sc2"
.LC550:
	.string	"cc3ii1"
.LC551:
	.string	"i30i3i2i6"
.LC552:
	.string	"c7b1I13is5"
.LC553:
	.string	"I0i2i2C4S3ic5"
.LC554:
	.string	"i18isI5b1"
.LC555:
	.string	"iis4i14"
.LC556:
	.string	"c1i10bs9"
.LC557:
	.string	"sb1c4b1"
.LC558:
	.string	"b1i13i7i19"
.LC559:
	.string	"c1i7is1"
.LC560:
	.string	"I16s3i1i5s6"
.LC561:
	.string	"c8sc7b"
.LC562:
	.string	"cs1b1c3"
.LC563:
	.string	"i12b1c5S3s5"
.LC564:
	.string	"s15is13b1"
.LC565:
	.string	"c7is5s12"
.LC566:
	.string	"b1b1cs4"
.LC567:
	.string	"c1cs1s3"
.LC568:
	.string	"i23sis6"
.LC569:
	.string	"I3C2i7i9c1i8"
.LC570:
	.string	"c1b1c4i19"
.LC571:
	.string	"i15c1i9c3"
.LC572:
	.string	"si4i6c4"
.LC573:
	.string	"c7I3ii14s8"
.LC574:
	.string	"i27i8c6c5"
.LC575:
	.string	"i31i5i13i7"
.LC576:
	.string	"i2s9i6s2"
.LC577:
	.string	"i2c2i6b"
.LC578:
	.string	"S10i6i6C6i1i3"
.LC579:
	.string	"i13c1cc3"
.LC580:
	.string	"is15i4I0i19"
.LC581:
	.string	"bc2i15s11"
.LC582:
	.string	"bC7I0cc3s5"
.LC583:
	.string	"s13iis6"
.LC584:
	.string	"i28S2bs4i32"
.LC585:
	.string	"cC8i1C6i12b"
.LC586:
	.string	"iii3s3"
.LC587:
	.string	"c6c7s7i22"
.LC588:
	.string	"I20i2iss7"
.LC589:
	.string	"cci26c"
.LC590:
	.string	"i4c1is"
.LC591:
	.string	"i10i3i13c5"
.LC592:
	.string	"i28s16b1b1"
.LC593:
	.string	"iiii3"
.LC594:
	.string	"i13si9i2"
.LC595:
	.string	"s6i6i22s5"
.LC596:
	.string	"c7b1S8s6S3I6i2"
.LC597:
	.string	"i5i5si11"
.LC598:
	.string	"iI2s14i12c4"
.LC599:
	.string	"is5c1b"
.LC600:
	.string	"iC1c5i32i"
.LC601:
	.string	"c6c3is9"
.LC602:
	.string	"ici15b1"
.LC603:
	.string	"i11s5b1i17"
.LC604:
	.string	"i12s5i10i13"
.LC605:
	.string	"i22c3s1s2"
.LC606:
	.string	"i1b1i3s9"
.LC607:
	.string	"i2i2i18s1"
.LC608:
	.string	"bi1i1i"
.LC609:
	.string	"c1i1i14i1"
.LC610:
	.string	"s6b1i1i"
.LC611:
	.string	"s2C0s1b1B1b"
.LC612:
	.string	"I0I1s4ii2s16"
.LC613:
	.string	"C4is14bi4"
.LC614:
	.string	"c6I7C0c6i18s1"
.LC615:
	.string	"s5c2i20c6"
.LC616:
	.string	"s15s4ii"
.LC617:
	.string	"c4s2i28i14"
.LC618:
	.string	"ic8i29C0i"
.LC619:
	.string	"s1ii15i31"
.LC620:
	.string	"I0I12si2s5s9"
.LC621:
	.string	"c1C7b1S3i2s4"
.LC622:
	.string	"c3i13i25c1"
.LC623:
	.string	"i24C0cc7I0s7"
.LC624:
	.string	"S10i5I26i26b1i"
.LC625:
	.string	"s12I15ss2s5"
.LC626:
	.string	"I5ii1b1b"
.LC627:
	.string	"I14i11C1s1i4c"
.LC628:
	.string	"i29s8c3c4"
.LC629:
	.string	"c4s2s1i15"
.LC630:
	.string	"ii9s2s1"
.LC631:
	.string	"i28i11i4i30"
.LC632:
	.string	"s9si1i28"
.LC633:
	.string	"c7s2C7I0c1b1"
.LC634:
	.string	"c5i11ii30"
.LC635:
	.string	"i2ii7b1"
.LC636:
	.string	"S10b1i4i1c6"
.LC637:
	.string	"cs9s14s9"
.LC638:
	.string	"s1i3b1i5"
.LC639:
	.string	"cbI27c3c2"
.LC640:
	.string	"i7b1c3i28"
.LC641:
	.string	"i2i22s8i2"
.LC642:
	.string	"i12c7I0C5s2i28"
.LC643:
	.string	"b1iss3"
.LC644:
	.string	"i1c5c1s2"
.LC645:
	.string	"bi6i27b"
.LC646:
	.string	"c4c5sc"
.LC647:
	.string	"c2ii1c4"
.LC648:
	.string	"isi13S3b1"
.LC649:
	.string	"i23i20ii1"
.LC650:
	.string	"i2b1s1b"
.LC651:
	.string	"ic1c3s2"
.LC652:
	.string	"b1iI7c4i4"
.LC653:
	.string	"S4ci13i4s1"
.LC654:
	.string	"i13i8b1i2"
.LC655:
	.string	"c5b1i10i20"
.LC656:
	.string	"i8ci4B0c2"
.LC657:
	.string	"b1i8ii2"
.LC658:
	.string	"i6c5i18i3"
.LC659:
	.string	"c6i26i11c8"
.LC660:
	.string	"I0i2b1i9b1"
.LC661:
	.string	"s2i9B1s1b1"
.LC662:
	.string	"ii6b1i"
.LC663:
	.string	"I4si22c1c1"
.LC664:
	.string	"iis4i1"
.LC665:
	.string	"i4i2C0I4i1b1"
.LC666:
	.string	"b1ci20i"
.LC667:
	.string	"ciis1"
.LC668:
	.string	"C2s2s14i4s4"
.LC669:
	.string	"s1s1c6S3i13"
.LC670:
	.string	"s2s11ib1"
.LC671:
	.string	"s9S8s14s2c4"
.LC672:
	.string	"bc4i22i5"
.LC673:
	.string	"i1ii9s6"
.LC674:
	.string	"i20ic8i15"
.LC675:
	.string	"i2c7is"
.LC676:
	.string	"s16i6c1i8"
.LC677:
	.string	"i2is8c1"
.LC678:
	.string	"i8s3I12i6i6"
.LC679:
	.string	"i1c5ii"
.LC680:
	.string	"ii17i2b1"
.LC681:
	.string	"ib1b1s10"
.LC682:
	.string	"s8c1b1C4i"
.LC683:
	.string	"s16I0s8ib1"
.LC684:
	.string	"s16c1b1s9"
.LC685:
	.string	"I0cii20c5"
.LC686:
	.string	"bc7c5i"
.LC687:
	.string	"s7b1ii10"
.LC688:
	.string	"i25C1S0c2s6i7"
.LC689:
	.string	"i28s12c5b1"
.LC690:
	.string	"i15i5i2s4"
.LC691:
	.string	"ciI6ii9"
.LC692:
	.string	"i2s7ib1"
.LC693:
	.string	"i6S11c6s8I6i3"
.LC694:
	.string	"c7C1c5ss8"
.LC695:
	.string	"i5s8i25c2"
.LC696:
	.string	"s4s3ci1"
.LC697:
	.string	"is2c1s6"
.LC698:
	.string	"s1i9c3c8"
.LC699:
	.string	"i2c3i19s6"
.LC700:
	.string	"i4c2s1c"
.LC701:
	.string	"s1ci27s"
.LC702:
	.string	"c7c1s3c2"
.LC703:
	.string	"c4i3s2I2i5"
.LC704:
	.string	"i2c1c1c3"
.LC705:
	.string	"sci5c5"
.LC706:
	.string	"c7c1c3i"
.LC707:
	.string	"I0i13i28i13s2"
.LC708:
	.string	"c1bS0i5b1"
.LC709:
	.string	"bS0i4cc"
.LC710:
	.string	"i15si6c7"
.LC711:
	.string	"i6i15c3i"
.LC712:
	.string	"ic4i29i"
.LC713:
	.string	"c8s4b1b1"
.LC714:
	.string	"s3i11s10c"
.LC715:
	.string	"c3c2cs3"
.LC716:
	.string	"c6i5i10s"
.LC717:
	.string	"s2b1i14s2"
.LC718:
	.string	"bb1i2C3s"
.LC719:
	.string	"b1i4c1i"
.LC720:
	.string	"i11I20i4si20"
.LC721:
	.string	"i20I2si1s15"
.LC722:
	.string	"i31b1ii2"
.LC723:
	.string	"c7I0cs16i"
.LC724:
	.string	"c1S1ic3i1"
.LC725:
	.string	"c3s1i7i2"
.LC726:
	.string	"ii7I2i4b1"
.LC727:
	.string	"c5isc6"
.LC728:
	.string	"c7B0c7i9i7"
.LC729:
	.string	"cs1i2c5"
.LC730:
	.string	"c5c8s2s6"
.LC731:
	.string	"ibi2i19"
.LC732:
	.string	"I10si28S8b1s"
.LC733:
	.string	"sb1i1S5s4"
.LC734:
	.string	"i13si25c"
.LC735:
	.string	"s11s4si4"
.LC736:
	.string	"B1s2s4i7S4s4"
.LC737:
	.string	"c5is3i"
.LC738:
	.string	"i8i23s9i31"
.LC739:
	.string	"I13i5b1i15i1"
.LC740:
	.string	"i8i1cs16"
.LC741:
	.string	"s12I26ibi4"
.LC742:
	.string	"si2I0ic5"
.LC743:
	.string	"i14bi20i5"
.LC744:
	.string	"I0cc1i2s15"
.LC745:
	.string	"s11S0sc1i9"
.LC746:
	.string	"s2c1s2b1"
.LC747:
	.string	"c1b1c8i6"
.LC748:
	.string	"i17C4ii13c1"
.LC749:
	.string	"ii1b1i10"
.LC750:
	.string	"i18bs3i2"
.LC751:
	.string	"s6b1ii1"
.LC752:
	.string	"s15b1S7c6I0i25"
.LC753:
	.string	"i20C8I1I5i15b1c1"
.LC754:
	.string	"i12c1I0s3s12"
.LC755:
	.string	"c2b1i7C1i"
.LC756:
	.string	"I6b1I25s12i5c1"
.LC757:
	.string	"s4c3bi12"
.LC758:
	.string	"i22b1si7"
.LC759:
	.string	"i14i12i24i2"
.LC760:
	.string	"i3s1ci"
.LC761:
	.string	"ib1b1c3"
.LC762:
	.string	"c2S6s4c7i12"
.LC763:
	.string	"S4i2b1i28s15"
.LC764:
	.string	"b1s7ii5"
.LC765:
	.string	"ciii29"
.LC766:
	.string	"c7sc1i8"
.LC767:
	.string	"ii24b1i4"
.LC768:
	.string	"c6i31i4c2"
.LC769:
	.string	"cbs5c4"
.LC770:
	.string	"ib1ci13"
.LC771:
	.string	"c3I1i23I4C0i18i32"
.LC772:
	.string	"cb1ib1"
.LC773:
	.string	"b1S0bi6b1"
.LC774:
	.string	"c2B1i26i10I10i20"
.LC775:
	.string	"i15i3S0i4I11I0c"
.LC776:
	.string	"i1ii22i"
.LC777:
	.string	"b1i11ii"
.LC778:
	.string	"b1i14i2c"
.LC779:
	.string	"si1i1B0s"
.LC780:
	.string	"i6I0i1i16c6"
.LC781:
	.string	"i6i1i14c1"
.LC782:
	.string	"i6s2s3c2"
.LC783:
	.string	"s4i1i8c"
.LC784:
	.string	"sb1c2i2"
.LC785:
	.string	"b1i1i10i23"
.LC786:
	.string	"i1i3s4i"
.LC787:
	.string	"c3i1ic5"
.LC788:
	.string	"i5bi10C1i"
.LC789:
	.string	"i5b1i8i11"
.LC790:
	.string	"c8i1s14I22s13"
.LC791:
	.string	"i7i6c1c"
.LC792:
	.string	"s3i1c6s6"
.LC793:
	.string	"cc1c4c1"
.LC794:
	.string	"ib1i11c"
.LC795:
	.string	"i2i5b1i8"
.LC796:
	.string	"is3s9c7"
.LC797:
	.string	"i23i1i3b1"
.LC798:
	.string	"S1i23b1i16c2"
.LC799:
	.string	"c4sS12s8c5"
.LC800:
	.string	"i1i7ci14"
.LC801:
	.string	"i30S3s16sb1"
.LC802:
	.string	"i1b1b1b1"
.LC803:
	.string	"ss6sc8"
.LC804:
	.string	"I0ii4i17c7"
.LC805:
	.string	"i26i14I23I10i20I22i19"
.LC806:
	.string	"c6b1is11"
.LC807:
	.string	"i23i1i12s4"
.LC808:
	.string	"i17ci29b1"
.LC809:
	.string	"C0i1s15I0is1"
.LC810:
	.string	"i28b1s2i11"
.LC811:
	.string	"si5c6s3"
.LC812:
	.string	"c3is12c1"
.LC813:
	.string	"i3i7i8c4"
.LC814:
	.string	"ci2i10b1"
.LC815:
	.string	"c1I25i9bi3"
.LC816:
	.string	"S6I0i14iB1c3s8"
.LC817:
	.string	"ic2i4s7"
.LC818:
	.string	"s1s2i28C1i4"
.LC819:
	.string	"b1i7si13"
.LC820:
	.string	"i6s2c1b1"
.LC821:
	.string	"i18I2c1sc2"
.LC822:
	.string	"is9I0c8i"
.LC823:
	.string	"c4c5s8i12"
.LC824:
	.string	"s7i4i2s"
.LC825:
	.string	"i25i9s1s"
.LC826:
	.string	"I0i20sbI14c4"
.LC827:
	.string	"bb1i14i21"
.LC828:
	.string	"c1ic5b"
.LC829:
	.string	"c2i2s7i1"
.LC830:
	.string	"i26b1bs2"
.LC831:
	.string	"i7s3s12c5"
.LC832:
	.string	"s4i1i2c5"
.LC833:
	.string	"s1i4i4i19"
.LC834:
	.string	"i2i23c8c5"
.LC835:
	.string	"i5sC8b1s9"
.LC836:
	.string	"s2i19c1i17"
.LC837:
	.string	"c1s3s10i7"
.LC838:
	.string	"c4i4i21c"
.LC839:
	.string	"s1B1ci15i2"
.LC840:
	.string	"I2i2i3i22c"
.LC841:
	.string	"i30C5i22i1s1"
.LC842:
	.string	"i2i1i12I9i10"
.LC843:
	.string	"cs11B1i14c4"
.LC844:
	.string	"b1cs14i24"
.LC845:
	.string	"c1s16b1B1c6"
.LC846:
	.string	"bI11ic1i3"
.LC847:
	.string	"b1i15I0ii1"
.LC848:
	.string	"i5i8s2i2"
.LC849:
	.string	"sc1i2c4"
.LC850:
	.string	"i1c6I0S1s1i26"
.LC851:
	.string	"i7b1C7s3s7"
.LC852:
	.string	"c2i16c1b"
.LC853:
	.string	"s5i3i32c4"
.LC854:
	.string	"c2b1i1i7"
.LC855:
	.string	"sS0s14i14i2"
.LC856:
	.string	"i10s5c4i3"
.LC857:
	.string	"c4is4i14"
.LC858:
	.string	"i7ssi10"
.LC859:
	.string	"sc1S6c5i2"
.LC860:
	.string	"cS1S4c4si8"
.LC861:
	.string	"i10i11b1b1"
.LC862:
	.string	"i10ic7b1"
.LC863:
	.string	"i25i32i3s16"
.LC864:
	.string	"S6C5S8c7s8I0s2i4"
.LC865:
	.string	"sc1s4s2"
.LC866:
	.string	"cb1s1c7"
.LC867:
	.string	"b1ii1b"
.LC868:
	.string	"ii2i19i10"
.LC869:
	.string	"ii2i9i"
.LC870:
	.string	"s5ci32i2"
.LC871:
	.string	"s1iC7ii26"
.LC872:
	.string	"c1s12i19I31i14"
.LC873:
	.string	"i14I13b1b1s14"
.LC874:
	.string	"c3I1i2sc"
.LC875:
	.string	"b1c1C0I26b1i2"
.LC876:
	.string	"i13i2ii30"
.LC877:
	.string	"ii11ss10"
.LC878:
	.string	"ici27s"
.LC879:
	.string	"i1s8s3i32"
.LC880:
	.string	"i15c2i7i"
.LC881:
	.string	"S0i27s16i27c3"
.LC882:
	.string	"ic2ii2"
.LC883:
	.string	"s1i21s16b1"
.LC884:
	.string	"c3s3s6s12"
.LC885:
	.string	"b1sb1i22"
.LC886:
	.string	"cs3c2c7"
.LC887:
	.string	"b1c6i10i9"
.LC888:
	.string	"ici1i1"
.LC889:
	.string	"i32C0i1s1c7"
.LC890:
	.string	"i14I23s5si12"
.LC891:
	.string	"i14i2ic6"
.LC892:
	.string	"c1c4i11i14"
.LC893:
	.string	"bi5is6"
.LC894:
	.string	"sc8is"
.LC895:
	.string	"ic3s4i27"
.LC896:
	.string	"s1I8s4c2b"
.LC897:
	.string	"i4c6ii1"
.LC898:
	.string	"ci5s4b1"
.LC899:
	.string	"ci2s10S9i2"
.LC900:
	.string	"c1s2i5c1"
.LC901:
	.string	"i12s13i19s7"
.LC902:
	.string	"i11i26s7I19s"
.LC903:
	.string	"s2b1i11i"
.LC904:
	.string	"i3s2ii21"
.LC905:
	.string	"s2s9bi3"
.LC906:
	.string	"i18c2b1i"
.LC907:
	.string	"b1c1s3b1"
.LC908:
	.string	"iiI10I2b1s8"
.LC909:
	.string	"s6I21s2ii14"
.LC910:
	.string	"c5S1cs3c7"
.LC911:
	.string	"iS0s6s9b1"
.LC912:
	.string	"s2s5b1c3"
.LC913:
	.string	"b1i10c1c"
.LC914:
	.string	"c4i11B1is"
.LC915:
	.string	"B0csbi1"
.LC916:
	.string	"S3i1i13s1b"
.LC917:
	.string	"ii2s7C1B0c1"
.LC918:
	.string	"i3i8i1I0i4"
.LC919:
	.string	"s3s5i1i1"
.LC920:
	.string	"is7i1i2"
.LC921:
	.string	"i14c7i7b1"
.LC922:
	.string	"c6bi7s16"
.LC923:
	.string	"i1b1c2c"
.LC924:
	.string	"s15b1i1i14"
.LC925:
	.string	"B1I0i7is3b1"
.LC926:
	.string	"i14b1cS0i5"
.LC927:
	.string	"s1c1c1i3"
.LC928:
	.string	"ic6s7S5c3"
.LC929:
	.string	"b1i3b1i7"
.LC930:
	.string	"i2s15i11c1"
.LC931:
	.string	"B1b1c2ic1"
.LC932:
	.string	"ccS0c5i2"
.LC933:
	.string	"cb1i1I20s3"
.LC934:
	.string	"i5i2i14i1"
.LC935:
	.string	"c4C1ic8I14i7"
.LC936:
	.string	"s1I28s1C4i31c3"
.LC937:
	.string	"i12b1i2i"
.LC938:
	.string	"b1s2si8"
.LC939:
	.string	"i9i1i26b"
.LC940:
	.string	"c2i11c4c"
.LC941:
	.string	"i1i4s5i10"
.LC942:
	.string	"ib1i9c4"
.LC943:
	.string	"i20s4s4b1"
.LC944:
	.string	"ii13I15b1c3"
.LC945:
	.string	"isi7s4"
.LC946:
	.string	"I0i22i14ic"
.LC947:
	.string	"i2i2c7i10"
.LC948:
	.string	"si1b1s14"
.LC949:
	.string	"s12i26c7i10"
.LC950:
	.string	"s2i25i10c8"
.LC951:
	.string	"i13c1i6b"
.LC952:
	.string	"C3i3i28s2i27"
.LC953:
	.string	"i2ib1i"
.LC954:
	.string	"c1bi8i8"
.LC955:
	.string	"i11i1i6c4"
.LC956:
	.string	"c8c2i21c2"
.LC957:
	.string	"cb1c6s9"
.LC958:
	.string	"s13sii22"
.LC959:
	.string	"s10i10ii1"
.LC960:
	.string	"s1s16cs"
.LC961:
	.string	"i9I31i24ic4"
.LC962:
	.string	"ii2s8b1"
.LC963:
	.string	"i26c3sb"
.LC964:
	.string	"i13C3cs14c"
.LC965:
	.string	"cs2i23s"
.LC966:
	.string	"c3ii2s15"
.LC967:
	.string	"c5i2S4S0i2i31"
.LC968:
	.string	"b1i24bs2"
.LC969:
	.string	"i6i20c8s2"
.LC970:
	.string	"ss2i19i8"
.LC971:
	.string	"i2i4bc4"
.LC972:
	.string	"ib1i27s"
.LC973:
	.string	"I3i29s1c6i21"
.LC974:
	.string	"i14isi2"
.LC975:
	.string	"i29iS10sS0c7"
.LC976:
	.string	"c1i1s4i1"
.LC977:
	.string	"c1s6c4c"
.LC978:
	.string	"iii14c"
.LC979:
	.string	"s8cs7s2"
.LC980:
	.string	"i1b1c2c1"
.LC981:
	.string	"s13b1bi12"
.LC982:
	.string	"i12i5c5s8"
.LC983:
	.string	"c3ib1i17"
.LC984:
	.string	"C0S6s3B1s13i1s3"
.LC985:
	.string	"i2b1c3c8"
.LC986:
	.string	"bC0i11s10s12"
.LC987:
	.string	"s12bis3"
.LC988:
	.string	"c5ci13c8"
.LC989:
	.string	"c4s8ii"
.LC990:
	.string	"i2i10s5s4"
.LC991:
	.string	"c3c6b1c"
.LC992:
	.string	"ib1i2c2"
.LC993:
	.string	"ib1S0s3i32"
.LC994:
	.string	"iss1i8"
.LC995:
	.string	"i6i6b1i7"
.LC996:
	.string	"i11s9b1i12"
.LC997:
	.string	"s4i3is5"
.LC998:
	.string	"c4i2s6b1"
.LC999:
	.string	"s2I4c6c2c7"
.LC1000:
	.string	"is15c6C0c1"
.LC1001:
	.string	"i5s2b1c7"
.LC1002:
	.string	"s4s8c8c4"
.LC1003:
	.string	"b1i20c1i2"
	.text
	.globl	main
	.type	main, @function
main:
.LFB10:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	xorl	%eax, %eax
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC4, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$15, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC5, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$31, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC6, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC7, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$6, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$8388600, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16256, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC8, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$1, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC9, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC10, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC11, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$-32, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC12, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8190, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC13, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$33553408, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC14, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$2, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$4, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC15, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$33521664, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$12, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC16, %edi
	call	print_prologue
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$16, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16352, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC17, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2016, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$24, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$134209536, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC18, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$4032, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC19, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$28, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$992, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC20, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -28(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$31, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$96, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC21, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$4, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC22, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC23, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC24, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$124, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC25, %edi
	call	print_prologue
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$6, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC26, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$268435454, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$127, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$1920, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC27, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$63, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$2097088, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC28, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2032, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$15, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC29, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$524287, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$15, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -24(%rbp)
	movzbl	-22(%rbp), %eax
	orl	$63, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC30, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$496, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC31, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC32, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$1, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC33, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$16, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC34, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$30, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC35, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$124, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC36, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$96, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC37, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$62, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC38, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4080, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC39, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC40, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -32(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$32, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC41, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$992, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC42, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32764, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$7, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$262143, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC43, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC44, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$4, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$63, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC45, %edi
	call	print_prologue
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC46, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$4, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC47, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16256, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2147467264, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$20, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$20, %edx
	movl	$4, %esi
	movl	$.LC48, %edi
	call	print_prologue
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-16(%rbp), %eax
	orl	$8388607, %eax
	movl	%eax, -16(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC49, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$48, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$3, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC50, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$3, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC51, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$62, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC52, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC53, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$112, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC54, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$96, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC55, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$3, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$1, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC56, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$31, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC57, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$16382, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC58, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$63, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC59, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$536870911, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$32, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC60, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$15, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$112, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$8355840, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC61, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16380, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC62, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16380, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$15, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC63, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8176, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$63, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC64, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2032, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$120, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC65, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$56, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$7, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC66, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC67, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$63, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC68, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$127, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-128, %eax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$7, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC69, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC70, %edi
	call	print_prologue
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1048574, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$112, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC71, %edi
	call	print_prologue
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4094, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC72, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$4194288, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$63, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC73, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC74, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$992, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC75, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -28(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$15, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$48, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC76, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC77, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$127, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC78, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$6, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC79, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$16777215, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$1, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$14, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC80, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$1, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC81, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$67108832, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC82, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1020, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$536870911, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC83, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$2097151, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$96, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$131071, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC84, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC85, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC86, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -28(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$7, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$8, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC87, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$8, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC88, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$262128, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$4, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC89, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$28, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC90, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$524287, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC91, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC92, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC93, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$480, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC94, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC95, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$30, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC96, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$1, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC97, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-21(%rbp), %eax
	orl	$48, %eax
	movb	%al, -21(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$1, %esi
	movl	$.LC98, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$6, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$24, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$15, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC99, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-4, %eax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$7, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC100, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$96, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$384, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC101, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-20(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC102, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$8388607, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$127, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$127, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$262016, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC103, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$30, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC104, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC105, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC106, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$127, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$384, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC107, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC108, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4092, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC109, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC110, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$120, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$3, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC111, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC112, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC113, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC114, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$30, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$96, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC115, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$60, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$2, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC116, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$4080, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC117, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$8388606, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1920, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$56, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC118, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$15, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC119, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$3, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC120, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$16, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC121, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$524287, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$8, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC122, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$131071, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$30, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$-32, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC123, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$28, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC124, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC125, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$127, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-20(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC126, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$524287, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC127, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$1, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC128, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$8388607, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$3968, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$48, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC129, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC130, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC131, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$15, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC132, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$1048568, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC133, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -27(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -26(%rbp)
	movzbl	-25(%rbp), %eax
	orl	$7, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -24(%rbp)
	movzbl	-23(%rbp), %eax
	orl	$3, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC134, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$4, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC135, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$126, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16256, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC136, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$28, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$15, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC137, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC138, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$2, %esi
	movl	$.LC139, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC140, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8190, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$127, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$3, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$3, %edx
	movl	$1, %esi
	movl	$.LC141, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC142, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC143, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$126, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -27(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$127, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC144, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$4, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$127, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC145, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$992, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$523264, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC146, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1920, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$120, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$536838144, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC147, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -28(%rbp)
	movzwl	-26(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC148, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC149, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$64, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$1, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC150, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$28, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC151, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$60, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC152, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC153, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$524032, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$8, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC154, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$504, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$62, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$536854528, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$2, %esi
	movl	$.LC155, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$56, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC156, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$120, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC157, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$124, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$1073741696, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC158, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$536870656, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$3, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$3, %edx
	movl	$1, %esi
	movl	$.LC159, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC160, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2046, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$8, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$4190208, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC161, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$2097151, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC162, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$8176, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC163, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$6, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC164, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2046, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$3, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC165, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1920, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$7, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC166, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC167, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$62, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC168, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC169, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC170, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$536870784, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC171, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$96, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$384, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC172, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$-2, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$63, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC173, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$131071, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-22(%rbp), %eax
	orw	$1020, %ax
	movw	%ax, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC174, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$4, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC175, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$2097150, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC176, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC177, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$64, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC178, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$536870911, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$1, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$62, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC179, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$6, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$2, %esi
	movl	$.LC180, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$15, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC181, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-64, %eax
	movw	%ax, -32(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$124, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC182, %edi
	call	print_prologue
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$1, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$126, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC183, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC184, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$32, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$4032, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC185, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$127, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$3968, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$48, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC186, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC187, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$63, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16320, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC188, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC189, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$127, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC190, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$16777215, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$15, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC191, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$67108862, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC192, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$14, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC193, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$6, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8176, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$3, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$3, %edx
	movl	$1, %esi
	movl	$.LC194, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC195, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$63, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC196, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8128, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$2, %esi
	movl	$.LC197, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$7, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC198, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$120, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC199, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$15, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC200, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC201, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$2, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$124, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC202, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$32766, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC203, %edi
	call	print_prologue
	movb	$1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$63, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -24(%rbp)
	movzbl	-22(%rbp), %eax
	orl	$3, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$124, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC204, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$8, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC205, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1008, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC206, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$131071, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC207, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC208, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$510, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC209, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$131071, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$62, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$448, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$2, %esi
	movl	$.LC210, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$4, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC211, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$4, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC212, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$384, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC213, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC214, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$60, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC215, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$127, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC216, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$63, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$114688, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC217, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC218, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$31, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC219, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16376, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC220, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2046, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC221, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$48, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$245760, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC222, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$262140, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$4, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC223, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$4, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC224, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC225, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$28, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC226, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$15, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC227, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$127, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC228, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$63, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC229, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$127, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC230, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$1, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC231, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC232, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-128, %eax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$1, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC233, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1920, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC234, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2044, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$536870911, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$-32, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC235, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$14, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1008, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$124, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC236, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$63, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$7, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC237, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$30, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$15, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC238, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$8388607, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$384, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$126, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC239, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC240, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-32, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$63, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC241, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC242, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$67100672, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC243, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$508, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC244, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$896, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$3, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC245, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$8, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC246, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC247, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$126, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16256, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC248, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC249, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$524284, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC250, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$127, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC251, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$30, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4064, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC252, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$24, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC253, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$2097151, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$2016, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$8, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC254, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$8388607, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$1, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$30, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC255, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$63, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC256, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC257, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$96, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$262016, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC258, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC259, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC260, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC261, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$96, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC262, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC263, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$15, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC264, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16380, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC265, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC266, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$62, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC267, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-22(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC268, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32766, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC269, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC270, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$2097151, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$16352, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC271, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$261888, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC272, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$63, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$16777215, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC273, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$31, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$63, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC274, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$1, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC275, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC276, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC277, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$7, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC278, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC279, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$16, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$32, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC280, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$6, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$8, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC281, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$3, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -30(%rbp)
	movzbl	-29(%rbp), %eax
	orl	$3, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC282, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$64, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC283, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$6, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC284, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$12, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC285, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$56, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC286, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$6, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$120, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC287, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$28, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$96, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC288, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2147483646, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC289, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -32(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$112, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC290, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC291, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$384, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$523264, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC292, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC293, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$67108862, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$4193280, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$64, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC294, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$1, %esi
	movl	$.LC295, %edi
	call	print_prologue
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$1, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$6, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC296, %edi
	call	print_prologue
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC297, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC298, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16380, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC299, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$24, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC300, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$8388607, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32640, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4080, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC301, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8190, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$3, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC302, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$6, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$127, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC303, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC304, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$3, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC305, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$3, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$4, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -27(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -26(%rbp)
	movzbl	-25(%rbp), %eax
	orl	$31, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC306, %edi
	call	print_prologue
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$63, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$64, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC307, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC308, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$127, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$67076096, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$12, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC309, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$60, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$32704, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC310, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2040, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$56, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC311, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1016, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$60, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC312, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$56, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC313, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC314, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC315, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$127, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC316, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$1, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC317, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$7, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$24, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC318, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$32764, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC319, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC320, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$63, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC321, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -27(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$63, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC322, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-2, %eax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$7, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC323, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$124, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC324, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$536870908, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$96, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC325, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$63, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC326, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$124, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC327, %edi
	call	print_prologue
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-21(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -21(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-20(%rbp), %eax
	orl	$262143, %eax
	movl	%eax, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC328, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC329, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$2, %esi
	movl	$.LC330, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$14, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$127, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC331, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC332, %edi
	call	print_prologue
	movzbl	-31(%rbp), %eax
	orl	$64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$134217727, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-20(%rbp), %eax
	orl	$131071, %eax
	movl	%eax, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC333, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1020, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC334, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1984, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC335, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$384, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$4, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC336, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$3968, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC337, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$127, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC338, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -27(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -26(%rbp)
	movzbl	-25(%rbp), %eax
	orl	$31, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$32, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC339, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8188, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$12, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC340, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32764, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC341, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32640, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -28(%rbp)
	movzwl	-26(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC342, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$28, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC343, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$48, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC344, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$130816, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC345, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -23(%rbp)
	movzbl	-22(%rbp), %eax
	orl	$3, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC346, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC347, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$62, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$268435392, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC348, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC349, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$2, %esi
	movl	$.LC350, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$96, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC351, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$524256, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC352, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4092, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC353, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2080768, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16320, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC354, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC355, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$62, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC356, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$4194303, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$31, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC357, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC358, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC359, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$15, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC360, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8188, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$33546240, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$2, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC361, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-4, %eax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC362, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$127, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2064384, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC363, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$64, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC364, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC365, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$24, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC366, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$536870911, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$4, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC367, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$524287, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$4194303, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -24(%rbp)
	movzbl	-22(%rbp), %eax
	orl	$127, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$1, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$2, %esi
	movl	$.LC368, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC369, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16256, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC370, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$2032, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC371, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$127, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC372, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$2, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$1, %esi
	movl	$.LC373, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC374, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$3968, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$31, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC375, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$16777208, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$134217727, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC376, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-8, %eax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC377, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$63, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$8128, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC378, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$896, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC379, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$8388607, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC380, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$1, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$1, %esi
	movl	$.LC381, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$63, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC382, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orl	$-4, %eax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC383, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$24, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC384, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16256, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC385, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC386, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$524287, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$24, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC387, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$131071, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1020, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC388, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$30, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4032, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC389, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8064, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC390, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8190, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$253952, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$60, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC391, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC392, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-20(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC393, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$62, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC394, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$28, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4064, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC395, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$126, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC396, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1022, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$12, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC397, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC398, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$6, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$20, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$20, %edx
	movl	$4, %esi
	movl	$.LC399, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$134217727, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-16(%rbp), %eax
	orl	$1, %eax
	movb	%al, -16(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$10, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$10, %edx
	movl	$2, %esi
	movl	$.LC400, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$10, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$10, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$10, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$10, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC401, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC402, %edi
	call	print_prologue
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$127, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC403, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$63, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC404, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$262140, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$124, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC405, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$6, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC406, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC407, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$4, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC408, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$60, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC409, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2044, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$120, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC410, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$1, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC411, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$496, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$6, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC412, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$14, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC413, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$131071, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$510, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC414, %edi
	call	print_prologue
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$15, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$63, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC415, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16256, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC416, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC417, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$127, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC418, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$4, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC419, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$31, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC420, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC421, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC422, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$16, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$63, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC423, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$268419072, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$2, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC424, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$63, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$127, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC425, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$1, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC426, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$30, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1048560, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$10, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$10, %edx
	movl	$2, %esi
	movl	$.LC427, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$10, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$30, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$10, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$10, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$10, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC428, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$126, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$32, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC429, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$63, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$64, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC430, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2032, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC431, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$32764, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$268402688, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC432, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC433, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2147483632, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC434, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -28(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$63, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$64, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC435, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$536870911, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC436, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$28, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC437, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -27(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$63, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC438, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC439, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4094, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16352, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$16777215, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC440, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$7, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC441, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC442, %edi
	call	print_prologue
	movzbl	-31(%rbp), %eax
	orl	$63, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$7, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC443, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$3, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$12, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$4190208, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC444, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$63, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$262080, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$28, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC445, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$14, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC446, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$536870908, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC447, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$4194303, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$63, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC448, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$268435328, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$134217727, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC449, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-4, %eax
	movw	%ax, -32(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC450, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$992, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$28, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC451, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$30, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC452, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$2, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC453, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$2, %esi
	movl	$.LC454, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$1, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC455, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$4194176, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC456, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC457, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$124, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC458, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-32, %eax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC459, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC460, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$496, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC461, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$33554424, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$2, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC462, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$31, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC463, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$-128, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$48, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC464, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16382, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC465, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$63, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$1, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$1, %edx
	movl	$1, %esi
	movl	$.LC466, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$1, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$1, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$1, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$1, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC467, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$16777215, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$1, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC468, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC469, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$131008, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$62, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1984, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC470, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2147483520, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$8, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$16, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC471, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$30, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$32, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC472, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$3, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC473, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC474, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$30, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC475, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32752, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC476, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$127, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC477, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$6, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$120, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$8064, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC478, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$8, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$16, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC479, %edi
	call	print_prologue
	movzbl	-31(%rbp), %eax
	orl	$3, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$4, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$24, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC480, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC481, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC482, %edi
	call	print_prologue
	movzbl	-31(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -30(%rbp)
	movzbl	-29(%rbp), %eax
	orl	$1, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$7, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -24(%rbp)
	movzbl	-23(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -23(%rbp)
	movzbl	-22(%rbp), %eax
	orl	$63, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC483, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16382, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC484, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$30, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$32, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC485, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$992, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$8387584, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$1, %esi
	movl	$.LC486, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$127, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC487, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC488, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$33554416, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC489, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC490, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$1073741822, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC491, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$20, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$20, %edx
	movl	$4, %esi
	movl	$.LC492, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$1, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -16(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC493, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$16, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$2, %esi
	movl	$.LC494, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$6, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$32, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC495, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC496, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$67108800, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$120, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC497, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$131068, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$6, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC498, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$134217727, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-20(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC499, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$28, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC500, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1016, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$12, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$112, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC501, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$4, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC502, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8184, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC503, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$56, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$67108800, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC504, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$15, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$112, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2147450880, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC505, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$63, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$1984, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC506, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$62, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$31, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC507, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC508, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC509, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$12, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC510, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$15, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2147479552, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC511, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC512, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2044, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC513, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$32736, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$2, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC514, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$384, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$62, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC515, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$7, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC516, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$2, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC517, %edi
	call	print_prologue
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$63, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$-64, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC518, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$14, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$508, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC519, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC520, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$536870911, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-32, %eax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$127, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC521, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC522, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$127, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$67076096, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC523, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$96, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC524, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$2096640, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$32, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC525, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$126, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$15, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC526, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC527, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$67104768, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC528, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$16, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$2016, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$1, %esi
	movl	$.LC529, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC530, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC531, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$28, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$96, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC532, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -28(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$7, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC533, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$63, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC534, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC535, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8176, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC536, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$1048568, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$2, %esi
	movl	$.LC537, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$28, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC538, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$524287, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC539, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$4194303, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$64, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC540, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$536870904, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC541, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC542, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$48, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC543, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$120, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$7, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC544, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$8388096, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC545, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$1, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$1, %esi
	movl	$.LC546, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC547, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$8, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC548, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$24, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$96, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC549, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$524287, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$3, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC550, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC551, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$24, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2016, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC552, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC553, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC554, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$262143, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$32, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC555, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$262128, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC556, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2046, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC557, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$30, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC558, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16382, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2080768, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$524287, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC559, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC560, %edi
	call	print_prologue
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$8, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$496, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$126, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC561, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$127, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$2, %esi
	movl	$.LC562, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$28, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC563, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$31, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC564, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$32, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC565, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-22(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC566, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC567, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$14, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC568, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$8388607, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$63, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC569, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4064, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2093056, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16320, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC570, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$60, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$33554368, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC571, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$14, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC572, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1008, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$60, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC573, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC574, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$134217727, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$63, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$31, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC575, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$262112, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$508, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC576, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2044, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$129024, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$6, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC577, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1008, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC578, %edi
	call	print_prologue
	movzbl	-31(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$64, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC579, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$7, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC580, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$491520, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$524287, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC581, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$3, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -30(%rbp)
	movzbl	-29(%rbp), %eax
	orl	$1, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$7, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC582, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$7, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC583, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$63, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC584, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$15, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC585, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$15, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC586, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$56, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC587, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$127, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$4194303, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC588, %edi
	call	print_prologue
	movzbl	-30(%rbp), %eax
	orl	$48, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$127, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC589, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC590, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC591, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$28, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$67100672, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$124, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC592, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$1, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$2, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC593, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$7, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC594, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$6, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC595, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4032, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$4194303, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$1984, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC596, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC597, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$992, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC598, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-4, %eax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC599, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$32, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC600, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$62, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC601, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC602, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -27(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$127, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC603, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$131071, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC604, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32736, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC605, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$4194303, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$7, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$8, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$48, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC606, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$28, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16352, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC607, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$4194288, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC608, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC609, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-4, %eax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC610, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC611, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC612, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$30, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC613, %edi
	call	print_prologue
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-21(%rbp), %eax
	orl	$15, %eax
	movb	%al, -21(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC614, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -28(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$3, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$4, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC615, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$96, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$134217600, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$63, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC616, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC617, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$48, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC618, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$536870911, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC619, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-20(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC620, %edi
	call	print_prologue
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$124, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-128, %eax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC621, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$48, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC622, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-8, %eax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$2, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC623, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -32(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$127, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$127, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC624, %edi
	call	print_prologue
	movzbl	-31(%rbp), %eax
	orl	$124, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-21(%rbp), %eax
	orl	$4, %eax
	movb	%al, -21(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$2, %esi
	movl	$.LC625, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$3, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$124, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC626, %edi
	call	print_prologue
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$2, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC627, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$33538048, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$4, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$120, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC628, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$536870911, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$7, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$120, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC629, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$48, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$4194176, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC630, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$6, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$8, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC631, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$120, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC632, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$536870910, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC633, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$384, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$2, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC634, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-32, %eax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC635, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$127, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC636, %edi
	call	print_prologue
	movzbl	-31(%rbp), %eax
	orl	$4, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$120, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$2, %esi
	movl	$.LC637, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC638, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$14, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$992, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$1, %esi
	movl	$.LC639, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$56, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC640, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC641, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$16777212, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC642, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$96, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC643, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$7, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC644, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$62, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$384, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC645, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$63, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -27(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -26(%rbp)
	movzbl	-25(%rbp), %eax
	orl	$7, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC646, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC647, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$30, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC648, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC649, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$8388607, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$1, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC650, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC651, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$14, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$48, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC652, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$15, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC653, %edi
	call	print_prologue
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$16, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC654, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2088960, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC655, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-64, %eax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC656, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$3, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC657, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$510, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC658, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2147475456, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC659, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$-64, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC660, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4088, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC661, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2044, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC662, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$63, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$64, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC663, %edi
	call	print_prologue
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$4194303, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$64, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC664, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$16, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC665, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$48, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC666, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC667, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$1, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC668, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC669, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$16775168, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC670, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8188, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$2, %esi
	movl	$.LC671, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$15, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC672, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$15, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -27(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$63, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -26(%rbp)
	movzbl	-25(%rbp), %eax
	orl	$7, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC673, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$126, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC674, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$8388352, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC675, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$127, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC676, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32640, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC677, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$1, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC678, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$8064, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$63, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC679, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$62, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC680, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$131071, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$6, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$8, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC681, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$2, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4092, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC682, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC683, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$1, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC684, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$2044, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC685, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-21(%rbp), %eax
	orl	$31, %eax
	movb	%al, -21(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC686, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$127, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC687, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC688, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$127, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC689, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$31, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$32, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC690, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$1015808, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$48, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$960, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$20, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$20, %edx
	movl	$4, %esi
	movl	$.LC691, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-16(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -16(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC692, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$508, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC693, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$63, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16320, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$112, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC694, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC695, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8160, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$6, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC696, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC697, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$4, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$504, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC698, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1022, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$28, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC699, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$28, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$16777184, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$63, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC700, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$48, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC701, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$134217727, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$2, %esi
	movl	$.LC702, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$24, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC703, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$384, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC704, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC705, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$31, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC706, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC707, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$96, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC708, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC709, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC710, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$63, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$127, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC711, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2097088, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC712, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$536870911, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$2, %esi
	movl	$.LC713, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$15, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC714, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16376, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC715, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$24, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC716, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1984, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2095104, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC717, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$131064, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$6, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC718, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$6, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC719, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$30, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC720, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC721, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$1, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orl	$-2, %eax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC722, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC723, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC724, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$8, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC725, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2032, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$24, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC726, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$127, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$30, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$32, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC727, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$63, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC728, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$127, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$127, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC729, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$6, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC730, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC731, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$3, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -27(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -26(%rbp)
	movzbl	-25(%rbp), %eax
	orl	$31, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC732, %edi
	call	print_prologue
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$1, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC733, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1920, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC734, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC735, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$120, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC736, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$6, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$120, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16256, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC737, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC738, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2147483392, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC739, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$253952, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$4, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC740, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC741, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-19(%rbp), %eax
	orl	$15, %eax
	movb	%al, -19(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC742, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC743, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$496, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC744, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$6, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -30(%rbp)
	movzbl	-29(%rbp), %eax
	orl	$127, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC745, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$1022, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$2, %esi
	movl	$.LC746, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$24, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC747, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC748, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$131071, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$32, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC749, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$2, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4092, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC750, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -32(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$24, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC751, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC752, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$63, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC753, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$2097088, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$32, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$64, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC754, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32760, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC755, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1016, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC756, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$126976, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$2, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC757, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC758, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$4194303, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$127, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC759, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$67092480, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$16777215, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$3, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC760, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC761, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$2, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$28, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC762, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$15, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC763, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$48, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC764, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC765, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-20(%rbp), %eax
	orl	$536870911, %eax
	movl	%eax, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC766, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$510, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC767, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$16777215, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$1, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$30, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC768, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$48, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC769, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$15, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC770, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC771, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$134217712, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$262143, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC772, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC773, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$63, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$64, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC774, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$536870904, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -24(%rbp)
	movzbl	-22(%rbp), %eax
	orl	$15, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC775, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$229376, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC776, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$4194303, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC777, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4094, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC778, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$32766, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC779, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC780, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$131070, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$126, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC781, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2097024, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC782, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$24, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC783, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8160, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC784, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$6, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$24, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC785, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4092, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$8388607, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC786, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$14, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC787, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC788, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC789, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16320, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$33538048, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC790, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC791, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8064, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC792, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$63, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$1, %esi
	movl	$.LC793, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$30, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC794, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4094, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC795, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$124, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC796, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4088, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$127, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC797, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$8388607, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$7, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$8, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC798, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$16777214, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$1, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$3, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$2, %esi
	movl	$.LC799, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$31, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC800, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC801, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$1, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC802, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$2, %esi
	movl	$.LC803, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$63, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC804, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$2097136, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$127, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$24, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$24, %edx
	movl	$4, %esi
	movl	$.LC805, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$24, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$24, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-20(%rbp), %eax
	orl	$1073740800, %eax
	movl	%eax, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$24, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-12(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -12(%rbp)
	movzbl	-10(%rbp), %eax
	orl	$7, %eax
	movb	%al, -10(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$24, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC806, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC807, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$8388607, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC808, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -32(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$536870911, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$32, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC809, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-2, %eax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC810, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$16, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$96, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC811, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$63, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC812, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$16, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC813, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1016, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$261120, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$60, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC814, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$3, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$16, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC815, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$7, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC816, %edi
	call	print_prologue
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$14, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-20(%rbp), %eax
	orw	$4080, %ax
	movw	%ax, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC817, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$60, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$8128, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC818, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$6, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2147483640, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC819, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC820, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC821, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$262143, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$16, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$3, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC822, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC823, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC824, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$1920, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$24, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC825, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$2, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC826, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$15, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC827, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-2, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -27(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$31, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC828, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC829, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2032, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$8, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC830, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$4, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$3, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC831, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$896, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC832, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$96, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC833, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$30, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$480, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$268434944, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC834, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$33554428, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$31, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC835, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$1, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC836, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2097148, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$131071, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC837, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$14, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16368, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2080768, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC838, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$536870656, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC839, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC840, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$536870784, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC841, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$134217696, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$8, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$16, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC842, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$32760, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC843, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$15, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC844, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -28(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$6, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$6, %edx
	movl	$2, %esi
	movl	$.LC845, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-4, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$6, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC846, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$14, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC847, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-2, %eax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC848, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8160, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$96, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$98304, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC849, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$6, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$120, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC850, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$126, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$2, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$268435452, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC851, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1016, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC852, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-4, %eax
	movw	%ax, -32(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$4, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC853, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC854, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2032, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC855, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC856, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$124, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$112, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC857, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$15, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$262128, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC858, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$127, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC859, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$31, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$96, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC860, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC861, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2096128, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC862, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$127, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC863, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$33554431, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC864, %edi
	call	print_prologue
	movzbl	-29(%rbp), %eax
	orl	$127, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$60, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC865, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$30, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$96, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC866, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC867, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC868, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$2097148, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$32736, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC869, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2044, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC870, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$20, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$20, %edx
	movl	$4, %esi
	movl	$.LC871, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-16(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -16(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC872, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8190, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$-8192, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC873, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$8, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$16, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC874, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$48, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC875, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$4, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$24, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC876, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$96, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$1073741823, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC877, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC878, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$134217727, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC879, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$510, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$14, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC880, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$508, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC881, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$134217727, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$134217727, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-21(%rbp), %eax
	orl	$56, %eax
	movb	%al, -21(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC882, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$3, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC883, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$4194302, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$1, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC884, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$56, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4032, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC885, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$8388606, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC886, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$24, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC887, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$126, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$130944, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$1022, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC888, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$1, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$2, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC889, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$2, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$127, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC890, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$3968, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-22(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC891, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$63, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC892, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$30, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-32, %eax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC893, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$63, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC894, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC895, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$120, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$134217727, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC896, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$30, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$96, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC897, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$63, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC898, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$31, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$16, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC899, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$3, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -30(%rbp)
	movzbl	-29(%rbp), %eax
	orl	$3, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$6, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC900, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$6, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC901, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$524287, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$1016, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC902, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$127, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC903, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$16376, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC904, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$24, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$2097151, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC905, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2044, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$7, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC906, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$262143, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$12, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$16, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$2, %esi
	movl	$.LC907, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$28, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$32, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC908, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-23(%rbp), %eax
	orl	$16, %eax
	movb	%al, -23(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC909, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$24, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC910, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$127, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC911, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$63, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32704, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$2, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$2, %edx
	movl	$2, %esi
	movl	$.LC912, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$124, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$7, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$2, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC913, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2046, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$8, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC914, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$32752, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC915, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$1, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC916, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orl	$-16, %eax
	movw	%ax, -32(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC917, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$508, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$1, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC918, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$2040, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$8, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$15, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC919, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC920, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$127, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$3, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC921, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16256, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$64, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC922, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC923, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC924, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32766, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC925, %edi
	call	print_prologue
	movzbl	-28(%rbp), %eax
	orl	$127, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$7, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$8, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC926, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$31, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC927, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$56, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC928, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$63, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$8128, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$-32, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC929, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$14, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4064, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC930, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$8, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC931, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC932, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$96, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC933, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC934, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$96, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2097024, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC935, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-22(%rbp), %eax
	orw	$8128, %ax
	movw	%ax, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC936, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$32, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$2147483647, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$7, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC937, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$96, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC938, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$6, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC939, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$2, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC940, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$8188, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC941, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$30, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$992, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$1047552, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC942, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$1022, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$60, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC943, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$1048575, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-16, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$15, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$16, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC944, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$16, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$-32, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC945, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$127, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$1920, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC946, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$4194303, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC947, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$127, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$33521664, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC948, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$1, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$2, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orl	$-4, %eax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC949, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$127, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orl	$-128, %eax
	movw	%ax, -24(%rbp)
	movzbl	-22(%rbp), %eax
	orl	$1, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC950, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$134217724, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC951, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC952, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$56, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$268435455, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$48, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$134217727, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC953, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC954, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC955, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$8, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$258048, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$60, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC956, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$3, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2147482624, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC957, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$1, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$126, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -30(%rbp)
	movzbl	-29(%rbp), %eax
	orl	$1, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC958, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$4194303, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC959, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$1023, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$1047552, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$2, %esi
	movl	$.LC960, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$20, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$20, %edx
	movl	$4, %esi
	movl	$.LC961, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -24(%rbp)
	movzbl	-22(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-16(%rbp), %eax
	orl	$15, %eax
	movb	%al, -16(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$20, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC962, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$3, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$1020, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$4, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC963, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$67108863, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$28, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC964, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC965, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$3, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -27(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$127, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC966, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$3, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-22(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC967, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$96, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -28(%rbp)
	movzwl	-26(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC968, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$33554430, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$3, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC969, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$67108800, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-27(%rbp), %eax
	orl	$3, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC970, %edi
	call	print_prologue
	movw	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$3, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orl	$-1, %eax
	movw	%ax, -28(%rbp)
	movzbl	-26(%rbp), %eax
	orl	$7, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$2040, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC971, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$60, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$15, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC972, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$268435454, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC973, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$-8, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$126, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-28(%rbp), %eax
	orl	$268435328, %eax
	movl	%eax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC974, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-22(%rbp), %eax
	orl	$3, %eax
	movb	%al, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$16, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$16, %edx
	movl	$4, %esi
	movl	$.LC975, %edi
	call	print_prologue
	movl	-32(%rbp), %eax
	orl	$536870911, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movw	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-20(%rbp), %eax
	orl	$127, %eax
	movb	%al, -20(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$16, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC976, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$60, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$64, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC977, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$126, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$15, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC978, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-24(%rbp), %eax
	orw	$16383, %ax
	movw	%ax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -22(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC979, %edi
	call	print_prologue
	movb	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$384, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC980, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$2, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$12, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$16, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC981, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$32, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC982, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$126976, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$62, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$16320, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC983, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$1, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-24(%rbp), %eax
	orl	$262142, %eax
	movl	%eax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC984, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$448, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$32, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$7, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC985, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$4, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$56, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC986, %edi
	call	print_prologue
	movb	$1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -31(%rbp)
	movzbl	-30(%rbp), %eax
	orl	$7, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-8, %eax
	movb	%al, -30(%rbp)
	movzbl	-29(%rbp), %eax
	orl	$31, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$-1, %eax
	movb	%al, -28(%rbp)
	movzbl	-27(%rbp), %eax
	orl	$15, %eax
	movb	%al, -27(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC987, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$7, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC988, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movb	$-1, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$8191, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC989, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4080, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC990, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4092, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$31, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$480, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$3, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$3, %edx
	movl	$1, %esi
	movl	$.LC991, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$7, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$63, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$3, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC992, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$6, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$24, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC993, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-28(%rbp), %eax
	orl	$1, %eax
	movb	%al, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$7, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC994, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movw	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$1, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-26(%rbp), %eax
	orw	$510, %ax
	movw	%ax, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC995, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$63, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4032, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$1040384, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC996, %edi
	call	print_prologue
	movzwl	-32(%rbp), %eax
	orw	$2047, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-30(%rbp), %eax
	orw	$511, %ax
	movw	%ax, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$2, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$4095, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$12, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$12, %edx
	movl	$4, %esi
	movl	$.LC997, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$112, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movl	$-1, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-24(%rbp), %eax
	orl	$31, %eax
	movb	%al, -24(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$12, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC998, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$48, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4032, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$16, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC999, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$3, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$63, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$127, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$8, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$8, %edx
	movl	$4, %esi
	movl	$.LC1000, %edi
	call	print_prologue
	movl	$-1, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-28(%rbp), %eax
	orw	$32767, %ax
	movw	%ax, -28(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-26(%rbp), %eax
	orl	$63, %eax
	movb	%al, -26(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-25(%rbp), %eax
	orl	$1, %eax
	movb	%al, -25(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$8, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC1001, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$31, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$96, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-32(%rbp), %eax
	orl	$-128, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-31(%rbp), %eax
	orl	$127, %eax
	movb	%al, -31(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$2, %esi
	movl	$.LC1002, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$15, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movzwl	-32(%rbp), %eax
	orw	$4080, %ax
	movw	%ax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movb	$-1, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-29(%rbp), %eax
	orl	$15, %eax
	movb	%al, -29(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	leaq	-32(%rbp), %rax
	movl	$4, %edx
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset
	movl	$4, %edx
	movl	$4, %esi
	movl	$.LC1003, %edi
	call	print_prologue
	movzbl	-32(%rbp), %eax
	orl	$1, %eax
	movb	%al, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$1, %edi
	call	print_next_field
	movl	-32(%rbp), %eax
	orl	$2097150, %eax
	movl	%eax, -32(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$32, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	movzbl	-30(%rbp), %eax
	orl	$-64, %eax
	movb	%al, -30(%rbp)
	leaq	-32(%rbp), %rax
	movq	%rax, %rdx
	movl	$4, %esi
	movl	$0, %edi
	call	print_next_field
	call	print_epilogue
	movl	$0, %eax
	movq	-8(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L19
	call	__stack_chk_fail
.L19:
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.size	main, .-main
	.local	pos.1
	.comm	pos.1,4,4
	.section	.rodata
	.align 16
	.type	__PRETTY_FUNCTION__.0, @object
	.size	__PRETTY_FUNCTION__.0, 17
__PRETTY_FUNCTION__.0:
	.string	"print_next_field"
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
