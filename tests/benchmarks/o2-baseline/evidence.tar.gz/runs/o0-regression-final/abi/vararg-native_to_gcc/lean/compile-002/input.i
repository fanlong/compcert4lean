# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c"
# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 1
# 43 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h"
typedef __builtin_va_list __gnuc_va_list;
# 59 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h"
typedef __builtin_va_list va_list;
# 2 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c" 2
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 29 "/usr/include/stdio.h" 2 3 4









# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4

# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef unsigned long size_t;
# 39 "/usr/include/stdio.h" 2 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 45 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 46 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 47 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 48 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 2 3 4

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2:24;

  char _short_backupbuf[1];
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;

  int _unused3;

  __uint64_t _total_written;




  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
# 49 "/usr/include/stdio.h" 2 3 4
# 89 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;
# 133 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 134 "/usr/include/stdio.h" 2 3 4
# 153 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) ;

extern int rename (const char *__old, const char *__new) ;
# 191 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) ;
# 201 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  ;
# 218 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) ;
# 243 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 271 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *restrict __filename,
      const char *restrict __modes)
  ;




extern FILE *freopen (const char *restrict __filename,
        const char *restrict __modes,
        FILE *restrict __stream) ;
# 341 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *restrict __stream, char *restrict __buf)
  ;



extern int setvbuf (FILE *restrict __stream, char *restrict __buf,
      int __modes, size_t __n) ;
# 364 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *restrict __stream,
      const char *restrict __format, ...) ;




extern int printf (const char *restrict __format, ...);

extern int sprintf (char *restrict __s,
      const char *restrict __format, ...) ;





extern int vfprintf (FILE *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;




extern int vprintf (const char *restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;



extern int snprintf (char *restrict __s, size_t __maxlen,
       const char *restrict __format, ...)
     ;

extern int vsnprintf (char *restrict __s, size_t __maxlen,
        const char *restrict __format, __gnuc_va_list __arg)
     ;
# 429 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *restrict __stream,
     const char *restrict __format, ...) ;




extern int scanf (const char *restrict __format, ...) ;

extern int sscanf (const char *restrict __s,
     const char *restrict __format, ...) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 445 "/usr/include/stdio.h" 2 3 4
# 479 "/usr/include/stdio.h" 3 4
extern int __isoc99_fscanf (FILE *restrict __stream,
       const char *restrict __format, ...)
  ;
extern int __isoc99_scanf (const char *restrict __format, ...) ;
extern int __isoc99_sscanf (const char *restrict __s,
       const char *restrict __format, ...) ;
# 497 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *restrict __s, const char *restrict __format,
      __gnuc_va_list __arg)
     ;





extern int vscanf (const char *restrict __format, __gnuc_va_list __arg)
     ;


extern int vsscanf (const char *restrict __s,
      const char *restrict __format, __gnuc_va_list __arg)
     ;
# 561 "/usr/include/stdio.h" 3 4
extern int __isoc99_vfscanf (FILE *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
extern int __isoc99_vscanf (const char *restrict __format,
       __gnuc_va_list __arg) ;
extern int __isoc99_vsscanf (const char *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
# 582 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) ;
extern int getc (FILE *__stream) ;





extern int getchar (void);
# 615 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) ;
extern int putc (int __c, FILE *__stream) ;





extern int putchar (int __c);
# 658 "/usr/include/stdio.h" 3 4
extern char *fgets (char *restrict __s, int __n, FILE *restrict __stream)
     ;
# 671 "/usr/include/stdio.h" 3 4
extern char *gets (char *__s) ;
# 711 "/usr/include/stdio.h" 3 4
extern int fputs (const char *restrict __s, FILE *restrict __stream)
  ;





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) ;






extern size_t fread (void *restrict __ptr, size_t __size,
       size_t __n, FILE *restrict __stream)
  ;




extern size_t fwrite (const void *restrict __ptr, size_t __size,
        size_t __n, FILE *restrict __s) ;
# 773 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  ;




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream) ;
# 823 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *restrict __stream, fpos_t *restrict __pos)
  ;




extern int fsetpos (FILE *__stream, const fpos_t *__pos) ;
# 854 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) ;

extern int feof (FILE *__stream) ;

extern int ferror (FILE *__stream) ;
# 872 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) ;
# 953 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 977 "/usr/include/stdio.h" 3 4

# 3 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4


# 37 "/usr/include/string.h" 3 4
# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 38 "/usr/include/string.h" 2 3 4
# 47 "/usr/include/string.h" 3 4
extern void *memcpy (void *restrict __dest, const void *restrict __src,
       size_t __n) ;


extern void *memmove (void *__dest, const void *__src, size_t __n)
     ;
# 65 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) ;
# 75 "/usr/include/string.h" 3 4
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     ;
# 91 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     ;
# 118 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      ;
# 156 "/usr/include/string.h" 3 4
extern char *strcpy (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncpy (char *restrict __dest,
        const char *restrict __src, size_t __n)
     ;


extern char *strcat (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncat (char *restrict __dest, const char *restrict __src,
        size_t __n) ;


extern int strcmp (const char *__s1, const char *__s2)
     ;

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     ;


extern int strcoll (const char *__s1, const char *__s2)
     ;

extern size_t strxfrm (char *restrict __dest,
         const char *restrict __src, size_t __n)
    ;
# 261 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     ;
# 292 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     ;
# 316 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     ;


extern size_t strspn (const char *__s, const char *__accept)
     ;
# 346 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     ;
# 377 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     ;
# 388 "/usr/include/string.h" 3 4
extern char *strtok (char *restrict __s, const char *restrict __delim)
     ;



extern char *__strtok_r (char *restrict __s,
    const char *restrict __delim,
    char **restrict __save_ptr)
     ;
# 439 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     ;
# 451 "/usr/include/string.h" 3 4
extern char *strerror (int __errnum) ;
# 584 "/usr/include/string.h" 3 4

# 4 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c" 2
# 1 "/usr/include/unistd.h" 1 3 4
# 27 "/usr/include/unistd.h" 3 4

# 202 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/posix_opt.h" 1 3 4
# 203 "/usr/include/unistd.h" 2 3 4
# 220 "/usr/include/unistd.h" 3 4
typedef __ssize_t ssize_t;





# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 227 "/usr/include/unistd.h" 2 3 4
# 287 "/usr/include/unistd.h" 3 4
extern int access (const char *__name, int __type) ;
# 339 "/usr/include/unistd.h" 3 4
extern __off_t lseek (int __fd, __off_t __offset, int __whence) ;
# 358 "/usr/include/unistd.h" 3 4
extern int close (int __fd);
# 371 "/usr/include/unistd.h" 3 4
extern ssize_t read (int __fd, void *__buf, size_t __nbytes)
    ;





extern ssize_t write (int __fd, const void *__buf, size_t __n)
    ;
# 437 "/usr/include/unistd.h" 3 4
extern int pipe (int __pipedes[2]) ;
# 452 "/usr/include/unistd.h" 3 4
extern unsigned int alarm (unsigned int __seconds) ;
# 464 "/usr/include/unistd.h" 3 4
extern unsigned int sleep (unsigned int __seconds);
# 489 "/usr/include/unistd.h" 3 4
extern int pause (void);



extern int chown (const char *__file, __uid_t __owner, __gid_t __group)
     ;
# 517 "/usr/include/unistd.h" 3 4
extern int chdir (const char *__path) ;
# 531 "/usr/include/unistd.h" 3 4
extern char *getcwd (char *__buf, size_t __size) ;
# 552 "/usr/include/unistd.h" 3 4
extern int dup (int __fd) ;


extern int dup2 (int __fd, int __fd2) ;
# 564 "/usr/include/unistd.h" 3 4
extern char **__environ;







extern int execve (const char *__path, char *const __argv[],
     char *const __envp[]) ;
# 584 "/usr/include/unistd.h" 3 4
extern int execv (const char *__path, char *const __argv[])
     ;



extern int execle (const char *__path, const char *__arg, ...)
     ;



extern int execl (const char *__path, const char *__arg, ...)
     ;



extern int execvp (const char *__file, char *const __argv[])
     ;




extern int execlp (const char *__file, const char *__arg, ...)
     ;
# 624 "/usr/include/unistd.h" 3 4
extern void _exit (int __status) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/confname.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/confname.h" 3 4
enum
  {
    _PC_LINK_MAX,

    _PC_MAX_CANON,

    _PC_MAX_INPUT,

    _PC_NAME_MAX,

    _PC_PATH_MAX,

    _PC_PIPE_BUF,

    _PC_CHOWN_RESTRICTED,

    _PC_NO_TRUNC,

    _PC_VDISABLE,

    _PC_SYNC_IO,

    _PC_ASYNC_IO,

    _PC_PRIO_IO,

    _PC_SOCK_MAXBUF,

    _PC_FILESIZEBITS,

    _PC_REC_INCR_XFER_SIZE,

    _PC_REC_MAX_XFER_SIZE,

    _PC_REC_MIN_XFER_SIZE,

    _PC_REC_XFER_ALIGN,

    _PC_ALLOC_SIZE_MIN,

    _PC_SYMLINK_MAX,

    _PC_2_SYMLINKS

  };


enum
  {
    _SC_ARG_MAX,

    _SC_CHILD_MAX,

    _SC_CLK_TCK,

    _SC_NGROUPS_MAX,

    _SC_OPEN_MAX,

    _SC_STREAM_MAX,

    _SC_TZNAME_MAX,

    _SC_JOB_CONTROL,

    _SC_SAVED_IDS,

    _SC_REALTIME_SIGNALS,

    _SC_PRIORITY_SCHEDULING,

    _SC_TIMERS,

    _SC_ASYNCHRONOUS_IO,

    _SC_PRIORITIZED_IO,

    _SC_SYNCHRONIZED_IO,

    _SC_FSYNC,

    _SC_MAPPED_FILES,

    _SC_MEMLOCK,

    _SC_MEMLOCK_RANGE,

    _SC_MEMORY_PROTECTION,

    _SC_MESSAGE_PASSING,

    _SC_SEMAPHORES,

    _SC_SHARED_MEMORY_OBJECTS,

    _SC_AIO_LISTIO_MAX,

    _SC_AIO_MAX,

    _SC_AIO_PRIO_DELTA_MAX,

    _SC_DELAYTIMER_MAX,

    _SC_MQ_OPEN_MAX,

    _SC_MQ_PRIO_MAX,

    _SC_VERSION,

    _SC_PAGESIZE,


    _SC_RTSIG_MAX,

    _SC_SEM_NSEMS_MAX,

    _SC_SEM_VALUE_MAX,

    _SC_SIGQUEUE_MAX,

    _SC_TIMER_MAX,




    _SC_BC_BASE_MAX,

    _SC_BC_DIM_MAX,

    _SC_BC_SCALE_MAX,

    _SC_BC_STRING_MAX,

    _SC_COLL_WEIGHTS_MAX,

    _SC_EQUIV_CLASS_MAX,

    _SC_EXPR_NEST_MAX,

    _SC_LINE_MAX,

    _SC_RE_DUP_MAX,

    _SC_CHARCLASS_NAME_MAX,


    _SC_2_VERSION,

    _SC_2_C_BIND,

    _SC_2_C_DEV,

    _SC_2_FORT_DEV,

    _SC_2_FORT_RUN,

    _SC_2_SW_DEV,

    _SC_2_LOCALEDEF,


    _SC_PII,

    _SC_PII_XTI,

    _SC_PII_SOCKET,

    _SC_PII_INTERNET,

    _SC_PII_OSI,

    _SC_POLL,

    _SC_SELECT,

    _SC_UIO_MAXIOV,

    _SC_IOV_MAX = _SC_UIO_MAXIOV,

    _SC_PII_INTERNET_STREAM,

    _SC_PII_INTERNET_DGRAM,

    _SC_PII_OSI_COTS,

    _SC_PII_OSI_CLTS,

    _SC_PII_OSI_M,

    _SC_T_IOV_MAX,



    _SC_THREADS,

    _SC_THREAD_SAFE_FUNCTIONS,

    _SC_GETGR_R_SIZE_MAX,

    _SC_GETPW_R_SIZE_MAX,

    _SC_LOGIN_NAME_MAX,

    _SC_TTY_NAME_MAX,

    _SC_THREAD_DESTRUCTOR_ITERATIONS,

    _SC_THREAD_KEYS_MAX,

    _SC_THREAD_STACK_MIN,

    _SC_THREAD_THREADS_MAX,

    _SC_THREAD_ATTR_STACKADDR,

    _SC_THREAD_ATTR_STACKSIZE,

    _SC_THREAD_PRIORITY_SCHEDULING,

    _SC_THREAD_PRIO_INHERIT,

    _SC_THREAD_PRIO_PROTECT,

    _SC_THREAD_PROCESS_SHARED,


    _SC_NPROCESSORS_CONF,

    _SC_NPROCESSORS_ONLN,

    _SC_PHYS_PAGES,

    _SC_AVPHYS_PAGES,

    _SC_ATEXIT_MAX,

    _SC_PASS_MAX,


    _SC_XOPEN_VERSION,

    _SC_XOPEN_XCU_VERSION,

    _SC_XOPEN_UNIX,

    _SC_XOPEN_CRYPT,

    _SC_XOPEN_ENH_I18N,

    _SC_XOPEN_SHM,


    _SC_2_CHAR_TERM,

    _SC_2_C_VERSION,

    _SC_2_UPE,


    _SC_XOPEN_XPG2,

    _SC_XOPEN_XPG3,

    _SC_XOPEN_XPG4,


    _SC_CHAR_BIT,

    _SC_CHAR_MAX,

    _SC_CHAR_MIN,

    _SC_INT_MAX,

    _SC_INT_MIN,

    _SC_LONG_BIT,

    _SC_WORD_BIT,

    _SC_MB_LEN_MAX,

    _SC_NZERO,

    _SC_SSIZE_MAX,

    _SC_SCHAR_MAX,

    _SC_SCHAR_MIN,

    _SC_SHRT_MAX,

    _SC_SHRT_MIN,

    _SC_UCHAR_MAX,

    _SC_UINT_MAX,

    _SC_ULONG_MAX,

    _SC_USHRT_MAX,


    _SC_NL_ARGMAX,

    _SC_NL_LANGMAX,

    _SC_NL_MSGMAX,

    _SC_NL_NMAX,

    _SC_NL_SETMAX,

    _SC_NL_TEXTMAX,


    _SC_XBS5_ILP32_OFF32,

    _SC_XBS5_ILP32_OFFBIG,

    _SC_XBS5_LP64_OFF64,

    _SC_XBS5_LPBIG_OFFBIG,


    _SC_XOPEN_LEGACY,

    _SC_XOPEN_REALTIME,

    _SC_XOPEN_REALTIME_THREADS,


    _SC_ADVISORY_INFO,

    _SC_BARRIERS,

    _SC_BASE,

    _SC_C_LANG_SUPPORT,

    _SC_C_LANG_SUPPORT_R,

    _SC_CLOCK_SELECTION,

    _SC_CPUTIME,

    _SC_THREAD_CPUTIME,

    _SC_DEVICE_IO,

    _SC_DEVICE_SPECIFIC,

    _SC_DEVICE_SPECIFIC_R,

    _SC_FD_MGMT,

    _SC_FIFO,

    _SC_PIPE,

    _SC_FILE_ATTRIBUTES,

    _SC_FILE_LOCKING,

    _SC_FILE_SYSTEM,

    _SC_MONOTONIC_CLOCK,

    _SC_MULTI_PROCESS,

    _SC_SINGLE_PROCESS,

    _SC_NETWORKING,

    _SC_READER_WRITER_LOCKS,

    _SC_SPIN_LOCKS,

    _SC_REGEXP,

    _SC_REGEX_VERSION,

    _SC_SHELL,

    _SC_SIGNALS,

    _SC_SPAWN,

    _SC_SPORADIC_SERVER,

    _SC_THREAD_SPORADIC_SERVER,

    _SC_SYSTEM_DATABASE,

    _SC_SYSTEM_DATABASE_R,

    _SC_TIMEOUTS,

    _SC_TYPED_MEMORY_OBJECTS,

    _SC_USER_GROUPS,

    _SC_USER_GROUPS_R,

    _SC_2_PBS,

    _SC_2_PBS_ACCOUNTING,

    _SC_2_PBS_LOCATE,

    _SC_2_PBS_MESSAGE,

    _SC_2_PBS_TRACK,

    _SC_SYMLOOP_MAX,

    _SC_STREAMS,

    _SC_2_PBS_CHECKPOINT,


    _SC_V6_ILP32_OFF32,

    _SC_V6_ILP32_OFFBIG,

    _SC_V6_LP64_OFF64,

    _SC_V6_LPBIG_OFFBIG,


    _SC_HOST_NAME_MAX,

    _SC_TRACE,

    _SC_TRACE_EVENT_FILTER,

    _SC_TRACE_INHERIT,

    _SC_TRACE_LOG,


    _SC_LEVEL1_ICACHE_SIZE,

    _SC_LEVEL1_ICACHE_ASSOC,

    _SC_LEVEL1_ICACHE_LINESIZE,

    _SC_LEVEL1_DCACHE_SIZE,

    _SC_LEVEL1_DCACHE_ASSOC,

    _SC_LEVEL1_DCACHE_LINESIZE,

    _SC_LEVEL2_CACHE_SIZE,

    _SC_LEVEL2_CACHE_ASSOC,

    _SC_LEVEL2_CACHE_LINESIZE,

    _SC_LEVEL3_CACHE_SIZE,

    _SC_LEVEL3_CACHE_ASSOC,

    _SC_LEVEL3_CACHE_LINESIZE,

    _SC_LEVEL4_CACHE_SIZE,

    _SC_LEVEL4_CACHE_ASSOC,

    _SC_LEVEL4_CACHE_LINESIZE,



    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,

    _SC_RAW_SOCKETS,


    _SC_V7_ILP32_OFF32,

    _SC_V7_ILP32_OFFBIG,

    _SC_V7_LP64_OFF64,

    _SC_V7_LPBIG_OFFBIG,


    _SC_SS_REPL_MAX,


    _SC_TRACE_EVENT_NAME_MAX,

    _SC_TRACE_NAME_MAX,

    _SC_TRACE_SYS_MAX,

    _SC_TRACE_USER_EVENT_MAX,


    _SC_XOPEN_STREAMS,


    _SC_THREAD_ROBUST_PRIO_INHERIT,

    _SC_THREAD_ROBUST_PRIO_PROTECT,


    _SC_MINSIGSTKSZ,


    _SC_SIGSTKSZ

  };


enum
  {
    _CS_PATH,


    _CS_V6_WIDTH_RESTRICTED_ENVS,



    _CS_GNU_LIBC_VERSION,

    _CS_GNU_LIBPTHREAD_VERSION,


    _CS_V5_WIDTH_RESTRICTED_ENVS,



    _CS_V7_WIDTH_RESTRICTED_ENVS,



    _CS_LFS_CFLAGS = 1000,

    _CS_LFS_LDFLAGS,

    _CS_LFS_LIBS,

    _CS_LFS_LINTFLAGS,

    _CS_LFS64_CFLAGS,

    _CS_LFS64_LDFLAGS,

    _CS_LFS64_LIBS,

    _CS_LFS64_LINTFLAGS,


    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,

    _CS_XBS5_ILP32_OFF32_LDFLAGS,

    _CS_XBS5_ILP32_OFF32_LIBS,

    _CS_XBS5_ILP32_OFF32_LINTFLAGS,

    _CS_XBS5_ILP32_OFFBIG_CFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LIBS,

    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,

    _CS_XBS5_LP64_OFF64_CFLAGS,

    _CS_XBS5_LP64_OFF64_LDFLAGS,

    _CS_XBS5_LP64_OFF64_LIBS,

    _CS_XBS5_LP64_OFF64_LINTFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LIBS,

    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LIBS,

    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V6_LP64_OFF64_CFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LIBS,

    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LIBS,

    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V7_LP64_OFF64_CFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LIBS,

    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,


    _CS_V6_ENV,

    _CS_V7_ENV

  };
# 631 "/usr/include/unistd.h" 2 3 4


extern long int pathconf (const char *__path, int __name)
     ;


extern long int fpathconf (int __fd, int __name) ;


extern long int sysconf (int __name) ;
# 650 "/usr/include/unistd.h" 3 4
extern __pid_t getpid (void) ;


extern __pid_t getppid (void) ;


extern __pid_t getpgrp (void) ;


extern __pid_t __getpgid (__pid_t __pid) ;
# 668 "/usr/include/unistd.h" 3 4
extern int setpgid (__pid_t __pid, __pid_t __pgid) ;
# 689 "/usr/include/unistd.h" 3 4
extern __pid_t setsid (void) ;







extern __uid_t getuid (void) ;


extern __uid_t geteuid (void) ;


extern __gid_t getgid (void) ;


extern __gid_t getegid (void) ;




extern int getgroups (int __size, __gid_t __list[])
    ;
# 722 "/usr/include/unistd.h" 3 4
extern int setuid (__uid_t __uid) ;
# 739 "/usr/include/unistd.h" 3 4
extern int setgid (__gid_t __gid) ;
# 778 "/usr/include/unistd.h" 3 4
extern __pid_t fork (void) ;
# 799 "/usr/include/unistd.h" 3 4
extern char *ttyname (int __fd) ;



extern int ttyname_r (int __fd, char *__buf, size_t __buflen)
    
     ;



extern int isatty (int __fd) ;
# 819 "/usr/include/unistd.h" 3 4
extern int link (const char *__from, const char *__to)
     ;
# 858 "/usr/include/unistd.h" 3 4
extern int unlink (const char *__name) ;
# 867 "/usr/include/unistd.h" 3 4
extern int rmdir (const char *__path) ;



extern __pid_t tcgetpgrp (int __fd) ;


extern int tcsetpgrp (int __fd, __pid_t __pgrp_id) ;






extern char *getlogin (void);
# 989 "/usr/include/unistd.h" 3 4
extern int fsync (int __fd);
# 1221 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/unistd_ext.h" 1 3 4
# 1222 "/usr/include/unistd.h" 2 3 4


# 5 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_decl.h" 1







# 7 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_decl.h"
extern int failed;

static void failure(const char * assertion, const char * file,
                    int line, const char * fn)
{
  fprintf(
# 12 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_decl.h" 3 4
         stderr
# 12 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_decl.h"
               , "%s:%d:%s: assertion %s failed\n", file, line, fn, assertion);
  failed = 1;
}



extern void f1(int x0, int x1, ...);
extern void f2(int x0, int x1, ...);
extern void f3(int x0, int x1, ...);
extern void f4(int x0, long long x1, ...);
extern void f5(int x0, long long x1, ...);
extern void f6(int x0, long long x1, ...);
extern void f7(int x0, double x1, ...);
extern void f8(int x0, double x1, ...);
extern void f9(int x0, double x1, ...);
extern void f10(long long x0, int x1, ...);
extern void f11(long long x0, int x1, ...);
extern void f12(long long x0, int x1, ...);
extern void f13(long long x0, long long x1, ...);
extern void f14(long long x0, long long x1, ...);
extern void f15(long long x0, long long x1, ...);
extern void f16(long long x0, double x1, ...);
extern void f17(long long x0, double x1, ...);
extern void f18(long long x0, double x1, ...);
extern void f19(float x0, int x1, ...);
extern void f20(float x0, int x1, ...);
extern void f21(float x0, int x1, ...);
extern void f22(float x0, long long x1, ...);
extern void f23(float x0, long long x1, ...);
extern void f24(float x0, long long x1, ...);
extern void f25(float x0, double x1, ...);
extern void f26(float x0, double x1, ...);
extern void f27(float x0, double x1, ...);
extern void f28(double x0, int x1, ...);
extern void f29(double x0, int x1, ...);
extern void f30(double x0, int x1, ...);
extern void f31(double x0, long long x1, ...);
extern void f32(double x0, long long x1, ...);
extern void f33(double x0, long long x1, ...);
extern void f34(double x0, double x1, ...);
extern void f35(double x0, double x1, ...);
extern void f36(double x0, double x1, ...);
extern void f37(int x0, int x1, ...);
extern void f38(int x0, int x1, ...);
extern void f39(int x0, int x1, ...);
extern void f40(int x0, int x1, ...);
extern void f41(int x0, int x1, ...);
extern void f42(int x0, int x1, ...);
extern void f43(int x0, int x1, ...);
extern void f44(int x0, int x1, ...);
extern void f45(int x0, int x1, ...);
extern void f46(int x0, long long x1, ...);
extern void f47(int x0, long long x1, ...);
extern void f48(int x0, long long x1, ...);
extern void f49(int x0, long long x1, ...);
extern void f50(int x0, long long x1, ...);
extern void f51(int x0, long long x1, ...);
extern void f52(int x0, long long x1, ...);
extern void f53(int x0, long long x1, ...);
extern void f54(int x0, long long x1, ...);
extern void f55(int x0, double x1, ...);
extern void f56(int x0, double x1, ...);
extern void f57(int x0, double x1, ...);
extern void f58(int x0, double x1, ...);
extern void f59(int x0, double x1, ...);
extern void f60(int x0, double x1, ...);
extern void f61(int x0, double x1, ...);
extern void f62(int x0, double x1, ...);
extern void f63(int x0, double x1, ...);
extern void f64(long long x0, int x1, ...);
extern void f65(long long x0, int x1, ...);
extern void f66(long long x0, int x1, ...);
extern void f67(long long x0, int x1, ...);
extern void f68(long long x0, int x1, ...);
extern void f69(long long x0, int x1, ...);
extern void f70(long long x0, int x1, ...);
extern void f71(long long x0, int x1, ...);
extern void f72(long long x0, int x1, ...);
extern void f73(long long x0, long long x1, ...);
extern void f74(long long x0, long long x1, ...);
extern void f75(long long x0, long long x1, ...);
extern void f76(long long x0, long long x1, ...);
extern void f77(long long x0, long long x1, ...);
extern void f78(long long x0, long long x1, ...);
extern void f79(long long x0, long long x1, ...);
extern void f80(long long x0, long long x1, ...);
extern void f81(long long x0, long long x1, ...);
extern void f82(long long x0, double x1, ...);
extern void f83(long long x0, double x1, ...);
extern void f84(long long x0, double x1, ...);
extern void f85(long long x0, double x1, ...);
extern void f86(long long x0, double x1, ...);
extern void f87(long long x0, double x1, ...);
extern void f88(long long x0, double x1, ...);
extern void f89(long long x0, double x1, ...);
extern void f90(long long x0, double x1, ...);
extern void f91(float x0, int x1, ...);
extern void f92(float x0, int x1, ...);
extern void f93(float x0, int x1, ...);
extern void f94(float x0, int x1, ...);
extern void f95(float x0, int x1, ...);
extern void f96(float x0, int x1, ...);
extern void f97(float x0, int x1, ...);
extern void f98(float x0, int x1, ...);
extern void f99(float x0, int x1, ...);
extern void f100(float x0, long long x1, ...);
extern void f101(float x0, long long x1, ...);
extern void f102(float x0, long long x1, ...);
extern void f103(float x0, long long x1, ...);
extern void f104(float x0, long long x1, ...);
extern void f105(float x0, long long x1, ...);
extern void f106(float x0, long long x1, ...);
extern void f107(float x0, long long x1, ...);
extern void f108(float x0, long long x1, ...);
extern void f109(float x0, double x1, ...);
extern void f110(float x0, double x1, ...);
extern void f111(float x0, double x1, ...);
extern void f112(float x0, double x1, ...);
extern void f113(float x0, double x1, ...);
extern void f114(float x0, double x1, ...);
extern void f115(float x0, double x1, ...);
extern void f116(float x0, double x1, ...);
extern void f117(float x0, double x1, ...);
extern void f118(double x0, int x1, ...);
extern void f119(double x0, int x1, ...);
extern void f120(double x0, int x1, ...);
extern void f121(double x0, int x1, ...);
extern void f122(double x0, int x1, ...);
extern void f123(double x0, int x1, ...);
extern void f124(double x0, int x1, ...);
extern void f125(double x0, int x1, ...);
extern void f126(double x0, int x1, ...);
extern void f127(double x0, long long x1, ...);
extern void f128(double x0, long long x1, ...);
extern void f129(double x0, long long x1, ...);
extern void f130(double x0, long long x1, ...);
extern void f131(double x0, long long x1, ...);
extern void f132(double x0, long long x1, ...);
extern void f133(double x0, long long x1, ...);
extern void f134(double x0, long long x1, ...);
extern void f135(double x0, long long x1, ...);
extern void f136(double x0, double x1, ...);
extern void f137(double x0, double x1, ...);
extern void f138(double x0, double x1, ...);
extern void f139(double x0, double x1, ...);
extern void f140(double x0, double x1, ...);
extern void f141(double x0, double x1, ...);
extern void f142(double x0, double x1, ...);
extern void f143(double x0, double x1, ...);
extern void f144(double x0, double x1, ...);
extern void f145(int x0, int x1, ...);
extern void f146(int x0, int x1, ...);
extern void f147(int x0, int x1, int x2, int x3, int x4, int x5, ...);
extern void f148(int x0, int x1, ...);
extern void f149(int x0, int x1, int x2, int x3, int x4, int x5, ...);
extern void f150(int x0, int x1, ...);
extern void f151(int x0, int x1, int x2, int x3, int x4, int x5, ...);
extern void f152(int x0, int x1, ...);
extern void f153(int x0, int x1, int x2, int x3, int x4, int x5, ...);
extern void f154(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7, int x8, int x9, int x10, int x11, int x12, int x13, ...);
extern void f155(int x0, int x1, ...);
extern void f156(int x0, int x1, int x2, int x3, int x4, int x5, ...);
extern void f157(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7, int x8, int x9, int x10, int x11, int x12, int x13, ...);
extern void f158(long long x0, long long x1, ...);
extern void f159(long long x0, long long x1, ...);
extern void f160(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, ...);
extern void f161(long long x0, long long x1, ...);
extern void f162(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, ...);
extern void f163(long long x0, long long x1, ...);
extern void f164(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, ...);
extern void f165(long long x0, long long x1, ...);
extern void f166(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, ...);
extern void f167(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7, long long x8, long long x9, long long x10, long long x11, long long x12, long long x13, ...);
extern void f168(long long x0, long long x1, ...);
extern void f169(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, ...);
extern void f170(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7, long long x8, long long x9, long long x10, long long x11, long long x12, long long x13, ...);
extern void f171(double x0, double x1, ...);
extern void f172(double x0, double x1, ...);
extern void f173(double x0, double x1, double x2, double x3, double x4, double x5, ...);
extern void f174(double x0, double x1, ...);
extern void f175(double x0, double x1, double x2, double x3, double x4, double x5, ...);
extern void f176(double x0, double x1, ...);
extern void f177(double x0, double x1, double x2, double x3, double x4, double x5, ...);
extern void f178(double x0, double x1, ...);
extern void f179(double x0, double x1, double x2, double x3, double x4, double x5, ...);
extern void f180(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11, double x12, double x13, ...);
extern void f181(double x0, double x1, ...);
extern void f182(double x0, double x1, double x2, double x3, double x4, double x5, ...);
extern void f183(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11, double x12, double x13, ...);
extern void f184(int x0, long long x1, ...);
extern void f185(int x0, long long x1, ...);
extern void f186(int x0, long long x1, int x2, long long x3, int x4, long long x5, ...);
extern void f187(int x0, long long x1, ...);
extern void f188(int x0, long long x1, int x2, long long x3, int x4, long long x5, ...);
extern void f189(int x0, long long x1, ...);
extern void f190(int x0, long long x1, int x2, long long x3, int x4, long long x5, ...);
extern void f191(int x0, long long x1, ...);
extern void f192(int x0, long long x1, int x2, long long x3, int x4, long long x5, ...);
extern void f193(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7, int x8, long long x9, int x10, long long x11, int x12, long long x13, ...);
extern void f194(int x0, long long x1, ...);
extern void f195(int x0, long long x1, int x2, long long x3, int x4, long long x5, ...);
extern void f196(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7, int x8, long long x9, int x10, long long x11, int x12, long long x13, ...);
extern void f197(int x0, double x1, ...);
extern void f198(int x0, double x1, ...);
extern void f199(int x0, double x1, int x2, double x3, int x4, double x5, ...);
extern void f200(int x0, double x1, ...);
extern void f201(int x0, double x1, int x2, double x3, int x4, double x5, ...);
extern void f202(int x0, double x1, ...);
extern void f203(int x0, double x1, int x2, double x3, int x4, double x5, ...);
extern void f204(int x0, double x1, ...);
extern void f205(int x0, double x1, int x2, double x3, int x4, double x5, ...);
extern void f206(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7, int x8, double x9, int x10, double x11, int x12, double x13, ...);
extern void f207(int x0, double x1, ...);
extern void f208(int x0, double x1, int x2, double x3, int x4, double x5, ...);
extern void f209(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7, int x8, double x9, int x10, double x11, int x12, double x13, ...);
extern void f210(long long x0, double x1, ...);
extern void f211(long long x0, double x1, ...);
extern void f212(long long x0, double x1, long long x2, double x3, long long x4, double x5, ...);
extern void f213(long long x0, double x1, ...);
extern void f214(long long x0, double x1, long long x2, double x3, long long x4, double x5, ...);
extern void f215(long long x0, double x1, ...);
extern void f216(long long x0, double x1, long long x2, double x3, long long x4, double x5, ...);
extern void f217(long long x0, double x1, ...);
extern void f218(long long x0, double x1, long long x2, double x3, long long x4, double x5, ...);
extern void f219(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7, long long x8, double x9, long long x10, double x11, long long x12, double x13, ...);
extern void f220(long long x0, double x1, ...);
extern void f221(long long x0, double x1, long long x2, double x3, long long x4, double x5, ...);
extern void f222(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7, long long x8, double x9, long long x10, double x11, long long x12, double x13, ...);
extern float f223(int x0, double x1, ...);
extern void f224(float x0, double x1, char * x2, float x3);
extern char * f225(char * x0, double x1, double x2, double x3, float x4);
extern signed char f226(float x0, char * x1, long long x2, char * x3, ...);
extern void f227(char * x0, long long x1, double x2, ...);
extern void f228(char * x0, long long x1, char * x2, char * x3, long long x4, int x5, char * x6, double x7, long long x8, ...);
extern signed char f229(double x0, double x1, long long x2, double x3, ...);
extern int f230(char * x0, double x1, char * x2, int x3, char * x4, char * x5, char * x6, int x7, long long x8, long long x9, long long x10, ...);
extern char * f231(long long x0, double x1, ...);
extern short f232(char * x0, float x1, float x2, long long x3, long long x4, float x5);
extern void f233(void);
extern unsigned char f234(char * x0, int x1, double x2, int x3, double x4, int x5, ...);
extern unsigned char f235(double x0, int x1, int x2, float x3);
extern char * f236(char * x0, int x1, double x2, ...);
extern unsigned char f237(char * x0, char * x1, float x2);
extern char * f238(void);
extern void f239(double x0, double x1, ...);
extern void f240(long long x0, double x1, ...);
extern signed char f241(char * x0, float x1, int x2, char * x3, ...);
extern void f242(char * x0, char * x1, float x2, long long x3, ...);
extern void f243(int x0, int x1, double x2, long long x3, char * x4, double x5, char * x6, int x7, double x8, ...);
extern void f244(long long x0, float x1, int x2, float x3);
extern float f245(float x0, long long x1, double x2, long long x3, int x4, int x5, long long x6, long long x7, int x8, char * x9, double x10, ...);
extern void f246(int x0, ...);
extern unsigned short f247(char * x0, char * x1, long long x2, long long x3, float x4, double x5, long long x6, ...);
extern void f248(void);
extern void f249(int x0, float x1, char * x2, double x3, int x4, float x5, char * x6, double x7, ...);
extern void f250(double x0, ...);
extern void f251(char * x0, char * x1, double x2, float x3, float x4, double x5, ...);
extern void f252(double x0, ...);
extern void f253(float x0);
extern unsigned char f254(int x0, double x1, char * x2, ...);
extern signed char f255(void);
extern void f256(double x0, long long x1, float x2, int x3, double x4, long long x5, float x6, char * x7, int x8, ...);
extern unsigned char f257(long long x0, int x1, double x2, float x3, double x4, long long x5, float x6);
extern void f258(float x0, long long x1, double x2, int x3, double x4, double x5, long long x6, char * x7, ...);
extern void f259(int x0, long long x1, float x2, long long x3, long long x4, char * x5, int x6, long long x7, float x8);
extern float f260(double x0, char * x1, double x2, double x3, double x4, double x5, char * x6, char * x7, double x8, float x9, double x10, ...);
extern short f261(char * x0, double x1, float x2, double x3, int x4, double x5, float x6, float x7, long long x8, float x9);
extern float f262(char * x0, float x1, char * x2, long long x3, long long x4, long long x5, double x6, ...);
extern void f263(float x0, char * x1, char * x2, float x3, double x4, double x5, char * x6, float x7, int x8, long long x9, double x10, ...);
extern void f264(void);
extern void f265(int x0, char * x1, float x2, char * x3, int x4, float x5, double x6, char * x7, double x8, float x9, long long x10, ...);
extern short f266(long long x0, long long x1, ...);
extern void f267(long long x0, int x1, long long x2, double x3, ...);
extern void f268(double x0, double x1, float x2, char * x3, long long x4, float x5, int x6, double x7, float x8);
extern unsigned char f269(char * x0, ...);
extern void f270(long long x0, char * x1, int x2, double x3, float x4, float x5, long long x6, ...);
extern unsigned short f271(long long x0, double x1, char * x2, ...);
extern void f272(float x0, double x1, char * x2, float x3);
extern short f273(long long x0, int x1, char * x2, long long x3, float x4, long long x5, ...);
extern void f274(char * x0, float x1, double x2, float x3, long long x4, int x5, double x6, int x7, double x8, ...);
extern void f275(float x0, int x1, int x2, long long x3, double x4, double x5, float x6, long long x7, ...);
extern unsigned char f276(char * x0, char * x1, ...);
extern int f277(float x0, char * x1, char * x2, double x3, int x4, char * x5, char * x6, char * x7, char * x8, ...);
extern char * f278(float x0, float x1, float x2, float x3, double x4, float x5, float x6, int x7, long long x8, ...);
extern void f279(double x0, double x1, int x2, int x3, ...);
extern void f280(float x0, float x1, double x2, char * x3, long long x4, int x5, char * x6, float x7, double x8, float x9, float x10);
extern void f281(long long x0, float x1, double x2, int x3, double x4, int x5, double x6, float x7, long long x8, int x9, ...);
extern void f282(long long x0, float x1, double x2, float x3);
extern void f283(float x0, long long x1, double x2, ...);
extern void f284(float x0, long long x1, float x2, float x3, long long x4, float x5, long long x6, int x7, ...);
extern void f285(float x0, double x1, double x2, char * x3, ...);
extern void f286(double x0, int x1, int x2, int x3, int x4, double x5, char * x6, int x7, char * x8, ...);
extern void f287(char * x0, int x1, char * x2, float x3, double x4, int x5, ...);
extern signed char f288(char * x0, double x1, ...);
extern unsigned char f289(long long x0, long long x1, ...);
extern void f290(int x0, float x1, double x2, char * x3, float x4, long long x5, char * x6, long long x7, ...);
extern char * f291(int x0, long long x1, double x2, int x3, float x4);
extern void f292(long long x0, long long x1, char * x2, float x3, long long x4, int x5, char * x6, int x7, int x8, double x9, ...);
extern void f293(char * x0, int x1, double x2, long long x3, char * x4, int x5, int x6, char * x7, double x8, float x9, double x10, ...);
extern void f294(int x0, long long x1, double x2, float x3, int x4, long long x5, float x6, double x7, int x8, long long x9, ...);
extern void f295(float x0);
extern void f296(void);
extern double f297(char * x0, int x1, float x2, long long x3, char * x4, long long x5, int x6, ...);
extern int f298(long long x0, float x1, float x2, double x3, float x4);
extern long long f299(char * x0, long long x1, int x2, char * x3, int x4, float x5, int x6, char * x7, double x8, ...);
extern signed char f300(float x0, int x1, float x2, long long x3, float x4, long long x5, ...);
extern short f301(char * x0, ...);
extern int f302(int x0, int x1, ...);
extern char * f303(float x0, int x1, double x2, double x3, float x4, long long x5, int x6, ...);
extern signed char f304(char * x0, int x1, long long x2, float x3, float x4, long long x5, long long x6, char * x7, ...);
extern unsigned short f305(long long x0, int x1, double x2, char * x3, double x4, int x5, float x6);
extern void f306(int x0, long long x1, ...);
extern void f307(float x0, int x1, ...);
extern void f308(int x0, long long x1, double x2, int x3, float x4, char * x5, long long x6, float x7, long long x8, ...);
extern void f309(float x0);
extern long long f310(double x0, float x1, int x2, int x3, double x4, int x5, int x6, float x7, float x8);
extern void f311(int x0, char * x1, float x2, long long x3, ...);
extern float f312(double x0, int x1, float x2);
extern long long f313(float x0, long long x1, long long x2, float x3, long long x4, float x5, char * x6, ...);
extern void f314(char * x0, char * x1, double x2, double x3, int x4, double x5, char * x6, int x7, float x8, char * x9, ...);
extern void f315(int x0, float x1, long long x2, double x3, char * x4, float x5, double x6, double x7, double x8, double x9, int x10, ...);
extern void f316(double x0, ...);
extern void f317(int x0, double x1, char * x2, ...);
extern unsigned short f318(char * x0, int x1, int x2, long long x3, ...);
extern void f319(double x0, long long x1, char * x2, char * x3, ...);
extern unsigned short f320(double x0, char * x1, double x2, long long x3, long long x4, ...);
extern void f321(long long x0, long long x1, char * x2, char * x3, long long x4, long long x5, long long x6, char * x7, long long x8, ...);
extern double f322(char * x0, double x1, ...);
extern double f323(void);
extern int f324(double x0, ...);
extern void f325(float x0, int x1, float x2, char * x3, ...);
extern char * f326(float x0, long long x1, ...);
extern void f327(char * x0, float x1, int x2, char * x3, double x4, double x5, ...);
extern void f328(long long x0, long long x1, int x2, char * x3, char * x4, float x5);
extern short f329(void);
extern float f330(float x0, double x1, float x2, long long x3, long long x4, char * x5, long long x6, float x7);
extern void f331(float x0, double x1, long long x2, ...);
extern void f332(double x0, int x1, int x2, long long x3, char * x4, int x5, double x6, int x7, ...);
extern void f333(void);
extern signed char f334(float x0);
extern void f335(void);
extern signed char f336(float x0, char * x1, long long x2, char * x3, ...);
extern unsigned short f337(float x0, int x1, int x2, ...);
extern double f338(char * x0, char * x1, char * x2, char * x3, int x4, char * x5, ...);
extern void f339(char * x0, double x1, char * x2, double x3, char * x4, char * x5, int x6, ...);
extern long long f340(float x0, float x1, int x2, char * x3, long long x4, int x5, char * x6, long long x7, double x8, float x9);
extern void f341(char * x0, long long x1, int x2, float x3, float x4);
extern long long f342(double x0, char * x1, int x2, ...);
extern void f343(int x0, char * x1, float x2, char * x3, float x4, float x5, int x6, float x7);
extern unsigned char f344(long long x0, long long x1, int x2, char * x3, float x4, float x5);
extern int f345(long long x0, long long x1, long long x2, char * x3, float x4);
extern void f346(double x0, char * x1, int x2, long long x3, char * x4, char * x5, int x6, ...);
extern void f347(long long x0, int x1, long long x2, ...);
extern double f348(long long x0, int x1, double x2, char * x3, float x4, double x5, int x6, char * x7, ...);
extern signed char f349(char * x0, double x1, ...);
extern long long f350(double x0, char * x1, double x2, ...);
extern void f351(int x0, ...);
extern void f352(long long x0, double x1, long long x2, int x3, ...);
extern void f353(int x0, int x1, double x2, float x3, double x4, long long x5, float x6, float x7, double x8, float x9, long long x10, ...);
extern unsigned char f354(double x0, int x1, char * x2, long long x3, float x4, int x5, int x6, char * x7, int x8, ...);
extern void f355(float x0, char * x1, float x2, int x3, int x4, ...);
extern void f356(char * x0, int x1, double x2, float x3, double x4, int x5, double x6, char * x7, long long x8, char * x9, int x10, ...);
extern unsigned char f357(char * x0, int x1, double x2, int x3, int x4, double x5, double x6, double x7, double x8, int x9, int x10, ...);
extern int f358(double x0, double x1, char * x2, ...);
extern void f359(float x0, double x1, int x2, double x3, char * x4, char * x5, ...);
extern void f360(int x0, int x1, int x2, long long x3, char * x4, double x5, long long x6, ...);
extern double f361(void);
extern void f362(float x0, long long x1, double x2, char * x3, float x4, double x5, char * x6, float x7, long long x8, double x9, ...);
extern void f363(long long x0, ...);
extern int f364(double x0, ...);
extern unsigned char f365(char * x0, float x1, double x2, float x3, float x4, int x5, long long x6, double x7, long long x8, int x9, char * x10, ...);
extern unsigned char f366(char * x0, long long x1, char * x2, float x3, double x4, int x5, int x6, long long x7, ...);
extern void f367(float x0, long long x1, char * x2, double x3, long long x4, int x5, float x6, float x7, double x8, long long x9, ...);
extern short f368(float x0, float x1, float x2, int x3, int x4, ...);
extern short f369(void);
extern unsigned char f370(long long x0, float x1, long long x2, long long x3, char * x4, ...);
extern int f371(int x0, float x1, double x2, int x3, ...);
extern void f372(double x0, char * x1, double x2, float x3, double x4, float x5, int x6, float x7, double x8, double x9, float x10);
extern float f373(int x0, char * x1, long long x2, double x3, char * x4, int x5, float x6, double x7, int x8, char * x9, ...);
extern int f374(float x0, long long x1, double x2, char * x3, char * x4, float x5, int x6, char * x7, int x8, ...);
extern void f375(double x0, float x1, float x2, char * x3, char * x4, ...);
extern unsigned short f376(char * x0, ...);
extern void f377(int x0, ...);
extern void f378(int x0, char * x1, int x2, ...);
extern float f379(int x0, char * x1, double x2, int x3, char * x4, char * x5, double x6, ...);
extern void f380(double x0, long long x1, ...);
extern unsigned char f381(char * x0, int x1, char * x2, char * x3, int x4, float x5, char * x6, int x7, long long x8, int x9, ...);
extern char * f382(long long x0, char * x1, float x2);
extern void f383(char * x0, long long x1, char * x2, float x3, double x4, ...);
extern signed char f384(int x0, int x1, double x2, char * x3, float x4);
extern int f385(int x0, int x1, double x2, char * x3, int x4, int x5, int x6, ...);
extern void f386(long long x0, int x1, ...);
extern void f387(int x0, char * x1, int x2, ...);
extern void f388(long long x0, long long x1, double x2, int x3, double x4, float x5);
extern void f389(char * x0, double x1, char * x2, int x3, char * x4, int x5, int x6, int x7, char * x8, float x9);
extern void f390(double x0, ...);
extern void f391(long long x0, char * x1, float x2, int x3, float x4, int x5, long long x6, char * x7, ...);
extern float f392(float x0);
extern void f393(char * x0, float x1, float x2, double x3, int x4, double x5, double x6, float x7);
extern int f394(char * x0, ...);
extern long long f395(char * x0, char * x1, int x2, ...);
extern signed char f396(int x0, long long x1, int x2, float x3);
extern int f397(long long x0, double x1, long long x2, long long x3, long long x4, long long x5, long long x6, ...);
extern void f398(float x0, int x1, char * x2, char * x3, long long x4, int x5, ...);
extern unsigned char f399(float x0, char * x1, long long x2, int x3, double x4, char * x5, int x6, float x7, int x8, int x9, long long x10, ...);
extern void f400(int x0, int x1, long long x2, float x3);
extern unsigned char f401(void);
extern unsigned char f402(int x0, int x1, long long x2, char * x3, double x4, long long x5, char * x6, long long x7, long long x8, ...);
extern void f403(double x0, long long x1, long long x2, float x3, double x4, float x5, double x6, float x7);
extern void f404(long long x0, float x1, float x2, float x3, long long x4, double x5, int x6, ...);
extern void f405(int x0, long long x1, int x2, float x3, long long x4, long long x5, char * x6, double x7, int x8, double x9, double x10, ...);
extern void f406(void);
extern signed char f407(float x0, double x1, ...);
extern void f408(int x0, char * x1, char * x2, int x3, long long x4, int x5, ...);
extern unsigned char f409(long long x0, float x1, float x2, float x3, long long x4, int x5, float x6);
extern void f410(float x0, double x1, char * x2, double x3, char * x4, ...);
extern void f411(float x0, int x1, ...);
extern short f412(int x0, int x1, ...);
extern void f413(char * x0, long long x1, ...);
extern long long f414(long long x0, long long x1, char * x2, int x3, char * x4, char * x5, char * x6, int x7, double x8, char * x9, float x10);
extern void f415(int x0, int x1, double x2, float x3, float x4, long long x5, double x6, ...);
extern long long f416(void);
extern char * f417(double x0, double x1, char * x2, double x3, ...);
extern unsigned char f418(float x0, double x1, int x2, double x3, double x4, float x5, long long x6, float x7);
extern unsigned char f419(double x0, ...);
extern unsigned short f420(long long x0, int x1, char * x2, char * x3, double x4, double x5, char * x6, float x7);
extern void f421(float x0);
extern short f422(long long x0, long long x1, long long x2, int x3, long long x4, int x5, double x6, double x7, int x8, ...);
extern void f423(long long x0, double x1, int x2, long long x3, long long x4, double x5, float x6, double x7, char * x8, ...);
extern int f424(int x0, char * x1, double x2, char * x3, float x4);
extern unsigned short f425(int x0, float x1, char * x2, ...);
extern unsigned short f426(int x0, char * x1, ...);
extern unsigned char f427(double x0, char * x1, double x2, int x3, ...);
extern void f428(long long x0, double x1, char * x2, char * x3, float x4);
extern signed char f429(long long x0, float x1, int x2, long long x3, long long x4, float x5);
extern signed char f430(char * x0, long long x1, long long x2, double x3, double x4, char * x5, int x6, int x7, ...);
extern double f431(long long x0, int x1, int x2, long long x3, double x4, long long x5, char * x6, int x7, ...);
extern void f432(float x0);
extern float f433(float x0, double x1, long long x2, char * x3, float x4, float x5);
extern void f434(char * x0, long long x1, char * x2, char * x3, long long x4, char * x5, float x6, int x7, char * x8, long long x9, float x10);
extern void f435(long long x0, double x1, long long x2, float x3, double x4, double x5, double x6, char * x7, long long x8, int x9, ...);
extern float f436(int x0, int x1, char * x2, double x3, char * x4, ...);
extern void f437(int x0, long long x1, char * x2, long long x3, float x4, float x5, char * x6, ...);
extern int f438(double x0, int x1, char * x2, char * x3, float x4);
extern long long f439(long long x0, char * x1, int x2, int x3, int x4, double x5, double x6, double x7, ...);
extern void f440(int x0, long long x1, char * x2, long long x3, char * x4, long long x5, ...);
extern signed char f441(long long x0, char * x1, long long x2, int x3, char * x4, float x5, double x6, int x7, long long x8, float x9);
extern int f442(char * x0, float x1, long long x2, char * x3, char * x4, double x5, ...);
extern void f443(int x0, float x1, int x2, int x3, double x4, int x5, ...);
extern void f444(double x0, double x1, double x2, ...);
extern void f445(double x0, int x1, char * x2, char * x3, char * x4, double x5, int x6, int x7, ...);
extern long long f446(long long x0, float x1, double x2, float x3, long long x4, char * x5, float x6, int x7, ...);
extern unsigned short f447(char * x0, int x1, float x2, char * x3, ...);
extern void f448(long long x0, int x1, double x2, double x3, float x4, double x5, double x6, int x7, int x8, int x9, ...);
extern char * f449(int x0, ...);
extern void f450(int x0, long long x1, char * x2, ...);
extern void f451(float x0, double x1, char * x2, double x3, float x4, double x5, char * x6, int x7, long long x8, float x9);
extern void f452(long long x0, double x1, int x2, long long x3, int x4, ...);
extern void f453(double x0, ...);
extern double f454(double x0, long long x1, double x2, char * x3, long long x4, int x5, char * x6, double x7, ...);
extern void f455(char * x0, int x1, char * x2, double x3, double x4, char * x5, char * x6, double x7, char * x8, float x9, float x10);
extern void f456(void);
extern void f457(long long x0, int x1, long long x2, double x3, double x4, ...);
extern short f458(double x0, int x1, char * x2, long long x3, ...);
extern unsigned short f459(char * x0, long long x1, long long x2, long long x3, int x4, float x5);
extern int f460(float x0, long long x1, long long x2, long long x3, double x4, long long x5, long long x6, char * x7, char * x8, double x9, int x10, ...);
extern void f461(double x0, char * x1, char * x2, long long x3, int x4, char * x5, char * x6, int x7, int x8, int x9, float x10);
extern void f462(char * x0, float x1, double x2, char * x3, double x4, double x5, long long x6, ...);
extern void f463(int x0, long long x1, int x2, char * x3, int x4, char * x5, float x6, int x7, double x8, double x9, ...);
extern short f464(long long x0, char * x1, double x2, double x3, ...);
extern short f465(double x0, ...);
extern signed char f466(int x0, char * x1, ...);
extern void f467(long long x0, ...);
extern void f468(int x0, double x1, int x2, ...);
extern unsigned short f469(char * x0, long long x1, float x2, long long x3, double x4, float x5, int x6, double x7, long long x8, double x9, ...);
extern void f470(double x0, double x1, long long x2, int x3, double x4, ...);
extern unsigned short f471(float x0, int x1, float x2, double x3, char * x4, long long x5, ...);
extern int f472(float x0, long long x1, int x2, int x3, char * x4, char * x5, int x6, double x7, ...);
extern void f473(char * x0, char * x1, long long x2, float x3, float x4);
extern void f474(void);
extern void f475(int x0, int x1, long long x2, long long x3, char * x4, ...);
extern void f476(char * x0, double x1, long long x2, ...);
extern signed char f477(long long x0, float x1, char * x2, double x3, int x4, double x5, float x6, double x7, double x8, long long x9, double x10, ...);
extern unsigned char f478(int x0, double x1, long long x2, double x3, int x4, ...);
extern void f479(int x0, int x1, int x2, char * x3, int x4, float x5, int x6, ...);
extern int f480(int x0, int x1, long long x2, char * x3, ...);
extern int f481(float x0, char * x1, int x2, char * x3, ...);
extern unsigned short f482(double x0, float x1, char * x2, double x3, float x4, long long x5, double x6, ...);
extern void f483(int x0, char * x1, long long x2, float x3);
extern void f484(long long x0, double x1, char * x2, ...);
extern long long f485(int x0, float x1, double x2, ...);
extern void f486(float x0, long long x1, long long x2, int x3, double x4, long long x5, double x6, ...);
extern int f487(int x0, long long x1, double x2, ...);
extern void f488(double x0, ...);
extern void f489(int x0, ...);
extern void f490(double x0, ...);
extern float f491(int x0, long long x1, long long x2, double x3, ...);
extern void f492(long long x0, float x1, char * x2, double x3, double x4, float x5, long long x6, int x7, ...);
extern signed char f493(double x0, ...);
extern short f494(double x0, char * x1, double x2, double x3, int x4, float x5, long long x6, long long x7, ...);
extern long long f495(double x0, float x1, float x2, double x3, ...);
extern void f496(double x0, long long x1, int x2, double x3, int x4, char * x5, double x6, float x7, char * x8, ...);
extern int f497(long long x0, char * x1, float x2, int x3, char * x4, float x5, double x6, char * x7, ...);
extern char * f498(double x0, double x1, int x2, ...);
extern void f499(void);
extern unsigned char f500(float x0, double x1, double x2, int x3, long long x4, ...);
extern void f501(void);
extern void f502(char * x0, char * x1, double x2, double x3, double x4, char * x5, float x6, float x7, char * x8, char * x9, ...);
extern void f503(int x0, double x1, float x2, float x3, int x4, float x5, long long x6, ...);
extern signed char f504(int x0, char * x1, int x2, char * x3, double x4, int x5, int x6, float x7, double x8, ...);
extern void f505(char * x0, char * x1, double x2, float x3);
extern void f506(double x0, float x1, double x2, char * x3, float x4, char * x5, char * x6, ...);
extern long long f507(int x0, char * x1, int x2, char * x3, ...);
extern void f508(float x0, double x1, double x2, double x3, ...);
extern void f509(long long x0, double x1, float x2, char * x3, double x4, double x5, char * x6, char * x7, float x8, char * x9, ...);
extern double f510(long long x0, int x1, long long x2, long long x3, long long x4, ...);
extern short f511(char * x0, int x1, float x2, long long x3, long long x4, float x5, int x6, double x7, long long x8, long long x9, char * x10, ...);
extern short f512(float x0, long long x1, float x2, double x3, long long x4, long long x5, double x6, int x7, ...);
extern char * f513(float x0, char * x1, int x2, float x3);
extern void f514(float x0, float x1);
extern void f515(int x0, int x1, char * x2, ...);
extern void f516(char * x0, ...);
extern void f517(int x0, int x1, char * x2, int x3, long long x4, char * x5, float x6, float x7, char * x8, ...);
extern unsigned char f518(long long x0, int x1, double x2, char * x3, double x4, int x5, long long x6, float x7);
extern signed char f519(long long x0, float x1, long long x2, ...);
extern void f520(float x0, float x1, char * x2, float x3, int x4, long long x5, double x6, int x7, ...);
extern unsigned char f521(float x0, int x1, long long x2, double x3, int x4, long long x5, long long x6, ...);
extern void f522(float x0, float x1, int x2, double x3, ...);
extern float f523(float x0, int x1, double x2, double x3, float x4, double x5, int x6, int x7, ...);
extern unsigned short f524(int x0, long long x1, int x2, long long x3, float x4);
extern void f525(long long x0, double x1, int x2, char * x3, ...);
extern double f526(double x0, double x1, long long x2, char * x3, float x4, double x5, long long x6, float x7, long long x8, ...);
extern float f527(void);
extern short f528(char * x0, double x1, ...);
extern void f529(void);
extern short f530(int x0, char * x1, float x2, double x3, float x4, int x5, ...);
extern unsigned short f531(char * x0, int x1, double x2, double x3, char * x4, long long x5, float x6, char * x7, ...);
extern void f532(long long x0, double x1, float x2, float x3, float x4, char * x5, int x6, float x7, int x8, long long x9, ...);
extern unsigned short f533(float x0, float x1, int x2, double x3, double x4, float x5, int x6, float x7, char * x8, double x9, long long x10, ...);
extern void f534(double x0, double x1, long long x2, char * x3, int x4, char * x5, long long x6, long long x7, double x8, char * x9, int x10, ...);
extern long long f535(char * x0, long long x1, long long x2, float x3, double x4, float x5, long long x6, ...);
extern void f536(long long x0, char * x1, long long x2, char * x3, ...);
extern float f537(void);
extern unsigned char f538(double x0, float x1);
extern short f539(double x0, int x1, int x2, char * x3, int x4, long long x5, ...);
extern void f540(double x0, char * x1, float x2, double x3, long long x4, ...);
extern unsigned char f541(float x0, long long x1, int x2, int x3, double x4, double x5, int x6, char * x7, long long x8, int x9, char * x10, ...);
extern void f542(int x0, ...);
extern void f543(void);
extern void f544(char * x0, int x1, char * x2, float x3, char * x4, int x5, ...);
extern void f545(long long x0, int x1, long long x2, double x3, int x4, ...);
extern signed char f546(void);
extern void f547(float x0, int x1, char * x2, ...);
extern void f548(int x0, float x1, long long x2, double x3, double x4, ...);
extern signed char f549(long long x0, int x1, long long x2, double x3, long long x4, float x5, char * x6, double x7, long long x8, ...);
extern void f550(float x0, int x1, ...);
extern signed char f551(long long x0, float x1, int x2, char * x3, int x4, float x5);
extern int f552(long long x0, float x1, float x2, char * x3, ...);
extern void f553(void);
extern char * f554(char * x0, long long x1, long long x2, long long x3, double x4, ...);
extern int f555(int x0, char * x1, long long x2, ...);
extern char * f556(int x0, long long x1, double x2, long long x3, char * x4, ...);
extern void f557(double x0, long long x1, long long x2, long long x3, long long x4, float x5, float x6);
extern void f558(float x0, double x1, int x2, int x3, long long x4, ...);
extern void f559(int x0, char * x1, int x2, float x3, float x4, float x5, char * x6, char * x7, long long x8, ...);
extern unsigned short f560(double x0, int x1, int x2, float x3, int x4, double x5, long long x6, int x7, char * x8, long long x9, float x10);
extern void f561(float x0, float x1, int x2, int x3, char * x4, char * x5, ...);
extern long long f562(int x0, ...);
extern float f563(float x0, char * x1, float x2);
extern void f564(long long x0, float x1, float x2, int x3, int x4, ...);
extern short f565(float x0, float x1, long long x2, float x3, char * x4, int x5, int x6, float x7, double x8, int x9, double x10, ...);
extern unsigned short f566(double x0, double x1, float x2, int x3, char * x4, int x5, double x6, int x7, ...);
extern unsigned char f567(long long x0, double x1, char * x2, double x3, char * x4, float x5, double x6, int x7, ...);
extern void f568(float x0, long long x1, float x2, long long x3, long long x4, double x5, long long x6, int x7, ...);
extern void f569(double x0, ...);
extern void f570(void);
extern void f571(double x0, float x1, float x2, double x3, ...);
extern void f572(int x0, char * x1, double x2, char * x3, ...);
extern void f573(double x0, int x1, ...);
extern void f574(double x0, float x1, int x2, double x3, int x4, long long x5, long long x6, long long x7, ...);
extern float f575(float x0, int x1, char * x2, double x3, int x4, int x5, int x6, ...);
extern float f576(char * x0, float x1, long long x2, long long x3, double x4, double x5, int x6, float x7);
extern void f577(long long x0, double x1, double x2, char * x3, int x4, double x5, char * x6, char * x7, int x8, char * x9, double x10, ...);
extern int f578(void);
extern void f579(long long x0, double x1, long long x2, double x3, float x4);
extern float f580(long long x0, int x1, int x2, long long x3, ...);
extern void f581(double x0, char * x1, char * x2, char * x3, long long x4, double x5, float x6, int x7, ...);
extern void f582(float x0, int x1, double x2, float x3, float x4, int x5, double x6, ...);
extern void f583(char * x0, float x1, int x2, long long x3, int x4, long long x5, char * x6, char * x7, double x8, double x9, char * x10, ...);
extern double f584(int x0, ...);
extern void f585(char * x0, char * x1, long long x2, int x3, double x4, float x5);
extern int f586(void);
extern int f587(void);
extern short f588(float x0, long long x1, double x2, long long x3, int x4, float x5, double x6, float x7, long long x8, float x9);
extern int f589(int x0, long long x1, ...);
extern void f590(int x0, ...);
extern char * f591(float x0, int x1, long long x2, float x3, double x4, ...);
extern unsigned char f592(long long x0, double x1, ...);
extern void f593(long long x0, ...);
extern void f594(int x0, long long x1, long long x2, float x3, long long x4, char * x5, float x6, double x7, ...);
extern unsigned short f595(float x0, int x1, int x2, long long x3, char * x4, int x5, double x6, float x7);
extern void f596(int x0, float x1, int x2, long long x3, long long x4, char * x5, ...);
extern void f597(char * x0, int x1, char * x2, char * x3, float x4, int x5, float x6, char * x7, ...);
extern void f598(double x0, char * x1, double x2, int x3, char * x4, double x5, float x6, char * x7, double x8, int x9, ...);
extern void f599(float x0, long long x1, long long x2, ...);
extern long long f600(long long x0, float x1, int x2, int x3, int x4, char * x5, float x6, char * x7, int x8, char * x9, double x10, ...);
extern void f601(char * x0, char * x1, double x2, float x3, double x4, float x5, double x6, double x7, int x8, char * x9, int x10, ...);
extern void f602(long long x0, long long x1, ...);
extern void f603(long long x0, double x1, int x2, float x3, int x4, int x5, float x6, float x7, long long x8, ...);
extern void f604(char * x0, int x1, long long x2, char * x3, double x4, float x5, char * x6, double x7, ...);
extern signed char f605(float x0, char * x1, char * x2, int x3, char * x4, int x5, int x6, float x7);
extern void f606(char * x0, int x1, int x2, ...);
extern char * f607(long long x0, double x1, double x2, int x3, long long x4, float x5);
extern signed char f608(void);
extern int f609(double x0, double x1, ...);
extern void f610(double x0, char * x1, int x2, long long x3, int x4, char * x5, double x6, double x7, long long x8, ...);
extern void f611(long long x0, float x1, float x2, char * x3, long long x4, ...);
extern void f612(int x0, int x1, ...);
extern signed char f613(int x0, float x1, float x2, float x3, long long x4, long long x5, char * x6, double x7, float x8, int x9, float x10);
extern float f614(char * x0, long long x1, float x2);
extern double f615(int x0, double x1, float x2, int x3, char * x4, float x5);
extern double f616(long long x0, int x1, char * x2, ...);
extern void f617(float x0, char * x1, int x2, float x3);
extern void f618(int x0, double x1, float x2);
extern float f619(int x0, long long x1, long long x2, long long x3, long long x4, ...);
extern unsigned char f620(char * x0, char * x1, ...);
extern double f621(int x0, char * x1, long long x2, ...);
extern float f622(long long x0, long long x1, long long x2, int x3, char * x4, char * x5, float x6, float x7, int x8, double x9, ...);
extern signed char f623(double x0, double x1, long long x2, long long x3, int x4, ...);
extern char * f624(int x0, float x1, float x2, double x3, ...);
extern void f625(long long x0, int x1, char * x2, double x3, ...);
extern void f626(int x0, long long x1, float x2, float x3, long long x4, float x5, int x6, ...);
extern int f627(void);
extern void f628(char * x0, long long x1, double x2, long long x3, double x4, int x5, long long x6, double x7, ...);
extern char * f629(long long x0, float x1, long long x2, char * x3, int x4, long long x5, double x6, ...);
extern void f630(long long x0, double x1, float x2, char * x3, int x4, double x5, float x6, float x7);
extern void f631(double x0, int x1, ...);
extern unsigned char f632(float x0, long long x1, double x2, long long x3, float x4, char * x5, ...);
extern void f633(char * x0, float x1, float x2, long long x3, char * x4, ...);
extern void f634(long long x0, char * x1, char * x2, double x3, char * x4, char * x5, char * x6, int x7, ...);
extern void f635(int x0, int x1, float x2);
extern float f636(char * x0, int x1, float x2, long long x3, int x4, double x5, int x6, char * x7, ...);
extern void f637(char * x0, int x1, long long x2, long long x3, char * x4, double x5, int x6, float x7, char * x8, double x9, ...);
extern unsigned short f638(float x0, long long x1, long long x2, ...);
extern void f639(int x0, int x1, long long x2, ...);
extern void f640(double x0, char * x1, float x2, int x3, int x4, double x5, char * x6, double x7, char * x8, ...);
extern int f641(char * x0, double x1, float x2, long long x3, float x4);
extern void f642(int x0, char * x1, double x2, float x3, float x4);
extern long long f643(double x0, int x1, int x2, float x3, double x4, long long x5, long long x6, char * x7, ...);
extern void f644(float x0, float x1, float x2, long long x3, char * x4, long long x5, long long x6, ...);
extern float f645(int x0, char * x1, double x2, char * x3, long long x4, double x5, float x6, long long x7, ...);
extern void f646(char * x0, char * x1, float x2, float x3);
extern void f647(double x0, double x1, ...);
extern float f648(float x0, int x1, float x2, long long x3, long long x4, double x5, double x6, int x7, int x8, long long x9, char * x10, ...);
extern char * f649(int x0, double x1, double x2, ...);
extern void f650(long long x0, float x1, float x2, long long x3, double x4, double x5, ...);
extern unsigned char f651(long long x0, long long x1, long long x2, char * x3, double x4, double x5, long long x6, ...);
extern unsigned short f652(char * x0, ...);
extern void f653(int x0, double x1, long long x2, ...);
extern void f654(int x0, long long x1, double x2, double x3, char * x4, double x5, ...);
extern void f655(char * x0, float x1, int x2, float x3, int x4, float x5, double x6, int x7, int x8, ...);
extern signed char f656(float x0, char * x1, int x2, int x3, char * x4, int x5, ...);
extern double f657(char * x0, char * x1, float x2, double x3, int x4, long long x5, int x6, int x7, long long x8, char * x9, ...);
extern double f658(char * x0, char * x1, float x2, char * x3, double x4, ...);
extern void f659(int x0, ...);
extern int f660(void);
extern float f661(float x0, char * x1, float x2, int x3, float x4, long long x5, long long x6, int x7, long long x8, ...);
extern void f662(char * x0, double x1, long long x2, char * x3, int x4, double x5, int x6, long long x7, int x8, char * x9, ...);
extern void f663(int x0, long long x1, float x2, float x3, char * x4, int x5, float x6, int x7, long long x8, ...);
extern int f664(char * x0, int x1, int x2, char * x3, double x4, ...);
extern short f665(char * x0, char * x1, float x2, float x3, double x4, double x5, char * x6, long long x7, ...);
extern int f666(int x0, ...);
extern void f667(double x0, double x1, double x2, float x3, char * x4, double x5, ...);
extern float f668(float x0, double x1, int x2, double x3, char * x4, int x5, char * x6, ...);
extern short f669(int x0, long long x1, float x2, char * x3, long long x4, double x5, double x6, float x7, float x8);
extern long long f670(float x0, float x1, float x2);
extern float f671(char * x0, double x1, long long x2, double x3, char * x4, float x5, int x6, long long x7, char * x8, char * x9, double x10, ...);
extern void f672(void);
extern long long f673(float x0, float x1, long long x2, char * x3, int x4, long long x5, double x6, long long x7, char * x8, ...);
extern short f674(float x0, double x1, char * x2, int x3, int x4, ...);
extern long long f675(int x0, int x1, ...);
extern double f676(char * x0, float x1, long long x2, float x3, float x4, double x5, char * x6, float x7, float x8);
extern void f677(float x0, int x1, double x2, double x3, int x4, char * x5, char * x6, double x7, ...);
extern short f678(char * x0, long long x1, ...);
extern void f679(int x0, double x1, double x2, double x3, long long x4, double x5, char * x6, float x7, int x8, ...);
extern void f680(void);
extern int f681(int x0, int x1, int x2, float x3, char * x4, char * x5, long long x6, char * x7, ...);
extern void f682(long long x0, double x1, float x2, double x3, double x4, int x5, long long x6, ...);
extern unsigned short f683(char * x0, long long x1, char * x2, double x3, double x4, int x5, int x6, int x7, float x8, float x9);
extern signed char f684(float x0, int x1, double x2, double x3, long long x4, float x5, char * x6, int x7, char * x8, int x9, ...);
extern void f685(float x0, char * x1, long long x2, double x3, float x4, float x5, float x6);
extern void f686(void);
extern void f687(char * x0, int x1, char * x2, float x3);
extern void f688(void);
extern signed char f689(long long x0, int x1, char * x2, double x3, float x4, double x5, long long x6, double x7, int x8, ...);
extern char * f690(long long x0, int x1, int x2, long long x3, float x4, float x5, float x6, double x7, ...);
extern long long f691(long long x0, char * x1, long long x2, double x3, float x4, long long x5, int x6, float x7, long long x8, double x9, ...);
extern void f692(int x0, long long x1, char * x2, char * x3, ...);
extern void f693(void);
extern void f694(char * x0, char * x1, int x2, double x3, long long x4, char * x5, double x6, ...);
extern unsigned short f695(long long x0, double x1, char * x2, char * x3, float x4, long long x5, char * x6, int x7, int x8, ...);
extern void f696(char * x0, long long x1, char * x2, char * x3, long long x4, char * x5, int x6, float x7, float x8, int x9, ...);
extern unsigned char f697(char * x0, int x1, long long x2, double x3, char * x4, double x5, ...);
extern void f698(char * x0, double x1, char * x2, double x3, ...);
extern char * f699(long long x0, float x1, double x2, float x3, double x4, ...);
extern signed char f700(char * x0, float x1, float x2, long long x3, int x4, double x5, float x6, float x7, int x8, double x9, int x10, ...);
extern float f701(char * x0, int x1, float x2, int x3, float x4);
extern void f702(double x0, double x1, char * x2, ...);
extern void f703(double x0, double x1, double x2, long long x3, double x4, ...);
extern short f704(int x0, char * x1, char * x2, long long x3, int x4, float x5, int x6, ...);
extern void f705(long long x0, float x1, float x2, float x3);
extern unsigned short f706(double x0, int x1, long long x2, double x3, char * x4, int x5, int x6, float x7, long long x8, double x9, ...);
extern void f707(char * x0, double x1, char * x2, double x3, ...);
extern unsigned short f708(long long x0, long long x1, float x2, char * x3, long long x4, ...);
extern void f709(long long x0, float x1, float x2, long long x3, double x4, long long x5, double x6, int x7, ...);
extern char * f710(char * x0, char * x1, float x2, double x3, long long x4, double x5, long long x6, char * x7, long long x8, ...);
extern void f711(int x0, char * x1, double x2, long long x3, double x4, int x5, double x6, ...);
extern signed char f712(float x0, double x1, float x2, long long x3, int x4, float x5, int x6, double x7, int x8, double x9, ...);
extern float f713(char * x0, long long x1, int x2, int x3, int x4, int x5, float x6);
extern void f714(float x0, char * x1, long long x2, long long x3, int x4, float x5, char * x6, char * x7, int x8, int x9, int x10, ...);
extern signed char f715(float x0, float x1, char * x2, double x3, char * x4, int x5, long long x6, int x7, ...);
extern unsigned char f716(long long x0, double x1, char * x2, float x3, char * x4, double x5, ...);
extern unsigned short f717(char * x0, int x1, float x2, float x3, double x4, double x5, double x6, char * x7, long long x8, ...);
extern void f718(int x0, ...);
extern short f719(void);
extern long long f720(void);
extern void f721(long long x0, long long x1, int x2, double x3, double x4, float x5);
extern unsigned short f722(long long x0, float x1);
# 6 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c" 2

int failed = 0;

void call_f1(void)
{
  f1(359424978, -1562221124, 1815701022);
}

void call_f2(void)
{
  f2(1377895494, 786384645, -7464907809330185142);
}

void call_f3(void)
{
  f3(-869060679, -1292962594, 0x1.1fc90e8ae4d78p+5);
}

void call_f4(void)
{
  f4(-165825162, 2865677210277011461, 242953397);
}

void call_f5(void)
{
  f5(1902534691, -6641433098825932921, 7023089093677220574);
}

void call_f6(void)
{
  f6(-1677478395, 763066718451839546, -0x1.5a88d9cb03d4ep+5);
}

void call_f7(void)
{
  f7(1076806509, -0x1.66b1425c8106ap+5, -201024218);
}

void call_f8(void)
{
  f8(508313204, 0x1.9d76d8f5f836p+4, -5795356962823460286);
}

void call_f9(void)
{
  f9(-1819372239, -0x1.35448a73f98b9p+4, 0x1.4e73f70cf636ap+5);
}

void call_f10(void)
{
  f10(-4971797672212541531, -1922283024, -1113522804);
}

void call_f11(void)
{
  f11(-2489200765840530951, -147460712, -3617192151061228944);
}

void call_f12(void)
{
  f12(-3238782525965314528, -1224970120, -0x1.54fc0b912fd64p+5);
}

void call_f13(void)
{
  f13(6447444042990336358, 6306578937032190423, -837774178);
}

void call_f14(void)
{
  f14(-3094182341537540600, 6582052121744720579, -8109874353755007897);
}

void call_f15(void)
{
  f15(-1009011661423897945, -5748340618103229792, 0x1.c0ff22b9a895p+3);
}

void call_f16(void)
{
  f16(-1307556698743366303, 0x1.49b1fe131e4e4p+4, 1967018687);
}

void call_f17(void)
{
  f17(-8373128873323628130, -0x1.1b8b50730db52p+4, 6240028794231868543);
}

void call_f18(void)
{
  f18(219597293007463358, -0x1.209d248df9f1cp+5, 0x1.06b6844287feep+5);
}

void call_f19(void)
{
  f19(0x1.cfabe89130a64p+4, -1112381232, -136078582);
}

void call_f20(void)
{
  f20(0x1.058d46e3148b2p+5, -261564199, -816271512240593349);
}

void call_f21(void)
{
  f21(-0x1.0c5df46c0464ep+5, 929994926, -0x1.094ee516a1758p+2);
}

void call_f22(void)
{
  f22(-0x1.768e529f87bc4p+5, 85495102829890918, -2058290849);
}

void call_f23(void)
{
  f23(-0x1.b3ed0b83526adp+4, -903189518129672391, -2962885905197277511);
}

void call_f24(void)
{
  f24(0x1.0f5ba4f9bf4bp+4, -423722403545853660, -0x1.753a9c9e51be6p+4);
}

void call_f25(void)
{
  f25(-0x1.3cb00a7f7bba4p+3, 0x1.22424233d124cp+4, 1572015079);
}

void call_f26(void)
{
  f26(0x1.3bd4e8e7ca6p-2, -0x1.7f0ba63263p-7, -2986530589438070174);
}

void call_f27(void)
{
  f27(0x1.3ef7c81f4b458p+2, 0x1.8465a13dd251p+4, -0x1.7d995dad1b01ap+5);
}

void call_f28(void)
{
  f28(0x1.cf1a6da9f998p+1, -1518910039, -1607654603);
}

void call_f29(void)
{
  f29(0x1.14842d560a37p+4, 1473128726, -3305590614301434542);
}

void call_f30(void)
{
  f30(0x1.906b12247d51p+4, -613423447, -0x1.87727d845bbcp+1);
}

void call_f31(void)
{
  f31(0x1.73554208220fp+4, -3664856455106978918, 775993642);
}

void call_f32(void)
{
  f32(-0x1.3b4046343c179p+4, -2281112740324733311, -5570156521017131236);
}

void call_f33(void)
{
  f33(0x1.27f3c254363p-2, -4193600751476499094, 0x1.83d073d680ecp+1);
}

void call_f34(void)
{
  f34(-0x1.23a352476cfb6p+4, 0x1.b8259985b054p-1, -744195134);
}

void call_f35(void)
{
  f35(0x1.f7c78c12f522cp+4, 0x1.6106b27e3c608p+2, -4992434273277327112);
}

void call_f36(void)
{
  f36(0x1.0a099fc6d4a7cp+3, 0x1.7ea86cb6bc6acp+5, -0x1.088acf1b29a78p+2);
}

void call_f37(void)
{
  f37(-1445046092, -1975936579, 1730389472, 1478666504);
}

void call_f38(void)
{
  f38(2121459177, 2103463326, -228551895, 7195013931605585044);
}

void call_f39(void)
{
  f39(-1640768698, 1401296338, -98877459, -0x1.7498b57458c42p+5);
}

void call_f40(void)
{
  f40(-1384038326, -1274047355, -3503088096956866809, 28133347);
}

void call_f41(void)
{
  f41(-1355722973, -1123699173, -310356697724664812, 5530916566671647935);
}

void call_f42(void)
{
  f42(566498622, -164386158, 2454026593132767882, 0x1.334650848c9bp+5);
}

void call_f43(void)
{
  f43(-696938087, -1070080870, 0x1.17608ca595ef4p+3, 77906415);
}

void call_f44(void)
{
  f44(-199276533, -2145374759, 0x1.3a384bf073518p+4, 853874488809628856);
}

void call_f45(void)
{
  f45(1506521253, -1858410359, 0x1.174c8a971aa9cp+4, 0x1.95a932ddd5878p+4);
}

void call_f46(void)
{
  f46(-1959346214, -2764389137750137807, -1871219255, 2142923641);
}

void call_f47(void)
{
  f47(-1569901924, -6043704264483072140, 170333871, 262717837599596757);
}

void call_f48(void)
{
  f48(12610356, 7890885412985214173, -1114791576, -0x1.63a894d88733dp+5);
}

void call_f49(void)
{
  f49(-732874692, -7966584001606153128, 8201870088602307925, -1793312842);
}

void call_f50(void)
{
  f50(1943647114, -530483447763922945, -3063565391278754656, 2238207705307226773);
}

void call_f51(void)
{
  f51(1892913789, 7822206821611107814, 1140383201358012743, 0x1.f8a5108fc64bp+3);
}

void call_f52(void)
{
  f52(1089849600, -6453396190629267522, 0x1.e617159111c6p+3, 511105398);
}

void call_f53(void)
{
  f53(-579219014, 4875847001392206432, 0x1.6666e8d6da7b2p+5, -4148770280024345250);
}

void call_f54(void)
{
  f54(2019589566, 3643995881483418290, 0x1.303c017928c18p+3, -0x1.50a0d8fdfe7aap+5);
}

void call_f55(void)
{
  f55(-1764540629, 0x1.ee05e3df4ad08p+4, 147062550, 579382097);
}

void call_f56(void)
{
  f56(205924480, 0x1.58403a407323ap+5, 1881146979, 2502368680755852513);
}

void call_f57(void)
{
  f57(1837081861, -0x1.f6152a60bd36dp+4, 353368475, 0x1.082f29ade00b8p+5);
}

void call_f58(void)
{
  f58(2028339913, 0x1.603d4384a88p+3, -5209146470440639169, 454829462);
}

void call_f59(void)
{
  f59(-849235975, 0x1.b4aa17e858e2cp+4, -3470538958400062728, -2446134964275251616);
}

void call_f60(void)
{
  f60(819952374, -0x1.60b0d11dc6fdcp+4, 7922390524902826388, -0x1.ec6c0617c3f3fp+4);
}

void call_f61(void)
{
  f61(-1128257059, -0x1.570c225af493cp+3, -0x1.5e750b7e3dab3p+5, -1004428147);
}

void call_f62(void)
{
  f62(-1997500289, 0x1.71334196ef4fcp+3, -0x1.207aaf1ff6054p+5, -547787666650465496);
}

void call_f63(void)
{
  f63(384626661, 0x1.1d8acfcb3347p+3, -0x1.0087d4b26222ap+4, -0x1.83300d2afadc1p+4);
}

void call_f64(void)
{
  f64(-3685631349062350180, 1570397300, -1742504644, -750563089);
}

void call_f65(void)
{
  f65(97216063839586273, -1376062746, -1451620885, -6254705757323335590);
}

void call_f66(void)
{
  f66(-8384246231275541477, -2051755498, 469225311, 0x1.49ac09d0a5f4p-1);
}

void call_f67(void)
{
  f67(4096375621822253700, -532450537, 1512102459350253406, -599449141);
}

void call_f68(void)
{
  f68(2813896935711592399, 1408947757, -5497088006292366087, 2039206422884399344);
}

void call_f69(void)
{
  f69(3005607600168193821, 82599028, -6009762168677869894, -0x1.123327bf64a9ap+5);
}

void call_f70(void)
{
  f70(-3049073247352223820, 1938211837, -0x1.4d3e6a7e6e978p+3, 749165510);
}

void call_f71(void)
{
  f71(-4851250440027904151, 294853913, 0x1.4efb51527d2e8p+4, 8958506565527435041);
}

void call_f72(void)
{
  f72(4116966074951466500, -22622776, 0x1.9fe3fc9a5a5b8p+3, 0x1.34f04e72af2ecp+5);
}

void call_f73(void)
{
  f73(1924310484161439730, -5187201658317067911, -1883593375, 1176346314);
}

void call_f74(void)
{
  f74(-4162783042393750771, 1947624486602445359, -2114261717, 7415999042694616475);
}

void call_f75(void)
{
  f75(8306851171896508373, 1655943856802705669, -15766459, -0x1.0ccdb527067bp+3);
}

void call_f76(void)
{
  f76(6018749837755183769, -924026792401846729, 1538580925615931364, -380871711);
}

void call_f77(void)
{
  f77(-8817475389486941232, 7038150392182796620, -710116634788725456, -1125746084457454639);
}

void call_f78(void)
{
  f78(-2867377179166082689, 2438115870243609249, -5567481585363274997, 0x1.702ad9510438ap+5);
}

void call_f79(void)
{
  f79(-7392652832198131400, -2278402126921985524, 0x1.19f6223a7277p+4, 842257082);
}

void call_f80(void)
{
  f80(2766526116231485049, -6539455330709863584, 0x1.5b3112b6d7e4p+5, 5072028129040829001);
}

void call_f81(void)
{
  f81(-5388975356473619580, -363550020020937075, -0x1.283a624285da4p+5, -0x1.0f67f6107ea0ap+4);
}

void call_f82(void)
{
  f82(-1514223337871268699, -0x1.782e17fb6da91p+5, 382796591, -1289446421);
}

void call_f83(void)
{
  f83(8990493608382882555, -0x1.7bc8b0fb86f48p+3, -79725348, 2362011078066337442);
}

void call_f84(void)
{
  f84(6723161287530045277, -0x1.c113ab9f4985p+2, 292665972, -0x1.18667f9b9b755p+5);
}

void call_f85(void)
{
  f85(-6126799388973932805, -0x1.3eac6dd88a13dp+5, -8614159119768975220, 529773661);
}

void call_f86(void)
{
  f86(-3897469818935181801, -0x1.b2f66a5acccep+2, -3410629010478134551, 3023028825705722044);
}

void call_f87(void)
{
  f87(481733938141487684, 0x1.77f193b5d984p-1, -8116214728459333129, -0x1.a7a1895c713e5p+4);
}

void call_f88(void)
{
  f88(-6991194740902206945, 0x1.409d2f6ee7ac6p+5, -0x1.15bb2260b99e2p+4, -2008562512);
}

void call_f89(void)
{
  f89(6230788033825020966, 0x1.c12606b863d84p+4, -0x1.74cfd1826968p+5, -2581553745515055050);
}

void call_f90(void)
{
  f90(-6026619660610185780, 0x1.3e8899133b3e8p+4, -0x1.eae4d7d07ab31p+4, 0x1.4db9b0c9db11cp+5);
}

void call_f91(void)
{
  f91(-0x1.51ea7544bd4bbp+5, 657822410, -259680655, -1588868041);
}

void call_f92(void)
{
  f92(-0x1.614402b192af8p+5, 105355747, -1817190970, 596821572915558576);
}

void call_f93(void)
{
  f93(-0x1.345574cd53158p+2, -1344140964, -201762310, -0x1.1b5e3e815901p+3);
}

void call_f94(void)
{
  f94(0x1.5b73879065002p+5, 138831035, 5890915413734920096, 1170439507);
}

void call_f95(void)
{
  f95(0x1.914f4ef541e6cp+3, -901708113, -2248472009846266261, 5916914735009836092);
}

void call_f96(void)
{
  f96(-0x1.839dbbb724e6fp+5, -1453289939, 3805885858168182106, 0x1.4f6079b59ccc6p+5);
}

void call_f97(void)
{
  f97(0x1.e0a6809607158p+3, -226379304, 0x1.5d694b073972ep+5, -331382370);
}

void call_f98(void)
{
  f98(-0x1.d04897b5d458p+0, -1988060205, 0x1.65a5ae61be03p+4, -6378160163883348121);
}

void call_f99(void)
{
  f99(0x1.54a949342f7f8p+4, -446753604, 0x1.fa9f700d4f2b4p+4, -0x1.7abbdd38ecad8p+3);
}

void call_f100(void)
{
  f100(0x1.785eb43e3e9b8p+5, 8135181758416272486, 444288557, 1539643957);
}

void call_f101(void)
{
  f101(0x1.ccd0a9c2f1bacp+4, 2594920467080957417, 1661453363, -6931813258906711885);
}

void call_f102(void)
{
  f102(-0x1.01b149839befcp+4, -2446778831495484759, -131672199, -0x1.09471b45dff2ep+4);
}

void call_f103(void)
{
  f103(0x1.012b4305a4164p+4, 3493084762587142371, -8353956116721848834, -960835659);
}

void call_f104(void)
{
  f104(0x1.4c9d82e25096ep+5, 1079692642011568313, -5910386215838478255, -853223942979755708);
}

void call_f105(void)
{
  f105(-0x1.82cba080090ep+2, -4204779356924275974, -1453838133056313875, -0x1.5ee3e8f11e13p+3);
}

void call_f106(void)
{
  f106(0x1.4ecc0d1ff80cp+4, 4369025988183143195, 0x1.0d7cf31ff543p+2, 992757697);
}

void call_f107(void)
{
  f107(0x1.e2a77c99782fp+3, -446113700451689138, 0x1.07eb594a69418p+5, -8036129073541119462);
}

void call_f108(void)
{
  f108(-0x1.60092a5709dbcp+5, 6138812719369568698, -0x1.6000e47b89207p+4, 0x1.ae05f06d853bcp+4);
}

void call_f109(void)
{
  f109(0x1.3f231c6443c38p+4, -0x1.5916815731c6cp+5, -664509735, 850864379);
}

void call_f110(void)
{
  f110(-0x1.12070fdffa2bp+1, 0x1.3f12d053cadf2p+5, -918798096, 2159426877905288864);
}

void call_f111(void)
{
  f111(-0x1.70dc342d2fc07p+4, -0x1.775892a7cf36p+3, -90690405, -0x1.8c1eb17c835acp+5);
}

void call_f112(void)
{
  f112(-0x1.669f89c371c7fp+4, 0x1.876593d53775cp+5, 1796586587475423713, 1810921833);
}

void call_f113(void)
{
  f113(-0x1.33badf717d365p+4, -0x1.5b917bfede58fp+5, -3904746857552307209, -1465661783242108810);
}

void call_f114(void)
{
  f114(-0x1.0fe57a23d2f88p+5, 0x1.27514907bf828p+4, -1620968819502707764, -0x1.f55c57eef7d19p+4);
}

void call_f115(void)
{
  f115(0x1.b1623c71a2b58p+2, 0x1.515891563167p+5, -0x1.6b390de7bf05dp+5, 1114458038);
}

void call_f116(void)
{
  f116(0x1.6fbdee91a99a2p+5, -0x1.0be282fc42b42p+5, -0x1.d5953ceee778p+4, -4369754408188776218);
}

void call_f117(void)
{
  f117(-0x1.7a2812acec3c7p+5, 0x1.8e9010f21c408p+5, 0x1.6b5df6c3ecfd8p+2, -0x1.f742fc7054999p+4);
}

void call_f118(void)
{
  f118(0x1.5c329cf45a3e8p+2, -1154072941, -1958617229, 1209040476);
}

void call_f119(void)
{
  f119(0x1.41286af991318p+4, 1789290894, -162740179, -904784330988199112);
}

void call_f120(void)
{
  f120(-0x1.1fe6d381e6f1ap+5, -1472197982, -1837793097, 0x1.53012588e709cp+4);
}

void call_f121(void)
{
  f121(0x1.2728a877eb524p+3, 1071652809, 6320105014614788560, 792354742);
}

void call_f122(void)
{
  f122(-0x1.c55cd912e6d9p+1, 2137893632, -8736419640509049470, 3447512007547072430);
}

void call_f123(void)
{
  f123(-0x1.9296876cf3d81p+4, 2017027596, -7668136696906663294, 0x1.608d50b9da21ep+5);
}

void call_f124(void)
{
  f124(0x1.613fba2f70a66p+5, 335856087, 0x1.1b03cfca1b2d2p+5, 460985691);
}

void call_f125(void)
{
  f125(-0x1.02339a06901bep+5, 471009214, -0x1.2735a57e587bbp+5, 9038333908756567190);
}

void call_f126(void)
{
  f126(0x1.29c3c4eaf8488p+5, -933765704, 0x1.229610cd16a2p+3, 0x1.a634423d9d65p+3);
}

void call_f127(void)
{
  f127(-0x1.34c7c96f228a6p+4, -5158525646333457425, -420226156, -808909499);
}

void call_f128(void)
{
  f128(-0x1.1adb0e8ef791ep+5, -5901522585009499217, 296626979, -1246838133130280089);
}

void call_f129(void)
{
  f129(-0x1.34323045fc12p+5, -8778424889350918429, -1680442135, 0x1.985b75fffb9dp+4);
}

void call_f130(void)
{
  f130(0x1.d31d0341e5bfp+2, 4123036653640454683, -8146330331831504656, 40759530);
}

void call_f131(void)
{
  f131(-0x1.e716bf222a628p+2, -8548807017413479059, 3696032817293990332, 6194051204194735608);
}

void call_f132(void)
{
  f132(-0x1.8d745804e53b3p+4, -8771181705065488441, 7361763836308525961, -0x1.5e88fef0556f9p+4);
}

void call_f133(void)
{
  f133(0x1.2c4fbe964a16p+0, -5765134792816289955, -0x1.4f82048d372a4p+5, 254104975);
}

void call_f134(void)
{
  f134(-0x1.58fe5d2b9cad4p+4, -3216582421759950188, -0x1.253b2530ccedep+5, -7993269371005905925);
}

void call_f135(void)
{
  f135(0x1.0950a3bb5bdep+2, 842676686985466516, 0x1.23e1ba168f31cp+3, 0x1.712e62ea80988p+5);
}

void call_f136(void)
{
  f136(-0x1.8a940a9af1f0bp+5, -0x1.7b01d15d4faddp+5, 680468869, 1259447516);
}

void call_f137(void)
{
  f137(0x1.0921982472b9cp+4, -0x1.91c7f0107720cp+4, -483271256, 6436233302697777269);
}

void call_f138(void)
{
  f138(-0x1.6fd5433cfe2dcp+3, -0x1.0565de824adep+2, -1109569469, 0x1.81cdd3752b504p+4);
}

void call_f139(void)
{
  f139(0x1.7a21285a782ep+5, -0x1.3da512ca29e2fp+5, -4656627859361317666, 1391263886);
}

void call_f140(void)
{
  f140(-0x1.3cf7279c8cbd9p+5, -0x1.1e2fe964e2621p+5, 8379416732587422751, 7358346341353651142);
}

void call_f141(void)
{
  f141(0x1.4af278b735f5cp+5, 0x1.0caac579b39eap+5, -6783838905289834688, -0x1.22a5acdc7b9a4p+3);
}

void call_f142(void)
{
  f142(0x1.36986b7895d22p+5, -0x1.191113995caap+4, -0x1.8af519794e527p+4, 1964623228);
}

void call_f143(void)
{
  f143(-0x1.0ae03a8643801p+5, 0x1.7123526617e28p+5, -0x1.d76c7e2f21378p+3, 4256799072677778877);
}

void call_f144(void)
{
  f144(-0x1.d06a263de4f8p+1, 0x1.abd7230e6fec8p+4, -0x1.532f477b0360ap+5, 0x1.4236116f25428p+5);
}

void call_f145(void)
{
  f145(-1416889597, 989435626, 549881158, 1985631473, -1166221679, -892096705);
}

void call_f146(void)
{
  f146(514272135, 42417971, 1214146102, -284511380, -1815646765, -229073129, 1929277135, 802908122);
}

void call_f147(void)
{
  f147(-1996283125, -1448643279, 1887474008, 891641358, 636169479, 1229841940, 1551449701, 1531753642);
}

void call_f148(void)
{
  f148(-372205195, 1896203899, -824377265, 1300715519, -394731009, -1007005517, 1413980321, 1077625376, 1323240971, -381270210);
}

void call_f149(void)
{
  f149(636432176, 597083034, -397991165, -1635539635, -1072318227, 1891897078, -78072112, 2033699987, 1487976713, 871265326);
}

void call_f150(void)
{
  f150(-1976752092, 153693369, 1909645720, 145098420, 180688047, -1897243712, -401417275, 1525741539, 227031579, 182687599, 1786720666, -700648310);
}

void call_f151(void)
{
  f151(-813832358, 1617287439, 674741904, -1689932413, 228823011, -272260654, -1252414069, -111373395, -1100393839, -1488973280, -1992630175, 1336918965);
}

void call_f152(void)
{
  f152(854053192, -1865537446, -72472895, 1431150033, -355212525, 834702231, 696931964, -841584278, 1694736698, 1512734292, 723534493, -987499469, -1124635463, -1222947356, 167800257, -1397585518);
}

void call_f153(void)
{
  f153(1095598425, 1881687105, 2119507733, -222870089, 469662150, 835498177, 1344831068, -881533844, 740163245, -980083198, -1610444177, 1423080858, -1237381754, -1226179442, 1880629498, 1544603676);
}

void call_f154(void)
{
  f154(-624752815, 1039172962, 1417609089, -790620295, -1607062814, -1135571617, 461410476, 1868464243, 864959002, 1746220267, -88051703, -1304103250, -115509353, -376145423, 848523956, -1533487293);
}

void call_f155(void)
{
  f155(57605404, -960267905, 1203813435, -1536225593, 1298251681, -274471940, -445871988, -655054479, -996548042, 800167122, -1014681974, 598602536, -923070297, 1447867762, -816462611, 935566346, -1145805478, 535838414, 753779831, -177629987, 1050023806, -444193967, 95814945, 559535739, 1175548532, -649735938, -585249651, 1252130810, 390215065, -1413877754, 1372447392, -268873303);
}

void call_f156(void)
{
  f156(1157214751, 1589932050, 1476300076, -1430437561, -1229436278, -1962571362, 428826351, 295164091, -1060434379, -47508621, -37766873, -267438621, 539243951, -94908942, 1879063041, 168173221, 659372969, 1921467845, -644358521, -2132323439, 1853736657, 1062458584, -1924230095, -1686728487, -861751977, -2088103259, -560445732, 1544339429, 457068933, -787090403, 868295885, -960511181);
}

void call_f157(void)
{
  f157(-1719514255, 653247991, -1860247192, 198590481, -1814175504, 1663089875, -1633717052, 721673904, -1265683896, 239682285, 1164668419, 1756213581, -580464282, 1706252649, 14317483, 449790809, -505927198, -1445697325, -289864456, 1196824785, 1701047255, -627316430, -342995323, -773532940, 385752727, -1768470496, -623493518, 1620120436, -1054209673, 1082147019, -635026671, 2001266504);
}

void call_f158(void)
{
  f158(-5138430401274632811, -2065429908643735626, 7156747918579539497, 1889624012293684361, 7730674279948387405, -1361991442091970310);
}

void call_f159(void)
{
  f159(-5647120799942789603, 5681314785231712022, -7153494674054534766, -5604780313563474845, -6517368045522489634, -7996727095238576820, 7951850076805813309, 1072617192320951081);
}

void call_f160(void)
{
  f160(5370986570565925808, 8987646762597354743, 1313767108689385216, 310382890322352710, -7625140031200871166, 6230910873971966405, 3188053628766003827, 3894251671286241365);
}

void call_f161(void)
{
  f161(-8946778096555650251, -2376092173181403518, 5164654117555791239, 595918833979128647, 128963344397007561, 8612069310914500196, -4813145566795079855, -3838631481694339580, -1744735189103047269, 5978119237157745548);
}

void call_f162(void)
{
  f162(3328720460983628328, -9155901278121633934, 4889171545636726555, -6605337829112327554, -1721970875841844209, 1885059846851751772, 3183841180715191807, 4610083186076444933, 9064086029710947646, 1664735137301258800);
}

void call_f163(void)
{
  f163(1738534457876028595, 8398245934073599286, 2404150199276534881, -413469928417042782, 8075553462705350886, 6616730034542351317, 7225590006799330577, -3078810585043605504, -6913565872607961278, 3449295451502157911, 6321153245081853427, -5154469733998345801);
}

void call_f164(void)
{
  f164(-2636952044700804645, 2106706550183726330, -6976409780377772289, 4057518156153265300, -7477891924552959926, -6320855859911932033, 3935376049511752050, -6590015501619187600, -5399390337454439163, -2836254641330925163, -3971325912302539598, 8165075520375979388);
}

void call_f165(void)
{
  f165(8021367050294595689, 5966289387050517868, -7251756001158949497, -461282064023901131, 7109988575795088431, 7034939172948071308, 7424051237976585391, -1208494439316553845, 9120136251407028621, -7095616490480762670, -74090135265001715, 9210700778121023134, 3723443027841607681, -6924490146476521235, -3050881640756342740, 7333907952850625862);
}

void call_f166(void)
{
  f166(-4465419502713426560, 3554545626042267272, -8037095940923102799, -4038227020892648462, -7810359266076428556, 4869086151445624813, 4494448565390693015, 4944615466877424437, 4169686391845976670, -5045408152623293315, 7414262994632409334, -3193567555580175562, -7796428337446052608, 3534457841146480083, -6833732212678890153, 6937780809066017729);
}

void call_f167(void)
{
  f167(-1167674898460290603, -6359820037429637114, 8855730952456200504, -3158877631101955653, 8004260390163514096, 253178229707113610, -9124698134849112717, 378231293743041269, 3360430034956634054, 3215452256746537435, 8266611502231135777, -4158007861552482946, -2598023572967750354, -822036932612697331, 8049817753290897554, -2023975685860521022);
}

void call_f168(void)
{
  f168(7680766453139706011, -4173749765766461189, -3979651924177130329, 4302565634605308061, -3400428953905979642, 960494875819953564, -5407556641038319871, -3820755374648326114, -6243566852583913483, -1112621103225466691, -1972486418233502026, 5499555596280382977, -2514344024409023463, -7761116748253345247, -5857846572070150943, 3606497515113782022, -1787123078591100410, -8074837532177768375, -7573110075921279587, 4106671772660410051, -3366188543703054616, 1559156442762609988, 7618761467045217599, 7901044983409236442, -7846021161666937389, -8606577777302620539, 5028231680057739307, -2867357632849617873, -8801394156760143287, 1562463476130034573, 8727775012063320845, 9205346156416653280);
}

void call_f169(void)
{
  f169(-7123046257320256755, 8684778297488049079, -89071364333319842, 2716010182160077985, -7587916929990714799, 6439578625645459108, -2973129288417525763, -5416532997039398122, 1181881368689918297, 1297379220444967017, -7601942277525814791, 1329616920946101187, 7895414843047260292, -8208682825376253666, 285593680464961954, -1032623352286291047, -5730518312854327492, -2174934019558193692, -7538460525400492011, 7420349528745639309, 2240762522255761272, 3777878199679308190, 5234295786590818024, -3504737477111085989, 4621235212134634086, 5846513951038241238, -7792519515530593487, -9090833822273424832, 8128429077318725493, -1773330441488007043, -1597955878845432235, 6156657326302067351);
}

void call_f170(void)
{
  f170(3644771427546716394, 4138865106599557496, 2710136159944319893, -7405677939958724101, 4584557111659572086, -143619041452032619, -8136937344329903290, 8674866750732785226, -5389935272339472491, 6559957627809696811, -4241125726455397128, -3133532764997106330, 2368620295178091787, 6721548268360333262, 3246881501047318098, 5493454027407917657, 5329902734942066901, 3239767908675527246, -4062713956091839771, -9096902404860319124, 5797636537374168158, -4476829549485306179, 4799883693226891250, -4618506863822635254, 2675255833659187347, -4880096111261388088, 7192939112115659504, 7890614073790724546, 597206298824234801, 2765211231409344531, -189821609327887032, 8416332516349927221);
}

void call_f171(void)
{
  f171(-0x1.71ac5b773e687p+4, -0x1.61db95a1c1bd7p+5, 0x1.9e3bac299cea4p+4, -0x1.760879f9dcbbp+3, -0x1.2831a6696a717p+4, 0x1.ee5962549df5p+2);
}

void call_f172(void)
{
  f172(0x1.793ac644eabd2p+5, -0x1.a4da56907f0ap+2, 0x1.6af8258d26c1ap+5, 0x1.749eb80bee68p+1, -0x1.848a06b2abeep+1, 0x1.8a704e295beep+0, 0x1.c9ef30344313p+4, -0x1.34c8f69e8481ep+5);
}

void call_f173(void)
{
  f173(-0x1.497547b80c867p+4, 0x1.d4a059ea4f89p+4, 0x1.7cd073b5bbf5cp+4, 0x1.a578561fe9edcp+3, -0x1.31031a2ae68b4p+5, 0x1.3909e51ac6622p+5, 0x1.e09937b742e8p+3, -0x1.237a66bc123fp+4);
}

void call_f174(void)
{
  f174(0x1.42ae1cd3cff8p+0, -0x1.678f6bb15f73bp+5, 0x1.608bf197a3338p+4, 0x1.9f2b97e0392d4p+3, -0x1.0d472acbd4eeap+5, 0x1.e12aa3008f4d4p+4, 0x1.7e702a5c3085ap+5, -0x1.ef9c0b82d4918p+2, 0x1.384ad7e653198p+4, 0x1.a3089f8b3384p+1);
}

void call_f175(void)
{
  f175(0x1.338e86f7a93dap+5, -0x1.dde70f9cc6b5ep+4, -0x1.04bf8ae9be42ap+4, 0x1.1bbdc31f2374cp+4, 0x1.1d71c3d18c79cp+5, -0x1.730fcd46e9cd2p+5, 0x1.6adaee83c7334p+5, 0x1.33233ad04c414p+3, -0x1.b63687d4ac27p+3, -0x1.4d98e6e267f08p+4);
}

void call_f176(void)
{
  f176(-0x1.34253d9bc8074p+5, 0x1.ce808ac9ae58p+3, -0x1.900b6262193cep+4, -0x1.3f3f9dd25255bp+5, 0x1.dccd30ba59128p+4, -0x1.51821ae533164p+5, -0x1.563d3d4da2595p+4, 0x1.febcbe53e9e88p+2, -0x1.0db9448784a54p+3, 0x1.6784e119993dep+5, -0x1.cdc0e65c92422p+4, 0x1.59225318a5d8cp+4);
}

void call_f177(void)
{
  f177(-0x1.7952416389b0fp+5, 0x1.8af7d37fabc4p+2, 0x1.4c5d62b5438a2p+5, 0x1.0c2c591da004p+0, 0x1.af671c4940018p+4, 0x1.ae4f93f86e854p+4, -0x1.7ad853e0a3b95p+4, 0x1.4359fd3347336p+5, 0x1.8f5210796036cp+4, -0x1.212cba360e8cep+5, -0x1.ac900906dacdcp+3, 0x1.09827affb31f2p+5);
}

void call_f178(void)
{
  f178(-0x1.49d8e9e3c49b2p+4, -0x1.4d0ab2702ec94p+5, -0x1.210be61546e14p+3, 0x1.dc8fa2a4b8968p+2, 0x1.88439d19ca22p+5, -0x1.624515946c039p+5, 0x1.ad553d5922bd8p+4, 0x1.8c89fe58921c8p+3, 0x1.442c669461a24p+3, 0x1.0e7b52e72d2d8p+4, 0x1.011c1ffaddd4ep+5, 0x1.83bc80030cc66p+5, -0x1.aa78400de2a6p+0, 0x1.6015c58432c14p+4, -0x1.5cfa3ce89023bp+4, -0x1.5ff3cb94f62ep+0);
}

void call_f179(void)
{
  f179(0x1.61abced607052p+5, 0x1.4c74743111512p+5, 0x1.6209862920d34p+4, 0x1.6a88b13f8fcd6p+5, -0x1.74c0d8fc008d8p+3, -0x1.403ef4bc58ea6p+4, 0x1.4aee9f6264f9cp+5, 0x1.4441f28933e4p+4, 0x1.4809d3e58b42p+3, 0x1.3390b74c30878p+4, -0x1.40069ed5a81f8p+5, 0x1.ba75463b4fbfp+1, 0x1.aa97635cdbfc8p+3, -0x1.16728b2973ff4p+5, 0x1.5ec2dfc527fdp+2, -0x1.bb63586bdb6ap+1);
}

void call_f180(void)
{
  f180(0x1.195366cb27bdcp+5, -0x1.e3797235d0ap-1, 0x1.3a2a3b2f3d7bp+4, -0x1.13dd5df692a68p+4, 0x1.1510c5549ed74p+4, 0x1.02ceb09471e2cp+3, -0x1.8651ed57cfd5p+5, 0x1.9ddb22b2eebep+0, 0x1.3c6916f592bacp+5, 0x1.a7e74fca4e99cp+4, -0x1.b2b57bb6e83bcp+3, -0x1.407eed47bd612p+5, -0x1.455c3caa75cbp+2, -0x1.82a5b027a7f85p+5, -0x1.1b7a52c50c8b8p+5, 0x1.33cd2b0a7693cp+4);
}

void call_f181(void)
{
  f181(0x1.de2425d6e1198p+4, 0x1.0edd4e0e14a9p+1, -0x1.3bd852f6dff1p+5, -0x1.06e1f6833e6dcp+4, 0x1.ba5e3f7ae456cp+4, 0x1.5202de35e9f02p+5, 0x1.8e3a12734efp-2, 0x1.226e7b962258cp+5, -0x1.c65924cac7888p+4, -0x1.5543d4ba09fb9p+5, -0x1.4ec5f40d8354p+5, 0x1.90451623cadcp-1, -0x1.6fceb5f73d608p+5, 0x1.a918fff3ae638p+4, 0x1.8c7dad95066b4p+5, -0x1.c003da8c8040cp+4, 0x1.9ee19d78ccd3cp+4, -0x1.efc60ce0e5e7cp+3, 0x1.5c1f84fbeeaep+4, -0x1.bb19d7b368224p+3, 0x1.289e88b0ccc1cp+4, -0x1.37124e3a0978p-1, -0x1.56c21b3aa643bp+5, -0x1.3c9f67347841cp+5, 0x1.8383075fd09f8p+5, -0x1.e7efc513bf4c3p+4, 0x1.829d5a22d6ffp+5, 0x1.ccb0f6a809eap+1, -0x1.43c1ec1605e52p+4, -0x1.330bc45750b58p+2, -0x1.67d5cfdbbd6a9p+5, 0x1.8c4a9784e468cp+4);
}

void call_f182(void)
{
  f182(-0x1.8f89daf93601p+3, -0x1.b10598c64f753p+4, 0x1.42140cc444b0cp+5, -0x1.deb1b63962bfcp+4, 0x1.4dde9457122bp+3, 0x1.cb34289e2eff4p+4, 0x1.5ba6c3b69dfbp+1, 0x1.74cfc3792686cp+5, 0x1.378b91c93b45p+3, -0x1.58a57d387dad9p+5, -0x1.bfc0dc8d8727dp+4, -0x1.2e445e3e19b6fp+4, -0x1.6390a9a927028p+3, -0x1.c309cbc51297ep+4, -0x1.27d42a9d9c60cp+3, -0x1.d38fb51045095p+4, 0x1.6c07e2e741b34p+5, -0x1.4864b538f57c6p+5, -0x1.f4d0d716a5707p+4, 0x1.aa54b6c680f78p+2, 0x1.f7d975116fabp+3, -0x1.7f215900e5ddp+3, 0x1.f392aefdc2be4p+4, 0x1.22f7abdf466b4p+5, -0x1.93e2204c9ff09p+4, -0x1.503f9f2d7c1bep+5, -0x1.2d538bcd3db1ep+4, 0x1.28bf1c16f031cp+3, -0x1.5c419fcb731a8p+5, 0x1.876629e797e14p+5, -0x1.09f247593f08p+4, 0x1.718f80f79b7d4p+5);
}

void call_f183(void)
{
  f183(-0x1.4efe64df0403cp+4, -0x1.2a361da58b2a8p+5, 0x1.4da96a87ed48p+5, 0x1.6abbfa98a1a58p+3, 0x1.6236cf8caf65p+5, -0x1.11a60e5c36eap+0, -0x1.833819bf30b8cp+4, 0x1.6991c637af56p+5, -0x1.22b3e54c16a9ep+4, -0x1.717c4a0947121p+5, -0x1.099e0d7a827b4p+5, 0x1.03a62d91019fap+5, -0x1.0766c89d40e6fp+5, -0x1.591e1cb407f46p+4, 0x1.55ce0f6504f38p+4, -0x1.1985cc3c6497ap+5, 0x1.1ed790e7d9dcap+5, -0x1.b8ac6bd54ff3bp+4, -0x1.744ad56d6235p+5, -0x1.1824d06b89655p+5, 0x1.788b37026117p+5, -0x1.3b9aa8dac6668p+4, -0x1.aa4ecbf3c22eap+4, -0x1.3e6f6a66c3e74p+3, 0x1.8867900f93238p+4, -0x1.787fcfb628588p+5, -0x1.d171916d74b98p+4, 0x1.fa2e547aa6b6p+2, 0x1.6c36d4674468p+5, -0x1.a81f1d28b6296p+4, -0x1.5f0b90b29dbe3p+5, -0x1.db5f2251f6b68p+4);
}

void call_f184(void)
{
  f184(2101281900, 7795706548067128403, 1183029474, -4278502574447296935, -1837297251, 2703834400518781371);
}

void call_f185(void)
{
  f185(2057290366, 1514566922856904769, 338311350, 1624995520417472926, -580354146, 4722168328255427661, 1064787640, -5438458004764631589);
}

void call_f186(void)
{
  f186(-1196777746, -4349640348834612142, -1752043305, -8181940770191071313, -19542934, -1082112759578367330, -479499677, -8660010067636992744);
}

void call_f187(void)
{
  f187(-1206868551, -2165517234932522841, -1659473323, -2056072224643458229, -911429314, -3468357254070985133, -506758755, -7341876885028021983, 350726495, 907161223085417018);
}

void call_f188(void)
{
  f188(769832611, 2850135700643884849, -422193959, -626863810377284598, 832992912, -3406020066056130279, 830666051, 219340346850629006, -2086829476, 617791154256843269);
}

void call_f189(void)
{
  f189(32703162, 3686610974523805272, -515100259, -2265306312381088271, -623243022, -3435350100597533171, 1505276306, 5871427736792246667, -1836348415, -7953588449138844476, 1922578507, 3103963351908038982);
}

void call_f190(void)
{
  f190(2040383217, -7868679259815963714, 1178086693, 3858410342630167475, 1496055099, 543037399386287656, 1465777616, 1444590229324257099, -1052481189, -2554991559743879210, 1131147407, 1110379372601820984);
}

void call_f191(void)
{
  f191(-1587327106, 4587548386013910406, -1305870880, 6161502383126308140, -1596461089, 3012795587101044752, 705934465, -1184414321843717782, 808022229, 6787765901417159717, -859393046, 7688210307630695491, -1075200320, 8228686258748198786, 1004607381, 1145369775551292747);
}

void call_f192(void)
{
  f192(-1956439563, -7252997999685681699, 2031566435, -4153907580481520220, -1379650130, 5474505284148149177, -19745483, 5737434355556327344, -1890307557, 5983524845181210474, -1438792809, 2210759732536958727, -1097645518, 2717651289751120990, -1413457542, -299655281654888348);
}

void call_f193(void)
{
  f193(2005817930, 9124727616685238930, 1175841930, 1299902380951791643, 392771098, 5204900592519685591, -1942272654, -4495603742408276254, -1054983971, -7853534566400334987, 1748646090, -2967970573914480619, 937089175, 6558853782901673302, 1797562881, -1133183291748726600);
}

void call_f194(void)
{
  f194(1622292222, 8602393661277762853, 1490214699, -2995625662755041992, 1693557030, 8728158255088310309, -1487573766, -4791501633878555527, 1915101845, 3442378124667900717, 1537851202, 7068217606749267212, -664512239, -4775239207752964933, 629168398, -2109445881971704641, -1383677233, 7056438772573304515, -480780430, -9188876383750096929, 888730129, 1979672478103890791, 1052473259, 1936166498865635077, -1057274670, 4562235459385479731, -1129619964, -243587917047033645, -1567781665, 404534679445506861, 270856395, 7446348214805072298);
}

void call_f195(void)
{
  f195(1675709691, 1764487498711989127, -1678426139, 5819752496118659423, 659955275, -6302243808785743709, -1691274873, -6454939088536412389, 452944661, 7012404946277384296, 1364441287, -8105842358062750625, -94490555, 3141735048510226230, -1239181832, -2890719911977649552, -78972422, 2331562392741038947, 539131628, -8294485743144085619, 1794723783, 4002318007288614474, 935716287, 8280802302393157835, -656920485, -7150249304022632740, 1954832142, 6149505987229525728, 481565089, -1963872804924400213, 470984548, 2950949638210749720);
}

void call_f196(void)
{
  f196(1924095644, 4200497026230075488, -368105140, -8022696757634398598, -710489218, -68840199802498301, -1027386084, -4494299176534079520, 589556588, -9007851611009677318, 617282110, -5780353032551804269, -251308531, -7487164526307168264, 340881166, 3942896681735280149, 185870479, 6366677771156053955, 544618658, -2291350537356801921, 102371990, -1746350616343134264, -629579251, 8942101680030711439, 1096722260, 8243126499962979472, 1035026792, 8122397152700875184, -557730099, -7471356718194690361, 514239217, 8775300646252608308);
}

void call_f197(void)
{
  f197(-1829262212, -0x1.67c36e94664fap+5, 1256504760, 0x1.19bed4642555p+1, -487516088, 0x1.c6bc866ba1838p+4);
}

void call_f198(void)
{
  f198(867195587, -0x1.7999027557ad2p+4, -1737574096, 0x1.90cc01fb67088p+3, 1763585465, 0x1.414ea0c2cfff6p+5, -2081183474, 0x1.126704753942p+2);
}

void call_f199(void)
{
  f199(-625621609, -0x1.a3bbbf654f2adp+4, -38585282, -0x1.0d222afc0aep+0, 996915887, -0x1.ae98708634954p+4, 761476581, -0x1.0705351bdfd98p+5);
}

void call_f200(void)
{
  f200(388213404, -0x1.d89a326e62b8bp+4, 1469220609, 0x1.528ace548db94p+4, -519305307, 0x1.2607835772d48p+2, -493637302, 0x1.60ca089b6a25cp+5, 223724096, 0x1.3cce8129fbe1p+3);
}

void call_f201(void)
{
  f201(-91128154, -0x1.238cb21d28567p+4, 2038052731, -0x1.8cd0fa13d062ep+5, 1415295420, -0x1.f60737c42d234p+3, 1771216603, 0x1.8aa2512150188p+3, 208715035, 0x1.8aee4d51ae492p+5);
}

void call_f202(void)
{
  f202(-577548883, 0x1.5229edde5c62p+2, -1328148949, 0x1.beabb138c307cp+4, -1684205015, -0x1.e27b045a40c4cp+4, 1679057669, 0x1.153b316a1cd1cp+5, -1890371794, 0x1.89dca6ad9b87cp+5, -1440297963, -0x1.5072144a50f1ap+5);
}

void call_f203(void)
{
  f203(967165480, 0x1.cd160bdc3b4c4p+4, -1237342091, 0x1.101ee8a2ee15p+1, -490392152, -0x1.848347b99a1c9p+5, -1391386089, 0x1.2a51a809363ep+5, 348707521, 0x1.5865fd610f8c4p+4, -767210357, -0x1.7a26cd184234fp+4);
}

void call_f204(void)
{
  f204(1411820846, -0x1.32d0e0e2cdeb2p+5, -1815515642, -0x1.404a59ce160f2p+5, -50601225, -0x1.a1a40587797dep+4, 392048417, 0x1.eba7c2c882be4p+4, 1054113911, -0x1.3bfd9c0aae064p+4, -1518317381, 0x1.1d628757f8cd8p+3, -1706140960, 0x1.b4d64bbec1f48p+2, -811361998, -0x1.6407eadab615fp+5);
}

void call_f205(void)
{
  f205(-1304686793, 0x1.18765ae33ba24p+3, 8328634, -0x1.755541d3bd21bp+5, 529201262, -0x1.51c465d6aaaa4p+4, -1720800926, -0x1.3920ccf8fed3bp+4, -1701625325, -0x1.1831fd19472f4p+5, 2049872961, -0x1.2b41745eb7588p+2, 347062261, 0x1.db5acaa51e4f4p+4, 1520638345, 0x1.f628c95775b8p+2);
}

void call_f206(void)
{
  f206(263792395, 0x1.ac0209abaa5c8p+4, 989265161, -0x1.745c98ffe058p+1, -1646967273, -0x1.047712e93708p+4, -644651992, 0x1.288dd5602b20ep+5, 778818461, 0x1.f8dac193f3468p+4, -1937098666, 0x1.6132869a5a3fap+5, -440883994, 0x1.5088e66b9e57cp+4, -241060713, -0x1.a9adf029b4814p+4);
}

void call_f207(void)
{
  f207(85848435, -0x1.7215666a5c26p+2, -514535422, 0x1.c1b0b74c614e8p+4, 1727818286, 0x1.1bd161ea9649ep+5, 801350404, 0x1.4dd87b8c64b5p+2, 432446956, 0x1.4b2c276550d64p+4, -1435806555, 0x1.14bef0eb7fde8p+5, -1920537403, 0x1.daf258edf22bcp+4, -587965555, -0x1.cb06213160e61p+4, 695571911, -0x1.3cbc525983f1bp+4, -1429491980, 0x1.4c3da4c74b318p+4, 220092288, -0x1.e4425749f04fp+1, 893499725, -0x1.12a3adcbd449ap+5, 1070919864, -0x1.731e3186c895ep+5, 141471065, 0x1.d70ff69bfcffp+2, -1573848151, -0x1.8394b2090326p+5, -558277291, -0x1.d0291ce895568p+2);
}

void call_f208(void)
{
  f208(285989980, -0x1.b161a28114664p+4, -26110409, -0x1.76411d590262p+3, 303801445, 0x1.5c1d9f64ea3ep+2, 1088365329, 0x1.05c538c4086dp+5, -112575152, -0x1.23e85f3116941p+5, 842610607, 0x1.0ded10d7557bap+5, 19756698, 0x1.3ae92e28f8348p+5, -1453937196, 0x1.24a00d92c19bp+3, -1259371359, -0x1.c8cd260b6f4f4p+3, -1338447145, 0x1.3f9302a8fcc08p+3, 629714221, 0x1.5a962236e1962p+5, -2058883027, 0x1.255340539ep-8, 77266830, 0x1.6f4473ff105d8p+2, 1912205329, -0x1.866726c583028p+2, -1638125478, 0x1.97f4d10c470b8p+2, 424062823, -0x1.50c27b4d51a11p+5);
}

void call_f209(void)
{
  f209(1997647214, -0x1.3b96de69357ccp+4, 582375435, -0x1.188d09452b02p+0, 1528406927, 0x1.6f4536ddb56ep+4, -872382992, 0x1.64998d42df63cp+3, 502729657, -0x1.14a2826372e44p+3, 1503246997, 0x1.99b82b63c2d8cp+4, 1947852619, -0x1.c3ba5a37e696p+2, -1595325650, -0x1.5ed4e08c0ddbcp+3, 1612908721, 0x1.49f95b03f32acp+5, -1258536580, 0x1.48d0bbb35d13p+5, -838605495, -0x1.265946da69d36p+5, 1720493830, -0x1.8fa6bb0f7a68p+3, -1531371345, -0x1.6948fa13c8a81p+5, 5299772, -0x1.1b089d003e664p+3, 894035418, 0x1.4c67b5e426f52p+5, 113813725, 0x1.56d5e0407e198p+5);
}

void call_f210(void)
{
  f210(3809642546361448317, -0x1.83a8a6e8d91c1p+5, -4009334498260084411, 0x1.7cb9cabe2e064p+4, -6461888156724207201, -0x1.270d9a3dfd2d9p+5);
}

void call_f211(void)
{
  f211(-6470335657427498220, 0x1.62b03476f8ffp+5, -6324878543430706112, -0x1.085cb5f9f6b1ap+4, -7115861557478825103, 0x1.26cb20912c75cp+5, 7402884048386665510, 0x1.8d7ecdb27272p+3);
}

void call_f212(void)
{
  f212(-6999533128592504298, 0x1.9f44cd500b21p+3, 2908717789388991894, -0x1.4b588a0a88ac3p+5, -6161641352145761067, -0x1.d005ffacba17fp+4, -2794924262900712764, -0x1.6800521afbc4p+5);
}

void call_f213(void)
{
  f213(-7756277013377958434, 0x1.6774c958abba4p+5, -7653069727141566306, 0x1.0b08058c434f4p+4, -3021758889749575568, -0x1.465b8d80d3eb2p+5, -2652144505998481228, 0x1.810a4d5b0906cp+4, -7516643584455971919, -0x1.5b71591f33a15p+5);
}

void call_f214(void)
{
  f214(791873458626076711, 0x1.3ed10be364b2p+2, -2673244282983360304, 0x1.dc9c9120f921p+4, -5621757522872000374, 0x1.103b201f9858ap+5, -6118850144409082166, 0x1.7f595fa6366ecp+4, 2916286790195564370, -0x1.26e22b4b19368p+5);
}

void call_f215(void)
{
  f215(-6709103496690611001, -0x1.a9d14b2f873dfp+4, 7437094676907782317, 0x1.4d2c83f18bdp-2, 2595897417912636049, -0x1.5b57dbfbebb1fp+5, 8430391118025657778, -0x1.604564b0a431cp+5, 6546609744353350034, -0x1.8acfdc4b3092p+1, -1684749779270411960, -0x1.c37df55a5a2fap+4);
}

void call_f216(void)
{
  f216(-5434459602411747367, 0x1.2de4ca695bac8p+4, 6926035893535265179, -0x1.b1d79eaa1b2efp+4, 4460362269111323745, 0x1.154ea279322acp+5, -2697307470402865399, -0x1.12bf7f6c68cfep+4, 3739629809658903244, 0x1.2c5b8e9653666p+5, -2853060826382266171, -0x1.002e99e46d278p+5);
}

void call_f217(void)
{
  f217(-6041082342366437429, -0x1.11f01575a30bdp+5, 7349883861154805331, 0x1.8509190ea427cp+3, 2016008965206351131, 0x1.588a97bf612f4p+4, 6597878428224964135, -0x1.8b8defdf0718bp+4, 6521771674801712981, -0x1.9cac2815820ap+0, -8814050392180975356, 0x1.f7510a2155efp+4, -7434909045184700397, -0x1.41aec47c03674p+5, 6113108154725150236, -0x1.406ede471c66ap+5);
}

void call_f218(void)
{
  f218(6752687191631752432, -0x1.3d39d3e228094p+5, -3684296718839465818, 0x1.96f0f17702f64p+4, 2534387275290051572, 0x1.a66a9067a6f58p+2, -8133644112867496132, -0x1.39919fb8c0278p+2, 6546526313682422971, 0x1.81a1d742f99acp+3, -1910855404217623825, -0x1.5ad45c7dca985p+5, 6212851175673903907, 0x1.7036b8a1077cep+5, -6352486478068732432, 0x1.3796541ddc1cp+1);
}

void call_f219(void)
{
  f219(4238693618901641292, -0x1.071fcbfaa259cp+5, -7402920289884219606, 0x1.584ffd8376e18p+5, -5130065475684308470, -0x1.c354b7e81bf28p+3, 3633412501166066037, -0x1.7eff44cea31p+2, 2841502822633153931, 0x1.aaf6a0ecc116p+0, -29325127467614001, -0x1.33c23ea49b155p+5, -1286062573990353741, -0x1.6fc8a02b12a79p+5, -1674725291415045733, -0x1.077cbb916e88cp+3);
}

void call_f220(void)
{
  f220(2752703929500466541, 0x1.06d8f42068f4cp+4, 6543223271806673124, 0x1.3b1e397d5ad5cp+5, -703373875341566723, -0x1.e608df5f7897dp+4, -4659879749672752105, 0x1.90d703e5851f8p+2, 8221574054508186320, 0x1.53a618f6e5e72p+5, 4576606807310476014, 0x1.c212251659908p+2, -4177802448300814336, -0x1.82c14fcd9f858p+5, 557781998832873777, 0x1.0349adcbd544p-1, -9003100464182381163, -0x1.c5aa70edb8904p+4, -3066163619781376778, -0x1.0e7e87e37abbcp+3, 4072014796293902764, 0x1.2f3533d63194cp+4, 5156848834818604039, -0x1.49c6fd7af4becp+5, -8785776237861602248, 0x1.4cf3602c19e18p+3, 5711601050988866569, 0x1.e34353b26af9p+3, 154277128294263651, -0x1.27b94820e4fc8p+2, 5625560203284085893, -0x1.6405a5bbb0d6ep+5);
}

void call_f221(void)
{
  f221(5708576668523360894, 0x1.79d373fb03528p+3, 8676594468273064664, -0x1.7fc40a5330194p+3, -5680086517367370380, -0x1.3a54c275d319ap+5, -4122729870963773149, 0x1.1ed2a31775678p+2, 3806485273945370087, 0x1.75387a72b8aap+5, 7762471959644051070, -0x1.526c8496c465p+3, -30451852103140096, -0x1.991d86477db7p+1, -1414322154554077432, -0x1.5fc4bc4264c38p+5, 7616091551292295606, -0x1.77eb2aa49f4a6p+4, -4711440631684733053, -0x1.1297d955fa04ep+4, 2627199423882454337, 0x1.449b610c93f2p+0, -1859637581171241234, 0x1.122e8a09b488p+5, 3147626218843032488, -0x1.5de7ddde140b6p+5, 6088454465651888992, 0x1.d8f4bae679b58p+4, -2262929244611470129, -0x1.00ef6efdbc63p+1, 3885067062799455433, 0x1.d7df7112748dp+3);
}

void call_f222(void)
{
  f222(-4059841820591761865, 0x1.0919838d9443p+4, 3967026355621114618, 0x1.27204b475c7p+4, 7564584116651377815, -0x1.c98f2b8a49097p+4, 6601428471629196807, 0x1.9a08e27f83788p+2, 868644070098517752, -0x1.807aeb7694fdbp+4, 8004872032578307313, 0x1.62db5109ca6c4p+4, 4785801764088872046, 0x1.25b73e5521668p+2, 8586031223180042616, 0x1.db4c40b9f4cf4p+4, 3840614249491433503, 0x1.1ac97d7b69d18p+2, -330935148507099720, 0x1.d819a239b943cp+4, -2036618730679336579, -0x1.5ca7da3187478p+5, -4952543996741785342, -0x1.0896e0fe6da64p+3, 5252210869316814940, -0x1.8364a7e3b007cp+5, -4594533007969215430, -0x1.316d8edb0c81p+2, 5222965446399891275, -0x1.62e0b4239718ap+4, 930875816963334098, 0x1.6eb00ba7aa9dp+1);
}

void call_f223(void)
{
  float r = f223(880610492, 0x1.6ce820a897b1ap+5, "k", 1273198395, 0x1.5e3898dde5ccep+5, 544018559, -1029698568, 0x1.62029a85bdc62p+5, 3141849129382149905, -5300491126696668083);
  ((r == -0x1.1f2ce6p+3F) ? (void)0 : failure("r == -0x1.1f2ce6p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1122,__func__));
}

void call_f224(void)
{
  f224(0x1.be1685d13687p+1, 0x1.33f230cd8442cp+3, "", -0x1.dd60c139a2437p+4);
}

void call_f225(void)
{
  char * r = f225("", 0x1.6b4f2293090bp+4, 0x1.7c78225e0041p+3, -0x1.6a5e5721bc867p+4, 0x1.d18818c41c32p+4);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1133,__func__));
}

void call_f226(void)
{
  signed char r = f226(-0x1.cb57a6b69bf6cp+3, "c", -3300438537967555521, "hp", -1041135359131854169, "h", 5827440436972359970, 860055996966095937, -1073276577, 8116031199702340492, -0x1.2e896c76f3fd8p+3, 0x1.8957b8635a0d4p+4, 607257622119277083, "");
  ((r == 76) ? (void)0 : failure("r == 76","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1139,__func__));
}

void call_f227(void)
{
  f227("", -8599929139656498242, 0x1.2eaf19ad086ep+3, -0x1.80a2f78db02adp+5, 0x1.65e1587c2b53cp+5, 2086504945491028097, -1199192389, 0x1.445a9fc1ba218p+2);
}

void call_f228(void)
{
  f228("w", 2809425053381553650, "", "wx", 4543034236897786663, -276605100, "m", 0x1.c7c54023e3568p+3, -4819284075335764486, -1301142930, "qa", 0x1.8e59a1ce91254p+4, 7042241250012258875, -721974744206171562, -1357189151, -403123671, "w", -602960374, "", -1300076022247124446, -7588476048231447857);
}

void call_f229(void)
{
  signed char r = f229(-0x1.a5178362139cap+4, -0x1.2f2b60c19e854p+5, 7256277085474007404, -0x1.4aeb7a8435c71p+4, "n", "", -1044445959, 0x1.fb86964d64f04p+4, 0x1.8567220d522eap+5);
  ((r == -81) ? (void)0 : failure("r == -81","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1155,__func__));
}

void call_f230(void)
{
  int r = f230("vq", -0x1.a5edea8b8719p+2, "", -922105604, "", "", "te", 52252314, -9068210845888585775, -5287244800092113263, 3572553085994510538, 0x1.6ad9c4be671b4p+4, -165297705, -1048354480);
  ((r == 286260549) ? (void)0 : failure("r == 286260549","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1161,__func__));
}

void call_f231(void)
{
  char * r = f231(-3695914098913012632, -0x1.0ffc55e83fefp+3, "", -0x1.3fb0dd580246bp+4, 7574380728876675419);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1167,__func__));
}

void call_f232(void)
{
  short r = f232("m", 0x1.bc749caee4638p+4, -0x1.90c09c19ba113p+4, -9162505659793198055, -3660690917292719455, -0x1.174426db4a746p+5);
  ((r == -22969) ? (void)0 : failure("r == -22969","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1173,__func__));
}

void call_f233(void)
{
  f233();
}

void call_f234(void)
{
  unsigned char r = f234("", 987082487, 0x1.142f9ecb65232p+5, -12304927, -0x1.81892eb0270c3p+5, 1208013192, 0x1.052b32b225acp+5, "", -6807747391203424966, -873548909);
  ((r == 251) ? (void)0 : failure("r == 251","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1184,__func__));
}

void call_f235(void)
{
  unsigned char r = f235(0x1.27a27261e58b8p+2, -391508697, -588244090, 0x1.e95bab39bf798p+2);
  ((r == 196) ? (void)0 : failure("r == 196","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1190,__func__));
}

void call_f236(void)
{
  char * r = f236("m", 97250955, 0x1.126d50ddc91f8p+4, 0x1.5a08e0344c8aap+5, -1508273131, -0x1.6609dfe23b294p+5, "", "p", 1491401258, "x", 207149725193556738, "ng", -1883277528, "vu", 0x1.54f584764955cp+3);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1196,__func__));
}

void call_f237(void)
{
  unsigned char r = f237("", "eo", 0x1.3a92c1894175cp+5);
  ((r == 185) ? (void)0 : failure("r == 185","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1202,__func__));
}

void call_f238(void)
{
  char * r = f238();
  ((strcmp(r, "f") == 0) ? (void)0 : failure("strcmp(r, \"f\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1208,__func__));
}

void call_f239(void)
{
  f239(0x1.f464296dee01p+1, -0x1.45e825adeac28p+3, 3832952752884498014, 0x1.86e5a0b973bacp+3, "", -691543214, -6162242494010868692);
}

void call_f240(void)
{
  f240(-7316156671842081657, -0x1.19f538206dedp+3, -0x1.c6324f19778p+0, "sb", -0x1.06547be6370f2p+5, "a", 1135653425, -0x1.a6f8e276358p-2, "ir", -3608169333670370893, -6878237425665761835, "ra", 1571928758, 1256777652);
}

void call_f241(void)
{
  signed char r = f241("h", -0x1.9bb9d52d34f8p+1, -207883433, "", "", 333418184, 0x1.2d522f53d2668p+4);
  ((r == 90) ? (void)0 : failure("r == 90","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1224,__func__));
}

void call_f242(void)
{
  f242("w", "", 0x1.336176744f4p-2, 4523374572555496023, "", "ct");
}

void call_f243(void)
{
  f243(1320571200, 1365941225, 0x1.8fe877d99bb3ap+5, 7329066605434923229, "q", 0x1.2efaa5b7fd48cp+4, "", -750565070, -0x1.160a52e7f9396p+4, 0x1.03d675b600f8p-2, -7080219741100790363, 6972123897562786603, "", -1250391001282373804);
}

void call_f244(void)
{
  f244(-8152968387778153094, -0x1.6718623044ae8p+3, -912440311, 0x1.7ba73116fab2ep+5);
}

void call_f245(void)
{
  float r = f245(-0x1.38ed45a94e075p+5, -5460263765386238908, -0x1.89ff7d195b45cp+5, -5891634392922006036, -414769906, -270024581, 6017685922514238267, -908472266062452516, 952459785, "", 0x1.afd3d3a4a2098p+4, 0x1.41a8a016e311ep+5, -8525630846104331613, "", -0x1.8de9a391a2277p+5, -6570065531223612091, 6733711639975330794, "m", -1576755067, "k", "");
  ((r == -0x1.15cb86p+5F) ? (void)0 : failure("r == -0x1.15cb86p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1245,__func__));
}

void call_f246(void)
{
  f246(-1501240518, 0x1.26e111a241fp+2, 6714299586112261130, 3036778064058806478, 2749411040150391977);
}

void call_f247(void)
{
  unsigned short r = f247("m", "iw", -4451967061161765446, -8977036637405289888, -0x1.6c63639774ff4p+4, 0x1.383a9597441a8p+3, -7011191395967215723, 0x1.e5dd48b35795p+3, 0x1.a33568c95e38p+3, -15072578, "s", "a", -673721585, 2742864179678774140, -1493525618);
  ((r == 18555) ? (void)0 : failure("r == 18555","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1256,__func__));
}

void call_f248(void)
{
  f248();
}

void call_f249(void)
{
  f249(939067254, 0x1.072cf7358f7cp+0, "", -0x1.9b9466bc3ecep+3, 577572031, 0x1.2cc8ed4f5a07ap+5, "b", -0x1.6f30c8e6f9856p+5, -0x1.6451fcd3aae58p+3, 0x1.1d7e9660e2d52p+5, 0x1.9bf08c43ae0cp+0, -0x1.ab256812345afp+4, 6690649529174387163, -948893389, -0x1.2790b891d3cccp+5, "j", -163136395, "ec", 432846000, 737326890);
}

void call_f250(void)
{
  f250(0x1.2f67fc0aab74cp+5, "", -8836281921504108420);
}

void call_f251(void)
{
  f251("", "ws", 0x1.a5c1ca45e9724p+4, -0x1.fadceb2e58fcp+0, 0x1.92dcc79be22b8p+4, -0x1.77f6bc4c9d02ap+5, 0x1.26b6b5a6b9dc4p+4);
}

void call_f252(void)
{
  f252(-0x1.67fd622a92d82p+5, 100990779, 0x1.3333bcaacdcep+2, 0x1.605a6ff31e794p+3, 0x1.c94035f3517e8p+3, 0x1.3dcb37389c11p+4);
}

void call_f253(void)
{
  f253(-0x1.a3757174a6584p+3);
}

void call_f254(void)
{
  unsigned char r = f254(-989371757, -0x1.55c98b4350195p+4, "ux", "", "");
  ((r == 185) ? (void)0 : failure("r == 185","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1292,__func__));
}

void call_f255(void)
{
  signed char r = f255();
  ((r == 104) ? (void)0 : failure("r == 104","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1298,__func__));
}

void call_f256(void)
{
  f256(-0x1.95da89ca32a4p+3, 8978686881529881035, 0x1.0b81b11f31ad2p+5, -1920695739, 0x1.8530cc7b5d6bep+5, -494354937276477104, -0x1.bb34aec5bf548p+2, "w", 1974430537, 0x1.a133d2e4a6ca4p+3, 0x1.7d81662ac4c14p+5);
}

void call_f257(void)
{
  unsigned char r = f257(-3908210990047860652, -444129001, 0x1.7c9bf3c5d174p+5, 0x1.cf4481c9e326p+0, 0x1.5754f0fd42778p+5, -8656765496303253453, -0x1.bda299b2a4c8cp+3);
  ((r == 36) ? (void)0 : failure("r == 36","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1309,__func__));
}

void call_f258(void)
{
  f258(0x1.ceeede4b67b38p+4, -6265762273774709740, 0x1.7655e8323832p+2, 1199686515, 0x1.ea9ccbd44c0c8p+3, -0x1.1a8ac15b62df3p+5, -3514874873839182359, "", 1144766677288378375, -2695176154197637678, 2825741283999616923, -1900323635, 0x1.87db9b320055ap+5, 216352714324506497, 2068087488, "a");
}

void call_f259(void)
{
  f259(890063932, -1486954930444078655, 0x1.37c7157aa36c4p+5, 2998869292701908817, -1314668356077915067, "", 1124252401, -7402478993823088180, -0x1.32cf0a78c7f42p+4);
}

void call_f260(void)
{
  float r = f260(0x1.74f5cb72c3c4ep+5, "by", -0x1.47a78268dd201p+5, 0x1.03ef0f80f883p+4, -0x1.6238429b0c2p-1, 0x1.ed4b470e75918p+2, "zl", "", -0x1.e90664f69bdd8p+2, 0x1.c1bdcf1a0b994p+4, -0x1.3dad23c499d94p+4, 3968630348213579551, 0x1.7eb20ab13941ap+5, -0x1.4e6bcc26bd03dp+5, 0x1.2f135f0811574p+4, -1007378504, "i", 0x1.7549768be766p+2, 7298324271780221166);
  ((r == -0x1.5f2b28p+5F) ? (void)0 : failure("r == -0x1.5f2b28p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1325,__func__));
}

void call_f261(void)
{
  short r = f261("", 0x1.43488ba39fac2p+5, 0x1.b49860cdfbf84p+4, -0x1.a597d86b57c9cp+3, 158909944, 0x1.c6c524e36d36p+3, -0x1.9f0edb2931b68p+3, 0x1.0fce2b5b953e4p+5, -8218966984318768657, 0x1.9f86e5f87d6c8p+4);
  ((r == 29363) ? (void)0 : failure("r == 29363","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1331,__func__));
}

void call_f262(void)
{
  float r = f262("", 0x1.6948eea20655p+4, "h", -7901966172405414212, 7369277243254479830, 4581971966023530667, 0x1.1da7f0cd829dp+4, -2403406700373077348, 5715981931932128689, -127678299, -1267337855, -3805783430338707645, -2833317500795931353);
  ((r == 0x1.365a94p+3F) ? (void)0 : failure("r == 0x1.365a94p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1337,__func__));
}

void call_f263(void)
{
  f263(-0x1.8439df46cb097p+5, "", "", -0x1.4b07eeaa49ca4p+5, -0x1.34e36135bdcb9p+5, -0x1.e750f4b79134p+1, "", -0x1.956be902c8cbbp+4, -12010147, 7984857244712650717, 0x1.86799c2ddd4acp+4, "w", 583332379);
}

void call_f264(void)
{
  f264();
}

void call_f265(void)
{
  f265(92353621, "", -0x1.7f04dccb34a78p+2, "vj", -2096794158, -0x1.243a38e30009p+1, 0x1.2825527ad5178p+3, "b", 0x1.952aca0639018p+3, 0x1.cd8a6a85338d8p+4, -346233905166944054, -1114405677, -1036915709, "m", "i", 1090137098, 2146154468, "", 0x1.974f1d8122dbp+3);
}

void call_f266(void)
{
  short r = f266(3217584677624396343, 5677788257559738958, -1852479952, "s", -0x1.41f550d133f6ap+5, 1309782083, 0x1.b5bf8f0f1886p+4, 931531639, 0x1.8591d4200ee4ap+5, -8751720270110101972, -0x1.9935824fc957p+1, -3328472866171462715, 1705246427);
  ((r == 9781) ? (void)0 : failure("r == 9781","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1358,__func__));
}

void call_f267(void)
{
  f267(-2230124832077227184, 832087808, -1521717384517654668, -0x1.e0025d21ed174p+3, 794786085, -0x1.8f4585b9a3911p+5, "ps", "e", 0x1.98d493d770578p+2, -3069066533352165817, "h", -6038625584820556154, "k", "ko", -3040165652053014353);
}

void call_f268(void)
{
  f268(-0x1.ccbfd19e94982p+4, 0x1.4db0ffbdbdc82p+5, 0x1.3352a3b3bfd08p+4, "o", 7839817676736996027, 0x1.04c5e035c3144p+5, 429381756, 0x1.a8913348810ap+4, -0x1.3d607cb917e7p+5);
}

void call_f269(void)
{
  unsigned char r = f269("zn", 1596881650, -3449836571455753779, "lg", 0x1.565140d13ae7cp+5, 0x1.5d97044ebf8b8p+5, -657087953735463251, 352355355, -0x1.30622adfe7cecp+5);
  ((r == 34) ? (void)0 : failure("r == 34","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1374,__func__));
}

void call_f270(void)
{
  f270(-429761115495277992, "lo", 1800762868, -0x1.d0781f0cf9ffp+2, 0x1.f4caa42d90aa4p+4, 0x1.28a1837bc13p+5, 1167375819432843989, 87396051, 0x1.58720339fc12ep+5, "", -2770974134527863667, -0x1.3cd359d18f79cp+3, 1242010516);
}

void call_f271(void)
{
  unsigned short r = f271(-5893027839152564854, 0x1.8285c4a2afd4cp+5, "", -1557074689, 0x1.63055ff55159p+5, -240812134);
  ((r == 23035) ? (void)0 : failure("r == 23035","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1385,__func__));
}

void call_f272(void)
{
  f272(-0x1.a378c476f17cp-1, -0x1.1853c4be978c4p+5, "c", -0x1.a93f5d7959644p+3);
}

void call_f273(void)
{
  short r = f273(-2556731478262355512, -1014341553, "", 4233826779247381790, -0x1.4e16bbed54ecp+1, -974151317624007898, 0x1.9f269c339e37cp+3, "q");
  ((r == -28371) ? (void)0 : failure("r == -28371","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1396,__func__));
}

void call_f274(void)
{
  f274("", 0x1.455035e35016ep+5, -0x1.16e93e3ffc068p+3, 0x1.45a7fd9b45ebcp+5, -4004193673729815144, 1845146161, 0x1.6e9fb0769788p+2, -506491829, 0x1.8607079716a46p+5, -0x1.ec30557d0bcacp+4, -1691667939);
}

void call_f275(void)
{
  f275(0x1.d8faaa8d6b8d4p+4, -1664524600, -1487500134, -7908050929654297658, 0x1.a36fd2c504d4p+3, -0x1.535a20f0c2152p+5, -0x1.054f28067d6bp+5, 1178251491070235999, -3828392848763181658, 0x1.c2272e3ffaeep+3, 2344318826756630718, "zh");
}

void call_f276(void)
{
  unsigned char r = f276("", "zm", "gu");
  ((r == 76) ? (void)0 : failure("r == 76","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1412,__func__));
}

void call_f277(void)
{
  int r = f277(0x1.bc09fc94cb458p+2, "k", "", -0x1.4b780378f733p+3, -309446255, "et", "i", "ri", "", -4847486021229121143, "u", "lp", 6294645278751895415, 4048669065798390876, -0x1.80f4a0de709bcp+5, 1856986039, -130408865);
  ((r == -1737506065) ? (void)0 : failure("r == -1737506065","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1418,__func__));
}

void call_f278(void)
{
  char * r = f278(-0x1.3ea103522bddp+5, 0x1.c89b8f0d10d68p+3, 0x1.45a552561764p-1, -0x1.564e9bdc32bbp+4, 0x1.8bfd7f155c6a4p+5, 0x1.46f82011d5fccp+3, -0x1.f0594e27a0d4ep+4, 1707270703, 4069615313214599605, "pw", "", -0x1.06c2e2d66c928p+3, -0x1.333de054c4b9cp+3, -0x1.dd6ea4eaab36cp+3, -2129993028, -2073451964, "", "", 3321606546225789514, "c", -0x1.1a8cea40ba71cp+5);
  ((strcmp(r, "w") == 0) ? (void)0 : failure("strcmp(r, \"w\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1424,__func__));
}

void call_f279(void)
{
  f279(0x1.2007a26fd0fap+3, 0x1.26b00f397f6p+4, -1776718043, 1608912595, "f");
}

void call_f280(void)
{
  f280(0x1.48be50837aa2cp+5, -0x1.a7e51861b3378p+4, 0x1.8decdbacad99cp+5, "mb", -4016557388191931175, 521977516, "b", -0x1.419cac63daad7p+4, -0x1.fb1b608113bp-3, 0x1.d512233de0a7p+3, -0x1.77e678aa45c7bp+4);
}

void call_f281(void)
{
  f281(-839737046748985754, -0x1.8c3d25ab41e81p+5, 0x1.581927db972b6p+5, -120163677, -0x1.13786e9ae2c2p+2, 107715119, 0x1.eb9b22e747964p+4, 0x1.21c68867756ep+3, 16583983585740786, 640700276, 4768094562670639616, -0x1.817ad5a24348cp+4, -5720705267226117732, -3460233239669716951, -0x1.191bc9c6a3ebp+1, -7084056397084253353, 1417185194, -0x1.d3b9463c81bcp+1);
}

void call_f282(void)
{
  f282(7770609864033053056, -0x1.3e8996a4db6bp+1, 0x1.9c2bd7fa4dd6cp+4, 0x1.039e91796e684p+3);
}

void call_f283(void)
{
  f283(0x1.21e7e67377672p+5, 5044897394613003977, -0x1.0dc863b061dep+5, 551037213, "gb", 824214662, 1608512937, -8559449919500890771, 510464226, -37040991, -1091371049, 8695283464068969290, "", "", "");
}

void call_f284(void)
{
  f284(0x1.1154833b2a862p+5, 8074402528906806057, -0x1.0e6ed639c8bd4p+4, -0x1.4d85aedb7a45dp+4, -4445826599959131050, 0x1.3f65674ee7edep+5, -7089671770062263364, -1977961490, 0x1.f1e875ebcf7c8p+4, "uh", -1645527570, 0x1.c1881c4e7c164p+4, "e", "");
}

void call_f285(void)
{
  f285(-0x1.329b0ad536029p+5, -0x1.a3c80a8d0a63cp+3, -0x1.9a6f1ee5a79p+2, "qa", 439093181, 0x1.bc6c8b66f66c8p+4, -0x1.451f157df8645p+5, "k", "f", -0x1.0363d496c1f2p+1, -0x1.73b6f1c2600dcp+4, -0x1.8749a0f3fcdb9p+4, -0x1.43ac2b582644ep+4, 1698399027, "", -3317519536534328383);
}

void call_f286(void)
{
  f286(0x1.0799b85ef60ecp+5, 1906569674, 643833280, -1684391956, 1427520970, -0x1.1e1e446cde628p+5, "", 2122290320, "d", 0x1.11da48df728fp+4, -1653247220, -5969084465317180479, "gc", -3640534786734645904, -8634779851483398858, "pw", 8344854363560466330, "h", 384816347558204149, -1025822029, "tc");
}

void call_f287(void)
{
  f287("wg", 363865308, "x", 0x1.bc6b20257761p+3, 0x1.8cf34af516648p+4, 5296646, -0x1.2c9e20fbc43bep+5, -1272758997, "u");
}

void call_f288(void)
{
  signed char r = f288("", -0x1.28f4b515c0471p+5, 0x1.259d836c54de8p+4, 0x1.18384a79719dep+5, -5116100821650663821, 0x1.bc98b2e4f024p+2, -8877452586158159727, -1979311235326881472, -404818647, 7156926551408759865, -6032662564851510327, -0x1.46c642e3ce8b8p+3);
  ((r == -110) ? (void)0 : failure("r == -110","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1475,__func__));
}

void call_f289(void)
{
  unsigned char r = f289(6709027574004452074, -2763770865711647265, "u", -0x1.8881836788a5dp+4, 5121137855786418276, 1548939395, 1176808764);
  ((r == 253) ? (void)0 : failure("r == 253","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1481,__func__));
}

void call_f290(void)
{
  f290(-101121801, 0x1.c0b7417f352c4p+4, 0x1.c4dbaa769d64p+2, "", -0x1.6422374d00c3p+5, 5962643340995458044, "fe", -455943489805169284, -1272959198, 1123158765, -0x1.b953f7da24c7p+4, -36225555, -306915776384125125, "lb");
}

void call_f291(void)
{
  char * r = f291(-1340835137, -5501544465815069939, -0x1.686fa002ce64dp+5, 119747036, -0x1.b6ff9808d0c5cp+3);
  ((strcmp(r, "c") == 0) ? (void)0 : failure("strcmp(r, \"c\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1492,__func__));
}

void call_f292(void)
{
  f292(8797221812402295465, 6520443597826758523, "iv", -0x1.a455a59683c1cp+3, -6538572752034084702, -1880465097, "q", -1874710201, -845756039, -0x1.a97194b89fbd9p+4, -0x1.616509c80e201p+5, "jz", "", "", "hm", -0x1.08241c0dbdddep+5, 1882505267496089566, -0x1.b91607f476218p+3, "r", 0x1.f42258f854134p+4, "", "");
}

void call_f293(void)
{
  f293("t", -786862960, -0x1.8754cfd025524p+5, 1351883227508626244, "v", 664916448, 868205271, "q", 0x1.4af5e4ae82d14p+5, 0x1.eb4b5106f9f38p+2, 0x1.3a3aab9fe8428p+3, 0x1.6c7e653a74cd8p+3, 41985585, -1486809495624857503, -2089001220, 2733367569982352213, -1647409091, 6560559117785584341, -0x1.5a6b4e08811fcp+5, -0x1.852c2ad4501dp+2, 143786259);
}

void call_f294(void)
{
  f294(1109858847, 1372635160225514051, -0x1.465acb246096ep+5, 0x1.212c8138f036ap+5, 1162499627, -7423316620761680386, 0x1.79feda0e968b4p+4, -0x1.ace36e4b6414fp+4, 2053456871, 55897399064173843, 8872540622966396017, 0x1.45f2378584e32p+5, "k", -3020280165285786140, -0x1.0a43fd3cfcecap+4, 786279045, -1624923133, -6921651157792110514, -185422814, 0x1.5051bc3504c9p+1, -0x1.86e1458669087p+5);
}

void call_f295(void)
{
  f295(-0x1.253a39284cb9fp+5);
}

void call_f296(void)
{
  f296();
}

void call_f297(void)
{
  double r = f297("", -1353191396, 0x1.de73d8ad0e31p+2, -3540834271338585729, "d", 5369893235386119860, 2082502130, -397430094, -0x1.61b9221b35d65p+4, 0x1.14b4e144b4e5p+4, -0x1.02020c41b9658p+5, 6399971092696596247, -0x1.81b3db4bf49bp+3);
  ((r == 0x1.d632b527a5a08p+2) ? (void)0 : failure("r == 0x1.d632b527a5a08p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1523,__func__));
}

void call_f298(void)
{
  int r = f298(-5803320444362264310, 0x1.6276a05f12afp+3, 0x1.b6aaa17026948p+4, -0x1.59299be710687p+5, 0x1.16446b7cb5feap+5);
  ((r == -1200611673) ? (void)0 : failure("r == -1200611673","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1529,__func__));
}

void call_f299(void)
{
  long long r = f299("s", 2114795634863991725, -1883303616, "", -1014162939, 0x1.ab6aecec45fap+2, 1500285433, "fu", 0x1.1d479b2f978aap+5, 379252973, 0x1.82f3bf214f4p+3, -1081121856, -3485704085356731557, "jx", 0x1.82d23e603b464p+3, 768945262);
  ((r == 3261839270162720307) ? (void)0 : failure("r == 3261839270162720307","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1535,__func__));
}

void call_f300(void)
{
  signed char r = f300(-0x1.5f4ae2e94c5eep+5, 930210981, 0x1.724173239bc64p+3, 2400505231399532723, -0x1.6a9a70b813e4p+0, 7149506365124953165, 559349466, -2169577933277872766, "c", 0x1.85c3348c8be34p+4, 1092637433, 8644750014683195574);
  ((r == -55) ? (void)0 : failure("r == -55","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1541,__func__));
}

void call_f301(void)
{
  short r = f301("rp", -0x1.521034eb53d48p+2, -665678461, 0x1.1587d4f54f1dcp+5, "tv", -6038235396445270668, "dh", 4185627410046074882, -0x1.1a42774bb7f7p+5, "m", -495295021510510004);
  ((r == 3940) ? (void)0 : failure("r == 3940","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1547,__func__));
}

void call_f302(void)
{
  int r = f302(1970278027, 1333712801, 2011791611276024140, -3338786086826683408, -0x1.9d0fdfde0085cp+4, 0x1.6f0eaa497e57cp+4, 0x1.52245f2277b48p+3);
  ((r == 1899175422) ? (void)0 : failure("r == 1899175422","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1553,__func__));
}

void call_f303(void)
{
  char * r = f303(-0x1.1fcd9f03a2aefp+5, 594117695, -0x1.17885b4ae81f2p+5, 0x1.65efc01d51ca8p+3, -0x1.8f7d979c5e8c7p+4, 1032051699229147231, -1242366118, 763099127, "bb", -5408719227798632180);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1559,__func__));
}

void call_f304(void)
{
  signed char r = f304("", 1607956844, -1981948734327254087, 0x1.1edab1d817404p+4, 0x1.6327f8293986p+5, -7332213299969842499, 8576515980854068487, "v", -0x1.214f44b7dc134p+3, 2931145958212816711, 5963167713423805735, -0x1.7c8a25cb68fap+0, -0x1.4e843196b3632p+5, "d", 9006980420434566160, 1373712959, -34744644, 0x1.1b7960b4c8ea8p+4);
  ((r == 61) ? (void)0 : failure("r == 61","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1565,__func__));
}

void call_f305(void)
{
  unsigned short r = f305(-1027546187753116087, 1703615785, -0x1.397db52519908p+2, "u", -0x1.ef5e965a9161fp+4, 812022985, 0x1.2e66d938e018p+4);
  ((r == 21734) ? (void)0 : failure("r == 21734","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1571,__func__));
}

void call_f306(void)
{
  f306(-148927269, -3893315862952420552, 7810850944044496350, -0x1.ef0a207920599p+4);
}

void call_f307(void)
{
  f307(0x1.2b9e1bdf4f8c2p+5, 1213685802, -652508038, -7484149774706094256, 2264147161327955050, -0x1.7b5918b481265p+4, 1141972039877428590, 3039512631733764634, "if", -0x1.1ba6fc744bb98p+2, "", -8294162568352746105, 0x1.de199d63aba74p+4, 7607425947228141580);
}

void call_f308(void)
{
  f308(836924912, 1060251425908117377, 0x1.78414f09016cp-1, -1118199102, 0x1.dba090acb4ff8p+2, "q", 833231539216552331, -0x1.49b577a6cd011p+5, 5433900494262014283, "v", "i", 0x1.2d9162977e9a4p+5, 1340548581, 1142475742, 1316365061968508428, "", -0x1.e4e9493796aep+2, -1344136922527227462, -7852662167239208475, 1985611907536137206, "");
}

void call_f309(void)
{
  f309(0x1.835e90230a8c8p+5);
}

void call_f310(void)
{
  long long r = f310(0x1.e88e5a05560dp+4, -0x1.b3a98e80cbf62p+4, -1549559531, -1635970016, -0x1.df9601102967cp+3, 1334300516, 30196541, -0x1.c54317ece53cp+3, 0x1.30347f2812132p+5);
  ((r == 9149232225553254770) ? (void)0 : failure("r == 9149232225553254770","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1597,__func__));
}

void call_f311(void)
{
  f311(505267456, "fe", 0x1.0d8d996ee7c5cp+4, -3173312054587419831, "sv", 1534421037, 2871227460534947046, 65643992, -839017892, "", 0x1.1843a7d2423ccp+3);
}

void call_f312(void)
{
  float r = f312(-0x1.773e1c7e18283p+5, -473758487, -0x1.3a0a17b43ccc4p+3);
  ((r == -0x1.50bfb8p+1F) ? (void)0 : failure("r == -0x1.50bfb8p+1F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1608,__func__));
}

void call_f313(void)
{
  long long r = f313(-0x1.6ac13d35d6df4p+5, -3162037854224500493, -6125512784319098696, 0x1.56581f2646d8p+0, 6085739115341688864, -0x1.52ffb2430f996p+4, "v", -3361986261829733019, 5390249354751479333);
  ((r == 2376056816018432602) ? (void)0 : failure("r == 2376056816018432602","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1614,__func__));
}

void call_f314(void)
{
  f314("", "zk", 0x1.880c139118c58p+4, -0x1.1105dcd9143c5p+5, -1346102255, -0x1.e32796c3925fp+2, "", 749401044, 0x1.87485a2d6d304p+4, "", -1900273843323265671, -5408185105142591795, "", -0x1.36f8e961756c6p+5);
}

void call_f315(void)
{
  f315(867303121, -0x1.e7e49a96a7ec8p+3, 7416495100021317280, 0x1.2871b0207b64cp+4, "j", -0x1.df6cc7b4df74ep+4, -0x1.4659ad354b196p+4, -0x1.7ec068373959ap+4, 0x1.9a410150f8d48p+3, 0x1.1ee5bd1d674f4p+5, 325435585, "wr", -1435149548, "dj");
}

void call_f316(void)
{
  f316(0x1.8f634feadd284p+4, "qr", 834815937, -0x1.b3ba978835edap+4, -2889622290121868931, "", "", 1658297061, -9153574820629202453, 1812846022029390968, -1251462846);
}

void call_f317(void)
{
  f317(547226019, -0x1.7a446c0a64b3p+2, "al", -543784106517300044, 6901134813524877173, -38766804, -0x1.031cb2fd2459ep+5);
}

void call_f318(void)
{
  unsigned short r = f318("t", 1769344242, 1635704816, -7803741436329943862, "l", "in", -0x1.84e2465fe8d32p+4);
  ((r == 3079) ? (void)0 : failure("r == 3079","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1640,__func__));
}

void call_f319(void)
{
  f319(0x1.18bc2350a218p-2, 2774735404388523627, "of", "k", -0x1.69c6cbb70f246p+4, "m", -389525730, 0x1.c0aeca5b42ea8p+3, -0x1.6357e3fb88abdp+4, 1407503431, 0x1.84f13c7040c6cp+5, 0x1.30fa87c663308p+4, -8904775086370790423);
}

void call_f320(void)
{
  unsigned short r = f320(0x1.e3e0111832528p+3, "", -0x1.492cae1592652p+5, 8706879762223533449, -6760091726060669588, 0x1.52b468d45fd8cp+3, 3681685589883336094, "", -0x1.9b91ae47e09cp+2);
  ((r == 14882) ? (void)0 : failure("r == 14882","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1651,__func__));
}

void call_f321(void)
{
  f321(-4950567851095398179, -5059543581525121931, "x", "hd", -7588035842918834892, -6816100002953717038, -4878717707357634315, "", -6964331653969348695, "w", -780173396, -133067726781169623, -0x1.1e97b78a83379p+5, 0x1.6840af5ff5bbep+5, "z", "", 6563803130227107814, -3435679631573555052);
}

void call_f322(void)
{
  double r = f322("cz", -0x1.7ed757ad31736p+4, "", "x", -0x1.45cdd47ac6fe4p+3, -0x1.301009a96e581p+5);
  ((r == -0x1.75d3b6edc4c99p+4) ? (void)0 : failure("r == -0x1.75d3b6edc4c99p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1662,__func__));
}

void call_f323(void)
{
  double r = f323();
  ((r == -0x1.447e7ae0e125fp+4) ? (void)0 : failure("r == -0x1.447e7ae0e125fp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1668,__func__));
}

void call_f324(void)
{
  int r = f324(-0x1.ce55f85745fbap+4, "fv", "", -1801134832682844197, -0x1.a77e815a44a4p+4, "my", 7543797139295504822, -13098737, "i", -2114490671, -7523845368020600293);
  ((r == -1725395142) ? (void)0 : failure("r == -1725395142","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1674,__func__));
}

void call_f325(void)
{
  f325(-0x1.5dda13eff1cf3p+5, -1448341360, 0x1.44e2d72f2ad8p+5, "", 0x1.018b2466dcd94p+4, -0x1.75db7a090206cp+3, 0x1.53833705b786ep+5, -0x1.d0c2a3e4fd54cp+4, 1517898047, 0x1.6b733014cf05cp+4, 4045590874656630804, 1926312397026696236, "c", -526359235);
}

void call_f326(void)
{
  char * r = f326(-0x1.e4e8d830de6bp+1, 447695550354088923, 632707567, -6587565192326759569, "", -1422892359);
  ((strcmp(r, "cb") == 0) ? (void)0 : failure("strcmp(r, \"cb\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1685,__func__));
}

void call_f327(void)
{
  f327("", 0x1.0220e9fd890fp+2, 802674590, "wg", 0x1.7520a49539356p+5, 0x1.3cc2978ea641p+4, 0x1.eccb304744b68p+2, "mf", -0x1.33e1070d58f71p+5, -1721523586, 0x1.244b22d013b0cp+5, "d", -4179595550387229823, 1649280346, 0x1.1e541463549f4p+5, -8135973523165024345, 1026926927);
}

void call_f328(void)
{
  f328(-6940665796129561359, -1632080728290254324, -1915284138, "", "pw", -0x1.30d1f3050fa4cp+5);
}

void call_f329(void)
{
  short r = f329();
  ((r == 19559) ? (void)0 : failure("r == 19559","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1701,__func__));
}

void call_f330(void)
{
  float r = f330(0x1.46a2d23f36b36p+5, 0x1.143d3726d358ep+5, 0x1.899e209224fcep+5, 4061965947723704342, -557035097313091816, "o", -6316212609333064407, 0x1.7f79ee8dbd0f8p+4);
  ((r == -0x1.0e1978p+5F) ? (void)0 : failure("r == -0x1.0e1978p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1707,__func__));
}

void call_f331(void)
{
  f331(0x1.04e8a513075bp+5, -0x1.dcb35aeae477ap+4, 2811174495189676234, -3793123838630687984, 1351427010, "", "", "sn", "d");
}

void call_f332(void)
{
  f332(-0x1.352e1c4cbcd4ep+5, -240799484, 408815127, -8266241600563963339, "j", -1969894396, -0x1.e10e29867a48p-2, 2122866641, 0x1.eb3682ff509ep+4, 1328700006, -1723773860, 1302081103, 4087217794739298836, 6704474645156904863, 8957558363750598774, 201873732, 0x1.d3a25ac0893fp+2, 1947801495, -1091422502039343554, 1481263984);
}

void call_f333(void)
{
  f333();
}

void call_f334(void)
{
  signed char r = f334(0x1.4a00f79a5b2eap+5);
  ((r == 105) ? (void)0 : failure("r == 105","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1728,__func__));
}

void call_f335(void)
{
  f335();
}

void call_f336(void)
{
  signed char r = f336(0x1.765863017639p+3, "", -3951152112832662524, "v", 1364360627, 0x1.efdbf7ec0f95p+2, "n", 4688722018086858146, -0x1.65113a47de99p+2, "wn", -6186335732350758366, -5957221583890933712, 0x1.0a0ff5a86dfeep+5, -0x1.eb73925f0c781p+4);
  ((r == 28) ? (void)0 : failure("r == 28","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1739,__func__));
}

void call_f337(void)
{
  unsigned short r = f337(0x1.f958037fc9698p+4, 383381210, -1867670715, 0x1.66b688b1236f8p+4, -0x1.1453c779ec93ep+4, 5172103878154495345, 85807667580961982, -0x1.69c53b22189fdp+4, "bu", 1703853116142916199, 0x1.bbe659fbc33ap+3, 0x1.d91fc7abffe64p+4, "");
  ((r == 40149) ? (void)0 : failure("r == 40149","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1745,__func__));
}

void call_f338(void)
{
  double r = f338("", "", "", "cp", 1709742282, "", "z");
  ((r == 0x1.bf76125538a78p+2) ? (void)0 : failure("r == 0x1.bf76125538a78p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1751,__func__));
}

void call_f339(void)
{
  f339("u", 0x1.2206806b8a732p+5, "q", 0x1.fd146560b078cp+4, "", "j", -56011054, -4373959091616431264, "", -2021368604, 0x1.0d3ff6aa3aa9ep+5, 1049005904, 520645667, 0x1.151e7014af292p+5, -4520916292909034400, 6116188741433837355);
}

void call_f340(void)
{
  long long r = f340(0x1.631c4bd40ccbap+5, 0x1.4f9b469302718p+2, -602422128, "zv", -1108162089871436829, 1467150173, "w", -750980166474877259, 0x1.08ba6dca9c5ap+5, 0x1.4456c26de4c28p+5);
  ((r == -8341874066178998339) ? (void)0 : failure("r == -8341874066178998339","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1762,__func__));
}

void call_f341(void)
{
  f341("", -4611087756606470939, -1389444925, 0x1.4c436861336e8p+5, -0x1.07dc5d6b2f66ap+5);
}

void call_f342(void)
{
  long long r = f342(-0x1.5657d9c819afep+5, "ea", -1911210377, "i", 397481054, -0x1.6c7bca4ab8b28p+5, 0x1.b77d49c2c301p+4, 0x1.3b0d79297b0bep+5, -6817759528235100378);
  ((r == -7426741672165475965) ? (void)0 : failure("r == -7426741672165475965","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1773,__func__));
}

void call_f343(void)
{
  f343(180523198, "z", 0x1.490ed4dd9347ep+5, "rd", -0x1.729f30158043fp+4, -0x1.cf73910c23888p+2, -564770630, 0x1.e0214cb391d84p+4);
}

void call_f344(void)
{
  unsigned char r = f344(-8968000023492187537, 3219442348896526502, -389904367, "q", -0x1.30aec0566cca2p+5, 0x1.0cc2bc7840064p+3);
  ((r == 218) ? (void)0 : failure("r == 218","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1784,__func__));
}

void call_f345(void)
{
  int r = f345(-7649725443728123747, 7910656067213300869, 7166397673402158031, "", 0x1.370196ecb1f34p+5);
  ((r == -309664137) ? (void)0 : failure("r == -309664137","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1790,__func__));
}

void call_f346(void)
{
  f346(-0x1.6598318b6b8fap+4, "h", 893864118, -4372952471077333114, "", "h", -1530338664, -9088936009987987223, -639424147, -2040643005, 3110366407399508454, "f");
}

void call_f347(void)
{
  f347(7756954086193292355, 1800388071, -9171515906443593038, "ov", "yx", "");
}

void call_f348(void)
{
  double r = f348(-3375239158681947824, 524313065, -0x1.1f1af3cec8c7p+4, "i", 0x1.54fd15612afe8p+5, 0x1.12bf877b26a86p+5, 1936183670, "r", -1979321463189905076, "e", 1455566127, 1079210708, 0x1.0d97f76f89f18p+5, 0x1.1a4e7bc49998p+2);
  ((r == 0x1.88904aa657adep+5) ? (void)0 : failure("r == 0x1.88904aa657adep+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1806,__func__));
}

void call_f349(void)
{
  signed char r = f349("v", -0x1.a1ed32c0b268p-1, -0x1.5b0e5a5ad7f0bp+5, "x", -1578599436, "", 0x1.5f166c49650f8p+4);
  ((r == 78) ? (void)0 : failure("r == 78","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1812,__func__));
}

void call_f350(void)
{
  long long r = f350(0x1.1ff8222e1705cp+5, "c", -0x1.3eefdbc6467d1p+4, 6097632932126221279, -0x1.2603da5fbc78cp+3, -0x1.cadb3efdeb2acp+4, -369166610);
  ((r == -4153376280086276203) ? (void)0 : failure("r == -4153376280086276203","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1818,__func__));
}

void call_f351(void)
{
  f351(-2060497350, 0x1.82e4ce627a2dcp+4, -1186306408, 1774898463929680753, "g", "pm", "", "a", 1193087540);
}

void call_f352(void)
{
  f352(-2819812719553000558, 0x1.5d33244b35c9cp+4, 2475336530287483154, 406326674, 1313469490707118699);
}

void call_f353(void)
{
  f353(-1119708459, -1634327276, 0x1.749da60d8f322p+5, 0x1.038a1c6da5c18p+3, -0x1.c73acc52ae5dbp+4, -7351408073255723591, -0x1.3b2a13af16638p+3, -0x1.486a5310a480bp+5, 0x1.08b02fd5dd764p+4, -0x1.9c77e1ce1e1b8p+3, 3705418758406717489, 2081925174, -5321363941451550026, -467980341, 729275595, 1333747591, 5651593142186218488);
}

void call_f354(void)
{
  unsigned char r = f354(-0x1.99994ab4da2e8p+3, 1961269057, "", 8653310565015019493, 0x1.331d2226ad8fp+4, 1068426168, 1147229647, "cg", 207835852, -937802677, -1347782403, 3171625199926625229);
  ((r == 91) ? (void)0 : failure("r == 91","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1839,__func__));
}

void call_f355(void)
{
  f355(-0x1.7951c7ba48b3p+2, "", 0x1.6b34e0739eb5cp+5, 1972889107, -407004843, -762650224, 0x1.ac520bfc00f5p+4, -723372812131976737);
}

void call_f356(void)
{
  f356("p", -1469795892, -0x1.3673b06c37a2cp+5, -0x1.aa8b900c6e9c7p+4, -0x1.9e604e3508c08p+4, 608138053, 0x1.7b3d9b37ae338p+4, "jk", -1200846830601239226, "", 336471127, 0x1.6df122a65e8aap+5, -0x1.3b3ff5c945101p+5, 588089471, -0x1.852b0745c3b17p+5, 125895612, 4512699241279415353, 8964225839131482500, 0x1.90c2dca287a98p+3, 1968860061);
}

void call_f357(void)
{
  unsigned char r = f357("", -107296598, -0x1.b56806e13f6b4p+4, -223257523, 955806436, 0x1.b8769166a8be8p+2, -0x1.ff781b735c6ep+2, 0x1.563652d9329cep+5, 0x1.81e3aa565c5d2p+5, 1679385774, 859744905, -630277354, -2011785399, -287681752, 129736644, "d", "", "r", "", 1390465477);
  ((r == 68) ? (void)0 : failure("r == 68","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1855,__func__));
}

void call_f358(void)
{
  int r = f358(0x1.a839da6cdbfp+0, -0x1.51cb454282aep+1, "a", -0x1.08fd68dc196d8p+2, "h", -1970004248, -0x1.0fdcd62a44f78p+5, "", 0x1.30c26d4e47a8ap+5, -0x1.b222a794p-9, "", -1442407926, "z", -0x1.5b19aaf293c61p+4, 0x1.879038c73852p+5);
  ((r == -1207689981) ? (void)0 : failure("r == -1207689981","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1861,__func__));
}

void call_f359(void)
{
  f359(-0x1.21f9a6462f7bcp+3, -0x1.276ba881f7f5fp+4, 1473532388, -0x1.fde04c778e188p+3, "n", "qg", -1091520624, "un", -6593823468793108761, -8319434273037475647, -4377699855107254355, -0x1.b18586198f1cp+3);
}

void call_f360(void)
{
  f360(1109400404, -1292826199, 1265586749, -8806130752219285635, "ky", -0x1.650425bf5f845p+4, 7424528221564074095, -6451539246473953774);
}

void call_f361(void)
{
  double r = f361();
  ((r == -0x1.e4920dcebbf84p+3) ? (void)0 : failure("r == -0x1.e4920dcebbf84p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1877,__func__));
}

void call_f362(void)
{
  f362(0x1.e000b12026c1cp+4, -4576235592882585200, 0x1.559f168090cc4p+5, "hj", -0x1.3dcf91312d63p+3, -0x1.cd2613ff77a6p+3, "p", 0x1.f743ad07eab84p+4, -7435255772518939288, 0x1.2fc2468817c5p+1, 7976546144779592719);
}

void call_f363(void)
{
  f363(-8663473761702795351, 8498306888377686161, 737003175200675000, -21848868, -0x1.24d2769ab4b6dp+5, "", 22466210159888190, -620719562, -0x1.04cac1a01c298p+3, "r", -2615567019503550213, "j", -0x1.464e591e96a4p+0);
}

void call_f364(void)
{
  int r = f364(-0x1.33c812f7bd597p+4, 7059211044464324586, 1033331163, -6931573106523872878, 0x1.241d7b78755dp+3, -5236841679094552310, "u", 4196838064703872957, 2012052911, "");
  ((r == 100560592) ? (void)0 : failure("r == 100560592","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1893,__func__));
}

void call_f365(void)
{
  unsigned char r = f365("g", 0x1.78e9568f36af8p+3, 0x1.baaae777f6bbp+4, 0x1.5dfd25d7cd04ep+5, -0x1.e5c05ecd9f646p+4, 32185187, -9161435729913337620, -0x1.fa7dd2b5556ffp+4, 7063664142852668450, -895519100, "a", 580018140019724310, -1166944723524206980, 4616959893582439494, "", 9154944956101257854, 0x1.d4113e1e531bp+4, -5890645907586717083, -0x1.4e86bb188d818p+2, -0x1.a93e81e7148fap+4);
  ((r == 115) ? (void)0 : failure("r == 115","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1899,__func__));
}

void call_f366(void)
{
  unsigned char r = f366("", -3492633014075569093, "g", -0x1.54b3d3ae5ad13p+5, -0x1.e0a7b8ddd882p+0, -1554918273, 1845038999, 9029433016740392999, 6734700838120378808, 6688915047703768885, -9120864394201672087, 1624890013460032996, -1215832813);
  ((r == 224) ? (void)0 : failure("r == 224","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1905,__func__));
}

void call_f367(void)
{
  f367(0x1.ccb46da6f8f7p+4, -4843063910624717224, "g", 0x1.9ea1714fb0028p+3, 5962134697647837027, 2093027558, 0x1.4f6e0016200fep+5, 0x1.412c96ec3cc86p+5, 0x1.c044749e28738p+4, 1464030997663272324, 6498515806313722936);
}

void call_f368(void)
{
  short r = f368(-0x1.1dcb4e73a84a2p+5, 0x1.68e359bf4460cp+3, -0x1.7d75f0f6022f7p+4, 1832068716, 1414333806, 0x1.19dcab16d6f4p-1, -801280794, "n", -2658729342230005676, -0x1.89eec189b0cf8p+2, 0x1.6704af021bc98p+4);
  ((r == 3044) ? (void)0 : failure("r == 3044","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1916,__func__));
}

void call_f369(void)
{
  short r = f369();
  ((r == -22553) ? (void)0 : failure("r == -22553","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1922,__func__));
}

void call_f370(void)
{
  unsigned char r = f370(-944362741595812964, 0x1.afaee537e964p+3, 1574143057351108963, 3335050325075631784, "", 0x1.db58e6364cd8p+1, "", 0x1.3e6cc8f773022p+5, 5216998835748368271, "jl", 0x1.6136009ec01bp+3);
  ((r == 140) ? (void)0 : failure("r == 140","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1928,__func__));
}

void call_f371(void)
{
  int r = f371(1944304611, 0x1.069397ebf91bp+2, 0x1.46d546618c87p+2, 2033299863, "g");
  ((r == -317740801) ? (void)0 : failure("r == -317740801","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1934,__func__));
}

void call_f372(void)
{
  f372(0x1.5d822d4298128p+4, "dr", -0x1.5f86b8d464d36p+4, -0x1.450333b1f16fbp+4, 0x1.3924c11c86a92p+5, -0x1.25f957d6c5c46p+4, -1336269231, 0x1.276b294e1af3p+5, -0x1.efbaa283ec428p+2, 0x1.8933edc72242p+5, -0x1.9b73a55818405p+4);
}

void call_f373(void)
{
  float r = f373(-1010136654, "i", 9107488858019508811, 0x1.4a7b9d9fc1bbep+5, "m", -1506362094, 0x1.3e41bd9d267a2p+5, -0x1.ac53a9c931ap-3, -241548268, "t", -323556221, -689174823, -6066767570770547574, 0x1.55d6d09dfd5c8p+5, -1278130497, 8512486047544567155, -5937815654893097537, -0x1.3b365d394f227p+5);
  ((r == 0x1.7c2dacp+5F) ? (void)0 : failure("r == 0x1.7c2dacp+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1945,__func__));
}

void call_f374(void)
{
  int r = f374(-0x1.5e1b1a6e93d63p+4, -3949805547158131547, -0x1.918fdd689ed3ep+4, "w", "ti", 0x1.03a5f78827d4p+3, -1176590888, "qk", -789737033, -0x1.784cbb0c079ccp+5, 2617571236008726468, 3094772161977548988);
  ((r == -82559121) ? (void)0 : failure("r == -82559121","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1951,__func__));
}

void call_f375(void)
{
  f375(0x1.45c4b4e2eb09p+5, 0x1.8256ad2cebe5p+2, 0x1.6ba69349679e4p+4, "g", "", -1022199127, 0x1.6a24571126d4cp+5, -1010640638552937041, 1464883694, -0x1.dcddd634a914p+2, -0x1.55804bae1ac68p+2, 1847171628, 6361247729289883731, -1671848029991763941, 1125257737926285353, -1725304373);
}

void call_f376(void)
{
  unsigned short r = f376("c", 0x1.6b10e3c297328p+4, -0x1.24d11ce7d70d4p+4, "im", -2981137155106111235, -8010121281505465952);
  ((r == 18559) ? (void)0 : failure("r == 18559","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1962,__func__));
}

void call_f377(void)
{
  f377(-704442052, "z", 8731365765365840067, 1964565802, "", "", 478365264, -610676158, "bw", 0x1.f092e1d278318p+4, 0x1.836fe3d995228p+2, 992675679, -0x1.e17d62f9ac23ap+4);
}

void call_f378(void)
{
  f378(116623881, "u", -187353554, 7073899786640683007);
}

void call_f379(void)
{
  float r = f379(1921517955, "", -0x1.58c75f93a817cp+5, -939711679, "w", "", -0x1.745cae7e4a505p+5, 259085891, 0x1.3b4b5727bc8b4p+4, 328785319, -3821877283951913704, -0x1.8ca90bbe9576p+5, "kz");
  ((r == -0x1.7e1ae8p+5F) ? (void)0 : failure("r == -0x1.7e1ae8p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1978,__func__));
}

void call_f380(void)
{
  f380(-0x1.1c4b4817f05ap+4, 3036427163715274546, -1002588527, 1809537267049705509, 446998178, 1552500687, 4282222278791749913, 6746221720864541908, "r", -891888198);
}

void call_f381(void)
{
  unsigned char r = f381("", 1602489521, "ir", "a", -1217748184, 0x1.3c933abfb6998p+5, "", -1338976697, -743013630108157970, -332924421, -1923670909, 2006366440, 1787610733, -894355467, -174619683, -3882802053915483094, -633828158, 8945034274489066713, "x", 0x1.acedd28940b7p+3, "");
  ((r == 127) ? (void)0 : failure("r == 127","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1989,__func__));
}

void call_f382(void)
{
  char * r = f382(-2848537325273698262, "", 0x1.b76c0fdf48f3p+4);
  ((strcmp(r, "vl") == 0) ? (void)0 : failure("strcmp(r, \"vl\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",1995,__func__));
}

void call_f383(void)
{
  f383("vf", -88950668625353680, "", 0x1.3a2ab5f8ea5e8p+4, -0x1.0bebd302951b2p+5, "f", 0x1.07843cc2095fp+2, "tf", "c", "m", -0x1.23b885dd3d6d3p+5, "lk");
}

void call_f384(void)
{
  signed char r = f384(1134629599, -1446161495, -0x1.85964eaa80d14p+5, "qv", -0x1.26a4bcc9272ccp+5);
  ((r == 116) ? (void)0 : failure("r == 116","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2006,__func__));
}

void call_f385(void)
{
  int r = f385(-820310325, -576007657, -0x1.e911c6faff0b5p+4, "s", -929406143, 1234641885, -858284875, -1743297679, -154973873, 0x1.88d4bd7088a36p+5, 0x1.9027bded7b22p+1, -8848833330105723885, "");
  ((r == 255611144) ? (void)0 : failure("r == 255611144","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2012,__func__));
}

void call_f386(void)
{
  f386(268739485640921195, 1815164000, 0x1.570689284b054p+5, 1723009720, -295376919, 0x1.2700c94d996ecp+5, -0x1.3510739ae3fbcp+5);
}

void call_f387(void)
{
  f387(-1147446936, "b", 190865201, -8008939739774508569, -6692154369532895499);
}

void call_f388(void)
{
  f388(-3404794411596171317, 5277431011697174596, -0x1.91f4574c2a5ep+2, 504924269, 0x1.32b4db30d8b08p+4, -0x1.8b479a5d9a18p+4);
}

void call_f389(void)
{
  f389("rw", -0x1.12f050ba093f9p+5, "zo", -1700333435, "bv", 695789473, 799984527, -1221411307, "d", -0x1.ee09a3b2f6a33p+4);
}

void call_f390(void)
{
  f390(0x1.76002d4cdb08ap+5, -0x1.caaea76497e7p+3, -12893873, -1710630261071329401, 0x1.22ff073b96f8p+5, "w", 0x1.885cc18daf514p+3, 3347234072170776746, 0x1.96538d83fb358p+2, 7818653364717693676, "un", -0x1.5a37159b98746p+5);
}

void call_f391(void)
{
  f391(-6688772897249871268, "", -0x1.00f38da422a1ap+4, -1657564931, -0x1.f714deccda294p+3, -2044490375, 2794558176664611757, "b", "s", 4714658141453493963, -8352307048362164498, "i", -8315637634303422099, -0x1.7868d2643e162p+5);
}

void call_f392(void)
{
  float r = f392(0x1.c92a826d4b49p+4);
  ((r == -0x1.7841fap+5F) ? (void)0 : failure("r == -0x1.7841fap+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2048,__func__));
}

void call_f393(void)
{
  f393("", -0x1.46fd01e2f3064p+3, -0x1.72d04854d7244p+3, 0x1.cccee482b4a94p+4, 240331771, -0x1.ef145afe73b18p+4, -0x1.6c87d1485c9ap+0, 0x1.fcc30078e7da4p+4);
}

void call_f394(void)
{
  int r = f394("v", "k", -3245300792685634058, -0x1.81d3a745f0e67p+5, "ab", -2625964743875037455, "ac", -0x1.70ca33972b08bp+4, 922433656);
  ((r == -1554834830) ? (void)0 : failure("r == -1554834830","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2059,__func__));
}

void call_f395(void)
{
  long long r = f395("ms", "dy", 1765079969, "ga", -5578757459018333728, 6594643821592793736, "", 6646112187922931332);
  ((r == -8537975113634276278) ? (void)0 : failure("r == -8537975113634276278","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2065,__func__));
}

void call_f396(void)
{
  signed char r = f396(286985400, -7311387266251951454, 1914336000, 0x1.034943a756258p+2);
  ((r == 27) ? (void)0 : failure("r == 27","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2071,__func__));
}

void call_f397(void)
{
  int r = f397(3728894804269904562, 0x1.017eb292f2c2ep+5, 5172531724684815032, -5886119806245789581, -3975978435453692483, -1171951691120871960, 9101510710040093231, 4360226038102736322, "aw", -0x1.080307fa1a09dp+5, -0x1.977d47fd6ee6p+1, -7012070, "", -4670222011351350073);
  ((r == 1766675382) ? (void)0 : failure("r == 1766675382","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2077,__func__));
}

void call_f398(void)
{
  f398(-0x1.1a895ccc520b6p+4, 1940735987, "", "", 7822038628949301765, -2024322641, -0x1.1bf681fa9c002p+5, 1137144881);
}

void call_f399(void)
{
  unsigned char r = f399(0x1.7590c183db204p+4, "h", -8673330767513305233, 1828710623, 0x1.f90b50c8c5f88p+4, "sx", -1920137004, -0x1.446860591c3fp+1, -599413244, 1192910252, -5786314609602176423, -1934655404110490421, 247864091886248731, 0x1.108564b6bdb62p+5, 301701767, -2040193165, -6556225824940071541);
  ((r == 247) ? (void)0 : failure("r == 247","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2088,__func__));
}

void call_f400(void)
{
  f400(-312296630, 2125117404, -536831817437974351, 0x1.53817047007bap+5);
}

void call_f401(void)
{
  unsigned char r = f401();
  ((r == 28) ? (void)0 : failure("r == 28","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2099,__func__));
}

void call_f402(void)
{
  unsigned char r = f402(-1117448805, 1397070986, -7881822047712719609, "", 0x1.473ced07cbbbep+5, -4206278730199123265, "", -4700396064497104481, -6723967974166959776, "oo", "e", 0x1.2457347360624p+4, -6363051988768385215, -0x1.58c562652e5c8p+2);
  ((r == 192) ? (void)0 : failure("r == 192","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2105,__func__));
}

void call_f403(void)
{
  f403(-0x1.53fb08c59ab15p+5, -2142606025796945929, 8893401622320059937, -0x1.1900f67ffe2d4p+3, 0x1.80c614fabfa78p+3, -0x1.c908594ab61d8p+4, -0x1.c0e01fa3127d8p+3, 0x1.cada46285cb9p+2);
}

void call_f404(void)
{
  f404(5869225607872425770, -0x1.aad511454a7bep+4, 0x1.12165bb138aep+4, 0x1.3a7eaadcbbfcp+5, 3191783427267381895, -0x1.1dc3c004464ccp+5, 340338545, "", 0x1.63fc41b194fa6p+5, -0x1.2b1dcb363dcep+5, -1338691100);
}

void call_f405(void)
{
  f405(1491784699, 9117494913531589820, 276042693, 0x1.6d8a1336f9b5p+4, 5947540972798742221, 623533150851825794, "jk", -0x1.4ca6adab44d8cp+3, 1263831186, -0x1.5e0333d37054ap+4, -0x1.8cfacca02f034p+4, -6508964952510159333, -3797653321694789116, "", 4436872473581005130, 0x1.181c4cabeaf78p+4, 7823553664752172982, -5287472623467951187);
}

void call_f406(void)
{
  f406();
}

void call_f407(void)
{
  signed char r = f407(-0x1.7beffc281bda2p+4, 0x1.4a86cd7a80974p+4, -1050976790, 0x1.87592ce069cdcp+4, 0x1.965e78fa2d13p+4, -3209851180859385995, 0x1.8e882f04f4b42p+5);
  ((r == 73) ? (void)0 : failure("r == 73","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2131,__func__));
}

void call_f408(void)
{
  f408(-1462205848, "z", "xq", -285031047, -862543176140105523, 1010995369, 7880397847096153357, 1900393088, -680536412, 0x1.34121efe8db34p+4, "k", "", -7164459273887415629, "wq", 892046416);
}

void call_f409(void)
{
  unsigned char r = f409(-6481384395978021705, 0x1.7837276eaff5cp+5, -0x1.4f9408cff7d18p+5, 0x1.8a61f54a31928p+5, -9039691872851130658, -329207642, 0x1.9f01a84eb4834p+4);
  ((r == 74) ? (void)0 : failure("r == 74","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2142,__func__));
}

void call_f410(void)
{
  f410(0x1.6e29f9928165p+5, 0x1.2a1da5aaba408p+5, "m", -0x1.328bd15ff797fp+4, "", 0x1.049283cc5e136p+5, "yu", -0x1.39f1a0e47b392p+5, 0x1.9d9dce52daf14p+4, "", 494372736, 7012440593895020133);
}

void call_f411(void)
{
  f411(0x1.88c734fcaec74p+4, -1844154054, -0x1.2cf792f0071f9p+5, "qm", 0x1.6250ce3d31d88p+2, -0x1.00be46df71496p+5, -0x1.648f69ee5f55ep+4, 0x1.4d5e1454ed63p+2, "", 0x1.eda3f9335ac6p+3, "t", 0x1.241e47ae8baa8p+4, -1133840968);
}

void call_f412(void)
{
  short r = f412(126582700, 1809045953, "kn", "v", "x", -7924397406285458602, -0x1.084fc53502fb8p+5, 6357472930508636675);
  ((r == -25392) ? (void)0 : failure("r == -25392","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2158,__func__));
}

void call_f413(void)
{
  f413("m", 7209940972449357255, 0x1.a7d92eddebc54p+3, 1427234931, "pn");
}

void call_f414(void)
{
  long long r = f414(3332021323172770669, -7835749584134344428, "xe", -1211535218, "ya", "", "pq", 1910130244, -0x1.2c0590cbf1325p+5, "", -0x1.7754e5fe19b86p+5);
  ((r == -4096837288720221779) ? (void)0 : failure("r == -4096837288720221779","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2169,__func__));
}

void call_f415(void)
{
  f415(1044169548, 1762126574, 0x1.74ffe0790426p+0, -0x1.e65610af59cp-5, 0x1.89e9f4826ffdp+4, -1478996642247107876, 0x1.522a780ea6f0ap+5, 0x1.2ca37660b2e1p+4, -2237227555588447244, -1051521141164062127, 2185968291040805907, 1678890927, "", "k", -623823850, 4238149781591558334, 328470252, "");
}

void call_f416(void)
{
  long long r = f416();
  ((r == -8338444318046532472) ? (void)0 : failure("r == -8338444318046532472","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2180,__func__));
}

void call_f417(void)
{
  char * r = f417(0x1.b392b2e3d36b4p+3, 0x1.4c0ad94aee564p+5, "yi", -0x1.8f7b1c55694a4p+4, 0x1.23baf6be5a0b4p+5, -0x1.d8541e09304ep+3, "xh", 0x1.7053c35ebe028p+5, 0x1.5467dd07beb2ep+5, 4296321206485065795, "", 0x1.1ec3716ac8f34p+4, 0x1.e0192f550485p+4, 8610008847562450312);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2186,__func__));
}

void call_f418(void)
{
  unsigned char r = f418(0x1.a386eb81db9e8p+4, -0x1.02e3459498b4ap+5, 829775566, -0x1.27d6216f63851p+5, 0x1.899d23f17c51cp+4, -0x1.f846c40faaecp+0, 2669409591860942334, 0x1.d2d96957c177p+3);
  ((r == 206) ? (void)0 : failure("r == 206","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2192,__func__));
}

void call_f419(void)
{
  unsigned char r = f419(0x1.5916aa530733p+1, -0x1.897f8b05f299ep+5, 1567111581, -0x1.78f107ad1bb7ep+5, 193306957, 4362841012538455904, 3750740465433711348, "mp", -0x1.6c2e9042bfe7p+4, "", -0x1.a3703af7894bcp+3, 932369841);
  ((r == 133) ? (void)0 : failure("r == 133","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2198,__func__));
}

void call_f420(void)
{
  unsigned short r = f420(-2543424678288622194, -1888416697, "y", "t", 0x1.d7d11033d116p+2, 0x1.8eb93857ca3p+0, "d", -0x1.49dd43a32418ep+5);
  ((r == 54283) ? (void)0 : failure("r == 54283","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2204,__func__));
}

void call_f421(void)
{
  f421(0x1.5eaf8e2d43002p+5);
}

void call_f422(void)
{
  short r = f422(-4659502981922870288, 7203236368455605103, 4131768964428189029, 1295619543, -928518594439630155, -2026195856, -0x1.007ec5ecaac1ap+4, 0x1.564361a7314b6p+5, -1254631403, -7782709099316799147, -2241989375239868597);
  ((r == -8925) ? (void)0 : failure("r == -8925","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2215,__func__));
}

void call_f423(void)
{
  f423(-6032275333697373315, -0x1.820b50a1afda9p+5, -1910946212, -1121011567992070858, -8231506343554514326, -0x1.3a24518bc0fa5p+5, 0x1.f7bca3711aa04p+4, -0x1.eb04991ba4084p+3, "", -5592393229809429378, -7584110784821390930, -242019977, 4621862673231321039, 6812384790969327026, 0x1.ed9a7dc002c04p+4);
}

void call_f424(void)
{
  int r = f424(223935773, "", 0x1.c8efc9e42819p+1, "", 0x1.8e4bdcf0df0a6p+5);
  ((r == -935224610) ? (void)0 : failure("r == -935224610","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2226,__func__));
}

void call_f425(void)
{
  unsigned short r = f425(-358889847, -0x1.8631351a052b5p+5, "z", 0x1.14c0fe6655b28p+5, -0x1.c6a0f233a32c4p+3, -0x1.203fb63dfe3fep+5, -0x1.c5a844c83f37p+2, -244306599, 147994962);
  ((r == 14834) ? (void)0 : failure("r == 14834","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2232,__func__));
}

void call_f426(void)
{
  unsigned short r = f426(1709297337, "e", 0x1.7187882fda44ap+5, 0x1.01c0ef332c6c4p+4);
  ((r == 29766) ? (void)0 : failure("r == 29766","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2238,__func__));
}

void call_f427(void)
{
  unsigned char r = f427(-0x1.58d8a5f03ed9dp+5, "b", 0x1.2e4d600375e22p+5, -1056763356, -0x1.22acf6264add4p+3, "r", 0x1.787ddd9652778p+3, 413153996, 1195360696, -0x1.8c16dec4a1818p+3, -7729372579897122667, 1078062019020227661, "q", 1997713726);
  ((r == 19) ? (void)0 : failure("r == 19","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2244,__func__));
}

void call_f428(void)
{
  f428(3723698571664203973, 0x1.88f49eac78876p+5, "", "jz", 0x1.d6dad90df14ep+1);
}

void call_f429(void)
{
  signed char r = f429(-7302998367745747016, 0x1.2429b02458a62p+5, -68546152, -461655491113207654, -490600668167066820, -0x1.ae8264a333f6cp+4);
  ((r == -13) ? (void)0 : failure("r == -13","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2255,__func__));
}

void call_f430(void)
{
  signed char r = f430("", 3431596498022145775, 885117644200106649, 0x1.112c10e56b2e8p+3, 0x1.2ef04835f27p+4, "e", -167487185, 294804365, 27931983, 0x1.352e03d960134p+5, 0x1.a2a96deec78dp+3, 0x1.968f31ca144b4p+4, "mn", 691798510, 0x1.04fe3fb33bd54p+4, 723956671, 0x1.66a3b3739738p-2, 0x1.9db39121fd438p+4, 0x1.84246e5cffddap+5, -1560802388);
  ((r == -74) ? (void)0 : failure("r == -74","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2261,__func__));
}

void call_f431(void)
{
  double r = f431(-1389139239892506449, 1807514746, 1777341255, 6873234772713951789, 0x1.c9eb6cabe1ep-4, 5936749792073005503, "", 1484048182, -5189260766996094280, -8447949907469236439);
  ((r == 0x1.452ef4ed66d9cp+4) ? (void)0 : failure("r == 0x1.452ef4ed66d9cp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2267,__func__));
}

void call_f432(void)
{
  f432(0x1.edb824fde7b9p+4);
}

void call_f433(void)
{
  float r = f433(-0x1.83535fbd33534p+3, 0x1.57bc4ea3f1374p+3, -8670558370469767670, "", 0x1.a5abd525e59d8p+3, -0x1.0490e851afc58p+5);
  ((r == -0x1.56f2bp+4F) ? (void)0 : failure("r == -0x1.56f2bp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2278,__func__));
}

void call_f434(void)
{
  f434("", 3597387870720388596, "", "", -9100642254613773564, "", -0x1.6b3ac0e9ad925p+4, -714025561, "", 6593047330670613933, 0x1.72f53ba241436p+5);
}

void call_f435(void)
{
  f435(1112340541809043337, -0x1.4b6b5abd153b2p+5, 3510909056831984727, -0x1.2a9a18907268ap+5, -0x1.b3a2aaf8223cep+4, 0x1.52addbffc324cp+4, 0x1.3b425fc26ea76p+5, "bk", -8525909450212887855, -42372531, -3931221075725135024, "w", -0x1.144b0c01cd9bbp+5, "", "", -645236408, "p", 331484373);
}

void call_f436(void)
{
  float r = f436(-1932883737, -1686372171, "gy", 0x1.469c6add28c3p+1, "u", -0x1.22c26bf8ba5c5p+4, 0x1.4a308a9ed41c8p+4, -0x1.3aa0607f44b24p+5, -8344328645602464328, "", 1084052184, 0x1.849c2727927cap+5, -2102459270, 6721858365440107547, -0x1.23d2943319b8p-1, "ct", "bm");
  ((r == 0x1.5f46fap+5F) ? (void)0 : failure("r == 0x1.5f46fap+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2294,__func__));
}

void call_f437(void)
{
  f437(-1578017286, -7936177746241009067, "g", -3265647520849273440, -0x1.7f61e2dd1229p+2, 0x1.232c8edd7b028p+4, "q", 0x1.bcddf96b16ccp+4);
}

void call_f438(void)
{
  int r = f438(-0x1.567b6059acd8p-1, 1836431751, "dt", "z", 0x1.a7b3771e79f88p+4);
  ((r == 1017531477) ? (void)0 : failure("r == 1017531477","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2305,__func__));
}

void call_f439(void)
{
  long long r = f439(2914749209243483988, "zw", 1512128390, 713876067, 229596889, 0x1.503a4746e60d8p+4, -0x1.1c22d7ddff639p+5, -0x1.8f498bf8a8fa5p+4, -825677613440443389, 0x1.13b0ee65dd7eap+5, -978667160, 747083862, 3146381270137346382, 1783876605, "gg", -1307441470, -0x1.0cd4dc0acf208p+5, -0x1.1a5fa5520141ap+4, -0x1.e39684c172dc5p+4);
  ((r == 1689161203693244332) ? (void)0 : failure("r == 1689161203693244332","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2311,__func__));
}

void call_f440(void)
{
  f440(1148521352, -8304254539502452849, "", -5020494555461985258, "", -1484388191958804826, -307738451, 5907278515224361855, "ng", -0x1.9644291fea9cp+1, -1244972682, "rd");
}

void call_f441(void)
{
  signed char r = f441(7825368572396376916, "", -6718535042655483889, -1110537140, "ci", -0x1.5df94b804b4f4p+5, 0x1.a9d4e2a3c607p+1, -1571514110, 6903578562116876435, 0x1.8e3472ee7ce2ep+5);
  ((r == 56) ? (void)0 : failure("r == 56","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2322,__func__));
}

void call_f442(void)
{
  int r = f442("ls", 0x1.1e56f9326dadcp+4, 347129725963138648, "ir", "", 0x1.53b03677fe674p+3, "au", "is", -175526916, -0x1.7c55fbb8c88e9p+5, 0x1.7219655dcb8c4p+5, 0x1.847568059a7ccp+4, "yy", 0x1.a767ec4949a44p+4, -0x1.280a4ff9a2002p+4, -8654925139574787767, 4943491571959771240);
  ((r == -1158379832) ? (void)0 : failure("r == -1158379832","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2328,__func__));
}

void call_f443(void)
{
  f443(-1925059265, 0x1.312296ef06cc8p+4, 85693242, 1688914688, -0x1.11d372bd2bf54p+4, 1293631854, -174156961, "dx", 0x1.e646d256d0014p+4, -0x1.3239cc7946542p+4, -1850156903, "u", 0x1.ec26cf64a5108p+4, -1420236500);
}

void call_f444(void)
{
  f444(0x1.953a0a8c06fb4p+4, 0x1.7fe4358181ecp+5, 0x1.8dd3e653b38aep+5, -1409450674);
}

void call_f445(void)
{
  f445(0x1.399309ad4f78cp+5, 1510156362, "j", "dq", "rs", -0x1.805fbbaf4864p+3, 846166782, -1618775866, 5309788833199994328, "c", -3998065641956683756);
}

void call_f446(void)
{
  long long r = f446(-3340077035928372098, 0x1.895d808b37176p+5, 0x1.86703f544a9dp+1, -0x1.5c42109b4031ep+4, -4788980648105821183, "", 0x1.8517e74fed384p+4, -1730445794, -0x1.891394e9ab5b5p+4, 5723049967409746506, 0x1.913f6816f8878p+4, "gk");
  ((r == -3943990466621953530) ? (void)0 : failure("r == -3943990466621953530","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2349,__func__));
}

void call_f447(void)
{
  unsigned short r = f447("", 754018202, -0x1.61d269f2a60f7p+5, "gb", -1557349605826096936, -0x1.8f069825bddap+0, "b", 908729257579937216, 2137595933, -3953019648424700906);
  ((r == 20544) ? (void)0 : failure("r == 20544","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2355,__func__));
}

void call_f448(void)
{
  f448(6531138720861228097, 1259483470, 0x1.0053e88800588p+4, 0x1.918803162afcp+2, -0x1.559a36acd70fdp+4, -0x1.a46024eede87dp+4, 0x1.a1bb5ed44f89cp+3, 885326688, 780966760, -822013912, "ud", 2517585105817420038, 639439147, 687509194, 564106330, -8329133427401313242, 541772266, "k", "", 5774002144040153665, -5416621571185012528, "dy");
}

void call_f449(void)
{
  char * r = f449(1977825708, -0x1.37608547a4e2ep+5, "o", -0x1.159e7324e09dep+5, 1925022791, 0x1.1955523f04fp+2, 8310344355305523420, "ot", 6069382889623661291, -7639394178144039046, "y");
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2366,__func__));
}

void call_f450(void)
{
  f450(2004920064, 1908866981740348154, "a", "xj", -0x1.67bd1ba598694p+5, "");
}

void call_f451(void)
{
  f451(0x1.8674cff527abp+3, -0x1.598153945c03ap+4, "n", -0x1.53c224959dba3p+5, 0x1.9f40a5a6b377cp+4, -0x1.bf7d48f516c5fp+4, "", -267722864, -8847227619112772465, 0x1.2bdace938562p+1);
}

void call_f452(void)
{
  f452(6786981795028323271, 0x1.25968b8b2596p+4, 1160723800, -2934037939437583584, 1899399846, 0x1.e27f9b9e9184p+1, "", 3155488523765662551, -969198, "ni", 1074637142, 1451331639, 0x1.ae226d9e8e07cp+4, 0x1.022047a2909a6p+5, 7431145146083460897, -1616131068, "k");
}

void call_f453(void)
{
  f453(-0x1.2b07123f898e2p+5, "", "");
}

void call_f454(void)
{
  double r = f454(-0x1.000188bd4f2ap+5, 2827476977970540292, 0x1.5e18a0dcc67fp+5, "f", 3475265456363539506, 1834756799, "q", -0x1.ca643daeb3bcp+0, -2221146778954367206, "mt", -0x1.521bdb0e07bc2p+5, "");
  ((r == -0x1.139c47086856ep+5) ? (void)0 : failure("r == -0x1.139c47086856ep+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2392,__func__));
}

void call_f455(void)
{
  f455("nf", -990091541, "y", 0x1.4a190b1016aap+1, -0x1.c5fb16bbabf42p+4, "", "u", -0x1.ce659e1190eb2p+4, "ex", -0x1.c5f620cbb193p+2, -0x1.b18044b013ae8p+2);
}

void call_f456(void)
{
  f456();
}

void call_f457(void)
{
  f457(-4183088704107341406, -293631940, 1951433067793795806, 0x1.6f0be93ca4e82p+5, 0x1.75afa14a0c2dap+5, -1682790137, -2810625771442701827, "gg", "yq", -1697818224171832666, 1197597137, 961174163);
}

void call_f458(void)
{
  short r = f458(0x1.8aa38954a0f62p+5, 1755929040, "y", -852349325747961357, -528986701, "ro");
  ((r == -21159) ? (void)0 : failure("r == -21159","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2413,__func__));
}

void call_f459(void)
{
  unsigned short r = f459("ja", -8580452957776928631, 7551253078661079189, -3096887836211969871, -866300376, -0x1.8ffc20cca6f0dp+5);
  ((r == 58152) ? (void)0 : failure("r == 58152","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2419,__func__));
}

void call_f460(void)
{
  int r = f460(0x1.ccb183052b1bp+4, 371145016760780922, -7651408772339500446, -8397725739502352725, -0x1.2fa4f19cf4ca8p+5, 97631758895810288, -7802928474814678546, "", "lq", -0x1.d1afde5c6295p+1, 1357591004, -284909661, -142641072, -1640662685, "g", -8208205157200549136, 0x1.8d6c09857634p+2, 8567442892322636103, 1876327329938168813, 6621558789175268637, -0x1.19aa0b682e47cp+5, "np", -654603124);
  ((r == 657428119) ? (void)0 : failure("r == 657428119","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2425,__func__));
}

void call_f461(void)
{
  f461(0x1.04fa1551accecp+4, "xv", "", 4521021799245562075, 442676745, "", "", -1015977850, -152309192, -59469468, -0x1.4ed72c7ea87b3p+4);
}

void call_f462(void)
{
  f462("f", -0x1.cb69e434998f8p+3, -0x1.7c5ba71c60639p+5, "zj", -0x1.cf1f1ea3e3c2p+4, -0x1.deba7be93abdbp+4, -5383175227743470451, 2189022040572435127, 7738184846733503198, "", -0x1.35475971c891p+4, -724439081858302702);
}

void call_f463(void)
{
  f463(-1613431125, -2279226944540707646, -1553652926, "", -564138388, "i", 0x1.210fddf89541p+4, 909225134, -0x1.583cf6c23379p+2, -0x1.01d692c32e3eep+4, "un", -5072118962435481767, -1568677558664840053, "u", -210371824, -0x1.50d914c03338p+3);
}

void call_f464(void)
{
  short r = f464(3441675435695409651, "", 0x1.3211867b814ep+5, 0x1.165dd5224ce38p+3, -1453875715, -1436156682, -0x1.a8713419fe854p+3, 1091351706);
  ((r == 14198) ? (void)0 : failure("r == 14198","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2446,__func__));
}

void call_f465(void)
{
  short r = f465(-0x1.3b10916fcef18p+4, -0x1.79ffa05c9f5afp+5, 984534765420987531, 0x1.4909446f529c4p+5);
  ((r == -23590) ? (void)0 : failure("r == -23590","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2452,__func__));
}

void call_f466(void)
{
  signed char r = f466(-454837357, "", 111240261, -7739071356052650126, 7951045253483613970);
  ((r == 98) ? (void)0 : failure("r == 98","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2458,__func__));
}

void call_f467(void)
{
  f467(3092945891219883833, -0x1.1e2ec1bb46ae2p+5, 3275105333968491987);
}

void call_f468(void)
{
  f468(423684324, 0x1.21a1ecc22cdc8p+3, -1963862824, 4856666994394623229, "");
}

void call_f469(void)
{
  unsigned short r = f469("h", -1859745287902798633, -0x1.2c4fb5d2184p-3, 8817381647518280879, -0x1.5dd72e3ae9dfbp+5, 0x1.23810b6153128p+5, -729237242, 0x1.f1abfbe37aa24p+4, -457649514637023615, 0x1.0d6da7ac8c0d8p+3, -1309169112, -3827666976791921074, 680075702, 6210357095358154935, -101554523, "jo", "jm", 1864769428870608778, -5097624462335850760, "d", -2224454466772420642, 1331964661);
  ((r == 7431) ? (void)0 : failure("r == 7431","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2474,__func__));
}

void call_f470(void)
{
  f470(0x1.7701ab469864p+5, 0x1.0a8618a706e44p+3, 510492394365680779, -1091738348, 0x1.3efb605f5e434p+5, 1290119251, 805973639, 66888567, "");
}

void call_f471(void)
{
  unsigned short r = f471(-0x1.20a086d30a698p+5, 22739900, 0x1.04f23f61dc0ap+4, 0x1.7ddbe5491d118p+4, "d", 1399999975557627438, -979071720729495506, 6210329465289788228, -845261329455869777, "b", 0x1.da79bc84b6788p+4, 1143615238, 9205245695571776255, -1059702907, 6026857156842592738, "gs", -0x1.2080bc6d1cf4dp+5, -0x1.1f8b260b1acp+2);
  ((r == 27816) ? (void)0 : failure("r == 27816","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2485,__func__));
}

void call_f472(void)
{
  int r = f472(-0x1.127f20a36bfdap+5, 8361563117239913931, -708981828, -682177507, "j", "a", -1035562504, 0x1.ca141077f4cc8p+3, -8110757907165980708, 2091592325379509654);
  ((r == 209900256) ? (void)0 : failure("r == 209900256","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2491,__func__));
}

void call_f473(void)
{
  f473("", "", -6596332103010422241, 0x1.6f730ac47d0eep+5, 0x1.f3e3c35e7e5c8p+4);
}

void call_f474(void)
{
  f474();
}

void call_f475(void)
{
  f475(-1789861995, 65794141, -8678248775806784123, 727935938741720899, "no", -1209516127, 0x1.8be52b724befap+5);
}

void call_f476(void)
{
  f476("py", -0x1.9f0c3cb45b717p+4, 7044885812300100702, 0x1.a087b7c64aa38p+4, "f", 0x1.ee4a7e88a741p+4, -0x1.401b303bcc896p+5, -1643400595, -6055613274544340933, "b", 1703751279, -0x1.2c8d049b17a6dp+5, 1036938235);
}

void call_f477(void)
{
  signed char r = f477(-4981457954179849412, 0x1.19726f9d4b584p+4, "ur", -0x1.fc7bbecfc7e67p+4, -1858670971, -0x1.d5e3b1d63e39p+4, -0x1.aaee7d373861p+3, 0x1.9ae66928955bp+1, -0x1.50d0dacead73fp+4, -6792125561638610440, 0x1.30a330bddbc3p+4, -1254707167331127018, -1557716816123251151);
  ((r == -25) ? (void)0 : failure("r == -25","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2517,__func__));
}

void call_f478(void)
{
  unsigned char r = f478(-1738626056, -0x1.2de4d1a73c3f6p+5, 3149483165371455966, -0x1.e5e0ab7f6dfbap+4, -741220564, -336958194, -0x1.c3eec33b637f9p+4, -0x1.2c29e1facbb78p+5, 0x1.934faa893ce4p+4);
  ((r == 15) ? (void)0 : failure("r == 15","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2523,__func__));
}

void call_f479(void)
{
  f479(1124630208, 1092809248, 2071298591, "ai", 1536243244, -0x1.89caa13580cf2p+5, 1988835336, 1778442459, "", -0x1.c8a257562179p+2, 1503486678, -0x1.2dd3d4dcbbcdfp+5, -1793535980, -5001379318247038898, 6770056227770594402, -1758958832915014383, 0x1.5fb1bf73e2066p+5, "h", -8046525426970221834);
}

void call_f480(void)
{
  int r = f480(-264806641, 368629457, 6073383306546713128, "xb", 0x1.cc02ef1729efp+1, 1629606706);
  ((r == 1017239924) ? (void)0 : failure("r == 1017239924","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2534,__func__));
}

void call_f481(void)
{
  int r = f481(-0x1.82fcdaaef90fbp+5, "av", 2112946337, "fo", -0x1.8c6ffa3db93a8p+3, -1411196581, "m", 1183197745, "zy");
  ((r == 305707200) ? (void)0 : failure("r == 305707200","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2540,__func__));
}

void call_f482(void)
{
  unsigned short r = f482(0x1.47dc78359c7fp+4, 0x1.fd8cb94d10eap+3, "mu", 0x1.3520fbe826f1p+4, 0x1.7d813256fd3ep+4, 8161909211195693285, 0x1.dc52ea5737428p+3, 0x1.78bf86ca8152p+0, -5238119274067864212, 1371665610, -1183020625, -1944016242, 5127346095352164750, 0x1.eb3c45ed7c108p+2, 0x1.d3382128b1cp+0);
  ((r == 22872) ? (void)0 : failure("r == 22872","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2546,__func__));
}

void call_f483(void)
{
  f483(1990308632, "", -8208414291246551077, -0x1.72894accb8437p+5);
}

void call_f484(void)
{
  f484(-2837839556032175157, 0x1.6245aad9bffdp+5, "k", "uc", 7745849908150609330, 2156536073251677927);
}

void call_f485(void)
{
  long long r = f485(1649678245, -0x1.cf8ca38733p-5, -0x1.28bf4b25638f1p+5, "bx", "v");
  ((r == -7593823269043106072) ? (void)0 : failure("r == -7593823269043106072","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2562,__func__));
}

void call_f486(void)
{
  f486(0x1.6b04696e1881cp+4, 1946252880016561096, 225316091108943196, 1900889988, 0x1.d503f33cf5ep-3, 3391719220547287569, 0x1.11e7e5339ac92p+5, -6761704709855275128, 695788152, 2717630359834829336, 1521664899, "gn", -1482873030786247727, 6128064440941605652, 1926528990, -0x1.06089d974a9p+1, "fp", 1108125219);
}

void call_f487(void)
{
  int r = f487(2076937530, 4496011919892396696, -0x1.935c880596bc6p+4, 2368047998335318973, -733820000, 5367072593640329219, "", "jx", -0x1.095abbc1c826p+2, -8102496600985539800, 698879239, -0x1.7b519f63e3949p+4, 0x1.11f91077b8f84p+4, -1103863388969090019, "pk");
  ((r == 724735184) ? (void)0 : failure("r == 724735184","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2573,__func__));
}

void call_f488(void)
{
  f488(0x1.9fd483d4d59a8p+4, "o", -1505681063745686924, "", "go", -0x1.102a7df0ce6b6p+5, -0x1.4c44551302487p+5, -719239906, 0x1.aa25df777d93p+1, -0x1.880565ee32552p+5, 6536561442510662059);
}

void call_f489(void)
{
  f489(556137699, -8506443797512955591, "d", -3870457569821168887, 4273485909301346191, -742077583, 1512685080, 5801394799897302686, 0x1.7e3c1ca2f585ep+5, "", 1974404511, 0x1.1a4b5762c3d88p+4);
}

void call_f490(void)
{
  f490(-0x1.06debece9f29p+3, 7395079662439375560, "", -1195092298507015320, -0x1.82c477dd97851p+5, 3399467016899805619);
}

void call_f491(void)
{
  float r = f491(-625320957, -1525701813325274915, -2423513978029863395, 0x1.c2d6cca0cde3p+2, "", -245139832763243504, -0x1.1b78ab179b4bp+5, 1151193352, "kb", 0x1.f57f2eefe288p+1, -0x1.5bf4d874b3985p+4, "", 0x1.442d61bcab214p+5);
  ((r == 0x1.3fa7fap+2F) ? (void)0 : failure("r == 0x1.3fa7fap+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2594,__func__));
}

void call_f492(void)
{
  f492(2499137313056970316, 0x1.81f9423752d6cp+4, "", -0x1.5702e13467138p+3, -0x1.7e1338b9b9f6dp+5, -0x1.2b217d0da4a18p+2, 3409169819483140607, 1941106801, -850841273, 1521652897, "ik", -4248151032378236044, -299454802, "yl", 1737133976, -0x1.4581fdf8ed814p+4, 881421933);
}

void call_f493(void)
{
  signed char r = f493(-0x1.b3e7f73929a8p+0, "", -0x1.e1fd6f3fa215p+1, "", 643099168, "k", "qv", 1060013639, -5649686171471899207, 322030614, "", 0x1.173d10ed86c1cp+4, 1255040962);
  ((r == 89) ? (void)0 : failure("r == 89","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2605,__func__));
}

void call_f494(void)
{
  short r = f494(0x1.27f21c01160f8p+3, "nq", 0x1.ce9275e14c0cp+3, -0x1.41ee620acd564p+5, 354381792, -0x1.1e47bb31bd9f4p+5, 1316630861071370470, 6316264718836293419, 0x1.09191db9e3p+5, 437596463, -0x1.0b4a4141c3a57p+5, -0x1.47f0aaed59b57p+5, 31328260, 1229202954074516754, 6409107729878666053, "", -0x1.df5a8fecc5636p+4, 1870791342, -0x1.06ee5c7d9d7fap+5, "z");
  ((r == 29570) ? (void)0 : failure("r == 29570","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2611,__func__));
}

void call_f495(void)
{
  long long r = f495(0x1.2f240463c4978p+4, 0x1.d16e5507a540cp+4, 0x1.77ea6b74b717p+4, -0x1.1cbe25546f428p+3, "", -537405277, 775164369, -5797071416553158081, "sm", "", 1651144867, 0x1.795923ecad484p+4);
  ((r == -7953726854742778049) ? (void)0 : failure("r == -7953726854742778049","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2617,__func__));
}

void call_f496(void)
{
  f496(-0x1.0d7e05d60b6ep+4, 924974350230110704, -1105436760, -0x1.fef6bedb7b6dp+3, -474052090, "h", 0x1.8bfc096d682f6p+5, -0x1.6ac3605fe49e4p+3, "x", 299869371, 0x1.2a9dc336cc4ep+1, 0x1.8645a5f37ec36p+5, 0x1.d9fa185b0678p-2, -107454757750749833, -0x1.9304b39574a2cp+3, 8991864676009315385, -0x1.3ee9ad754bce1p+4);
}

void call_f497(void)
{
  int r = f497(9067052149775252579, "am", -0x1.3f7ad5077fe37p+5, -1531602223, "oj", -0x1.714fde4b45fa8p+4, -0x1.49bdbdcfb143p+3, "", -1860971214, -3351872412661437216, -1423444904, 6536640503442391623, 0x1.73a1a83789456p+5, -0x1.10dc5aebcfff2p+4, 0x1.52d530fbd82c8p+2, -0x1.bfd265ad4ef8dp+4, -0x1.2088592523f88p+5, "mj", "", -0x1.fc610f5bd49cep+4);
  ((r == 189252878) ? (void)0 : failure("r == 189252878","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2628,__func__));
}

void call_f498(void)
{
  char * r = f498(0x1.78e74e7b4e7bp+5, 0x1.1d192d6665684p+5, 609386512, 515880579105358902, 7803400743594830996, -0x1.c0d8fc93947acp+3);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2634,__func__));
}

void call_f499(void)
{
  f499();
}

void call_f500(void)
{
  unsigned char r = f500(-0x1.7137bbd1f4ae5p+5, 0x1.083b8670578e8p+4, 0x1.341f3b9c9808p+1, 82124363, 4273729732326104388, 616046139);
  ((r == 165) ? (void)0 : failure("r == 165","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2645,__func__));
}

void call_f501(void)
{
  f501();
}

void call_f502(void)
{
  f502("nw", "ng", -0x1.b703520af0abp+2, -0x1.ccceafe3e0eccp+4, 0x1.30526ee7f0dcep+5, "ph", 0x1.49f3863ada868p+5, 0x1.e7efb10195274p+4, "qt", "", -0x1.d63bf428445ep+4);
}

void call_f503(void)
{
  f503(1798878281, -0x1.0b8ac1b2292a8p+3, -0x1.8ecd6dfbff6b6p+5, -0x1.69da911f43187p+4, -1335348672, -0x1.4a5a6f022c0ap+0, 8738125266098186668, "", -1446268868, 0x1.bf8f1fc760338p+3, -0x1.de94b9344fad8p+3);
}

void call_f504(void)
{
  signed char r = f504(244509094, "", 770552651, "u", -0x1.30e09eae206f7p+4, 1597672026, -118654103, 0x1.85e3bf5360664p+4, 0x1.de379b44080ap+4, "nr", "", 0x1.e36b20c9faa94p+4, -2748047483634507751, -1104646640);
  ((r == 76) ? (void)0 : failure("r == 76","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2666,__func__));
}

void call_f505(void)
{
  f505("ex", "e", 0x1.790af46748624p+5, 0x1.5398d0eb5349ep+5);
}

void call_f506(void)
{
  f506(0x1.1a5c776bd9de4p+3, 0x1.0396c39b05c68p+2, 0x1.e1c6016d5851p+4, "ga", 0x1.09a2f5c1321ep+2, "b", "ib", -6558662452786854647, 1245572389, 0x1.6e14b0b7f8834p+4, -1694067589, -0x1.8f0074fb1ce2p+0, 1732907963720042730, 1646310654);
}

void call_f507(void)
{
  long long r = f507(-651952185, "l", 1853001903, "nc", "g", -2601809875231634152);
  ((r == 1930727983678913588) ? (void)0 : failure("r == 1930727983678913588","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2682,__func__));
}

void call_f508(void)
{
  f508(0x1.aaf27489649fp+4, -0x1.f3822e9e647cap+4, -0x1.76f5fed431e48p+2, -0x1.c9eb02682e57p+1, 0x1.2a08f961a36bap+5, 0x1.18e828387a5dp+4, "wx", 3981182153445660123, "", -1902437595, 1774891545, "", 1630948436, 1292718334, -0x1.0a02e01b96adcp+4);
}

void call_f509(void)
{
  f509(-7952187229834953590, -0x1.5a6a8a48b6568p+3, 0x1.b83f9f355cd94p+4, "tb", -0x1.4a18214f8c59ep+5, -0x1.892134fa25938p+5, "v", "", -0x1.cca53e28beb3ap+4, "rt", 6888358195601309165, "", 6771964114822910718, -1094672446, -344555233, -750146799510835077, -2468906402371680535, -5239875721579740148, -0x1.2a1fc984254dp+1, 7328451540451387922, -1575222014);
}

void call_f510(void)
{
  double r = f510(-1017899302790885832, -176678215, -9089079110903146822, 926281361436496019, 3759872874475197959, 0x1.5a3847df2d774p+5, -0x1.809d2df4d3307p+5, -0x1.a402b97d26d9cp+3, 2057031648, -1507422706);
  ((r == 0x1.0d281e8ab78ep+4) ? (void)0 : failure("r == 0x1.0d281e8ab78ep+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2698,__func__));
}

void call_f511(void)
{
  short r = f511("oq", -828344192, 0x1.d6f1dd61a2268p+4, 5828183684608355986, -3551820415930537204, 0x1.4e6c7a07c6d18p+5, -121574205, -0x1.9cab90221957ap+4, 1695238037491674857, 3602788237121354324, "", -0x1.3b70c7861208p-2, 9220487526464789609, "m", 0x1.764a74992f93p+2, -0x1.c7bd4c501ab24p+3, -0x1.ebd0bb9358f5p+3, -1029575674031138501, "nw", "wk", 0x1.b40e699c7e73p+1);
  ((r == -27840) ? (void)0 : failure("r == -27840","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2704,__func__));
}

void call_f512(void)
{
  short r = f512(-0x1.3136d6329a47dp+4, -5131772831501270453, 0x1.ac977d31b7724p+4, 0x1.82e67a4751384p+4, -152046794516214871, -2686009953251989677, -0x1.6e3191be6d38p+0, 197508484, "b", "jy", 0x1.0df4a51a43b8cp+3, 6402972165995281082, 0x1.b578b90d096b8p+3, 905495105, 987947171, 305901769, "");
  ((r == 11168) ? (void)0 : failure("r == 11168","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2710,__func__));
}

void call_f513(void)
{
  char * r = f513(0x1.5f25b17896728p+5, "", 1247418810, -0x1.31216ee60112ap+5);
  ((strcmp(r, "wf") == 0) ? (void)0 : failure("strcmp(r, \"wf\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2716,__func__));
}

void call_f514(void)
{
  f514(-0x1.31584e5187b04p+3, 0x1.1062e7728d7d8p+3);
}

void call_f515(void)
{
  f515(-59529341, -1942726981, "m", "rt", 7477404251717217658, -0x1.269dfb0336a08p+5, -0x1.5fadcb0f7bf22p+5, -458505438, "sl", "", -0x1.8104c1603f356p+5, -6484798746886086784, 123828328, -0x1.1526039885b44p+4, 2142119050);
}

void call_f516(void)
{
  f516("x", 8983749367112252155, -2414032101388523989, 0x1.92697982f8f3p+3, -23983818591887564, 3739889602196038057, -1085086301, 0x1.c28098e6f743p+4);
}

void call_f517(void)
{
  f517(-571139464, 1270847116, "yc", 1411859401, -2491334963369161517, "c", -0x1.054e53396179p+5, -0x1.23870e70d4bfdp+4, "", 0x1.169dd9f8f68ep+2, -0x1.16a21ae0e0523p+5, -6814862987840914625);
}

void call_f518(void)
{
  unsigned char r = f518(-4572740975018088296, 2061584246, -0x1.f65e093ab22ccp+3, "", 0x1.91d50bdf15e9p+3, 1210843119, 1709850131847537874, -0x1.edaa4989ad347p+4);
  ((r == 14) ? (void)0 : failure("r == 14","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2742,__func__));
}

void call_f519(void)
{
  signed char r = f519(-7759359980323158405, 0x1.90511ab7f1e3cp+4, 4427428993970271842, -799817705, 1447954731924560890, 1670122740, "", 7791722256667529060, -1936245491, -868390373);
  ((r == 33) ? (void)0 : failure("r == 33","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2748,__func__));
}

void call_f520(void)
{
  f520(0x1.c83861d62eeacp+4, 0x1.28f680d7f843p+5, "u", -0x1.17db21bc39863p+5, -1893609524, 1376561809374834330, 0x1.eeaa6b6a91e18p+3, -1141771397, 1059883812, 1878760592, -0x1.e886cf062a52p+2, 0x1.049032807fe86p+5, "g", "xy", 0x1.dba0cf17d5c2p+0, -0x1.bb82f7658dce8p+2, 0x1.44af287261b9p+5, "sg", 0x1.04b3ffdda70ep+3);
}

void call_f521(void)
{
  unsigned char r = f521(-0x1.3a99f0cc8d7c8p+5, 216478274, 9214521487584816137, -0x1.402257a4c0f5p+5, -1702289222, 2373198978270937138, 9123128734294932014, 2523318209244906958, -1767283371374065002, "dc", 743288435, 0x1.5a6cd600652a4p+5, 0x1.650f1aa5f760ap+5);
  ((r == 64) ? (void)0 : failure("r == 64","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2759,__func__));
}

void call_f522(void)
{
  f522(0x1.848f322247054p+5, 0x1.8083cb6cb0d78p+3, -2009376865, 0x1.bce36fe5a8a6cp+4, 959766711, "", -3937866228603091076, 3156430611373474695, "", -250480375, "c", -0x1.6427216f8d30ap+5, -2092803091);
}

void call_f523(void)
{
  float r = f523(-0x1.8ab0e438b15d6p+5, -1481574566, 0x1.10b487eb50ca2p+5, -0x1.89c045c9cd963p+5, -0x1.124d3c522b35p+3, -0x1.f2565c40d9e54p+4, -496215247, -1442888657, 1752505881, 0x1.a13185832fdfp+3, 969690593, 0x1.ba0be4972f02p+3, "h", -1923305637321720560, "", 0x1.609c5fe7b49d4p+3, -0x1.1acee027c7cdap+5, "h");
  ((r == -0x1.28bfdap+3F) ? (void)0 : failure("r == -0x1.28bfdap+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2770,__func__));
}

void call_f524(void)
{
  unsigned short r = f524(1480255774, -3073147713313255759, -1029372633, -5098863275645614687, -0x1.5b5bb5087c48p+5);
  ((r == 9763) ? (void)0 : failure("r == 9763","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2776,__func__));
}

void call_f525(void)
{
  f525(-7409978769002218785, 0x1.2fcda58801954p+4, 55773943, "", 467835886182215763, -1579479498);
}

void call_f526(void)
{
  double r = f526(0x1.89842cb20daap+0, -0x1.2ac7594316abcp+3, -6232490480648844681, "ag", 0x1.20fa5e9dc247p+5, 0x1.82921d7e89104p+4, -4873326973335777349, -0x1.b03f4af34e94dp+4, -5658329014223809032, 7239803764381444189, 3395247704272537503, "x", 0x1.769b097923588p+4, -1761992647, 1002787026, 1523920409, "", 0x1.312102fd88518p+4, "r");
  ((r == -0x1.7e86e135094d4p+4) ? (void)0 : failure("r == -0x1.7e86e135094d4p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2787,__func__));
}

void call_f527(void)
{
  float r = f527();
  ((r == -0x1.3407d4p+5F) ? (void)0 : failure("r == -0x1.3407d4p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2793,__func__));
}

void call_f528(void)
{
  short r = f528("", 0x1.4c22bc2f9b6dcp+4, 972527470, -5226027206361503183, -0x1.348295833a456p+5, "zl", -8816272440449236248);
  ((r == -8568) ? (void)0 : failure("r == -8568","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2799,__func__));
}

void call_f529(void)
{
  f529();
}

void call_f530(void)
{
  short r = f530(972477848, "w", 0x1.c024ec02369d4p+4, 0x1.79dd147362902p+5, -0x1.f6989fe88194p+0, 1971094942, -0x1.369b87c374201p+4, 3004482235910548209, -1282551546, -1201220347013816886, "gu", "k", "b");
  ((r == -18870) ? (void)0 : failure("r == -18870","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2810,__func__));
}

void call_f531(void)
{
  unsigned short r = f531("o", 767709112, 0x1.2d4e736e702d4p+4, 0x1.5b90c048c9eap+5, "z", -861970088082761768, 0x1.9deee2c761a84p+4, "ae", "", -7675337716757400194, "i", -0x1.6982e70e0e156p+4, 0x1.439cfc38c696p+5, -2416939910125236944, 2094574980, -9141091173761559155, 0x1.b991227dbd9ccp+3);
  ((r == 47159) ? (void)0 : failure("r == 47159","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2816,__func__));
}

void call_f532(void)
{
  f532(8784686957353186823, -0x1.54833c5919be3p+5, -0x1.37fbb1daf7334p+3, -0x1.4251a5956f3ep+4, -0x1.7fb650590217p+2, "my", 394073720, -0x1.9217de75b966cp+3, -96573073, 8290516323485685336, -0x1.43a2b0d28abdfp+4, 754473761, 301625330, "q", 1815556357);
}

void call_f533(void)
{
  unsigned short r = f533(-0x1.cf231474516a4p+3, -0x1.10c1967c334fp+3, 2136122701, -0x1.1a8c89bb7de2ap+5, 0x1.2631d0908f4bp+2, -0x1.597544a9d34aap+5, 1709552844, 0x1.a4089b2e07a2cp+4, "", 0x1.e887c715617ccp+4, 2545769689655215965, -8093832326274495498, "e", 1819077510, 629841100, -9145413208239521943, -0x1.b740fef0ac19bp+4, "v", 0x1.a3682efe576e4p+4, -5878880310163128514, -0x1.e75638882546p+1);
  ((r == 55301) ? (void)0 : failure("r == 55301","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2827,__func__));
}

void call_f534(void)
{
  f534(0x1.6a885804bf1p-1, -0x1.9d08e65ba8ae2p+4, -5194079658675282136, "z", -1751099162, "vr", 4369164843112851440, 23141014236653083, 0x1.06df3ac45b954p+3, "", 1418062658, 0x1.e049467cffe9cp+4, -1689564276640444071, "", 1511790788);
}

void call_f535(void)
{
  long long r = f535("", 7893994441795009860, 3746295763452153143, 0x1.15490dcf78214p+5, -0x1.44f120a52962ap+5, 0x1.8b2d847ad8b9ap+5, 2259721128970133124, "", 6698804892780814335, 0x1.efdfb85ea0188p+4);
  ((r == -2966051762440522075) ? (void)0 : failure("r == -2966051762440522075","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2838,__func__));
}

void call_f536(void)
{
  f536(-1496722834956437840, "", -5743784618782441441, "", 0x1.c01fe45a32a38p+4, 0x1.de98f8c0a4d8p+0, "", -9056188527555560148, 5072609348756823732, 1022212250, 1532022636, -7173590080507240407, 1148701616, 2921893121470474002, -465128987);
}

void call_f537(void)
{
  float r = f537();
  ((r == -0x1.ae0562p+4F) ? (void)0 : failure("r == -0x1.ae0562p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2849,__func__));
}

void call_f538(void)
{
  unsigned char r = f538(-0x1.1bd04bffa9faep+4, 0x1.d5b2f9c798e1p+3);
  ((r == 93) ? (void)0 : failure("r == 93","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2855,__func__));
}

void call_f539(void)
{
  short r = f539(-0x1.2f6a378286fb8p+2, -829089096, 1555262113, "s", -1555002920, 1428822819874240521, -2068468886, 2106273274, 227239238, -742870723, "d");
  ((r == 14190) ? (void)0 : failure("r == 14190","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2861,__func__));
}

void call_f540(void)
{
  f540(-0x1.e3e28f96e4aep+2, "b", 0x1.643beff31a04p+1, 0x1.46509ff1ce478p+2, -3953951112177812083, -35829848, -6892021542998755305, 0x1.604d94cacba8cp+5, -2871603373389305324);
}

void call_f541(void)
{
  unsigned char r = f541(-0x1.304d9f1b61944p+5, 6353242918429893303, -479318415, -772674521, -0x1.6265ccc9ad1ap+0, 0x1.22632fa01544p+1, 640679940, "xm", -1414227088618573429, -1168033057, "d", -1363151946, -0x1.2ba7a953762p-1, 0x1.38de85e47683p+5, 1047562712, 0x1.d9d280937b24p+4, 0x1.e8cb333ebac7p+3, "", 3932303769132766187, 2510536494076463661, -1617227974, 0x1.187b3772b6108p+4, "c");
  ((r == 172) ? (void)0 : failure("r == 172","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2872,__func__));
}

void call_f542(void)
{
  f542(1262113270, 0x1.8d088f2125a4p+1, "", 74183402, 110340599, -6441231034753087305, -4042276067362204747, 1189239202, "", "qb", -1393053640, 148631831);
}

void call_f543(void)
{
  f543();
}

void call_f544(void)
{
  f544("xn", 638707019, "sj", -0x1.877676c6e4918p+3, "l", -1480625252, 8696243274217057601, -1200358625, 1795411772, -0x1.8be5a0918676dp+5, 334111222, 2100974585877414477, "", 0x1.94c0bcd201c4cp+4);
}

void call_f545(void)
{
  f545(7730231872730052573, -1205741730, -3274010710732184602, 0x1.0bdf642be232p+5, 1872115344, -1471691508, "", -1502339216, "h", "u", "ib", -0x1.9c6a8b3531a2p+2, "b", 1999880833, -8109088);
}

void call_f546(void)
{
  signed char r = f546();
  ((r == -58) ? (void)0 : failure("r == -58","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2898,__func__));
}

void call_f547(void)
{
  f547(-0x1.7f945a1e5d9b8p+4, -1382248931, "p", "jy", -2113910881707529575, -0x1.667cf482e252p+5);
}

void call_f548(void)
{
  f548(-353957268, 0x1.32913aad97a9cp+3, -4249896693879178290, -0x1.85abd17725d2cp+3, -0x1.7ed04068616efp+4, 7987477250887422933, "o");
}

void call_f549(void)
{
  signed char r = f549(7410075724737335107, -1040532043, 3535838193547037023, 0x1.48ecc60ad72a4p+4, 1528369831060304550, 0x1.f8f3a47ab1b28p+2, "w", 0x1.2f87453d9bb28p+4, 1967884146437431789, -0x1.31da3ed09cc05p+4, -496650687397827104, -1480918338, -0x1.3c11f4f928684p+5, "", "f", -217003070902442168, 0x1.39655d3c8b53cp+4, -1454746890, 8554161589578494100, 190436192);
  ((r == 57) ? (void)0 : failure("r == 57","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2914,__func__));
}

void call_f550(void)
{
  f550(-0x1.0696ebb9e5af6p+5, -751879081, -1463543090239527823, -1407985688, 160306366, -0x1.74a8af79cfb11p+5, -0x1.74d2cc0b44c03p+4, 0x1.81f5ba9d95ffp+5, 0x1.178360dababb2p+5, "e");
}

void call_f551(void)
{
  signed char r = f551(8388536694602410541, 0x1.13bccb2db3014p+5, 451430514, "", -785208510, -0x1.6492db5d9303p+1);
  ((r == -61) ? (void)0 : failure("r == -61","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2925,__func__));
}

void call_f552(void)
{
  int r = f552(7746876322165760833, -0x1.5adad9109abfbp+4, -0x1.f5f03619e2164p+3, "wd", -4829922143638835400, "");
  ((r == 1789111052) ? (void)0 : failure("r == 1789111052","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2931,__func__));
}

void call_f553(void)
{
  f553();
}

void call_f554(void)
{
  char * r = f554("", 4186213902172969692, 7064173624906808330, 6164530808455782707, 0x1.024be90a630bp+2, 8839513535509104275, "hb", -2052549188, -0x1.78fc3e97a5a43p+5, -2607177193378727911, 0x1.594735636dafp+5, 1847885607, "v", 3591550192550182094, 2057941646, "rc", -0x1.4f1ebf87ba684p+4);
  ((strcmp(r, "y") == 0) ? (void)0 : failure("strcmp(r, \"y\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2942,__func__));
}

void call_f555(void)
{
  int r = f555(1397226439, "kl", -6390682720830159080, 3098191562268198506, 0x1.ed1d62c0d4548p+2, -0x1.51560054c096p+3, "", "", 1898098220, 679816092, -518341237, -1228507786728731217, "");
  ((r == -269388257) ? (void)0 : failure("r == -269388257","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2948,__func__));
}

void call_f556(void)
{
  char * r = f556(1255941764, -606350957517177638, -0x1.1675b557492a8p+5, -3846326204071899950, "", "", 0x1.a507362d07e2cp+4, -506521180009401055, -286015233, 1538536807, -6628117677660823713, -7509780196484447046, 170746462);
  ((strcmp(r, "xq") == 0) ? (void)0 : failure("strcmp(r, \"xq\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2954,__func__));
}

void call_f557(void)
{
  f557(-0x1.1fea08ef3be1cp+3, 1231000221965872253, 4298491641687918135, -6740767039821507648, -3510841410357832240, 0x1.f32bc11690afp+3, -0x1.4280cdf64c9b4p+3);
}

void call_f558(void)
{
  f558(0x1.166cfe477d818p+2, 0x1.ab56ed9d4ee28p+4, 1754810215, 1375057869, -1957161966017920104, 1260490310, "n", -5674880395024575388, -1434475658, "nm", 0x1.6ce8f062df978p+4, 9165352564945872203, -0x1.69b275c85d357p+5, 0x1.6b0bf8016848p+5, 0x1.66a7435cef624p+5, 0x1.4bb59fac03872p+5);
}

void call_f559(void)
{
  f559(1119881781, "o", 1724742225, 0x1.a6f6c6470de84p+4, 0x1.78dbfa4dee2dcp+5, 0x1.47d74fa9a265ep+5, "e", "n", 3101986023843295641, -2048723949, 104642630134579599, "dk", 1338234810, "cq", -1771497900);
}

void call_f560(void)
{
  unsigned short r = f560(-0x1.82001d30caf74p+5, -107726475, -1800383137, -0x1.35129ea6230aep+5, -164186545, -0x1.62178ce68201cp+5, -5156292856568060212, 1418668653, "ga", -6310622347309610917, 0x1.59ac56ccd8bp+2);
  ((r == 48644) ? (void)0 : failure("r == 48644","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2975,__func__));
}

void call_f561(void)
{
  f561(-0x1.3c37136d0bacp+2, -0x1.5024b091677ecp+5, 862755397, 2091565542, "bd", "z", "c", 0x1.22efe0ce5f5cp+0, "li", "b", 704820973, 0x1.e84dd8e8923f8p+2, -0x1.6923f88bf92bep+5);
}

void call_f562(void)
{
  long long r = f562(-772177932, 883921892, -0x1.e6574a1890688p+2, -1443315617672487977, "");
  ((r == 7441097621895104987) ? (void)0 : failure("r == 7441097621895104987","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2986,__func__));
}

void call_f563(void)
{
  float r = f563(-0x1.882aa8cfa9f4ap+5, "z", 0x1.5c3c5de686626p+5);
  ((r == -0x1.65505ap+4F) ? (void)0 : failure("r == -0x1.65505ap+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",2992,__func__));
}

void call_f564(void)
{
  f564(-2039294200464676978, 0x1.a79e2b4a7ef38p+4, 0x1.6ef854abdf8bap+5, 147017829, -1431554094, "st", 1561180988, 6802559661172802502, -610797454);
}

void call_f565(void)
{
  short r = f565(0x1.203283c3e548ap+5, 0x1.17ff4b43a4876p+5, 4960990124650603468, -0x1.f1f0e9ff137bcp+4, "c", -1914937311, 1738727781, 0x1.ed2a50ec63fep+3, 0x1.6ce81d30fd00ap+5, -1196369579, -0x1.19c32c2d2b0e8p+5, 0x1.4a9881680bde4p+4, 0x1.01629918dc80ap+5, 0x1.4a4dab638692cp+5, -1947265083, 0x1.571fb14f4337cp+4, 1177886641);
  ((r == 12202) ? (void)0 : failure("r == 12202","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3003,__func__));
}

void call_f566(void)
{
  unsigned short r = f566(0x1.7fbbbc9c8bcc8p+2, 0x1.3e9e673e19bc6p+5, 0x1.9508d9d93a958p+4, -1975714379, "oq", 1561082007, 0x1.071db8efb91p-2, 2095285010, -0x1.805479e471f02p+5, -0x1.56147c8e81fp+4, 0x1.4b5d8544fe26ep+5, 489073228);
  ((r == 59136) ? (void)0 : failure("r == 59136","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3009,__func__));
}

void call_f567(void)
{
  unsigned char r = f567(5392171703235331082, 0x1.3ae3ac1449152p+5, "", -0x1.68e05c62c5582p+5, "q", 0x1.37160c52de5bp+5, 0x1.4a657cbb860dcp+4, -734859057, -0x1.f7eee2e4ecc4p-1, "", -5447626643971544640, -959017552, 5140727014358927006);
  ((r == 96) ? (void)0 : failure("r == 96","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3015,__func__));
}

void call_f568(void)
{
  f568(-0x1.81246c8e34cccp+4, 1791195525044733894, 0x1.52c8a0b9df5c4p+3, 5100341654775555757, -1949854282280122798, -0x1.2355543423149p+5, 6581850378987397480, -394136027, 0x1.700fb78f99c76p+5, 0x1.54e62f91063ap+3, -2115523354);
}

void call_f569(void)
{
  f569(-0x1.f920a16c7c081p+4, 2064650932, 204169512, 7039394762897550066, 8184586000491168676, 444568970);
}

void call_f570(void)
{
  f570();
}

void call_f571(void)
{
  f571(0x1.3f31bc5752dd8p+5, 0x1.e6302a111d768p+2, -0x1.2602387243ep+4, -0x1.5038968442f7p+5, -0x1.7c611bb15840bp+5, -7298951395524275436, 917106162, 245813638, -0x1.4705ae50aab82p+5, -8652832969470019780, "", -5726123959703364059, "aj", -5582807806781207605, "r", 0x1.8b83870860548p+4);
}

void call_f572(void)
{
  f572(1245122773, "", -0x1.8c0a8c6fb72bdp+5, "fn", 7723737855437059959, -4921753107660369630, 8320357314525756719);
}

void call_f573(void)
{
  f573(-0x1.d57795d911b18p+3, 1857771995, "ki", "jm", "i", -466476220, -5872853918910996267, -8473789874934999806);
}

void call_f574(void)
{
  f574(-0x1.7e0cfc4647dap+5, 0x1.544be7ec287d8p+5, 1766434936, -0x1.bd64ae756b6fp+2, -1219694058, 1601712367660320974, 6583196504011463179, 5981059661437967017, "");
}

void call_f575(void)
{
  float r = f575(0x1.f73cc70cc61f8p+3, 1411139781, "t", 0x1.87e4a619cb9fp+4, 626800579, -1476154551, 2103456633, 0x1.3aa7b0c141c58p+5, -1371413535, 131230215916667313, -0x1.854fcca858908p+2, 1785594678, -0x1.5ce0a35434049p+4, -2013525579165033210, 5316180501848133634);
  ((r == -0x1.254464p+5F) ? (void)0 : failure("r == -0x1.254464p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3056,__func__));
}

void call_f576(void)
{
  float r = f576("z", -0x1.0cf07ce50dabp+2, -1083737581266618600, -4192230367285534420, -0x1.c1f36847c58b1p+4, -0x1.70aba36464586p+5, -1633862445, -0x1.4804ca803365p+3);
  ((r == 0x1.136e66p+4F) ? (void)0 : failure("r == 0x1.136e66p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3062,__func__));
}

void call_f577(void)
{
  f577(-7998204164749943798, 0x1.ae629008d36c4p+3, -0x1.6ee51e96769f6p+5, "y", 1729019749, -0x1.d74b8c20395c3p+4, "m", "n", -1529292665, "", 0x1.62cbc453be42cp+3, "", -0x1.0d8c38576085p+5, "k", 6831612564546006264, "v", -770290849636613861, "jf", -6658814257162962508, 1760454807);
}

void call_f578(void)
{
  int r = f578();
  ((r == -53771081) ? (void)0 : failure("r == -53771081","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3073,__func__));
}

void call_f579(void)
{
  f579(6874400531628409083, 0x1.7fd674de85848p+2, 2413132070650506650, -0x1.841dd26fb6d65p+5, -0x1.314a39c5cd518p+3);
}

void call_f580(void)
{
  float r = f580(-1200921070185497114, 723682123, -838699950, -2798077814189756999, -0x1.146137f209e58p+4, -2303308333142813984, 1867910889, "l", 0x1.36e24d9604de4p+5, -3805334446325926332, -934513081, -1341550829);
  ((r == 0x1.5f60ecp+4F) ? (void)0 : failure("r == 0x1.5f60ecp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3084,__func__));
}

void call_f581(void)
{
  f581(0x1.62c7d8077c61cp+4, "i", "f", "r", -5639302176979454456, 0x1.c819222336acp+0, 0x1.7a671440dfb6p+5, 1780294554, 5168305285845341942, "n", -488490490, "u");
}

void call_f582(void)
{
  f582(-0x1.de94594d55ce6p+4, 948082525, 0x1.24ca7116a4f6p+5, -0x1.675fd316aa958p+3, -0x1.8ea102cf14e82p+5, 1039480709, -0x1.51dccf3d527a4p+3, 3264011584981200754, 1237639062, "r", 1239697135, -869609986, -5619339265646166324, 0x1.6e44f85d59a3cp+5, "gv", 968056811, 984473993);
}

void call_f583(void)
{
  f583("", 0x1.3aba871440958p+4, -232478720, -2998100074326028926, -1672035971, -4148810961608434490, "", "p", 0x1.313f55566144ap+5, 0x1.65f38cd2279b6p+5, "p", 0x1.9a748378ab37p+3, -637653982761750565);
}

void call_f584(void)
{
  double r = f584(-2055222978, "yy", 4208852735004330834, -4673232213016711015, -195593720, 2120437856, -562581243);
  ((r == -0x1.131b7e620d13p+2) ? (void)0 : failure("r == -0x1.131b7e620d13p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3105,__func__));
}

void call_f585(void)
{
  f585("d", "h", 6647328201421121520, -937597927, 0x1.f8758e28c54f8p+4, -0x1.359fbedddbc52p+5);
}

void call_f586(void)
{
  int r = f586();
  ((r == -1319154786) ? (void)0 : failure("r == -1319154786","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3116,__func__));
}

void call_f587(void)
{
  int r = f587();
  ((r == 344736865) ? (void)0 : failure("r == 344736865","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3122,__func__));
}

void call_f588(void)
{
  short r = f588(0x1.ed2489a9a17cp+4, 5909704293210198499, 0x1.13a09b5e0584cp+3, 1211651080908209059, -391304249, -0x1.fc8789e78d9ap+2, -0x1.b473118434533p+4, 0x1.8496e064b7ab4p+5, -8395815346627644071, 0x1.1b29dfd397edcp+5);
  ((r == -15064) ? (void)0 : failure("r == -15064","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3128,__func__));
}

void call_f589(void)
{
  int r = f589(1558936214, 1284446448317536924, 1411241138106466469, "", 3887979282438863394, -283106386, "jy");
  ((r == 228838927) ? (void)0 : failure("r == 228838927","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3134,__func__));
}

void call_f590(void)
{
  f590(575891934, "w", 0x1.88ca481d600c2p+5, 6742533440532794600, -8462718044848788771, -2014644236662954408, -0x1.33b1b7fe2b7d8p+4, 3905611834053580771, 0x1.77bfa6c3f79a8p+2);
}

void call_f591(void)
{
  char * r = f591(0x1.3232c9f058cp+5, 1545844966, -3696214788596571914, -0x1.0348c3b67661p+2, -0x1.9c0e6811c6361p+4, -4547715094048853101, -1934393619, "q", -1507750914, -3380424355536714386, 1454357008, -0x1.21a3bc54998d2p+5, -4667543389674695796);
  ((strcmp(r, "d") == 0) ? (void)0 : failure("strcmp(r, \"d\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3145,__func__));
}

void call_f592(void)
{
  unsigned char r = f592(-6010526387574749282, -0x1.54cfaff3ed2b6p+5, "cy", 0x1.8389344353708p+4, "d", 0x1.7db44641b8accp+4, "rk", 1851361746258123059, "", -0x1.39c513f7c51a6p+4);
  ((r == 79) ? (void)0 : failure("r == 79","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3151,__func__));
}

void call_f593(void)
{
  f593(-1606293719242913555, -0x1.597554d97293ap+4);
}

void call_f594(void)
{
  f594(613919097, -6839072874997353397, -1412880681287440009, -0x1.1ce6985132184p+4, -3210698475411362292, "", 0x1.8c1ba034c2a38p+5, -0x1.6bbd3e7357b08p+4, "", "k", 4789690432534831324);
}

void call_f595(void)
{
  unsigned short r = f595(0x1.9fb56116c9b8p+3, 91189867, 650714991, 5104098104168875624, "", -254870107, 0x1.7e4acfcb5e3b8p+5, 0x1.05c72280ff624p+4);
  ((r == 63746) ? (void)0 : failure("r == 63746","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3167,__func__));
}

void call_f596(void)
{
  f596(439592826, -0x1.d3fb646cab779p+4, 210246548, -6057735894740793294, -964723570602079407, "z", "y");
}

void call_f597(void)
{
  f597("", 1225247850, "eo", "", 0x1.dad08b33c8f2p+0, 566934922, 0x1.ac09adf2d8bfp+1, "", -0x1.3441fd6a0b4dp+1, 0x1.34fd0580d0a88p+3, 0x1.b283eccf3b4a8p+4, "gl", -1437603341657675818, "", "vj", "", -0x1.4ee812e0c5f93p+4, 0x1.d42d725eda34cp+4, -86589506, "");
}

void call_f598(void)
{
  f598(0x1.1b9c6d33b3694p+4, "bk", -0x1.1f06098a1e5a8p+4, -1661295811, "qo", -0x1.2d41d41a7e6fdp+4, 0x1.274237bebe926p+5, "yi", 0x1.5aa5ce3c7ca3ap+5, 1214375879, -92492881, "lt", 0x1.2d36507d0cd78p+5, "", -433132298, -6638107430273770276, -0x1.73632fdb028f5p+5, 0x1.41e9d7bef6438p+2);
}

void call_f599(void)
{
  f599(0x1.0a5c621324a8p+3, -1437248243466294719, 2192732621401526400, -2129777702216336045, 5488384474265387762, 0x1.b385552c78788p+3);
}

void call_f600(void)
{
  long long r = f600(8548938812409740645, -0x1.4fc515b7439d8p+3, 1923042089, 1720220438, 924625963, "", -0x1.74730bc0fd411p+5, "", 1243502182, "", -0x1.2ddc7a0ade424p+3, -2100580644, -1714656852, -0x1.d4f3aad90d5d8p+3, "dn", -0x1.5d4e40aebbe29p+4);
  ((r == 7456500054151728525) ? (void)0 : failure("r == 7456500054151728525","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3193,__func__));
}

void call_f601(void)
{
  f601("", "", -0x1.55dff485e9053p+5, -0x1.585981951c26dp+5, -0x1.6ce4340eae608p+4, 0x1.88897651724dap+5, 0x1.827810f00f894p+5, -0x1.02409281a4de2p+5, -1361236657, "es", 462683981, "g", "hy", "", -849774625, 0x1.3a1a645fe6214p+4, "", "f", "d", 0x1.12f048530539cp+4, 0x1.c88880587df68p+4);
}

void call_f602(void)
{
  f602(-3225866366080192854, 7747388518188295935, 0x1.1dec18eae8248p+2, "tb", "te", 0x1.c21ede743b2ap+0, -0x1.eb6f51e88b8p-4, -0x1.4f7cf4b40c616p+5, -0x1.1c6c42d60d1f3p+5, -0x1.1b8e214012e5cp+5, -0x1.8afc5634b4a66p+5, -0x1.023631171e5c2p+4);
}

void call_f603(void)
{
  f603(-131759271021167308, -0x1.f1f246efa6519p+4, 2052229948, -0x1.5f5f10d2e0c74p+5, 2018441658, -1256043477, 0x1.b9c41fcd56888p+3, -0x1.866bddcc65854p+5, 2246125240120251299, -0x1.76783cd36aecp+5);
}

void call_f604(void)
{
  f604("", -2080589611, -1008472608135867976, "ii", 0x1.85fe47498c9b6p+5, -0x1.eb10616217df3p+4, "d", 0x1.3efe10c3ba9dep+5, -812051159, -0x1.64e05607a5c34p+4, "a", -7413593815604792790, "nt", -1252423462, -707683619, -374879432);
}

void call_f605(void)
{
  signed char r = f605(-0x1.e02662c3f782p+1, "sc", "", -462044302, "", 955920632, -1280024851, -0x1.92e8d31855e3p+2);
  ((r == -80) ? (void)0 : failure("r == -80","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3219,__func__));
}

void call_f606(void)
{
  f606("", 1564872346, 907329276, -5173643799795348529, "tk", 1767739958, 1072912657, "w", "", 1060086561931974853, -879608095, -652945953, 7954915392307621442, -0x1.f91646acb0147p+4, 3418180576762642690);
}

void call_f607(void)
{
  char * r = f607(8389549318565367211, 0x1.0b0daa3f4cdp+2, -0x1.6051c303892dap+5, 1595012736, 3939231186474907876, -0x1.adc199cc3defp+1);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3230,__func__));
}

void call_f608(void)
{
  signed char r = f608();
  ((r == 25) ? (void)0 : failure("r == 25","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3236,__func__));
}

void call_f609(void)
{
  int r = f609(0x1.90ec560a932acp+3, -0x1.67aea5d95e551p+4, "", -8588638061169398311, "y", "", -0x1.093e1e0982c82p+4, "w", "", 0x1.f382758187514p+4, "iz", -1360992768432908900, -0x1.d1673c45b5c5fp+4, -2690279873019069672);
  ((r == 269648066) ? (void)0 : failure("r == 269648066","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3242,__func__));
}

void call_f610(void)
{
  f610(0x1.0f118e36349c8p+2, "", -2075559511, 3519757924312170868, -698848033, "i", 0x1.9424ef5bf903cp+3, -0x1.75ec6eb13af4fp+5, 5187146857427162719, 0x1.7dbb5eb5ef11p+5, "a", "", 304988408, -9040502092554335374, -0x1.11c14fc52375cp+5, -2543939973448170113, 0x1.ef18b5e23e5ap+4, -923811976, 0x1.0d3d7aa3c3302p+5);
}

void call_f611(void)
{
  f611(-5120240935899343292, -0x1.69c1cfa34a3eep+5, 0x1.d8d3cd172952cp+4, "f", 3934528999776025528, "ju");
}

void call_f612(void)
{
  f612(1819477407, -1203568227, 3694474857801203734);
}

void call_f613(void)
{
  signed char r = f613(-1771306250, -0x1.b512c1bebcea8p+2, 0x1.2dff3cd5383p-1, -0x1.18044d74dae5cp+4, -2318183522248439844, 1650726648707629926, "j", -0x1.7febc382e794p-1, 0x1.81a32acdc6abap+5, -28377364, -0x1.0f92a47815cdcp+3);
  ((r == -45) ? (void)0 : failure("r == -45","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3263,__func__));
}

void call_f614(void)
{
  float r = f614("mj", -828899054996193599, -0x1.5eaaa1f1f05c9p+5);
  ((r == -0x1.239ff2p+3F) ? (void)0 : failure("r == -0x1.239ff2p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3269,__func__));
}

void call_f615(void)
{
  double r = f615(-1812474834, 0x1.50da177eeb1dap+5, 0x1.e29c54d0ee438p+4, 1307541174, "", 0x1.1bfd9c5eb518p+5);
  ((r == 0x1.073138061cd8cp+3) ? (void)0 : failure("r == 0x1.073138061cd8cp+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3275,__func__));
}

void call_f616(void)
{
  double r = f616(-8615737153638088308, 1109910946, "gw", 1736923791, -2096866747, -4257582868174086548, 2181687769024172495, "", 0x1.20d6dd56c02dp+2, -6762082900715991516, 6145781177741228778, "", -0x1.0599e55570934p+3, -0x1.0a2e3f8756288p+2);
  ((r == -0x1.dfc9a744a7c77p+4) ? (void)0 : failure("r == -0x1.dfc9a744a7c77p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3281,__func__));
}

void call_f617(void)
{
  f617(-0x1.466e1b4f9664ap+4, "", 1756527267, 0x1.b2f87425dbf9p+2);
}

void call_f618(void)
{
  f618(-1340624680, -0x1.2bf90d635c33p+1, -0x1.fd47aea31e05p+3);
}

void call_f619(void)
{
  float r = f619(-187959198, 208707181507894175, -5638103979469228455, 2984511488087942380, -7874804799140832543, -2113726061, -6213056264536725772, -0x1.30925cef0583bp+5, -1891148, "qa");
  ((r == 0x1.5b468ep+5F) ? (void)0 : failure("r == 0x1.5b468ep+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3297,__func__));
}

void call_f620(void)
{
  unsigned char r = f620("", "gh", 0x1.ca1c0acbf38bp+4, -0x1.c3fe99725be0cp+3, "fw", "", 2015901704, -8495424927078404014);
  ((r == 96) ? (void)0 : failure("r == 96","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3303,__func__));
}

void call_f621(void)
{
  double r = f621(-177189053, "", 7142449366587603624, "", -6364373401726786850, 5452076689348022708, 8804990196057740377, "gr", "", -8918805900708829346);
  ((r == 0x1.78ea65ace86ep+3) ? (void)0 : failure("r == 0x1.78ea65ace86ep+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3309,__func__));
}

void call_f622(void)
{
  float r = f622(547184949249757999, 5941739354517701838, -5346372466948576782, -1539047160, "l", "bb", -0x1.59c7b9260bd78p+4, -0x1.3c636b3ca41cbp+4, -1977108359, 0x1.351ff6703987ap+5, 6171762307607568305, "ph", "ao");
  ((r == 0x1.dcb4fcp+4F) ? (void)0 : failure("r == 0x1.dcb4fcp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3315,__func__));
}

void call_f623(void)
{
  signed char r = f623(0x1.0634c9cd0e7cep+5, 0x1.1e0869500c9fp+4, -3501619966134180474, 7271432008532077239, 1134273527, "z", "m", 5694669144119031793, -1993727952, -0x1.5e2933134a9e7p+5, -556108535, 1515181104527854772, -1930930757, -2106393457, -1513321562193627998, -1412480631);
  ((r == 17) ? (void)0 : failure("r == 17","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3321,__func__));
}

void call_f624(void)
{
  char * r = f624(-747559199, 0x1.6d19f2dff3c86p+5, -0x1.0c6477a268d9dp+5, -0x1.a1789deeee0ep+2, "xy", 273657478, 0x1.9e25d90444d64p+3, -589062463, 7759781279018340227, 301407843, -0x1.2a977fbcf6f4cp+4, -0x1.af307530058cp+0, 0x1.55d44b954553p+2);
  ((strcmp(r, "hc") == 0) ? (void)0 : failure("strcmp(r, \"hc\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3327,__func__));
}

void call_f625(void)
{
  f625(-5043579740373115186, -765739729, "if", 0x1.553ed4c812c66p+5, -1450743264, "", "ic", 1528894666, -4295331302826968663, "z", -0x1.bfbe16ad9ecep+3, -1266232048);
}

void call_f626(void)
{
  f626(-1344926246, -421183147830527406, 0x1.2ff8c7a8a949p+1, -0x1.534ad0a09b402p+4, 8099629238747404336, 0x1.868fd5cdfe3fp+3, -503133587, 1249838987, "io", 1082079563, -3918770263459058100, 1581668471, "t");
}

void call_f627(void)
{
  int r = f627();
  ((r == -1829867664) ? (void)0 : failure("r == -1829867664","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3343,__func__));
}

void call_f628(void)
{
  f628("oc", -9217538561892391980, 0x1.f3c0bcfd31bbp+3, -7946251573754236074, -0x1.343c7b71319dap+5, 1353035069, 7287745300589057960, -0x1.1e08cf0ff599cp+5, 1732066304, 0x1.f8cebf84eacf8p+4, 0x1.dabce41a4d2bp+3);
}

void call_f629(void)
{
  char * r = f629(146502663118481574, 0x1.0c9c62bc5ba9p+4, 3815575656811470531, "u", 1679663445, -1395487532524630300, -0x1.576aae1a91839p+5, -1859589493);
  ((strcmp(r, "v") == 0) ? (void)0 : failure("strcmp(r, \"v\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3354,__func__));
}

void call_f630(void)
{
  f630(6569183602416844708, 0x1.48e7bf88427dp+5, -0x1.8cdb4f9ec7c84p+5, "e", 824291211, -0x1.8901bf59d7799p+5, -0x1.2bb3ab3864bf5p+5, 0x1.5591d24042992p+5);
}

void call_f631(void)
{
  f631(-0x1.e89f1479d49c8p+2, -1495663381, 1656171470, -0x1.ea4cbd31d2fp+0, -0x1.1f8eabaf295d8p+4, "", 465606698, -0x1.2b48b1aefaf79p+4, "kk");
}

void call_f632(void)
{
  unsigned char r = f632(-0x1.2fd2937adda12p+4, -588463664444324021, -0x1.1e0a74b5dbd8p+4, -7207797486385991930, 0x1.12fc6498e4e5p+2, "", "", "", 6330759665922262785, "", -0x1.34374367fb95dp+4, -0x1.667e8e7d42e5p+5, 7384386207144349506);
  ((r == 14) ? (void)0 : failure("r == 14","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3370,__func__));
}

void call_f633(void)
{
  f633("cp", -0x1.eaca4f627a48p+3, -0x1.a4b537cdd543ap+4, 1026451162850323114, "es", -0x1.15a163a71e64p-1, 1601993968, -116524704, 8552210943544301086, -85623240, 840736215, -1068888202, 3992442782739677467, -8703215556391474645, "u", -1350219812, -0x1.a8c3f074e2382p+4);
}

void call_f634(void)
{
  f634(3798273438506068514, "eg", "j", -0x1.2cc34f8b6bc78p+4, "", "cy", "", 1137340383, 3387893095306772005, -6669120512685267456);
}

void call_f635(void)
{
  f635(-1088547301, -1258498568, 0x1.a60cbf7103b4cp+4);
}

void call_f636(void)
{
  float r = f636("r", 79782339, 0x1.36cac787da13cp+5, 8919041018464589865, 1155136068, -0x1.11de9e15ba0d8p+5, -1299285610, "tn", -6138261563589878042, -886630806, -0x1.1d6c0b0eed3cp+5, -1526803768, -7887639675954083565, -0x1.812699851687fp+5, 0x1.d7ea328ceda18p+4, -0x1.b2564c530c42dp+4);
  ((r == -0x1.6d2338p+4F) ? (void)0 : failure("r == -0x1.6d2338p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3391,__func__));
}

void call_f637(void)
{
  f637("y", -816329033, -3741695569855730315, 2206563217582123786, "", -0x1.83460f9add948p+2, 2027963869, -0x1.214a8d68e528ap+5, "xy", 0x1.a986265808eep+4, -2306280156297823933, 0x1.21e59905a3d2p+3, "rt", -0x1.50d8aa9e3486p+2, -1787510018, "qt");
}

void call_f638(void)
{
  unsigned short r = f638(-0x1.6bfc87bceb908p+5, 349380893780640591, 2714783807000847261, 2117421366, 0x1.5d85bb0dd81p-1, -0x1.96eb21aa81ddfp+4);
  ((r == 56498) ? (void)0 : failure("r == 56498","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3402,__func__));
}

void call_f639(void)
{
  f639(-1187953195, -1949769754, -1892650183612110446, 3496299691700584099, 1771475272, 0x1.2d4475201a99p+3, -822598276, "b", 0x1.326d98f0058ecp+5, "", 0x1.2a6a28a846bbap+5, "", "rp", 0x1.2361f15bea8a4p+5, "mb");
}

void call_f640(void)
{
  f640(0x1.94167d62c0fap+3, "y", 0x1.394e609880ebcp+5, -1587915109, -1088998360, -0x1.620e803e1568ep+5, "z", -0x1.8a7638c8147fdp+5, "wv", "xo", -2937526815564948103, 2600044501742680935);
}

void call_f641(void)
{
  int r = f641("", -0x1.1b7c460f5cfb4p+4, 0x1.eb1033304e72p+2, 4912913164045855025, 0x1.727e324a65208p+4);
  ((r == 903768430) ? (void)0 : failure("r == 903768430","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3418,__func__));
}

void call_f642(void)
{
  f642(-1365273179, "", 0x1.0d6b3f2ba8406p+5, 0x1.1a0ea599d3538p+5, -0x1.16ca826fff503p+5);
}

void call_f643(void)
{
  long long r = f643(-0x1.25e3f779c6149p+4, 581861176, -683934681, -0x1.d724f7c622b78p+4, 0x1.93a7575589bcp+4, -2506328392131763210, 3507097896546837780, "n", 2068784971, -0x1.0adae9998db44p+5, "", -0x1.4684769b6c3e3p+4, 0x1.5d09b8eafa48ap+5, -4590071897467501932, -990144499, "", "", "k", 0x1.33a669027e3eep+5, 2082035264);
  ((r == -218982151881425774) ? (void)0 : failure("r == -218982151881425774","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3429,__func__));
}

void call_f644(void)
{
  f644(0x1.5d6c7c5df49ep+0, -0x1.e8df17901f5cfp+4, -0x1.3e72d84ee83d2p+5, 437621942423595983, "z", -5512698382316777594, -6455415996889137058, 1033505905, -0x1.dbaabe4870ap+3, 50425697929873964, "", "go", -1008554134638755647, 6913706153578024595, -258699417, 5514889292004705570, -1229601298);
}

void call_f645(void)
{
  float r = f645(2064578907, "", -0x1.00a621279c9b2p+4, "rv", -5622966164531639756, 0x1.dbdd67e18697p+4, -0x1.571af7136b6d7p+4, 2518812247611033146, -1044637563);
  ((r == -0x1.f636dcp+4F) ? (void)0 : failure("r == -0x1.f636dcp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3440,__func__));
}

void call_f646(void)
{
  f646("s", "oo", 0x1.411be11cf573cp+4, -0x1.f0f8fe23c6624p+4);
}

void call_f647(void)
{
  f647(0x1.af3032c2289fp+4, 0x1.f6668327e83a4p+4, 0x1.3c18ce556da24p+5, -3185181259585629561, "", "fj", 0x1.59c279d775aa4p+5, 0x1.43dc1f708306p+3);
}

void call_f648(void)
{
  float r = f648(0x1.11f86b7ce889p+5, -1781855986, 0x1.75e512711812p+3, -1323056392180592835, -5878885792793727526, 0x1.7b95dc7b3854p+4, -0x1.4f0c1995d8e19p+4, 1795264236, 1165422760, 5327301867136099849, "", 277219865, -0x1.1815877187afp+1, "", "", -1111465773, 1823669135);
  ((r == 0x1.330f68p+4F) ? (void)0 : failure("r == 0x1.330f68p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3456,__func__));
}

void call_f649(void)
{
  char * r = f649(-1697727152, -0x1.d2d01f8362adp+4, -0x1.0969589128b04p+5, "ky", -1311675918054309991, 5553966877889997251, 1733836014, -587926258, -0x1.7220d4eef37c8p+3);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3462,__func__));
}

void call_f650(void)
{
  f650(-2682452516823688473, 0x1.5afa0011406fp+2, -0x1.17679c357ecb6p+4, 3147568539306732941, -0x1.66f8dd703bf55p+5, 0x1.78679eb4611fep+5, "d", "", -0x1.98a03b38cdaefp+4, 0x1.30517bde86e4p+5, 8361950544101958725, 2008067230);
}

void call_f651(void)
{
  unsigned char r = f651(-1492856601456366813, 3210379746510596745, 1464362373363724668, "qb", 0x1.427a81ca2acap+5, -0x1.302570219f828p+5, 6737368438786276128, -0x1.93abadc78fa2p+3);
  ((r == 13) ? (void)0 : failure("r == 13","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3473,__func__));
}

void call_f652(void)
{
  unsigned short r = f652("ko", 0x1.729808a4ab02p+4, "l", -124251942, -2600490318683432363, "v", "k", 2906665546869162569);
  ((r == 47053) ? (void)0 : failure("r == 47053","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3479,__func__));
}

void call_f653(void)
{
  f653(2006996479, 0x1.45ad8d1e7dab8p+3, -2342502688323166835, -5530637500125412312, -4303803848588391412, 0x1.525c42167573p+4, -0x1.28435be8753bdp+5, 0x1.ef0f38777a76p+0, -0x1.1d56224ab6cd2p+4);
}

void call_f654(void)
{
  f654(-276065562, -4896889940483283061, -0x1.163fb3d9be854p+4, 0x1.884fcb2ff88bcp+3, "", 0x1.0a7b760b5c9ecp+3, -2100760464, "y", "j");
}

void call_f655(void)
{
  f655("cp", -0x1.3a8a19b40f114p+3, 1899544549, -0x1.2dd0b025fbdc8p+5, -102069440, 0x1.1e3f1cc561d6ep+5, 0x1.416db433ac3a4p+5, -1412494041, -1296389917, 5117189682248027843, -0x1.64d36b8a3054ap+5);
}

void call_f656(void)
{
  signed char r = f656(0x1.4361dfdc9fdeap+5, "c", 889766650, 1429314100, "a", 14167378, -593463160, -736664145385048193, 0x1.23cd903303c98p+3, -4591006240404468919, "", "", "d", 0x1.380286b501a02p+5, 101126630960372363, "", "", -8163784675802707061);
  ((r == -53) ? (void)0 : failure("r == -53","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3500,__func__));
}

void call_f657(void)
{
  double r = f657("oi", "fc", -0x1.0f1c567517364p+4, 0x1.73c317e7933a2p+5, 848237124, -3217992989939229884, 1030265678, -226777007, 8253346827661922013, "", -0x1.28fbd7d923654p+5, 0x1.83a4bbb2a6d9p+4, -5758475476294075987);
  ((r == -0x1.c2f761250de46p+4) ? (void)0 : failure("r == -0x1.c2f761250de46p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3506,__func__));
}

void call_f658(void)
{
  double r = f658("zd", "jo", -0x1.88a363c887a47p+5, "nr", 0x1.03776b753f0fcp+3, 0x1.579c055988744p+4, "iz", 0x1.e6b8a6d91120cp+4, "", "u", 1505321931077810488, 551752351, "c", 8792873102080589895, 0x1.e0009759af978p+2, 1382010072, 0x1.12565e4b72908p+3);
  ((r == 0x1.65c22c235fb7ep+5) ? (void)0 : failure("r == 0x1.65c22c235fb7ep+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3512,__func__));
}

void call_f659(void)
{
  f659(-875364434, 0x1.d976cd61d92cp+3, 97528049, 183702950, "ru", -1792857550, "s", 303048718, -9186190290389128614, "ft", 0x1.eae07e2383b08p+4, -566164750394717669);
}

void call_f660(void)
{
  int r = f660();
  ((r == 474177692) ? (void)0 : failure("r == 474177692","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3523,__func__));
}

void call_f661(void)
{
  float r = f661(-0x1.f0bf2d307cafp+2, "n", 0x1.17b84136b0e34p+3, 1757670968, -0x1.9485d1cee93d9p+4, 3553239126551381398, -7468601704491466311, 196012669, -6769402016187374936, 905688913, -8511177467490139296, -0x1.dc84d926f03acp+3, 859723451, -7844150188543847404, -3645694689356736980, -1895999461, -0x1.58b64efe89a52p+4);
  ((r == -0x1.f7b4aep+4F) ? (void)0 : failure("r == -0x1.f7b4aep+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3529,__func__));
}

void call_f662(void)
{
  f662("y", 0x1.6d334a08117d8p+4, 2356876561578874312, "hd", 847177987, -0x1.7012d09588ab6p+5, -1364835889, 1564735355421946155, -2138843807, "", "", -0x1.2bf1612d62bd3p+5, "", "", 0x1.1293cf79b1724p+4, -1404737936, 0x1.10c936b5c97cp+5, -0x1.d39c431b4d552p+4);
}

void call_f663(void)
{
  f663(-1128002351, -5831744838140581097, -0x1.250b3d52d3738p+3, -0x1.26701f6e8f7a5p+4, "q", 625964783, 0x1.190af24e5d758p+4, -754499637, 6942457409606774668, 0x1.63e66b48826c8p+5, 6427110086082022795, "");
}

void call_f664(void)
{
  int r = f664("", 1973853702, 705914605, "y", -0x1.db031537e956cp+3, -8395727873903635112, -792608242, "k", 0x1.1a88dc467f6f2p+5, "", -2759664866527831115, -1416104276, "vm", -1061751221, -1108137346, "zr");
  ((r == 1833979080) ? (void)0 : failure("r == 1833979080","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3545,__func__));
}

void call_f665(void)
{
  short r = f665("sb", "jb", -0x1.15e757a696798p+3, -0x1.72da0fd42f86dp+5, -0x1.4908da6efa868p+2, -0x1.396b14414b462p+5, "hg", 7731655530350973607, -0x1.e2a135fd988d7p+4, -2610305730455693136, 0x1.13888713f13b4p+4, 42326595271206464, 5045907935158101578, "zo", "", -0x1.63a28a07ab71p+2, 0x1.09e8427f0245cp+5, -0x1.3b623710bcedp+2, -552853342);
  ((r == 21867) ? (void)0 : failure("r == 21867","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3551,__func__));
}

void call_f666(void)
{
  int r = f666(920580807, -3173914579294635642);
  ((r == -1516187776) ? (void)0 : failure("r == -1516187776","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3557,__func__));
}

void call_f667(void)
{
  f667(0x1.069dbea7f5f68p+5, 0x1.66cc90694417cp+5, 0x1.ddb94640ffbf8p+4, -0x1.248dfa5187b4ep+5, "c", 0x1.0049cf2edd218p+2, 0x1.8bd349f612304p+3, -0x1.4586f2d56d55cp+5, 775218595, "u", 3493322490663154879);
}

void call_f668(void)
{
  float r = f668(-0x1.4e088cb63fd4fp+5, -0x1.14ded6ae1eab8p+3, -1903451904, 0x1.20e797638dfa4p+5, "ud", -857629265, "", 3254611156257424803, -1525015089, 0x1.0770cee9980bp+2, -2102488012, "j", "", 545842080);
  ((r == -0x1.76e9e6p+5F) ? (void)0 : failure("r == -0x1.76e9e6p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3568,__func__));
}

void call_f669(void)
{
  short r = f669(1609144253, 1153169113682578948, 0x1.822ab3babc988p+2, "dg", 1130061744682193977, 0x1.7edbe66ae956p+2, 0x1.5177677763786p+5, -0x1.823111ce93803p+4, -0x1.9af0d96f3c226p+4);
  ((r == -16014) ? (void)0 : failure("r == -16014","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3574,__func__));
}

void call_f670(void)
{
  long long r = f670(-0x1.ae20028589dd8p+3, -0x1.913a0d01d45e9p+4, 0x1.18313a48dd42p+4);
  ((r == -6959248285087389708) ? (void)0 : failure("r == -6959248285087389708","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3580,__func__));
}

void call_f671(void)
{
  float r = f671("f", -0x1.4df19e00ebefp+5, 3818253661908911851, 0x1.767fa8a3980ap+2, "c", -0x1.b7a0282133114p+3, 1190479578, -9045853469000302919, "s", "", 0x1.3986b3158525cp+5, "j", 852094260, 848012779, "c", 2079361764, -38601674, 663004539, 1053834206880342394);
  ((r == 0x1.409718p+5F) ? (void)0 : failure("r == 0x1.409718p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3586,__func__));
}

void call_f672(void)
{
  f672();
}

void call_f673(void)
{
  long long r = f673(0x1.3e35c4ef224a8p+5, -0x1.968ee7c00d944p+3, 8433498826289563926, "", 242319173, -5506388642912533925, -0x1.e2d0237e1315dp+4, -1648442553969680669, "q", -0x1.503f98a4d51dbp+5, 1417664714775283816);
  ((r == 3913619852902404880) ? (void)0 : failure("r == 3913619852902404880","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3597,__func__));
}

void call_f674(void)
{
  short r = f674(-0x1.3c3774b08aabp+5, -0x1.d84a2c7a95b08p+3, "", 933152245, 1012200319, "l");
  ((r == -3491) ? (void)0 : failure("r == -3491","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3603,__func__));
}

void call_f675(void)
{
  long long r = f675(-520863509, 1630487220, "", 0x1.667d30f45215p+4, 0x1.309384fe87e5p+5, 0x1.0759676fbec7p+2, 0x1.e9b43902d6a7p+4, -881514322, "p", "", 4714083201215846726, "", -1024778529, 1217228234);
  ((r == -682023577706211229) ? (void)0 : failure("r == -682023577706211229","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3609,__func__));
}

void call_f676(void)
{
  double r = f676("", -0x1.812157207c48p+3, -2278986424629807488, 0x1.cb2d94554375cp+4, 0x1.0d3d19bafa474p+3, -0x1.793cc52731dbp+2, "i", 0x1.db54229a29c6p+3, 0x1.558f077a54126p+5);
  ((r == -0x1.69a56c7a5a9acp+4) ? (void)0 : failure("r == -0x1.69a56c7a5a9acp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3615,__func__));
}

void call_f677(void)
{
  f677(0x1.706d142d94c9cp+4, 2025826491, -0x1.67b6a8abe3557p+4, -0x1.64cd624313571p+4, 2030656516, "oo", "aq", -0x1.360104de5fa3p+5, 1930303152, "", -8009807674419147213, 2017130798119899133, 0x1.16155b8bd439p+1, "n", "", -0x1.75aa124ef270bp+5, "", "", -3311010493127433547);
}

void call_f678(void)
{
  short r = f678("js", -3805939337381161460, 0x1.12b276706874cp+3, 2220111173955058815, 1955584158, 0x1.2de182341a578p+4, 1266974008, 0x1.355f59900cb54p+3);
  ((r == 2971) ? (void)0 : failure("r == 2971","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3626,__func__));
}

void call_f679(void)
{
  f679(2059911633, 0x1.55bdec45977fp+5, 0x1.363a01995b6fep+5, -0x1.c5fd7c325044cp+4, 2158515337712687738, -0x1.3c5dd49e9d062p+5, "sb", 0x1.7721f264684c4p+3, -1496893898, 8616908048078776375, 0x1.0296c5a07c088p+5, "z", 1530608568, "");
}

void call_f680(void)
{
  f680();
}

void call_f681(void)
{
  int r = f681(1732213699, 1545166901, -2015578578, 0x1.656fcf669bap+4, "n", "", -8885769528345554289, "", 890883522288784557, -1100987316, 0x1.a7f1888b2fbap+0, "gw", 1963532801);
  ((r == -806284336) ? (void)0 : failure("r == -806284336","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3642,__func__));
}

void call_f682(void)
{
  f682(-2836230558094006280, 0x1.62a41069d2404p+4, 0x1.f6248d77a2e24p+4, 0x1.1f403bd7d5754p+3, -0x1.6b01f5d072eccp+5, 55888541, 1386459273026800978, 0x1.6ddde521f7274p+4, -0x1.2ed54f3e00752p+5, -84358091667469811, "q");
}

void call_f683(void)
{
  unsigned short r = f683("", 1675396916365188636, "v", -0x1.6226580c75e78p+3, -0x1.f8f4beb50823cp+3, -612709851, -2106492062, 1419738696, 0x1.3d05b9fa65828p+5, 0x1.c091f1317b98p-2);
  ((r == 1834) ? (void)0 : failure("r == 1834","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3653,__func__));
}

void call_f684(void)
{
  signed char r = f684(-0x1.26252f5709c8bp+4, 738329358, -0x1.0fbb94d006ad4p+5, -0x1.de6ea22bd26dcp+3, -661358659782600706, 0x1.78abea809d59p+2, "n", 1131696978, "d", -1496134647, 0x1.003a2b7fa1112p+5, 6501746381738153343);
  ((r == 59) ? (void)0 : failure("r == 59","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3659,__func__));
}

void call_f685(void)
{
  f685(-0x1.79a5b97d1bf73p+5, "h", -3140362815423910069, 0x1.56f6d1bdd3d4p+3, 0x1.190ef62e63018p+4, 0x1.c3afc842c2b24p+4, -0x1.68f07340047f8p+2);
}

void call_f686(void)
{
  f686();
}

void call_f687(void)
{
  f687("pq", -1627631899, "g", 0x1.8817b0a6c114cp+5);
}

void call_f688(void)
{
  f688();
}

void call_f689(void)
{
  signed char r = f689(6367016584592931901, -1689355882, "", -0x1.6f8a7eed655e9p+5, 0x1.93854ebb02298p+4, 0x1.056beeab1c49p+4, 1633533153470720632, 0x1.1f9b23d13056p+5, -1609503591, 0x1.43597d3f2cdd4p+5, "co", 973602969520741354, 1043328895423696761, 0x1.0eb04233c8428p+3, -0x1.160d0c3fd83f1p+5, -6172222920797026190, "", "", -9022912784743794387, 0x1.4ebc0a93560d4p+3);
  ((r == 27) ? (void)0 : failure("r == 27","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3685,__func__));
}

void call_f690(void)
{
  char * r = f690(-3750900501354088184, -1576281349, -1697988757, 2038851159846018016, 0x1.17797f571f8p+1, -0x1.b898790ed47b8p+3, -0x1.fdb2da22cd79cp+3, -0x1.ffe71400fc8e1p+4, -0x1.c0f78e3433138p+4, 1933489868, -1666213284, -9036964026481189336, 1421136308, -709259359, "e", -0x1.0a1a796422928p+5, -14291841, 0x1.42e4a8c96b8a8p+5, 0x1.277e1ad78d6e4p+5);
  ((strcmp(r, "tk") == 0) ? (void)0 : failure("strcmp(r, \"tk\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3691,__func__));
}

void call_f691(void)
{
  long long r = f691(-7442204861738462214, "", 7528309936253066000, 0x1.e13c083a62ec8p+3, 0x1.c3649d76dbb54p+4, 6758695546646999538, -16687990, 0x1.47b5837880c4p+1, 4210117645755700783, 0x1.c67180802818p+2, 1964792412, 0x1.2349b59a95748p+5, 4977338945267546701, "gy", "ur", "", 1707759517, "w", "kq", 0x1.16f2a58377b8p+1, -3135265790968006712);
  ((r == 3051136623865764158) ? (void)0 : failure("r == 3051136623865764158","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3697,__func__));
}

void call_f692(void)
{
  f692(-2064448899, -3058825207710041941, "cy", "f", 862600121, 682843603940626958, "", -1723318956502309032, -5861788712640166613, -0x1.eff3f44ac744p+4);
}

void call_f693(void)
{
  f693();
}

void call_f694(void)
{
  f694("l", "", 880333893, -0x1.1d6d89a782d42p+5, -1327741968292242621, "", 0x1.8b7611d8ba972p+5, "em", 8204550104807411134, -291356861, -1981861892);
}

void call_f695(void)
{
  unsigned short r = f695(-5300664604302227697, -0x1.8209169bba2afp+4, "o", "va", 0x1.56c6dc9f0942p+5, -3551388045920458891, "b", 1577587036, -1790503741, "m", -5297153997977870730, "u", "wn", -0x1.2727170f0aa8p+5, -381008049, -139024982);
  ((r == 22157) ? (void)0 : failure("r == 22157","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3718,__func__));
}

void call_f696(void)
{
  f696("", 2495811398441534509, "", "u", -4570585142567549395, "qb", 1309514874, -0x1.88d3e71660bbp+2, 0x1.31b2bfdedc476p+5, -204122122, 0x1.3b65a97c303ecp+4, -2084753124, 1642009557, "", 0x1.141b7772bc48ep+5, "g", -0x1.542c942fb1d17p+5, 0x1.0f6e64d6227dp+3, 725564924);
}

void call_f697(void)
{
  unsigned char r = f697("g", 1946893453, -559523310121702532, -0x1.15dc454503154p+4, "ba", -0x1.037f3e0f00593p+5, 377112244389569770, 0x1.2bf7b1aaddcd2p+5, "vw", 0x1.2c9fce8ca2bbp+4, 733276130, 0x1.839291f73c858p+4, -1524859481, 2039280883253698794, 0x1.5ca11a96c1b3p+2);
  ((r == 200) ? (void)0 : failure("r == 200","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3729,__func__));
}

void call_f698(void)
{
  f698("l", -0x1.5f13f7ec26578p+2, "zx", 0x1.73855e89e794p+4, 0x1.1b461ecbf156ep+5, "rr", 0x1.a61759183adbp+2, -6981952327172804064, -0x1.3456dac0fa01p+1, 1964686500670336744);
}

void call_f699(void)
{
  char * r = f699(-4484989185756434957, 0x1.03271c3ebd288p+4, 0x1.85836e21957e6p+5, -0x1.6b6d74a0ac625p+5, -0x1.d4e72733c892dp+4, 2102876187, -0x1.6b998919b5fc4p+3, 961358198, -386745656, 7181354233035117320, -0x1.6819c3668f37fp+4);
  ((strcmp(r, "gr") == 0) ? (void)0 : failure("strcmp(r, \"gr\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3740,__func__));
}

void call_f700(void)
{
  signed char r = f700("", -0x1.76f5235d7c7a9p+4, -0x1.32452ab6198cp+3, -2459085891581484819, 1807275214, -0x1.751da7955f9cp-1, -0x1.eee3ebeedd1dp+1, 0x1.d6802ac0cbd4cp+4, -889719577, -0x1.2f22060d193c5p+5, 1070089972, -382796327, 0x1.79d8b1c9848dcp+4, -0x1.69611dcb66a13p+4, 2145204948, -49637352, "p");
  ((r == -124) ? (void)0 : failure("r == -124","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3746,__func__));
}

void call_f701(void)
{
  float r = f701("qh", 536526275, -0x1.24f3657d7f504p+3, -870089933, -0x1.a97c4c2a57bd4p+3);
  ((r == -0x1.8dfc58p+5F) ? (void)0 : failure("r == -0x1.8dfc58p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3752,__func__));
}

void call_f702(void)
{
  f702(-0x1.72786789c47bdp+4, 0x1.274ae290b81e2p+5, "fq", 4638354944769506192, -918471340, -0x1.cf50a7e54346p+1, 391822947, 0x1.6d081523d5234p+5, 0x1.8fbf79ebeae82p+5, 0x1.59852ab52c65p+5);
}

void call_f703(void)
{
  f703(-0x1.3d5bd1cb3bcdep+5, 0x1.8424dc25660d4p+4, -0x1.dd44fe45c972p+1, 7835436811188437354, 0x1.fedd960071c3p+3, 1525250532, -1303953130, -427497845, -0x1.778087c141bacp+5, -0x1.cfee2bc652de3p+4, 1525129954, -4732772884075157065, "ny", -225945003, 1184322853, -1423255312, -2061209602);
}

void call_f704(void)
{
  short r = f704(-930195258, "", "xo", -6530266032080582828, 1514799402, -0x1.84cc2a857a90ap+4, -505806579, 6360264925827467512, 1646764990, "a", 1873465129, 7607821824489512407, "rt", -4912495514248060641, -10090495);
  ((r == 32365) ? (void)0 : failure("r == 32365","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3768,__func__));
}

void call_f705(void)
{
  f705(-7401032677358378648, -0x1.3c610b0076a3ap+5, 0x1.2651eaf314b9ep+5, -0x1.83937a0c5bc57p+5);
}

void call_f706(void)
{
  unsigned short r = f706(-0x1.11bba3cf2d308p+3, -678978009, -904477038191105343, -0x1.0fe972863d318p+4, "r", -1173630298, -1269452061, 0x1.2d46a1b2cbe38p+3, -4993312352704182924, 0x1.426dbec95364ep+5, 1954297985, 811102318, -400772448744947459, 1754981564, "hk", -372770022, 1430613552);
  ((r == 44776) ? (void)0 : failure("r == 44776","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3779,__func__));
}

void call_f707(void)
{
  f707("", 0x1.574fb5282ad32p+5, "", -0x1.498d8a3a2b8dcp+5, 1256123682, -0x1.7ff843c5e6468p+5, "h");
}

void call_f708(void)
{
  unsigned short r = f708(8855239887090695481, 7581219621979276725, -0x1.00800e35d8f9p+2, "rk", 8828917983308899398, -8124030964293730888, -1685211800034789018, -4935141429391310898, -0x1.4060c17c450acp+5, -73538952, -1039545829);
  ((r == 22955) ? (void)0 : failure("r == 22955","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3790,__func__));
}

void call_f709(void)
{
  f709(6014465501601863499, 0x1.58d3825e8535ep+5, 0x1.3d87e0f57aa98p+4, 6845176419187105710, 0x1.5805fe8a0f554p+3, 3309687262534505698, -0x1.4a4ed89bf43e4p+4, 65661957, -1284694857554390933, 7547413822156468334, -0x1.bd0f630cc1637p+4, 350409935, 4359162586439416569, -1361214722032881327, -554111631);
}

void call_f710(void)
{
  char * r = f710("", "", 0x1.5fb6014b71b88p+3, -0x1.38458dc42b32fp+5, 4908422009768745045, -0x1.5b984ac901d4fp+5, 1422511125041748284, "", 6754188163068925040, "fk", "n");
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3801,__func__));
}

void call_f711(void)
{
  f711(17776914, "q", 0x1.52ba948e84608p+5, -7689314548975836677, -0x1.6f477a4a2adabp+5, 286473971, -0x1.4ec17e930d9c7p+5, -1366357397949222732, -7230077827323117320, -1226429119, -0x1.9125be7a10efp+4, 1535745609, "s");
}

void call_f712(void)
{
  signed char r = f712(-0x1.518e01effe5f2p+5, 0x1.5a245ef1f5cd4p+4, -0x1.afa2f634e3ddcp+3, 6396970551448115493, -1443148615, -0x1.29e8a76e36d62p+5, 1198590045, -0x1.43fdc08dc7d9cp+3, -1789225121, 0x1.d367ff37b3e3p+3, -0x1.018255d695bfep+5, 1473371005, 1688430142, "w", -8901740783675604601, 8779848120204494513, -0x1.b63576755cd56p+4, -723890098, 1801803073481109447);
  ((r == -113) ? (void)0 : failure("r == -113","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3812,__func__));
}

void call_f713(void)
{
  float r = f713("j", -7804864611931326238, 1030860420, -363815033, 1699473626, -324611234, -0x1.d40d8a0d95038p+3);
  ((r == -0x1.72915cp+2F) ? (void)0 : failure("r == -0x1.72915cp+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3818,__func__));
}

void call_f714(void)
{
  f714(-0x1.549fc0af2c361p+5, "", -8598668267699225307, -6066755665501404374, 2126574980, 0x1.9f2e3ea4b6284p+4, "", "k", 1320724073, -1163915213, 331680728, -0x1.875832617daap+5, -1081894045607833815, "xm", "zi");
}

void call_f715(void)
{
  signed char r = f715(-0x1.658dff81b556ap+4, -0x1.793d09138466fp+4, "", -0x1.381884797ca3p+5, "v", 1524685348, -6734931617300810523, 874126211, 8190862678723229925, 4611748873698641410, "md");
  ((r == -55) ? (void)0 : failure("r == -55","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3829,__func__));
}

void call_f716(void)
{
  unsigned char r = f716(-2412224687332121186, -0x1.bf59b23e671ecp+4, "bn", 0x1.f28d36e745ba8p+4, "", 0x1.6b8b95f9aa2bcp+3, 7953983380489026108, -812757294);
  ((r == 157) ? (void)0 : failure("r == 157","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3835,__func__));
}

void call_f717(void)
{
  unsigned short r = f717("f", 1208974437, 0x1.196b32d19575ep+5, -0x1.fba331388bc5bp+4, -0x1.da2593c591da2p+4, -0x1.6f08c83d80ef6p+5, -0x1.d8009be4a79b4p+4, "", 1965762088698384909, -0x1.2fc1deda862e6p+5);
  ((r == 62585) ? (void)0 : failure("r == 62585","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3841,__func__));
}

void call_f718(void)
{
  f718(-425143655, "", 0x1.9134f1e5b3c8p+4, 0x1.bb69a14932464p+3, -6259729363396866658, "v", 3178345139128936672, 1867949463);
}

void call_f719(void)
{
  short r = f719();
  ((r == -15717) ? (void)0 : failure("r == -15717","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3852,__func__));
}

void call_f720(void)
{
  long long r = f720();
  ((r == -9164859480658306097) ? (void)0 : failure("r == -9164859480658306097","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3858,__func__));
}

void call_f721(void)
{
  f721(-7668166041995321423, 2623561741131440059, 1861166846, 0x1.96360dae9388p+4, 0x1.8456c3c74e538p+2, -0x1.0174e9e25e7p+0);
}

void call_f722(void)
{
  unsigned short r = f722(2536834788558919162, 0x1.277ec4084c1a4p+5);
  ((r == 39454) ? (void)0 : failure("r == 39454","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/vararg-native_to_gcc/lean/abi/vararg_use.c",3869,__func__));
}

int main(void)
{
  alarm(60);
  call_f1();
  call_f2();
  call_f3();
  call_f4();
  call_f5();
  call_f6();
  call_f7();
  call_f8();
  call_f9();
  call_f10();
  call_f11();
  call_f12();
  call_f13();
  call_f14();
  call_f15();
  call_f16();
  call_f17();
  call_f18();
  call_f19();
  call_f20();
  call_f21();
  call_f22();
  call_f23();
  call_f24();
  call_f25();
  call_f26();
  call_f27();
  call_f28();
  call_f29();
  call_f30();
  call_f31();
  call_f32();
  call_f33();
  call_f34();
  call_f35();
  call_f36();
  call_f37();
  call_f38();
  call_f39();
  call_f40();
  call_f41();
  call_f42();
  call_f43();
  call_f44();
  call_f45();
  call_f46();
  call_f47();
  call_f48();
  call_f49();
  call_f50();
  call_f51();
  call_f52();
  call_f53();
  call_f54();
  call_f55();
  call_f56();
  call_f57();
  call_f58();
  call_f59();
  call_f60();
  call_f61();
  call_f62();
  call_f63();
  call_f64();
  call_f65();
  call_f66();
  call_f67();
  call_f68();
  call_f69();
  call_f70();
  call_f71();
  call_f72();
  call_f73();
  call_f74();
  call_f75();
  call_f76();
  call_f77();
  call_f78();
  call_f79();
  call_f80();
  call_f81();
  call_f82();
  call_f83();
  call_f84();
  call_f85();
  call_f86();
  call_f87();
  call_f88();
  call_f89();
  call_f90();
  call_f91();
  call_f92();
  call_f93();
  call_f94();
  call_f95();
  call_f96();
  call_f97();
  call_f98();
  call_f99();
  call_f100();
  call_f101();
  call_f102();
  call_f103();
  call_f104();
  call_f105();
  call_f106();
  call_f107();
  call_f108();
  call_f109();
  call_f110();
  call_f111();
  call_f112();
  call_f113();
  call_f114();
  call_f115();
  call_f116();
  call_f117();
  call_f118();
  call_f119();
  call_f120();
  call_f121();
  call_f122();
  call_f123();
  call_f124();
  call_f125();
  call_f126();
  call_f127();
  call_f128();
  call_f129();
  call_f130();
  call_f131();
  call_f132();
  call_f133();
  call_f134();
  call_f135();
  call_f136();
  call_f137();
  call_f138();
  call_f139();
  call_f140();
  call_f141();
  call_f142();
  call_f143();
  call_f144();
  call_f145();
  call_f146();
  call_f147();
  call_f148();
  call_f149();
  call_f150();
  call_f151();
  call_f152();
  call_f153();
  call_f154();
  call_f155();
  call_f156();
  call_f157();
  call_f158();
  call_f159();
  call_f160();
  call_f161();
  call_f162();
  call_f163();
  call_f164();
  call_f165();
  call_f166();
  call_f167();
  call_f168();
  call_f169();
  call_f170();
  call_f171();
  call_f172();
  call_f173();
  call_f174();
  call_f175();
  call_f176();
  call_f177();
  call_f178();
  call_f179();
  call_f180();
  call_f181();
  call_f182();
  call_f183();
  call_f184();
  call_f185();
  call_f186();
  call_f187();
  call_f188();
  call_f189();
  call_f190();
  call_f191();
  call_f192();
  call_f193();
  call_f194();
  call_f195();
  call_f196();
  call_f197();
  call_f198();
  call_f199();
  call_f200();
  call_f201();
  call_f202();
  call_f203();
  call_f204();
  call_f205();
  call_f206();
  call_f207();
  call_f208();
  call_f209();
  call_f210();
  call_f211();
  call_f212();
  call_f213();
  call_f214();
  call_f215();
  call_f216();
  call_f217();
  call_f218();
  call_f219();
  call_f220();
  call_f221();
  call_f222();
  call_f223();
  call_f224();
  call_f225();
  call_f226();
  call_f227();
  call_f228();
  call_f229();
  call_f230();
  call_f231();
  call_f232();
  call_f233();
  call_f234();
  call_f235();
  call_f236();
  call_f237();
  call_f238();
  call_f239();
  call_f240();
  call_f241();
  call_f242();
  call_f243();
  call_f244();
  call_f245();
  call_f246();
  call_f247();
  call_f248();
  call_f249();
  call_f250();
  call_f251();
  call_f252();
  call_f253();
  call_f254();
  call_f255();
  call_f256();
  call_f257();
  call_f258();
  call_f259();
  call_f260();
  call_f261();
  call_f262();
  call_f263();
  call_f264();
  call_f265();
  call_f266();
  call_f267();
  call_f268();
  call_f269();
  call_f270();
  call_f271();
  call_f272();
  call_f273();
  call_f274();
  call_f275();
  call_f276();
  call_f277();
  call_f278();
  call_f279();
  call_f280();
  call_f281();
  call_f282();
  call_f283();
  call_f284();
  call_f285();
  call_f286();
  call_f287();
  call_f288();
  call_f289();
  call_f290();
  call_f291();
  call_f292();
  call_f293();
  call_f294();
  call_f295();
  call_f296();
  call_f297();
  call_f298();
  call_f299();
  call_f300();
  call_f301();
  call_f302();
  call_f303();
  call_f304();
  call_f305();
  call_f306();
  call_f307();
  call_f308();
  call_f309();
  call_f310();
  call_f311();
  call_f312();
  call_f313();
  call_f314();
  call_f315();
  call_f316();
  call_f317();
  call_f318();
  call_f319();
  call_f320();
  call_f321();
  call_f322();
  call_f323();
  call_f324();
  call_f325();
  call_f326();
  call_f327();
  call_f328();
  call_f329();
  call_f330();
  call_f331();
  call_f332();
  call_f333();
  call_f334();
  call_f335();
  call_f336();
  call_f337();
  call_f338();
  call_f339();
  call_f340();
  call_f341();
  call_f342();
  call_f343();
  call_f344();
  call_f345();
  call_f346();
  call_f347();
  call_f348();
  call_f349();
  call_f350();
  call_f351();
  call_f352();
  call_f353();
  call_f354();
  call_f355();
  call_f356();
  call_f357();
  call_f358();
  call_f359();
  call_f360();
  call_f361();
  call_f362();
  call_f363();
  call_f364();
  call_f365();
  call_f366();
  call_f367();
  call_f368();
  call_f369();
  call_f370();
  call_f371();
  call_f372();
  call_f373();
  call_f374();
  call_f375();
  call_f376();
  call_f377();
  call_f378();
  call_f379();
  call_f380();
  call_f381();
  call_f382();
  call_f383();
  call_f384();
  call_f385();
  call_f386();
  call_f387();
  call_f388();
  call_f389();
  call_f390();
  call_f391();
  call_f392();
  call_f393();
  call_f394();
  call_f395();
  call_f396();
  call_f397();
  call_f398();
  call_f399();
  call_f400();
  call_f401();
  call_f402();
  call_f403();
  call_f404();
  call_f405();
  call_f406();
  call_f407();
  call_f408();
  call_f409();
  call_f410();
  call_f411();
  call_f412();
  call_f413();
  call_f414();
  call_f415();
  call_f416();
  call_f417();
  call_f418();
  call_f419();
  call_f420();
  call_f421();
  call_f422();
  call_f423();
  call_f424();
  call_f425();
  call_f426();
  call_f427();
  call_f428();
  call_f429();
  call_f430();
  call_f431();
  call_f432();
  call_f433();
  call_f434();
  call_f435();
  call_f436();
  call_f437();
  call_f438();
  call_f439();
  call_f440();
  call_f441();
  call_f442();
  call_f443();
  call_f444();
  call_f445();
  call_f446();
  call_f447();
  call_f448();
  call_f449();
  call_f450();
  call_f451();
  call_f452();
  call_f453();
  call_f454();
  call_f455();
  call_f456();
  call_f457();
  call_f458();
  call_f459();
  call_f460();
  call_f461();
  call_f462();
  call_f463();
  call_f464();
  call_f465();
  call_f466();
  call_f467();
  call_f468();
  call_f469();
  call_f470();
  call_f471();
  call_f472();
  call_f473();
  call_f474();
  call_f475();
  call_f476();
  call_f477();
  call_f478();
  call_f479();
  call_f480();
  call_f481();
  call_f482();
  call_f483();
  call_f484();
  call_f485();
  call_f486();
  call_f487();
  call_f488();
  call_f489();
  call_f490();
  call_f491();
  call_f492();
  call_f493();
  call_f494();
  call_f495();
  call_f496();
  call_f497();
  call_f498();
  call_f499();
  call_f500();
  call_f501();
  call_f502();
  call_f503();
  call_f504();
  call_f505();
  call_f506();
  call_f507();
  call_f508();
  call_f509();
  call_f510();
  call_f511();
  call_f512();
  call_f513();
  call_f514();
  call_f515();
  call_f516();
  call_f517();
  call_f518();
  call_f519();
  call_f520();
  call_f521();
  call_f522();
  call_f523();
  call_f524();
  call_f525();
  call_f526();
  call_f527();
  call_f528();
  call_f529();
  call_f530();
  call_f531();
  call_f532();
  call_f533();
  call_f534();
  call_f535();
  call_f536();
  call_f537();
  call_f538();
  call_f539();
  call_f540();
  call_f541();
  call_f542();
  call_f543();
  call_f544();
  call_f545();
  call_f546();
  call_f547();
  call_f548();
  call_f549();
  call_f550();
  call_f551();
  call_f552();
  call_f553();
  call_f554();
  call_f555();
  call_f556();
  call_f557();
  call_f558();
  call_f559();
  call_f560();
  call_f561();
  call_f562();
  call_f563();
  call_f564();
  call_f565();
  call_f566();
  call_f567();
  call_f568();
  call_f569();
  call_f570();
  call_f571();
  call_f572();
  call_f573();
  call_f574();
  call_f575();
  call_f576();
  call_f577();
  call_f578();
  call_f579();
  call_f580();
  call_f581();
  call_f582();
  call_f583();
  call_f584();
  call_f585();
  call_f586();
  call_f587();
  call_f588();
  call_f589();
  call_f590();
  call_f591();
  call_f592();
  call_f593();
  call_f594();
  call_f595();
  call_f596();
  call_f597();
  call_f598();
  call_f599();
  call_f600();
  call_f601();
  call_f602();
  call_f603();
  call_f604();
  call_f605();
  call_f606();
  call_f607();
  call_f608();
  call_f609();
  call_f610();
  call_f611();
  call_f612();
  call_f613();
  call_f614();
  call_f615();
  call_f616();
  call_f617();
  call_f618();
  call_f619();
  call_f620();
  call_f621();
  call_f622();
  call_f623();
  call_f624();
  call_f625();
  call_f626();
  call_f627();
  call_f628();
  call_f629();
  call_f630();
  call_f631();
  call_f632();
  call_f633();
  call_f634();
  call_f635();
  call_f636();
  call_f637();
  call_f638();
  call_f639();
  call_f640();
  call_f641();
  call_f642();
  call_f643();
  call_f644();
  call_f645();
  call_f646();
  call_f647();
  call_f648();
  call_f649();
  call_f650();
  call_f651();
  call_f652();
  call_f653();
  call_f654();
  call_f655();
  call_f656();
  call_f657();
  call_f658();
  call_f659();
  call_f660();
  call_f661();
  call_f662();
  call_f663();
  call_f664();
  call_f665();
  call_f666();
  call_f667();
  call_f668();
  call_f669();
  call_f670();
  call_f671();
  call_f672();
  call_f673();
  call_f674();
  call_f675();
  call_f676();
  call_f677();
  call_f678();
  call_f679();
  call_f680();
  call_f681();
  call_f682();
  call_f683();
  call_f684();
  call_f685();
  call_f686();
  call_f687();
  call_f688();
  call_f689();
  call_f690();
  call_f691();
  call_f692();
  call_f693();
  call_f694();
  call_f695();
  call_f696();
  call_f697();
  call_f698();
  call_f699();
  call_f700();
  call_f701();
  call_f702();
  call_f703();
  call_f704();
  call_f705();
  call_f706();
  call_f707();
  call_f708();
  call_f709();
  call_f710();
  call_f711();
  call_f712();
  call_f713();
  call_f714();
  call_f715();
  call_f716();
  call_f717();
  call_f718();
  call_f719();
  call_f720();
  call_f721();
  call_f722();
  return failed;
}
