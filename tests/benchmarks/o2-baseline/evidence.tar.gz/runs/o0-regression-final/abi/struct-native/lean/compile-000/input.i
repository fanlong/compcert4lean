# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c"
# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 1
# 43 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h"
typedef __builtin_va_list __gnuc_va_list;
# 59 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h"
typedef __builtin_va_list va_list;
# 2 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c" 2
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 29 "/usr/include/stdio.h" 2 3 4









# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4

# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef unsigned long size_t;
# 39 "/usr/include/stdio.h" 2 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 45 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 46 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 47 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 48 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 2 3 4

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2:24;

  char _short_backupbuf[1];
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;

  int _unused3;

  __uint64_t _total_written;




  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
# 49 "/usr/include/stdio.h" 2 3 4
# 89 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;
# 133 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 134 "/usr/include/stdio.h" 2 3 4
# 153 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) ;

extern int rename (const char *__old, const char *__new) ;
# 191 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) ;
# 201 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  ;
# 218 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) ;
# 243 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 271 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *restrict __filename,
      const char *restrict __modes)
  ;




extern FILE *freopen (const char *restrict __filename,
        const char *restrict __modes,
        FILE *restrict __stream) ;
# 341 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *restrict __stream, char *restrict __buf)
  ;



extern int setvbuf (FILE *restrict __stream, char *restrict __buf,
      int __modes, size_t __n) ;
# 364 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *restrict __stream,
      const char *restrict __format, ...) ;




extern int printf (const char *restrict __format, ...);

extern int sprintf (char *restrict __s,
      const char *restrict __format, ...) ;





extern int vfprintf (FILE *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;




extern int vprintf (const char *restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;



extern int snprintf (char *restrict __s, size_t __maxlen,
       const char *restrict __format, ...)
     ;

extern int vsnprintf (char *restrict __s, size_t __maxlen,
        const char *restrict __format, __gnuc_va_list __arg)
     ;
# 429 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *restrict __stream,
     const char *restrict __format, ...) ;




extern int scanf (const char *restrict __format, ...) ;

extern int sscanf (const char *restrict __s,
     const char *restrict __format, ...) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 445 "/usr/include/stdio.h" 2 3 4
# 479 "/usr/include/stdio.h" 3 4
extern int __isoc99_fscanf (FILE *restrict __stream,
       const char *restrict __format, ...)
  ;
extern int __isoc99_scanf (const char *restrict __format, ...) ;
extern int __isoc99_sscanf (const char *restrict __s,
       const char *restrict __format, ...) ;
# 497 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *restrict __s, const char *restrict __format,
      __gnuc_va_list __arg)
     ;





extern int vscanf (const char *restrict __format, __gnuc_va_list __arg)
     ;


extern int vsscanf (const char *restrict __s,
      const char *restrict __format, __gnuc_va_list __arg)
     ;
# 561 "/usr/include/stdio.h" 3 4
extern int __isoc99_vfscanf (FILE *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
extern int __isoc99_vscanf (const char *restrict __format,
       __gnuc_va_list __arg) ;
extern int __isoc99_vsscanf (const char *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
# 582 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) ;
extern int getc (FILE *__stream) ;





extern int getchar (void);
# 615 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) ;
extern int putc (int __c, FILE *__stream) ;





extern int putchar (int __c);
# 658 "/usr/include/stdio.h" 3 4
extern char *fgets (char *restrict __s, int __n, FILE *restrict __stream)
     ;
# 671 "/usr/include/stdio.h" 3 4
extern char *gets (char *__s) ;
# 711 "/usr/include/stdio.h" 3 4
extern int fputs (const char *restrict __s, FILE *restrict __stream)
  ;





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) ;






extern size_t fread (void *restrict __ptr, size_t __size,
       size_t __n, FILE *restrict __stream)
  ;




extern size_t fwrite (const void *restrict __ptr, size_t __size,
        size_t __n, FILE *restrict __s) ;
# 773 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  ;




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream) ;
# 823 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *restrict __stream, fpos_t *restrict __pos)
  ;




extern int fsetpos (FILE *__stream, const fpos_t *__pos) ;
# 854 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) ;

extern int feof (FILE *__stream) ;

extern int ferror (FILE *__stream) ;
# 872 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) ;
# 953 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 977 "/usr/include/stdio.h" 3 4

# 3 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4


# 37 "/usr/include/string.h" 3 4
# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 38 "/usr/include/string.h" 2 3 4
# 47 "/usr/include/string.h" 3 4
extern void *memcpy (void *restrict __dest, const void *restrict __src,
       size_t __n) ;


extern void *memmove (void *__dest, const void *__src, size_t __n)
     ;
# 65 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) ;
# 75 "/usr/include/string.h" 3 4
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     ;
# 91 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     ;
# 118 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      ;
# 156 "/usr/include/string.h" 3 4
extern char *strcpy (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncpy (char *restrict __dest,
        const char *restrict __src, size_t __n)
     ;


extern char *strcat (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncat (char *restrict __dest, const char *restrict __src,
        size_t __n) ;


extern int strcmp (const char *__s1, const char *__s2)
     ;

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     ;


extern int strcoll (const char *__s1, const char *__s2)
     ;

extern size_t strxfrm (char *restrict __dest,
         const char *restrict __src, size_t __n)
    ;
# 261 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     ;
# 292 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     ;
# 316 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     ;


extern size_t strspn (const char *__s, const char *__accept)
     ;
# 346 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     ;
# 377 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     ;
# 388 "/usr/include/string.h" 3 4
extern char *strtok (char *restrict __s, const char *restrict __delim)
     ;



extern char *__strtok_r (char *restrict __s,
    const char *restrict __delim,
    char **restrict __save_ptr)
     ;
# 439 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     ;
# 451 "/usr/include/string.h" 3 4
extern char *strerror (int __errnum) ;
# 584 "/usr/include/string.h" 3 4

# 4 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c" 2
# 1 "/usr/include/unistd.h" 1 3 4
# 27 "/usr/include/unistd.h" 3 4

# 202 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/posix_opt.h" 1 3 4
# 203 "/usr/include/unistd.h" 2 3 4
# 220 "/usr/include/unistd.h" 3 4
typedef __ssize_t ssize_t;





# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 227 "/usr/include/unistd.h" 2 3 4
# 287 "/usr/include/unistd.h" 3 4
extern int access (const char *__name, int __type) ;
# 339 "/usr/include/unistd.h" 3 4
extern __off_t lseek (int __fd, __off_t __offset, int __whence) ;
# 358 "/usr/include/unistd.h" 3 4
extern int close (int __fd);
# 371 "/usr/include/unistd.h" 3 4
extern ssize_t read (int __fd, void *__buf, size_t __nbytes)
    ;





extern ssize_t write (int __fd, const void *__buf, size_t __n)
    ;
# 437 "/usr/include/unistd.h" 3 4
extern int pipe (int __pipedes[2]) ;
# 452 "/usr/include/unistd.h" 3 4
extern unsigned int alarm (unsigned int __seconds) ;
# 464 "/usr/include/unistd.h" 3 4
extern unsigned int sleep (unsigned int __seconds);
# 489 "/usr/include/unistd.h" 3 4
extern int pause (void);



extern int chown (const char *__file, __uid_t __owner, __gid_t __group)
     ;
# 517 "/usr/include/unistd.h" 3 4
extern int chdir (const char *__path) ;
# 531 "/usr/include/unistd.h" 3 4
extern char *getcwd (char *__buf, size_t __size) ;
# 552 "/usr/include/unistd.h" 3 4
extern int dup (int __fd) ;


extern int dup2 (int __fd, int __fd2) ;
# 564 "/usr/include/unistd.h" 3 4
extern char **__environ;







extern int execve (const char *__path, char *const __argv[],
     char *const __envp[]) ;
# 584 "/usr/include/unistd.h" 3 4
extern int execv (const char *__path, char *const __argv[])
     ;



extern int execle (const char *__path, const char *__arg, ...)
     ;



extern int execl (const char *__path, const char *__arg, ...)
     ;



extern int execvp (const char *__file, char *const __argv[])
     ;




extern int execlp (const char *__file, const char *__arg, ...)
     ;
# 624 "/usr/include/unistd.h" 3 4
extern void _exit (int __status) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/confname.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/confname.h" 3 4
enum
  {
    _PC_LINK_MAX,

    _PC_MAX_CANON,

    _PC_MAX_INPUT,

    _PC_NAME_MAX,

    _PC_PATH_MAX,

    _PC_PIPE_BUF,

    _PC_CHOWN_RESTRICTED,

    _PC_NO_TRUNC,

    _PC_VDISABLE,

    _PC_SYNC_IO,

    _PC_ASYNC_IO,

    _PC_PRIO_IO,

    _PC_SOCK_MAXBUF,

    _PC_FILESIZEBITS,

    _PC_REC_INCR_XFER_SIZE,

    _PC_REC_MAX_XFER_SIZE,

    _PC_REC_MIN_XFER_SIZE,

    _PC_REC_XFER_ALIGN,

    _PC_ALLOC_SIZE_MIN,

    _PC_SYMLINK_MAX,

    _PC_2_SYMLINKS

  };


enum
  {
    _SC_ARG_MAX,

    _SC_CHILD_MAX,

    _SC_CLK_TCK,

    _SC_NGROUPS_MAX,

    _SC_OPEN_MAX,

    _SC_STREAM_MAX,

    _SC_TZNAME_MAX,

    _SC_JOB_CONTROL,

    _SC_SAVED_IDS,

    _SC_REALTIME_SIGNALS,

    _SC_PRIORITY_SCHEDULING,

    _SC_TIMERS,

    _SC_ASYNCHRONOUS_IO,

    _SC_PRIORITIZED_IO,

    _SC_SYNCHRONIZED_IO,

    _SC_FSYNC,

    _SC_MAPPED_FILES,

    _SC_MEMLOCK,

    _SC_MEMLOCK_RANGE,

    _SC_MEMORY_PROTECTION,

    _SC_MESSAGE_PASSING,

    _SC_SEMAPHORES,

    _SC_SHARED_MEMORY_OBJECTS,

    _SC_AIO_LISTIO_MAX,

    _SC_AIO_MAX,

    _SC_AIO_PRIO_DELTA_MAX,

    _SC_DELAYTIMER_MAX,

    _SC_MQ_OPEN_MAX,

    _SC_MQ_PRIO_MAX,

    _SC_VERSION,

    _SC_PAGESIZE,


    _SC_RTSIG_MAX,

    _SC_SEM_NSEMS_MAX,

    _SC_SEM_VALUE_MAX,

    _SC_SIGQUEUE_MAX,

    _SC_TIMER_MAX,




    _SC_BC_BASE_MAX,

    _SC_BC_DIM_MAX,

    _SC_BC_SCALE_MAX,

    _SC_BC_STRING_MAX,

    _SC_COLL_WEIGHTS_MAX,

    _SC_EQUIV_CLASS_MAX,

    _SC_EXPR_NEST_MAX,

    _SC_LINE_MAX,

    _SC_RE_DUP_MAX,

    _SC_CHARCLASS_NAME_MAX,


    _SC_2_VERSION,

    _SC_2_C_BIND,

    _SC_2_C_DEV,

    _SC_2_FORT_DEV,

    _SC_2_FORT_RUN,

    _SC_2_SW_DEV,

    _SC_2_LOCALEDEF,


    _SC_PII,

    _SC_PII_XTI,

    _SC_PII_SOCKET,

    _SC_PII_INTERNET,

    _SC_PII_OSI,

    _SC_POLL,

    _SC_SELECT,

    _SC_UIO_MAXIOV,

    _SC_IOV_MAX = _SC_UIO_MAXIOV,

    _SC_PII_INTERNET_STREAM,

    _SC_PII_INTERNET_DGRAM,

    _SC_PII_OSI_COTS,

    _SC_PII_OSI_CLTS,

    _SC_PII_OSI_M,

    _SC_T_IOV_MAX,



    _SC_THREADS,

    _SC_THREAD_SAFE_FUNCTIONS,

    _SC_GETGR_R_SIZE_MAX,

    _SC_GETPW_R_SIZE_MAX,

    _SC_LOGIN_NAME_MAX,

    _SC_TTY_NAME_MAX,

    _SC_THREAD_DESTRUCTOR_ITERATIONS,

    _SC_THREAD_KEYS_MAX,

    _SC_THREAD_STACK_MIN,

    _SC_THREAD_THREADS_MAX,

    _SC_THREAD_ATTR_STACKADDR,

    _SC_THREAD_ATTR_STACKSIZE,

    _SC_THREAD_PRIORITY_SCHEDULING,

    _SC_THREAD_PRIO_INHERIT,

    _SC_THREAD_PRIO_PROTECT,

    _SC_THREAD_PROCESS_SHARED,


    _SC_NPROCESSORS_CONF,

    _SC_NPROCESSORS_ONLN,

    _SC_PHYS_PAGES,

    _SC_AVPHYS_PAGES,

    _SC_ATEXIT_MAX,

    _SC_PASS_MAX,


    _SC_XOPEN_VERSION,

    _SC_XOPEN_XCU_VERSION,

    _SC_XOPEN_UNIX,

    _SC_XOPEN_CRYPT,

    _SC_XOPEN_ENH_I18N,

    _SC_XOPEN_SHM,


    _SC_2_CHAR_TERM,

    _SC_2_C_VERSION,

    _SC_2_UPE,


    _SC_XOPEN_XPG2,

    _SC_XOPEN_XPG3,

    _SC_XOPEN_XPG4,


    _SC_CHAR_BIT,

    _SC_CHAR_MAX,

    _SC_CHAR_MIN,

    _SC_INT_MAX,

    _SC_INT_MIN,

    _SC_LONG_BIT,

    _SC_WORD_BIT,

    _SC_MB_LEN_MAX,

    _SC_NZERO,

    _SC_SSIZE_MAX,

    _SC_SCHAR_MAX,

    _SC_SCHAR_MIN,

    _SC_SHRT_MAX,

    _SC_SHRT_MIN,

    _SC_UCHAR_MAX,

    _SC_UINT_MAX,

    _SC_ULONG_MAX,

    _SC_USHRT_MAX,


    _SC_NL_ARGMAX,

    _SC_NL_LANGMAX,

    _SC_NL_MSGMAX,

    _SC_NL_NMAX,

    _SC_NL_SETMAX,

    _SC_NL_TEXTMAX,


    _SC_XBS5_ILP32_OFF32,

    _SC_XBS5_ILP32_OFFBIG,

    _SC_XBS5_LP64_OFF64,

    _SC_XBS5_LPBIG_OFFBIG,


    _SC_XOPEN_LEGACY,

    _SC_XOPEN_REALTIME,

    _SC_XOPEN_REALTIME_THREADS,


    _SC_ADVISORY_INFO,

    _SC_BARRIERS,

    _SC_BASE,

    _SC_C_LANG_SUPPORT,

    _SC_C_LANG_SUPPORT_R,

    _SC_CLOCK_SELECTION,

    _SC_CPUTIME,

    _SC_THREAD_CPUTIME,

    _SC_DEVICE_IO,

    _SC_DEVICE_SPECIFIC,

    _SC_DEVICE_SPECIFIC_R,

    _SC_FD_MGMT,

    _SC_FIFO,

    _SC_PIPE,

    _SC_FILE_ATTRIBUTES,

    _SC_FILE_LOCKING,

    _SC_FILE_SYSTEM,

    _SC_MONOTONIC_CLOCK,

    _SC_MULTI_PROCESS,

    _SC_SINGLE_PROCESS,

    _SC_NETWORKING,

    _SC_READER_WRITER_LOCKS,

    _SC_SPIN_LOCKS,

    _SC_REGEXP,

    _SC_REGEX_VERSION,

    _SC_SHELL,

    _SC_SIGNALS,

    _SC_SPAWN,

    _SC_SPORADIC_SERVER,

    _SC_THREAD_SPORADIC_SERVER,

    _SC_SYSTEM_DATABASE,

    _SC_SYSTEM_DATABASE_R,

    _SC_TIMEOUTS,

    _SC_TYPED_MEMORY_OBJECTS,

    _SC_USER_GROUPS,

    _SC_USER_GROUPS_R,

    _SC_2_PBS,

    _SC_2_PBS_ACCOUNTING,

    _SC_2_PBS_LOCATE,

    _SC_2_PBS_MESSAGE,

    _SC_2_PBS_TRACK,

    _SC_SYMLOOP_MAX,

    _SC_STREAMS,

    _SC_2_PBS_CHECKPOINT,


    _SC_V6_ILP32_OFF32,

    _SC_V6_ILP32_OFFBIG,

    _SC_V6_LP64_OFF64,

    _SC_V6_LPBIG_OFFBIG,


    _SC_HOST_NAME_MAX,

    _SC_TRACE,

    _SC_TRACE_EVENT_FILTER,

    _SC_TRACE_INHERIT,

    _SC_TRACE_LOG,


    _SC_LEVEL1_ICACHE_SIZE,

    _SC_LEVEL1_ICACHE_ASSOC,

    _SC_LEVEL1_ICACHE_LINESIZE,

    _SC_LEVEL1_DCACHE_SIZE,

    _SC_LEVEL1_DCACHE_ASSOC,

    _SC_LEVEL1_DCACHE_LINESIZE,

    _SC_LEVEL2_CACHE_SIZE,

    _SC_LEVEL2_CACHE_ASSOC,

    _SC_LEVEL2_CACHE_LINESIZE,

    _SC_LEVEL3_CACHE_SIZE,

    _SC_LEVEL3_CACHE_ASSOC,

    _SC_LEVEL3_CACHE_LINESIZE,

    _SC_LEVEL4_CACHE_SIZE,

    _SC_LEVEL4_CACHE_ASSOC,

    _SC_LEVEL4_CACHE_LINESIZE,



    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,

    _SC_RAW_SOCKETS,


    _SC_V7_ILP32_OFF32,

    _SC_V7_ILP32_OFFBIG,

    _SC_V7_LP64_OFF64,

    _SC_V7_LPBIG_OFFBIG,


    _SC_SS_REPL_MAX,


    _SC_TRACE_EVENT_NAME_MAX,

    _SC_TRACE_NAME_MAX,

    _SC_TRACE_SYS_MAX,

    _SC_TRACE_USER_EVENT_MAX,


    _SC_XOPEN_STREAMS,


    _SC_THREAD_ROBUST_PRIO_INHERIT,

    _SC_THREAD_ROBUST_PRIO_PROTECT,


    _SC_MINSIGSTKSZ,


    _SC_SIGSTKSZ

  };


enum
  {
    _CS_PATH,


    _CS_V6_WIDTH_RESTRICTED_ENVS,



    _CS_GNU_LIBC_VERSION,

    _CS_GNU_LIBPTHREAD_VERSION,


    _CS_V5_WIDTH_RESTRICTED_ENVS,



    _CS_V7_WIDTH_RESTRICTED_ENVS,



    _CS_LFS_CFLAGS = 1000,

    _CS_LFS_LDFLAGS,

    _CS_LFS_LIBS,

    _CS_LFS_LINTFLAGS,

    _CS_LFS64_CFLAGS,

    _CS_LFS64_LDFLAGS,

    _CS_LFS64_LIBS,

    _CS_LFS64_LINTFLAGS,


    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,

    _CS_XBS5_ILP32_OFF32_LDFLAGS,

    _CS_XBS5_ILP32_OFF32_LIBS,

    _CS_XBS5_ILP32_OFF32_LINTFLAGS,

    _CS_XBS5_ILP32_OFFBIG_CFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LIBS,

    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,

    _CS_XBS5_LP64_OFF64_CFLAGS,

    _CS_XBS5_LP64_OFF64_LDFLAGS,

    _CS_XBS5_LP64_OFF64_LIBS,

    _CS_XBS5_LP64_OFF64_LINTFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LIBS,

    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LIBS,

    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V6_LP64_OFF64_CFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LIBS,

    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LIBS,

    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V7_LP64_OFF64_CFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LIBS,

    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,


    _CS_V6_ENV,

    _CS_V7_ENV

  };
# 631 "/usr/include/unistd.h" 2 3 4


extern long int pathconf (const char *__path, int __name)
     ;


extern long int fpathconf (int __fd, int __name) ;


extern long int sysconf (int __name) ;
# 650 "/usr/include/unistd.h" 3 4
extern __pid_t getpid (void) ;


extern __pid_t getppid (void) ;


extern __pid_t getpgrp (void) ;


extern __pid_t __getpgid (__pid_t __pid) ;
# 668 "/usr/include/unistd.h" 3 4
extern int setpgid (__pid_t __pid, __pid_t __pgid) ;
# 689 "/usr/include/unistd.h" 3 4
extern __pid_t setsid (void) ;







extern __uid_t getuid (void) ;


extern __uid_t geteuid (void) ;


extern __gid_t getgid (void) ;


extern __gid_t getegid (void) ;




extern int getgroups (int __size, __gid_t __list[])
    ;
# 722 "/usr/include/unistd.h" 3 4
extern int setuid (__uid_t __uid) ;
# 739 "/usr/include/unistd.h" 3 4
extern int setgid (__gid_t __gid) ;
# 778 "/usr/include/unistd.h" 3 4
extern __pid_t fork (void) ;
# 799 "/usr/include/unistd.h" 3 4
extern char *ttyname (int __fd) ;



extern int ttyname_r (int __fd, char *__buf, size_t __buflen)
    
     ;



extern int isatty (int __fd) ;
# 819 "/usr/include/unistd.h" 3 4
extern int link (const char *__from, const char *__to)
     ;
# 858 "/usr/include/unistd.h" 3 4
extern int unlink (const char *__name) ;
# 867 "/usr/include/unistd.h" 3 4
extern int rmdir (const char *__path) ;



extern __pid_t tcgetpgrp (int __fd) ;


extern int tcsetpgrp (int __fd, __pid_t __pgrp_id) ;






extern char *getlogin (void);
# 989 "/usr/include/unistd.h" 3 4
extern int fsync (int __fd);
# 1221 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/unistd_ext.h" 1 3 4
# 1222 "/usr/include/unistd.h" 2 3 4


# 5 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_decl.h" 1







# 7 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_decl.h"
extern int failed;

static void failure(const char * assertion, const char * file,
                    int line, const char * fn)
{
  fprintf(
# 12 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_decl.h" 3 4
         stderr
# 12 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_decl.h"
               , "%s:%d:%s: assertion %s failed\n", file, line, fn, assertion);
  failed = 1;
}



struct s1 {
  unsigned char a;
};
extern struct s1 f1(void);
extern void f2(struct s1 x0);
extern void f3(struct s1 x0, struct s1 x1);
extern void f4(int x0, struct s1 x1);
extern void f5(double x0, struct s1 x1);
struct s2 {
  signed char a;
};
extern struct s2 f6(void);
extern void f7(struct s2 x0);
extern void f8(struct s2 x0, struct s2 x1);
extern void f9(int x0, struct s2 x1);
extern void f10(double x0, struct s2 x1);
struct s3 {
  unsigned short a;
};
extern struct s3 f11(void);
extern void f12(struct s3 x0);
extern void f13(struct s3 x0, struct s3 x1);
extern void f14(int x0, struct s3 x1);
extern void f15(double x0, struct s3 x1);
struct s4 {
  short a;
};
extern struct s4 f16(void);
extern void f17(struct s4 x0);
extern void f18(struct s4 x0, struct s4 x1);
extern void f19(int x0, struct s4 x1);
extern void f20(double x0, struct s4 x1);
struct s5 {
  int a;
};
extern struct s5 f21(void);
extern void f22(struct s5 x0);
extern void f23(struct s5 x0, struct s5 x1);
extern void f24(int x0, struct s5 x1);
extern void f25(double x0, struct s5 x1);
struct s6 {
  long long a;
};
extern struct s6 f26(void);
extern void f27(struct s6 x0);
extern void f28(struct s6 x0, struct s6 x1);
extern void f29(int x0, struct s6 x1);
extern void f30(double x0, struct s6 x1);
struct s7 {
  float a;
};
extern struct s7 f31(void);
extern void f32(struct s7 x0);
extern void f33(struct s7 x0, struct s7 x1);
extern void f34(int x0, struct s7 x1);
extern void f35(double x0, struct s7 x1);
struct s8 {
  double a;
};
extern struct s8 f36(void);
extern void f37(struct s8 x0);
extern void f38(struct s8 x0, struct s8 x1);
extern void f39(int x0, struct s8 x1);
extern void f40(double x0, struct s8 x1);
struct s9 {
  char * a;
};
extern struct s9 f41(void);
extern void f42(struct s9 x0);
extern void f43(struct s9 x0, struct s9 x1);
extern void f44(int x0, struct s9 x1);
extern void f45(double x0, struct s9 x1);
struct s10 {
  unsigned char a;
  unsigned char b;
};
extern struct s10 f46(void);
extern void f47(struct s10 x0);
extern void f48(struct s10 x0, struct s10 x1);
extern void f49(int x0, struct s10 x1);
extern void f50(double x0, struct s10 x1);
struct s11 {
  unsigned char a;
  unsigned short b;
};
extern struct s11 f51(void);
extern void f52(struct s11 x0);
extern void f53(struct s11 x0, struct s11 x1);
extern void f54(int x0, struct s11 x1);
extern void f55(double x0, struct s11 x1);
struct s12 {
  unsigned char a;
  int b;
};
extern struct s12 f56(void);
extern void f57(struct s12 x0);
extern void f58(struct s12 x0, struct s12 x1);
extern void f59(int x0, struct s12 x1);
extern void f60(double x0, struct s12 x1);
struct s13 {
  unsigned char a;
  long long b;
};
extern struct s13 f61(void);
extern void f62(struct s13 x0);
extern void f63(struct s13 x0, struct s13 x1);
extern void f64(int x0, struct s13 x1);
extern void f65(double x0, struct s13 x1);
struct s14 {
  unsigned char a;
  float b;
};
extern struct s14 f66(void);
extern void f67(struct s14 x0);
extern void f68(struct s14 x0, struct s14 x1);
extern void f69(int x0, struct s14 x1);
extern void f70(double x0, struct s14 x1);
struct s15 {
  unsigned char a;
  double b;
};
extern struct s15 f71(void);
extern void f72(struct s15 x0);
extern void f73(struct s15 x0, struct s15 x1);
extern void f74(int x0, struct s15 x1);
extern void f75(double x0, struct s15 x1);
struct s16 {
  unsigned short a;
  unsigned char b;
};
extern struct s16 f76(void);
extern void f77(struct s16 x0);
extern void f78(struct s16 x0, struct s16 x1);
extern void f79(int x0, struct s16 x1);
extern void f80(double x0, struct s16 x1);
struct s17 {
  unsigned short a;
  unsigned short b;
};
extern struct s17 f81(void);
extern void f82(struct s17 x0);
extern void f83(struct s17 x0, struct s17 x1);
extern void f84(int x0, struct s17 x1);
extern void f85(double x0, struct s17 x1);
struct s18 {
  unsigned short a;
  int b;
};
extern struct s18 f86(void);
extern void f87(struct s18 x0);
extern void f88(struct s18 x0, struct s18 x1);
extern void f89(int x0, struct s18 x1);
extern void f90(double x0, struct s18 x1);
struct s19 {
  unsigned short a;
  long long b;
};
extern struct s19 f91(void);
extern void f92(struct s19 x0);
extern void f93(struct s19 x0, struct s19 x1);
extern void f94(int x0, struct s19 x1);
extern void f95(double x0, struct s19 x1);
struct s20 {
  unsigned short a;
  float b;
};
extern struct s20 f96(void);
extern void f97(struct s20 x0);
extern void f98(struct s20 x0, struct s20 x1);
extern void f99(int x0, struct s20 x1);
extern void f100(double x0, struct s20 x1);
struct s21 {
  unsigned short a;
  double b;
};
extern struct s21 f101(void);
extern void f102(struct s21 x0);
extern void f103(struct s21 x0, struct s21 x1);
extern void f104(int x0, struct s21 x1);
extern void f105(double x0, struct s21 x1);
struct s22 {
  int a;
  unsigned char b;
};
extern struct s22 f106(void);
extern void f107(struct s22 x0);
extern void f108(struct s22 x0, struct s22 x1);
extern void f109(int x0, struct s22 x1);
extern void f110(double x0, struct s22 x1);
struct s23 {
  int a;
  unsigned short b;
};
extern struct s23 f111(void);
extern void f112(struct s23 x0);
extern void f113(struct s23 x0, struct s23 x1);
extern void f114(int x0, struct s23 x1);
extern void f115(double x0, struct s23 x1);
struct s24 {
  int a;
  int b;
};
extern struct s24 f116(void);
extern void f117(struct s24 x0);
extern void f118(struct s24 x0, struct s24 x1);
extern void f119(int x0, struct s24 x1);
extern void f120(double x0, struct s24 x1);
struct s25 {
  int a;
  long long b;
};
extern struct s25 f121(void);
extern void f122(struct s25 x0);
extern void f123(struct s25 x0, struct s25 x1);
extern void f124(int x0, struct s25 x1);
extern void f125(double x0, struct s25 x1);
struct s26 {
  int a;
  float b;
};
extern struct s26 f126(void);
extern void f127(struct s26 x0);
extern void f128(struct s26 x0, struct s26 x1);
extern void f129(int x0, struct s26 x1);
extern void f130(double x0, struct s26 x1);
struct s27 {
  int a;
  double b;
};
extern struct s27 f131(void);
extern void f132(struct s27 x0);
extern void f133(struct s27 x0, struct s27 x1);
extern void f134(int x0, struct s27 x1);
extern void f135(double x0, struct s27 x1);
struct s28 {
  long long a;
  unsigned char b;
};
extern struct s28 f136(void);
extern void f137(struct s28 x0);
extern void f138(struct s28 x0, struct s28 x1);
extern void f139(int x0, struct s28 x1);
extern void f140(double x0, struct s28 x1);
struct s29 {
  long long a;
  unsigned short b;
};
extern struct s29 f141(void);
extern void f142(struct s29 x0);
extern void f143(struct s29 x0, struct s29 x1);
extern void f144(int x0, struct s29 x1);
extern void f145(double x0, struct s29 x1);
struct s30 {
  long long a;
  int b;
};
extern struct s30 f146(void);
extern void f147(struct s30 x0);
extern void f148(struct s30 x0, struct s30 x1);
extern void f149(int x0, struct s30 x1);
extern void f150(double x0, struct s30 x1);
struct s31 {
  long long a;
  long long b;
};
extern struct s31 f151(void);
extern void f152(struct s31 x0);
extern void f153(struct s31 x0, struct s31 x1);
extern void f154(int x0, struct s31 x1);
extern void f155(double x0, struct s31 x1);
struct s32 {
  long long a;
  float b;
};
extern struct s32 f156(void);
extern void f157(struct s32 x0);
extern void f158(struct s32 x0, struct s32 x1);
extern void f159(int x0, struct s32 x1);
extern void f160(double x0, struct s32 x1);
struct s33 {
  long long a;
  double b;
};
extern struct s33 f161(void);
extern void f162(struct s33 x0);
extern void f163(struct s33 x0, struct s33 x1);
extern void f164(int x0, struct s33 x1);
extern void f165(double x0, struct s33 x1);
struct s34 {
  float a;
  unsigned char b;
};
extern struct s34 f166(void);
extern void f167(struct s34 x0);
extern void f168(struct s34 x0, struct s34 x1);
extern void f169(int x0, struct s34 x1);
extern void f170(double x0, struct s34 x1);
struct s35 {
  float a;
  unsigned short b;
};
extern struct s35 f171(void);
extern void f172(struct s35 x0);
extern void f173(struct s35 x0, struct s35 x1);
extern void f174(int x0, struct s35 x1);
extern void f175(double x0, struct s35 x1);
struct s36 {
  float a;
  int b;
};
extern struct s36 f176(void);
extern void f177(struct s36 x0);
extern void f178(struct s36 x0, struct s36 x1);
extern void f179(int x0, struct s36 x1);
extern void f180(double x0, struct s36 x1);
struct s37 {
  float a;
  long long b;
};
extern struct s37 f181(void);
extern void f182(struct s37 x0);
extern void f183(struct s37 x0, struct s37 x1);
extern void f184(int x0, struct s37 x1);
extern void f185(double x0, struct s37 x1);
struct s38 {
  float a;
  float b;
};
extern struct s38 f186(void);
extern void f187(struct s38 x0);
extern void f188(struct s38 x0, struct s38 x1);
extern void f189(int x0, struct s38 x1);
extern void f190(double x0, struct s38 x1);
struct s39 {
  float a;
  double b;
};
extern struct s39 f191(void);
extern void f192(struct s39 x0);
extern void f193(struct s39 x0, struct s39 x1);
extern void f194(int x0, struct s39 x1);
extern void f195(double x0, struct s39 x1);
struct s40 {
  double a;
  unsigned char b;
};
extern struct s40 f196(void);
extern void f197(struct s40 x0);
extern void f198(struct s40 x0, struct s40 x1);
extern void f199(int x0, struct s40 x1);
extern void f200(double x0, struct s40 x1);
struct s41 {
  double a;
  unsigned short b;
};
extern struct s41 f201(void);
extern void f202(struct s41 x0);
extern void f203(struct s41 x0, struct s41 x1);
extern void f204(int x0, struct s41 x1);
extern void f205(double x0, struct s41 x1);
struct s42 {
  double a;
  int b;
};
extern struct s42 f206(void);
extern void f207(struct s42 x0);
extern void f208(struct s42 x0, struct s42 x1);
extern void f209(int x0, struct s42 x1);
extern void f210(double x0, struct s42 x1);
struct s43 {
  double a;
  long long b;
};
extern struct s43 f211(void);
extern void f212(struct s43 x0);
extern void f213(struct s43 x0, struct s43 x1);
extern void f214(int x0, struct s43 x1);
extern void f215(double x0, struct s43 x1);
struct s44 {
  double a;
  float b;
};
extern struct s44 f216(void);
extern void f217(struct s44 x0);
extern void f218(struct s44 x0, struct s44 x1);
extern void f219(int x0, struct s44 x1);
extern void f220(double x0, struct s44 x1);
struct s45 {
  double a;
  double b;
};
extern struct s45 f221(void);
extern void f222(struct s45 x0);
extern void f223(struct s45 x0, struct s45 x1);
extern void f224(int x0, struct s45 x1);
extern void f225(double x0, struct s45 x1);
struct s46 {
  unsigned char a;
  unsigned char b;
  unsigned char c;
};
extern struct s46 f226(void);
extern void f227(struct s46 x0);
extern void f228(struct s46 x0, struct s46 x1);
extern void f229(int x0, struct s46 x1);
extern void f230(double x0, struct s46 x1);
struct s47 {
  unsigned char a;
  unsigned char b;
  unsigned char c;
  unsigned char d;
};
extern struct s47 f231(void);
extern void f232(struct s47 x0);
extern void f233(struct s47 x0, struct s47 x1);
extern void f234(int x0, struct s47 x1);
extern void f235(double x0, struct s47 x1);
struct s48 {
  unsigned char a;
  unsigned char b;
  unsigned char c;
  unsigned char d;
  unsigned char e;
  unsigned char f;
};
extern struct s48 f236(void);
extern void f237(struct s48 x0);
extern void f238(struct s48 x0, struct s48 x1);
extern void f239(int x0, struct s48 x1);
extern void f240(double x0, struct s48 x1);
struct s49 {
  unsigned char a;
  unsigned char b;
  unsigned char c;
  unsigned char d;
  unsigned char e;
  unsigned char f;
  unsigned char g;
  unsigned char h;
};
extern struct s49 f241(void);
extern void f242(struct s49 x0);
extern void f243(struct s49 x0, struct s49 x1);
extern void f244(int x0, struct s49 x1);
extern void f245(double x0, struct s49 x1);
struct s50 {
  unsigned short a;
  unsigned short b;
  unsigned short c;
};
extern struct s50 f246(void);
extern void f247(struct s50 x0);
extern void f248(struct s50 x0, struct s50 x1);
extern void f249(int x0, struct s50 x1);
extern void f250(double x0, struct s50 x1);
struct s51 {
  unsigned short a;
  unsigned short b;
  unsigned short c;
  unsigned short d;
};
extern struct s51 f251(void);
extern void f252(struct s51 x0);
extern void f253(struct s51 x0, struct s51 x1);
extern void f254(int x0, struct s51 x1);
extern void f255(double x0, struct s51 x1);
struct s52 {
  unsigned short a;
  unsigned short b;
  unsigned short c;
  unsigned short d;
  unsigned short e;
  unsigned short f;
};
extern struct s52 f256(void);
extern void f257(struct s52 x0);
extern void f258(struct s52 x0, struct s52 x1);
extern void f259(int x0, struct s52 x1);
extern void f260(double x0, struct s52 x1);
struct s53 {
  unsigned short a;
  unsigned short b;
  unsigned short c;
  unsigned short d;
  unsigned short e;
  unsigned short f;
  unsigned short g;
  unsigned short h;
};
extern struct s53 f261(void);
extern void f262(struct s53 x0);
extern void f263(struct s53 x0, struct s53 x1);
extern void f264(int x0, struct s53 x1);
extern void f265(double x0, struct s53 x1);
struct s54 {
  int a;
  int b;
  int c;
};
extern struct s54 f266(void);
extern void f267(struct s54 x0);
extern void f268(struct s54 x0, struct s54 x1);
extern void f269(int x0, struct s54 x1);
extern void f270(double x0, struct s54 x1);
struct s55 {
  int a;
  int b;
  int c;
  int d;
};
extern struct s55 f271(void);
extern void f272(struct s55 x0);
extern void f273(struct s55 x0, struct s55 x1);
extern void f274(int x0, struct s55 x1);
extern void f275(double x0, struct s55 x1);
struct s56 {
  int a;
  int b;
  int c;
  int d;
  int e;
  int f;
};
extern struct s56 f276(void);
extern void f277(struct s56 x0);
extern void f278(struct s56 x0, struct s56 x1);
extern void f279(int x0, struct s56 x1);
extern void f280(double x0, struct s56 x1);
struct s57 {
  int a;
  int b;
  int c;
  int d;
  int e;
  int f;
  int g;
  int h;
};
extern struct s57 f281(void);
extern void f282(struct s57 x0);
extern void f283(struct s57 x0, struct s57 x1);
extern void f284(int x0, struct s57 x1);
extern void f285(double x0, struct s57 x1);
struct s58 {
  long long a;
  long long b;
  long long c;
};
extern struct s58 f286(void);
extern void f287(struct s58 x0);
extern void f288(struct s58 x0, struct s58 x1);
extern void f289(int x0, struct s58 x1);
extern void f290(double x0, struct s58 x1);
struct s59 {
  long long a;
  long long b;
  long long c;
  long long d;
};
extern struct s59 f291(void);
extern void f292(struct s59 x0);
extern void f293(struct s59 x0, struct s59 x1);
extern void f294(int x0, struct s59 x1);
extern void f295(double x0, struct s59 x1);
struct s60 {
  long long a;
  long long b;
  long long c;
  long long d;
  long long e;
  long long f;
};
extern struct s60 f296(void);
extern void f297(struct s60 x0);
extern void f298(struct s60 x0, struct s60 x1);
extern void f299(int x0, struct s60 x1);
extern void f300(double x0, struct s60 x1);
struct s61 {
  long long a;
  long long b;
  long long c;
  long long d;
  long long e;
  long long f;
  long long g;
  long long h;
};
extern struct s61 f301(void);
extern void f302(struct s61 x0);
extern void f303(struct s61 x0, struct s61 x1);
extern void f304(int x0, struct s61 x1);
extern void f305(double x0, struct s61 x1);
struct s62 {
  float a;
  float b;
  float c;
};
extern struct s62 f306(void);
extern void f307(struct s62 x0);
extern void f308(struct s62 x0, struct s62 x1);
extern void f309(int x0, struct s62 x1);
extern void f310(double x0, struct s62 x1);
struct s63 {
  float a;
  float b;
  float c;
  float d;
};
extern struct s63 f311(void);
extern void f312(struct s63 x0);
extern void f313(struct s63 x0, struct s63 x1);
extern void f314(int x0, struct s63 x1);
extern void f315(double x0, struct s63 x1);
struct s64 {
  float a;
  float b;
  float c;
  float d;
  float e;
  float f;
};
extern struct s64 f316(void);
extern void f317(struct s64 x0);
extern void f318(struct s64 x0, struct s64 x1);
extern void f319(int x0, struct s64 x1);
extern void f320(double x0, struct s64 x1);
struct s65 {
  float a;
  float b;
  float c;
  float d;
  float e;
  float f;
  float g;
  float h;
};
extern struct s65 f321(void);
extern void f322(struct s65 x0);
extern void f323(struct s65 x0, struct s65 x1);
extern void f324(int x0, struct s65 x1);
extern void f325(double x0, struct s65 x1);
struct s66 {
  double a;
  double b;
  double c;
};
extern struct s66 f326(void);
extern void f327(struct s66 x0);
extern void f328(struct s66 x0, struct s66 x1);
extern void f329(int x0, struct s66 x1);
extern void f330(double x0, struct s66 x1);
struct s67 {
  double a;
  double b;
  double c;
  double d;
};
extern struct s67 f331(void);
extern void f332(struct s67 x0);
extern void f333(struct s67 x0, struct s67 x1);
extern void f334(int x0, struct s67 x1);
extern void f335(double x0, struct s67 x1);
struct s68 {
  double a;
  double b;
  double c;
  double d;
  double e;
  double f;
};
extern struct s68 f336(void);
extern void f337(struct s68 x0);
extern void f338(struct s68 x0, struct s68 x1);
extern void f339(int x0, struct s68 x1);
extern void f340(double x0, struct s68 x1);
struct s69 {
  double a;
  double b;
  double c;
  double d;
  double e;
  double f;
  double g;
  double h;
};
extern struct s69 f341(void);
extern void f342(struct s69 x0);
extern void f343(struct s69 x0, struct s69 x1);
extern void f344(int x0, struct s69 x1);
extern void f345(double x0, struct s69 x1);
# 6 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c" 2

struct s1 f1(void)
{
  return (struct s1){450782004};
}

void f2(struct s1 x0)
{
  ((x0.a == 210) ? (void)0 : failure("x0.a == 210","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",14,__func__));
}

void f3(struct s1 x0, struct s1 x1)
{
  ((x0.a == 234) ? (void)0 : failure("x0.a == 234","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",19,__func__));
  ((x1.a == 188) ? (void)0 : failure("x1.a == 188","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",20,__func__));
}

void f4(int x0, struct s1 x1)
{
  ((x0 == 1815701022) ? (void)0 : failure("x0 == 1815701022","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",25,__func__));
  ((x1.a == 229) ? (void)0 : failure("x1.a == 229","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",26,__func__));
}

void f5(double x0, struct s1 x1)
{
  ((x0 == 0x1.f76a831c5397p+2) ? (void)0 : failure("x0 == 0x1.f76a831c5397p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",31,__func__));
  ((x1.a == 5) ? (void)0 : failure("x1.a == 5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",32,__func__));
}

struct s2 f6(void)
{
  return (struct s2){-225722087};
}

void f7(struct s2 x0)
{
  ((x0.a == -105) ? (void)0 : failure("x0.a == -105","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",42,__func__));
}

void f8(struct s2 x0, struct s2 x1)
{
  ((x0.a == 74) ? (void)0 : failure("x0.a == 74","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",47,__func__));
  ((x1.a == -41) ? (void)0 : failure("x1.a == -41","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",48,__func__));
}

void f9(int x0, struct s2 x1)
{
  ((x0 == 1947842430) ? (void)0 : failure("x0 == 1947842430","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",53,__func__));
  ((x1.a == -34) ? (void)0 : failure("x1.a == -34","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",54,__func__));
}

void f10(double x0, struct s2 x1)
{
  ((x0 == 0x1.1fc90e8ae4d78p+5) ? (void)0 : failure("x0 == 0x1.1fc90e8ae4d78p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",59,__func__));
  ((x1.a == 91) ? (void)0 : failure("x1.a == 91","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",60,__func__));
}

struct s3 f11(void)
{
  return (struct s3){371045750};
}

void f12(struct s3 x0)
{
  ((x0.a == 61138) ? (void)0 : failure("x0.a == 61138","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",70,__func__));
}

void f13(struct s3 x0, struct s3 x1)
{
  ((x0.a == 47349) ? (void)0 : failure("x0.a == 47349","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",75,__func__));
  ((x1.a == 24581) ? (void)0 : failure("x1.a == 24581","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",76,__func__));
}

void f14(int x0, struct s3 x1)
{
  ((x0 == 242953397) ? (void)0 : failure("x0 == 242953397","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",81,__func__));
  ((x1.a == 49977) ? (void)0 : failure("x1.a == 49977","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",82,__func__));
}

void f15(double x0, struct s3 x1)
{
  ((x0 == 0x1.7c994f1a97fbp+3) ? (void)0 : failure("x0 == 0x1.7c994f1a97fbp+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",87,__func__));
  ((x1.a == 36643) ? (void)0 : failure("x1.a == 36643","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",88,__func__));
}

struct s4 f16(void)
{
  return (struct s4){-252354681};
}

void f17(struct s4 x0)
{
  ((x0.a == 19286) ? (void)0 : failure("x0.a == 19286","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",98,__func__));
}

void f18(struct s4 x0, struct s4 x1)
{
  ((x0.a == 6472) ? (void)0 : failure("x0.a == 6472","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",103,__func__));
  ((x1.a == 734) ? (void)0 : failure("x1.a == 734","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",104,__func__));
}

void f19(int x0, struct s4 x1)
{
  ((x0 == -1677478395) ? (void)0 : failure("x0 == -1677478395","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",109,__func__));
  ((x1.a == 4352) ? (void)0 : failure("x1.a == 4352","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",110,__func__));
}

void f20(double x0, struct s4 x1)
{
  ((x0 == 0x1.098fb3dd45ef8p+5) ? (void)0 : failure("x0 == 0x1.098fb3dd45ef8p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",115,__func__));
  ((x1.a == -16889) ? (void)0 : failure("x1.a == -16889","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",116,__func__));
}

struct s5 f21(void)
{
  return (struct s5){1577533673};
}

void f22(struct s5 x0)
{
  ((x0.a == 2061240087) ? (void)0 : failure("x0.a == 2061240087","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",126,__func__));
}

void f23(struct s5 x0, struct s5 x1)
{
  ((x0.a == 109785855) ? (void)0 : failure("x0.a == 109785855","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",131,__func__));
  ((x1.a == -1908988732) ? (void)0 : failure("x1.a == -1908988732","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",132,__func__));
}

void f24(int x0, struct s5 x1)
{
  ((x0 == 986535705) ? (void)0 : failure("x0 == 986535705","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",137,__func__));
  ((x1.a == -275829590) ? (void)0 : failure("x1.a == -275829590","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",138,__func__));
}

void f25(double x0, struct s5 x1)
{
  ((x0 == 0x1.b018822955398p+2) ? (void)0 : failure("x0 == 0x1.b018822955398p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",143,__func__));
  ((x1.a == -1819372239) ? (void)0 : failure("x1.a == -1819372239","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",144,__func__));
}

struct s6 f26(void)
{
  return (struct s6){-3105154652647668272};
}

void f27(struct s6 x0)
{
  ((x0.a == 3378611537454465391) ? (void)0 : failure("x0.a == 3378611537454465391","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",154,__func__));
}

void f28(struct s6 x0, struct s6 x1)
{
  ((x0.a == 6537315735875373552) ? (void)0 : failure("x0.a == 6537315735875373552","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",159,__func__));
  ((x1.a == 3416050011937819997) ? (void)0 : failure("x1.a == 3416050011937819997","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",160,__func__));
}

void f29(int x0, struct s6 x1)
{
  ((x0 == -2123243015) ? (void)0 : failure("x0 == -2123243015","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",165,__func__));
  ((x1.a == -4770020751718028244) ? (void)0 : failure("x1.a == -4770020751718028244","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",166,__func__));
}

void f30(double x0, struct s6 x1)
{
  ((x0 == 0x1.8bcde682c8466p+5) ? (void)0 : failure("x0 == 0x1.8bcde682c8466p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",171,__func__));
  ((x1.a == -3238782525965314528) ? (void)0 : failure("x1.a == -3238782525965314528","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",172,__func__));
}

struct s7 f31(void)
{
  return (struct s7){0x1.1f537de4ed74p+5};
}

void f32(struct s7 x0)
{
  ((x0.a == -0x1.54fc0cp+5F) ? (void)0 : failure("x0.a == -0x1.54fc0cp+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",182,__func__));
}

void f33(struct s7 x0, struct s7 x1)
{
  ((x0.a == 0x1.274088p+3F) ? (void)0 : failure("x0.a == 0x1.274088p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",187,__func__));
  ((x1.a == -0x1.f72312p+2F) ? (void)0 : failure("x1.a == -0x1.f72312p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",188,__func__));
}

void f34(int x0, struct s7 x1)
{
  ((x0 == 700688855) ? (void)0 : failure("x0 == 700688855","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",193,__func__));
  ((x1.a == -0x1.c0617cp+4F) ? (void)0 : failure("x1.a == -0x1.c0617cp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",194,__func__));
}

void f35(double x0, struct s7 x1)
{
  ((x0 == -0x1.260a64981aed2p+4) ? (void)0 : failure("x0 == -0x1.260a64981aed2p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",199,__func__));
  ((x1.a == -0x1.6070d4p+4F) ? (void)0 : failure("x1.a == -0x1.6070d4p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",200,__func__));
}

struct s8 f36(void)
{
  return (struct s8){-0x1.657e7ae346456p+4};
}

void f37(struct s8 x0)
{
  ((x0.a == 0x1.74a4ec30c5bcep+5) ? (void)0 : failure("x0.a == 0x1.74a4ec30c5bcep+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",210,__func__));
}

void f38(struct s8 x0, struct s8 x1)
{
  ((x0.a == 0x1.3a13dc3c291b8p+5) ? (void)0 : failure("x0.a == 0x1.3a13dc3c291b8p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",215,__func__));
  ((x1.a == 0x1.090bd2521edc4p+4) ? (void)0 : failure("x1.a == 0x1.090bd2521edc4p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",216,__func__));
}

void f39(int x0, struct s8 x1)
{
  ((x0 == -1058592089) ? (void)0 : failure("x0 == -1058592089","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",221,__func__));
  ((x1.a == 0x1.9512a51a88c2cp+4) ? (void)0 : failure("x1.a == 0x1.9512a51a88c2cp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",222,__func__));
}

void f40(double x0, struct s8 x1)
{
  ((x0 == -0x1.0cb18c10ff00ep+5) ? (void)0 : failure("x0 == -0x1.0cb18c10ff00ep+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",227,__func__));
  ((x1.a == 0x1.287d6f4752cd2p+5) ? (void)0 : failure("x1.a == 0x1.287d6f4752cd2p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",228,__func__));
}

struct s9 f41(void)
{
  return (struct s9){""};
}

void f42(struct s9 x0)
{
  ((strcmp(x0.a, "") == 0) ? (void)0 : failure("strcmp(x0.a, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",238,__func__));
}

void f43(struct s9 x0, struct s9 x1)
{
  ((strcmp(x0.a, "") == 0) ? (void)0 : failure("strcmp(x0.a, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",243,__func__));
  ((strcmp(x1.a, "s") == 0) ? (void)0 : failure("strcmp(x1.a, \"s\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",244,__func__));
}

void f44(int x0, struct s9 x1)
{
  ((x0 == 117078430) ? (void)0 : failure("x0 == 117078430","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",249,__func__));
  ((strcmp(x1.a, "e") == 0) ? (void)0 : failure("strcmp(x1.a, \"e\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",250,__func__));
}

void f45(double x0, struct s9 x1)
{
  ((x0 == -0x1.1870de6a4f604p+3) ? (void)0 : failure("x0 == -0x1.1870de6a4f604p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",255,__func__));
  ((strcmp(x1.a, "o") == 0) ? (void)0 : failure("strcmp(x1.a, \"o\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",256,__func__));
}

struct s10 f46(void)
{
  return (struct s10){-332354996, -212278338};
}

void f47(struct s10 x0)
{
  ((x0.a == 144) ? (void)0 : failure("x0.a == 144","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",266,__func__));
  ((x0.b == 70) ? (void)0 : failure("x0.b == 70","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",267,__func__));
}

void f48(struct s10 x0, struct s10 x1)
{
  ((x0.a == 5) ? (void)0 : failure("x0.a == 5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",272,__func__));
  ((x0.b == 128) ? (void)0 : failure("x0.b == 128","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",273,__func__));
  ((x1.a == 214) ? (void)0 : failure("x1.a == 214","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",274,__func__));
  ((x1.b == 16) ? (void)0 : failure("x1.b == 16","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",275,__func__));
}

void f49(int x0, struct s10 x1)
{
  ((x0 == -1112381232) ? (void)0 : failure("x0 == -1112381232","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",280,__func__));
  ((x1.a == 51) ? (void)0 : failure("x1.a == 51","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",281,__func__));
  ((x1.b == 10) ? (void)0 : failure("x1.b == 10","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",282,__func__));
}

void f50(double x0, struct s10 x1)
{
  ((x0 == 0x1.058d46e3148b2p+5) ? (void)0 : failure("x0 == 0x1.058d46e3148b2p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",287,__func__));
  ((x1.a == 207) ? (void)0 : failure("x1.a == 207","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",288,__func__));
  ((x1.b == 217) ? (void)0 : failure("x1.b == 217","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",289,__func__));
}

struct s11 f51(void)
{
  return (struct s11){185612783, -223341175};
}

void f52(struct s11 x0)
{
  ((x0.a == 59) ? (void)0 : failure("x0.a == 59","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",299,__func__));
  ((x0.b == 48682) ? (void)0 : failure("x0.b == 48682","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",300,__func__));
}

void f53(struct s11 x0, struct s11 x1)
{
  ((x0.a == 247) ? (void)0 : failure("x0.a == 247","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",305,__func__));
  ((x0.b == 59224) ? (void)0 : failure("x0.b == 59224","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",306,__func__));
  ((x1.a == 174) ? (void)0 : failure("x1.a == 174","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",307,__func__));
  ((x1.b == 46297) ? (void)0 : failure("x1.b == 46297","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",308,__func__));
}

void f54(int x0, struct s11 x1)
{
  ((x0 == 1285894652) ? (void)0 : failure("x0 == 1285894652","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",313,__func__));
  ((x1.a == 28) ? (void)0 : failure("x1.a == 28","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",314,__func__));
  ((x1.b == 43200) ? (void)0 : failure("x1.b == 43200","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",315,__func__));
}

void f55(double x0, struct s11 x1)
{
  ((x0 == -0x1.58b8b10825683p+4) ? (void)0 : failure("x0 == -0x1.58b8b10825683p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",320,__func__));
  ((x1.a == 246) ? (void)0 : failure("x1.a == 246","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",321,__func__));
  ((x1.b == 63839) ? (void)0 : failure("x1.b == 63839","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",322,__func__));
}

struct s12 f56(void)
{
  return (struct s12){-78251852, -1906949473};
}

void f57(struct s12 x0)
{
  ((x0.a == 172) ? (void)0 : failure("x0.a == 172","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",332,__func__));
  ((x0.b == 1933564125) ? (void)0 : failure("x0.b == 1933564125","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",333,__func__));
}

void f58(struct s12 x0, struct s12 x1)
{
  ((x0.a == 222) ? (void)0 : failure("x0.a == 222","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",338,__func__));
  ((x0.b == 1964828987) ? (void)0 : failure("x0.b == 1964828987","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",339,__func__));
  ((x1.a == 173) ? (void)0 : failure("x1.a == 173","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",340,__func__));
  ((x1.b == -394622240) ? (void)0 : failure("x1.b == -394622240","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",341,__func__));
}

void f59(int x0, struct s12 x1)
{
  ((x0 == 1060027508) ? (void)0 : failure("x0 == 1060027508","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",346,__func__));
  ((x1.a == 177) ? (void)0 : failure("x1.a == 177","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",347,__func__));
  ((x1.b == -1716875482) ? (void)0 : failure("x1.b == -1716875482","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",348,__func__));
}

void f60(double x0, struct s12 x1)
{
  ((x0 == 0x1.22424233d124cp+4) ? (void)0 : failure("x0 == 0x1.22424233d124cp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",353,__func__));
  ((x1.a == 225) ? (void)0 : failure("x1.a == 225","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",354,__func__));
  ((x1.b == -875240157) ? (void)0 : failure("x1.b == -875240157","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",355,__func__));
}

struct s13 f61(void)
{
  return (struct s13){3311735, -5188281542945856611};
}

void f62(struct s13 x0)
{
  ((x0.a == 2) ? (void)0 : failure("x0.a == 2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",365,__func__));
  ((x0.b == 2436054323590893261) ? (void)0 : failure("x0.b == 2436054323590893261","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",366,__func__));
}

void f63(struct s13 x0, struct s13 x1)
{
  ((x0.a == 104) ? (void)0 : failure("x0.a == 104","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",371,__func__));
  ((x0.b == -9002517791903262263) ? (void)0 : failure("x0.b == -9002517791903262263","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",372,__func__));
  ((x1.a == 189) ? (void)0 : failure("x1.a == 189","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",373,__func__));
  ((x1.b == -5040905127155251799) ? (void)0 : failure("x1.b == -5040905127155251799","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",374,__func__));
}

void f64(int x0, struct s13 x1)
{
  ((x0 == -1607654603) ? (void)0 : failure("x0 == -1607654603","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",379,__func__));
  ((x1.a == 45) ? (void)0 : failure("x1.a == 45","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",380,__func__));
  ((x1.b == -1163175273696450282) ? (void)0 : failure("x1.b == -1163175273696450282","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",381,__func__));
}

void f65(double x0, struct s13 x1)
{
  ((x0 == -0x1.25b6d9848376p+5) ? (void)0 : failure("x0 == -0x1.25b6d9848376p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",386,__func__));
  ((x1.a == 82) ? (void)0 : failure("x1.a == 82","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",387,__func__));
  ((x1.b == 6629600029036599347) ? (void)0 : failure("x1.b == 6629600029036599347","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",388,__func__));
}

struct s14 f66(void)
{
  return (struct s14){-76552535, -0x1.87727d845bbcp+1};
}

void f67(struct s14 x0)
{
  ((x0.a == 93) ? (void)0 : failure("x0.a == 93","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",398,__func__));
  ((x0.b == 0x1.559ab4p+5F) ? (void)0 : failure("x0.b == 0x1.559ab4p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",399,__func__));
}

void f68(struct s14 x0, struct s14 x1)
{
  ((x0.a == 226) ? (void)0 : failure("x0.a == 226","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",404,__func__));
  ((x0.b == -0x1.58fe98p-1F) ? (void)0 : failure("x0.b == -0x1.58fe98p-1F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",405,__func__));
  ((x1.a == 42) ? (void)0 : failure("x1.a == 42","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",406,__func__));
  ((x1.b == -0x1.3b4046p+4F) ? (void)0 : failure("x1.b == -0x1.3b4046p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",407,__func__));
}

void f69(int x0, struct s14 x1)
{
  ((x0 == -2124451791) ? (void)0 : failure("x0 == -2124451791","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",412,__func__));
  ((x1.a == 129) ? (void)0 : failure("x1.a == 129","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",413,__func__));
  ((x1.b == -0x1.09129p+5F) ? (void)0 : failure("x1.b == -0x1.09129p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",414,__func__));
}

void f70(double x0, struct s14 x1)
{
  ((x0 == 0x1.d0d8d023834a8p+2) ? (void)0 : failure("x0 == 0x1.d0d8d023834a8p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",419,__func__));
  ((x1.a == 51) ? (void)0 : failure("x1.a == 51","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",420,__func__));
  ((x1.b == -0x1.b7948cp+3F) ? (void)0 : failure("x1.b == -0x1.b7948cp+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",421,__func__));
}

struct s15 f71(void)
{
  return (struct s15){-294740630, 0x1.83d073d680ecp+1};
}

void f72(struct s15 x0)
{
  ((x0.a == 182) ? (void)0 : failure("x0.a == 182","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",431,__func__));
  ((x0.b == 0x1.75b0578c78b96p+5) ? (void)0 : failure("x0.b == 0x1.75b0578c78b96p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",432,__func__));
}

void f73(struct s15 x0, struct s15 x1)
{
  ((x0.a == 212) ? (void)0 : failure("x0.a == 212","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",437,__func__));
  ((x0.b == -0x1.34efea07bf133p+4) ? (void)0 : failure("x0.b == -0x1.34efea07bf133p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",438,__func__));
  ((x1.a == 184) ? (void)0 : failure("x1.a == 184","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",439,__func__));
  ((x1.b == 0x1.078c1542be3c4p+3) ? (void)0 : failure("x1.b == 0x1.078c1542be3c4p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",440,__func__));
}

void f74(int x0, struct s15 x1)
{
  ((x0 == 1723296699) ? (void)0 : failure("x0 == 1723296699","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",445,__func__));
  ((x1.a == 235) ? (void)0 : failure("x1.a == 235","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",446,__func__));
  ((x1.b == 0x1.f529ed56a3e5p+3) ? (void)0 : failure("x1.b == 0x1.f529ed56a3e5p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",447,__func__));
}

void f75(double x0, struct s15 x1)
{
  ((x0 == -0x1.81ca9bad6beccp+4) ? (void)0 : failure("x0 == -0x1.81ca9bad6beccp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",452,__func__));
  ((x1.a == 127) ? (void)0 : failure("x1.a == 127","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",453,__func__));
  ((x1.b == -0x1.088acf1b29a78p+2) ? (void)0 : failure("x1.b == -0x1.088acf1b29a78p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",454,__func__));
}

struct s16 f76(void)
{
  return (struct s16){25989974, 165566644};
}

void f77(struct s16 x0)
{
  ((x0.a == 43638) ? (void)0 : failure("x0.a == 43638","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",464,__func__));
  ((x0.b == 189) ? (void)0 : failure("x0.b == 189","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",465,__func__));
}

void f78(struct s16 x0, struct s16 x1)
{
  ((x0.a == 59449) ? (void)0 : failure("x0.a == 59449","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",470,__func__));
  ((x0.b == 224) ? (void)0 : failure("x0.b == 224","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",471,__func__));
  ((x1.a == 5525) ? (void)0 : failure("x1.a == 5525","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",472,__func__));
  ((x1.b == 8) ? (void)0 : failure("x1.b == 8","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",473,__func__));
}

void f79(int x0, struct s16 x1)
{
  ((x0 == 2121459177) ? (void)0 : failure("x0 == 2121459177","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",478,__func__));
  ((x1.a == 57641) ? (void)0 : failure("x1.a == 57641","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",479,__func__));
  ((x1.b == 158) ? (void)0 : failure("x1.b == 158","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",480,__func__));
}

void f80(double x0, struct s16 x1)
{
  ((x0 == 0x1.cb6e5f02078d4p+4) ? (void)0 : failure("x0 == 0x1.cb6e5f02078d4p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",485,__func__));
  ((x1.a == 22038) ? (void)0 : failure("x1.a == 22038","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",486,__func__));
  ((x1.b == 51) ? (void)0 : failure("x1.b == 51","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",487,__func__));
}

struct s17 f81(void)
{
  return (struct s17){-346657644, -399262278};
}

void f82(struct s17 x0)
{
  ((x0.a == 56134) ? (void)0 : failure("x0.a == 56134","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",497,__func__));
  ((x0.b == 19889) ? (void)0 : failure("x0.b == 19889","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",498,__func__));
}

void f83(struct s17 x0, struct s17 x1)
{
  ((x0.a == 5586) ? (void)0 : failure("x0.a == 5586","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",503,__func__));
  ((x0.b == 9939) ? (void)0 : failure("x0.b == 9939","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",504,__func__));
  ((x1.a == 16365) ? (void)0 : failure("x1.a == 16365","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",505,__func__));
  ((x1.b == 52228) ? (void)0 : failure("x1.b == 52228","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",506,__func__));
}

void f84(int x0, struct s17 x1)
{
  ((x0 == 1448707066) ? (void)0 : failure("x0 == 1448707066","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",511,__func__));
  ((x1.a == 16458) ? (void)0 : failure("x1.a == 16458","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",512,__func__));
  ((x1.b == 53118) ? (void)0 : failure("x1.b == 53118","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",513,__func__));
}

void f85(double x0, struct s17 x1)
{
  ((x0 == -0x1.f322227d4f5p+1) ? (void)0 : failure("x0 == -0x1.f322227d4f5p+1","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",518,__func__));
  ((x1.a == 8126) ? (void)0 : failure("x1.a == 8126","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",519,__func__));
  ((x1.b == 40711) ? (void)0 : failure("x1.b == 40711","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",520,__func__));
}

struct s18 f86(void)
{
  return (struct s18){-518802928, -180084018};
}

void f87(struct s18 x0)
{
  ((x0.a == 20259) ? (void)0 : failure("x0.a == 20259","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",530,__func__));
  ((x0.b == -1123699173) ? (void)0 : failure("x0.b == -1123699173","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",531,__func__));
}

void f88(struct s18 x0, struct s18 x1)
{
  ((x0.a == 52911) ? (void)0 : failure("x0.a == 52911","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",536,__func__));
  ((x0.b == 1316307988) ? (void)0 : failure("x0.b == 1316307988","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",537,__func__));
  ((x1.a == 23796) ? (void)0 : failure("x1.a == 23796","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",538,__func__));
  ((x1.b == 919168191) ? (void)0 : failure("x1.b == 919168191","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",539,__func__));
}

void f89(int x0, struct s18 x1)
{
  ((x0 == 566498622) ? (void)0 : failure("x0 == 566498622","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",544,__func__));
  ((x1.a == 47067) ? (void)0 : failure("x1.a == 47067","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",545,__func__));
  ((x1.b == -1996126542) ? (void)0 : failure("x1.b == -1996126542","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",546,__func__));
}

void f90(double x0, struct s18 x1)
{
  ((x0 == 0x1.390233be9b4acp+5) ? (void)0 : failure("x0 == 0x1.390233be9b4acp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",551,__func__));
  ((x1.a == 38078) ? (void)0 : failure("x1.a == 38078","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",552,__func__));
  ((x1.b == -218736169) ? (void)0 : failure("x1.b == -218736169","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",553,__func__));
}

struct s19 f91(void)
{
  return (struct s19){-160067175, -1148990584631858503};
}

void f92(struct s19 x0)
{
  ((x0.a == 26934) ? (void)0 : failure("x0.a == 26934","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",563,__func__));
  ((x0.b == 4695337395212137791) ? (void)0 : failure("x0.b == 4695337395212137791","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",564,__func__));
}

void f93(struct s19 x0, struct s19 x1)
{
  ((x0.a == 18443) ? (void)0 : failure("x0.a == 18443","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",569,__func__));
  ((x0.b == 2308107411769263091) ? (void)0 : failure("x0.b == 2308107411769263091","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",570,__func__));
  ((x1.a == 40099) ? (void)0 : failure("x1.a == 40099","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",571,__func__));
  ((x1.b == 853874488809628856) ? (void)0 : failure("x1.b == 853874488809628856","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",572,__func__));
}

void f94(int x0, struct s19 x1)
{
  ((x0 == 1506521253) ? (void)0 : failure("x0 == 1506521253","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",577,__func__));
  ((x1.a == 6834) ? (void)0 : failure("x1.a == 6834","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",578,__func__));
  ((x1.b == -7881179922387171957) ? (void)0 : failure("x1.b == -7881179922387171957","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",579,__func__));
}

void f95(double x0, struct s19 x1)
{
  ((x0 == 0x1.95a932ddd5878p+4) ? (void)0 : failure("x0 == 0x1.95a932ddd5878p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",584,__func__));
  ((x1.a == 30378) ? (void)0 : failure("x1.a == 30378","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",585,__func__));
  ((x1.b == -6366729590814299418) ? (void)0 : failure("x1.b == -6366729590814299418","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",586,__func__));
}

struct s20 f96(void)
{
  return (struct s20){527721521, -0x1.84557f4d8fb77p+4};
}

void f97(struct s20 x0)
{
  ((x0.a == 45369) ? (void)0 : failure("x0.a == 45369","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",596,__func__));
  ((x0.b == -0x1.7fcf88p+5F) ? (void)0 : failure("x0.b == -0x1.7fcf88p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",597,__func__));
}

void f98(struct s20 x0, struct s20 x1)
{
  ((x0.a == 12956) ? (void)0 : failure("x0.a == 12956","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",602,__func__));
  ((x0.b == 0x1.9cacecp+4F) ? (void)0 : failure("x0.b == 0x1.9cacecp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",603,__func__));
  ((x1.a == 6004) ? (void)0 : failure("x1.a == 6004","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",604,__func__));
  ((x1.b == -0x1.111764p+5F) ? (void)0 : failure("x1.b == -0x1.111764p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",605,__func__));
}

void f99(int x0, struct s20 x1)
{
  ((x0 == 244675052) ? (void)0 : failure("x0 == 244675052","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",610,__func__));
  ((x1.a == 24789) ? (void)0 : failure("x1.a == 24789","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",611,__func__));
  ((x1.b == -0x1.869ac4p+5F) ? (void)0 : failure("x1.b == -0x1.869ac4p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",612,__func__));
}

void f100(double x0, struct s20 x1)
{
  ((x0 == 0x1.1366d3bc60632p+5) ? (void)0 : failure("x0 == 0x1.1366d3bc60632p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",617,__func__));
  ((x1.a == 38109) ? (void)0 : failure("x1.a == 38109","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",618,__func__));
  ((x1.b == 0x1.716a62p+5F) ? (void)0 : failure("x1.b == 0x1.716a62p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",619,__func__));
}

struct s21 f101(void)
{
  return (struct s21){-109790911, -0x1.a265f09f9d44bp+4};
}

void f102(struct s21 x0)
{
  ((x0.a == 14396) ? (void)0 : failure("x0.a == 14396","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",629,__func__));
  ((x0.b == -0x1.47ed990b20901p+5) ? (void)0 : failure("x0.b == -0x1.47ed990b20901p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",630,__func__));
}

void f103(struct s21 x0, struct s21 x1)
{
  ((x0.a == 35928) ? (void)0 : failure("x0.a == 35928","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",635,__func__));
  ((x0.b == -0x1.34cf327e7c506p+5) ? (void)0 : failure("x0.b == -0x1.34cf327e7c506p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",636,__func__));
  ((x1.a == 52565) ? (void)0 : failure("x1.a == 52565","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",637,__func__));
  ((x1.b == -0x1.103e8f280c46cp+4) ? (void)0 : failure("x1.b == -0x1.103e8f280c46cp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",638,__func__));
}

void f104(int x0, struct s21 x1)
{
  ((x0 == 1943647114) ? (void)0 : failure("x0 == 1943647114","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",643,__func__));
  ((x1.a == 63711) ? (void)0 : failure("x1.a == 63711","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",644,__func__));
  ((x1.b == 0x1.b8581fe8fe738p+3) ? (void)0 : failure("x1.b == 0x1.b8581fe8fe738p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",645,__func__));
}

void f105(double x0, struct s21 x1)
{
  ((x0 == -0x1.f71a225948d64p+3) ? (void)0 : failure("x0 == -0x1.f71a225948d64p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",650,__func__));
  ((x1.a == 13472) ? (void)0 : failure("x1.a == 13472","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",651,__func__));
  ((x1.b == 0x1.61118e76f0f1ap+5) ? (void)0 : failure("x1.b == 0x1.61118e76f0f1ap+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",652,__func__));
}

struct s22 f106(void)
{
  return (struct s22){1859156861, 282301053};
}

void f107(struct s22 x0)
{
  ((x0.a == -1304936796) ? (void)0 : failure("x0.a == -1304936796","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",662,__func__));
  ((x0.b == 230) ? (void)0 : failure("x0.b == 230","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",663,__func__));
}

void f108(struct s22 x0, struct s22 x1)
{
  ((x0.a == 1062064619) ? (void)0 : failure("x0.a == 1062064619","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",668,__func__));
  ((x0.b == 71) ? (void)0 : failure("x0.b == 71","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",669,__func__));
  ((x1.a == -367540222) ? (void)0 : failure("x1.a == -367540222","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",670,__func__));
  ((x1.b == 101) ? (void)0 : failure("x1.b == 101","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",671,__func__));
}

void f109(int x0, struct s22 x1)
{
  ((x0 == 866633562) ? (void)0 : failure("x0 == 866633562","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",676,__func__));
  ((x1.a == 783218622) ? (void)0 : failure("x1.a == 783218622","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",677,__func__));
  ((x1.b == 241) ? (void)0 : failure("x1.b == 241","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",678,__func__));
}

void f110(double x0, struct s22 x1)
{
  ((x0 == 0x1.8eb2dd062617p+5) ? (void)0 : failure("x0 == 0x1.8eb2dd062617p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",683,__func__));
  ((x1.a == -1592439001) ? (void)0 : failure("x1.a == -1592439001","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",684,__func__));
  ((x1.b == 186) ? (void)0 : failure("x1.b == 186","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",685,__func__));
}

struct s23 f111(void)
{
  return (struct s23){246019086, 287494752};
}

void f112(struct s23 x0)
{
  ((x0.a == -55831904) ? (void)0 : failure("x0.a == -55831904","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",695,__func__));
  ((x0.b == 35132) ? (void)0 : failure("x0.b == 35132","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",696,__func__));
}

void f113(struct s23 x0, struct s23 x1)
{
  ((x0.a == 1416852830) ? (void)0 : failure("x0.a == 1416852830","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",701,__func__));
  ((x0.b == 27897) ? (void)0 : failure("x0.b == 27897","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",702,__func__));
  ((x1.a == -1403118349) ? (void)0 : failure("x1.a == -1403118349","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",703,__func__));
  ((x1.b == 19402) ? (void)0 : failure("x1.b == 19402","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",704,__func__));
}

void f114(int x0, struct s23 x1)
{
  ((x0 == -2122589996) ? (void)0 : failure("x0 == -2122589996","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",709,__func__));
  ((x1.a == 129359416) ? (void)0 : failure("x1.a == 129359416","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",710,__func__));
  ((x1.b == 55849) ? (void)0 : failure("x1.b == 55849","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",711,__func__));
}

void f115(double x0, struct s23 x1)
{
  ((x0 == -0x1.cabda96e77868p+3) ? (void)0 : failure("x0 == -0x1.cabda96e77868p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",716,__func__));
  ((x1.a == -1279079508) ? (void)0 : failure("x1.a == -1279079508","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",717,__func__));
  ((x1.b == 54912) ? (void)0 : failure("x1.b == 54912","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",718,__func__));
}

struct s24 f116(void)
{
  return (struct s24){-1812095004, 1890498760};
}

void f117(struct s24 x0)
{
  ((x0.a == 682879303) ? (void)0 : failure("x0.a == 682879303","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",728,__func__));
  ((x0.b == 1996844329) ? (void)0 : failure("x0.b == 1996844329","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",729,__func__));
}

void f118(struct s24 x0, struct s24 x1)
{
  ((x0.a == -596900446) ? (void)0 : failure("x0.a == -596900446","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",734,__func__));
  ((x0.b == -1719405343) ? (void)0 : failure("x0.b == -1719405343","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",735,__func__));
  ((x1.a == 1837081861) ? (void)0 : failure("x1.a == 1837081861","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",736,__func__));
  ((x1.b == -873812894) ? (void)0 : failure("x1.b == -873812894","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",737,__func__));
}

void f119(int x0, struct s24 x1)
{
  ((x0 == 353368475) ? (void)0 : failure("x0 == 353368475","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",742,__func__));
  ((x1.a == -1256030666) ? (void)0 : failure("x1.a == -1256030666","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",743,__func__));
  ((x1.b == 2028339913) ? (void)0 : failure("x1.b == 2028339913","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",744,__func__));
}

void f120(double x0, struct s24 x1)
{
  ((x0 == 0x1.603d4384a88p+3) ? (void)0 : failure("x0 == 0x1.603d4384a88p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",749,__func__));
  ((x1.a == -556428407) ? (void)0 : failure("x1.a == -556428407","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",750,__func__));
  ((x1.b == -152436980) ? (void)0 : failure("x1.b == -152436980","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",751,__func__));
}

struct s25 f121(void)
{
  return (struct s25){-1280826129, -7316568651887840872};
}

void f122(struct s25 x0)
{
  ((x0.a == 1062776017) ? (void)0 : failure("x0.a == 1062776017","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",761,__func__));
  ((x0.b == -9010939211461274409) ? (void)0 : failure("x0.b == -9010939211461274409","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",762,__func__));
}

void f123(struct s25 x0, struct s25 x1)
{
  ((x0.a == 164787212) ? (void)0 : failure("x0.a == 164787212","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",767,__func__));
  ((x0.b == 7988486642612859523) ? (void)0 : failure("x0.b == 7988486642612859523","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",768,__func__));
  ((x1.a == -1211633452) ? (void)0 : failure("x1.a == -1211633452","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",769,__func__));
  ((x1.b == 4853087427906869595) ? (void)0 : failure("x1.b == 4853087427906869595","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",770,__func__));
}

void f124(int x0, struct s25 x1)
{
  ((x0 == -1128257059) ? (void)0 : failure("x0 == -1128257059","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",775,__func__));
  ((x1.a == -651978519) ? (void)0 : failure("x1.a == -651978519","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",776,__func__));
  ((x1.b == -1081522815091978829) ? (void)0 : failure("x1.b == -1081522815091978829","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",777,__func__));
}

void f125(double x0, struct s25 x1)
{
  ((x0 == 0x1.d6a006879d244p+4) ? (void)0 : failure("x0 == 0x1.d6a006879d244p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",782,__func__));
  ((x1.a == -409421860) ? (void)0 : failure("x1.a == -409421860","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",783,__func__));
  ((x1.b == -4100805016390209027) ? (void)0 : failure("x1.b == -4100805016390209027","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",784,__func__));
}

struct s26 f126(void)
{
  return (struct s26){-510167021, -0x1.0fcd96ac180dfp+5};
}

void f127(struct s26 x0)
{
  ((x0.a == 1571964502) ? (void)0 : failure("x0.a == 1571964502","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",794,__func__));
  ((x0.b == 0x1.87775ap+4F) ? (void)0 : failure("x0.b == 0x1.87775ap+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",795,__func__));
}

void f128(struct s26 x0, struct s26 x1)
{
  ((x0.a == -686332331) ? (void)0 : failure("x0.a == -686332331","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",800,__func__));
  ((x0.b == -0x1.185584p+5F) ? (void)0 : failure("x0.b == -0x1.185584p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",801,__func__));
  ((x1.a == -1172813156) ? (void)0 : failure("x1.a == -1172813156","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",802,__func__));
  ((x1.b == -0x1.df67c4p+1F) ? (void)0 : failure("x1.b == -0x1.df67c4p+1F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",803,__func__));
}

void f129(int x0, struct s26 x1)
{
  ((x0 == -1742504644) ? (void)0 : failure("x0 == -1742504644","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",808,__func__));
  ((x1.a == -750563089) ? (void)0 : failure("x1.a == -750563089","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",809,__func__));
  ((x1.b == -0x1.4c8af6p+5F) ? (void)0 : failure("x1.b == -0x1.4c8af6p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",810,__func__));
}

void f130(double x0, struct s26 x1)
{
  ((x0 == 0x1.4e5f19dee8188p+2) ? (void)0 : failure("x0 == 0x1.4e5f19dee8188p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",815,__func__));
  ((x1.a == -1538611978) ? (void)0 : failure("x1.a == -1538611978","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",816,__func__));
  ((x1.b == 0x1.5b25aap+3F) ? (void)0 : failure("x1.b == 0x1.5b25aap+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",817,__func__));
}

struct s27 f131(void)
{
  return (struct s27){-1473845158, 0x1.6c855f5d7163cp+4};
}

void f132(struct s27 x0)
{
  ((x0.a == -304810474) ? (void)0 : failure("x0.a == -304810474","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",827,__func__));
  ((x0.b == 0x1.b8e539e4752bp+3) ? (void)0 : failure("x0.b == 0x1.b8e539e4752bp+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",828,__func__));
}

void f133(struct s27 x0, struct s27 x1)
{
  ((x0.a == -578950471) ? (void)0 : failure("x0.a == -578950471","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",833,__func__));
  ((x0.b == 0x1.39ecb3dea4d58p+2) ? (void)0 : failure("x0.b == 0x1.39ecb3dea4d58p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",834,__func__));
  ((x1.a == -1387722108) ? (void)0 : failure("x1.a == -1387722108","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",835,__func__));
  ((x1.b == 0x1.a58f505e191p-2) ? (void)0 : failure("x1.b == 0x1.a58f505e191p-2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",836,__func__));
}

void f134(int x0, struct s27 x1)
{
  ((x0 == 1408255155) ? (void)0 : failure("x0 == 1408255155","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",841,__func__));
  ((x1.a == -1991287261) ? (void)0 : failure("x1.a == -1991287261","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",842,__func__));
  ((x1.b == -0x1.b7c07b72f4fedp+4) ? (void)0 : failure("x1.b == -0x1.b7c07b72f4fedp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",843,__func__));
}

void f135(double x0, struct s27 x1)
{
  ((x0 == 0x1.279ee5a10222p+5) ? (void)0 : failure("x0 == 0x1.279ee5a10222p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",848,__func__));
  ((x1.a == 1408947757) ? (void)0 : failure("x1.a == 1408947757","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",849,__func__));
  ((x1.b == -0x1.acbdf9a1b5766p+4) ? (void)0 : failure("x1.b == -0x1.acbdf9a1b5766p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",850,__func__));
}

struct s28 f136(void)
{
  return (struct s28){-7378056962774999617, 465058032};
}

void f137(struct s28 x0)
{
  ((x0.a == 3005607600168193821) ? (void)0 : failure("x0.a == 3005607600168193821","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",860,__func__));
  ((x0.b == 148) ? (void)0 : failure("x0.b == 148","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",861,__func__));
}

void f138(struct s28 x0, struct s28 x1)
{
  ((x0.a == 5011935939289949336) ? (void)0 : failure("x0.a == 5011935939289949336","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",866,__func__));
  ((x0.b == 186) ? (void)0 : failure("x0.b == 186","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",867,__func__));
  ((x1.a == -6736231869584637411) ? (void)0 : failure("x1.a == -6736231869584637411","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",868,__func__));
  ((x1.b == 37) ? (void)0 : failure("x1.b == 37","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",869,__func__));
}

void f139(int x0, struct s28 x1)
{
  ((x0 == 568895837) ? (void)0 : failure("x0 == 568895837","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",874,__func__));
  ((x1.a == -2823089690153465173) ? (void)0 : failure("x1.a == -2823089690153465173","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",875,__func__));
  ((x1.b == 88) ? (void)0 : failure("x1.b == 88","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",876,__func__));
}

void f140(double x0, struct s28 x1)
{
  ((x0 == -0x1.0fdefcd5c7502p+5) ? (void)0 : failure("x0 == -0x1.0fdefcd5c7502p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",881,__func__));
  ((x1.a == 7019838422983881864) ? (void)0 : failure("x1.a == 7019838422983881864","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",882,__func__));
  ((x1.b == 25) ? (void)0 : failure("x1.b == 25","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",883,__func__));
}

struct s29 f141(void)
{
  return (struct s29){-4946767010283495353, 290195719};
}

void f142(struct s29 x0)
{
  ((x0.a == 2141993738737130324) ? (void)0 : failure("x0.a == 2141993738737130324","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",893,__func__));
  ((x0.b == 65028) ? (void)0 : failure("x0.b == 65028","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",894,__func__));
}

void f143(struct s29 x0, struct s29 x1)
{
  ((x0.a == 9199081016697467462) ? (void)0 : failure("x0.a == 9199081016697467462","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",899,__func__));
  ((x0.b == 23575) ? (void)0 : failure("x0.b == 23575","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",900,__func__));
  ((x1.a == -3589997681132222015) ? (void)0 : failure("x1.a == -3589997681132222015","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",901,__func__));
  ((x1.b == 6338) ? (void)0 : failure("x1.b == 6338","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",902,__func__));
}

void f144(int x0, struct s29 x1)
{
  ((x0 == -1571880597) ? (void)0 : failure("x0 == -1571880597","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",907,__func__));
  ((x1.a == -4004709014795347406) ? (void)0 : failure("x1.a == -4004709014795347406","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",908,__func__));
  ((x1.b == 42337) ? (void)0 : failure("x1.b == 42337","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",909,__func__));
}

void f145(double x0, struct s29 x1)
{
  ((x0 == -0x1.438dbf1dbd2a4p+5) ? (void)0 : failure("x0 == -0x1.438dbf1dbd2a4p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",914,__func__));
  ((x1.a == -4162783042393750771) ? (void)0 : failure("x1.a == -4162783042393750771","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",915,__func__));
  ((x1.b == 45745) ? (void)0 : failure("x1.b == 45745","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",916,__func__));
}

struct s30 f146(void)
{
  return (struct s30){-5480136876204796410, -734103738};
}

void f147(struct s30 x0)
{
  ((x0.a == -7161632261904739433) ? (void)0 : failure("x0.a == -7161632261904739433","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",926,__func__));
  ((x0.b == 384679893) ? (void)0 : failure("x0.b == 384679893","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",927,__func__));
}

void f148(struct s30 x0, struct s30 x1)
{
  ((x0.a == 1655943856802705669) ? (void)0 : failure("x0.a == 1655943856802705669","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",932,__func__));
  ((x0.b == -15766459) ? (void)0 : failure("x0.b == -15766459","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",933,__func__));
  ((x1.a == 2785457078199258533) ? (void)0 : failure("x1.a == 2785457078199258533","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",934,__func__));
  ((x1.b == -1219071335) ? (void)0 : failure("x1.b == -1219071335","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",935,__func__));
}

void f149(int x0, struct s30 x1)
{
  ((x0 == -860567012) ? (void)0 : failure("x0 == -860567012","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",940,__func__));
  ((x1.a == 8701319485013396684) ? (void)0 : failure("x1.a == 8701319485013396684","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",941,__func__));
  ((x1.b == 397458395) ? (void)0 : failure("x1.b == 397458395","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",942,__func__));
}

void f150(double x0, struct s30 x1)
{
  ((x0 == -0x1.41052823ef161p+5) ? (void)0 : failure("x0 == -0x1.41052823ef161p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",947,__func__));
  ((x1.a == 7672003959483129798) ? (void)0 : failure("x1.a == 7672003959483129798","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",948,__func__));
  ((x1.b == -237702836) ? (void)0 : failure("x1.b == -237702836","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",949,__func__));
}

struct s31 f151(void)
{
  return (struct s31){-710116634788725456, -1125746084457454639};
}

void f152(struct s31 x0)
{
  ((x0.a == -2867377179166082689) ? (void)0 : failure("x0.a == -2867377179166082689","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",959,__func__));
  ((x0.b == 2438115870243609249) ? (void)0 : failure("x0.b == 2438115870243609249","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",960,__func__));
}

void f153(struct s31 x0, struct s31 x1)
{
  ((x0.a == -5567481585363274997) ? (void)0 : failure("x0.a == -5567481585363274997","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",965,__func__));
  ((x0.b == -5810483165404764631) ? (void)0 : failure("x0.b == -5810483165404764631","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",966,__func__));
  ((x1.a == -5673725954458197362) ? (void)0 : failure("x1.a == -5673725954458197362","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",967,__func__));
  ((x1.b == -7902545747332296229) ? (void)0 : failure("x1.b == -7902545747332296229","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",968,__func__));
}

void f154(int x0, struct s31 x1)
{
  ((x0 == 445643060) ? (void)0 : failure("x0 == 445643060","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",973,__func__));
  ((x1.a == -6407157356906237087) ? (void)0 : failure("x1.a == -6407157356906237087","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",974,__func__));
  ((x1.b == -7912635108962811880) ? (void)0 : failure("x1.b == -7912635108962811880","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",975,__func__));
}

void f155(double x0, struct s31 x1)
{
  ((x0 == 0x1.2fc80b7609958p+2) ? (void)0 : failure("x0 == 0x1.2fc80b7609958p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",980,__func__));
  ((x1.a == 10246336403069655) ? (void)0 : failure("x1.a == 10246336403069655","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",981,__func__));
  ((x1.b == -7998521500189979172) ? (void)0 : failure("x1.b == -7998521500189979172","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",982,__func__));
}

struct s32 f156(void)
{
  return (struct s32){4662808498417018043, 0x1.5d12e1fbd097p+4};
}

void f157(struct s32 x0)
{
  ((x0.a == 1775746362653330738) ? (void)0 : failure("x0.a == 1775746362653330738","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",992,__func__));
  ((x0.b == 0x1.2a97cep+4F) ? (void)0 : failure("x0.b == 0x1.2a97cep+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",993,__func__));
}

void f158(struct s32 x0, struct s32 x1)
{
  ((x0.a == 5863448758647772447) ? (void)0 : failure("x0.a == 5863448758647772447","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",998,__func__));
  ((x0.b == -0x1.cb2d6p+3F) ? (void)0 : failure("x0.b == -0x1.cb2d6p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",999,__func__));
  ((x1.a == -5996218570252070921) ? (void)0 : failure("x1.a == -5996218570252070921","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1000,__func__));
  ((x1.b == -0x1.ebd756p+2F) ? (void)0 : failure("x1.b == -0x1.ebd756p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1001,__func__));
}

void f159(int x0, struct s32 x1)
{
  ((x0 == -1738047084) ? (void)0 : failure("x0 == -1738047084","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1006,__func__));
  ((x1.a == -85604440416876734) ? (void)0 : failure("x1.a == -85604440416876734","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1007,__func__));
  ((x1.b == -0x1.fd9a8cp-2F) ? (void)0 : failure("x1.b == -0x1.fd9a8cp-2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1008,__func__));
}

void f160(double x0, struct s32 x1)
{
  ((x0 == 0x1.09215a7850c92p+5) ? (void)0 : failure("x0 == 0x1.09215a7850c92p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1013,__func__));
  ((x1.a == -2343741634815828736) ? (void)0 : failure("x1.a == -2343741634815828736","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1014,__func__));
  ((x1.b == -0x1.6be4cap+4F) ? (void)0 : failure("x1.b == -0x1.6be4cap+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1015,__func__));
}

struct s33 f161(void)
{
  return (struct s33){8242811742561973546, 0x1.469ae34a12b72p+5};
}

void f162(struct s33 x0)
{
  ((x0.a == 8187654296218072904) ? (void)0 : failure("x0.a == 8187654296218072904","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1025,__func__));
  ((x0.b == -0x1.c422a91b28c18p+2) ? (void)0 : failure("x0.b == -0x1.c422a91b28c18p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1026,__func__));
}

void f163(struct s33 x0, struct s33 x1)
{
  ((x0.a == 568840137674323020) ? (void)0 : failure("x0.a == 568840137674323020","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1031,__func__));
  ((x0.b == 0x1.850fd04e7cb24p+4) ? (void)0 : failure("x0.b == 0x1.850fd04e7cb24p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1032,__func__));
  ((x1.a == 3956869377390794029) ? (void)0 : failure("x1.a == 3956869377390794029","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1033,__func__));
  ((x1.b == 0x1.429c0861059a6p+5) ? (void)0 : failure("x1.b == 0x1.429c0861059a6p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1034,__func__));
}

void f164(int x0, struct s33 x1)
{
  ((x0 == -1479552307) ? (void)0 : failure("x0 == -1479552307","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1039,__func__));
  ((x1.a == -4404512927516861989) ? (void)0 : failure("x1.a == -4404512927516861989","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1040,__func__));
  ((x1.b == 0x1.85d985f7deab4p+5) ? (void)0 : failure("x1.b == 0x1.85d985f7deab4p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1041,__func__));
}

void f165(double x0, struct s33 x1)
{
  ((x0 == 0x1.a0531f84aefe4p+4) ? (void)0 : failure("x0 == 0x1.a0531f84aefe4p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1046,__func__));
  ((x1.a == 3411710355216270447) ? (void)0 : failure("x1.a == 3411710355216270447","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1047,__func__));
  ((x1.b == -0x1.fabbfed91e862p+4) ? (void)0 : failure("x1.b == -0x1.fabbfed91e862p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1048,__func__));
}

struct s34 f166(void)
{
  return (struct s34){-0x1.7860eae198ed4p+4, -330285196};
}

void f167(struct s34 x0)
{
  ((x0.a == -0x1.1ccf16p+3F) ? (void)0 : failure("x0.a == -0x1.1ccf16p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1058,__func__));
  ((x0.b == 221) ? (void)0 : failure("x0.b == 221","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1059,__func__));
}

void f168(struct s34 x0, struct s34 x1)
{
  ((x0.a == -0x1.287ee6p+5F) ? (void)0 : failure("x0.a == -0x1.287ee6p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1064,__func__));
  ((x0.b == 245) ? (void)0 : failure("x0.b == 245","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1065,__func__));
  ((x1.a == 0x1.217fp+2F) ? (void)0 : failure("x1.a == 0x1.217fp+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1066,__func__));
  ((x1.b == 93) ? (void)0 : failure("x1.b == 93","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1067,__func__));
}

void f169(int x0, struct s34 x1)
{
  ((x0 == -1152060004) ? (void)0 : failure("x0 == -1152060004","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1072,__func__));
  ((x1.a == 0x1.2a87fp+5F) ? (void)0 : failure("x1.a == 0x1.2a87fp+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1073,__func__));
  ((x1.b == 47) ? (void)0 : failure("x1.b == 47","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1074,__func__));
}

void f170(double x0, struct s34 x1)
{
  ((x0 == -0x1.667ca9d844338p+5) ? (void)0 : failure("x0 == -0x1.667ca9d844338p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1079,__func__));
  ((x1.a == -0x1.31887cp+2F) ? (void)0 : failure("x1.a == -0x1.31887cp+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1080,__func__));
  ((x1.b == 165) ? (void)0 : failure("x1.b == 165","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1081,__func__));
}

struct s35 f171(void)
{
  return (struct s35){-0x1.1f56614742eedp+5, -329433332};
}

void f172(struct s35 x0)
{
  ((x0.a == 0x1.4db9bp+5F) ? (void)0 : failure("x0.a == 0x1.4db9bp+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1091,__func__));
  ((x0.b == 58051) ? (void)0 : failure("x0.b == 58051","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1092,__func__));
}

void f173(struct s35 x0, struct s35 x1)
{
  ((x0.a == 0x1.a5d26p+4F) ? (void)0 : failure("x0.a == 0x1.a5d26p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1097,__func__));
  ((x0.b == 37578) ? (void)0 : failure("x0.b == 37578","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1098,__func__));
  ((x1.a == 0x1.9d0bb2p+4F) ? (void)0 : failure("x1.a == 0x1.9d0bb2p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1099,__func__));
  ((x1.b == 13266) ? (void)0 : failure("x1.b == 13266","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1100,__func__));
}

void f174(int x0, struct s35 x1)
{
  ((x0 == -908212935) ? (void)0 : failure("x0 == -908212935","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1105,__func__));
  ((x1.a == -0x1.58bc1cp+4F) ? (void)0 : failure("x1.a == -0x1.58bc1cp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1106,__func__));
  ((x1.b == 39395) ? (void)0 : failure("x1.b == 39395","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1107,__func__));
}

void f175(double x0, struct s35 x1)
{
  ((x0 == -0x1.33d3579316aa4p+4) ? (void)0 : failure("x0 == -0x1.33d3579316aa4p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1112,__func__));
  ((x1.a == 0x1.c419dep+0F) ? (void)0 : failure("x1.a == 0x1.c419dep+0F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1113,__func__));
  ((x1.b == 63664) ? (void)0 : failure("x1.b == 63664","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1114,__func__));
}

struct s36 f176(void)
{
  return (struct s36){-0x1.345574cd53158p+2, -1344140964};
}

void f177(struct s36 x0)
{
  ((x0.a == 0x1.f359cap+4F) ? (void)0 : failure("x0.a == 0x1.f359cap+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1124,__func__));
  ((x0.b == 1515530165) ? (void)0 : failure("x0.b == 1515530165","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1125,__func__));
}

void f178(struct s36 x0, struct s36 x1)
{
  ((x0.a == 0x1.5b7388p+5F) ? (void)0 : failure("x0.a == 0x1.5b7388p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1130,__func__));
  ((x0.b == 138831035) ? (void)0 : failure("x0.b == 138831035","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1131,__func__));
  ((x1.a == -0x1.385b36p+5F) ? (void)0 : failure("x1.a == -0x1.385b36p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1132,__func__));
  ((x1.b == 524632817) ? (void)0 : failure("x1.b == 524632817","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1133,__func__));
}

void f179(int x0, struct s36 x1)
{
  ((x0 == -574292381) ? (void)0 : failure("x0 == -574292381","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1138,__func__));
  ((x1.a == 0x1.a927eap+3F) ? (void)0 : failure("x1.a == 0x1.a927eap+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1139,__func__));
  ((x1.b == -1003427730) ? (void)0 : failure("x1.b == -1003427730","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1140,__func__));
}

void f180(double x0, struct s36 x1)
{
  ((x0 == 0x1.0f4f003a1f3c8p+5) ? (void)0 : failure("x0 == 0x1.0f4f003a1f3c8p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1145,__func__));
  ((x1.a == -0x1.2650cep+5F) ? (void)0 : failure("x1.a == -0x1.2650cep+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1146,__func__));
  ((x1.b == 73517053) ? (void)0 : failure("x1.b == 73517053","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1147,__func__));
}

struct s37 f181(void)
{
  return (struct s37){0x1.bd2128998c488p+2, -2814264140199828456};
}

void f182(struct s37 x0)
{
  ((x0.a == 0x1.373314p+5F) ? (void)0 : failure("x0.a == 0x1.373314p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1157,__func__));
  ((x0.b == -2904724171930145257) ? (void)0 : failure("x0.b == -2904724171930145257","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1158,__func__));
}

void f183(struct s37 x0, struct s37 x1)
{
  ((x0.a == 0x1.ceab26p+4F) ? (void)0 : failure("x0.a == 0x1.ceab26p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1163,__func__));
  ((x0.b == -4684592017084951337) ? (void)0 : failure("x0.b == -4684592017084951337","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1164,__func__));
  ((x1.a == 0x1.245752p+5F) ? (void)0 : failure("x1.a == 0x1.245752p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1165,__func__));
  ((x1.b == 8811506025757711315) ? (void)0 : failure("x1.b == 8811506025757711315","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1166,__func__));
}

void f184(int x0, struct s37 x1)
{
  ((x0 == 776883879) ? (void)0 : failure("x0 == 776883879","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1171,__func__));
  ((x1.a == -0x1.9bcd7ep+1F) ? (void)0 : failure("x1.a == -0x1.9bcd7ep+1F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1172,__func__));
  ((x1.b == 8724643086277304086) ? (void)0 : failure("x1.b == 8724643086277304086","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1173,__func__));
}

void f185(double x0, struct s37 x1)
{
  ((x0 == 0x1.0c920cc7eaf44p+3) ? (void)0 : failure("x0 == 0x1.0c920cc7eaf44p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1178,__func__));
  ((x1.a == 0x1.fa9f7p+4F) ? (void)0 : failure("x1.a == 0x1.fa9f7p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1179,__func__));
  ((x1.b == 5051693522324474451) ? (void)0 : failure("x1.b == 5051693522324474451","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1180,__func__));
}

struct s38 f186(void)
{
  return (struct s38){-0x1.85e2d50c5e853p+5, -0x1.cb029a0898ab6p+4};
}

void f187(struct s38 x0)
{
  ((x0.a == -0x1.13eabcp+3F) ? (void)0 : failure("x0.a == -0x1.13eabcp+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1190,__func__));
  ((x0.b == -0x1.a701c4p+2F) ? (void)0 : failure("x0.b == -0x1.a701c4p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1191,__func__));
}

void f188(struct s38 x0, struct s38 x1)
{
  ((x0.a == 0x1.ccd0aap+4F) ? (void)0 : failure("x0.a == 0x1.ccd0aap+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1196,__func__));
  ((x0.b == -0x1.8ed30ep+4F) ? (void)0 : failure("x0.b == -0x1.8ed30ep+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1197,__func__));
  ((x1.a == -0x1.7b7bdcp+5F) ? (void)0 : failure("x1.a == -0x1.7b7bdcp+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1198,__func__));
  ((x1.b == 0x1.340a12p+4F) ? (void)0 : failure("x1.b == 0x1.340a12p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1199,__func__));
}

void f189(int x0, struct s38 x1)
{
  ((x0 == 1032177843) ? (void)0 : failure("x0 == 1032177843","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1204,__func__));
  ((x1.a == -0x1.01b14ap+4F) ? (void)0 : failure("x1.a == -0x1.01b14ap+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1205,__func__));
  ((x1.b == 0x1.2e34c4p+5F) ? (void)0 : failure("x1.b == 0x1.2e34c4p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1206,__func__));
}

void f190(double x0, struct s38 x1)
{
  ((x0 == -0x1.c1d1a68b26be8p+3) ? (void)0 : failure("x0 == -0x1.c1d1a68b26be8p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1211,__func__));
  ((x1.a == 0x1.3401a6p+5F) ? (void)0 : failure("x1.a == 0x1.3401a6p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1212,__func__));
  ((x1.b == 0x1.49059ap+4F) ? (void)0 : failure("x1.b == 0x1.49059ap+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1213,__func__));
}

struct s39 f191(void)
{
  return (struct s39){0x1.21c25eadc2568p+5, -0x1.6e5e475105fp+2};
}

void f192(struct s39 x0)
{
  ((x0.a == 0x1.968e96p+4F) ? (void)0 : failure("x0.a == 0x1.968e96p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1223,__func__));
  ((x0.b == 0x1.1626110abf4p+4) ? (void)0 : failure("x0.b == 0x1.1626110abf4p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1224,__func__));
}

void f193(struct s39 x0, struct s39 x1)
{
  ((x0.a == 0x1.9096eap+3F) ? (void)0 : failure("x0.a == 0x1.9096eap+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1229,__func__));
  ((x0.b == 0x1.506d3f537276p+5) ? (void)0 : failure("x0.b == 0x1.506d3f537276p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1230,__func__));
  ((x1.a == -0x1.16b7eap+5F) ? (void)0 : failure("x1.a == -0x1.16b7eap+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1231,__func__));
  ((x1.b == 0x1.2ad880962da54p+5) ? (void)0 : failure("x1.b == 0x1.2ad880962da54p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1232,__func__));
}

void f194(int x0, struct s39 x1)
{
  ((x0 == 1513575343) ? (void)0 : failure("x0 == 1513575343","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1237,__func__));
  ((x1.a == 0x1.40d68p+4F) ? (void)0 : failure("x1.a == 0x1.40d68p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1238,__func__));
  ((x1.b == -0x1.82cba080090ep+2) ? (void)0 : failure("x1.b == -0x1.82cba080090ep+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1239,__func__));
}

void f195(double x0, struct s39 x1)
{
  ((x0 == -0x1.d69b6d766f33cp+3) ? (void)0 : failure("x0 == -0x1.d69b6d766f33cp+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1244,__func__));
  ((x1.a == 0x1.dca3b8p+0F) ? (void)0 : failure("x1.a == 0x1.dca3b8p+0F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1245,__func__));
  ((x1.b == 0x1.16443a1bbcc9ep+5) ? (void)0 : failure("x1.b == 0x1.16443a1bbcc9ep+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1246,__func__));
}

struct s40 f196(void)
{
  return (struct s40){-0x1.5ee3e8f11e13p+3, 449637252};
}

void f197(struct s40 x0)
{
  ((x0.a == -0x1.6670a18344cfcp+4) ? (void)0 : failure("x0.a == -0x1.6670a18344cfcp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1256,__func__));
  ((x0.b == 243) ? (void)0 : failure("x0.b == 243","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1257,__func__));
}

void f198(struct s40 x0, struct s40 x1)
{
  ((x0.a == -0x1.5055ea4a0abp+5) ? (void)0 : failure("x0.a == -0x1.5055ea4a0abp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1262,__func__));
  ((x0.b == 182) ? (void)0 : failure("x0.b == 182","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1263,__func__));
  ((x1.a == 0x1.53a980f365beep+5) ? (void)0 : failure("x1.a == 0x1.53a980f365beep+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1264,__func__));
  ((x1.b == 152) ? (void)0 : failure("x1.b == 152","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1265,__func__));
}

void f199(int x0, struct s40 x1)
{
  ((x0 == -1650214369) ? (void)0 : failure("x0 == -1650214369","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1270,__func__));
  ((x1.a == 0x1.53468e56a9c94p+5) ? (void)0 : failure("x1.a == 0x1.53468e56a9c94p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1271,__func__));
  ((x1.b == 102) ? (void)0 : failure("x1.b == 102","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1272,__func__));
}

void f200(double x0, struct s40 x1)
{
  ((x0 == -0x1.cc00496a40a53p+4) ? (void)0 : failure("x0 == -0x1.cc00496a40a53p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1277,__func__));
  ((x1.a == -0x1.542f4b75417a4p+4) ? (void)0 : failure("x1.a == -0x1.542f4b75417a4p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1278,__func__));
  ((x1.b == 13) ? (void)0 : failure("x1.b == 13","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1279,__func__));
}

struct s41 f201(void)
{
  return (struct s41){-0x1.1262ec08c024bp+5, -188365166};
}

void f202(struct s41 x0)
{
  ((x0.a == -0x1.61240d686e5b3p+5) ? (void)0 : failure("x0.a == -0x1.61240d686e5b3p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1289,__func__));
  ((x0.b == 31739) ? (void)0 : failure("x0.b == 31739","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1290,__func__));
}

void f203(struct s41 x0, struct s41 x1)
{
  ((x0.a == 0x1.ae05f06d853bcp+4) ? (void)0 : failure("x0.a == 0x1.ae05f06d853bcp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1295,__func__));
  ((x0.b == 65242) ? (void)0 : failure("x0.b == 65242","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1296,__func__));
  ((x1.a == -0x1.1c71affe41b9cp+5) ? (void)0 : failure("x1.a == -0x1.1c71affe41b9cp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1297,__func__));
  ((x1.b == 39294) ? (void)0 : failure("x1.b == 39294","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1298,__func__));
}

void f204(int x0, struct s41 x1)
{
  ((x0 == -664509735) ? (void)0 : failure("x0 == -664509735","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1303,__func__));
  ((x1.a == 0x1.d3e3008d5e254p+4) ? (void)0 : failure("x1.a == 0x1.d3e3008d5e254p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1304,__func__));
  ((x1.b == 56787) ? (void)0 : failure("x1.b == 56787","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1305,__func__));
}

void f205(double x0, struct s41 x1)
{
  ((x0 == 0x1.456f981cf6fc8p+4) ? (void)0 : failure("x0 == 0x1.456f981cf6fc8p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1310,__func__));
  ((x1.a == -0x1.3b491b7a87698p+4) ? (void)0 : failure("x1.a == -0x1.3b491b7a87698p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1311,__func__));
  ((x1.b == 16624) ? (void)0 : failure("x1.b == 16624","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1312,__func__));
}

struct s42 f206(void)
{
  return (struct s42){0x1.2a67453a68c8cp+5, 421485310};
}

void f207(struct s42 x0)
{
  ((x0.a == 0x1.a6193dbcbc8fp+4) ? (void)0 : failure("x0.a == 0x1.a6193dbcbc8fp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1322,__func__));
  ((x0.b == 2047251715) ? (void)0 : failure("x0.b == 2047251715","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1323,__func__));
}

void f208(struct s42 x0, struct s42 x1)
{
  ((x0.a == 0x1.de529c6fe3718p+4) ? (void)0 : failure("x0.a == 0x1.de529c6fe3718p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1328,__func__));
  ((x0.b == -835133062) ? (void)0 : failure("x0.b == -835133062","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1329,__func__));
  ((x1.a == 0x1.7ddd738872c1p+5) ? (void)0 : failure("x1.a == 0x1.7ddd738872c1p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1330,__func__));
  ((x1.b == -1442257695) ? (void)0 : failure("x1.b == -1442257695","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1331,__func__));
}

void f209(int x0, struct s42 x1)
{
  ((x0 == -1967902239) ? (void)0 : failure("x0 == -1967902239","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1336,__func__));
  ((x1.a == 0x1.2a7bdb5479ddp+4) ? (void)0 : failure("x1.a == 0x1.2a7bdb5479ddp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1337,__func__));
  ((x1.b == -743385001) ? (void)0 : failure("x1.b == -743385001","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1338,__func__));
}

void f210(double x0, struct s42 x1)
{
  ((x0 == -0x1.5b917bfede58fp+5) ? (void)0 : failure("x0 == -0x1.5b917bfede58fp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1343,__func__));
  ((x1.a == 0x1.6a267c3ac7014p+3) ? (void)0 : failure("x1.a == 0x1.6a267c3ac7014p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1344,__func__));
  ((x1.b == -197257186) ? (void)0 : failure("x1.b == -197257186","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1345,__func__));
}

struct s43 f211(void)
{
  return (struct s43){0x1.8b69b9837f16p+0, -3274147762378740424};
}

void f212(struct s43 x0)
{
  ((x0.a == 0x1.3d28293c75148p+2) ? (void)0 : failure("x0.a == 0x1.3d28293c75148p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1355,__func__));
  ((x0.b == -7321829404139722879) ? (void)0 : failure("x0.b == -7321829404139722879","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1356,__func__));
}

void f213(struct s43 x0, struct s43 x1)
{
  ((x0.a == -0x1.45d4a9ae55716p+4) ? (void)0 : failure("x0.a == -0x1.45d4a9ae55716p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1361,__func__));
  ((x0.b == -3118147426284939155) ? (void)0 : failure("x0.b == -3118147426284939155","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1362,__func__));
  ((x1.a == -0x1.6b390de7bf05dp+5) ? (void)0 : failure("x1.a == -0x1.6b390de7bf05dp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1363,__func__));
  ((x1.b == -8026731829316443005) ? (void)0 : failure("x1.b == -8026731829316443005","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1364,__func__));
}

void f214(int x0, struct s43 x1)
{
  ((x0 == -237130372) ? (void)0 : failure("x0 == -237130372","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1369,__func__));
  ((x1.a == -0x1.19ddff71df142p+4) ? (void)0 : failure("x1.a == -0x1.19ddff71df142p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1370,__func__));
  ((x1.b == 1283735415415508498) ? (void)0 : failure("x1.b == 1283735415415508498","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1371,__func__));
}

void f215(double x0, struct s43 x1)
{
  ((x0 == -0x1.61e3899caedep+0) ? (void)0 : failure("x0 == -0x1.61e3899caedep+0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1376,__func__));
  ((x1.a == -0x1.d1dfc36f5140ap+4) ? (void)0 : failure("x1.a == -0x1.d1dfc36f5140ap+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1377,__func__));
  ((x1.b == 8392412469743728698) ? (void)0 : failure("x1.b == 8392412469743728698","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1378,__func__));
}

struct s44 f216(void)
{
  return (struct s44){-0x1.f742fc7054999p+4, 0x1.5c329cf45a3e8p+2};
}

void f217(struct s44 x0)
{
  ((x0.a == 0x1.54260e37b4048p+5) ? (void)0 : failure("x0.a == 0x1.54260e37b4048p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1388,__func__));
  ((x0.b == -0x1.034896p+5F) ? (void)0 : failure("x0.b == -0x1.034896p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1389,__func__));
}

void f218(struct s44 x0, struct s44 x1)
{
  ((x0.a == -0x1.2b31d47615ecap+5) ? (void)0 : failure("x0.a == -0x1.2b31d47615ecap+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1394,__func__));
  ((x0.b == 0x1.41286ap+4F) ? (void)0 : failure("x0.b == 0x1.41286ap+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1395,__func__));
  ((x1.a == 0x1.0a404ee0abe3cp+4) ? (void)0 : failure("x1.a == 0x1.0a404ee0abe3cp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1396,__func__));
  ((x1.b == 0x1.16bfc6p+5F) ? (void)0 : failure("x1.b == 0x1.16bfc6p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1397,__func__));
}

void f219(int x0, struct s44 x1)
{
  ((x0 == -842646073) ? (void)0 : failure("x0 == -842646073","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1402,__func__));
  ((x1.a == 0x1.b21cd6033b928p+2) ? (void)0 : failure("x1.a == 0x1.b21cd6033b928p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1403,__func__));
  ((x1.b == 0x1.5c338cp+5F) ? (void)0 : failure("x1.b == 0x1.5c338cp+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1404,__func__));
}

void f220(double x0, struct s44 x1)
{
  ((x0 == -0x1.7379b58c8df78p+3) ? (void)0 : failure("x0 == -0x1.7379b58c8df78p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1409,__func__));
  ((x1.a == 0x1.99c2711a35e64p+4) ? (void)0 : failure("x1.a == 0x1.99c2711a35e64p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1410,__func__));
  ((x1.b == 0x1.9d6a48p+4F) ? (void)0 : failure("x1.b == 0x1.9d6a48p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1411,__func__));
}

struct s45 f221(void)
{
  return (struct s45){0x1.56ddc1dd6728ap+5, -0x1.8a82bc8a0c73ap+4};
}

void f222(struct s45 x0)
{
  ((x0.a == -0x1.6701c551fa2f5p+5) ? (void)0 : failure("x0.a == -0x1.6701c551fa2f5p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1421,__func__));
  ((x0.b == 0x1.7cb358db3f008p+4) ? (void)0 : failure("x0.b == 0x1.7cb358db3f008p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1422,__func__));
}

void f223(struct s45 x0, struct s45 x1)
{
  ((x0.a == -0x1.c55cd912e6d9p+1) ? (void)0 : failure("x0.a == -0x1.c55cd912e6d9p+1","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1427,__func__));
  ((x0.b == 0x1.88dad986da584p+5) ? (void)0 : failure("x0.b == 0x1.88dad986da584p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1428,__func__));
  ((x1.a == -0x1.f0df065a19698p+2) ? (void)0 : failure("x1.a == -0x1.f0df065a19698p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1429,__func__));
  ((x1.b == -0x1.6ccc12a200c6ap+4) ? (void)0 : failure("x1.b == -0x1.6ccc12a200c6ap+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1430,__func__));
}

void f224(int x0, struct s45 x1)
{
  ((x0 == -1195593810) ? (void)0 : failure("x0 == -1195593810","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1435,__func__));
  ((x1.a == -0x1.9296876cf3d81p+4) ? (void)0 : failure("x1.a == -0x1.9296876cf3d81p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1436,__func__));
  ((x1.b == 0x1.2ecd7b9a4b412p+5) ? (void)0 : failure("x1.b == 0x1.2ecd7b9a4b412p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1437,__func__));
}

void f225(double x0, struct s45 x1)
{
  ((x0 == -0x1.e35ad3ba3e478p+3) ? (void)0 : failure("x0 == -0x1.e35ad3ba3e478p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1442,__func__));
  ((x1.a == 0x1.46887322ab0e6p+5) ? (void)0 : failure("x1.a == 0x1.46887322ab0e6p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1443,__func__));
  ((x1.b == -0x1.cf59a532f72bp+3) ? (void)0 : failure("x1.b == -0x1.cf59a532f72bp+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1444,__func__));
}

struct s46 f226(void)
{
  return (struct s46){474122694, -327058572, -201014825};
}

void f227(struct s46 x0)
{
  ((x0.a == 237) ? (void)0 : failure("x0.a == 237","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1454,__func__));
  ((x0.b == 26) ? (void)0 : failure("x0.b == 26","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1455,__func__));
  ((x0.c == 212) ? (void)0 : failure("x0.c == 212","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1456,__func__));
}

void f228(struct s46 x0, struct s46 x1)
{
  ((x0.a == 91) ? (void)0 : failure("x0.a == 91","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1461,__func__));
  ((x0.b == 113) ? (void)0 : failure("x0.b == 113","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1462,__func__));
  ((x0.c == 40) ? (void)0 : failure("x0.c == 40","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1463,__func__));
  ((x1.a == 60) ? (void)0 : failure("x1.a == 60","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1464,__func__));
  ((x1.b == 190) ? (void)0 : failure("x1.b == 190","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1465,__func__));
  ((x1.c == 61) ? (void)0 : failure("x1.c == 61","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1466,__func__));
}

void f229(int x0, struct s46 x1)
{
  ((x0 == 245069159) ? (void)0 : failure("x0 == 245069159","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1471,__func__));
  ((x1.a == 54) ? (void)0 : failure("x1.a == 54","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1472,__func__));
  ((x1.b == 150) ? (void)0 : failure("x1.b == 150","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1473,__func__));
  ((x1.c == 64) ? (void)0 : failure("x1.c == 64","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1474,__func__));
}

void f230(double x0, struct s46 x1)
{
  ((x0 == 0x1.0fdd921e670fp+5) ? (void)0 : failure("x0 == 0x1.0fdd921e670fp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1479,__func__));
  ((x1.a == 184) ? (void)0 : failure("x1.a == 184","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1480,__func__));
  ((x1.b == 117) ? (void)0 : failure("x1.b == 117","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1481,__func__));
  ((x1.c == 34) ? (void)0 : failure("x1.c == 34","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1482,__func__));
}

struct s47 f231(void)
{
  return (struct s47){142052201, 141668199, 144528927, -207219031};
}

void f232(struct s47 x0)
{
  ((x0.a == 75) ? (void)0 : failure("x0.a == 75","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1492,__func__));
  ((x0.b == 5) ? (void)0 : failure("x0.b == 5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1493,__func__));
  ((x0.c == 239) ? (void)0 : failure("x0.c == 239","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1494,__func__));
  ((x0.d == 187) ? (void)0 : failure("x0.d == 187","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1495,__func__));
}

void f233(struct s47 x0, struct s47 x1)
{
  ((x0.a == 148) ? (void)0 : failure("x0.a == 148","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1500,__func__));
  ((x0.b == 219) ? (void)0 : failure("x0.b == 219","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1501,__func__));
  ((x0.c == 69) ? (void)0 : failure("x0.c == 69","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1502,__func__));
  ((x0.d == 98) ? (void)0 : failure("x0.d == 98","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1503,__func__));
  ((x1.a == 142) ? (void)0 : failure("x1.a == 142","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1504,__func__));
  ((x1.b == 58) ? (void)0 : failure("x1.b == 58","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1505,__func__));
  ((x1.c == 231) ? (void)0 : failure("x1.c == 231","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1506,__func__));
  ((x1.d == 175) ? (void)0 : failure("x1.d == 175","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1507,__func__));
}

void f234(int x0, struct s47 x1)
{
  ((x0 == 296626979) ? (void)0 : failure("x0 == 296626979","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1512,__func__));
  ((x1.a == 174) ? (void)0 : failure("x1.a == 174","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1513,__func__));
  ((x1.b == 75) ? (void)0 : failure("x1.b == 75","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1514,__func__));
  ((x1.c == 103) ? (void)0 : failure("x1.c == 103","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1515,__func__));
  ((x1.d == 57) ? (void)0 : failure("x1.d == 57","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1516,__func__));
}

void f235(double x0, struct s47 x1)
{
  ((x0 == 0x1.e23f3d6ade6e8p+4) ? (void)0 : failure("x0 == 0x1.e23f3d6ade6e8p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1521,__func__));
  ((x1.a == 74) ? (void)0 : failure("x1.a == 74","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1522,__func__));
  ((x1.b == 227) ? (void)0 : failure("x1.b == 227","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1523,__func__));
  ((x1.c == 198) ? (void)0 : failure("x1.c == 198","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1524,__func__));
  ((x1.d == 233) ? (void)0 : failure("x1.d == 233","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1525,__func__));
}

struct s48 f236(void)
{
  return (struct s48){-22210825, 274043924, -1101211, 78368612, 523064595, 81780727};
}

void f237(struct s48 x0)
{
  ((x0.a == 27) ? (void)0 : failure("x0.a == 27","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1535,__func__));
  ((x0.b == 40) ? (void)0 : failure("x0.b == 40","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1536,__func__));
  ((x0.c == 229) ? (void)0 : failure("x0.c == 229","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1537,__func__));
  ((x0.d == 240) ? (void)0 : failure("x0.d == 240","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1538,__func__));
  ((x0.e == 148) ? (void)0 : failure("x0.e == 148","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1539,__func__));
  ((x0.f == 234) ? (void)0 : failure("x0.f == 234","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1540,__func__));
}

void f238(struct s48 x0, struct s48 x1)
{
  ((x0.a == 87) ? (void)0 : failure("x0.a == 87","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1545,__func__));
  ((x0.b == 114) ? (void)0 : failure("x0.b == 114","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1546,__func__));
  ((x0.c == 152) ? (void)0 : failure("x0.c == 152","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1547,__func__));
  ((x0.d == 62) ? (void)0 : failure("x0.d == 62","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1548,__func__));
  ((x0.e == 109) ? (void)0 : failure("x0.e == 109","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1549,__func__));
  ((x0.f == 163) ? (void)0 : failure("x0.f == 163","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1550,__func__));
  ((x1.a == 15) ? (void)0 : failure("x1.a == 15","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1551,__func__));
  ((x1.b == 188) ? (void)0 : failure("x1.b == 188","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1552,__func__));
  ((x1.c == 181) ? (void)0 : failure("x1.c == 181","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1553,__func__));
  ((x1.d == 2) ? (void)0 : failure("x1.d == 2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1554,__func__));
  ((x1.e == 248) ? (void)0 : failure("x1.e == 248","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1555,__func__));
  ((x1.f == 140) ? (void)0 : failure("x1.f == 140","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1556,__func__));
}

void f239(int x0, struct s48 x1)
{
  ((x0 == 2079325832) ? (void)0 : failure("x0 == 2079325832","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1561,__func__));
  ((x1.a == 216) ? (void)0 : failure("x1.a == 216","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1562,__func__));
  ((x1.b == 199) ? (void)0 : failure("x1.b == 199","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1563,__func__));
  ((x1.c == 86) ? (void)0 : failure("x1.c == 86","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1564,__func__));
  ((x1.d == 209) ? (void)0 : failure("x1.d == 209","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1565,__func__));
  ((x1.e == 137) ? (void)0 : failure("x1.e == 137","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1566,__func__));
  ((x1.f == 63) ? (void)0 : failure("x1.f == 63","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1567,__func__));
}

void f240(double x0, struct s48 x1)
{
  ((x0 == -0x1.06d7a92efa24p+4) ? (void)0 : failure("x0 == -0x1.06d7a92efa24p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1572,__func__));
  ((x1.a == 9) ? (void)0 : failure("x1.a == 9","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1573,__func__));
  ((x1.b == 154) ? (void)0 : failure("x1.b == 154","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1574,__func__));
  ((x1.c == 205) ? (void)0 : failure("x1.c == 205","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1575,__func__));
  ((x1.d == 93) ? (void)0 : failure("x1.d == 93","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1576,__func__));
  ((x1.e == 143) ? (void)0 : failure("x1.e == 143","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1577,__func__));
  ((x1.f == 111) ? (void)0 : failure("x1.f == 111","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1578,__func__));
}

struct s49 f241(void)
{
  return (struct s49){418520364, -282765937, -520207206, -231521292, 214907037, -311321263, 3900052, -133187363};
}

void f242(struct s49 x0)
{
  ((x0.a == 221) ? (void)0 : failure("x0.a == 221","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1588,__func__));
  ((x0.b == 41) ? (void)0 : failure("x0.b == 41","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1589,__func__));
  ((x0.c == 109) ? (void)0 : failure("x0.c == 109","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1590,__func__));
  ((x0.d == 251) ? (void)0 : failure("x0.d == 251","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1591,__func__));
  ((x0.e == 254) ? (void)0 : failure("x0.e == 254","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1592,__func__));
  ((x0.f == 214) ? (void)0 : failure("x0.f == 214","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1593,__func__));
  ((x0.g == 112) ? (void)0 : failure("x0.g == 112","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1594,__func__));
  ((x0.h == 237) ? (void)0 : failure("x0.h == 237","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1595,__func__));
}

void f243(struct s49 x0, struct s49 x1)
{
  ((x0.a == 148) ? (void)0 : failure("x0.a == 148","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1600,__func__));
  ((x0.b == 66) ? (void)0 : failure("x0.b == 66","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1601,__func__));
  ((x0.c == 61) ? (void)0 : failure("x0.c == 61","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1602,__func__));
  ((x0.d == 98) ? (void)0 : failure("x0.d == 98","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1603,__func__));
  ((x0.e == 182) ? (void)0 : failure("x0.e == 182","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1604,__func__));
  ((x0.f == 148) ? (void)0 : failure("x0.f == 148","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1605,__func__));
  ((x0.g == 100) ? (void)0 : failure("x0.g == 100","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1606,__func__));
  ((x0.h == 33) ? (void)0 : failure("x0.h == 33","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1607,__func__));
  ((x1.a == 64) ? (void)0 : failure("x1.a == 64","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1608,__func__));
  ((x1.b == 168) ? (void)0 : failure("x1.b == 168","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1609,__func__));
  ((x1.c == 133) ? (void)0 : failure("x1.c == 133","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1610,__func__));
  ((x1.d == 25) ? (void)0 : failure("x1.d == 25","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1611,__func__));
  ((x1.e == 220) ? (void)0 : failure("x1.e == 220","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1612,__func__));
  ((x1.f == 38) ? (void)0 : failure("x1.f == 38","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1613,__func__));
  ((x1.g == 155) ? (void)0 : failure("x1.g == 155","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1614,__func__));
  ((x1.h == 165) ? (void)0 : failure("x1.h == 165","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1615,__func__));
}

void f244(int x0, struct s49 x1)
{
  ((x0 == -1909846621) ? (void)0 : failure("x0 == -1909846621","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1620,__func__));
  ((x1.a == 168) ? (void)0 : failure("x1.a == 168","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1621,__func__));
  ((x1.b == 85) ? (void)0 : failure("x1.b == 85","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1622,__func__));
  ((x1.c == 90) ? (void)0 : failure("x1.c == 90","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1623,__func__));
  ((x1.d == 117) ? (void)0 : failure("x1.d == 117","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1624,__func__));
  ((x1.e == 123) ? (void)0 : failure("x1.e == 123","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1625,__func__));
  ((x1.f == 218) ? (void)0 : failure("x1.f == 218","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1626,__func__));
  ((x1.g == 190) ? (void)0 : failure("x1.g == 190","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1627,__func__));
  ((x1.h == 65) ? (void)0 : failure("x1.h == 65","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1628,__func__));
}

void f245(double x0, struct s49 x1)
{
  ((x0 == 0x1.754e6b4fb978ap+5) ? (void)0 : failure("x0 == 0x1.754e6b4fb978ap+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1633,__func__));
  ((x1.a == 179) ? (void)0 : failure("x1.a == 179","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1634,__func__));
  ((x1.b == 14) ? (void)0 : failure("x1.b == 14","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1635,__func__));
  ((x1.c == 26) ? (void)0 : failure("x1.c == 26","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1636,__func__));
  ((x1.d == 181) ? (void)0 : failure("x1.d == 181","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1637,__func__));
  ((x1.e == 146) ? (void)0 : failure("x1.e == 146","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1638,__func__));
  ((x1.f == 86) ? (void)0 : failure("x1.f == 86","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1639,__func__));
  ((x1.g == 235) ? (void)0 : failure("x1.g == 235","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1640,__func__));
  ((x1.h == 136) ? (void)0 : failure("x1.h == 136","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1641,__func__));
}

struct s50 f246(void)
{
  return (struct s50){529841374, 96140801, -219348850};
}

void f247(struct s50 x0)
{
  ((x0.a == 3184) ? (void)0 : failure("x0.a == 3184","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1651,__func__));
  ((x0.b == 35888) ? (void)0 : failure("x0.b == 35888","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1652,__func__));
  ((x0.c == 26143) ? (void)0 : failure("x0.c == 26143","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1653,__func__));
}

void f248(struct s50 x0, struct s50 x1)
{
  ((x0.a == 58134) ? (void)0 : failure("x0.a == 58134","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1658,__func__));
  ((x0.b == 56679) ? (void)0 : failure("x0.b == 56679","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1659,__func__));
  ((x0.c == 44157) ? (void)0 : failure("x0.c == 44157","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1660,__func__));
  ((x1.a == 29727) ? (void)0 : failure("x1.a == 29727","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1661,__func__));
  ((x1.b == 52086) ? (void)0 : failure("x1.b == 52086","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1662,__func__));
  ((x1.c == 25611) ? (void)0 : failure("x1.c == 25611","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1663,__func__));
}

void f249(int x0, struct s50 x1)
{
  ((x0 == -1485132521) ? (void)0 : failure("x0 == -1485132521","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1668,__func__));
  ((x1.a == 52279) ? (void)0 : failure("x1.a == 52279","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1669,__func__));
  ((x1.b == 37455) ? (void)0 : failure("x1.b == 37455","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1670,__func__));
  ((x1.c == 19772) ? (void)0 : failure("x1.c == 19772","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1671,__func__));
}

void f250(double x0, struct s50 x1)
{
  ((x0 == -0x1.333bdd1a4244ap+5) ? (void)0 : failure("x0 == -0x1.333bdd1a4244ap+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1676,__func__));
  ((x1.a == 32576) ? (void)0 : failure("x1.a == 32576","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1677,__func__));
  ((x1.b == 1951) ? (void)0 : failure("x1.b == 1951","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1678,__func__));
  ((x1.c == 58097) ? (void)0 : failure("x1.c == 58097","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1679,__func__));
}

struct s51 f251(void)
{
  return (struct s51){71746484, 416874075, 521324449, -188620674};
}

void f252(struct s51 x0)
{
  ((x0.a == 19420) ? (void)0 : failure("x0.a == 19420","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1689,__func__));
  ((x0.b == 41682) ? (void)0 : failure("x0.b == 41682","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1690,__func__));
  ((x0.c == 55561) ? (void)0 : failure("x0.c == 55561","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1691,__func__));
  ((x0.d == 50556) ? (void)0 : failure("x0.d == 50556","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1692,__func__));
}

void f253(struct s51 x0, struct s51 x1)
{
  ((x0.a == 62858) ? (void)0 : failure("x0.a == 62858","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1697,__func__));
  ((x0.b == 25015) ? (void)0 : failure("x0.b == 25015","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1698,__func__));
  ((x0.c == 3368) ? (void)0 : failure("x0.c == 3368","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1699,__func__));
  ((x0.d == 61980) ? (void)0 : failure("x0.d == 61980","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1700,__func__));
  ((x1.a == 7972) ? (void)0 : failure("x1.a == 7972","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1701,__func__));
  ((x1.b == 20325) ? (void)0 : failure("x1.b == 20325","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1702,__func__));
  ((x1.c == 29635) ? (void)0 : failure("x1.c == 29635","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1703,__func__));
  ((x1.d == 49359) ? (void)0 : failure("x1.d == 49359","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1704,__func__));
}

void f254(int x0, struct s51 x1)
{
  ((x0 == 1986989253) ? (void)0 : failure("x0 == 1986989253","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1709,__func__));
  ((x1.a == 35995) ? (void)0 : failure("x1.a == 35995","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1710,__func__));
  ((x1.b == 5595) ? (void)0 : failure("x1.b == 5595","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1711,__func__));
  ((x1.c == 5601) ? (void)0 : failure("x1.c == 5601","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1712,__func__));
  ((x1.d == 59516) ? (void)0 : failure("x1.d == 59516","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1713,__func__));
}

void f255(double x0, struct s51 x1)
{
  ((x0 == 0x1.72a14178e685cp+4) ? (void)0 : failure("x0 == 0x1.72a14178e685cp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1718,__func__));
  ((x1.a == 58028) ? (void)0 : failure("x1.a == 58028","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1719,__func__));
  ((x1.b == 30442) ? (void)0 : failure("x1.b == 30442","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1720,__func__));
  ((x1.c == 64259) ? (void)0 : failure("x1.c == 64259","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1721,__func__));
  ((x1.d == 45284) ? (void)0 : failure("x1.d == 45284","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1722,__func__));
}

struct s52 f256(void)
{
  return (struct s52){452564714, 82950964, 13010246, 282159009, 375018737, 514294882};
}

void f257(struct s52 x0)
{
  ((x0.a == 56977) ? (void)0 : failure("x0.a == 56977","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1732,__func__));
  ((x0.b == 19555) ? (void)0 : failure("x0.b == 19555","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1733,__func__));
  ((x0.c == 44863) ? (void)0 : failure("x0.c == 44863","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1734,__func__));
  ((x0.d == 25916) ? (void)0 : failure("x0.d == 25916","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1735,__func__));
  ((x0.e == 11143) ? (void)0 : failure("x0.e == 11143","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1736,__func__));
  ((x0.f == 55452) ? (void)0 : failure("x0.f == 55452","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1737,__func__));
}

void f258(struct s52 x0, struct s52 x1)
{
  ((x0.a == 16179) ? (void)0 : failure("x0.a == 16179","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1742,__func__));
  ((x0.b == 47517) ? (void)0 : failure("x0.b == 47517","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1743,__func__));
  ((x0.c == 26166) ? (void)0 : failure("x0.c == 26166","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1744,__func__));
  ((x0.d == 60047) ? (void)0 : failure("x0.d == 60047","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1745,__func__));
  ((x0.e == 45932) ? (void)0 : failure("x0.e == 45932","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1746,__func__));
  ((x0.f == 28570) ? (void)0 : failure("x0.f == 28570","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1747,__func__));
  ((x1.a == 28115) ? (void)0 : failure("x1.a == 28115","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1748,__func__));
  ((x1.b == 41447) ? (void)0 : failure("x1.b == 41447","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1749,__func__));
  ((x1.c == 40727) ? (void)0 : failure("x1.c == 40727","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1750,__func__));
  ((x1.d == 55745) ? (void)0 : failure("x1.d == 55745","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1751,__func__));
  ((x1.e == 28367) ? (void)0 : failure("x1.e == 28367","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1752,__func__));
  ((x1.f == 61368) ? (void)0 : failure("x1.f == 61368","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1753,__func__));
}

void f259(int x0, struct s52 x1)
{
  ((x0 == -1689680134) ? (void)0 : failure("x0 == -1689680134","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1758,__func__));
  ((x1.a == 8971) ? (void)0 : failure("x1.a == 8971","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1759,__func__));
  ((x1.b == 42578) ? (void)0 : failure("x1.b == 42578","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1760,__func__));
  ((x1.c == 30001) ? (void)0 : failure("x1.c == 30001","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1761,__func__));
  ((x1.d == 49857) ? (void)0 : failure("x1.d == 49857","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1762,__func__));
  ((x1.e == 37208) ? (void)0 : failure("x1.e == 37208","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1763,__func__));
  ((x1.f == 58052) ? (void)0 : failure("x1.f == 58052","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1764,__func__));
}

void f260(double x0, struct s52 x1)
{
  ((x0 == -0x1.c7ac8ef3d674p+0) ? (void)0 : failure("x0 == -0x1.c7ac8ef3d674p+0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1769,__func__));
  ((x1.a == 11527) ? (void)0 : failure("x1.a == 11527","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1770,__func__));
  ((x1.b == 19073) ? (void)0 : failure("x1.b == 19073","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1771,__func__));
  ((x1.c == 58900) ? (void)0 : failure("x1.c == 58900","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1772,__func__));
  ((x1.d == 60365) ? (void)0 : failure("x1.d == 60365","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1773,__func__));
  ((x1.e == 15973) ? (void)0 : failure("x1.e == 15973","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1774,__func__));
  ((x1.f == 52841) ? (void)0 : failure("x1.f == 52841","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1775,__func__));
}

struct s53 f261(void)
{
  return (struct s53){-78859094, -161570977, 164665717, -508357419, 285591163, 101446347, -287506353, 2607461};
}

void f262(struct s53 x0)
{
  ((x0.a == 22527) ? (void)0 : failure("x0.a == 22527","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1785,__func__));
  ((x0.b == 60727) ? (void)0 : failure("x0.b == 60727","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1786,__func__));
  ((x0.c == 57855) ? (void)0 : failure("x0.c == 57855","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1787,__func__));
  ((x0.d == 33223) ? (void)0 : failure("x0.d == 33223","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1788,__func__));
  ((x0.e == 20659) ? (void)0 : failure("x0.e == 20659","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1789,__func__));
  ((x0.f == 27109) ? (void)0 : failure("x0.f == 27109","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1790,__func__));
  ((x0.g == 41121) ? (void)0 : failure("x0.g == 41121","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1791,__func__));
  ((x0.h == 65233) ? (void)0 : failure("x0.h == 65233","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1792,__func__));
}

void f263(struct s53 x0, struct s53 x1)
{
  ((x0.a == 16928) ? (void)0 : failure("x0.a == 16928","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1797,__func__));
  ((x0.b == 43105) ? (void)0 : failure("x0.b == 43105","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1798,__func__));
  ((x0.c == 3595) ? (void)0 : failure("x0.c == 3595","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1799,__func__));
  ((x0.d == 51739) ? (void)0 : failure("x0.d == 51739","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1800,__func__));
  ((x0.e == 18238) ? (void)0 : failure("x0.e == 18238","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1801,__func__));
  ((x0.f == 28644) ? (void)0 : failure("x0.f == 28644","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1802,__func__));
  ((x0.g == 12080) ? (void)0 : failure("x0.g == 12080","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1803,__func__));
  ((x0.h == 3400) ? (void)0 : failure("x0.h == 3400","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1804,__func__));
  ((x1.a == 50074) ? (void)0 : failure("x1.a == 50074","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1805,__func__));
  ((x1.b == 22671) ? (void)0 : failure("x1.b == 22671","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1806,__func__));
  ((x1.c == 8963) ? (void)0 : failure("x1.c == 8963","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1807,__func__));
  ((x1.d == 9542) ? (void)0 : failure("x1.d == 9542","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1808,__func__));
  ((x1.e == 42317) ? (void)0 : failure("x1.e == 42317","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1809,__func__));
  ((x1.f == 42135) ? (void)0 : failure("x1.f == 42135","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1810,__func__));
  ((x1.g == 47341) ? (void)0 : failure("x1.g == 47341","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1811,__func__));
  ((x1.h == 26661) ? (void)0 : failure("x1.h == 26661","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1812,__func__));
}

void f264(int x0, struct s53 x1)
{
  ((x0 == -1114110129) ? (void)0 : failure("x0 == -1114110129","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1817,__func__));
  ((x1.a == 46800) ? (void)0 : failure("x1.a == 46800","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1818,__func__));
  ((x1.b == 25993) ? (void)0 : failure("x1.b == 25993","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1819,__func__));
  ((x1.c == 52371) ? (void)0 : failure("x1.c == 52371","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1820,__func__));
  ((x1.d == 28453) ? (void)0 : failure("x1.d == 28453","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1821,__func__));
  ((x1.e == 47369) ? (void)0 : failure("x1.e == 47369","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1822,__func__));
  ((x1.f == 49100) ? (void)0 : failure("x1.f == 49100","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1823,__func__));
  ((x1.g == 29742) ? (void)0 : failure("x1.g == 29742","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1824,__func__));
  ((x1.h == 1294) ? (void)0 : failure("x1.h == 1294","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1825,__func__));
}

void f265(double x0, struct s53 x1)
{
  ((x0 == 0x1.54cc521bf9a38p+4) ? (void)0 : failure("x0 == 0x1.54cc521bf9a38p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1830,__func__));
  ((x1.a == 11449) ? (void)0 : failure("x1.a == 11449","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1831,__func__));
  ((x1.b == 12769) ? (void)0 : failure("x1.b == 12769","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1832,__func__));
  ((x1.c == 57752) ? (void)0 : failure("x1.c == 57752","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1833,__func__));
  ((x1.d == 41012) ? (void)0 : failure("x1.d == 41012","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1834,__func__));
  ((x1.e == 1716) ? (void)0 : failure("x1.e == 1716","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1835,__func__));
  ((x1.f == 15136) ? (void)0 : failure("x1.f == 15136","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1836,__func__));
  ((x1.g == 5295) ? (void)0 : failure("x1.g == 5295","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1837,__func__));
  ((x1.h == 11598) ? (void)0 : failure("x1.h == 11598","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1838,__func__));
}

struct s54 f266(void)
{
  return (struct s54){40398235, 2128836673, -770196380};
}

void f267(struct s54 x0)
{
  ((x0.a == -813077584) ? (void)0 : failure("x0.a == -813077584","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1848,__func__));
  ((x0.b == -822953675) ? (void)0 : failure("x0.b == -822953675","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1849,__func__));
  ((x0.c == -1102354705) ? (void)0 : failure("x0.c == -1102354705","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1850,__func__));
}

void f268(struct s54 x0, struct s54 x1)
{
  ((x0.a == -1546544965) ? (void)0 : failure("x0.a == -1546544965","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1855,__func__));
  ((x0.b == -1120789179) ? (void)0 : failure("x0.b == -1120789179","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1856,__func__));
  ((x0.c == -319268428) ? (void)0 : failure("x0.c == -319268428","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1857,__func__));
  ((x1.a == 875148878) ? (void)0 : failure("x1.a == 875148878","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1858,__func__));
  ((x1.b == -653511120) ? (void)0 : failure("x1.b == -653511120","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1859,__func__));
  ((x1.c == -227576861) ? (void)0 : failure("x1.c == -227576861","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1860,__func__));
}

void f269(int x0, struct s54 x1)
{
  ((x0 == -1748889414) ? (void)0 : failure("x0 == -1748889414","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1865,__func__));
  ((x1.a == -331560385) ? (void)0 : failure("x1.a == -331560385","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1866,__func__));
  ((x1.b == 1930180550) ? (void)0 : failure("x1.b == 1930180550","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1867,__func__));
  ((x1.c == 1835925762) ? (void)0 : failure("x1.c == 1835925762","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1868,__func__));
}

void f270(double x0, struct s54 x1)
{
  ((x0 == 0x1.97ed0ae2aa0ep+3) ? (void)0 : failure("x0 == 0x1.97ed0ae2aa0ep+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1873,__func__));
  ((x1.a == 1270154961) ? (void)0 : failure("x1.a == 1270154961","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1874,__func__));
  ((x1.b == 1222701288) ? (void)0 : failure("x1.b == 1222701288","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1875,__func__));
  ((x1.c == 68903934) ? (void)0 : failure("x1.c == 68903934","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1876,__func__));
}

struct s55 f271(void)
{
  return (struct s55){-2094011745, 1244358849, 1504382843, -376502836};
}

void f272(struct s55 x0)
{
  ((x0.a == -636837872) ? (void)0 : failure("x0.a == -636837872","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1886,__func__));
  ((x0.b == 602649651) ? (void)0 : failure("x0.b == 602649651","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1887,__func__));
  ((x0.c == -1737972595) ? (void)0 : failure("x0.c == -1737972595","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1888,__func__));
  ((x0.d == -1095762535) ? (void)0 : failure("x0.d == -1095762535","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1889,__func__));
}

void f273(struct s55 x0, struct s55 x1)
{
  ((x0.a == 493652316) ? (void)0 : failure("x0.a == 493652316","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1894,__func__));
  ((x0.b == 1414368155) ? (void)0 : failure("x0.b == 1414368155","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1895,__func__));
  ((x0.c == -873362258) ? (void)0 : failure("x0.c == -873362258","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1896,__func__));
  ((x0.d == 1914939786) ? (void)0 : failure("x0.d == 1914939786","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1897,__func__));
  ((x1.a == 867832304) ? (void)0 : failure("x1.a == 867832304","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1898,__func__));
  ((x1.b == 1710012470) ? (void)0 : failure("x1.b == 1710012470","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1899,__func__));
  ((x1.c == -2107262811) ? (void)0 : failure("x1.c == -2107262811","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1900,__func__));
  ((x1.d == 1899233657) ? (void)0 : failure("x1.d == 1899233657","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1901,__func__));
}

void f274(int x0, struct s55 x1)
{
  ((x0 == 1676010821) ? (void)0 : failure("x0 == 1676010821","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1906,__func__));
  ((x1.a == 1888701279) ? (void)0 : failure("x1.a == 1888701279","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1907,__func__));
  ((x1.b == -126389512) ? (void)0 : failure("x1.b == -126389512","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1908,__func__));
  ((x1.c == -1585042084) ? (void)0 : failure("x1.c == -1585042084","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1909,__func__));
  ((x1.d == 1592001549) ? (void)0 : failure("x1.d == 1592001549","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1910,__func__));
}

void f275(double x0, struct s55 x1)
{
  ((x0 == -0x1.3602402b58175p+5) ? (void)0 : failure("x0 == -0x1.3602402b58175p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1915,__func__));
  ((x1.a == 594342856) ? (void)0 : failure("x1.a == 594342856","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1916,__func__));
  ((x1.b == 1097502855) ? (void)0 : failure("x1.b == 1097502855","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1917,__func__));
  ((x1.c == -1269095678) ? (void)0 : failure("x1.c == -1269095678","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1918,__func__));
  ((x1.d == -724322331) ? (void)0 : failure("x1.d == -724322331","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1919,__func__));
}

struct s56 f276(void)
{
  return (struct s56){-1344324086, -2014742986, -2052156259, -2113919123, 740385887, 1642647504};
}

void f277(struct s56 x0)
{
  ((x0.a == -1478527619) ? (void)0 : failure("x0.a == -1478527619","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1929,__func__));
  ((x0.b == 1083029283) ? (void)0 : failure("x0.b == 1083029283","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1930,__func__));
  ((x0.c == 1090657006) ? (void)0 : failure("x0.c == 1090657006","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1931,__func__));
  ((x0.d == -1946734822) ? (void)0 : failure("x0.d == -1946734822","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1932,__func__));
  ((x0.e == -79118108) ? (void)0 : failure("x0.e == -79118108","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1933,__func__));
  ((x0.f == 278450333) ? (void)0 : failure("x0.f == 278450333","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1934,__func__));
}

void f278(struct s56 x0, struct s56 x1)
{
  ((x0.a == -384472236) ? (void)0 : failure("x0.a == -384472236","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1939,__func__));
  ((x0.b == -1129288703) ? (void)0 : failure("x0.b == -1129288703","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1940,__func__));
  ((x0.c == -368902093) ? (void)0 : failure("x0.c == -368902093","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1941,__func__));
  ((x0.d == 1099237150) ? (void)0 : failure("x0.d == 1099237150","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1942,__func__));
  ((x0.e == -1215525153) ? (void)0 : failure("x0.e == -1215525153","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1943,__func__));
  ((x0.f == -418234137) ? (void)0 : failure("x0.f == -418234137","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1944,__func__));
  ((x1.a == 1852653572) ? (void)0 : failure("x1.a == 1852653572","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1945,__func__));
  ((x1.b == 247991754) ? (void)0 : failure("x1.b == 247991754","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1946,__func__));
  ((x1.c == -155090660) ? (void)0 : failure("x1.c == -155090660","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1947,__func__));
  ((x1.d == 800929339) ? (void)0 : failure("x1.d == 800929339","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1948,__func__));
  ((x1.e == -458785323) ? (void)0 : failure("x1.e == -458785323","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1949,__func__));
  ((x1.f == -598412318) ? (void)0 : failure("x1.f == -598412318","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1950,__func__));
}

void f279(int x0, struct s56 x1)
{
  ((x0 == -866899555) ? (void)0 : failure("x0 == -866899555","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1955,__func__));
  ((x1.a == 1105570655) ? (void)0 : failure("x1.a == 1105570655","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1956,__func__));
  ((x1.b == 998449963) ? (void)0 : failure("x1.b == 998449963","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1957,__func__));
  ((x1.c == 70319619) ? (void)0 : failure("x1.c == 70319619","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1958,__func__));
  ((x1.d == 1775060919) ? (void)0 : failure("x1.d == 1775060919","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1959,__func__));
  ((x1.e == -1627442816) ? (void)0 : failure("x1.e == -1627442816","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1960,__func__));
  ((x1.f == -1428647701) ? (void)0 : failure("x1.f == -1428647701","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1961,__func__));
}

void f280(double x0, struct s56 x1)
{
  ((x0 == -0x1.b9a05f3e9ff9dp+4) ? (void)0 : failure("x0 == -0x1.b9a05f3e9ff9dp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1966,__func__));
  ((x1.a == 333479667) ? (void)0 : failure("x1.a == 333479667","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1967,__func__));
  ((x1.b == -410714259) ? (void)0 : failure("x1.b == -410714259","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1968,__func__));
  ((x1.c == -2028834241) ? (void)0 : failure("x1.c == -2028834241","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1969,__func__));
  ((x1.d == 1970859700) ? (void)0 : failure("x1.d == 1970859700","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1970,__func__));
  ((x1.e == -1549457394) ? (void)0 : failure("x1.e == -1549457394","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1971,__func__));
  ((x1.f == -2095839552) ? (void)0 : failure("x1.f == -2095839552","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1972,__func__));
}

struct s57 f281(void)
{
  return (struct s57){-1556001572, -741503189, 1089468836, -1749477125, 1613559968, 1262067752, -38315583, 424021687};
}

void f282(struct s57 x0)
{
  ((x0.a == -1239899849) ? (void)0 : failure("x0.a == -1239899849","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1982,__func__));
  ((x0.b == 1212598905) ? (void)0 : failure("x0.b == 1212598905","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1983,__func__));
  ((x0.c == -1939206716) ? (void)0 : failure("x0.c == -1939206716","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1984,__func__));
  ((x0.d == 1561341678) ? (void)0 : failure("x0.d == 1561341678","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1985,__func__));
  ((x0.e == -1760132827) ? (void)0 : failure("x0.e == -1760132827","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1986,__func__));
  ((x0.f == 473082591) ? (void)0 : failure("x0.f == 473082591","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1987,__func__));
  ((x0.g == 1226188033) ? (void)0 : failure("x0.g == 1226188033","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1988,__func__));
  ((x0.h == -812375367) ? (void)0 : failure("x0.h == -812375367","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1989,__func__));
}

void f283(struct s57 x0, struct s57 x1)
{
  ((x0.a == -1839575787) ? (void)0 : failure("x0.a == -1839575787","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1994,__func__));
  ((x0.b == 241057370) ? (void)0 : failure("x0.b == 241057370","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1995,__func__));
  ((x0.c == -1020266062) ? (void)0 : failure("x0.c == -1020266062","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1996,__func__));
  ((x0.d == -1791510506) ? (void)0 : failure("x0.d == -1791510506","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1997,__func__));
  ((x0.e == -1992608852) ? (void)0 : failure("x0.e == -1992608852","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1998,__func__));
  ((x0.f == -989345356) ? (void)0 : failure("x0.f == -989345356","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",1999,__func__));
  ((x0.g == -821263593) ? (void)0 : failure("x0.g == -821263593","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2000,__func__));
  ((x0.h == 1871873655) ? (void)0 : failure("x0.h == 1871873655","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2001,__func__));
  ((x1.a == -327970441) ? (void)0 : failure("x1.a == -327970441","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2002,__func__));
  ((x1.b == -1033528309) ? (void)0 : failure("x1.b == -1033528309","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2003,__func__));
  ((x1.c == -755590432) ? (void)0 : failure("x1.c == -755590432","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2004,__func__));
  ((x1.d == -878039353) ? (void)0 : failure("x1.d == -878039353","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2005,__func__));
  ((x1.e == -1094998271) ? (void)0 : failure("x1.e == -1094998271","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2006,__func__));
  ((x1.f == 1700980336) ? (void)0 : failure("x1.f == 1700980336","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2007,__func__));
  ((x1.g == 1133496704) ? (void)0 : failure("x1.g == 1133496704","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2008,__func__));
  ((x1.h == 1145738069) ? (void)0 : failure("x1.h == 1145738069","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2009,__func__));
}

void f284(int x0, struct s57 x1)
{
  ((x0 == 1572115023) ? (void)0 : failure("x0 == 1572115023","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2014,__func__));
  ((x1.a == -870901838) ? (void)0 : failure("x1.a == -870901838","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2015,__func__));
  ((x1.b == 2093595905) ? (void)0 : failure("x1.b == 2093595905","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2016,__func__));
  ((x1.c == 1682659984) ? (void)0 : failure("x1.c == 1682659984","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2017,__func__));
  ((x1.d == 917318514) ? (void)0 : failure("x1.d == 917318514","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2018,__func__));
  ((x1.e == 1547294906) ? (void)0 : failure("x1.e == 1547294906","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2019,__func__));
  ((x1.f == 1477264327) ? (void)0 : failure("x1.f == 1477264327","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2020,__func__));
  ((x1.g == -387644538) ? (void)0 : failure("x1.g == -387644538","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2021,__func__));
  ((x1.h == 1334680527) ? (void)0 : failure("x1.h == 1334680527","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2022,__func__));
}

void f285(double x0, struct s57 x1)
{
  ((x0 == 0x1.aa7d89e6f78p-5) ? (void)0 : failure("x0 == 0x1.aa7d89e6f78p-5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2027,__func__));
  ((x1.a == 1696458700) ? (void)0 : failure("x1.a == 1696458700","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2028,__func__));
  ((x1.b == 1495023119) ? (void)0 : failure("x1.b == 1495023119","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2029,__func__));
  ((x1.c == 1207879464) ? (void)0 : failure("x1.c == 1207879464","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2030,__func__));
  ((x1.d == 1958961143) ? (void)0 : failure("x1.d == 1958961143","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2031,__func__));
  ((x1.e == -570063302) ? (void)0 : failure("x1.e == -570063302","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2032,__func__));
  ((x1.f == 2106380128) ? (void)0 : failure("x1.f == 2106380128","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2033,__func__));
  ((x1.g == -215532182) ? (void)0 : failure("x1.g == -215532182","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2034,__func__));
  ((x1.h == 310324292) ? (void)0 : failure("x1.h == 310324292","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2035,__func__));
}

struct s58 f286(void)
{
  return (struct s58){2004723339903230192, 6397415174471306602, 4819258099187834544};
}

void f287(struct s58 x0)
{
  ((x0.a == 7864354302794522772) ? (void)0 : failure("x0.a == 7864354302794522772","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2045,__func__));
  ((x0.b == -3195831438043025917) ? (void)0 : failure("x0.b == -3195831438043025917","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2046,__func__));
  ((x0.c == 6497405992266599743) ? (void)0 : failure("x0.c == 6497405992266599743","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2047,__func__));
}

void f288(struct s58 x0, struct s58 x1)
{
  ((x0.a == 6982636052040341865) ? (void)0 : failure("x0.a == 6982636052040341865","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2052,__func__));
  ((x0.b == -9207998756414875964) ? (void)0 : failure("x0.b == -9207998756414875964","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2053,__func__));
  ((x0.c == -7926330336746133022) ? (void)0 : failure("x0.c == -7926330336746133022","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2054,__func__));
  ((x1.a == -1552305682186930785) ? (void)0 : failure("x1.a == -1552305682186930785","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2055,__func__));
  ((x1.b == -8515405049812870959) ? (void)0 : failure("x1.b == -8515405049812870959","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2056,__func__));
  ((x1.c == 1826485582942621559) ? (void)0 : failure("x1.c == 1826485582942621559","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2057,__func__));
}

void f289(int x0, struct s58 x1)
{
  ((x0 == -1120420969) ? (void)0 : failure("x0 == -1120420969","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2062,__func__));
  ((x1.a == 5891877809946940148) ? (void)0 : failure("x1.a == 5891877809946940148","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2063,__func__));
  ((x1.b == 414198837228287746) ? (void)0 : failure("x1.b == 414198837228287746","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2064,__func__));
  ((x1.c == 1029957303263444594) ? (void)0 : failure("x1.c == 1029957303263444594","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2065,__func__));
}

void f290(double x0, struct s58 x1)
{
  ((x0 == 0x1.c55cccd0d83p-1) ? (void)0 : failure("x0 == 0x1.c55cccd0d83p-1","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2070,__func__));
  ((x1.a == 3479737001473941325) ? (void)0 : failure("x1.a == 3479737001473941325","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2071,__func__));
  ((x1.b == -5440816454689209583) ? (void)0 : failure("x1.b == -5440816454689209583","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2072,__func__));
  ((x1.c == -2462842471211201829) ? (void)0 : failure("x1.c == -2462842471211201829","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2073,__func__));
}

struct s59 f291(void)
{
  return (struct s59){-7837027076644551922, 4374303578401666934, 1620389363152891905, -4398874295435412346};
}

void f292(struct s59 x0)
{
  ((x0.a == 2208066821676405006) ? (void)0 : failure("x0.a == 2208066821676405006","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2083,__func__));
  ((x0.b == -522667975979130469) ? (void)0 : failure("x0.b == -522667975979130469","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2084,__func__));
  ((x0.c == 6263431241607187268) ? (void)0 : failure("x0.c == 6263431241607187268","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2085,__func__));
  ((x0.d == -8090070468402203799) ? (void)0 : failure("x0.d == -8090070468402203799","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2086,__func__));
}

void f293(struct s59 x0, struct s59 x1)
{
  ((x0.a == -6154966703787290981) ? (void)0 : failure("x0.a == -6154966703787290981","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2091,__func__));
  ((x0.b == 251239613809491994) ? (void)0 : failure("x0.b == 251239613809491994","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2092,__func__));
  ((x0.c == -4464866342266211079) ? (void)0 : failure("x0.c == -4464866342266211079","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2093,__func__));
  ((x0.d == -3268472778921023930) ? (void)0 : failure("x0.d == -3268472778921023930","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2094,__func__));
  ((x1.a == -1744277274733010432) ? (void)0 : failure("x1.a == -1744277274733010432","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2095,__func__));
  ((x1.b == -3309836993627192140) ? (void)0 : failure("x1.b == -3309836993627192140","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2096,__func__));
  ((x1.c == 1296595703325259959) ? (void)0 : failure("x1.c == 1296595703325259959","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2097,__func__));
  ((x1.d == 3085954471522892401) ? (void)0 : failure("x1.d == 3085954471522892401","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2098,__func__));
}

void f294(int x0, struct s59 x1)
{
  ((x0 == -2029660416) ? (void)0 : failure("x0 == -2029660416","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2103,__func__));
  ((x1.a == 310382890322352710) ? (void)0 : failure("x1.a == 310382890322352710","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2104,__func__));
  ((x1.b == -7625140031200871166) ? (void)0 : failure("x1.b == -7625140031200871166","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2105,__func__));
  ((x1.c == 6230910873971966405) ? (void)0 : failure("x1.c == 6230910873971966405","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2106,__func__));
  ((x1.d == 3188053628766003827) ? (void)0 : failure("x1.d == 3188053628766003827","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2107,__func__));
}

void f295(double x0, struct s59 x1)
{
  ((x0 == -0x1.8747c38d5c09cp+3) ? (void)0 : failure("x0 == -0x1.8747c38d5c09cp+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2112,__func__));
  ((x1.a == 6167710983073211108) ? (void)0 : failure("x1.a == 6167710983073211108","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2113,__func__));
  ((x1.b == 6228397073198854919) ? (void)0 : failure("x1.b == 6228397073198854919","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2114,__func__));
  ((x1.c == 3085024040854890041) ? (void)0 : failure("x1.c == 3085024040854890041","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2115,__func__));
  ((x1.d == 8712948434506908694) ? (void)0 : failure("x1.d == 8712948434506908694","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2116,__func__));
}

struct s60 f296(void)
{
  return (struct s60){8830942043370466793, -7181376488475664989, 5475827025808791150, 1689952632491852805, 5202218061220139611, -5716583426545799401};
}

void f297(struct s60 x0)
{
  ((x0.a == -3652332570717718915) ? (void)0 : failure("x0.a == -3652332570717718915","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2126,__func__));
  ((x0.b == -8385153050934849232) ? (void)0 : failure("x0.b == -8385153050934849232","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2127,__func__));
  ((x0.c == 2796580170212265591) ? (void)0 : failure("x0.c == 2796580170212265591","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2128,__func__));
  ((x0.d == -4761308511779651338) ? (void)0 : failure("x0.d == -4761308511779651338","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2129,__func__));
  ((x0.e == -2011959598710697358) ? (void)0 : failure("x0.e == -2011959598710697358","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2130,__func__));
  ((x0.f == -837830109172576315) ? (void)0 : failure("x0.f == -837830109172576315","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2131,__func__));
}

void f298(struct s60 x0, struct s60 x1)
{
  ((x0.a == -3741235593561171267) ? (void)0 : failure("x0.a == -3741235593561171267","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2136,__func__));
  ((x0.b == -820991670170863378) ? (void)0 : failure("x0.b == -820991670170863378","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2137,__func__));
  ((x0.c == 5962138712415955169) ? (void)0 : failure("x0.c == 5962138712415955169","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2138,__func__));
  ((x0.d == -2000609577541218522) ? (void)0 : failure("x0.d == -2000609577541218522","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2139,__func__));
  ((x0.e == 65808555680337795) ? (void)0 : failure("x0.e == 65808555680337795","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2140,__func__));
  ((x0.f == 4218524788692500665) ? (void)0 : failure("x0.f == 4218524788692500665","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2141,__func__));
  ((x1.a == 7445458094847756153) ? (void)0 : failure("x1.a == 7445458094847756153","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2142,__func__));
  ((x1.b == 1791615147233262889) ? (void)0 : failure("x1.b == 1791615147233262889","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2143,__func__));
  ((x1.c == 2529433344807568474) ? (void)0 : failure("x1.c == 2529433344807568474","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2144,__func__));
  ((x1.d == 7184352829095371683) ? (void)0 : failure("x1.d == 7184352829095371683","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2145,__func__));
  ((x1.e == 6159634947789934416) ? (void)0 : failure("x1.e == 6159634947789934416","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2146,__func__));
  ((x1.f == 1444361232073586775) ? (void)0 : failure("x1.f == 1444361232073586775","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2147,__func__));
}

void f299(int x0, struct s60 x1)
{
  ((x0 == 382590090) ? (void)0 : failure("x0 == 382590090","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2152,__func__));
  ((x1.a == -289330091119253646) ? (void)0 : failure("x1.a == -289330091119253646","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2153,__func__));
  ((x1.b == 579284392501295509) ? (void)0 : failure("x1.b == 579284392501295509","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2154,__func__));
  ((x1.c == -6054430554678754373) ? (void)0 : failure("x1.c == -6054430554678754373","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2155,__func__));
  ((x1.d == -8583385428984158307) ? (void)0 : failure("x1.d == -8583385428984158307","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2156,__func__));
  ((x1.e == -8541192730599954335) ? (void)0 : failure("x1.e == -8541192730599954335","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2157,__func__));
  ((x1.f == -8904703611215753751) ? (void)0 : failure("x1.f == -8904703611215753751","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2158,__func__));
}

void f300(double x0, struct s60 x1)
{
  ((x0 == 0x1.a98c86feb9258p+4) ? (void)0 : failure("x0 == 0x1.a98c86feb9258p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2163,__func__));
  ((x1.a == 4057518156153265300) ? (void)0 : failure("x1.a == 4057518156153265300","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2164,__func__));
  ((x1.b == -7477891924552959926) ? (void)0 : failure("x1.b == -7477891924552959926","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2165,__func__));
  ((x1.c == -6320855859911932033) ? (void)0 : failure("x1.c == -6320855859911932033","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2166,__func__));
  ((x1.d == 3935376049511752050) ? (void)0 : failure("x1.d == 3935376049511752050","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2167,__func__));
  ((x1.e == -6590015501619187600) ? (void)0 : failure("x1.e == -6590015501619187600","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2168,__func__));
  ((x1.f == -5399390337454439163) ? (void)0 : failure("x1.f == -5399390337454439163","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2169,__func__));
}

struct s61 f301(void)
{
  return (struct s61){-2836254641330925163, -3971325912302539598, 8165075520375979388, 8021367050294595689, 5966289387050517868, -7251756001158949497, -461282064023901131, 7109988575795088431};
}

void f302(struct s61 x0)
{
  ((x0.a == 7034939172948071308) ? (void)0 : failure("x0.a == 7034939172948071308","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2179,__func__));
  ((x0.b == 7424051237976585391) ? (void)0 : failure("x0.b == 7424051237976585391","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2180,__func__));
  ((x0.c == -1208494439316553845) ? (void)0 : failure("x0.c == -1208494439316553845","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2181,__func__));
  ((x0.d == 9120136251407028621) ? (void)0 : failure("x0.d == 9120136251407028621","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2182,__func__));
  ((x0.e == -7095616490480762670) ? (void)0 : failure("x0.e == -7095616490480762670","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2183,__func__));
  ((x0.f == -74090135265001715) ? (void)0 : failure("x0.f == -74090135265001715","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2184,__func__));
  ((x0.g == 9210700778121023134) ? (void)0 : failure("x0.g == 9210700778121023134","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2185,__func__));
  ((x0.h == 3723443027841607681) ? (void)0 : failure("x0.h == 3723443027841607681","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2186,__func__));
}

void f303(struct s61 x0, struct s61 x1)
{
  ((x0.a == -6924490146476521235) ? (void)0 : failure("x0.a == -6924490146476521235","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2191,__func__));
  ((x0.b == -3050881640756342740) ? (void)0 : failure("x0.b == -3050881640756342740","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2192,__func__));
  ((x0.c == 7333907952850625862) ? (void)0 : failure("x0.c == 7333907952850625862","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2193,__func__));
  ((x0.d == -4465419502713426560) ? (void)0 : failure("x0.d == -4465419502713426560","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2194,__func__));
  ((x0.e == 3554545626042267272) ? (void)0 : failure("x0.e == 3554545626042267272","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2195,__func__));
  ((x0.f == -8037095940923102799) ? (void)0 : failure("x0.f == -8037095940923102799","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2196,__func__));
  ((x0.g == -4038227020892648462) ? (void)0 : failure("x0.g == -4038227020892648462","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2197,__func__));
  ((x0.h == -7810359266076428556) ? (void)0 : failure("x0.h == -7810359266076428556","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2198,__func__));
  ((x1.a == 4869086151445624813) ? (void)0 : failure("x1.a == 4869086151445624813","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2199,__func__));
  ((x1.b == 4494448565390693015) ? (void)0 : failure("x1.b == 4494448565390693015","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2200,__func__));
  ((x1.c == 4944615466877424437) ? (void)0 : failure("x1.c == 4944615466877424437","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2201,__func__));
  ((x1.d == 4169686391845976670) ? (void)0 : failure("x1.d == 4169686391845976670","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2202,__func__));
  ((x1.e == -5045408152623293315) ? (void)0 : failure("x1.e == -5045408152623293315","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2203,__func__));
  ((x1.f == 7414262994632409334) ? (void)0 : failure("x1.f == 7414262994632409334","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2204,__func__));
  ((x1.g == -3193567555580175562) ? (void)0 : failure("x1.g == -3193567555580175562","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2205,__func__));
  ((x1.h == -7796428337446052608) ? (void)0 : failure("x1.h == -7796428337446052608","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2206,__func__));
}

void f304(int x0, struct s61 x1)
{
  ((x0 == -1003246920) ? (void)0 : failure("x0 == -1003246920","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2211,__func__));
  ((x1.a == 4280713908087870217) ? (void)0 : failure("x1.a == 4280713908087870217","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2212,__func__));
  ((x1.b == 8957439470917897101) ? (void)0 : failure("x1.b == 8957439470917897101","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2213,__func__));
  ((x1.c == 1698121181740029815) ? (void)0 : failure("x1.c == 1698121181740029815","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2214,__func__));
  ((x1.d == 6779422321090594172) ? (void)0 : failure("x1.d == 6779422321090594172","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2215,__func__));
  ((x1.e == 7767898063319302534) ? (void)0 : failure("x1.e == 7767898063319302534","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2216,__func__));
  ((x1.f == -8315006110463056353) ? (void)0 : failure("x1.f == -8315006110463056353","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2217,__func__));
  ((x1.g == -5364749496295923286) ? (void)0 : failure("x1.g == -5364749496295923286","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2218,__func__));
  ((x1.h == 1043632969619464456) ? (void)0 : failure("x1.h == 1043632969619464456","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2219,__func__));
}

void f305(double x0, struct s61 x1)
{
  ((x0 == 0x1.6742a97d17bcep+5) ? (void)0 : failure("x0 == 0x1.6742a97d17bcep+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2224,__func__));
  ((x1.a == 534113460973376480) ? (void)0 : failure("x1.a == 534113460973376480","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2225,__func__));
  ((x1.b == -1972749546722034222) ? (void)0 : failure("x1.b == -1972749546722034222","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2226,__func__));
  ((x1.c == -33440608009732110) ? (void)0 : failure("x1.c == -33440608009732110","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2227,__func__));
  ((x1.d == -6564347790249916681) ? (void)0 : failure("x1.d == -6564347790249916681","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2228,__func__));
  ((x1.e == 4154932980812663836) ? (void)0 : failure("x1.e == 4154932980812663836","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2229,__func__));
  ((x1.f == 5888594362943646845) ? (void)0 : failure("x1.f == 5888594362943646845","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2230,__func__));
  ((x1.g == -3329671628006563281) ? (void)0 : failure("x1.g == -3329671628006563281","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2231,__func__));
  ((x1.h == -587837659352929050) ? (void)0 : failure("x1.h == -587837659352929050","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2232,__func__));
}

struct s62 f306(void)
{
  return (struct s62){-0x1.ff9339a57288fp+4, -0x1.98d49c44638b8p+4, -0x1.c9e1bc02de657p+4};
}

void f307(struct s62 x0)
{
  ((x0.a == -0x1.1162bp+5F) ? (void)0 : failure("x0.a == -0x1.1162bp+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2242,__func__));
  ((x0.b == -0x1.807b94p+3F) ? (void)0 : failure("x0.b == -0x1.807b94p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2243,__func__));
  ((x0.c == 0x1.3a0c0cp-1F) ? (void)0 : failure("x0.c == 0x1.3a0c0cp-1F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2244,__func__));
}

void f308(struct s62 x0, struct s62 x1)
{
  ((x0.a == 0x1.41878ep+5F) ? (void)0 : failure("x0.a == 0x1.41878ep+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2249,__func__));
  ((x0.b == 0x1.73026p+4F) ? (void)0 : failure("x0.b == 0x1.73026p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2250,__func__));
  ((x0.c == 0x1.6d018p+5F) ? (void)0 : failure("x0.c == 0x1.6d018p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2251,__func__));
  ((x1.a == 0x1.190304p+5F) ? (void)0 : failure("x1.a == 0x1.190304p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2252,__func__));
  ((x1.b == 0x1.0a7a2ap+5F) ? (void)0 : failure("x1.b == 0x1.0a7a2ap+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2253,__func__));
  ((x1.c == 0x1.f71434p+4F) ? (void)0 : failure("x1.c == 0x1.f71434p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2254,__func__));
}

void f309(int x0, struct s62 x1)
{
  ((x0 == -1407500543) ? (void)0 : failure("x0 == -1407500543","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2259,__func__));
  ((x1.a == 0x1.29a304p+4F) ? (void)0 : failure("x1.a == 0x1.29a304p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2260,__func__));
  ((x1.b == -0x1.c3eb7p+4F) ? (void)0 : failure("x1.b == -0x1.c3eb7p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2261,__func__));
  ((x1.c == -0x1.59d91cp+5F) ? (void)0 : failure("x1.c == -0x1.59d91cp+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2262,__func__));
}

void f310(double x0, struct s62 x1)
{
  ((x0 == -0x1.740935eb74bp+5) ? (void)0 : failure("x0 == -0x1.740935eb74bp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2267,__func__));
  ((x1.a == 0x1.daa4e2p+2F) ? (void)0 : failure("x1.a == 0x1.daa4e2p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2268,__func__));
  ((x1.b == 0x1.eaf3ep+2F) ? (void)0 : failure("x1.b == 0x1.eaf3ep+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2269,__func__));
  ((x1.c == 0x1.b02aa4p+4F) ? (void)0 : failure("x1.c == 0x1.b02aa4p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2270,__func__));
}

struct s63 f311(void)
{
  return (struct s63){0x1.e6499c1270c28p+3, 0x1.5d59fe857a964p+4, -0x1.72b690335b40bp+4, -0x1.7f3dbee5bb16p+3};
}

void f312(struct s63 x0)
{
  ((x0.a == 0x1.db7992p+4F) ? (void)0 : failure("x0.a == 0x1.db7992p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2280,__func__));
  ((x0.b == -0x1.297d58p+5F) ? (void)0 : failure("x0.b == -0x1.297d58p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2281,__func__));
  ((x0.c == -0x1.1d00e8p+5F) ? (void)0 : failure("x0.c == -0x1.1d00e8p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2282,__func__));
  ((x0.d == -0x1.4d2046p+4F) ? (void)0 : failure("x0.d == -0x1.4d2046p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2283,__func__));
}

void f313(struct s63 x0, struct s63 x1)
{
  ((x0.a == 0x1.8cf4b6p+5F) ? (void)0 : failure("x0.a == 0x1.8cf4b6p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2288,__func__));
  ((x0.b == 0x1.d2f372p+4F) ? (void)0 : failure("x0.b == 0x1.d2f372p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2289,__func__));
  ((x0.c == -0x1.957c24p+4F) ? (void)0 : failure("x0.c == -0x1.957c24p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2290,__func__));
  ((x0.d == 0x1.8c9b98p+2F) ? (void)0 : failure("x0.d == 0x1.8c9b98p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2291,__func__));
  ((x1.a == 0x1.4e89ep+5F) ? (void)0 : failure("x1.a == 0x1.4e89ep+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2292,__func__));
  ((x1.b == 0x1.0ddfd6p+5F) ? (void)0 : failure("x1.b == 0x1.0ddfd6p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2293,__func__));
  ((x1.c == -0x1.d878b8p+3F) ? (void)0 : failure("x1.c == -0x1.d878b8p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2294,__func__));
  ((x1.d == -0x1.765e0ep+2F) ? (void)0 : failure("x1.d == -0x1.765e0ep+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2295,__func__));
}

void f314(int x0, struct s63 x1)
{
  ((x0 == 933889343) ? (void)0 : failure("x0 == 933889343","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2300,__func__));
  ((x1.a == 0x1.1a7388p+5F) ? (void)0 : failure("x1.a == 0x1.1a7388p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2301,__func__));
  ((x1.b == 0x1.be655p+4F) ? (void)0 : failure("x1.b == 0x1.be655p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2302,__func__));
  ((x1.c == -0x1.b1e336p+4F) ? (void)0 : failure("x1.c == -0x1.b1e336p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2303,__func__));
  ((x1.d == 0x1.bfcab8p+1F) ? (void)0 : failure("x1.d == 0x1.bfcab8p+1F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2304,__func__));
}

void f315(double x0, struct s63 x1)
{
  ((x0 == 0x1.9565da10b5428p+3) ? (void)0 : failure("x0 == 0x1.9565da10b5428p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2309,__func__));
  ((x1.a == -0x1.74691ap+5F) ? (void)0 : failure("x1.a == -0x1.74691ap+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2310,__func__));
  ((x1.b == 0x1.4bdee8p+0F) ? (void)0 : failure("x1.b == 0x1.4bdee8p+0F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2311,__func__));
  ((x1.c == 0x1.38220ep-2F) ? (void)0 : failure("x1.c == 0x1.38220ep-2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2312,__func__));
  ((x1.d == 0x1.60d2e2p+4F) ? (void)0 : failure("x1.d == 0x1.60d2e2p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2313,__func__));
}

struct s64 f316(void)
{
  return (struct s64){-0x1.cf4aed40d5f98p+3, 0x1.0b903eee9a8c4p+3, 0x1.3f8f9229a0712p+5, 0x1.837df5dbf2336p+5, 0x1.979482a10868cp+3, 0x1.5e1522cc5933p+1};
}

void f317(struct s64 x0)
{
  ((x0.a == 0x1.a46886p+1F) ? (void)0 : failure("x0.a == 0x1.a46886p+1F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2323,__func__));
  ((x0.b == -0x1.bd9c16p+4F) ? (void)0 : failure("x0.b == -0x1.bd9c16p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2324,__func__));
  ((x0.c == 0x1.cea754p+3F) ? (void)0 : failure("x0.c == 0x1.cea754p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2325,__func__));
  ((x0.d == -0x1.cd8eb2p+3F) ? (void)0 : failure("x0.d == -0x1.cd8eb2p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2326,__func__));
  ((x0.e == 0x1.8776bcp+4F) ? (void)0 : failure("x0.e == 0x1.8776bcp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2327,__func__));
  ((x0.f == 0x1.d44592p+4F) ? (void)0 : failure("x0.f == 0x1.d44592p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2328,__func__));
}

void f318(struct s64 x0, struct s64 x1)
{
  ((x0.a == 0x1.116bdp+3F) ? (void)0 : failure("x0.a == 0x1.116bdp+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2333,__func__));
  ((x0.b == -0x1.59e4d6p+2F) ? (void)0 : failure("x0.b == -0x1.59e4d6p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2334,__func__));
  ((x0.c == -0x1.57a702p+2F) ? (void)0 : failure("x0.c == -0x1.57a702p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2335,__func__));
  ((x0.d == -0x1.3cf316p+4F) ? (void)0 : failure("x0.d == -0x1.3cf316p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2336,__func__));
  ((x0.e == 0x1.0b3f48p+5F) ? (void)0 : failure("x0.e == 0x1.0b3f48p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2337,__func__));
  ((x0.f == -0x1.014fdp+5F) ? (void)0 : failure("x0.f == -0x1.014fdp+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2338,__func__));
  ((x1.a == -0x1.2bc328p+5F) ? (void)0 : failure("x1.a == -0x1.2bc328p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2339,__func__));
  ((x1.b == 0x1.634adcp+4F) ? (void)0 : failure("x1.b == 0x1.634adcp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2340,__func__));
  ((x1.c == -0x1.82e088p+5F) ? (void)0 : failure("x1.c == -0x1.82e088p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2341,__func__));
  ((x1.d == -0x1.156496p+5F) ? (void)0 : failure("x1.d == -0x1.156496p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2342,__func__));
  ((x1.e == 0x1.d894b2p+4F) ? (void)0 : failure("x1.e == 0x1.d894b2p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2343,__func__));
  ((x1.f == -0x1.5989c4p+4F) ? (void)0 : failure("x1.f == -0x1.5989c4p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2344,__func__));
}

void f319(int x0, struct s64 x1)
{
  ((x0 == 945002968) ? (void)0 : failure("x0 == 945002968","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2349,__func__));
  ((x1.a == 0x1.8ee712p+2F) ? (void)0 : failure("x1.a == 0x1.8ee712p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2350,__func__));
  ((x1.b == 0x1.c74308p+4F) ? (void)0 : failure("x1.b == 0x1.c74308p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2351,__func__));
  ((x1.c == -0x1.3c86c2p+5F) ? (void)0 : failure("x1.c == -0x1.3c86c2p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2352,__func__));
  ((x1.d == -0x1.299344p+3F) ? (void)0 : failure("x1.d == -0x1.299344p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2353,__func__));
  ((x1.e == 0x1.89166ep+5F) ? (void)0 : failure("x1.e == 0x1.89166ep+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2354,__func__));
  ((x1.f == -0x1.3529e4p+5F) ? (void)0 : failure("x1.f == -0x1.3529e4p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2355,__func__));
}

void f320(double x0, struct s64 x1)
{
  ((x0 == -0x1.12d4bc17d7dcap+4) ? (void)0 : failure("x0 == -0x1.12d4bc17d7dcap+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2360,__func__));
  ((x1.a == 0x1.157d1ep+5F) ? (void)0 : failure("x1.a == 0x1.157d1ep+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2361,__func__));
  ((x1.b == -0x1.98c918p+2F) ? (void)0 : failure("x1.b == -0x1.98c918p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2362,__func__));
  ((x1.c == 0x1.fdcf56p+4F) ? (void)0 : failure("x1.c == 0x1.fdcf56p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2363,__func__));
  ((x1.d == -0x1.116ceep+4F) ? (void)0 : failure("x1.d == -0x1.116ceep+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2364,__func__));
  ((x1.e == -0x1.65240cp+4F) ? (void)0 : failure("x1.e == -0x1.65240cp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2365,__func__));
  ((x1.f == 0x1.3cd256p+3F) ? (void)0 : failure("x1.f == 0x1.3cd256p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2366,__func__));
}

struct s65 f321(void)
{
  return (struct s65){-0x1.7542cb4a7fd24p+4, 0x1.70198fa77577ap+5, 0x1.62edb517d1bfep+5, 0x1.0e4b8bf635024p+4, -0x1.572a7ee49d4d7p+5, 0x1.da5d39f64ffb8p+3, -0x1.64403c187c962p+5, -0x1.34087bce60e58p+5};
}

void f322(struct s65 x0)
{
  ((x0.a == -0x1.2d0a18p+5F) ? (void)0 : failure("x0.a == -0x1.2d0a18p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2376,__func__));
  ((x0.b == 0x1.263c32p+5F) ? (void)0 : failure("x0.b == 0x1.263c32p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2377,__func__));
  ((x0.c == -0x1.e7ec4p+1F) ? (void)0 : failure("x0.c == -0x1.e7ec4p+1F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2378,__func__));
  ((x0.d == 0x1.698d28p+4F) ? (void)0 : failure("x0.d == 0x1.698d28p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2379,__func__));
  ((x0.e == 0x1.d2c596p+4F) ? (void)0 : failure("x0.e == 0x1.d2c596p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2380,__func__));
  ((x0.f == -0x1.ffd7dcp+3F) ? (void)0 : failure("x0.f == -0x1.ffd7dcp+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2381,__func__));
  ((x0.g == -0x1.8733ecp+3F) ? (void)0 : failure("x0.g == -0x1.8733ecp+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2382,__func__));
  ((x0.h == 0x1.cc62aep+4F) ? (void)0 : failure("x0.h == 0x1.cc62aep+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2383,__func__));
}

void f323(struct s65 x0, struct s65 x1)
{
  ((x0.a == 0x1.1fa88ap+3F) ? (void)0 : failure("x0.a == 0x1.1fa88ap+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2388,__func__));
  ((x0.b == -0x1.2c1f46p+3F) ? (void)0 : failure("x0.b == -0x1.2c1f46p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2389,__func__));
  ((x0.c == -0x1.71b844p+5F) ? (void)0 : failure("x0.c == -0x1.71b844p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2390,__func__));
  ((x0.d == 0x1.ea3aacp+2F) ? (void)0 : failure("x0.d == 0x1.ea3aacp+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2391,__func__));
  ((x0.e == 0x1.34083ap+4F) ? (void)0 : failure("x0.e == 0x1.34083ap+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2392,__func__));
  ((x0.f == 0x1.43fdbep+4F) ? (void)0 : failure("x0.f == 0x1.43fdbep+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2393,__func__));
  ((x0.g == 0x1.2c5822p+5F) ? (void)0 : failure("x0.g == 0x1.2c5822p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2394,__func__));
  ((x0.h == 0x1.3d9656p+5F) ? (void)0 : failure("x0.h == 0x1.3d9656p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2395,__func__));
  ((x1.a == 0x1.8b127p+5F) ? (void)0 : failure("x1.a == 0x1.8b127p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2396,__func__));
  ((x1.b == 0x1.365e36p+1F) ? (void)0 : failure("x1.b == 0x1.365e36p+1F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2397,__func__));
  ((x1.c == -0x1.4145fep+5F) ? (void)0 : failure("x1.c == -0x1.4145fep+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2398,__func__));
  ((x1.d == -0x1.14c846p+5F) ? (void)0 : failure("x1.d == -0x1.14c846p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2399,__func__));
  ((x1.e == 0x1.2fc51ep+4F) ? (void)0 : failure("x1.e == 0x1.2fc51ep+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2400,__func__));
  ((x1.f == 0x1.87cbcap+3F) ? (void)0 : failure("x1.f == 0x1.87cbcap+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2401,__func__));
  ((x1.g == -0x1.084e42p+5F) ? (void)0 : failure("x1.g == -0x1.084e42p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2402,__func__));
  ((x1.h == -0x1.5ca678p+4F) ? (void)0 : failure("x1.h == -0x1.5ca678p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2403,__func__));
}

void f324(int x0, struct s65 x1)
{
  ((x0 == -1642056878) ? (void)0 : failure("x0 == -1642056878","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2408,__func__));
  ((x1.a == 0x1.258d6cp+3F) ? (void)0 : failure("x1.a == 0x1.258d6cp+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2409,__func__));
  ((x1.b == 0x1.0802d2p+5F) ? (void)0 : failure("x1.b == 0x1.0802d2p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2410,__func__));
  ((x1.c == -0x1.ea0b76p+2F) ? (void)0 : failure("x1.c == -0x1.ea0b76p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2411,__func__));
  ((x1.d == -0x1.7a98p+5F) ? (void)0 : failure("x1.d == -0x1.7a98p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2412,__func__));
  ((x1.e == 0x1.a7b2eep+4F) ? (void)0 : failure("x1.e == 0x1.a7b2eep+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2413,__func__));
  ((x1.f == -0x1.1f9f58p+5F) ? (void)0 : failure("x1.f == -0x1.1f9f58p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2414,__func__));
  ((x1.g == 0x1.687cb4p+2F) ? (void)0 : failure("x1.g == 0x1.687cb4p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2415,__func__));
  ((x1.h == 0x1.f014c6p+4F) ? (void)0 : failure("x1.h == 0x1.f014c6p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2416,__func__));
}

void f325(double x0, struct s65 x1)
{
  ((x0 == 0x1.3c7232c8cdbfcp+5) ? (void)0 : failure("x0 == 0x1.3c7232c8cdbfcp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2421,__func__));
  ((x1.a == -0x1.5e6bfap+0F) ? (void)0 : failure("x1.a == -0x1.5e6bfap+0F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2422,__func__));
  ((x1.b == -0x1.383e7ap+5F) ? (void)0 : failure("x1.b == -0x1.383e7ap+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2423,__func__));
  ((x1.c == -0x1.b12666p+3F) ? (void)0 : failure("x1.c == -0x1.b12666p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2424,__func__));
  ((x1.d == 0x1.13533ep+4F) ? (void)0 : failure("x1.d == 0x1.13533ep+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2425,__func__));
  ((x1.e == -0x1.326caep+5F) ? (void)0 : failure("x1.e == -0x1.326caep+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2426,__func__));
  ((x1.f == 0x1.146b4p+5F) ? (void)0 : failure("x1.f == 0x1.146b4p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2427,__func__));
  ((x1.g == -0x1.774394p+5F) ? (void)0 : failure("x1.g == -0x1.774394p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2428,__func__));
  ((x1.h == 0x1.8b446p+5F) ? (void)0 : failure("x1.h == 0x1.8b446p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2429,__func__));
}

struct s66 f326(void)
{
  return (struct s66){-0x1.9bc58aec5d286p+4, 0x1.9daf2e6302a74p+4, 0x1.ab81943d83d38p+4};
}

void f327(struct s66 x0)
{
  ((x0.a == -0x1.53376b1963029p+5) ? (void)0 : failure("x0.a == -0x1.53376b1963029p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2439,__func__));
  ((x0.b == 0x1.665814bafc6aap+5) ? (void)0 : failure("x0.b == 0x1.665814bafc6aap+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2440,__func__));
  ((x0.c == 0x1.1336a0b3e11d4p+5) ? (void)0 : failure("x0.c == 0x1.1336a0b3e11d4p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2441,__func__));
}

void f328(struct s66 x0, struct s66 x1)
{
  ((x0.a == -0x1.0c6c7b81c04c4p+5) ? (void)0 : failure("x0.a == -0x1.0c6c7b81c04c4p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2446,__func__));
  ((x0.b == 0x1.dc1b83d5f3294p+4) ? (void)0 : failure("x0.b == 0x1.dc1b83d5f3294p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2447,__func__));
  ((x0.c == -0x1.44ff3f19341ap+3) ? (void)0 : failure("x0.c == -0x1.44ff3f19341ap+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2448,__func__));
  ((x1.a == 0x1.608c566865b92p+5) ? (void)0 : failure("x1.a == 0x1.608c566865b92p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2449,__func__));
  ((x1.b == -0x1.4d8561f18edc6p+5) ? (void)0 : failure("x1.b == -0x1.4d8561f18edc6p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2450,__func__));
  ((x1.c == -0x1.3ffe08de67983p+4) ? (void)0 : failure("x1.c == -0x1.3ffe08de67983p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2451,__func__));
}

void f329(int x0, struct s66 x1)
{
  ((x0 == 1664566933) ? (void)0 : failure("x0 == 1664566933","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2456,__func__));
  ((x1.a == 0x1.7f90a30d5ca74p+5) ? (void)0 : failure("x1.a == 0x1.7f90a30d5ca74p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2457,__func__));
  ((x1.b == 0x1.239d4a3d3891cp+5) ? (void)0 : failure("x1.b == 0x1.239d4a3d3891cp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2458,__func__));
  ((x1.c == -0x1.6dcbaeec0388ap+5) ? (void)0 : failure("x1.c == -0x1.6dcbaeec0388ap+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2459,__func__));
}

void f330(double x0, struct s66 x1)
{
  ((x0 == 0x1.62b1d078c9f78p+5) ? (void)0 : failure("x0 == 0x1.62b1d078c9f78p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2464,__func__));
  ((x1.a == 0x1.e9df584ddf398p+4) ? (void)0 : failure("x1.a == 0x1.e9df584ddf398p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2465,__func__));
  ((x1.b == -0x1.1550b80e48d35p+5) ? (void)0 : failure("x1.b == -0x1.1550b80e48d35p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2466,__func__));
  ((x1.c == 0x1.580f5ef149d64p+4) ? (void)0 : failure("x1.c == 0x1.580f5ef149d64p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2467,__func__));
}

struct s67 f331(void)
{
  return (struct s67){0x1.e6c1914db64b8p+3, 0x1.bf7347cdd7c14p+4, 0x1.2a823ee8e93dp+2, 0x1.22b7d94bdedd8p+5};
}

void f332(struct s67 x0)
{
  ((x0.a == -0x1.8f3b3fe21d63fp+4) ? (void)0 : failure("x0.a == -0x1.8f3b3fe21d63fp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2477,__func__));
  ((x0.b == 0x1.8edf87cbd3de6p+5) ? (void)0 : failure("x0.b == 0x1.8edf87cbd3de6p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2478,__func__));
  ((x0.c == 0x1.737998cf66e1p+2) ? (void)0 : failure("x0.c == 0x1.737998cf66e1p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2479,__func__));
  ((x0.d == 0x1.e7c46be0b456p+3) ? (void)0 : failure("x0.d == 0x1.e7c46be0b456p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2480,__func__));
}

void f333(struct s67 x0, struct s67 x1)
{
  ((x0.a == 0x1.1dfae375a503p+3) ? (void)0 : failure("x0.a == 0x1.1dfae375a503p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2485,__func__));
  ((x0.b == -0x1.516124cb465f2p+5) ? (void)0 : failure("x0.b == -0x1.516124cb465f2p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2486,__func__));
  ((x0.c == -0x1.69a2cf819a87bp+5) ? (void)0 : failure("x0.c == -0x1.69a2cf819a87bp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2487,__func__));
  ((x0.d == 0x1.8662282fefce4p+3) ? (void)0 : failure("x0.d == 0x1.8662282fefce4p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2488,__func__));
  ((x1.a == -0x1.7bd181bd5bd87p+5) ? (void)0 : failure("x1.a == -0x1.7bd181bd5bd87p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2489,__func__));
  ((x1.b == -0x1.5247e134df66cp+5) ? (void)0 : failure("x1.b == -0x1.5247e134df66cp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2490,__func__));
  ((x1.c == -0x1.0c0289f0de9ap+0) ? (void)0 : failure("x1.c == -0x1.0c0289f0de9ap+0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2491,__func__));
  ((x1.d == -0x1.47dceb5197aa4p+5) ? (void)0 : failure("x1.d == -0x1.47dceb5197aa4p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2492,__func__));
}

void f334(int x0, struct s67 x1)
{
  ((x0 == -702763847) ? (void)0 : failure("x0 == -702763847","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2497,__func__));
  ((x1.a == -0x1.b1b4ab4ffba08p+3) ? (void)0 : failure("x1.a == -0x1.b1b4ab4ffba08p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2498,__func__));
  ((x1.b == 0x1.7588b492be574p+4) ? (void)0 : failure("x1.b == 0x1.7588b492be574p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2499,__func__));
  ((x1.c == -0x1.e1657fdf51cbp+1) ? (void)0 : failure("x1.c == -0x1.e1657fdf51cbp+1","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2500,__func__));
  ((x1.d == -0x1.63de953d7daacp+5) ? (void)0 : failure("x1.d == -0x1.63de953d7daacp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2501,__func__));
}

void f335(double x0, struct s67 x1)
{
  ((x0 == -0x1.06a48c40463f6p+5) ? (void)0 : failure("x0 == -0x1.06a48c40463f6p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2506,__func__));
  ((x1.a == -0x1.659cce37b7cep+5) ? (void)0 : failure("x1.a == -0x1.659cce37b7cep+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2507,__func__));
  ((x1.b == -0x1.0331f0f34f6a5p+5) ? (void)0 : failure("x1.b == -0x1.0331f0f34f6a5p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2508,__func__));
  ((x1.c == -0x1.65b0991b573dep+5) ? (void)0 : failure("x1.c == -0x1.65b0991b573dep+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2509,__func__));
  ((x1.d == -0x1.d1ad7a98e38bcp+4) ? (void)0 : failure("x1.d == -0x1.d1ad7a98e38bcp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2510,__func__));
}

struct s68 f336(void)
{
  return (struct s68){-0x1.47c854887bce2p+5, -0x1.1722cbd292fe2p+4, 0x1.4c79c99fddeep+3, 0x1.158cb75ab5c7p+5, 0x1.81cccffe73c0cp+5, 0x1.a620afbf5b5ep+2};
}

void f337(struct s68 x0)
{
  ((x0.a == 0x1.4f63f19cc8dp-1) ? (void)0 : failure("x0.a == 0x1.4f63f19cc8dp-1","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2520,__func__));
  ((x0.b == 0x1.8603de811393p+4) ? (void)0 : failure("x0.b == 0x1.8603de811393p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2521,__func__));
  ((x0.c == -0x1.100e785ed98e8p+2) ? (void)0 : failure("x0.c == -0x1.100e785ed98e8p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2522,__func__));
  ((x0.d == 0x1.2b95fb65bdac4p+3) ? (void)0 : failure("x0.d == 0x1.2b95fb65bdac4p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2523,__func__));
  ((x0.e == 0x1.59b0c62f1d014p+4) ? (void)0 : failure("x0.e == 0x1.59b0c62f1d014p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2524,__func__));
  ((x0.f == -0x1.64956ce26016cp+5) ? (void)0 : failure("x0.f == -0x1.64956ce26016cp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2525,__func__));
}

void f338(struct s68 x0, struct s68 x1)
{
  ((x0.a == 0x1.f644a3a98603p+4) ? (void)0 : failure("x0.a == 0x1.f644a3a98603p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2530,__func__));
  ((x0.b == -0x1.e62c8c14332dp+2) ? (void)0 : failure("x0.b == -0x1.e62c8c14332dp+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2531,__func__));
  ((x0.c == 0x1.bb4d44f79f7ap+1) ? (void)0 : failure("x0.c == 0x1.bb4d44f79f7ap+1","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2532,__func__));
  ((x0.d == 0x1.e9e8a3d270b2p+0) ? (void)0 : failure("x0.d == 0x1.e9e8a3d270b2p+0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2533,__func__));
  ((x0.e == 0x1.17b5ac39bf5e6p+5) ? (void)0 : failure("x0.e == 0x1.17b5ac39bf5e6p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2534,__func__));
  ((x0.f == 0x1.6c9eeba3648d4p+4) ? (void)0 : failure("x0.f == 0x1.6c9eeba3648d4p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2535,__func__));
  ((x1.a == 0x1.edbde86ef09c8p+2) ? (void)0 : failure("x1.a == 0x1.edbde86ef09c8p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2536,__func__));
  ((x1.b == 0x1.09762f5548fc8p+4) ? (void)0 : failure("x1.b == 0x1.09762f5548fc8p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2537,__func__));
  ((x1.c == -0x1.326c3c7a0dbb6p+5) ? (void)0 : failure("x1.c == -0x1.326c3c7a0dbb6p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2538,__func__));
  ((x1.d == -0x1.4a8784429524p+3) ? (void)0 : failure("x1.d == -0x1.4a8784429524p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2539,__func__));
  ((x1.e == -0x1.fc75de31ea104p+3) ? (void)0 : failure("x1.e == -0x1.fc75de31ea104p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2540,__func__));
  ((x1.f == 0x1.5680174fe2ebp+4) ? (void)0 : failure("x1.f == 0x1.5680174fe2ebp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2541,__func__));
}

void f339(int x0, struct s68 x1)
{
  ((x0 == 869731840) ? (void)0 : failure("x0 == 869731840","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2546,__func__));
  ((x1.a == -0x1.022f54296131cp+5) ? (void)0 : failure("x1.a == -0x1.022f54296131cp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2547,__func__));
  ((x1.b == -0x1.24772b976360dp+5) ? (void)0 : failure("x1.b == -0x1.24772b976360dp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2548,__func__));
  ((x1.c == -0x1.3c664bd76b615p+4) ? (void)0 : failure("x1.c == -0x1.3c664bd76b615p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2549,__func__));
  ((x1.d == -0x1.23f92c9ab298p+5) ? (void)0 : failure("x1.d == -0x1.23f92c9ab298p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2550,__func__));
  ((x1.e == 0x1.98b98e67bd484p+4) ? (void)0 : failure("x1.e == 0x1.98b98e67bd484p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2551,__func__));
  ((x1.f == -0x1.1dacdb2044b2fp+5) ? (void)0 : failure("x1.f == -0x1.1dacdb2044b2fp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2552,__func__));
}

void f340(double x0, struct s68 x1)
{
  ((x0 == 0x1.731f29aa4dcp+3) ? (void)0 : failure("x0 == 0x1.731f29aa4dcp+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2557,__func__));
  ((x1.a == -0x1.a24d872667d84p+3) ? (void)0 : failure("x1.a == -0x1.a24d872667d84p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2558,__func__));
  ((x1.b == 0x1.226d83e562718p+2) ? (void)0 : failure("x1.b == 0x1.226d83e562718p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2559,__func__));
  ((x1.c == 0x1.dc8f5a045eaap+2) ? (void)0 : failure("x1.c == 0x1.dc8f5a045eaap+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2560,__func__));
  ((x1.d == -0x1.8a3b4999e10bep+5) ? (void)0 : failure("x1.d == -0x1.8a3b4999e10bep+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2561,__func__));
  ((x1.e == -0x1.1d777ef2d1b83p+5) ? (void)0 : failure("x1.e == -0x1.1d777ef2d1b83p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2562,__func__));
  ((x1.f == -0x1.d601c48f3de31p+4) ? (void)0 : failure("x1.f == -0x1.d601c48f3de31p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2563,__func__));
}

struct s69 f341(void)
{
  return (struct s69){-0x1.0ba84e94c9146p+5, 0x1.648713a86aa9cp+3, 0x1.b0d130ee644f8p+2, 0x1.15a5aefe042c6p+5, 0x1.3ba9b7c2e7b5p+2, -0x1.99cd442771fp+0, -0x1.0bc54987b10ep+5, -0x1.49a7d879f54fp+5};
}

void f342(struct s69 x0)
{
  ((x0.a == 0x1.efdc53b8015c8p+2) ? (void)0 : failure("x0.a == 0x1.efdc53b8015c8p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2573,__func__));
  ((x0.b == 0x1.309d2c94305c8p+2) ? (void)0 : failure("x0.b == 0x1.309d2c94305c8p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2574,__func__));
  ((x0.c == -0x1.1c7d6caad7fcep+4) ? (void)0 : failure("x0.c == -0x1.1c7d6caad7fcep+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2575,__func__));
  ((x0.d == 0x1.d15123511abdp+3) ? (void)0 : failure("x0.d == 0x1.d15123511abdp+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2576,__func__));
  ((x0.e == -0x1.17cb2deb1c5c6p+4) ? (void)0 : failure("x0.e == -0x1.17cb2deb1c5c6p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2577,__func__));
  ((x0.f == -0x1.4c0ca81a7becfp+5) ? (void)0 : failure("x0.f == -0x1.4c0ca81a7becfp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2578,__func__));
  ((x0.g == 0x1.9fee5424d4458p+4) ? (void)0 : failure("x0.g == 0x1.9fee5424d4458p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2579,__func__));
  ((x0.h == 0x1.04e2b403cb3f4p+5) ? (void)0 : failure("x0.h == 0x1.04e2b403cb3f4p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2580,__func__));
}

void f343(struct s69 x0, struct s69 x1)
{
  ((x0.a == -0x1.76c18ba7c07dfp+5) ? (void)0 : failure("x0.a == -0x1.76c18ba7c07dfp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2585,__func__));
  ((x0.b == 0x1.67c7c336bba8p+1) ? (void)0 : failure("x0.b == 0x1.67c7c336bba8p+1","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2586,__func__));
  ((x0.c == -0x1.dd2f7652ddf08p+3) ? (void)0 : failure("x0.c == -0x1.dd2f7652ddf08p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2587,__func__));
  ((x0.d == 0x1.ec21dec61013cp+4) ? (void)0 : failure("x0.d == 0x1.ec21dec61013cp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2588,__func__));
  ((x0.e == -0x1.f40fc3acb1bd2p+4) ? (void)0 : failure("x0.e == -0x1.f40fc3acb1bd2p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2589,__func__));
  ((x0.f == 0x1.fa7df5567fcbp+4) ? (void)0 : failure("x0.f == 0x1.fa7df5567fcbp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2590,__func__));
  ((x0.g == 0x1.bb7f913a5d3a8p+4) ? (void)0 : failure("x0.g == 0x1.bb7f913a5d3a8p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2591,__func__));
  ((x0.h == 0x1.e6006071d52ecp+4) ? (void)0 : failure("x0.h == 0x1.e6006071d52ecp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2592,__func__));
  ((x1.a == 0x1.327fceaecc6bcp+4) ? (void)0 : failure("x1.a == 0x1.327fceaecc6bcp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2593,__func__));
  ((x1.b == -0x1.5f6daab7109e9p+5) ? (void)0 : failure("x1.b == -0x1.5f6daab7109e9p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2594,__func__));
  ((x1.c == 0x1.59ef6be351272p+5) ? (void)0 : failure("x1.c == 0x1.59ef6be351272p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2595,__func__));
  ((x1.d == 0x1.7a2f5ea9254dap+5) ? (void)0 : failure("x1.d == 0x1.7a2f5ea9254dap+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2596,__func__));
  ((x1.e == -0x1.0a13ed5bc6f4p+0) ? (void)0 : failure("x1.e == -0x1.0a13ed5bc6f4p+0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2597,__func__));
  ((x1.f == 0x1.ed598d51a2a38p+2) ? (void)0 : failure("x1.f == 0x1.ed598d51a2a38p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2598,__func__));
  ((x1.g == 0x1.83dae2b718454p+5) ? (void)0 : failure("x1.g == 0x1.83dae2b718454p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2599,__func__));
  ((x1.h == 0x1.771e300f6a218p+5) ? (void)0 : failure("x1.h == 0x1.771e300f6a218p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2600,__func__));
}

void f344(int x0, struct s69 x1)
{
  ((x0 == -1358227050) ? (void)0 : failure("x0 == -1358227050","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2605,__func__));
  ((x1.a == 0x1.2bbaf3894d708p+4) ? (void)0 : failure("x1.a == 0x1.2bbaf3894d708p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2606,__func__));
  ((x1.b == -0x1.4b514c968c44ap+5) ? (void)0 : failure("x1.b == -0x1.4b514c968c44ap+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2607,__func__));
  ((x1.c == -0x1.18b308e9396e8p+3) ? (void)0 : failure("x1.c == -0x1.18b308e9396e8p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2608,__func__));
  ((x1.d == -0x1.7a0ef3c9c0c58p+3) ? (void)0 : failure("x1.d == -0x1.7a0ef3c9c0c58p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2609,__func__));
  ((x1.e == -0x1.7f584962f2b58p+5) ? (void)0 : failure("x1.e == -0x1.7f584962f2b58p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2610,__func__));
  ((x1.f == 0x1.e28d459df0228p+2) ? (void)0 : failure("x1.f == 0x1.e28d459df0228p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2611,__func__));
  ((x1.g == -0x1.59fe159a62ae2p+5) ? (void)0 : failure("x1.g == -0x1.59fe159a62ae2p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2612,__func__));
  ((x1.h == -0x1.6645bff1952d8p+4) ? (void)0 : failure("x1.h == -0x1.6645bff1952d8p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2613,__func__));
}

void f345(double x0, struct s69 x1)
{
  ((x0 == -0x1.04b60cd0b7a54p+3) ? (void)0 : failure("x0 == -0x1.04b60cd0b7a54p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2618,__func__));
  ((x1.a == -0x1.a7b99e9cb0cb5p+4) ? (void)0 : failure("x1.a == -0x1.a7b99e9cb0cb5p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2619,__func__));
  ((x1.b == 0x1.d0a54047f8908p+4) ? (void)0 : failure("x1.b == 0x1.d0a54047f8908p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2620,__func__));
  ((x1.c == 0x1.600ef8020edd8p+3) ? (void)0 : failure("x1.c == 0x1.600ef8020edd8p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2621,__func__));
  ((x1.d == -0x1.77cdb6a42f615p+5) ? (void)0 : failure("x1.d == -0x1.77cdb6a42f615p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2622,__func__));
  ((x1.e == -0x1.66ea527a9b87ep+4) ? (void)0 : failure("x1.e == -0x1.66ea527a9b87ep+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2623,__func__));
  ((x1.f == -0x1.6b07f17c96871p+4) ? (void)0 : failure("x1.f == -0x1.6b07f17c96871p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2624,__func__));
  ((x1.g == -0x1.36588c07f7f48p+5) ? (void)0 : failure("x1.g == -0x1.36588c07f7f48p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2625,__func__));
  ((x1.h == -0x1.6769d1d7b38e3p+5) ? (void)0 : failure("x1.h == -0x1.6769d1d7b38e3p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_def.c",2626,__func__));
}
