# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c"
# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 1
# 43 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h"
typedef __builtin_va_list __gnuc_va_list;
# 59 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h"
typedef __builtin_va_list va_list;
# 2 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c" 2
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 29 "/usr/include/stdio.h" 2 3 4









# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4

# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef unsigned long size_t;
# 39 "/usr/include/stdio.h" 2 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 45 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 46 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 47 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 48 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 2 3 4

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2:24;

  char _short_backupbuf[1];
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;

  int _unused3;

  __uint64_t _total_written;




  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
# 49 "/usr/include/stdio.h" 2 3 4
# 89 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;
# 133 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 134 "/usr/include/stdio.h" 2 3 4
# 153 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) ;

extern int rename (const char *__old, const char *__new) ;
# 191 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) ;
# 201 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  ;
# 218 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) ;
# 243 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 271 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *restrict __filename,
      const char *restrict __modes)
  ;




extern FILE *freopen (const char *restrict __filename,
        const char *restrict __modes,
        FILE *restrict __stream) ;
# 341 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *restrict __stream, char *restrict __buf)
  ;



extern int setvbuf (FILE *restrict __stream, char *restrict __buf,
      int __modes, size_t __n) ;
# 364 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *restrict __stream,
      const char *restrict __format, ...) ;




extern int printf (const char *restrict __format, ...);

extern int sprintf (char *restrict __s,
      const char *restrict __format, ...) ;





extern int vfprintf (FILE *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;




extern int vprintf (const char *restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;



extern int snprintf (char *restrict __s, size_t __maxlen,
       const char *restrict __format, ...)
     ;

extern int vsnprintf (char *restrict __s, size_t __maxlen,
        const char *restrict __format, __gnuc_va_list __arg)
     ;
# 429 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *restrict __stream,
     const char *restrict __format, ...) ;




extern int scanf (const char *restrict __format, ...) ;

extern int sscanf (const char *restrict __s,
     const char *restrict __format, ...) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 445 "/usr/include/stdio.h" 2 3 4
# 479 "/usr/include/stdio.h" 3 4
extern int __isoc99_fscanf (FILE *restrict __stream,
       const char *restrict __format, ...)
  ;
extern int __isoc99_scanf (const char *restrict __format, ...) ;
extern int __isoc99_sscanf (const char *restrict __s,
       const char *restrict __format, ...) ;
# 497 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *restrict __s, const char *restrict __format,
      __gnuc_va_list __arg)
     ;





extern int vscanf (const char *restrict __format, __gnuc_va_list __arg)
     ;


extern int vsscanf (const char *restrict __s,
      const char *restrict __format, __gnuc_va_list __arg)
     ;
# 561 "/usr/include/stdio.h" 3 4
extern int __isoc99_vfscanf (FILE *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
extern int __isoc99_vscanf (const char *restrict __format,
       __gnuc_va_list __arg) ;
extern int __isoc99_vsscanf (const char *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
# 582 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) ;
extern int getc (FILE *__stream) ;





extern int getchar (void);
# 615 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) ;
extern int putc (int __c, FILE *__stream) ;





extern int putchar (int __c);
# 658 "/usr/include/stdio.h" 3 4
extern char *fgets (char *restrict __s, int __n, FILE *restrict __stream)
     ;
# 671 "/usr/include/stdio.h" 3 4
extern char *gets (char *__s) ;
# 711 "/usr/include/stdio.h" 3 4
extern int fputs (const char *restrict __s, FILE *restrict __stream)
  ;





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) ;






extern size_t fread (void *restrict __ptr, size_t __size,
       size_t __n, FILE *restrict __stream)
  ;




extern size_t fwrite (const void *restrict __ptr, size_t __size,
        size_t __n, FILE *restrict __s) ;
# 773 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  ;




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream) ;
# 823 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *restrict __stream, fpos_t *restrict __pos)
  ;




extern int fsetpos (FILE *__stream, const fpos_t *__pos) ;
# 854 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) ;

extern int feof (FILE *__stream) ;

extern int ferror (FILE *__stream) ;
# 872 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) ;
# 953 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 977 "/usr/include/stdio.h" 3 4

# 3 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4


# 37 "/usr/include/string.h" 3 4
# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 38 "/usr/include/string.h" 2 3 4
# 47 "/usr/include/string.h" 3 4
extern void *memcpy (void *restrict __dest, const void *restrict __src,
       size_t __n) ;


extern void *memmove (void *__dest, const void *__src, size_t __n)
     ;
# 65 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) ;
# 75 "/usr/include/string.h" 3 4
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     ;
# 91 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     ;
# 118 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      ;
# 156 "/usr/include/string.h" 3 4
extern char *strcpy (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncpy (char *restrict __dest,
        const char *restrict __src, size_t __n)
     ;


extern char *strcat (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncat (char *restrict __dest, const char *restrict __src,
        size_t __n) ;


extern int strcmp (const char *__s1, const char *__s2)
     ;

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     ;


extern int strcoll (const char *__s1, const char *__s2)
     ;

extern size_t strxfrm (char *restrict __dest,
         const char *restrict __src, size_t __n)
    ;
# 261 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     ;
# 292 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     ;
# 316 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     ;


extern size_t strspn (const char *__s, const char *__accept)
     ;
# 346 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     ;
# 377 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     ;
# 388 "/usr/include/string.h" 3 4
extern char *strtok (char *restrict __s, const char *restrict __delim)
     ;



extern char *__strtok_r (char *restrict __s,
    const char *restrict __delim,
    char **restrict __save_ptr)
     ;
# 439 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     ;
# 451 "/usr/include/string.h" 3 4
extern char *strerror (int __errnum) ;
# 584 "/usr/include/string.h" 3 4

# 4 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c" 2
# 1 "/usr/include/unistd.h" 1 3 4
# 27 "/usr/include/unistd.h" 3 4

# 202 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/posix_opt.h" 1 3 4
# 203 "/usr/include/unistd.h" 2 3 4
# 220 "/usr/include/unistd.h" 3 4
typedef __ssize_t ssize_t;





# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 227 "/usr/include/unistd.h" 2 3 4
# 287 "/usr/include/unistd.h" 3 4
extern int access (const char *__name, int __type) ;
# 339 "/usr/include/unistd.h" 3 4
extern __off_t lseek (int __fd, __off_t __offset, int __whence) ;
# 358 "/usr/include/unistd.h" 3 4
extern int close (int __fd);
# 371 "/usr/include/unistd.h" 3 4
extern ssize_t read (int __fd, void *__buf, size_t __nbytes)
    ;





extern ssize_t write (int __fd, const void *__buf, size_t __n)
    ;
# 437 "/usr/include/unistd.h" 3 4
extern int pipe (int __pipedes[2]) ;
# 452 "/usr/include/unistd.h" 3 4
extern unsigned int alarm (unsigned int __seconds) ;
# 464 "/usr/include/unistd.h" 3 4
extern unsigned int sleep (unsigned int __seconds);
# 489 "/usr/include/unistd.h" 3 4
extern int pause (void);



extern int chown (const char *__file, __uid_t __owner, __gid_t __group)
     ;
# 517 "/usr/include/unistd.h" 3 4
extern int chdir (const char *__path) ;
# 531 "/usr/include/unistd.h" 3 4
extern char *getcwd (char *__buf, size_t __size) ;
# 552 "/usr/include/unistd.h" 3 4
extern int dup (int __fd) ;


extern int dup2 (int __fd, int __fd2) ;
# 564 "/usr/include/unistd.h" 3 4
extern char **__environ;







extern int execve (const char *__path, char *const __argv[],
     char *const __envp[]) ;
# 584 "/usr/include/unistd.h" 3 4
extern int execv (const char *__path, char *const __argv[])
     ;



extern int execle (const char *__path, const char *__arg, ...)
     ;



extern int execl (const char *__path, const char *__arg, ...)
     ;



extern int execvp (const char *__file, char *const __argv[])
     ;




extern int execlp (const char *__file, const char *__arg, ...)
     ;
# 624 "/usr/include/unistd.h" 3 4
extern void _exit (int __status) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/confname.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/confname.h" 3 4
enum
  {
    _PC_LINK_MAX,

    _PC_MAX_CANON,

    _PC_MAX_INPUT,

    _PC_NAME_MAX,

    _PC_PATH_MAX,

    _PC_PIPE_BUF,

    _PC_CHOWN_RESTRICTED,

    _PC_NO_TRUNC,

    _PC_VDISABLE,

    _PC_SYNC_IO,

    _PC_ASYNC_IO,

    _PC_PRIO_IO,

    _PC_SOCK_MAXBUF,

    _PC_FILESIZEBITS,

    _PC_REC_INCR_XFER_SIZE,

    _PC_REC_MAX_XFER_SIZE,

    _PC_REC_MIN_XFER_SIZE,

    _PC_REC_XFER_ALIGN,

    _PC_ALLOC_SIZE_MIN,

    _PC_SYMLINK_MAX,

    _PC_2_SYMLINKS

  };


enum
  {
    _SC_ARG_MAX,

    _SC_CHILD_MAX,

    _SC_CLK_TCK,

    _SC_NGROUPS_MAX,

    _SC_OPEN_MAX,

    _SC_STREAM_MAX,

    _SC_TZNAME_MAX,

    _SC_JOB_CONTROL,

    _SC_SAVED_IDS,

    _SC_REALTIME_SIGNALS,

    _SC_PRIORITY_SCHEDULING,

    _SC_TIMERS,

    _SC_ASYNCHRONOUS_IO,

    _SC_PRIORITIZED_IO,

    _SC_SYNCHRONIZED_IO,

    _SC_FSYNC,

    _SC_MAPPED_FILES,

    _SC_MEMLOCK,

    _SC_MEMLOCK_RANGE,

    _SC_MEMORY_PROTECTION,

    _SC_MESSAGE_PASSING,

    _SC_SEMAPHORES,

    _SC_SHARED_MEMORY_OBJECTS,

    _SC_AIO_LISTIO_MAX,

    _SC_AIO_MAX,

    _SC_AIO_PRIO_DELTA_MAX,

    _SC_DELAYTIMER_MAX,

    _SC_MQ_OPEN_MAX,

    _SC_MQ_PRIO_MAX,

    _SC_VERSION,

    _SC_PAGESIZE,


    _SC_RTSIG_MAX,

    _SC_SEM_NSEMS_MAX,

    _SC_SEM_VALUE_MAX,

    _SC_SIGQUEUE_MAX,

    _SC_TIMER_MAX,




    _SC_BC_BASE_MAX,

    _SC_BC_DIM_MAX,

    _SC_BC_SCALE_MAX,

    _SC_BC_STRING_MAX,

    _SC_COLL_WEIGHTS_MAX,

    _SC_EQUIV_CLASS_MAX,

    _SC_EXPR_NEST_MAX,

    _SC_LINE_MAX,

    _SC_RE_DUP_MAX,

    _SC_CHARCLASS_NAME_MAX,


    _SC_2_VERSION,

    _SC_2_C_BIND,

    _SC_2_C_DEV,

    _SC_2_FORT_DEV,

    _SC_2_FORT_RUN,

    _SC_2_SW_DEV,

    _SC_2_LOCALEDEF,


    _SC_PII,

    _SC_PII_XTI,

    _SC_PII_SOCKET,

    _SC_PII_INTERNET,

    _SC_PII_OSI,

    _SC_POLL,

    _SC_SELECT,

    _SC_UIO_MAXIOV,

    _SC_IOV_MAX = _SC_UIO_MAXIOV,

    _SC_PII_INTERNET_STREAM,

    _SC_PII_INTERNET_DGRAM,

    _SC_PII_OSI_COTS,

    _SC_PII_OSI_CLTS,

    _SC_PII_OSI_M,

    _SC_T_IOV_MAX,



    _SC_THREADS,

    _SC_THREAD_SAFE_FUNCTIONS,

    _SC_GETGR_R_SIZE_MAX,

    _SC_GETPW_R_SIZE_MAX,

    _SC_LOGIN_NAME_MAX,

    _SC_TTY_NAME_MAX,

    _SC_THREAD_DESTRUCTOR_ITERATIONS,

    _SC_THREAD_KEYS_MAX,

    _SC_THREAD_STACK_MIN,

    _SC_THREAD_THREADS_MAX,

    _SC_THREAD_ATTR_STACKADDR,

    _SC_THREAD_ATTR_STACKSIZE,

    _SC_THREAD_PRIORITY_SCHEDULING,

    _SC_THREAD_PRIO_INHERIT,

    _SC_THREAD_PRIO_PROTECT,

    _SC_THREAD_PROCESS_SHARED,


    _SC_NPROCESSORS_CONF,

    _SC_NPROCESSORS_ONLN,

    _SC_PHYS_PAGES,

    _SC_AVPHYS_PAGES,

    _SC_ATEXIT_MAX,

    _SC_PASS_MAX,


    _SC_XOPEN_VERSION,

    _SC_XOPEN_XCU_VERSION,

    _SC_XOPEN_UNIX,

    _SC_XOPEN_CRYPT,

    _SC_XOPEN_ENH_I18N,

    _SC_XOPEN_SHM,


    _SC_2_CHAR_TERM,

    _SC_2_C_VERSION,

    _SC_2_UPE,


    _SC_XOPEN_XPG2,

    _SC_XOPEN_XPG3,

    _SC_XOPEN_XPG4,


    _SC_CHAR_BIT,

    _SC_CHAR_MAX,

    _SC_CHAR_MIN,

    _SC_INT_MAX,

    _SC_INT_MIN,

    _SC_LONG_BIT,

    _SC_WORD_BIT,

    _SC_MB_LEN_MAX,

    _SC_NZERO,

    _SC_SSIZE_MAX,

    _SC_SCHAR_MAX,

    _SC_SCHAR_MIN,

    _SC_SHRT_MAX,

    _SC_SHRT_MIN,

    _SC_UCHAR_MAX,

    _SC_UINT_MAX,

    _SC_ULONG_MAX,

    _SC_USHRT_MAX,


    _SC_NL_ARGMAX,

    _SC_NL_LANGMAX,

    _SC_NL_MSGMAX,

    _SC_NL_NMAX,

    _SC_NL_SETMAX,

    _SC_NL_TEXTMAX,


    _SC_XBS5_ILP32_OFF32,

    _SC_XBS5_ILP32_OFFBIG,

    _SC_XBS5_LP64_OFF64,

    _SC_XBS5_LPBIG_OFFBIG,


    _SC_XOPEN_LEGACY,

    _SC_XOPEN_REALTIME,

    _SC_XOPEN_REALTIME_THREADS,


    _SC_ADVISORY_INFO,

    _SC_BARRIERS,

    _SC_BASE,

    _SC_C_LANG_SUPPORT,

    _SC_C_LANG_SUPPORT_R,

    _SC_CLOCK_SELECTION,

    _SC_CPUTIME,

    _SC_THREAD_CPUTIME,

    _SC_DEVICE_IO,

    _SC_DEVICE_SPECIFIC,

    _SC_DEVICE_SPECIFIC_R,

    _SC_FD_MGMT,

    _SC_FIFO,

    _SC_PIPE,

    _SC_FILE_ATTRIBUTES,

    _SC_FILE_LOCKING,

    _SC_FILE_SYSTEM,

    _SC_MONOTONIC_CLOCK,

    _SC_MULTI_PROCESS,

    _SC_SINGLE_PROCESS,

    _SC_NETWORKING,

    _SC_READER_WRITER_LOCKS,

    _SC_SPIN_LOCKS,

    _SC_REGEXP,

    _SC_REGEX_VERSION,

    _SC_SHELL,

    _SC_SIGNALS,

    _SC_SPAWN,

    _SC_SPORADIC_SERVER,

    _SC_THREAD_SPORADIC_SERVER,

    _SC_SYSTEM_DATABASE,

    _SC_SYSTEM_DATABASE_R,

    _SC_TIMEOUTS,

    _SC_TYPED_MEMORY_OBJECTS,

    _SC_USER_GROUPS,

    _SC_USER_GROUPS_R,

    _SC_2_PBS,

    _SC_2_PBS_ACCOUNTING,

    _SC_2_PBS_LOCATE,

    _SC_2_PBS_MESSAGE,

    _SC_2_PBS_TRACK,

    _SC_SYMLOOP_MAX,

    _SC_STREAMS,

    _SC_2_PBS_CHECKPOINT,


    _SC_V6_ILP32_OFF32,

    _SC_V6_ILP32_OFFBIG,

    _SC_V6_LP64_OFF64,

    _SC_V6_LPBIG_OFFBIG,


    _SC_HOST_NAME_MAX,

    _SC_TRACE,

    _SC_TRACE_EVENT_FILTER,

    _SC_TRACE_INHERIT,

    _SC_TRACE_LOG,


    _SC_LEVEL1_ICACHE_SIZE,

    _SC_LEVEL1_ICACHE_ASSOC,

    _SC_LEVEL1_ICACHE_LINESIZE,

    _SC_LEVEL1_DCACHE_SIZE,

    _SC_LEVEL1_DCACHE_ASSOC,

    _SC_LEVEL1_DCACHE_LINESIZE,

    _SC_LEVEL2_CACHE_SIZE,

    _SC_LEVEL2_CACHE_ASSOC,

    _SC_LEVEL2_CACHE_LINESIZE,

    _SC_LEVEL3_CACHE_SIZE,

    _SC_LEVEL3_CACHE_ASSOC,

    _SC_LEVEL3_CACHE_LINESIZE,

    _SC_LEVEL4_CACHE_SIZE,

    _SC_LEVEL4_CACHE_ASSOC,

    _SC_LEVEL4_CACHE_LINESIZE,



    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,

    _SC_RAW_SOCKETS,


    _SC_V7_ILP32_OFF32,

    _SC_V7_ILP32_OFFBIG,

    _SC_V7_LP64_OFF64,

    _SC_V7_LPBIG_OFFBIG,


    _SC_SS_REPL_MAX,


    _SC_TRACE_EVENT_NAME_MAX,

    _SC_TRACE_NAME_MAX,

    _SC_TRACE_SYS_MAX,

    _SC_TRACE_USER_EVENT_MAX,


    _SC_XOPEN_STREAMS,


    _SC_THREAD_ROBUST_PRIO_INHERIT,

    _SC_THREAD_ROBUST_PRIO_PROTECT,


    _SC_MINSIGSTKSZ,


    _SC_SIGSTKSZ

  };


enum
  {
    _CS_PATH,


    _CS_V6_WIDTH_RESTRICTED_ENVS,



    _CS_GNU_LIBC_VERSION,

    _CS_GNU_LIBPTHREAD_VERSION,


    _CS_V5_WIDTH_RESTRICTED_ENVS,



    _CS_V7_WIDTH_RESTRICTED_ENVS,



    _CS_LFS_CFLAGS = 1000,

    _CS_LFS_LDFLAGS,

    _CS_LFS_LIBS,

    _CS_LFS_LINTFLAGS,

    _CS_LFS64_CFLAGS,

    _CS_LFS64_LDFLAGS,

    _CS_LFS64_LIBS,

    _CS_LFS64_LINTFLAGS,


    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,

    _CS_XBS5_ILP32_OFF32_LDFLAGS,

    _CS_XBS5_ILP32_OFF32_LIBS,

    _CS_XBS5_ILP32_OFF32_LINTFLAGS,

    _CS_XBS5_ILP32_OFFBIG_CFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LIBS,

    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,

    _CS_XBS5_LP64_OFF64_CFLAGS,

    _CS_XBS5_LP64_OFF64_LDFLAGS,

    _CS_XBS5_LP64_OFF64_LIBS,

    _CS_XBS5_LP64_OFF64_LINTFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LIBS,

    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LIBS,

    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V6_LP64_OFF64_CFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LIBS,

    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LIBS,

    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V7_LP64_OFF64_CFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LIBS,

    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,


    _CS_V6_ENV,

    _CS_V7_ENV

  };
# 631 "/usr/include/unistd.h" 2 3 4


extern long int pathconf (const char *__path, int __name)
     ;


extern long int fpathconf (int __fd, int __name) ;


extern long int sysconf (int __name) ;
# 650 "/usr/include/unistd.h" 3 4
extern __pid_t getpid (void) ;


extern __pid_t getppid (void) ;


extern __pid_t getpgrp (void) ;


extern __pid_t __getpgid (__pid_t __pid) ;
# 668 "/usr/include/unistd.h" 3 4
extern int setpgid (__pid_t __pid, __pid_t __pgid) ;
# 689 "/usr/include/unistd.h" 3 4
extern __pid_t setsid (void) ;







extern __uid_t getuid (void) ;


extern __uid_t geteuid (void) ;


extern __gid_t getgid (void) ;


extern __gid_t getegid (void) ;




extern int getgroups (int __size, __gid_t __list[])
    ;
# 722 "/usr/include/unistd.h" 3 4
extern int setuid (__uid_t __uid) ;
# 739 "/usr/include/unistd.h" 3 4
extern int setgid (__gid_t __gid) ;
# 778 "/usr/include/unistd.h" 3 4
extern __pid_t fork (void) ;
# 799 "/usr/include/unistd.h" 3 4
extern char *ttyname (int __fd) ;



extern int ttyname_r (int __fd, char *__buf, size_t __buflen)
    
     ;



extern int isatty (int __fd) ;
# 819 "/usr/include/unistd.h" 3 4
extern int link (const char *__from, const char *__to)
     ;
# 858 "/usr/include/unistd.h" 3 4
extern int unlink (const char *__name) ;
# 867 "/usr/include/unistd.h" 3 4
extern int rmdir (const char *__path) ;



extern __pid_t tcgetpgrp (int __fd) ;


extern int tcsetpgrp (int __fd, __pid_t __pgrp_id) ;






extern char *getlogin (void);
# 989 "/usr/include/unistd.h" 3 4
extern int fsync (int __fd);
# 1221 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/unistd_ext.h" 1 3 4
# 1222 "/usr/include/unistd.h" 2 3 4


# 5 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_decl.h" 1







# 7 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_decl.h"
extern int failed;

static void failure(const char * assertion, const char * file,
                    int line, const char * fn)
{
  fprintf(
# 12 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_decl.h" 3 4
         stderr
# 12 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_decl.h"
               , "%s:%d:%s: assertion %s failed\n", file, line, fn, assertion);
  failed = 1;
}



struct s1 {
  unsigned char a;
};
extern struct s1 f1(void);
extern void f2(struct s1 x0);
extern void f3(struct s1 x0, struct s1 x1);
extern void f4(int x0, struct s1 x1);
extern void f5(double x0, struct s1 x1);
struct s2 {
  signed char a;
};
extern struct s2 f6(void);
extern void f7(struct s2 x0);
extern void f8(struct s2 x0, struct s2 x1);
extern void f9(int x0, struct s2 x1);
extern void f10(double x0, struct s2 x1);
struct s3 {
  unsigned short a;
};
extern struct s3 f11(void);
extern void f12(struct s3 x0);
extern void f13(struct s3 x0, struct s3 x1);
extern void f14(int x0, struct s3 x1);
extern void f15(double x0, struct s3 x1);
struct s4 {
  short a;
};
extern struct s4 f16(void);
extern void f17(struct s4 x0);
extern void f18(struct s4 x0, struct s4 x1);
extern void f19(int x0, struct s4 x1);
extern void f20(double x0, struct s4 x1);
struct s5 {
  int a;
};
extern struct s5 f21(void);
extern void f22(struct s5 x0);
extern void f23(struct s5 x0, struct s5 x1);
extern void f24(int x0, struct s5 x1);
extern void f25(double x0, struct s5 x1);
struct s6 {
  long long a;
};
extern struct s6 f26(void);
extern void f27(struct s6 x0);
extern void f28(struct s6 x0, struct s6 x1);
extern void f29(int x0, struct s6 x1);
extern void f30(double x0, struct s6 x1);
struct s7 {
  float a;
};
extern struct s7 f31(void);
extern void f32(struct s7 x0);
extern void f33(struct s7 x0, struct s7 x1);
extern void f34(int x0, struct s7 x1);
extern void f35(double x0, struct s7 x1);
struct s8 {
  double a;
};
extern struct s8 f36(void);
extern void f37(struct s8 x0);
extern void f38(struct s8 x0, struct s8 x1);
extern void f39(int x0, struct s8 x1);
extern void f40(double x0, struct s8 x1);
struct s9 {
  char * a;
};
extern struct s9 f41(void);
extern void f42(struct s9 x0);
extern void f43(struct s9 x0, struct s9 x1);
extern void f44(int x0, struct s9 x1);
extern void f45(double x0, struct s9 x1);
struct s10 {
  unsigned char a;
  unsigned char b;
};
extern struct s10 f46(void);
extern void f47(struct s10 x0);
extern void f48(struct s10 x0, struct s10 x1);
extern void f49(int x0, struct s10 x1);
extern void f50(double x0, struct s10 x1);
struct s11 {
  unsigned char a;
  unsigned short b;
};
extern struct s11 f51(void);
extern void f52(struct s11 x0);
extern void f53(struct s11 x0, struct s11 x1);
extern void f54(int x0, struct s11 x1);
extern void f55(double x0, struct s11 x1);
struct s12 {
  unsigned char a;
  int b;
};
extern struct s12 f56(void);
extern void f57(struct s12 x0);
extern void f58(struct s12 x0, struct s12 x1);
extern void f59(int x0, struct s12 x1);
extern void f60(double x0, struct s12 x1);
struct s13 {
  unsigned char a;
  long long b;
};
extern struct s13 f61(void);
extern void f62(struct s13 x0);
extern void f63(struct s13 x0, struct s13 x1);
extern void f64(int x0, struct s13 x1);
extern void f65(double x0, struct s13 x1);
struct s14 {
  unsigned char a;
  float b;
};
extern struct s14 f66(void);
extern void f67(struct s14 x0);
extern void f68(struct s14 x0, struct s14 x1);
extern void f69(int x0, struct s14 x1);
extern void f70(double x0, struct s14 x1);
struct s15 {
  unsigned char a;
  double b;
};
extern struct s15 f71(void);
extern void f72(struct s15 x0);
extern void f73(struct s15 x0, struct s15 x1);
extern void f74(int x0, struct s15 x1);
extern void f75(double x0, struct s15 x1);
struct s16 {
  unsigned short a;
  unsigned char b;
};
extern struct s16 f76(void);
extern void f77(struct s16 x0);
extern void f78(struct s16 x0, struct s16 x1);
extern void f79(int x0, struct s16 x1);
extern void f80(double x0, struct s16 x1);
struct s17 {
  unsigned short a;
  unsigned short b;
};
extern struct s17 f81(void);
extern void f82(struct s17 x0);
extern void f83(struct s17 x0, struct s17 x1);
extern void f84(int x0, struct s17 x1);
extern void f85(double x0, struct s17 x1);
struct s18 {
  unsigned short a;
  int b;
};
extern struct s18 f86(void);
extern void f87(struct s18 x0);
extern void f88(struct s18 x0, struct s18 x1);
extern void f89(int x0, struct s18 x1);
extern void f90(double x0, struct s18 x1);
struct s19 {
  unsigned short a;
  long long b;
};
extern struct s19 f91(void);
extern void f92(struct s19 x0);
extern void f93(struct s19 x0, struct s19 x1);
extern void f94(int x0, struct s19 x1);
extern void f95(double x0, struct s19 x1);
struct s20 {
  unsigned short a;
  float b;
};
extern struct s20 f96(void);
extern void f97(struct s20 x0);
extern void f98(struct s20 x0, struct s20 x1);
extern void f99(int x0, struct s20 x1);
extern void f100(double x0, struct s20 x1);
struct s21 {
  unsigned short a;
  double b;
};
extern struct s21 f101(void);
extern void f102(struct s21 x0);
extern void f103(struct s21 x0, struct s21 x1);
extern void f104(int x0, struct s21 x1);
extern void f105(double x0, struct s21 x1);
struct s22 {
  int a;
  unsigned char b;
};
extern struct s22 f106(void);
extern void f107(struct s22 x0);
extern void f108(struct s22 x0, struct s22 x1);
extern void f109(int x0, struct s22 x1);
extern void f110(double x0, struct s22 x1);
struct s23 {
  int a;
  unsigned short b;
};
extern struct s23 f111(void);
extern void f112(struct s23 x0);
extern void f113(struct s23 x0, struct s23 x1);
extern void f114(int x0, struct s23 x1);
extern void f115(double x0, struct s23 x1);
struct s24 {
  int a;
  int b;
};
extern struct s24 f116(void);
extern void f117(struct s24 x0);
extern void f118(struct s24 x0, struct s24 x1);
extern void f119(int x0, struct s24 x1);
extern void f120(double x0, struct s24 x1);
struct s25 {
  int a;
  long long b;
};
extern struct s25 f121(void);
extern void f122(struct s25 x0);
extern void f123(struct s25 x0, struct s25 x1);
extern void f124(int x0, struct s25 x1);
extern void f125(double x0, struct s25 x1);
struct s26 {
  int a;
  float b;
};
extern struct s26 f126(void);
extern void f127(struct s26 x0);
extern void f128(struct s26 x0, struct s26 x1);
extern void f129(int x0, struct s26 x1);
extern void f130(double x0, struct s26 x1);
struct s27 {
  int a;
  double b;
};
extern struct s27 f131(void);
extern void f132(struct s27 x0);
extern void f133(struct s27 x0, struct s27 x1);
extern void f134(int x0, struct s27 x1);
extern void f135(double x0, struct s27 x1);
struct s28 {
  long long a;
  unsigned char b;
};
extern struct s28 f136(void);
extern void f137(struct s28 x0);
extern void f138(struct s28 x0, struct s28 x1);
extern void f139(int x0, struct s28 x1);
extern void f140(double x0, struct s28 x1);
struct s29 {
  long long a;
  unsigned short b;
};
extern struct s29 f141(void);
extern void f142(struct s29 x0);
extern void f143(struct s29 x0, struct s29 x1);
extern void f144(int x0, struct s29 x1);
extern void f145(double x0, struct s29 x1);
struct s30 {
  long long a;
  int b;
};
extern struct s30 f146(void);
extern void f147(struct s30 x0);
extern void f148(struct s30 x0, struct s30 x1);
extern void f149(int x0, struct s30 x1);
extern void f150(double x0, struct s30 x1);
struct s31 {
  long long a;
  long long b;
};
extern struct s31 f151(void);
extern void f152(struct s31 x0);
extern void f153(struct s31 x0, struct s31 x1);
extern void f154(int x0, struct s31 x1);
extern void f155(double x0, struct s31 x1);
struct s32 {
  long long a;
  float b;
};
extern struct s32 f156(void);
extern void f157(struct s32 x0);
extern void f158(struct s32 x0, struct s32 x1);
extern void f159(int x0, struct s32 x1);
extern void f160(double x0, struct s32 x1);
struct s33 {
  long long a;
  double b;
};
extern struct s33 f161(void);
extern void f162(struct s33 x0);
extern void f163(struct s33 x0, struct s33 x1);
extern void f164(int x0, struct s33 x1);
extern void f165(double x0, struct s33 x1);
struct s34 {
  float a;
  unsigned char b;
};
extern struct s34 f166(void);
extern void f167(struct s34 x0);
extern void f168(struct s34 x0, struct s34 x1);
extern void f169(int x0, struct s34 x1);
extern void f170(double x0, struct s34 x1);
struct s35 {
  float a;
  unsigned short b;
};
extern struct s35 f171(void);
extern void f172(struct s35 x0);
extern void f173(struct s35 x0, struct s35 x1);
extern void f174(int x0, struct s35 x1);
extern void f175(double x0, struct s35 x1);
struct s36 {
  float a;
  int b;
};
extern struct s36 f176(void);
extern void f177(struct s36 x0);
extern void f178(struct s36 x0, struct s36 x1);
extern void f179(int x0, struct s36 x1);
extern void f180(double x0, struct s36 x1);
struct s37 {
  float a;
  long long b;
};
extern struct s37 f181(void);
extern void f182(struct s37 x0);
extern void f183(struct s37 x0, struct s37 x1);
extern void f184(int x0, struct s37 x1);
extern void f185(double x0, struct s37 x1);
struct s38 {
  float a;
  float b;
};
extern struct s38 f186(void);
extern void f187(struct s38 x0);
extern void f188(struct s38 x0, struct s38 x1);
extern void f189(int x0, struct s38 x1);
extern void f190(double x0, struct s38 x1);
struct s39 {
  float a;
  double b;
};
extern struct s39 f191(void);
extern void f192(struct s39 x0);
extern void f193(struct s39 x0, struct s39 x1);
extern void f194(int x0, struct s39 x1);
extern void f195(double x0, struct s39 x1);
struct s40 {
  double a;
  unsigned char b;
};
extern struct s40 f196(void);
extern void f197(struct s40 x0);
extern void f198(struct s40 x0, struct s40 x1);
extern void f199(int x0, struct s40 x1);
extern void f200(double x0, struct s40 x1);
struct s41 {
  double a;
  unsigned short b;
};
extern struct s41 f201(void);
extern void f202(struct s41 x0);
extern void f203(struct s41 x0, struct s41 x1);
extern void f204(int x0, struct s41 x1);
extern void f205(double x0, struct s41 x1);
struct s42 {
  double a;
  int b;
};
extern struct s42 f206(void);
extern void f207(struct s42 x0);
extern void f208(struct s42 x0, struct s42 x1);
extern void f209(int x0, struct s42 x1);
extern void f210(double x0, struct s42 x1);
struct s43 {
  double a;
  long long b;
};
extern struct s43 f211(void);
extern void f212(struct s43 x0);
extern void f213(struct s43 x0, struct s43 x1);
extern void f214(int x0, struct s43 x1);
extern void f215(double x0, struct s43 x1);
struct s44 {
  double a;
  float b;
};
extern struct s44 f216(void);
extern void f217(struct s44 x0);
extern void f218(struct s44 x0, struct s44 x1);
extern void f219(int x0, struct s44 x1);
extern void f220(double x0, struct s44 x1);
struct s45 {
  double a;
  double b;
};
extern struct s45 f221(void);
extern void f222(struct s45 x0);
extern void f223(struct s45 x0, struct s45 x1);
extern void f224(int x0, struct s45 x1);
extern void f225(double x0, struct s45 x1);
struct s46 {
  unsigned char a;
  unsigned char b;
  unsigned char c;
};
extern struct s46 f226(void);
extern void f227(struct s46 x0);
extern void f228(struct s46 x0, struct s46 x1);
extern void f229(int x0, struct s46 x1);
extern void f230(double x0, struct s46 x1);
struct s47 {
  unsigned char a;
  unsigned char b;
  unsigned char c;
  unsigned char d;
};
extern struct s47 f231(void);
extern void f232(struct s47 x0);
extern void f233(struct s47 x0, struct s47 x1);
extern void f234(int x0, struct s47 x1);
extern void f235(double x0, struct s47 x1);
struct s48 {
  unsigned char a;
  unsigned char b;
  unsigned char c;
  unsigned char d;
  unsigned char e;
  unsigned char f;
};
extern struct s48 f236(void);
extern void f237(struct s48 x0);
extern void f238(struct s48 x0, struct s48 x1);
extern void f239(int x0, struct s48 x1);
extern void f240(double x0, struct s48 x1);
struct s49 {
  unsigned char a;
  unsigned char b;
  unsigned char c;
  unsigned char d;
  unsigned char e;
  unsigned char f;
  unsigned char g;
  unsigned char h;
};
extern struct s49 f241(void);
extern void f242(struct s49 x0);
extern void f243(struct s49 x0, struct s49 x1);
extern void f244(int x0, struct s49 x1);
extern void f245(double x0, struct s49 x1);
struct s50 {
  unsigned short a;
  unsigned short b;
  unsigned short c;
};
extern struct s50 f246(void);
extern void f247(struct s50 x0);
extern void f248(struct s50 x0, struct s50 x1);
extern void f249(int x0, struct s50 x1);
extern void f250(double x0, struct s50 x1);
struct s51 {
  unsigned short a;
  unsigned short b;
  unsigned short c;
  unsigned short d;
};
extern struct s51 f251(void);
extern void f252(struct s51 x0);
extern void f253(struct s51 x0, struct s51 x1);
extern void f254(int x0, struct s51 x1);
extern void f255(double x0, struct s51 x1);
struct s52 {
  unsigned short a;
  unsigned short b;
  unsigned short c;
  unsigned short d;
  unsigned short e;
  unsigned short f;
};
extern struct s52 f256(void);
extern void f257(struct s52 x0);
extern void f258(struct s52 x0, struct s52 x1);
extern void f259(int x0, struct s52 x1);
extern void f260(double x0, struct s52 x1);
struct s53 {
  unsigned short a;
  unsigned short b;
  unsigned short c;
  unsigned short d;
  unsigned short e;
  unsigned short f;
  unsigned short g;
  unsigned short h;
};
extern struct s53 f261(void);
extern void f262(struct s53 x0);
extern void f263(struct s53 x0, struct s53 x1);
extern void f264(int x0, struct s53 x1);
extern void f265(double x0, struct s53 x1);
struct s54 {
  int a;
  int b;
  int c;
};
extern struct s54 f266(void);
extern void f267(struct s54 x0);
extern void f268(struct s54 x0, struct s54 x1);
extern void f269(int x0, struct s54 x1);
extern void f270(double x0, struct s54 x1);
struct s55 {
  int a;
  int b;
  int c;
  int d;
};
extern struct s55 f271(void);
extern void f272(struct s55 x0);
extern void f273(struct s55 x0, struct s55 x1);
extern void f274(int x0, struct s55 x1);
extern void f275(double x0, struct s55 x1);
struct s56 {
  int a;
  int b;
  int c;
  int d;
  int e;
  int f;
};
extern struct s56 f276(void);
extern void f277(struct s56 x0);
extern void f278(struct s56 x0, struct s56 x1);
extern void f279(int x0, struct s56 x1);
extern void f280(double x0, struct s56 x1);
struct s57 {
  int a;
  int b;
  int c;
  int d;
  int e;
  int f;
  int g;
  int h;
};
extern struct s57 f281(void);
extern void f282(struct s57 x0);
extern void f283(struct s57 x0, struct s57 x1);
extern void f284(int x0, struct s57 x1);
extern void f285(double x0, struct s57 x1);
struct s58 {
  long long a;
  long long b;
  long long c;
};
extern struct s58 f286(void);
extern void f287(struct s58 x0);
extern void f288(struct s58 x0, struct s58 x1);
extern void f289(int x0, struct s58 x1);
extern void f290(double x0, struct s58 x1);
struct s59 {
  long long a;
  long long b;
  long long c;
  long long d;
};
extern struct s59 f291(void);
extern void f292(struct s59 x0);
extern void f293(struct s59 x0, struct s59 x1);
extern void f294(int x0, struct s59 x1);
extern void f295(double x0, struct s59 x1);
struct s60 {
  long long a;
  long long b;
  long long c;
  long long d;
  long long e;
  long long f;
};
extern struct s60 f296(void);
extern void f297(struct s60 x0);
extern void f298(struct s60 x0, struct s60 x1);
extern void f299(int x0, struct s60 x1);
extern void f300(double x0, struct s60 x1);
struct s61 {
  long long a;
  long long b;
  long long c;
  long long d;
  long long e;
  long long f;
  long long g;
  long long h;
};
extern struct s61 f301(void);
extern void f302(struct s61 x0);
extern void f303(struct s61 x0, struct s61 x1);
extern void f304(int x0, struct s61 x1);
extern void f305(double x0, struct s61 x1);
struct s62 {
  float a;
  float b;
  float c;
};
extern struct s62 f306(void);
extern void f307(struct s62 x0);
extern void f308(struct s62 x0, struct s62 x1);
extern void f309(int x0, struct s62 x1);
extern void f310(double x0, struct s62 x1);
struct s63 {
  float a;
  float b;
  float c;
  float d;
};
extern struct s63 f311(void);
extern void f312(struct s63 x0);
extern void f313(struct s63 x0, struct s63 x1);
extern void f314(int x0, struct s63 x1);
extern void f315(double x0, struct s63 x1);
struct s64 {
  float a;
  float b;
  float c;
  float d;
  float e;
  float f;
};
extern struct s64 f316(void);
extern void f317(struct s64 x0);
extern void f318(struct s64 x0, struct s64 x1);
extern void f319(int x0, struct s64 x1);
extern void f320(double x0, struct s64 x1);
struct s65 {
  float a;
  float b;
  float c;
  float d;
  float e;
  float f;
  float g;
  float h;
};
extern struct s65 f321(void);
extern void f322(struct s65 x0);
extern void f323(struct s65 x0, struct s65 x1);
extern void f324(int x0, struct s65 x1);
extern void f325(double x0, struct s65 x1);
struct s66 {
  double a;
  double b;
  double c;
};
extern struct s66 f326(void);
extern void f327(struct s66 x0);
extern void f328(struct s66 x0, struct s66 x1);
extern void f329(int x0, struct s66 x1);
extern void f330(double x0, struct s66 x1);
struct s67 {
  double a;
  double b;
  double c;
  double d;
};
extern struct s67 f331(void);
extern void f332(struct s67 x0);
extern void f333(struct s67 x0, struct s67 x1);
extern void f334(int x0, struct s67 x1);
extern void f335(double x0, struct s67 x1);
struct s68 {
  double a;
  double b;
  double c;
  double d;
  double e;
  double f;
};
extern struct s68 f336(void);
extern void f337(struct s68 x0);
extern void f338(struct s68 x0, struct s68 x1);
extern void f339(int x0, struct s68 x1);
extern void f340(double x0, struct s68 x1);
struct s69 {
  double a;
  double b;
  double c;
  double d;
  double e;
  double f;
  double g;
  double h;
};
extern struct s69 f341(void);
extern void f342(struct s69 x0);
extern void f343(struct s69 x0, struct s69 x1);
extern void f344(int x0, struct s69 x1);
extern void f345(double x0, struct s69 x1);
# 6 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c" 2

int failed = 0;

void call_f1(void)
{
  struct s1 r = f1();
  ((r.a == 52) ? (void)0 : failure("r.a == 52","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",12,__func__));
}

void call_f2(void)
{
  f2((struct s1){-177445934});
}

void call_f3(void)
{
  f3((struct s1){527586794}, (struct s1){48391612});
}

void call_f4(void)
{
  f4(1815701022, (struct s1){-83025435});
}

void call_f5(void)
{
  f5(0x1.f76a831c5397p+2, (struct s1){249513733});
}

void call_f6(void)
{
  struct s2 r = f6();
  ((r.a == 25) ? (void)0 : failure("r.a == 25","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",38,__func__));
}

void call_f7(void)
{
  f7((struct s2){27084695});
}

void call_f8(void)
{
  f8((struct s2){265665610}, (struct s2){-344555561});
}

void call_f9(void)
{
  f9(1947842430, (struct s2){317650142});
}

void call_f10(void)
{
  f10(0x1.1fc90e8ae4d78p+5, (struct s2){-456258725});
}

void call_f11(void)
{
  struct s3 r = f11();
  ((r.a == 46454) ? (void)0 : failure("r.a == 46454","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",64,__func__));
}

void call_f12(void)
{
  f12((struct s3){-441782574});
}

void call_f13(void)
{
  f13((struct s3){-15484683}, (struct s3){-8495099});
}

void call_f14(void)
{
  f14(242953397, (struct s3){-198261959});
}

void call_f15(void)
{
  f15(0x1.7c994f1a97fbp+3, (struct s3){-279736541});
}

void call_f16(void)
{
  struct s4 r = f16();
  ((r.a == 24455) ? (void)0 : failure("r.a == 24455","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",90,__func__));
}

void call_f17(void)
{
  f17((struct s4){-360232106});
}

void call_f18(void)
{
  f18((struct s4){-438560440}, (struct s4){-24313122});
}

void call_f19(void)
{
  f19(-1677478395, (struct s4){-122679040});
}

void call_f20(void)
{
  f20(0x1.098fb3dd45ef8p+5, (struct s4){-495206905});
}

void call_f21(void)
{
  struct s5 r = f21();
  ((r.a == 1577533673) ? (void)0 : failure("r.a == 1577533673","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",116,__func__));
}

void call_f22(void)
{
  f22((struct s5){2061240087});
}

void call_f23(void)
{
  f23((struct s5){109785855}, (struct s5){-1908988732});
}

void call_f24(void)
{
  f24(986535705, (struct s5){-275829590});
}

void call_f25(void)
{
  f25(0x1.b018822955398p+2, (struct s5){-1819372239});
}

void call_f26(void)
{
  struct s6 r = f26();
  ((r.a == -3105154652647668272) ? (void)0 : failure("r.a == -3105154652647668272","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",142,__func__));
}

void call_f27(void)
{
  f27((struct s6){3378611537454465391});
}

void call_f28(void)
{
  f28((struct s6){6537315735875373552}, (struct s6){3416050011937819997});
}

void call_f29(void)
{
  f29(-2123243015, (struct s6){-4770020751718028244});
}

void call_f30(void)
{
  f30(0x1.8bcde682c8466p+5, (struct s6){-3238782525965314528});
}

void call_f31(void)
{
  struct s7 r = f31();
  ((r.a == 0x1.1f537ep+5F) ? (void)0 : failure("r.a == 0x1.1f537ep+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",168,__func__));
}

void call_f32(void)
{
  f32((struct s7){-0x1.54fc0b912fd64p+5});
}

void call_f33(void)
{
  f33((struct s7){0x1.2740875bbfd64p+3}, (struct s7){-0x1.f723113b4d0ep+2});
}

void call_f34(void)
{
  f34(700688855, (struct s7){-0x1.c0617c7e65fd1p+4});
}

void call_f35(void)
{
  f35(-0x1.260a64981aed2p+4, (struct s7){-0x1.6070d3ba43266p+4});
}

void call_f36(void)
{
  struct s8 r = f36();
  ((r.a == -0x1.657e7ae346456p+4) ? (void)0 : failure("r.a == -0x1.657e7ae346456p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",194,__func__));
}

void call_f37(void)
{
  f37((struct s8){0x1.74a4ec30c5bcep+5});
}

void call_f38(void)
{
  f38((struct s8){0x1.3a13dc3c291b8p+5}, (struct s8){0x1.090bd2521edc4p+4});
}

void call_f39(void)
{
  f39(-1058592089, (struct s8){0x1.9512a51a88c2cp+4});
}

void call_f40(void)
{
  f40(-0x1.0cb18c10ff00ep+5, (struct s8){0x1.287d6f4752cd2p+5});
}

void call_f41(void)
{
  struct s9 r = f41();
  ((strcmp(r.a, "") == 0) ? (void)0 : failure("strcmp(r.a, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",220,__func__));
}

void call_f42(void)
{
  f42((struct s9){""});
}

void call_f43(void)
{
  f43((struct s9){""}, (struct s9){"s"});
}

void call_f44(void)
{
  f44(117078430, (struct s9){"e"});
}

void call_f45(void)
{
  f45(-0x1.1870de6a4f604p+3, (struct s9){"o"});
}

void call_f46(void)
{
  struct s10 r = f46();
  ((r.a == 76) ? (void)0 : failure("r.a == 76","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",246,__func__));
  ((r.b == 190) ? (void)0 : failure("r.b == 190","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",247,__func__));
}

void call_f47(void)
{
  f47((struct s10){66456464, -387370938});
}

void call_f48(void)
{
  f48((struct s10){-319439611, 352607360}, (struct s10){-485759274, 311164688});
}

void call_f49(void)
{
  f49(-1112381232, (struct s10){321034035, 400792330});
}

void call_f50(void)
{
  f50(0x1.058d46e3148b2p+5, (struct s10){-370120241, 275306713});
}

void call_f51(void)
{
  struct s11 r = f51();
  ((r.a == 239) ? (void)0 : failure("r.a == 239","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",273,__func__));
  ((r.b == 5513) ? (void)0 : failure("r.b == 5513","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",274,__func__));
}

void call_f52(void)
{
  f52((struct s11){144762427, -151798230});
}

void call_f53(void)
{
  f53((struct s11){-360196105, -481368232}, (struct s11){393124014, -479218471});
}

void call_f54(void)
{
  f54(1285894652, (struct s11){-502720484, -246568768});
}

void call_f55(void)
{
  f55(-0x1.58b8b10825683p+4, (struct s11){2402294, -447678113});
}

void call_f56(void)
{
  struct s12 r = f56();
  ((r.a == 180) ? (void)0 : failure("r.a == 180","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",300,__func__));
  ((r.b == -1906949473) ? (void)0 : failure("r.b == -1906949473","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",301,__func__));
}

void call_f57(void)
{
  f57((struct s12){-304289876, 1933564125});
}

void call_f58(void)
{
  f58((struct s12){-75047970, 1964828987}, (struct s12){182105261, -394622240});
}

void call_f59(void)
{
  f59(1060027508, (struct s12){-250469711, -1716875482});
}

void call_f60(void)
{
  f60(0x1.22424233d124cp+4, (struct s12){-366854687, -875240157});
}

void call_f61(void)
{
  struct s13 r = f61();
  ((r.a == 119) ? (void)0 : failure("r.a == 119","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",327,__func__));
  ((r.b == -5188281542945856611) ? (void)0 : failure("r.b == -5188281542945856611","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",328,__func__));
}

void call_f62(void)
{
  f62((struct s13){-97068798, 2436054323590893261});
}

void call_f63(void)
{
  f63((struct s13){400357480, -9002517791903262263}, (struct s13){-440368451, -5040905127155251799});
}

void call_f64(void)
{
  f64(-1607654603, (struct s13){495634989, -1163175273696450282});
}

void call_f65(void)
{
  f65(-0x1.25b6d9848376p+5, (struct s13){-38625966, 6629600029036599347});
}

void call_f66(void)
{
  struct s14 r = f66();
  ((r.a == 169) ? (void)0 : failure("r.a == 169","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",354,__func__));
  ((r.b == -0x1.87727ep+1F) ? (void)0 : failure("r.b == -0x1.87727ep+1F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",355,__func__));
}

void call_f67(void)
{
  f67((struct s14){-531156899, 0x1.559ab44f26aa8p+5});
}

void call_f68(void)
{
  f68((struct s14){344932834, -0x1.58fe98851c28p-1}, (struct s14){239122730, -0x1.3b4046343c179p+4});
}

void call_f69(void)
{
  f69(-2124451791, (struct s14){206802561, -0x1.0912903ae6cb1p+5});
}

void call_f70(void)
{
  f70(0x1.d0d8d023834a8p+2, (struct s14){3103283, -0x1.b7948cd45876cp+3});
}

void call_f71(void)
{
  struct s15 r = f71();
  ((r.a == 106) ? (void)0 : failure("r.a == 106","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",381,__func__));
  ((r.b == 0x1.83d073d680ecp+1) ? (void)0 : failure("r.b == 0x1.83d073d680ecp+1","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",382,__func__));
}

void call_f72(void)
{
  f72((struct s15){3190710, 0x1.75b0578c78b96p+5});
}

void call_f73(void)
{
  f73((struct s15){9230548, -0x1.34efea07bf133p+4}, (struct s15){363249592, 0x1.078c1542be3c4p+3});
}

void call_f74(void)
{
  f74(1723296699, (struct s15){182271467, 0x1.f529ed56a3e5p+3});
}

void call_f75(void)
{
  f75(-0x1.81ca9bad6beccp+4, (struct s15){513594751, -0x1.088acf1b29a78p+2});
}

void call_f76(void)
{
  struct s16 r = f76();
  ((r.a == 37718) ? (void)0 : failure("r.a == 37718","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",408,__func__));
  ((r.b == 180) ? (void)0 : failure("r.b == 180","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",409,__func__));
}

void call_f77(void)
{
  f77((struct s16){322873974, -365323843});
}

void call_f78(void)
{
  f78((struct s16){-314513351, 119776736}, (struct s16){145757589, -131946232});
}

void call_f79(void)
{
  f79(2121459177, (struct s16){-122691287, 492850590});
}

void call_f80(void)
{
  f80(0x1.cb6e5f02078d4p+4, (struct s16){507270678, -278442957});
}

void call_f81(void)
{
  struct s17 r = f81();
  ((r.a == 27796) ? (void)0 : failure("r.a == 27796","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",435,__func__));
  ((r.b == 48570) ? (void)0 : failure("r.b == 48570","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",436,__func__));
}

void call_f82(void)
{
  f82((struct s17){-30155962, -206025295});
}

void call_f83(void)
{
  f83((struct s17){-209316398, 435693267}, (struct s17){437993453, 421186564});
}

void call_f84(void)
{
  f84(1448707066, (struct s17){226574410, -77803650});
}

void call_f85(void)
{
  f85(-0x1.f322227d4f5p+1, (struct s17){495591358, -67330297});
}

void call_f86(void)
{
  struct s18 r = f86();
  ((r.a == 45584) ? (void)0 : failure("r.a == 45584","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",462,__func__));
  ((r.b == -180084018) ? (void)0 : failure("r.b == -180084018","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",463,__func__));
}

void call_f87(void)
{
  f87((struct s18){254889763, -1123699173});
}

void call_f88(void)
{
  f88((struct s18){-167260497, 1316307988}, (struct s18){206855412, 919168191});
}

void call_f89(void)
{
  f89(566498622, (struct s18){371111899, -1996126542});
}

void call_f90(void)
{
  f90(0x1.390233be9b4acp+5, (struct s18){68654270, -218736169});
}

void call_f91(void)
{
  struct s19 r = f91();
  ((r.a == 37273) ? (void)0 : failure("r.a == 37273","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",489,__func__));
  ((r.b == -1148990584631858503) ? (void)0 : failure("r.b == -1148990584631858503","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",490,__func__));
}

void call_f92(void)
{
  f92((struct s19){93743414, 4695337395212137791});
}

void call_f93(void)
{
  f93((struct s19){337594379, 2308107411769263091}, (struct s19){210869411, 853874488809628856});
}

void call_f94(void)
{
  f94(1506521253, (struct s19){344464050, -7881179922387171957});
}

void call_f95(void)
{
  f95(0x1.95a932ddd5878p+4, (struct s19){256800426, -6366729590814299418});
}

void call_f96(void)
{
  struct s20 r = f96();
  ((r.a == 25649) ? (void)0 : failure("r.a == 25649","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",516,__func__));
  ((r.b == -0x1.84558p+4F) ? (void)0 : failure("r.b == -0x1.84558p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",517,__func__));
}

void call_f97(void)
{
  f97((struct s20){-201346759, -0x1.7fcf88a68d97p+5});
}

void call_f98(void)
{
  f98((struct s20){40710812, 0x1.9caceb427d5ecp+4}, (struct s20){-335997068, -0x1.1117646d9d841p+5});
}

void call_f99(void)
{
  f99(244675052, (struct s20){440950997, -0x1.869ac3efd42edp+5});
}

void call_f100(void)
{
  f100(0x1.1366d3bc60632p+5, (struct s20){340497629, 0x1.716a61971fdfcp+5});
}

void call_f101(void)
{
  struct s21 r = f101();
  ((r.a == 47425) ? (void)0 : failure("r.a == 47425","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",543,__func__));
  ((r.b == -0x1.a265f09f9d44bp+4) ? (void)0 : failure("r.b == -0x1.a265f09f9d44bp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",544,__func__));
}

void call_f102(void)
{
  f102((struct s21){-196003780, -0x1.47ed990b20901p+5});
}

void call_f103(void)
{
  f103((struct s21){250907736, -0x1.34cf327e7c506p+5}, (struct s21){84594005, -0x1.103e8f280c46cp+4});
}

void call_f104(void)
{
  f104(1943647114, (struct s21){-258475809, 0x1.b8581fe8fe738p+3});
}

void call_f105(void)
{
  f105(-0x1.f71a225948d64p+3, (struct s21){-223988576, 0x1.61118e76f0f1ap+5});
}

void call_f106(void)
{
  struct s22 r = f106();
  ((r.a == 1859156861) ? (void)0 : failure("r.a == 1859156861","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",570,__func__));
  ((r.b == 125) ? (void)0 : failure("r.b == 125","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",571,__func__));
}

void call_f107(void)
{
  f107((struct s22){-1304936796, -238783002});
}

void call_f108(void)
{
  f108((struct s22){1062064619, -389783225}, (struct s22){-367540222, -289931675});
}

void call_f109(void)
{
  f109(866633562, (struct s22){783218622, 1490929});
}

void call_f110(void)
{
  f110(0x1.8eb2dd062617p+5, (struct s22){-1592439001, -42348102});
}

void call_f111(void)
{
  struct s23 r = f111();
  ((r.a == 246019086) ? (void)0 : failure("r.a == 246019086","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",597,__func__));
  ((r.b == 53856) ? (void)0 : failure("r.b == 53856","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",598,__func__));
}

void call_f112(void)
{
  f112((struct s23){-55831904, -156202692});
}

void call_f113(void)
{
  f113((struct s23){1416852830, 277507321}, (struct s23){-1403118349, -364360758});
}

void call_f114(void)
{
  f114(-2122589996, (struct s23){129359416, -451814871});
}

void call_f115(void)
{
  f115(-0x1.cabda96e77868p+3, (struct s23){-1279079508, 250271360});
}

void call_f116(void)
{
  struct s24 r = f116();
  ((r.a == -1812095004) ? (void)0 : failure("r.a == -1812095004","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",624,__func__));
  ((r.b == 1890498760) ? (void)0 : failure("r.b == 1890498760","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",625,__func__));
}

void call_f117(void)
{
  f117((struct s24){682879303, 1996844329});
}

void call_f118(void)
{
  f118((struct s24){-596900446, -1719405343}, (struct s24){1837081861, -873812894});
}

void call_f119(void)
{
  f119(353368475, (struct s24){-1256030666, 2028339913});
}

void call_f120(void)
{
  f120(0x1.603d4384a88p+3, (struct s24){-556428407, -152436980});
}

void call_f121(void)
{
  struct s25 r = f121();
  ((r.a == -1280826129) ? (void)0 : failure("r.a == -1280826129","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",651,__func__));
  ((r.b == -7316568651887840872) ? (void)0 : failure("r.b == -7316568651887840872","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",652,__func__));
}

void call_f122(void)
{
  f122((struct s25){1062776017, -9010939211461274409});
}

void call_f123(void)
{
  f123((struct s25){164787212, 7988486642612859523}, (struct s25){-1211633452, 4853087427906869595});
}

void call_f124(void)
{
  f124(-1128257059, (struct s25){-651978519, -1081522815091978829});
}

void call_f125(void)
{
  f125(0x1.d6a006879d244p+4, (struct s25){-409421860, -4100805016390209027});
}

void call_f126(void)
{
  struct s26 r = f126();
  ((r.a == -510167021) ? (void)0 : failure("r.a == -510167021","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",678,__func__));
  ((r.b == -0x1.0fcd96p+5F) ? (void)0 : failure("r.b == -0x1.0fcd96p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",679,__func__));
}

void call_f127(void)
{
  f127((struct s26){1571964502, 0x1.877759a5bb15cp+4});
}

void call_f128(void)
{
  f128((struct s26){-686332331, -0x1.185584d6c6602p+5}, (struct s26){-1172813156, -0x1.df67c4ddd676p+1});
}

void call_f129(void)
{
  f129(-1742504644, (struct s26){-750563089, -0x1.4c8af547dd585p+5});
}

void call_f130(void)
{
  f130(0x1.4e5f19dee8188p+2, (struct s26){-1538611978, 0x1.5b25a9546754cp+3});
}

void call_f131(void)
{
  struct s27 r = f131();
  ((r.a == -1473845158) ? (void)0 : failure("r.a == -1473845158","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",705,__func__));
  ((r.b == 0x1.6c855f5d7163cp+4) ? (void)0 : failure("r.b == 0x1.6c855f5d7163cp+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",706,__func__));
}

void call_f132(void)
{
  f132((struct s27){-304810474, 0x1.b8e539e4752bp+3});
}

void call_f133(void)
{
  f133((struct s27){-578950471, 0x1.39ecb3dea4d58p+2}, (struct s27){-1387722108, 0x1.a58f505e191p-2});
}

void call_f134(void)
{
  f134(1408255155, (struct s27){-1991287261, -0x1.b7c07b72f4fedp+4});
}

void call_f135(void)
{
  f135(0x1.279ee5a10222p+5, (struct s27){1408947757, -0x1.acbdf9a1b5766p+4});
}

void call_f136(void)
{
  struct s28 r = f136();
  ((r.a == -7378056962774999617) ? (void)0 : failure("r.a == -7378056962774999617","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",732,__func__));
  ((r.b == 240) ? (void)0 : failure("r.b == 240","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",733,__func__));
}

void call_f137(void)
{
  f137((struct s28){3005607600168193821, -517534572});
}

void call_f138(void)
{
  f138((struct s28){5011935939289949336, -278931782}, (struct s28){-6736231869584637411, -155316187});
}

void call_f139(void)
{
  f139(568895837, (struct s28){-2823089690153465173, -114309288});
}

void call_f140(void)
{
  f140(-0x1.0fdefcd5c7502p+5, (struct s28){7019838422983881864, -242016999});
}

void call_f141(void)
{
  struct s29 r = f141();
  ((r.a == -4946767010283495353) ? (void)0 : failure("r.a == -4946767010283495353","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",759,__func__));
  ((r.b == 2311) ? (void)0 : failure("r.b == 2311","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",760,__func__));
}

void call_f142(void)
{
  f142((struct s29){2141993738737130324, 30473732});
}

void call_f143(void)
{
  f143((struct s29){9199081016697467462, 139549719}, (struct s29){-3589997681132222015, 181541058});
}

void call_f144(void)
{
  f144(-1571880597, (struct s29){-4004709014795347406, -272980639});
}

void call_f145(void)
{
  f145(-0x1.438dbf1dbd2a4p+5, (struct s29){-4162783042393750771, 412463793});
}

void call_f146(void)
{
  struct s30 r = f146();
  ((r.a == -5480136876204796410) ? (void)0 : failure("r.a == -5480136876204796410","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",786,__func__));
  ((r.b == -734103738) ? (void)0 : failure("r.b == -734103738","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",787,__func__));
}

void call_f147(void)
{
  f147((struct s30){-7161632261904739433, 384679893});
}

void call_f148(void)
{
  f148((struct s30){1655943856802705669, -15766459}, (struct s30){2785457078199258533, -1219071335});
}

void call_f149(void)
{
  f149(-860567012, (struct s30){8701319485013396684, 397458395});
}

void call_f150(void)
{
  f150(-0x1.41052823ef161p+5, (struct s30){7672003959483129798, -237702836});
}

void call_f151(void)
{
  struct s31 r = f151();
  ((r.a == -710116634788725456) ? (void)0 : failure("r.a == -710116634788725456","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",813,__func__));
  ((r.b == -1125746084457454639) ? (void)0 : failure("r.b == -1125746084457454639","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",814,__func__));
}

void call_f152(void)
{
  f152((struct s31){-2867377179166082689, 2438115870243609249});
}

void call_f153(void)
{
  f153((struct s31){-5567481585363274997, -5810483165404764631}, (struct s31){-5673725954458197362, -7902545747332296229});
}

void call_f154(void)
{
  f154(445643060, (struct s31){-6407157356906237087, -7912635108962811880});
}

void call_f155(void)
{
  f155(0x1.2fc80b7609958p+2, (struct s31){10246336403069655, -7998521500189979172});
}

void call_f156(void)
{
  struct s32 r = f156();
  ((r.a == 4662808498417018043) ? (void)0 : failure("r.a == 4662808498417018043","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",840,__func__));
  ((r.b == 0x1.5d12e2p+4F) ? (void)0 : failure("r.b == 0x1.5d12e2p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",841,__func__));
}

void call_f157(void)
{
  f157((struct s32){1775746362653330738, 0x1.2a97cdad03ffcp+4});
}

void call_f158(void)
{
  f158((struct s32){5863448758647772447, -0x1.cb2d60c57cb78p+3}, (struct s32){-5996218570252070921, -0x1.ebd755a432f08p+2});
}

void call_f159(void)
{
  f159(-1738047084, (struct s32){-85604440416876734, -0x1.fd9a8b320d18p-2});
}

void call_f160(void)
{
  f160(0x1.09215a7850c92p+5, (struct s32){-2343741634815828736, -0x1.6be4ca9b020aap+4});
}

void call_f161(void)
{
  struct s33 r = f161();
  ((r.a == 8242811742561973546) ? (void)0 : failure("r.a == 8242811742561973546","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",867,__func__));
  ((r.b == 0x1.469ae34a12b72p+5) ? (void)0 : failure("r.b == 0x1.469ae34a12b72p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",868,__func__));
}

void call_f162(void)
{
  f162((struct s33){8187654296218072904, -0x1.c422a91b28c18p+2});
}

void call_f163(void)
{
  f163((struct s33){568840137674323020, 0x1.850fd04e7cb24p+4}, (struct s33){3956869377390794029, 0x1.429c0861059a6p+5});
}

void call_f164(void)
{
  f164(-1479552307, (struct s33){-4404512927516861989, 0x1.85d985f7deab4p+5});
}

void call_f165(void)
{
  f165(0x1.a0531f84aefe4p+4, (struct s33){3411710355216270447, -0x1.fabbfed91e862p+4});
}

void call_f166(void)
{
  struct s34 r = f166();
  ((r.a == -0x1.7860eap+4F) ? (void)0 : failure("r.a == -0x1.7860eap+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",894,__func__));
  ((r.b == 116) ? (void)0 : failure("r.b == 116","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",895,__func__));
}

void call_f167(void)
{
  f167((struct s34){-0x1.1ccf16b0f62dp+3, -186382115});
}

void call_f168(void)
{
  f168((struct s34){-0x1.287ee55d57fdp+5, 402339317}, (struct s34){0x1.217eff006f498p+2, 424772957});
}

void call_f169(void)
{
  f169(-1152060004, (struct s34){0x1.2a87f0c2ecc0cp+5, 280095279});
}

void call_f170(void)
{
  f170(-0x1.667ca9d844338p+5, (struct s34){-0x1.31887c02b9d68p+2, 375011749});
}

void call_f171(void)
{
  struct s35 r = f171();
  ((r.a == -0x1.1f5662p+5F) ? (void)0 : failure("r.a == -0x1.1f5662p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",921,__func__));
  ((r.b == 16140) ? (void)0 : failure("r.b == 16140","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",922,__func__));
}

void call_f172(void)
{
  f172((struct s35){0x1.4db9b0c9db11cp+5, -471539005});
}

void call_f173(void)
{
  f173((struct s35){0x1.a5d2601df0ac4p+4, 120951498}, (struct s35){0x1.9d0bb1156695cp+4, 274740178});
}

void call_f174(void)
{
  f174(-908212935, (struct s35){-0x1.58bc1c3a8a201p+4, -431515165});
}

void call_f175(void)
{
  f175(-0x1.33d3579316aa4p+4, (struct s35){0x1.c419dd6eb794p+0, 401340592});
}

void call_f176(void)
{
  struct s36 r = f176();
  ((r.a == -0x1.345574p+2F) ? (void)0 : failure("r.a == -0x1.345574p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",948,__func__));
  ((r.b == -1344140964) ? (void)0 : failure("r.b == -1344140964","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",949,__func__));
}

void call_f177(void)
{
  f177((struct s36){0x1.f359c97c26974p+4, 1515530165});
}

void call_f178(void)
{
  f178((struct s36){0x1.5b73879065002p+5, 138831035}, (struct s36){-0x1.385b3621d5b01p+5, 524632817});
}

void call_f179(void)
{
  f179(-574292381, (struct s36){0x1.a927eaad453d8p+3, -1003427730});
}

void call_f180(void)
{
  f180(0x1.0f4f003a1f3c8p+5, (struct s36){-0x1.2650cde95ae04p+5, 73517053});
}

void call_f181(void)
{
  struct s37 r = f181();
  ((r.a == 0x1.bd2128p+2F) ? (void)0 : failure("r.a == 0x1.bd2128p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",975,__func__));
  ((r.b == -2814264140199828456) ? (void)0 : failure("r.b == -2814264140199828456","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",976,__func__));
}

void call_f182(void)
{
  f182((struct s37){0x1.373313e185dc4p+5, -2904724171930145257});
}

void call_f183(void)
{
  f183((struct s37){0x1.ceab2623ceacp+4, -4684592017084951337}, (struct s37){0x1.2457513824674p+5, 8811506025757711315});
}

void call_f184(void)
{
  f184(776883879, (struct s37){-0x1.9bcd7d2222d3p+1, 8724643086277304086});
}

void call_f185(void)
{
  f185(0x1.0c920cc7eaf44p+3, (struct s37){0x1.fa9f700d4f2b4p+4, 5051693522324474451});
}

void call_f186(void)
{
  struct s38 r = f186();
  ((r.a == -0x1.85e2d6p+5F) ? (void)0 : failure("r.a == -0x1.85e2d6p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1002,__func__));
  ((r.b == -0x1.cb029ap+4F) ? (void)0 : failure("r.b == -0x1.cb029ap+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1003,__func__));
}

void call_f187(void)
{
  f187((struct s38){-0x1.13eabb3392f9cp+3, -0x1.a701c3000633p+2});
}

void call_f188(void)
{
  f188((struct s38){0x1.ccd0a9c2f1bacp+4, -0x1.8ed30e5bf3c24p+4}, (struct s38){-0x1.7b7bdb7f7270dp+5, 0x1.340a128eaf088p+4});
}

void call_f189(void)
{
  f189(1032177843, (struct s38){-0x1.01b149839befcp+4, 0x1.2e34c4d63425cp+5});
}

void call_f190(void)
{
  f190(-0x1.c1d1a68b26be8p+3, (struct s38){0x1.3401a60d77962p+5, 0x1.49059a8c5ae3cp+4});
}

void call_f191(void)
{
  struct s39 r = f191();
  ((r.a == 0x1.21c25ep+5F) ? (void)0 : failure("r.a == 0x1.21c25ep+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1029,__func__));
  ((r.b == -0x1.6e5e475105fp+2) ? (void)0 : failure("r.b == -0x1.6e5e475105fp+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1030,__func__));
}

void call_f192(void)
{
  f192((struct s39){0x1.968e955d0b96p+4, 0x1.1626110abf4p+4});
}

void call_f193(void)
{
  f193((struct s39){0x1.9096ea9741f2p+3, 0x1.506d3f537276p+5}, (struct s39){-0x1.16b7eaebcb404p+5, 0x1.2ad880962da54p+5});
}

void call_f194(void)
{
  f194(1513575343, (struct s39){0x1.40d67faa7fa8p+4, -0x1.82cba080090ep+2});
}

void call_f195(void)
{
  f195(-0x1.d69b6d766f33cp+3, (struct s39){0x1.dca3b7d7b4f6p+0, 0x1.16443a1bbcc9ep+5});
}

void call_f196(void)
{
  struct s40 r = f196();
  ((r.a == -0x1.5ee3e8f11e13p+3) ? (void)0 : failure("r.a == -0x1.5ee3e8f11e13p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1056,__func__));
  ((r.b == 132) ? (void)0 : failure("r.b == 132","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1057,__func__));
}

void call_f197(void)
{
  f197((struct s40){-0x1.6670a18344cfcp+4, 310876147});
}

void call_f198(void)
{
  f198((struct s40){-0x1.5055ea4a0abp+5, 45212598}, (struct s40){0x1.53a980f365beep+5, -75817576});
}

void call_f199(void)
{
  f199(-1650214369, (struct s40){0x1.53468e56a9c94p+5, -415653530});
}

void call_f200(void)
{
  f200(-0x1.cc00496a40a53p+4, (struct s40){-0x1.542f4b75417a4p+4, -110682099});
}

void call_f201(void)
{
  struct s41 r = f201();
  ((r.a == -0x1.1262ec08c024bp+5) ? (void)0 : failure("r.a == -0x1.1262ec08c024bp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1083,__func__));
  ((r.b == 50834) ? (void)0 : failure("r.b == 50834","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1084,__func__));
}

void call_f202(void)
{
  f202((struct s41){-0x1.61240d686e5b3p+5, -236225541});
}

void call_f203(void)
{
  f203((struct s41){0x1.ae05f06d853bcp+4, -224854310}, (struct s41){-0x1.1c71affe41b9cp+5, -463169154});
}

void call_f204(void)
{
  f204(-664509735, (struct s41){0x1.d3e3008d5e254p+4, -536748589});
}

void call_f205(void)
{
  f205(0x1.456f981cf6fc8p+4, (struct s41){-0x1.3b491b7a87698p+4, -381927184});
}

void call_f206(void)
{
  struct s42 r = f206();
  ((r.a == 0x1.2a67453a68c8cp+5) ? (void)0 : failure("r.a == 0x1.2a67453a68c8cp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1110,__func__));
  ((r.b == 421485310) ? (void)0 : failure("r.b == 421485310","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1111,__func__));
}

void call_f207(void)
{
  f207((struct s42){0x1.a6193dbcbc8fp+4, 2047251715});
}

void call_f208(void)
{
  f208((struct s42){0x1.de529c6fe3718p+4, -835133062}, (struct s42){0x1.7ddd738872c1p+5, -1442257695});
}

void call_f209(void)
{
  f209(-1967902239, (struct s42){0x1.2a7bdb5479ddp+4, -743385001});
}

void call_f210(void)
{
  f210(-0x1.5b917bfede58fp+5, (struct s42){0x1.6a267c3ac7014p+3, -197257186});
}

void call_f211(void)
{
  struct s43 r = f211();
  ((r.a == 0x1.8b69b9837f16p+0) ? (void)0 : failure("r.a == 0x1.8b69b9837f16p+0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1137,__func__));
  ((r.b == -3274147762378740424) ? (void)0 : failure("r.b == -3274147762378740424","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1138,__func__));
}

void call_f212(void)
{
  f212((struct s43){0x1.3d28293c75148p+2, -7321829404139722879});
}

void call_f213(void)
{
  f213((struct s43){-0x1.45d4a9ae55716p+4, -3118147426284939155}, (struct s43){-0x1.6b390de7bf05dp+5, -8026731829316443005});
}

void call_f214(void)
{
  f214(-237130372, (struct s43){-0x1.19ddff71df142p+4, 1283735415415508498});
}

void call_f215(void)
{
  f215(-0x1.61e3899caedep+0, (struct s43){-0x1.d1dfc36f5140ap+4, 8392412469743728698});
}

void call_f216(void)
{
  struct s44 r = f216();
  ((r.a == -0x1.f742fc7054999p+4) ? (void)0 : failure("r.a == -0x1.f742fc7054999p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1164,__func__));
  ((r.b == 0x1.5c329cp+2F) ? (void)0 : failure("r.b == 0x1.5c329cp+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1165,__func__));
}

void call_f217(void)
{
  f217((struct s44){0x1.54260e37b4048p+5, -0x1.034896dd4473p+5});
}

void call_f218(void)
{
  f218((struct s44){-0x1.2b31d47615ecap+5, 0x1.41286af991318p+4}, (struct s44){0x1.0a404ee0abe3cp+4, 0x1.16bfc63b0004cp+5});
}

void call_f219(void)
{
  f219(-842646073, (struct s44){0x1.b21cd6033b928p+2, 0x1.5c338b26c064ap+5});
}

void call_f220(void)
{
  f220(-0x1.7379b58c8df78p+3, (struct s44){0x1.99c2711a35e64p+4, 0x1.9d6a4888cc048p+4});
}

void call_f221(void)
{
  struct s45 r = f221();
  ((r.a == 0x1.56ddc1dd6728ap+5) ? (void)0 : failure("r.a == 0x1.56ddc1dd6728ap+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1191,__func__));
  ((r.b == -0x1.8a82bc8a0c73ap+4) ? (void)0 : failure("r.b == -0x1.8a82bc8a0c73ap+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1192,__func__));
}

void call_f222(void)
{
  f222((struct s45){-0x1.6701c551fa2f5p+5, 0x1.7cb358db3f008p+4});
}

void call_f223(void)
{
  f223((struct s45){-0x1.c55cd912e6d9p+1, 0x1.88dad986da584p+5}, (struct s45){-0x1.f0df065a19698p+2, -0x1.6ccc12a200c6ap+4});
}

void call_f224(void)
{
  f224(-1195593810, (struct s45){-0x1.9296876cf3d81p+4, 0x1.2ecd7b9a4b412p+5});
}

void call_f225(void)
{
  f225(-0x1.e35ad3ba3e478p+3, (struct s45){0x1.46887322ab0e6p+5, -0x1.cf59a532f72bp+3});
}

void call_f226(void)
{
  struct s46 r = f226();
  ((r.a == 198) ? (void)0 : failure("r.a == 198","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1218,__func__));
  ((r.b == 116) ? (void)0 : failure("r.b == 116","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1219,__func__));
  ((r.c == 215) ? (void)0 : failure("r.c == 215","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1220,__func__));
}

void call_f227(void)
{
  f227((struct s46){-98255379, 379856154, -89481260});
}

void call_f228(void)
{
  f228((struct s46){-75885221, -69829775, -346552280}, (struct s46){-201293764, -65861698, -51164867});
}

void call_f229(void)
{
  f229(245069159, (struct s46){364540726, -389180266, 147734592});
}

void call_f230(void)
{
  f230(0x1.0fdd921e670fp+5, (struct s46){-396894792, 345495925, 97504546});
}

void call_f231(void)
{
  struct s47 r = f231();
  ((r.a == 105) ? (void)0 : failure("r.a == 105","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1246,__func__));
  ((r.b == 103) ? (void)0 : failure("r.b == 103","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1247,__func__));
  ((r.c == 31) ? (void)0 : failure("r.c == 31","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1248,__func__));
  ((r.d == 169) ? (void)0 : failure("r.d == 169","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1249,__func__));
}

void call_f232(void)
{
  f232((struct s47){-421619637, 27586821, 361581551, 471098299});
}

void call_f233(void)
{
  f233((struct s47){116644756, -82271781, -272038587, -362243486}, (struct s47){-379642482, -322917318, 409358823, 512775087});
}

void call_f234(void)
{
  f234(296626979, (struct s47){252215982, 449404235, 240894823, -406703303});
}

void call_f235(void)
{
  f235(0x1.e23f3d6ade6e8p+4, (struct s47){-122481590, 516583139, 269196998, -69829399});
}

void call_f236(void)
{
  struct s48 r = f236();
  ((r.a == 247) ? (void)0 : failure("r.a == 247","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1275,__func__));
  ((r.b == 20) ? (void)0 : failure("r.b == 20","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1276,__func__));
  ((r.c == 101) ? (void)0 : failure("r.c == 101","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1277,__func__));
  ((r.d == 100) ? (void)0 : failure("r.d == 100","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1278,__func__));
  ((r.e == 19) ? (void)0 : failure("r.e == 19","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1279,__func__));
  ((r.f == 247) ? (void)0 : failure("r.f == 247","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1280,__func__));
}

void call_f237(void)
{
  f237((struct s48){2593307, -85763544, 466202341, 204566768, -155253868, -496111382});
}

void call_f238(void)
{
  f238((struct s48){384769367, -81719950, -26666344, 91366718, 162788717, -523735645}, (struct s48){-315897585, -251749956, -92553291, -136920318, 312186360, 68915596});
}

void call_f239(void)
{
  f239(2079325832, (struct s48){-115735848, -517300281, 121380438, -123145007, 259822473, 93040447});
}

void call_f240(void)
{
  f240(-0x1.06d7a92efa24p+4, (struct s48){12595977, 102838426, 536379853, 267425629, 88863887, -450311057});
}

void call_f241(void)
{
  struct s49 r = f241();
  ((r.a == 44) ? (void)0 : failure("r.a == 44","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1306,__func__));
  ((r.b == 143) ? (void)0 : failure("r.b == 143","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1307,__func__));
  ((r.c == 154) ? (void)0 : failure("r.c == 154","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1308,__func__));
  ((r.d == 244) ? (void)0 : failure("r.d == 244","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1309,__func__));
  ((r.e == 157) ? (void)0 : failure("r.e == 157","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1310,__func__));
  ((r.f == 81) ? (void)0 : failure("r.f == 81","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1311,__func__));
  ((r.g == 148) ? (void)0 : failure("r.g == 148","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1312,__func__));
  ((r.h == 221) ? (void)0 : failure("r.h == 221","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1313,__func__));
}

void call_f242(void)
{
  f242((struct s49){-393568035, -192680407, -464990355, 321836027, -157208066, 44512470, 535957104, 247932909});
}

void call_f243(void)
{
  f243((struct s49){205886100, 420033858, 97939261, 107574114, 495506614, -274455148, -529594012, -305908703}, (struct s49){-508694720, 394213032, 143597957, 384278297, -351165220, -474673370, 177926555, 44438181});
}

void call_f244(void)
{
  f244(-1909846621, (struct s49){53599656, -414517163, 88629338, -220784523, 472599163, -123424294, -260838210, -43855295});
}

void call_f245(void)
{
  f245(0x1.754e6b4fb978ap+5, (struct s49){458238387, 258908686, -195897574, 507516853, -293227630, -426335658, -326458389, 495015560});
}

void call_f246(void)
{
  struct s50 r = f246();
  ((r.a == 48350) ? (void)0 : failure("r.a == 48350","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1339,__func__));
  ((r.b == 65025) ? (void)0 : failure("r.b == 65025","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1340,__func__));
  ((r.c == 142) ? (void)0 : failure("r.c == 142","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1341,__func__));
}

void call_f247(void)
{
  f247((struct s50){446696560, -425423824, 160261663});
}

void call_f248(void)
{
  f248((struct s50){-384113898, 400612711, -249123715}, (struct s50){-355044321, 448121718, -126327797});
}

void call_f249(void)
{
  f249(-1485132521, (struct s50){444189751, 468292175, 360598844});
}

void call_f250(void)
{
  f250(-0x1.333bdd1a4244ap+5, (struct s50){481918784, -160692321, -97525007});
}

void call_f251(void)
{
  struct s51 r = f251();
  ((r.a == 50100) ? (void)0 : failure("r.a == 50100","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1367,__func__));
  ((r.b == 65115) ? (void)0 : failure("r.b == 65115","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1368,__func__));
  ((r.c == 51105) ? (void)0 : failure("r.c == 51105","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1369,__func__));
  ((r.d == 57470) ? (void)0 : failure("r.d == 57470","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1370,__func__));
}

void call_f252(void)
{
  f252((struct s51){-335262756, -265051438, 504748297, 354010492});
}

void call_f253(void)
{
  f253((struct s51){342422922, -358194761, 158338344, 495448604}, (struct s51){-45736156, -158183579, 397898691, 206356687});
}

void call_f254(void)
{
  f254(1986989253, (struct s51){-38957925, 383849947, 287118817, 320989308});
}

void call_f255(void)
{
  f255(0x1.72a14178e685cp+4, (struct s51){432464556, 281966314, 193723139, -71388956});
}

void call_f256(void)
{
  struct s52 r = f256();
  ((r.a == 38634) ? (void)0 : failure("r.a == 38634","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1396,__func__));
  ((r.b == 47924) ? (void)0 : failure("r.b == 47924","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1397,__func__));
  ((r.c == 34118) ? (void)0 : failure("r.c == 34118","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1398,__func__));
  ((r.d == 26529) ? (void)0 : failure("r.d == 26529","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1399,__func__));
  ((r.e == 21745) ? (void)0 : failure("r.e == 21745","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1400,__func__));
  ((r.f == 33890) ? (void)0 : failure("r.f == 33890","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1401,__func__));
}

void call_f257(void)
{
  f257((struct s52){444391057, -17740701, -355225793, -457546436, -22598777, 495179932});
}

void call_f258(void)
{
  f258((struct s52){-494452941, 446085533, -396466634, -134485361, 252359532, -94015590}, (struct s52){-205034029, 430285287, 307797783, -215230015, 318664399, 411627448});
}

void call_f259(void)
{
  f259(-1689680134, (struct s52){-385670389, -32659886, 161969457, 178176705, 276861272, -419568956});
}

void call_f260(void)
{
  f260(-0x1.c7ac8ef3d674p+0, (struct s52){99298567, 180570753, -380770796, 65858509, -59163035, 135908969});
}

void call_f261(void)
{
  struct s53 r = f261();
  ((r.a == 46250) ? (void)0 : failure("r.a == 46250","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1427,__func__));
  ((r.b == 40799) ? (void)0 : failure("r.b == 40799","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1428,__func__));
  ((r.c == 39285) ? (void)0 : failure("r.c == 39285","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1429,__func__));
  ((r.d == 5333) ? (void)0 : failure("r.d == 5333","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1430,__func__));
  ((r.e == 50811) ? (void)0 : failure("r.e == 50811","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1431,__func__));
  ((r.f == 62155) ? (void)0 : failure("r.f == 62155","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1432,__func__));
  ((r.g == 79) ? (void)0 : failure("r.g == 79","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1433,__func__));
  ((r.h == 51557) ? (void)0 : failure("r.h == 51557","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1434,__func__));
}

void call_f262(void)
{
  f262((struct s53){-309897217, -123409097, 142139903, 203391431, -470134605, -24483355, -196632415, 181731025});
}

void call_f263(void)
{
  f263((struct s53){-532987360, 164210785, -287371765, 117275, 155600702, 184381412, 99561264, 536415560}, (struct s53){60212122, -460171121, 138879747, -338352826, -24926899, 81241239, -535447315, -363370459});
}

void call_f264(void)
{
  f264(-1114110129, (struct s53){458798800, 56518025, 423087251, -505712859, -122636023, 493010892, 334394414, 293340430});
}

void call_f265(void)
{
  f265(0x1.54cc521bf9a38p+4, (struct s53){-383177543, -456642079, 299032984, 358654004, -391772492, 348797728, -356182865, 311700814});
}

void call_f266(void)
{
  struct s54 r = f266();
  ((r.a == 40398235) ? (void)0 : failure("r.a == 40398235","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1460,__func__));
  ((r.b == 2128836673) ? (void)0 : failure("r.b == 2128836673","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1461,__func__));
  ((r.c == -770196380) ? (void)0 : failure("r.c == -770196380","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1462,__func__));
}

void call_f267(void)
{
  f267((struct s54){-813077584, -822953675, -1102354705});
}

void call_f268(void)
{
  f268((struct s54){-1546544965, -1120789179, -319268428}, (struct s54){875148878, -653511120, -227576861});
}

void call_f269(void)
{
  f269(-1748889414, (struct s54){-331560385, 1930180550, 1835925762});
}

void call_f270(void)
{
  f270(0x1.97ed0ae2aa0ep+3, (struct s54){1270154961, 1222701288, 68903934});
}

void call_f271(void)
{
  struct s55 r = f271();
  ((r.a == -2094011745) ? (void)0 : failure("r.a == -2094011745","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1488,__func__));
  ((r.b == 1244358849) ? (void)0 : failure("r.b == 1244358849","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1489,__func__));
  ((r.c == 1504382843) ? (void)0 : failure("r.c == 1504382843","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1490,__func__));
  ((r.d == -376502836) ? (void)0 : failure("r.d == -376502836","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1491,__func__));
}

void call_f272(void)
{
  f272((struct s55){-636837872, 602649651, -1737972595, -1095762535});
}

void call_f273(void)
{
  f273((struct s55){493652316, 1414368155, -873362258, 1914939786}, (struct s55){867832304, 1710012470, -2107262811, 1899233657});
}

void call_f274(void)
{
  f274(1676010821, (struct s55){1888701279, -126389512, -1585042084, 1592001549});
}

void call_f275(void)
{
  f275(-0x1.3602402b58175p+5, (struct s55){594342856, 1097502855, -1269095678, -724322331});
}

void call_f276(void)
{
  struct s56 r = f276();
  ((r.a == -1344324086) ? (void)0 : failure("r.a == -1344324086","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1517,__func__));
  ((r.b == -2014742986) ? (void)0 : failure("r.b == -2014742986","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1518,__func__));
  ((r.c == -2052156259) ? (void)0 : failure("r.c == -2052156259","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1519,__func__));
  ((r.d == -2113919123) ? (void)0 : failure("r.d == -2113919123","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1520,__func__));
  ((r.e == 740385887) ? (void)0 : failure("r.e == 740385887","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1521,__func__));
  ((r.f == 1642647504) ? (void)0 : failure("r.f == 1642647504","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1522,__func__));
}

void call_f277(void)
{
  f277((struct s56){-1478527619, 1083029283, 1090657006, -1946734822, -79118108, 278450333});
}

void call_f278(void)
{
  f278((struct s56){-384472236, -1129288703, -368902093, 1099237150, -1215525153, -418234137}, (struct s56){1852653572, 247991754, -155090660, 800929339, -458785323, -598412318});
}

void call_f279(void)
{
  f279(-866899555, (struct s56){1105570655, 998449963, 70319619, 1775060919, -1627442816, -1428647701});
}

void call_f280(void)
{
  f280(-0x1.b9a05f3e9ff9dp+4, (struct s56){333479667, -410714259, -2028834241, 1970859700, -1549457394, -2095839552});
}

void call_f281(void)
{
  struct s57 r = f281();
  ((r.a == -1556001572) ? (void)0 : failure("r.a == -1556001572","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1548,__func__));
  ((r.b == -741503189) ? (void)0 : failure("r.b == -741503189","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1549,__func__));
  ((r.c == 1089468836) ? (void)0 : failure("r.c == 1089468836","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1550,__func__));
  ((r.d == -1749477125) ? (void)0 : failure("r.d == -1749477125","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1551,__func__));
  ((r.e == 1613559968) ? (void)0 : failure("r.e == 1613559968","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1552,__func__));
  ((r.f == 1262067752) ? (void)0 : failure("r.f == 1262067752","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1553,__func__));
  ((r.g == -38315583) ? (void)0 : failure("r.g == -38315583","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1554,__func__));
  ((r.h == 424021687) ? (void)0 : failure("r.h == 424021687","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1555,__func__));
}

void call_f282(void)
{
  f282((struct s57){-1239899849, 1212598905, -1939206716, 1561341678, -1760132827, 473082591, 1226188033, -812375367});
}

void call_f283(void)
{
  f283((struct s57){-1839575787, 241057370, -1020266062, -1791510506, -1992608852, -989345356, -821263593, 1871873655}, (struct s57){-327970441, -1033528309, -755590432, -878039353, -1094998271, 1700980336, 1133496704, 1145738069});
}

void call_f284(void)
{
  f284(1572115023, (struct s57){-870901838, 2093595905, 1682659984, 917318514, 1547294906, 1477264327, -387644538, 1334680527});
}

void call_f285(void)
{
  f285(0x1.aa7d89e6f78p-5, (struct s57){1696458700, 1495023119, 1207879464, 1958961143, -570063302, 2106380128, -215532182, 310324292});
}

void call_f286(void)
{
  struct s58 r = f286();
  ((r.a == 2004723339903230192) ? (void)0 : failure("r.a == 2004723339903230192","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1581,__func__));
  ((r.b == 6397415174471306602) ? (void)0 : failure("r.b == 6397415174471306602","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1582,__func__));
  ((r.c == 4819258099187834544) ? (void)0 : failure("r.c == 4819258099187834544","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1583,__func__));
}

void call_f287(void)
{
  f287((struct s58){7864354302794522772, -3195831438043025917, 6497405992266599743});
}

void call_f288(void)
{
  f288((struct s58){6982636052040341865, -9207998756414875964, -7926330336746133022}, (struct s58){-1552305682186930785, -8515405049812870959, 1826485582942621559});
}

void call_f289(void)
{
  f289(-1120420969, (struct s58){5891877809946940148, 414198837228287746, 1029957303263444594});
}

void call_f290(void)
{
  f290(0x1.c55cccd0d83p-1, (struct s58){3479737001473941325, -5440816454689209583, -2462842471211201829});
}

void call_f291(void)
{
  struct s59 r = f291();
  ((r.a == -7837027076644551922) ? (void)0 : failure("r.a == -7837027076644551922","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1609,__func__));
  ((r.b == 4374303578401666934) ? (void)0 : failure("r.b == 4374303578401666934","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1610,__func__));
  ((r.c == 1620389363152891905) ? (void)0 : failure("r.c == 1620389363152891905","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1611,__func__));
  ((r.d == -4398874295435412346) ? (void)0 : failure("r.d == -4398874295435412346","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1612,__func__));
}

void call_f292(void)
{
  f292((struct s59){2208066821676405006, -522667975979130469, 6263431241607187268, -8090070468402203799});
}

void call_f293(void)
{
  f293((struct s59){-6154966703787290981, 251239613809491994, -4464866342266211079, -3268472778921023930}, (struct s59){-1744277274733010432, -3309836993627192140, 1296595703325259959, 3085954471522892401});
}

void call_f294(void)
{
  f294(-2029660416, (struct s59){310382890322352710, -7625140031200871166, 6230910873971966405, 3188053628766003827});
}

void call_f295(void)
{
  f295(-0x1.8747c38d5c09cp+3, (struct s59){6167710983073211108, 6228397073198854919, 3085024040854890041, 8712948434506908694});
}

void call_f296(void)
{
  struct s60 r = f296();
  ((r.a == 8830942043370466793) ? (void)0 : failure("r.a == 8830942043370466793","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1638,__func__));
  ((r.b == -7181376488475664989) ? (void)0 : failure("r.b == -7181376488475664989","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1639,__func__));
  ((r.c == 5475827025808791150) ? (void)0 : failure("r.c == 5475827025808791150","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1640,__func__));
  ((r.d == 1689952632491852805) ? (void)0 : failure("r.d == 1689952632491852805","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1641,__func__));
  ((r.e == 5202218061220139611) ? (void)0 : failure("r.e == 5202218061220139611","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1642,__func__));
  ((r.f == -5716583426545799401) ? (void)0 : failure("r.f == -5716583426545799401","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1643,__func__));
}

void call_f297(void)
{
  f297((struct s60){-3652332570717718915, -8385153050934849232, 2796580170212265591, -4761308511779651338, -2011959598710697358, -837830109172576315});
}

void call_f298(void)
{
  f298((struct s60){-3741235593561171267, -820991670170863378, 5962138712415955169, -2000609577541218522, 65808555680337795, 4218524788692500665}, (struct s60){7445458094847756153, 1791615147233262889, 2529433344807568474, 7184352829095371683, 6159634947789934416, 1444361232073586775});
}

void call_f299(void)
{
  f299(382590090, (struct s60){-289330091119253646, 579284392501295509, -6054430554678754373, -8583385428984158307, -8541192730599954335, -8904703611215753751});
}

void call_f300(void)
{
  f300(0x1.a98c86feb9258p+4, (struct s60){4057518156153265300, -7477891924552959926, -6320855859911932033, 3935376049511752050, -6590015501619187600, -5399390337454439163});
}

void call_f301(void)
{
  struct s61 r = f301();
  ((r.a == -2836254641330925163) ? (void)0 : failure("r.a == -2836254641330925163","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1669,__func__));
  ((r.b == -3971325912302539598) ? (void)0 : failure("r.b == -3971325912302539598","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1670,__func__));
  ((r.c == 8165075520375979388) ? (void)0 : failure("r.c == 8165075520375979388","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1671,__func__));
  ((r.d == 8021367050294595689) ? (void)0 : failure("r.d == 8021367050294595689","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1672,__func__));
  ((r.e == 5966289387050517868) ? (void)0 : failure("r.e == 5966289387050517868","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1673,__func__));
  ((r.f == -7251756001158949497) ? (void)0 : failure("r.f == -7251756001158949497","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1674,__func__));
  ((r.g == -461282064023901131) ? (void)0 : failure("r.g == -461282064023901131","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1675,__func__));
  ((r.h == 7109988575795088431) ? (void)0 : failure("r.h == 7109988575795088431","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1676,__func__));
}

void call_f302(void)
{
  f302((struct s61){7034939172948071308, 7424051237976585391, -1208494439316553845, 9120136251407028621, -7095616490480762670, -74090135265001715, 9210700778121023134, 3723443027841607681});
}

void call_f303(void)
{
  f303((struct s61){-6924490146476521235, -3050881640756342740, 7333907952850625862, -4465419502713426560, 3554545626042267272, -8037095940923102799, -4038227020892648462, -7810359266076428556}, (struct s61){4869086151445624813, 4494448565390693015, 4944615466877424437, 4169686391845976670, -5045408152623293315, 7414262994632409334, -3193567555580175562, -7796428337446052608});
}

void call_f304(void)
{
  f304(-1003246920, (struct s61){4280713908087870217, 8957439470917897101, 1698121181740029815, 6779422321090594172, 7767898063319302534, -8315006110463056353, -5364749496295923286, 1043632969619464456});
}

void call_f305(void)
{
  f305(0x1.6742a97d17bcep+5, (struct s61){534113460973376480, -1972749546722034222, -33440608009732110, -6564347790249916681, 4154932980812663836, 5888594362943646845, -3329671628006563281, -587837659352929050});
}

void call_f306(void)
{
  struct s62 r = f306();
  ((r.a == -0x1.ff933ap+4F) ? (void)0 : failure("r.a == -0x1.ff933ap+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1702,__func__));
  ((r.b == -0x1.98d49cp+4F) ? (void)0 : failure("r.b == -0x1.98d49cp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1703,__func__));
  ((r.c == -0x1.c9e1bcp+4F) ? (void)0 : failure("r.c == -0x1.c9e1bcp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1704,__func__));
}

void call_f307(void)
{
  f307((struct s62){-0x1.1162b06639973p+5, -0x1.807b93961408cp+3, 0x1.3a0c0c9480dp-1});
}

void call_f308(void)
{
  f308((struct s62){0x1.41878e2e5a3f4p+5, 0x1.730260dd93c6p+4, 0x1.6d018015e8a04p+5}, (struct s62){0x1.190303cba1e9ep+5, 0x1.0a7a2a04576e8p+5, 0x1.f714334357204p+4});
}

void call_f309(void)
{
  f309(-1407500543, (struct s62){0x1.29a303014b31p+4, -0x1.c3eb705955ccdp+4, -0x1.59d91c8231611p+5});
}

void call_f310(void)
{
  f310(-0x1.740935eb74bp+5, (struct s62){0x1.daa4e2714122p+2, 0x1.eaf3df34ea008p+2, 0x1.b02aa3b03b488p+4});
}

void call_f311(void)
{
  struct s63 r = f311();
  ((r.a == 0x1.e6499cp+3F) ? (void)0 : failure("r.a == 0x1.e6499cp+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1730,__func__));
  ((r.b == 0x1.5d59fep+4F) ? (void)0 : failure("r.b == 0x1.5d59fep+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1731,__func__));
  ((r.c == -0x1.72b69p+4F) ? (void)0 : failure("r.c == -0x1.72b69p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1732,__func__));
  ((r.d == -0x1.7f3dbep+3F) ? (void)0 : failure("r.d == -0x1.7f3dbep+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1733,__func__));
}

void call_f312(void)
{
  f312((struct s63){0x1.db79920ffa6b8p+4, -0x1.297d58dc75a5fp+5, -0x1.1d00e8477fb3cp+5, -0x1.4d20455ec086bp+4});
}

void call_f313(void)
{
  f313((struct s63){0x1.8cf4b6565e2bep+5, 0x1.d2f371d84339cp+4, -0x1.957c23a03734cp+4, 0x1.8c9b979698868p+2}, (struct s63){0x1.4e89e0f7af5fap+5, 0x1.0ddfd65500f34p+5, -0x1.d878b738119f4p+3, -0x1.765e0d35cd3p+2});
}

void call_f314(void)
{
  f314(933889343, (struct s63){0x1.1a7387911ecp+5, 0x1.be654f8388f74p+4, -0x1.b1e33660222abp+4, 0x1.bfcab8a94458p+1});
}

void call_f315(void)
{
  f315(0x1.9565da10b5428p+3, (struct s63){-0x1.746919e1fbda8p+5, 0x1.4bdee83fcb6p+0, 0x1.38220e31d7p-2, 0x1.60d2e12a26728p+4});
}

void call_f316(void)
{
  struct s64 r = f316();
  ((r.a == -0x1.cf4aeep+3F) ? (void)0 : failure("r.a == -0x1.cf4aeep+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1759,__func__));
  ((r.b == 0x1.0b903ep+3F) ? (void)0 : failure("r.b == 0x1.0b903ep+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1760,__func__));
  ((r.c == 0x1.3f8f92p+5F) ? (void)0 : failure("r.c == 0x1.3f8f92p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1761,__func__));
  ((r.d == 0x1.837df6p+5F) ? (void)0 : failure("r.d == 0x1.837df6p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1762,__func__));
  ((r.e == 0x1.979482p+3F) ? (void)0 : failure("r.e == 0x1.979482p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1763,__func__));
  ((r.f == 0x1.5e1522p+1F) ? (void)0 : failure("r.f == 0x1.5e1522p+1F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1764,__func__));
}

void call_f317(void)
{
  f317((struct s64){0x1.a46885dd6282p+1, -0x1.bd9c1620784e9p+4, 0x1.cea7548a231cp+3, -0x1.cd8eb1dff81bcp+3, 0x1.8776bb3e478bp+4, 0x1.d44591f376998p+4});
}

void call_f318(void)
{
  f318((struct s64){0x1.116bd0600d8d8p+3, -0x1.59e4d52481b28p+2, -0x1.57a70101e0bbp+2, -0x1.3cf3164b0db5cp+4, 0x1.0b3f4705583c6p+5, -0x1.014fcf272f9ecp+5}, (struct s64){-0x1.2bc327a4e28cbp+5, 0x1.634adb25ef8cp+4, -0x1.82e087526ba0ep+5, -0x1.156496b78c412p+5, 0x1.d894b267b219cp+4, -0x1.5989c306cba4cp+4});
}

void call_f319(void)
{
  f319(945002968, (struct s64){0x1.8ee71196df69p+2, 0x1.c74308d8315dp+4, -0x1.3c86c16995cf1p+5, -0x1.2993436af77c8p+3, 0x1.89166e6e5e9dep+5, -0x1.3529e45f2d954p+5});
}

void call_f320(void)
{
  f320(-0x1.12d4bc17d7dcap+4, (struct s64){0x1.157d1d0c4491ap+5, -0x1.98c9174d6dcf8p+2, 0x1.fdcf55b9741bp+4, -0x1.116ced306945p+4, -0x1.65240b5479b5ap+4, 0x1.3cd256c1737bcp+3});
}

void call_f321(void)
{
  struct s65 r = f321();
  ((r.a == -0x1.7542ccp+4F) ? (void)0 : failure("r.a == -0x1.7542ccp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1790,__func__));
  ((r.b == 0x1.70199p+5F) ? (void)0 : failure("r.b == 0x1.70199p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1791,__func__));
  ((r.c == 0x1.62edb6p+5F) ? (void)0 : failure("r.c == 0x1.62edb6p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1792,__func__));
  ((r.d == 0x1.0e4b8cp+4F) ? (void)0 : failure("r.d == 0x1.0e4b8cp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1793,__func__));
  ((r.e == -0x1.572a7ep+5F) ? (void)0 : failure("r.e == -0x1.572a7ep+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1794,__func__));
  ((r.f == 0x1.da5d3ap+3F) ? (void)0 : failure("r.f == 0x1.da5d3ap+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1795,__func__));
  ((r.g == -0x1.64403cp+5F) ? (void)0 : failure("r.g == -0x1.64403cp+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1796,__func__));
  ((r.h == -0x1.34087cp+5F) ? (void)0 : failure("r.h == -0x1.34087cp+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1797,__func__));
}

void call_f322(void)
{
  f322((struct s65){-0x1.2d0a18bd83b43p+5, 0x1.263c313720ec4p+5, -0x1.e7ec409b58dbp+1, 0x1.698d28acbc124p+4, 0x1.d2c5965c59904p+4, -0x1.ffd7dc2157b58p+3, -0x1.8733ec2227d04p+3, 0x1.cc62aede088bcp+4});
}

void call_f323(void)
{
  f323((struct s65){0x1.1fa889289002p+3, -0x1.2c1f45d8c6d3p+3, -0x1.71b843351ddc7p+5, 0x1.ea3aac6a07868p+2, 0x1.34083a0f9d5dp+4, 0x1.43fdbe9e69678p+4, 0x1.2c58222744f38p+5, 0x1.3d965612e3798p+5}, (struct s65){0x1.8b1270f6c7764p+5, 0x1.365e3647616fp+1, -0x1.4145fe6d44432p+5, -0x1.14c8453570136p+5, 0x1.2fc51e9c760bp+4, 0x1.87cbca2702398p+3, -0x1.084e41dffb7d1p+5, -0x1.5ca678c795472p+4});
}

void call_f324(void)
{
  f324(-1642056878, (struct s65){0x1.258d6c28b8f7cp+3, 0x1.0802d2dc281ep+5, -0x1.ea0b75f2d825p+2, -0x1.7a9800f4cc17fp+5, 0x1.a7b2ed4241d88p+4, -0x1.1f9f58c9c89a8p+5, 0x1.687cb3724b9dp+2, 0x1.f014c6c8a3a9cp+4});
}

void call_f325(void)
{
  f325(0x1.3c7232c8cdbfcp+5, (struct s65){-0x1.5e6bf971897cp+0, -0x1.383e7af4ba5bcp+5, -0x1.b12665b80334cp+3, 0x1.13533d2eb759p+4, -0x1.326cadd4e81a1p+5, 0x1.146b406cbbd06p+5, -0x1.774394acf5a58p+5, 0x1.8b445fd7ad88ep+5});
}

void call_f326(void)
{
  struct s66 r = f326();
  ((r.a == -0x1.9bc58aec5d286p+4) ? (void)0 : failure("r.a == -0x1.9bc58aec5d286p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1823,__func__));
  ((r.b == 0x1.9daf2e6302a74p+4) ? (void)0 : failure("r.b == 0x1.9daf2e6302a74p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1824,__func__));
  ((r.c == 0x1.ab81943d83d38p+4) ? (void)0 : failure("r.c == 0x1.ab81943d83d38p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1825,__func__));
}

void call_f327(void)
{
  f327((struct s66){-0x1.53376b1963029p+5, 0x1.665814bafc6aap+5, 0x1.1336a0b3e11d4p+5});
}

void call_f328(void)
{
  f328((struct s66){-0x1.0c6c7b81c04c4p+5, 0x1.dc1b83d5f3294p+4, -0x1.44ff3f19341ap+3}, (struct s66){0x1.608c566865b92p+5, -0x1.4d8561f18edc6p+5, -0x1.3ffe08de67983p+4});
}

void call_f329(void)
{
  f329(1664566933, (struct s66){0x1.7f90a30d5ca74p+5, 0x1.239d4a3d3891cp+5, -0x1.6dcbaeec0388ap+5});
}

void call_f330(void)
{
  f330(0x1.62b1d078c9f78p+5, (struct s66){0x1.e9df584ddf398p+4, -0x1.1550b80e48d35p+5, 0x1.580f5ef149d64p+4});
}

void call_f331(void)
{
  struct s67 r = f331();
  ((r.a == 0x1.e6c1914db64b8p+3) ? (void)0 : failure("r.a == 0x1.e6c1914db64b8p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1851,__func__));
  ((r.b == 0x1.bf7347cdd7c14p+4) ? (void)0 : failure("r.b == 0x1.bf7347cdd7c14p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1852,__func__));
  ((r.c == 0x1.2a823ee8e93dp+2) ? (void)0 : failure("r.c == 0x1.2a823ee8e93dp+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1853,__func__));
  ((r.d == 0x1.22b7d94bdedd8p+5) ? (void)0 : failure("r.d == 0x1.22b7d94bdedd8p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1854,__func__));
}

void call_f332(void)
{
  f332((struct s67){-0x1.8f3b3fe21d63fp+4, 0x1.8edf87cbd3de6p+5, 0x1.737998cf66e1p+2, 0x1.e7c46be0b456p+3});
}

void call_f333(void)
{
  f333((struct s67){0x1.1dfae375a503p+3, -0x1.516124cb465f2p+5, -0x1.69a2cf819a87bp+5, 0x1.8662282fefce4p+3}, (struct s67){-0x1.7bd181bd5bd87p+5, -0x1.5247e134df66cp+5, -0x1.0c0289f0de9ap+0, -0x1.47dceb5197aa4p+5});
}

void call_f334(void)
{
  f334(-702763847, (struct s67){-0x1.b1b4ab4ffba08p+3, 0x1.7588b492be574p+4, -0x1.e1657fdf51cbp+1, -0x1.63de953d7daacp+5});
}

void call_f335(void)
{
  f335(-0x1.06a48c40463f6p+5, (struct s67){-0x1.659cce37b7cep+5, -0x1.0331f0f34f6a5p+5, -0x1.65b0991b573dep+5, -0x1.d1ad7a98e38bcp+4});
}

void call_f336(void)
{
  struct s68 r = f336();
  ((r.a == -0x1.47c854887bce2p+5) ? (void)0 : failure("r.a == -0x1.47c854887bce2p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1880,__func__));
  ((r.b == -0x1.1722cbd292fe2p+4) ? (void)0 : failure("r.b == -0x1.1722cbd292fe2p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1881,__func__));
  ((r.c == 0x1.4c79c99fddeep+3) ? (void)0 : failure("r.c == 0x1.4c79c99fddeep+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1882,__func__));
  ((r.d == 0x1.158cb75ab5c7p+5) ? (void)0 : failure("r.d == 0x1.158cb75ab5c7p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1883,__func__));
  ((r.e == 0x1.81cccffe73c0cp+5) ? (void)0 : failure("r.e == 0x1.81cccffe73c0cp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1884,__func__));
  ((r.f == 0x1.a620afbf5b5ep+2) ? (void)0 : failure("r.f == 0x1.a620afbf5b5ep+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1885,__func__));
}

void call_f337(void)
{
  f337((struct s68){0x1.4f63f19cc8dp-1, 0x1.8603de811393p+4, -0x1.100e785ed98e8p+2, 0x1.2b95fb65bdac4p+3, 0x1.59b0c62f1d014p+4, -0x1.64956ce26016cp+5});
}

void call_f338(void)
{
  f338((struct s68){0x1.f644a3a98603p+4, -0x1.e62c8c14332dp+2, 0x1.bb4d44f79f7ap+1, 0x1.e9e8a3d270b2p+0, 0x1.17b5ac39bf5e6p+5, 0x1.6c9eeba3648d4p+4}, (struct s68){0x1.edbde86ef09c8p+2, 0x1.09762f5548fc8p+4, -0x1.326c3c7a0dbb6p+5, -0x1.4a8784429524p+3, -0x1.fc75de31ea104p+3, 0x1.5680174fe2ebp+4});
}

void call_f339(void)
{
  f339(869731840, (struct s68){-0x1.022f54296131cp+5, -0x1.24772b976360dp+5, -0x1.3c664bd76b615p+4, -0x1.23f92c9ab298p+5, 0x1.98b98e67bd484p+4, -0x1.1dacdb2044b2fp+5});
}

void call_f340(void)
{
  f340(0x1.731f29aa4dcp+3, (struct s68){-0x1.a24d872667d84p+3, 0x1.226d83e562718p+2, 0x1.dc8f5a045eaap+2, -0x1.8a3b4999e10bep+5, -0x1.1d777ef2d1b83p+5, -0x1.d601c48f3de31p+4});
}

void call_f341(void)
{
  struct s69 r = f341();
  ((r.a == -0x1.0ba84e94c9146p+5) ? (void)0 : failure("r.a == -0x1.0ba84e94c9146p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1911,__func__));
  ((r.b == 0x1.648713a86aa9cp+3) ? (void)0 : failure("r.b == 0x1.648713a86aa9cp+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1912,__func__));
  ((r.c == 0x1.b0d130ee644f8p+2) ? (void)0 : failure("r.c == 0x1.b0d130ee644f8p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1913,__func__));
  ((r.d == 0x1.15a5aefe042c6p+5) ? (void)0 : failure("r.d == 0x1.15a5aefe042c6p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1914,__func__));
  ((r.e == 0x1.3ba9b7c2e7b5p+2) ? (void)0 : failure("r.e == 0x1.3ba9b7c2e7b5p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1915,__func__));
  ((r.f == -0x1.99cd442771fp+0) ? (void)0 : failure("r.f == -0x1.99cd442771fp+0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1916,__func__));
  ((r.g == -0x1.0bc54987b10ep+5) ? (void)0 : failure("r.g == -0x1.0bc54987b10ep+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1917,__func__));
  ((r.h == -0x1.49a7d879f54fp+5) ? (void)0 : failure("r.h == -0x1.49a7d879f54fp+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/struct-native/lean/abi/struct_use.c",1918,__func__));
}

void call_f342(void)
{
  f342((struct s69){0x1.efdc53b8015c8p+2, 0x1.309d2c94305c8p+2, -0x1.1c7d6caad7fcep+4, 0x1.d15123511abdp+3, -0x1.17cb2deb1c5c6p+4, -0x1.4c0ca81a7becfp+5, 0x1.9fee5424d4458p+4, 0x1.04e2b403cb3f4p+5});
}

void call_f343(void)
{
  f343((struct s69){-0x1.76c18ba7c07dfp+5, 0x1.67c7c336bba8p+1, -0x1.dd2f7652ddf08p+3, 0x1.ec21dec61013cp+4, -0x1.f40fc3acb1bd2p+4, 0x1.fa7df5567fcbp+4, 0x1.bb7f913a5d3a8p+4, 0x1.e6006071d52ecp+4}, (struct s69){0x1.327fceaecc6bcp+4, -0x1.5f6daab7109e9p+5, 0x1.59ef6be351272p+5, 0x1.7a2f5ea9254dap+5, -0x1.0a13ed5bc6f4p+0, 0x1.ed598d51a2a38p+2, 0x1.83dae2b718454p+5, 0x1.771e300f6a218p+5});
}

void call_f344(void)
{
  f344(-1358227050, (struct s69){0x1.2bbaf3894d708p+4, -0x1.4b514c968c44ap+5, -0x1.18b308e9396e8p+3, -0x1.7a0ef3c9c0c58p+3, -0x1.7f584962f2b58p+5, 0x1.e28d459df0228p+2, -0x1.59fe159a62ae2p+5, -0x1.6645bff1952d8p+4});
}

void call_f345(void)
{
  f345(-0x1.04b60cd0b7a54p+3, (struct s69){-0x1.a7b99e9cb0cb5p+4, 0x1.d0a54047f8908p+4, 0x1.600ef8020edd8p+3, -0x1.77cdb6a42f615p+5, -0x1.66ea527a9b87ep+4, -0x1.6b07f17c96871p+4, -0x1.36588c07f7f48p+5, -0x1.6769d1d7b38e3p+5});
}

int main(void)
{
  alarm(60);
  call_f1();
  call_f2();
  call_f3();
  call_f4();
  call_f5();
  call_f6();
  call_f7();
  call_f8();
  call_f9();
  call_f10();
  call_f11();
  call_f12();
  call_f13();
  call_f14();
  call_f15();
  call_f16();
  call_f17();
  call_f18();
  call_f19();
  call_f20();
  call_f21();
  call_f22();
  call_f23();
  call_f24();
  call_f25();
  call_f26();
  call_f27();
  call_f28();
  call_f29();
  call_f30();
  call_f31();
  call_f32();
  call_f33();
  call_f34();
  call_f35();
  call_f36();
  call_f37();
  call_f38();
  call_f39();
  call_f40();
  call_f41();
  call_f42();
  call_f43();
  call_f44();
  call_f45();
  call_f46();
  call_f47();
  call_f48();
  call_f49();
  call_f50();
  call_f51();
  call_f52();
  call_f53();
  call_f54();
  call_f55();
  call_f56();
  call_f57();
  call_f58();
  call_f59();
  call_f60();
  call_f61();
  call_f62();
  call_f63();
  call_f64();
  call_f65();
  call_f66();
  call_f67();
  call_f68();
  call_f69();
  call_f70();
  call_f71();
  call_f72();
  call_f73();
  call_f74();
  call_f75();
  call_f76();
  call_f77();
  call_f78();
  call_f79();
  call_f80();
  call_f81();
  call_f82();
  call_f83();
  call_f84();
  call_f85();
  call_f86();
  call_f87();
  call_f88();
  call_f89();
  call_f90();
  call_f91();
  call_f92();
  call_f93();
  call_f94();
  call_f95();
  call_f96();
  call_f97();
  call_f98();
  call_f99();
  call_f100();
  call_f101();
  call_f102();
  call_f103();
  call_f104();
  call_f105();
  call_f106();
  call_f107();
  call_f108();
  call_f109();
  call_f110();
  call_f111();
  call_f112();
  call_f113();
  call_f114();
  call_f115();
  call_f116();
  call_f117();
  call_f118();
  call_f119();
  call_f120();
  call_f121();
  call_f122();
  call_f123();
  call_f124();
  call_f125();
  call_f126();
  call_f127();
  call_f128();
  call_f129();
  call_f130();
  call_f131();
  call_f132();
  call_f133();
  call_f134();
  call_f135();
  call_f136();
  call_f137();
  call_f138();
  call_f139();
  call_f140();
  call_f141();
  call_f142();
  call_f143();
  call_f144();
  call_f145();
  call_f146();
  call_f147();
  call_f148();
  call_f149();
  call_f150();
  call_f151();
  call_f152();
  call_f153();
  call_f154();
  call_f155();
  call_f156();
  call_f157();
  call_f158();
  call_f159();
  call_f160();
  call_f161();
  call_f162();
  call_f163();
  call_f164();
  call_f165();
  call_f166();
  call_f167();
  call_f168();
  call_f169();
  call_f170();
  call_f171();
  call_f172();
  call_f173();
  call_f174();
  call_f175();
  call_f176();
  call_f177();
  call_f178();
  call_f179();
  call_f180();
  call_f181();
  call_f182();
  call_f183();
  call_f184();
  call_f185();
  call_f186();
  call_f187();
  call_f188();
  call_f189();
  call_f190();
  call_f191();
  call_f192();
  call_f193();
  call_f194();
  call_f195();
  call_f196();
  call_f197();
  call_f198();
  call_f199();
  call_f200();
  call_f201();
  call_f202();
  call_f203();
  call_f204();
  call_f205();
  call_f206();
  call_f207();
  call_f208();
  call_f209();
  call_f210();
  call_f211();
  call_f212();
  call_f213();
  call_f214();
  call_f215();
  call_f216();
  call_f217();
  call_f218();
  call_f219();
  call_f220();
  call_f221();
  call_f222();
  call_f223();
  call_f224();
  call_f225();
  call_f226();
  call_f227();
  call_f228();
  call_f229();
  call_f230();
  call_f231();
  call_f232();
  call_f233();
  call_f234();
  call_f235();
  call_f236();
  call_f237();
  call_f238();
  call_f239();
  call_f240();
  call_f241();
  call_f242();
  call_f243();
  call_f244();
  call_f245();
  call_f246();
  call_f247();
  call_f248();
  call_f249();
  call_f250();
  call_f251();
  call_f252();
  call_f253();
  call_f254();
  call_f255();
  call_f256();
  call_f257();
  call_f258();
  call_f259();
  call_f260();
  call_f261();
  call_f262();
  call_f263();
  call_f264();
  call_f265();
  call_f266();
  call_f267();
  call_f268();
  call_f269();
  call_f270();
  call_f271();
  call_f272();
  call_f273();
  call_f274();
  call_f275();
  call_f276();
  call_f277();
  call_f278();
  call_f279();
  call_f280();
  call_f281();
  call_f282();
  call_f283();
  call_f284();
  call_f285();
  call_f286();
  call_f287();
  call_f288();
  call_f289();
  call_f290();
  call_f291();
  call_f292();
  call_f293();
  call_f294();
  call_f295();
  call_f296();
  call_f297();
  call_f298();
  call_f299();
  call_f300();
  call_f301();
  call_f302();
  call_f303();
  call_f304();
  call_f305();
  call_f306();
  call_f307();
  call_f308();
  call_f309();
  call_f310();
  call_f311();
  call_f312();
  call_f313();
  call_f314();
  call_f315();
  call_f316();
  call_f317();
  call_f318();
  call_f319();
  call_f320();
  call_f321();
  call_f322();
  call_f323();
  call_f324();
  call_f325();
  call_f326();
  call_f327();
  call_f328();
  call_f329();
  call_f330();
  call_f331();
  call_f332();
  call_f333();
  call_f334();
  call_f335();
  call_f336();
  call_f337();
  call_f338();
  call_f339();
  call_f340();
  call_f341();
  call_f342();
  call_f343();
  call_f344();
  call_f345();
  return failed;
}
