# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c"
# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 1
# 43 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h"
typedef __builtin_va_list __gnuc_va_list;
# 59 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h"
typedef __builtin_va_list va_list;
# 2 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c" 2
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 29 "/usr/include/stdio.h" 2 3 4









# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4

# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef unsigned long size_t;
# 39 "/usr/include/stdio.h" 2 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 45 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 46 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 47 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 48 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 2 3 4

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2:24;

  char _short_backupbuf[1];
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;

  int _unused3;

  __uint64_t _total_written;




  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
# 49 "/usr/include/stdio.h" 2 3 4
# 89 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;
# 133 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 134 "/usr/include/stdio.h" 2 3 4
# 153 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) ;

extern int rename (const char *__old, const char *__new) ;
# 191 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) ;
# 201 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  ;
# 218 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) ;
# 243 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 271 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *restrict __filename,
      const char *restrict __modes)
  ;




extern FILE *freopen (const char *restrict __filename,
        const char *restrict __modes,
        FILE *restrict __stream) ;
# 341 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *restrict __stream, char *restrict __buf)
  ;



extern int setvbuf (FILE *restrict __stream, char *restrict __buf,
      int __modes, size_t __n) ;
# 364 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *restrict __stream,
      const char *restrict __format, ...) ;




extern int printf (const char *restrict __format, ...);

extern int sprintf (char *restrict __s,
      const char *restrict __format, ...) ;





extern int vfprintf (FILE *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;




extern int vprintf (const char *restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;



extern int snprintf (char *restrict __s, size_t __maxlen,
       const char *restrict __format, ...)
     ;

extern int vsnprintf (char *restrict __s, size_t __maxlen,
        const char *restrict __format, __gnuc_va_list __arg)
     ;
# 429 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *restrict __stream,
     const char *restrict __format, ...) ;




extern int scanf (const char *restrict __format, ...) ;

extern int sscanf (const char *restrict __s,
     const char *restrict __format, ...) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 445 "/usr/include/stdio.h" 2 3 4
# 479 "/usr/include/stdio.h" 3 4
extern int __isoc99_fscanf (FILE *restrict __stream,
       const char *restrict __format, ...)
  ;
extern int __isoc99_scanf (const char *restrict __format, ...) ;
extern int __isoc99_sscanf (const char *restrict __s,
       const char *restrict __format, ...) ;
# 497 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *restrict __s, const char *restrict __format,
      __gnuc_va_list __arg)
     ;





extern int vscanf (const char *restrict __format, __gnuc_va_list __arg)
     ;


extern int vsscanf (const char *restrict __s,
      const char *restrict __format, __gnuc_va_list __arg)
     ;
# 561 "/usr/include/stdio.h" 3 4
extern int __isoc99_vfscanf (FILE *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
extern int __isoc99_vscanf (const char *restrict __format,
       __gnuc_va_list __arg) ;
extern int __isoc99_vsscanf (const char *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
# 582 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) ;
extern int getc (FILE *__stream) ;





extern int getchar (void);
# 615 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) ;
extern int putc (int __c, FILE *__stream) ;





extern int putchar (int __c);
# 658 "/usr/include/stdio.h" 3 4
extern char *fgets (char *restrict __s, int __n, FILE *restrict __stream)
     ;
# 671 "/usr/include/stdio.h" 3 4
extern char *gets (char *__s) ;
# 711 "/usr/include/stdio.h" 3 4
extern int fputs (const char *restrict __s, FILE *restrict __stream)
  ;





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) ;






extern size_t fread (void *restrict __ptr, size_t __size,
       size_t __n, FILE *restrict __stream)
  ;




extern size_t fwrite (const void *restrict __ptr, size_t __size,
        size_t __n, FILE *restrict __s) ;
# 773 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  ;




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream) ;
# 823 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *restrict __stream, fpos_t *restrict __pos)
  ;




extern int fsetpos (FILE *__stream, const fpos_t *__pos) ;
# 854 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) ;

extern int feof (FILE *__stream) ;

extern int ferror (FILE *__stream) ;
# 872 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) ;
# 953 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 977 "/usr/include/stdio.h" 3 4

# 3 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4


# 37 "/usr/include/string.h" 3 4
# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 38 "/usr/include/string.h" 2 3 4
# 47 "/usr/include/string.h" 3 4
extern void *memcpy (void *restrict __dest, const void *restrict __src,
       size_t __n) ;


extern void *memmove (void *__dest, const void *__src, size_t __n)
     ;
# 65 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) ;
# 75 "/usr/include/string.h" 3 4
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     ;
# 91 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     ;
# 118 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      ;
# 156 "/usr/include/string.h" 3 4
extern char *strcpy (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncpy (char *restrict __dest,
        const char *restrict __src, size_t __n)
     ;


extern char *strcat (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncat (char *restrict __dest, const char *restrict __src,
        size_t __n) ;


extern int strcmp (const char *__s1, const char *__s2)
     ;

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     ;


extern int strcoll (const char *__s1, const char *__s2)
     ;

extern size_t strxfrm (char *restrict __dest,
         const char *restrict __src, size_t __n)
    ;
# 261 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     ;
# 292 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     ;
# 316 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     ;


extern size_t strspn (const char *__s, const char *__accept)
     ;
# 346 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     ;
# 377 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     ;
# 388 "/usr/include/string.h" 3 4
extern char *strtok (char *restrict __s, const char *restrict __delim)
     ;



extern char *__strtok_r (char *restrict __s,
    const char *restrict __delim,
    char **restrict __save_ptr)
     ;
# 439 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     ;
# 451 "/usr/include/string.h" 3 4
extern char *strerror (int __errnum) ;
# 584 "/usr/include/string.h" 3 4

# 4 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c" 2
# 1 "/usr/include/unistd.h" 1 3 4
# 27 "/usr/include/unistd.h" 3 4

# 202 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/posix_opt.h" 1 3 4
# 203 "/usr/include/unistd.h" 2 3 4
# 220 "/usr/include/unistd.h" 3 4
typedef __ssize_t ssize_t;





# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 227 "/usr/include/unistd.h" 2 3 4
# 287 "/usr/include/unistd.h" 3 4
extern int access (const char *__name, int __type) ;
# 339 "/usr/include/unistd.h" 3 4
extern __off_t lseek (int __fd, __off_t __offset, int __whence) ;
# 358 "/usr/include/unistd.h" 3 4
extern int close (int __fd);
# 371 "/usr/include/unistd.h" 3 4
extern ssize_t read (int __fd, void *__buf, size_t __nbytes)
    ;





extern ssize_t write (int __fd, const void *__buf, size_t __n)
    ;
# 437 "/usr/include/unistd.h" 3 4
extern int pipe (int __pipedes[2]) ;
# 452 "/usr/include/unistd.h" 3 4
extern unsigned int alarm (unsigned int __seconds) ;
# 464 "/usr/include/unistd.h" 3 4
extern unsigned int sleep (unsigned int __seconds);
# 489 "/usr/include/unistd.h" 3 4
extern int pause (void);



extern int chown (const char *__file, __uid_t __owner, __gid_t __group)
     ;
# 517 "/usr/include/unistd.h" 3 4
extern int chdir (const char *__path) ;
# 531 "/usr/include/unistd.h" 3 4
extern char *getcwd (char *__buf, size_t __size) ;
# 552 "/usr/include/unistd.h" 3 4
extern int dup (int __fd) ;


extern int dup2 (int __fd, int __fd2) ;
# 564 "/usr/include/unistd.h" 3 4
extern char **__environ;







extern int execve (const char *__path, char *const __argv[],
     char *const __envp[]) ;
# 584 "/usr/include/unistd.h" 3 4
extern int execv (const char *__path, char *const __argv[])
     ;



extern int execle (const char *__path, const char *__arg, ...)
     ;



extern int execl (const char *__path, const char *__arg, ...)
     ;



extern int execvp (const char *__file, char *const __argv[])
     ;




extern int execlp (const char *__file, const char *__arg, ...)
     ;
# 624 "/usr/include/unistd.h" 3 4
extern void _exit (int __status) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/confname.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/confname.h" 3 4
enum
  {
    _PC_LINK_MAX,

    _PC_MAX_CANON,

    _PC_MAX_INPUT,

    _PC_NAME_MAX,

    _PC_PATH_MAX,

    _PC_PIPE_BUF,

    _PC_CHOWN_RESTRICTED,

    _PC_NO_TRUNC,

    _PC_VDISABLE,

    _PC_SYNC_IO,

    _PC_ASYNC_IO,

    _PC_PRIO_IO,

    _PC_SOCK_MAXBUF,

    _PC_FILESIZEBITS,

    _PC_REC_INCR_XFER_SIZE,

    _PC_REC_MAX_XFER_SIZE,

    _PC_REC_MIN_XFER_SIZE,

    _PC_REC_XFER_ALIGN,

    _PC_ALLOC_SIZE_MIN,

    _PC_SYMLINK_MAX,

    _PC_2_SYMLINKS

  };


enum
  {
    _SC_ARG_MAX,

    _SC_CHILD_MAX,

    _SC_CLK_TCK,

    _SC_NGROUPS_MAX,

    _SC_OPEN_MAX,

    _SC_STREAM_MAX,

    _SC_TZNAME_MAX,

    _SC_JOB_CONTROL,

    _SC_SAVED_IDS,

    _SC_REALTIME_SIGNALS,

    _SC_PRIORITY_SCHEDULING,

    _SC_TIMERS,

    _SC_ASYNCHRONOUS_IO,

    _SC_PRIORITIZED_IO,

    _SC_SYNCHRONIZED_IO,

    _SC_FSYNC,

    _SC_MAPPED_FILES,

    _SC_MEMLOCK,

    _SC_MEMLOCK_RANGE,

    _SC_MEMORY_PROTECTION,

    _SC_MESSAGE_PASSING,

    _SC_SEMAPHORES,

    _SC_SHARED_MEMORY_OBJECTS,

    _SC_AIO_LISTIO_MAX,

    _SC_AIO_MAX,

    _SC_AIO_PRIO_DELTA_MAX,

    _SC_DELAYTIMER_MAX,

    _SC_MQ_OPEN_MAX,

    _SC_MQ_PRIO_MAX,

    _SC_VERSION,

    _SC_PAGESIZE,


    _SC_RTSIG_MAX,

    _SC_SEM_NSEMS_MAX,

    _SC_SEM_VALUE_MAX,

    _SC_SIGQUEUE_MAX,

    _SC_TIMER_MAX,




    _SC_BC_BASE_MAX,

    _SC_BC_DIM_MAX,

    _SC_BC_SCALE_MAX,

    _SC_BC_STRING_MAX,

    _SC_COLL_WEIGHTS_MAX,

    _SC_EQUIV_CLASS_MAX,

    _SC_EXPR_NEST_MAX,

    _SC_LINE_MAX,

    _SC_RE_DUP_MAX,

    _SC_CHARCLASS_NAME_MAX,


    _SC_2_VERSION,

    _SC_2_C_BIND,

    _SC_2_C_DEV,

    _SC_2_FORT_DEV,

    _SC_2_FORT_RUN,

    _SC_2_SW_DEV,

    _SC_2_LOCALEDEF,


    _SC_PII,

    _SC_PII_XTI,

    _SC_PII_SOCKET,

    _SC_PII_INTERNET,

    _SC_PII_OSI,

    _SC_POLL,

    _SC_SELECT,

    _SC_UIO_MAXIOV,

    _SC_IOV_MAX = _SC_UIO_MAXIOV,

    _SC_PII_INTERNET_STREAM,

    _SC_PII_INTERNET_DGRAM,

    _SC_PII_OSI_COTS,

    _SC_PII_OSI_CLTS,

    _SC_PII_OSI_M,

    _SC_T_IOV_MAX,



    _SC_THREADS,

    _SC_THREAD_SAFE_FUNCTIONS,

    _SC_GETGR_R_SIZE_MAX,

    _SC_GETPW_R_SIZE_MAX,

    _SC_LOGIN_NAME_MAX,

    _SC_TTY_NAME_MAX,

    _SC_THREAD_DESTRUCTOR_ITERATIONS,

    _SC_THREAD_KEYS_MAX,

    _SC_THREAD_STACK_MIN,

    _SC_THREAD_THREADS_MAX,

    _SC_THREAD_ATTR_STACKADDR,

    _SC_THREAD_ATTR_STACKSIZE,

    _SC_THREAD_PRIORITY_SCHEDULING,

    _SC_THREAD_PRIO_INHERIT,

    _SC_THREAD_PRIO_PROTECT,

    _SC_THREAD_PROCESS_SHARED,


    _SC_NPROCESSORS_CONF,

    _SC_NPROCESSORS_ONLN,

    _SC_PHYS_PAGES,

    _SC_AVPHYS_PAGES,

    _SC_ATEXIT_MAX,

    _SC_PASS_MAX,


    _SC_XOPEN_VERSION,

    _SC_XOPEN_XCU_VERSION,

    _SC_XOPEN_UNIX,

    _SC_XOPEN_CRYPT,

    _SC_XOPEN_ENH_I18N,

    _SC_XOPEN_SHM,


    _SC_2_CHAR_TERM,

    _SC_2_C_VERSION,

    _SC_2_UPE,


    _SC_XOPEN_XPG2,

    _SC_XOPEN_XPG3,

    _SC_XOPEN_XPG4,


    _SC_CHAR_BIT,

    _SC_CHAR_MAX,

    _SC_CHAR_MIN,

    _SC_INT_MAX,

    _SC_INT_MIN,

    _SC_LONG_BIT,

    _SC_WORD_BIT,

    _SC_MB_LEN_MAX,

    _SC_NZERO,

    _SC_SSIZE_MAX,

    _SC_SCHAR_MAX,

    _SC_SCHAR_MIN,

    _SC_SHRT_MAX,

    _SC_SHRT_MIN,

    _SC_UCHAR_MAX,

    _SC_UINT_MAX,

    _SC_ULONG_MAX,

    _SC_USHRT_MAX,


    _SC_NL_ARGMAX,

    _SC_NL_LANGMAX,

    _SC_NL_MSGMAX,

    _SC_NL_NMAX,

    _SC_NL_SETMAX,

    _SC_NL_TEXTMAX,


    _SC_XBS5_ILP32_OFF32,

    _SC_XBS5_ILP32_OFFBIG,

    _SC_XBS5_LP64_OFF64,

    _SC_XBS5_LPBIG_OFFBIG,


    _SC_XOPEN_LEGACY,

    _SC_XOPEN_REALTIME,

    _SC_XOPEN_REALTIME_THREADS,


    _SC_ADVISORY_INFO,

    _SC_BARRIERS,

    _SC_BASE,

    _SC_C_LANG_SUPPORT,

    _SC_C_LANG_SUPPORT_R,

    _SC_CLOCK_SELECTION,

    _SC_CPUTIME,

    _SC_THREAD_CPUTIME,

    _SC_DEVICE_IO,

    _SC_DEVICE_SPECIFIC,

    _SC_DEVICE_SPECIFIC_R,

    _SC_FD_MGMT,

    _SC_FIFO,

    _SC_PIPE,

    _SC_FILE_ATTRIBUTES,

    _SC_FILE_LOCKING,

    _SC_FILE_SYSTEM,

    _SC_MONOTONIC_CLOCK,

    _SC_MULTI_PROCESS,

    _SC_SINGLE_PROCESS,

    _SC_NETWORKING,

    _SC_READER_WRITER_LOCKS,

    _SC_SPIN_LOCKS,

    _SC_REGEXP,

    _SC_REGEX_VERSION,

    _SC_SHELL,

    _SC_SIGNALS,

    _SC_SPAWN,

    _SC_SPORADIC_SERVER,

    _SC_THREAD_SPORADIC_SERVER,

    _SC_SYSTEM_DATABASE,

    _SC_SYSTEM_DATABASE_R,

    _SC_TIMEOUTS,

    _SC_TYPED_MEMORY_OBJECTS,

    _SC_USER_GROUPS,

    _SC_USER_GROUPS_R,

    _SC_2_PBS,

    _SC_2_PBS_ACCOUNTING,

    _SC_2_PBS_LOCATE,

    _SC_2_PBS_MESSAGE,

    _SC_2_PBS_TRACK,

    _SC_SYMLOOP_MAX,

    _SC_STREAMS,

    _SC_2_PBS_CHECKPOINT,


    _SC_V6_ILP32_OFF32,

    _SC_V6_ILP32_OFFBIG,

    _SC_V6_LP64_OFF64,

    _SC_V6_LPBIG_OFFBIG,


    _SC_HOST_NAME_MAX,

    _SC_TRACE,

    _SC_TRACE_EVENT_FILTER,

    _SC_TRACE_INHERIT,

    _SC_TRACE_LOG,


    _SC_LEVEL1_ICACHE_SIZE,

    _SC_LEVEL1_ICACHE_ASSOC,

    _SC_LEVEL1_ICACHE_LINESIZE,

    _SC_LEVEL1_DCACHE_SIZE,

    _SC_LEVEL1_DCACHE_ASSOC,

    _SC_LEVEL1_DCACHE_LINESIZE,

    _SC_LEVEL2_CACHE_SIZE,

    _SC_LEVEL2_CACHE_ASSOC,

    _SC_LEVEL2_CACHE_LINESIZE,

    _SC_LEVEL3_CACHE_SIZE,

    _SC_LEVEL3_CACHE_ASSOC,

    _SC_LEVEL3_CACHE_LINESIZE,

    _SC_LEVEL4_CACHE_SIZE,

    _SC_LEVEL4_CACHE_ASSOC,

    _SC_LEVEL4_CACHE_LINESIZE,



    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,

    _SC_RAW_SOCKETS,


    _SC_V7_ILP32_OFF32,

    _SC_V7_ILP32_OFFBIG,

    _SC_V7_LP64_OFF64,

    _SC_V7_LPBIG_OFFBIG,


    _SC_SS_REPL_MAX,


    _SC_TRACE_EVENT_NAME_MAX,

    _SC_TRACE_NAME_MAX,

    _SC_TRACE_SYS_MAX,

    _SC_TRACE_USER_EVENT_MAX,


    _SC_XOPEN_STREAMS,


    _SC_THREAD_ROBUST_PRIO_INHERIT,

    _SC_THREAD_ROBUST_PRIO_PROTECT,


    _SC_MINSIGSTKSZ,


    _SC_SIGSTKSZ

  };


enum
  {
    _CS_PATH,


    _CS_V6_WIDTH_RESTRICTED_ENVS,



    _CS_GNU_LIBC_VERSION,

    _CS_GNU_LIBPTHREAD_VERSION,


    _CS_V5_WIDTH_RESTRICTED_ENVS,



    _CS_V7_WIDTH_RESTRICTED_ENVS,



    _CS_LFS_CFLAGS = 1000,

    _CS_LFS_LDFLAGS,

    _CS_LFS_LIBS,

    _CS_LFS_LINTFLAGS,

    _CS_LFS64_CFLAGS,

    _CS_LFS64_LDFLAGS,

    _CS_LFS64_LIBS,

    _CS_LFS64_LINTFLAGS,


    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,

    _CS_XBS5_ILP32_OFF32_LDFLAGS,

    _CS_XBS5_ILP32_OFF32_LIBS,

    _CS_XBS5_ILP32_OFF32_LINTFLAGS,

    _CS_XBS5_ILP32_OFFBIG_CFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LIBS,

    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,

    _CS_XBS5_LP64_OFF64_CFLAGS,

    _CS_XBS5_LP64_OFF64_LDFLAGS,

    _CS_XBS5_LP64_OFF64_LIBS,

    _CS_XBS5_LP64_OFF64_LINTFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LIBS,

    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LIBS,

    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V6_LP64_OFF64_CFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LIBS,

    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LIBS,

    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V7_LP64_OFF64_CFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LIBS,

    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,


    _CS_V6_ENV,

    _CS_V7_ENV

  };
# 631 "/usr/include/unistd.h" 2 3 4


extern long int pathconf (const char *__path, int __name)
     ;


extern long int fpathconf (int __fd, int __name) ;


extern long int sysconf (int __name) ;
# 650 "/usr/include/unistd.h" 3 4
extern __pid_t getpid (void) ;


extern __pid_t getppid (void) ;


extern __pid_t getpgrp (void) ;


extern __pid_t __getpgid (__pid_t __pid) ;
# 668 "/usr/include/unistd.h" 3 4
extern int setpgid (__pid_t __pid, __pid_t __pgid) ;
# 689 "/usr/include/unistd.h" 3 4
extern __pid_t setsid (void) ;







extern __uid_t getuid (void) ;


extern __uid_t geteuid (void) ;


extern __gid_t getgid (void) ;


extern __gid_t getegid (void) ;




extern int getgroups (int __size, __gid_t __list[])
    ;
# 722 "/usr/include/unistd.h" 3 4
extern int setuid (__uid_t __uid) ;
# 739 "/usr/include/unistd.h" 3 4
extern int setgid (__gid_t __gid) ;
# 778 "/usr/include/unistd.h" 3 4
extern __pid_t fork (void) ;
# 799 "/usr/include/unistd.h" 3 4
extern char *ttyname (int __fd) ;



extern int ttyname_r (int __fd, char *__buf, size_t __buflen)
    
     ;



extern int isatty (int __fd) ;
# 819 "/usr/include/unistd.h" 3 4
extern int link (const char *__from, const char *__to)
     ;
# 858 "/usr/include/unistd.h" 3 4
extern int unlink (const char *__name) ;
# 867 "/usr/include/unistd.h" 3 4
extern int rmdir (const char *__path) ;



extern __pid_t tcgetpgrp (int __fd) ;


extern int tcsetpgrp (int __fd, __pid_t __pgrp_id) ;






extern char *getlogin (void);
# 989 "/usr/include/unistd.h" 3 4
extern int fsync (int __fd);
# 1221 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/unistd_ext.h" 1 3 4
# 1222 "/usr/include/unistd.h" 2 3 4


# 5 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_decl.h" 1







# 7 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_decl.h"
extern int failed;

static void failure(const char * assertion, const char * file,
                    int line, const char * fn)
{
  fprintf(
# 12 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_decl.h" 3 4
         stderr
# 12 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_decl.h"
               , "%s:%d:%s: assertion %s failed\n", file, line, fn, assertion);
  failed = 1;
}



extern unsigned char f1(void);
extern signed char f2(void);
extern unsigned short f3(void);
extern short f4(void);
extern int f5(void);
extern long long f6(void);
extern float f7(void);
extern double f8(void);
extern char * f9(void);
extern void f10(unsigned char x0);
extern void f11(signed char x0);
extern void f12(unsigned short x0);
extern void f13(short x0);
extern void f14(int x0);
extern void f15(long long x0);
extern void f16(float x0);
extern void f17(double x0);
extern void f18(char * x0);
extern void f19(int x0, int x1);
extern void f20(int x0, long long x1);
extern void f21(int x0, float x1);
extern void f22(int x0, double x1);
extern void f23(long long x0, int x1);
extern void f24(long long x0, long long x1);
extern void f25(long long x0, float x1);
extern void f26(long long x0, double x1);
extern void f27(float x0, int x1);
extern void f28(float x0, long long x1);
extern void f29(float x0, float x1);
extern void f30(float x0, double x1);
extern void f31(double x0, int x1);
extern void f32(double x0, long long x1);
extern void f33(double x0, float x1);
extern void f34(double x0, double x1);
extern void f35(int x0, int x1, int x2);
extern void f36(int x0, int x1, long long x2);
extern void f37(int x0, int x1, float x2);
extern void f38(int x0, int x1, double x2);
extern void f39(int x0, long long x1, int x2);
extern void f40(int x0, long long x1, long long x2);
extern void f41(int x0, long long x1, float x2);
extern void f42(int x0, long long x1, double x2);
extern void f43(int x0, float x1, int x2);
extern void f44(int x0, float x1, long long x2);
extern void f45(int x0, float x1, float x2);
extern void f46(int x0, float x1, double x2);
extern void f47(int x0, double x1, int x2);
extern void f48(int x0, double x1, long long x2);
extern void f49(int x0, double x1, float x2);
extern void f50(int x0, double x1, double x2);
extern void f51(long long x0, int x1, int x2);
extern void f52(long long x0, int x1, long long x2);
extern void f53(long long x0, int x1, float x2);
extern void f54(long long x0, int x1, double x2);
extern void f55(long long x0, long long x1, int x2);
extern void f56(long long x0, long long x1, long long x2);
extern void f57(long long x0, long long x1, float x2);
extern void f58(long long x0, long long x1, double x2);
extern void f59(long long x0, float x1, int x2);
extern void f60(long long x0, float x1, long long x2);
extern void f61(long long x0, float x1, float x2);
extern void f62(long long x0, float x1, double x2);
extern void f63(long long x0, double x1, int x2);
extern void f64(long long x0, double x1, long long x2);
extern void f65(long long x0, double x1, float x2);
extern void f66(long long x0, double x1, double x2);
extern void f67(float x0, int x1, int x2);
extern void f68(float x0, int x1, long long x2);
extern void f69(float x0, int x1, float x2);
extern void f70(float x0, int x1, double x2);
extern void f71(float x0, long long x1, int x2);
extern void f72(float x0, long long x1, long long x2);
extern void f73(float x0, long long x1, float x2);
extern void f74(float x0, long long x1, double x2);
extern void f75(float x0, float x1, int x2);
extern void f76(float x0, float x1, long long x2);
extern void f77(float x0, float x1, float x2);
extern void f78(float x0, float x1, double x2);
extern void f79(float x0, double x1, int x2);
extern void f80(float x0, double x1, long long x2);
extern void f81(float x0, double x1, float x2);
extern void f82(float x0, double x1, double x2);
extern void f83(double x0, int x1, int x2);
extern void f84(double x0, int x1, long long x2);
extern void f85(double x0, int x1, float x2);
extern void f86(double x0, int x1, double x2);
extern void f87(double x0, long long x1, int x2);
extern void f88(double x0, long long x1, long long x2);
extern void f89(double x0, long long x1, float x2);
extern void f90(double x0, long long x1, double x2);
extern void f91(double x0, float x1, int x2);
extern void f92(double x0, float x1, long long x2);
extern void f93(double x0, float x1, float x2);
extern void f94(double x0, float x1, double x2);
extern void f95(double x0, double x1, int x2);
extern void f96(double x0, double x1, long long x2);
extern void f97(double x0, double x1, float x2);
extern void f98(double x0, double x1, double x2);
extern void f99(int x0, int x1, int x2, int x3);
extern void f100(int x0, int x1, int x2, long long x3);
extern void f101(int x0, int x1, int x2, float x3);
extern void f102(int x0, int x1, int x2, double x3);
extern void f103(int x0, int x1, long long x2, int x3);
extern void f104(int x0, int x1, long long x2, long long x3);
extern void f105(int x0, int x1, long long x2, float x3);
extern void f106(int x0, int x1, long long x2, double x3);
extern void f107(int x0, int x1, float x2, int x3);
extern void f108(int x0, int x1, float x2, long long x3);
extern void f109(int x0, int x1, float x2, float x3);
extern void f110(int x0, int x1, float x2, double x3);
extern void f111(int x0, int x1, double x2, int x3);
extern void f112(int x0, int x1, double x2, long long x3);
extern void f113(int x0, int x1, double x2, float x3);
extern void f114(int x0, int x1, double x2, double x3);
extern void f115(int x0, long long x1, int x2, int x3);
extern void f116(int x0, long long x1, int x2, long long x3);
extern void f117(int x0, long long x1, int x2, float x3);
extern void f118(int x0, long long x1, int x2, double x3);
extern void f119(int x0, long long x1, long long x2, int x3);
extern void f120(int x0, long long x1, long long x2, long long x3);
extern void f121(int x0, long long x1, long long x2, float x3);
extern void f122(int x0, long long x1, long long x2, double x3);
extern void f123(int x0, long long x1, float x2, int x3);
extern void f124(int x0, long long x1, float x2, long long x3);
extern void f125(int x0, long long x1, float x2, float x3);
extern void f126(int x0, long long x1, float x2, double x3);
extern void f127(int x0, long long x1, double x2, int x3);
extern void f128(int x0, long long x1, double x2, long long x3);
extern void f129(int x0, long long x1, double x2, float x3);
extern void f130(int x0, long long x1, double x2, double x3);
extern void f131(int x0, float x1, int x2, int x3);
extern void f132(int x0, float x1, int x2, long long x3);
extern void f133(int x0, float x1, int x2, float x3);
extern void f134(int x0, float x1, int x2, double x3);
extern void f135(int x0, float x1, long long x2, int x3);
extern void f136(int x0, float x1, long long x2, long long x3);
extern void f137(int x0, float x1, long long x2, float x3);
extern void f138(int x0, float x1, long long x2, double x3);
extern void f139(int x0, float x1, float x2, int x3);
extern void f140(int x0, float x1, float x2, long long x3);
extern void f141(int x0, float x1, float x2, float x3);
extern void f142(int x0, float x1, float x2, double x3);
extern void f143(int x0, float x1, double x2, int x3);
extern void f144(int x0, float x1, double x2, long long x3);
extern void f145(int x0, float x1, double x2, float x3);
extern void f146(int x0, float x1, double x2, double x3);
extern void f147(int x0, double x1, int x2, int x3);
extern void f148(int x0, double x1, int x2, long long x3);
extern void f149(int x0, double x1, int x2, float x3);
extern void f150(int x0, double x1, int x2, double x3);
extern void f151(int x0, double x1, long long x2, int x3);
extern void f152(int x0, double x1, long long x2, long long x3);
extern void f153(int x0, double x1, long long x2, float x3);
extern void f154(int x0, double x1, long long x2, double x3);
extern void f155(int x0, double x1, float x2, int x3);
extern void f156(int x0, double x1, float x2, long long x3);
extern void f157(int x0, double x1, float x2, float x3);
extern void f158(int x0, double x1, float x2, double x3);
extern void f159(int x0, double x1, double x2, int x3);
extern void f160(int x0, double x1, double x2, long long x3);
extern void f161(int x0, double x1, double x2, float x3);
extern void f162(int x0, double x1, double x2, double x3);
extern void f163(long long x0, int x1, int x2, int x3);
extern void f164(long long x0, int x1, int x2, long long x3);
extern void f165(long long x0, int x1, int x2, float x3);
extern void f166(long long x0, int x1, int x2, double x3);
extern void f167(long long x0, int x1, long long x2, int x3);
extern void f168(long long x0, int x1, long long x2, long long x3);
extern void f169(long long x0, int x1, long long x2, float x3);
extern void f170(long long x0, int x1, long long x2, double x3);
extern void f171(long long x0, int x1, float x2, int x3);
extern void f172(long long x0, int x1, float x2, long long x3);
extern void f173(long long x0, int x1, float x2, float x3);
extern void f174(long long x0, int x1, float x2, double x3);
extern void f175(long long x0, int x1, double x2, int x3);
extern void f176(long long x0, int x1, double x2, long long x3);
extern void f177(long long x0, int x1, double x2, float x3);
extern void f178(long long x0, int x1, double x2, double x3);
extern void f179(long long x0, long long x1, int x2, int x3);
extern void f180(long long x0, long long x1, int x2, long long x3);
extern void f181(long long x0, long long x1, int x2, float x3);
extern void f182(long long x0, long long x1, int x2, double x3);
extern void f183(long long x0, long long x1, long long x2, int x3);
extern void f184(long long x0, long long x1, long long x2, long long x3);
extern void f185(long long x0, long long x1, long long x2, float x3);
extern void f186(long long x0, long long x1, long long x2, double x3);
extern void f187(long long x0, long long x1, float x2, int x3);
extern void f188(long long x0, long long x1, float x2, long long x3);
extern void f189(long long x0, long long x1, float x2, float x3);
extern void f190(long long x0, long long x1, float x2, double x3);
extern void f191(long long x0, long long x1, double x2, int x3);
extern void f192(long long x0, long long x1, double x2, long long x3);
extern void f193(long long x0, long long x1, double x2, float x3);
extern void f194(long long x0, long long x1, double x2, double x3);
extern void f195(long long x0, float x1, int x2, int x3);
extern void f196(long long x0, float x1, int x2, long long x3);
extern void f197(long long x0, float x1, int x2, float x3);
extern void f198(long long x0, float x1, int x2, double x3);
extern void f199(long long x0, float x1, long long x2, int x3);
extern void f200(long long x0, float x1, long long x2, long long x3);
extern void f201(long long x0, float x1, long long x2, float x3);
extern void f202(long long x0, float x1, long long x2, double x3);
extern void f203(long long x0, float x1, float x2, int x3);
extern void f204(long long x0, float x1, float x2, long long x3);
extern void f205(long long x0, float x1, float x2, float x3);
extern void f206(long long x0, float x1, float x2, double x3);
extern void f207(long long x0, float x1, double x2, int x3);
extern void f208(long long x0, float x1, double x2, long long x3);
extern void f209(long long x0, float x1, double x2, float x3);
extern void f210(long long x0, float x1, double x2, double x3);
extern void f211(long long x0, double x1, int x2, int x3);
extern void f212(long long x0, double x1, int x2, long long x3);
extern void f213(long long x0, double x1, int x2, float x3);
extern void f214(long long x0, double x1, int x2, double x3);
extern void f215(long long x0, double x1, long long x2, int x3);
extern void f216(long long x0, double x1, long long x2, long long x3);
extern void f217(long long x0, double x1, long long x2, float x3);
extern void f218(long long x0, double x1, long long x2, double x3);
extern void f219(long long x0, double x1, float x2, int x3);
extern void f220(long long x0, double x1, float x2, long long x3);
extern void f221(long long x0, double x1, float x2, float x3);
extern void f222(long long x0, double x1, float x2, double x3);
extern void f223(long long x0, double x1, double x2, int x3);
extern void f224(long long x0, double x1, double x2, long long x3);
extern void f225(long long x0, double x1, double x2, float x3);
extern void f226(long long x0, double x1, double x2, double x3);
extern void f227(float x0, int x1, int x2, int x3);
extern void f228(float x0, int x1, int x2, long long x3);
extern void f229(float x0, int x1, int x2, float x3);
extern void f230(float x0, int x1, int x2, double x3);
extern void f231(float x0, int x1, long long x2, int x3);
extern void f232(float x0, int x1, long long x2, long long x3);
extern void f233(float x0, int x1, long long x2, float x3);
extern void f234(float x0, int x1, long long x2, double x3);
extern void f235(float x0, int x1, float x2, int x3);
extern void f236(float x0, int x1, float x2, long long x3);
extern void f237(float x0, int x1, float x2, float x3);
extern void f238(float x0, int x1, float x2, double x3);
extern void f239(float x0, int x1, double x2, int x3);
extern void f240(float x0, int x1, double x2, long long x3);
extern void f241(float x0, int x1, double x2, float x3);
extern void f242(float x0, int x1, double x2, double x3);
extern void f243(float x0, long long x1, int x2, int x3);
extern void f244(float x0, long long x1, int x2, long long x3);
extern void f245(float x0, long long x1, int x2, float x3);
extern void f246(float x0, long long x1, int x2, double x3);
extern void f247(float x0, long long x1, long long x2, int x3);
extern void f248(float x0, long long x1, long long x2, long long x3);
extern void f249(float x0, long long x1, long long x2, float x3);
extern void f250(float x0, long long x1, long long x2, double x3);
extern void f251(float x0, long long x1, float x2, int x3);
extern void f252(float x0, long long x1, float x2, long long x3);
extern void f253(float x0, long long x1, float x2, float x3);
extern void f254(float x0, long long x1, float x2, double x3);
extern void f255(float x0, long long x1, double x2, int x3);
extern void f256(float x0, long long x1, double x2, long long x3);
extern void f257(float x0, long long x1, double x2, float x3);
extern void f258(float x0, long long x1, double x2, double x3);
extern void f259(float x0, float x1, int x2, int x3);
extern void f260(float x0, float x1, int x2, long long x3);
extern void f261(float x0, float x1, int x2, float x3);
extern void f262(float x0, float x1, int x2, double x3);
extern void f263(float x0, float x1, long long x2, int x3);
extern void f264(float x0, float x1, long long x2, long long x3);
extern void f265(float x0, float x1, long long x2, float x3);
extern void f266(float x0, float x1, long long x2, double x3);
extern void f267(float x0, float x1, float x2, int x3);
extern void f268(float x0, float x1, float x2, long long x3);
extern void f269(float x0, float x1, float x2, float x3);
extern void f270(float x0, float x1, float x2, double x3);
extern void f271(float x0, float x1, double x2, int x3);
extern void f272(float x0, float x1, double x2, long long x3);
extern void f273(float x0, float x1, double x2, float x3);
extern void f274(float x0, float x1, double x2, double x3);
extern void f275(float x0, double x1, int x2, int x3);
extern void f276(float x0, double x1, int x2, long long x3);
extern void f277(float x0, double x1, int x2, float x3);
extern void f278(float x0, double x1, int x2, double x3);
extern void f279(float x0, double x1, long long x2, int x3);
extern void f280(float x0, double x1, long long x2, long long x3);
extern void f281(float x0, double x1, long long x2, float x3);
extern void f282(float x0, double x1, long long x2, double x3);
extern void f283(float x0, double x1, float x2, int x3);
extern void f284(float x0, double x1, float x2, long long x3);
extern void f285(float x0, double x1, float x2, float x3);
extern void f286(float x0, double x1, float x2, double x3);
extern void f287(float x0, double x1, double x2, int x3);
extern void f288(float x0, double x1, double x2, long long x3);
extern void f289(float x0, double x1, double x2, float x3);
extern void f290(float x0, double x1, double x2, double x3);
extern void f291(double x0, int x1, int x2, int x3);
extern void f292(double x0, int x1, int x2, long long x3);
extern void f293(double x0, int x1, int x2, float x3);
extern void f294(double x0, int x1, int x2, double x3);
extern void f295(double x0, int x1, long long x2, int x3);
extern void f296(double x0, int x1, long long x2, long long x3);
extern void f297(double x0, int x1, long long x2, float x3);
extern void f298(double x0, int x1, long long x2, double x3);
extern void f299(double x0, int x1, float x2, int x3);
extern void f300(double x0, int x1, float x2, long long x3);
extern void f301(double x0, int x1, float x2, float x3);
extern void f302(double x0, int x1, float x2, double x3);
extern void f303(double x0, int x1, double x2, int x3);
extern void f304(double x0, int x1, double x2, long long x3);
extern void f305(double x0, int x1, double x2, float x3);
extern void f306(double x0, int x1, double x2, double x3);
extern void f307(double x0, long long x1, int x2, int x3);
extern void f308(double x0, long long x1, int x2, long long x3);
extern void f309(double x0, long long x1, int x2, float x3);
extern void f310(double x0, long long x1, int x2, double x3);
extern void f311(double x0, long long x1, long long x2, int x3);
extern void f312(double x0, long long x1, long long x2, long long x3);
extern void f313(double x0, long long x1, long long x2, float x3);
extern void f314(double x0, long long x1, long long x2, double x3);
extern void f315(double x0, long long x1, float x2, int x3);
extern void f316(double x0, long long x1, float x2, long long x3);
extern void f317(double x0, long long x1, float x2, float x3);
extern void f318(double x0, long long x1, float x2, double x3);
extern void f319(double x0, long long x1, double x2, int x3);
extern void f320(double x0, long long x1, double x2, long long x3);
extern void f321(double x0, long long x1, double x2, float x3);
extern void f322(double x0, long long x1, double x2, double x3);
extern void f323(double x0, float x1, int x2, int x3);
extern void f324(double x0, float x1, int x2, long long x3);
extern void f325(double x0, float x1, int x2, float x3);
extern void f326(double x0, float x1, int x2, double x3);
extern void f327(double x0, float x1, long long x2, int x3);
extern void f328(double x0, float x1, long long x2, long long x3);
extern void f329(double x0, float x1, long long x2, float x3);
extern void f330(double x0, float x1, long long x2, double x3);
extern void f331(double x0, float x1, float x2, int x3);
extern void f332(double x0, float x1, float x2, long long x3);
extern void f333(double x0, float x1, float x2, float x3);
extern void f334(double x0, float x1, float x2, double x3);
extern void f335(double x0, float x1, double x2, int x3);
extern void f336(double x0, float x1, double x2, long long x3);
extern void f337(double x0, float x1, double x2, float x3);
extern void f338(double x0, float x1, double x2, double x3);
extern void f339(double x0, double x1, int x2, int x3);
extern void f340(double x0, double x1, int x2, long long x3);
extern void f341(double x0, double x1, int x2, float x3);
extern void f342(double x0, double x1, int x2, double x3);
extern void f343(double x0, double x1, long long x2, int x3);
extern void f344(double x0, double x1, long long x2, long long x3);
extern void f345(double x0, double x1, long long x2, float x3);
extern void f346(double x0, double x1, long long x2, double x3);
extern void f347(double x0, double x1, float x2, int x3);
extern void f348(double x0, double x1, float x2, long long x3);
extern void f349(double x0, double x1, float x2, float x3);
extern void f350(double x0, double x1, float x2, double x3);
extern void f351(double x0, double x1, double x2, int x3);
extern void f352(double x0, double x1, double x2, long long x3);
extern void f353(double x0, double x1, double x2, float x3);
extern void f354(double x0, double x1, double x2, double x3);
extern void f355(int x0, int x1, int x2, int x3, int x4, int x5);
extern void f356(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7);
extern void f357(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7, int x8, int x9);
extern void f358(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7, int x8, int x9, int x10, int x11);
extern void f359(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7, int x8, int x9, int x10, int x11, int x12, int x13, int x14, int x15);
extern void f360(int x0, int x1, int x2, int x3, int x4, int x5, int x6, int x7, int x8, int x9, int x10, int x11, int x12, int x13, int x14, int x15, int x16, int x17, int x18, int x19, int x20, int x21, int x22, int x23, int x24, int x25, int x26, int x27, int x28, int x29, int x30, int x31);
extern void f361(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5);
extern void f362(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7);
extern void f363(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7, long long x8, long long x9);
extern void f364(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7, long long x8, long long x9, long long x10, long long x11);
extern void f365(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7, long long x8, long long x9, long long x10, long long x11, long long x12, long long x13, long long x14, long long x15);
extern void f366(long long x0, long long x1, long long x2, long long x3, long long x4, long long x5, long long x6, long long x7, long long x8, long long x9, long long x10, long long x11, long long x12, long long x13, long long x14, long long x15, long long x16, long long x17, long long x18, long long x19, long long x20, long long x21, long long x22, long long x23, long long x24, long long x25, long long x26, long long x27, long long x28, long long x29, long long x30, long long x31);
extern void f367(float x0, float x1, float x2, float x3, float x4, float x5);
extern void f368(float x0, float x1, float x2, float x3, float x4, float x5, float x6, float x7);
extern void f369(float x0, float x1, float x2, float x3, float x4, float x5, float x6, float x7, float x8, float x9);
extern void f370(float x0, float x1, float x2, float x3, float x4, float x5, float x6, float x7, float x8, float x9, float x10, float x11);
extern void f371(float x0, float x1, float x2, float x3, float x4, float x5, float x6, float x7, float x8, float x9, float x10, float x11, float x12, float x13, float x14, float x15);
extern void f372(float x0, float x1, float x2, float x3, float x4, float x5, float x6, float x7, float x8, float x9, float x10, float x11, float x12, float x13, float x14, float x15, float x16, float x17, float x18, float x19, float x20, float x21, float x22, float x23, float x24, float x25, float x26, float x27, float x28, float x29, float x30, float x31);
extern void f373(double x0, double x1, double x2, double x3, double x4, double x5);
extern void f374(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7);
extern void f375(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9);
extern void f376(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11);
extern void f377(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11, double x12, double x13, double x14, double x15);
extern void f378(double x0, double x1, double x2, double x3, double x4, double x5, double x6, double x7, double x8, double x9, double x10, double x11, double x12, double x13, double x14, double x15, double x16, double x17, double x18, double x19, double x20, double x21, double x22, double x23, double x24, double x25, double x26, double x27, double x28, double x29, double x30, double x31);
extern void f379(int x0, long long x1, int x2, long long x3, int x4, long long x5);
extern void f380(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7);
extern void f381(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7, int x8, long long x9);
extern void f382(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7, int x8, long long x9, int x10, long long x11);
extern void f383(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7, int x8, long long x9, int x10, long long x11, int x12, long long x13, int x14, long long x15);
extern void f384(int x0, long long x1, int x2, long long x3, int x4, long long x5, int x6, long long x7, int x8, long long x9, int x10, long long x11, int x12, long long x13, int x14, long long x15, int x16, long long x17, int x18, long long x19, int x20, long long x21, int x22, long long x23, int x24, long long x25, int x26, long long x27, int x28, long long x29, int x30, long long x31);
extern void f385(int x0, float x1, int x2, float x3, int x4, float x5);
extern void f386(int x0, float x1, int x2, float x3, int x4, float x5, int x6, float x7);
extern void f387(int x0, float x1, int x2, float x3, int x4, float x5, int x6, float x7, int x8, float x9);
extern void f388(int x0, float x1, int x2, float x3, int x4, float x5, int x6, float x7, int x8, float x9, int x10, float x11);
extern void f389(int x0, float x1, int x2, float x3, int x4, float x5, int x6, float x7, int x8, float x9, int x10, float x11, int x12, float x13, int x14, float x15);
extern void f390(int x0, float x1, int x2, float x3, int x4, float x5, int x6, float x7, int x8, float x9, int x10, float x11, int x12, float x13, int x14, float x15, int x16, float x17, int x18, float x19, int x20, float x21, int x22, float x23, int x24, float x25, int x26, float x27, int x28, float x29, int x30, float x31);
extern void f391(int x0, double x1, int x2, double x3, int x4, double x5);
extern void f392(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7);
extern void f393(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7, int x8, double x9);
extern void f394(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7, int x8, double x9, int x10, double x11);
extern void f395(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7, int x8, double x9, int x10, double x11, int x12, double x13, int x14, double x15);
extern void f396(int x0, double x1, int x2, double x3, int x4, double x5, int x6, double x7, int x8, double x9, int x10, double x11, int x12, double x13, int x14, double x15, int x16, double x17, int x18, double x19, int x20, double x21, int x22, double x23, int x24, double x25, int x26, double x27, int x28, double x29, int x30, double x31);
extern void f397(long long x0, float x1, long long x2, float x3, long long x4, float x5);
extern void f398(long long x0, float x1, long long x2, float x3, long long x4, float x5, long long x6, float x7);
extern void f399(long long x0, float x1, long long x2, float x3, long long x4, float x5, long long x6, float x7, long long x8, float x9);
extern void f400(long long x0, float x1, long long x2, float x3, long long x4, float x5, long long x6, float x7, long long x8, float x9, long long x10, float x11);
extern void f401(long long x0, float x1, long long x2, float x3, long long x4, float x5, long long x6, float x7, long long x8, float x9, long long x10, float x11, long long x12, float x13, long long x14, float x15);
extern void f402(long long x0, float x1, long long x2, float x3, long long x4, float x5, long long x6, float x7, long long x8, float x9, long long x10, float x11, long long x12, float x13, long long x14, float x15, long long x16, float x17, long long x18, float x19, long long x20, float x21, long long x22, float x23, long long x24, float x25, long long x26, float x27, long long x28, float x29, long long x30, float x31);
extern void f403(long long x0, double x1, long long x2, double x3, long long x4, double x5);
extern void f404(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7);
extern void f405(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7, long long x8, double x9);
extern void f406(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7, long long x8, double x9, long long x10, double x11);
extern void f407(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7, long long x8, double x9, long long x10, double x11, long long x12, double x13, long long x14, double x15);
extern void f408(long long x0, double x1, long long x2, double x3, long long x4, double x5, long long x6, double x7, long long x8, double x9, long long x10, double x11, long long x12, double x13, long long x14, double x15, long long x16, double x17, long long x18, double x19, long long x20, double x21, long long x22, double x23, long long x24, double x25, long long x26, double x27, long long x28, double x29, long long x30, double x31);
extern void f409(float x0, double x1, float x2, double x3, float x4, double x5);
extern void f410(float x0, double x1, float x2, double x3, float x4, double x5, float x6, double x7);
extern void f411(float x0, double x1, float x2, double x3, float x4, double x5, float x6, double x7, float x8, double x9);
extern void f412(float x0, double x1, float x2, double x3, float x4, double x5, float x6, double x7, float x8, double x9, float x10, double x11);
extern void f413(float x0, double x1, float x2, double x3, float x4, double x5, float x6, double x7, float x8, double x9, float x10, double x11, float x12, double x13, float x14, double x15);
extern void f414(float x0, double x1, float x2, double x3, float x4, double x5, float x6, double x7, float x8, double x9, float x10, double x11, float x12, double x13, float x14, double x15, float x16, double x17, float x18, double x19, float x20, double x21, float x22, double x23, float x24, double x25, float x26, double x27, float x28, double x29, float x30, double x31);
extern void f415(int x0, long long x1, float x2, double x3, int x4, long long x5);
extern void f416(int x0, long long x1, float x2, double x3, int x4, long long x5, float x6, double x7);
extern void f417(int x0, long long x1, float x2, double x3, int x4, long long x5, float x6, double x7, int x8, long long x9);
extern void f418(int x0, long long x1, float x2, double x3, int x4, long long x5, float x6, double x7, int x8, long long x9, float x10, double x11);
extern void f419(int x0, long long x1, float x2, double x3, int x4, long long x5, float x6, double x7, int x8, long long x9, float x10, double x11, int x12, long long x13, float x14, double x15);
extern void f420(int x0, long long x1, float x2, double x3, int x4, long long x5, float x6, double x7, int x8, long long x9, float x10, double x11, int x12, long long x13, float x14, double x15, int x16, long long x17, float x18, double x19, int x20, long long x21, float x22, double x23, int x24, long long x25, float x26, double x27, int x28, long long x29, float x30, double x31);
extern void f421(int x0);
extern void f422(int x0, char * x1, int x2, double x3, double x4, float x5, float x6, float x7, double x8);
extern void f423(long long x0, int x1, char * x2);
extern char * f424(double x0, double x1, long long x2, char * x3, long long x4, float x5, double x6, int x7);
extern void f425(int x0, float x1, char * x2, double x3, int x4, float x5, char * x6, double x7);
extern void f426(double x0, long long x1, int x2);
extern long long f427(float x0, long long x1, double x2, int x3, int x4, double x5, char * x6, int x7, long long x8, char * x9, int x10);
extern void f428(double x0, double x1);
extern int f429(long long x0, double x1);
extern void f430(int x0, float x1);
extern long long f431(char * x0, long long x1, long long x2, int x3, int x4, int x5, double x6, long long x7);
extern void f432(double x0, double x1, float x2, int x3, long long x4);
extern signed char f433(char * x0);
extern void f434(char * x0, float x1, char * x2, float x3, char * x4, float x5);
extern unsigned char f435(long long x0, int x1, double x2, float x3, double x4, long long x5, float x6);
extern void f436(float x0, long long x1, double x2, int x3, double x4, double x5, long long x6, char * x7);
extern void f437(void);
extern long long f438(char * x0, char * x1, int x2, double x3, char * x4, char * x5, double x6, float x7);
extern void f439(float x0, long long x1, long long x2, char * x3);
extern int f440(char * x0, char * x1, int x2, char * x3, float x4, float x5);
extern void f441(float x0, double x1);
extern float f442(long long x0, int x1, char * x2);
extern float f443(int x0, long long x1, float x2, int x3);
extern float f444(long long x0, int x1, long long x2, int x3, double x4, char * x5, float x6);
extern short f445(int x0, char * x1, char * x2, float x3);
extern signed char f446(long long x0, int x1, int x2);
extern float f447(int x0, float x1, int x2, double x3, int x4);
extern void f448(int x0, double x1, int x2, char * x3);
extern void f449(double x0, float x1, float x2, float x3, float x4, double x5, double x6, int x7);
extern float f450(float x0, char * x1, double x2);
extern void f451(double x0, char * x1, float x2, int x3, char * x4, double x5, double x6, char * x7, int x8, char * x9);
extern double f452(char * x0);
extern long long f453(double x0);
extern double f454(float x0, float x1, char * x2, float x3, long long x4, int x5, int x6, float x7);
extern long long f455(double x0, char * x1, char * x2, long long x3, int x4, float x5, double x6, char * x7);
extern short f456(double x0, float x1, int x2);
extern int f457(char * x0, int x1, char * x2, double x3, char * x4, int x5, char * x6, char * x7, int x8, double x9);
extern char * f458(float x0, float x1, long long x2, int x3, float x4, char * x5, float x6, int x7, char * x8, float x9);
extern void f459(long long x0, double x1, float x2, long long x3, int x4, char * x5, int x6);
extern void f460(long long x0, long long x1, char * x2, double x3, float x4);
extern float f461(long long x0, char * x1, int x2, double x3, float x4, float x5, long long x6);
extern short f462(void);
extern void f463(float x0, int x1, long long x2, char * x3, int x4);
extern void f464(double x0, char * x1, char * x2, float x3, int x4, float x5, long long x6, char * x7, long long x8);
extern unsigned short f465(float x0, char * x1, char * x2, int x3, long long x4, int x5);
extern unsigned char f466(long long x0, int x1, int x2, double x3, long long x4, long long x5, long long x6, double x7, int x8, int x9);
extern void f467(long long x0, int x1, char * x2, long long x3, int x4, long long x5, double x6, char * x7);
extern char * f468(float x0, long long x1);
extern char * f469(long long x0, long long x1, long long x2, float x3, int x4, int x5, float x6, float x7);
extern short f470(char * x0, char * x1, double x2, int x3, char * x4);
extern unsigned char f471(double x0, double x1, char * x2, double x3, float x4, long long x5, char * x6, char * x7, double x8, long long x9, float x10);
extern double f472(void);
extern void f473(float x0, float x1, double x2, float x3, float x4, int x5, long long x6, long long x7, char * x8, int x9);
extern void f474(double x0, float x1, char * x2, char * x3, char * x4, long long x5, long long x6, double x7, char * x8);
extern void f475(double x0, double x1, int x2, int x3);
extern void f476(float x0, double x1, double x2);
extern void f477(float x0, double x1, float x2, float x3, int x4);
extern void f478(long long x0, int x1, double x2, int x3, double x4, int x5, long long x6, double x7);
extern void f479(int x0, float x1, char * x2, char * x3, int x4);
extern short f480(char * x0, char * x1, char * x2, double x3);
extern int f481(char * x0, int x1, long long x2, char * x3, char * x4);
extern unsigned short f482(double x0, int x1, int x2, char * x3, char * x4, char * x5, long long x6, float x7);
extern signed char f483(float x0, long long x1, double x2, double x3, double x4, double x5, char * x6, float x7, float x8);
extern void f484(float x0, float x1, long long x2, float x3, long long x4, int x5, long long x6, char * x7, float x8, int x9, int x10);
extern void f485(double x0, char * x1, float x2, int x3, int x4, float x5);
extern unsigned short f486(double x0, float x1);
extern void f487(void);
extern long long f488(int x0, long long x1, long long x2, int x3, long long x4, long long x5, long long x6, char * x7, float x8, double x9);
extern signed char f489(long long x0, float x1, char * x2, double x3, int x4, double x5, double x6, double x7, float x8, double x9, long long x10);
extern unsigned short f490(float x0, char * x1, char * x2, float x3);
extern void f491(int x0, char * x1, int x2);
extern void f492(double x0, int x1, long long x2, char * x3, long long x4);
extern int f493(char * x0);
extern double f494(double x0, char * x1, float x2);
extern void f495(char * x0, int x1, long long x2, long long x3, int x4, int x5, char * x6, char * x7, double x8);
extern unsigned char f496(long long x0, long long x1);
extern void f497(float x0, double x1);
extern void f498(long long x0, double x1, long long x2, long long x3);
extern short f499(int x0, char * x1, char * x2, float x3, int x4);
extern void f500(float x0, long long x1, double x2, float x3);
extern void f501(float x0, double x1, long long x2);
extern void f502(float x0, float x1, long long x2, long long x3, double x4);
extern char * f503(long long x0, int x1, char * x2, int x3, int x4, double x5, double x6, long long x7);
extern short f504(char * x0, double x1, double x2, long long x3, int x4, long long x5, long long x6, float x7, double x8, int x9);
extern short f505(int x0, char * x1, int x2, double x3, long long x4, char * x5, int x6, int x7, char * x8, double x9, float x10);
extern signed char f506(char * x0, long long x1, int x2);
extern unsigned char f507(int x0, char * x1, float x2, double x3, float x4, char * x5);
extern void f508(int x0, long long x1, double x2, float x3, int x4, long long x5, float x6, double x7, int x8, long long x9);
extern void f509(long long x0, double x1, float x2, float x3, float x4, long long x5, float x6, char * x7);
extern void f510(char * x0, int x1, float x2, float x3, int x4, int x5, int x6, long long x7, float x8, long long x9);
extern float f511(int x0, char * x1, long long x2, long long x3, double x4, long long x5, int x6, float x7);
extern char * f512(double x0, float x1, double x2, long long x3, float x4, long long x5, float x6, float x7);
extern signed char f513(char * x0, int x1, int x2, char * x3, float x4, long long x5, long long x6, int x7, long long x8, int x9);
extern void f514(int x0, char * x1, float x2, char * x3, char * x4, char * x5, char * x6, float x7, char * x8, float x9, int x10);
extern void f515(char * x0, long long x1, double x2, long long x3, float x4);
extern void f516(float x0, char * x1, char * x2, long long x3, double x4, long long x5, char * x6);
extern int f517(char * x0, int x1, float x2, float x3, double x4, float x5, char * x6, int x7);
extern void f518(float x0);
extern long long f519(float x0, long long x1, char * x2, long long x3, long long x4);
extern void f520(int x0);
extern void f521(float x0, char * x1, float x2, float x3, int x4, int x5, long long x6, int x7, int x8);
extern void f522(double x0, int x1, int x2, float x3, long long x4, int x5);
extern void f523(float x0, long long x1, long long x2, long long x3, int x4, char * x5, long long x6, char * x7, double x8, float x9, long long x10);
extern void f524(float x0, long long x1, int x2, long long x3, double x4, float x5, float x6, int x7, float x8, int x9, float x10);
extern void f525(float x0, float x1, char * x2, int x3, float x4, double x5, char * x6, long long x7, double x8, long long x9, float x10);
extern unsigned char f526(float x0, long long x1);
extern void f527(double x0, int x1, float x2);
extern void f528(int x0, long long x1, float x2, int x3, int x4, int x5, char * x6, double x7, double x8, long long x9);
extern void f529(char * x0, double x1, int x2, int x3);
extern char * f530(long long x0, int x1, float x2, float x3, char * x4, char * x5);
extern void f531(float x0, float x1, double x2);
extern unsigned char f532(double x0, float x1, int x2, long long x3, char * x4);
extern short f533(char * x0, double x1, float x2, float x3);
extern void f534(int x0, long long x1, int x2, float x3, double x4);
extern void f535(double x0, int x1, float x2);
extern void f536(long long x0);
extern signed char f537(long long x0, float x1, char * x2, long long x3, float x4);
extern void f538(long long x0, long long x1, int x2, int x3, char * x4, long long x5, int x6, char * x7, long long x8, double x9, double x10);
extern void f539(void);
extern float f540(float x0, float x1, double x2, char * x3, int x4, double x5, double x6, double x7, double x8, long long x9);
extern signed char f541(long long x0, int x1, float x2, float x3, long long x4, double x5, long long x6, float x7, long long x8, long long x9, int x10);
extern unsigned char f542(void);
extern double f543(long long x0, double x1, double x2, double x3, long long x4);
extern void f544(float x0, double x1, int x2, int x3, char * x4);
extern void f545(float x0, int x1, int x2, int x3);
extern double f546(long long x0, double x1, double x2, float x3, float x4, long long x5, long long x6, char * x7, double x8);
extern short f547(float x0, float x1);
extern void f548(float x0, char * x1, float x2, char * x3, long long x4, double x5, float x6, char * x7, int x8);
extern void f549(char * x0, float x1, float x2, double x3, char * x4, long long x5, char * x6, long long x7, double x8, double x9);
extern void f550(double x0, int x1, long long x2, char * x3);
extern void f551(int x0, double x1, char * x2, int x3, float x4, int x5, int x6, double x7, int x8, double x9);
extern void f552(char * x0, float x1, long long x2, float x3, float x4, long long x5);
extern void f553(void);
extern char * f554(int x0, float x1);
extern void f555(double x0);
extern void f556(float x0, int x1, long long x2, char * x3, char * x4, double x5, int x6, int x7, char * x8);
extern short f557(double x0, float x1, char * x2, long long x3, char * x4, char * x5, float x6, int x7, float x8);
extern void f558(double x0, char * x1, char * x2, int x3, int x4, long long x5, double x6, long long x7, long long x8);
extern long long f559(int x0, int x1, float x2, int x3, double x4, int x5, float x6, int x7);
extern void f560(float x0, double x1, int x2, float x3, char * x4, char * x5, long long x6, int x7);
extern double f561(int x0, float x1, double x2, int x3, float x4, int x5, double x6, double x7, double x8, long long x9, long long x10);
extern void f562(long long x0, long long x1, float x2, double x3, float x4, long long x5);
extern signed char f563(int x0, char * x1);
extern void f564(double x0, float x1, double x2, long long x3, double x4, long long x5, float x6, char * x7, char * x8);
extern void f565(double x0, int x1, int x2, long long x3, char * x4, int x5, double x6, int x7);
extern unsigned char f566(void);
extern void f567(long long x0, char * x1, float x2, double x3, long long x4, char * x5, float x6, float x7, double x8, float x9);
extern int f568(void);
extern signed char f569(float x0);
extern void f570(void);
extern signed char f571(float x0, char * x1, long long x2, char * x3);
extern double f572(float x0, float x1, float x2, float x3, float x4);
extern char * f573(double x0, char * x1, float x2, float x3, double x4, int x5);
extern signed char f574(long long x0, double x1, double x2, int x3, int x4);
extern short f575(int x0, float x1, char * x2, float x3, double x4, int x5, float x6, float x7, long long x8);
extern unsigned short f576(float x0, long long x1, double x2, char * x3, float x4, long long x5, int x6, long long x7, char * x8, float x9);
extern void f577(double x0, int x1, char * x2, double x3, double x4, float x5, float x6, char * x7, float x8, double x9, char * x10);
extern int f578(float x0, long long x1, long long x2, char * x3, long long x4, long long x5, float x6, double x7, int x8, long long x9);
extern char * f579(char * x0, char * x1);
extern void f580(double x0, double x1, int x2, double x3, double x4, double x5, long long x6, float x7, char * x8, long long x9, int x10);
extern void f581(char * x0, double x1, char * x2, float x3, float x4, long long x5, long long x6, float x7, long long x8, char * x9);
extern float f582(float x0, char * x1, double x2, double x3, int x4, char * x5, char * x6, char * x7, int x8);
extern void f583(double x0, char * x1, int x2, long long x3, char * x4, char * x5, int x6);
extern short f584(double x0, int x1, char * x2, char * x3);
extern void f585(char * x0, double x1, long long x2, int x3, long long x4);
extern unsigned char f586(float x0, float x1);
extern float f587(float x0, double x1, int x2, char * x3, int x4, long long x5);
extern unsigned char f588(long long x0, float x1, char * x2, float x3, long long x4, float x5, long long x6, double x7, float x8);
extern void f589(void);
extern void f590(int x0, long long x1, float x2, float x3, double x4, char * x5, int x6, char * x7, double x8);
extern void f591(double x0, char * x1);
extern signed char f592(float x0, long long x1, int x2, double x3, double x4, int x5, float x6, double x7, double x8, char * x9);
extern void f593(int x0, int x1, float x2, float x3, long long x4, float x5, char * x6, long long x7, char * x8);
extern unsigned short f594(char * x0, int x1, char * x2, char * x3);
extern char * f595(int x0, long long x1, float x2, long long x3, long long x4, long long x5);
extern float f596(int x0);
extern short f597(char * x0, int x1, float x2, char * x3, char * x4, float x5, int x6);
extern double f598(float x0, long long x1, float x2, float x3, int x4, double x5, double x6, int x7);
extern void f599(char * x0);
extern int f600(char * x0, double x1, double x2, double x3, char * x4, int x5, double x6);
extern int f601(double x0);
extern long long f602(long long x0, double x1, char * x2);
extern void f603(float x0, double x1, double x2, float x3, long long x4, double x5, float x6, int x7, float x8);
extern void f604(double x0, int x1, int x2);
extern void f605(char * x0, int x1, float x2, double x3, long long x4, char * x5, long long x6, long long x7, long long x8, int x9, long long x10);
extern float f606(float x0, char * x1, long long x2, int x3, double x4, double x5, char * x6, char * x7, long long x8);
extern unsigned short f607(double x0, int x1, float x2, long long x3, float x4, float x5, long long x6, float x7, long long x8);
extern void f608(double x0, double x1, long long x2, char * x3, double x4, int x5);
extern void f609(double x0, long long x1, int x2, double x3, char * x4);
extern void f610(int x0, char * x1, char * x2, long long x3, int x4, float x5, float x6, int x7, double x8);
extern char * f611(float x0, long long x1, double x2, char * x3, long long x4, char * x5);
extern char * f612(double x0, double x1, char * x2, int x3, double x4, long long x5, char * x6);
extern float f613(double x0, double x1, float x2, double x3, char * x4);
extern void f614(int x0, long long x1, long long x2, int x3, char * x4, char * x5, char * x6);
extern long long f615(int x0, double x1, char * x2, long long x3, int x4, char * x5, long long x6, char * x7, char * x8, char * x9);
extern void f616(long long x0, int x1, char * x2, char * x3, long long x4, char * x5, long long x6, int x7);
extern void f617(char * x0, char * x1, long long x2, float x3, float x4, float x5, double x6, int x7);
extern char * f618(double x0, long long x1, char * x2, long long x3);
extern void f619(float x0, int x1, int x2);
extern void f620(long long x0, double x1, char * x2, double x3, long long x4, double x5, double x6, double x7, double x8, long long x9, float x10);
extern void f621(long long x0, long long x1, float x2, long long x3, double x4, long long x5, char * x6, long long x7, char * x8, float x9);
extern void f622(int x0);
extern void f623(float x0, float x1, char * x2, long long x3, int x4, int x5, double x6, double x7);
extern void f624(char * x0, float x1, double x2, long long x3, long long x4, char * x5, float x6);
extern void f625(double x0, float x1, long long x2, double x3, float x4, char * x5, double x6, float x7, char * x8, long long x9);
extern unsigned short f626(double x0, float x1);
extern int f627(int x0, int x1, char * x2, double x3, char * x4, int x5, int x6, char * x7, int x8, float x9, int x10);
extern long long f628(int x0, long long x1, double x2, long long x3, float x4);
extern void f629(long long x0, long long x1, char * x2, float x3, int x4, double x5, double x6, long long x7, int x8);
extern float f630(float x0, int x1, char * x2, int x3, long long x4, double x5, long long x6, int x7);
extern void f631(int x0, char * x1, char * x2, int x3, char * x4, char * x5, int x6, double x7);
extern float f632(long long x0, char * x1, double x2, float x3, float x4, int x5, float x6, int x7, float x8);
extern double f633(double x0, double x1, long long x2, int x3, int x4, char * x5, double x6, double x7, char * x8, long long x9, float x10);
extern void f634(void);
extern void f635(char * x0, float x1, double x2);
extern void f636(long long x0, long long x1, char * x2, double x3, int x4, char * x5, int x6);
extern void f637(int x0, char * x1, int x2);
extern void f638(int x0, float x1);
extern int f639(int x0, char * x1, char * x2, double x3, long long x4, double x5, long long x6, long long x7, char * x8, char * x9);
extern void f640(double x0, long long x1);
extern void f641(long long x0, int x1, char * x2, float x3, long long x4);
extern void f642(float x0);
extern void f643(long long x0, long long x1, long long x2);
extern void f644(char * x0, long long x1, char * x2, int x3);
extern void f645(double x0, double x1, int x2, double x3, char * x4, char * x5, float x6, char * x7);
extern void f646(int x0, int x1, long long x2, long long x3, long long x4, float x5, double x6, int x7);
extern void f647(char * x0);
extern void f648(float x0, double x1);
extern void f649(double x0, long long x1, int x2);
extern long long f650(long long x0, char * x1, char * x2, double x3, long long x4, long long x5, double x6, long long x7, long long x8, long long x9, char * x10);
extern char * f651(char * x0, int x1, int x2, int x3, double x4);
extern char * f652(int x0, long long x1, long long x2, char * x3, double x4);
extern long long f653(long long x0, int x1, char * x2, char * x3);
extern void f654(float x0, float x1, double x2, float x3, char * x4);
extern long long f655(char * x0, float x1, int x2, long long x3, double x4, int x5, long long x6, long long x7, long long x8);
extern float f656(char * x0, float x1, char * x2, long long x3, int x4, long long x5, float x6, double x7, char * x8, long long x9, float x10);
extern void f657(double x0, int x1, float x2, char * x3, long long x4, int x5, long long x6, char * x7, char * x8, int x9, long long x10);
extern unsigned char f658(long long x0, char * x1, int x2, double x3, long long x4);
extern double f659(double x0, char * x1, double x2, double x3, float x4, float x5);
extern unsigned short f660(double x0, double x1, float x2, long long x3);
extern void f661(float x0, double x1, double x2, long long x3);
extern void f662(void);
extern unsigned short f663(char * x0);
extern void f664(int x0, int x1);
extern void f665(double x0, char * x1, float x2, float x3, char * x4, int x5, long long x6, float x7, int x8, char * x9);
extern void f666(double x0, char * x1, long long x2, long long x3, char * x4);
extern void f667(long long x0, float x1);
extern char * f668(float x0, float x1, int x2, char * x3, int x4, double x5, double x6, long long x7, int x8, int x9, char * x10);
extern signed char f669(void);
extern void f670(float x0, float x1, double x2, double x3, long long x4, double x5, float x6, char * x7, double x8, int x9, float x10);
extern void f671(char * x0, long long x1, float x2, char * x3, double x4, double x5);
extern long long f672(char * x0, long long x1, int x2, double x3, char * x4, int x5, float x6, int x7);
extern void f673(char * x0, long long x1, int x2, char * x3, int x4, int x5);
extern long long f674(double x0, char * x1, double x2, double x3, long long x4, int x5);
extern unsigned char f675(double x0, float x1, int x2, int x3, long long x4, char * x5, double x6, long long x7);
extern signed char f676(double x0, long long x1, int x2, char * x3, double x4, double x5, double x6);
extern void f677(double x0, float x1, double x2);
extern void f678(float x0, char * x1, long long x2, double x3, int x4, double x5, float x6);
extern int f679(void);
extern int f680(char * x0, char * x1, double x2, int x3, char * x4, long long x5, char * x6);
extern void f681(long long x0, long long x1, char * x2, double x3, int x4);
extern signed char f682(double x0, float x1, long long x2, float x3, long long x4, float x5, long long x6, char * x7);
extern void f683(char * x0, long long x1, float x2, float x3, double x4, long long x5, double x6, long long x7, float x8, float x9);
extern void f684(float x0, char * x1, float x2, int x3, char * x4, char * x5, int x6, long long x7);
extern void f685(float x0, int x1, float x2, char * x3, char * x4, float x5, double x6, double x7, char * x8, char * x9, float x10);
extern void f686(long long x0, float x1, float x2, int x3, char * x4, long long x5);
extern int f687(int x0, float x1, char * x2, float x3, double x4, char * x5, int x6, int x7);
extern unsigned char f688(char * x0, long long x1, float x2, char * x3, float x4, int x5, float x6, double x7, long long x8, float x9);
extern signed char f689(float x0, int x1, int x2, double x3, long long x4, float x5);
extern int f690(char * x0);
extern void f691(float x0, double x1, double x2);
extern void f692(char * x0, long long x1);
extern float f693(char * x0, int x1, char * x2);
extern void f694(char * x0, char * x1, int x2, double x3, char * x4, float x5);
extern void f695(long long x0, char * x1, long long x2, double x3, double x4, long long x5, int x6, double x7, double x8, int x9);
extern void f696(void);
extern void f697(double x0, double x1, int x2, int x3, int x4, char * x5, long long x6, double x7);
extern void f698(double x0, double x1, long long x2, long long x3, char * x4);
extern long long f699(long long x0, double x1, double x2, char * x3, double x4, float x5, int x6, double x7, long long x8, char * x9, int x10);
extern void f700(char * x0, int x1, long long x2);
extern unsigned short f701(double x0, double x1, float x2);
extern unsigned short f702(long long x0);
extern void f703(char * x0, int x1);
extern void f704(float x0, double x1, float x2, char * x3, float x4, char * x5, float x6, int x7, char * x8);
extern unsigned char f705(double x0, double x1, double x2, char * x3, int x4, long long x5, int x6);
extern void f706(int x0, char * x1, float x2, char * x3);
extern void f707(long long x0, float x1, char * x2, int x3, float x4);
extern void f708(float x0);
extern double f709(void);
extern void f710(int x0, char * x1, long long x2, long long x3, float x4);
extern unsigned short f711(char * x0, float x1, int x2, long long x3, double x4, int x5, long long x6);
extern char * f712(void);
extern float f713(double x0, float x1, float x2, float x3, char * x4, char * x5, long long x6, long long x7, double x8, int x9);
extern char * f714(double x0, int x1, int x2, int x3, char * x4, double x5);
extern float f715(int x0, char * x1, char * x2, long long x3);
extern char * f716(float x0, int x1);
extern int f717(float x0, double x1, int x2, int x3, double x4, long long x5, double x6, char * x7, double x8, int x9);
extern unsigned char f718(int x0, float x1, char * x2, char * x3, char * x4, long long x5, long long x6, int x7);
extern void f719(char * x0);
extern signed char f720(long long x0, float x1, int x2, long long x3, long long x4, float x5);
extern signed char f721(char * x0, long long x1, long long x2, double x3, double x4, char * x5, int x6, int x7);
extern void f722(char * x0, char * x1, long long x2, int x3, int x4, double x5, char * x6, double x7);
extern double f723(char * x0, float x1, int x2);
extern long long f724(double x0, long long x1, char * x2, int x3, float x4);
extern unsigned short f725(char * x0, double x1, char * x2, double x3, int x4);
extern float f726(float x0, double x1, long long x2, char * x3, float x4, float x5);
extern void f727(char * x0, long long x1, char * x2, char * x3, long long x4, char * x5, float x6, int x7, char * x8, long long x9, float x10);
extern void f728(long long x0, double x1, long long x2, float x3, double x4, double x5, double x6, char * x7, long long x8, int x9);
extern void f729(int x0, double x1, double x2, char * x3, long long x4, char * x5);
extern unsigned char f730(long long x0, double x1, int x2, int x3, char * x4, double x5, char * x6, char * x7);
extern int f731(int x0, double x1, char * x2, long long x3, float x4, long long x5, double x6, long long x7, float x8, char * x9);
extern void f732(long long x0, float x1, float x2, char * x3, int x4, float x5, int x6, float x7);
extern int f733(double x0, int x1, char * x2, char * x3, float x4);
extern long long f734(long long x0, char * x1, int x2, int x3, int x4, double x5, double x6, double x7);
extern void f735(void);
extern void f736(double x0, long long x1, int x2, double x3, long long x4, float x5, double x6, int x7);
extern long long f737(double x0);
extern void f738(char * x0, long long x1, char * x2, long long x3);
extern unsigned short f739(float x0, char * x1, long long x2, long long x3, int x4, int x5, long long x6, long long x7, double x8);
extern void f740(double x0, float x1, float x2, double x3, double x4, int x5);
extern void f741(int x0, int x1, float x2, float x3, int x4, double x5, char * x6, char * x7);
extern void f742(char * x0, char * x1, double x2, float x3, int x4, double x5, int x6);
extern void f743(long long x0, double x1, long long x2, float x3, int x4);
extern unsigned char f744(int x0, int x1, float x2, int x3, int x4, double x5, int x6, long long x7, double x8);
extern void f745(double x0, float x1, char * x2, int x3, double x4, float x5, double x6, int x7);
extern float f746(long long x0, char * x1, char * x2, long long x3, char * x4, double x5, int x6, char * x7, char * x8, char * x9);
extern signed char f747(int x0, char * x1, char * x2, float x3);
extern signed char f748(char * x0, float x1, int x2, float x3);
extern void f749(char * x0, long long x1, int x2, char * x3, double x4, int x5, int x6, int x7);
extern void f750(float x0, char * x1, int x2, double x3, float x4);
extern void f751(double x0, char * x1, int x2, double x3, double x4, char * x5);
extern void f752(double x0, float x1, double x2, double x3);
extern double f753(void);
extern void f754(char * x0, int x1, double x2, int x3, float x4);
extern signed char f755(double x0, double x1, int x2, float x3);
extern int f756(int x0, float x1, char * x2, int x3);
extern unsigned char f757(int x0, float x1, char * x2, double x3, long long x4);
extern void f758(double x0, long long x1, float x2, double x3, float x4, float x5, int x6, float x7);
extern void f759(int x0, long long x1, char * x2);
extern signed char f760(float x0, float x1, char * x2, char * x3, float x4, long long x5, char * x6, long long x7);
extern char * f761(double x0, float x1);
extern unsigned char f762(long long x0, double x1, int x2, long long x3, int x4);
extern void f763(int x0, double x1, double x2, float x3, long long x4, long long x5, char * x6);
extern void f764(double x0, float x1, char * x2, char * x3, int x4, long long x5, float x6, int x7, int x8, int x9);
extern void f765(float x0, int x1, float x2, float x3, int x4);
extern void f766(float x0, long long x1, float x2, long long x3, float x4, long long x5, float x6);
extern long long f767(float x0, int x1, float x2, double x3, long long x4, double x5, double x6);
extern signed char f768(long long x0, int x1, long long x2, double x3, double x4);
extern void f769(char * x0, float x1, float x2, long long x3, char * x4, char * x5, long long x6, long long x7);
extern void f770(char * x0, long long x1, float x2, float x3, char * x4, char * x5, float x6);
extern void f771(char * x0, long long x1, long long x2, long long x3, int x4, float x5);
extern short f772(float x0);
extern void f773(long long x0, long long x1, char * x2, char * x3, double x4, int x5, int x6, int x7, double x8, long long x9);
extern short f774(int x0, long long x1, float x2, double x3, float x4, int x5, char * x6, int x7);
extern void f775(float x0, float x1, char * x2);
extern void f776(void);
extern double f777(int x0);
extern float f778(void);
extern unsigned short f779(long long x0);
extern void f780(long long x0, char * x1, int x2, char * x3, double x4, int x5, char * x6, long long x7, float x8);
extern void f781(long long x0, long long x1, char * x2, long long x3, double x4, double x5, long long x6, int x7);
extern int f782(int x0, double x1, double x2);
extern void f783(long long x0, float x1, long long x2, float x3, float x4, double x5, long long x6, char * x7, long long x8, double x9);
extern void f784(long long x0, char * x1, double x2, double x3);
extern float f785(char * x0);
extern double f786(char * x0, int x1);
extern void f787(long long x0, double x1, char * x2, double x3, long long x4, float x5);
extern void f788(char * x0, long long x1, long long x2, float x3, double x4, long long x5, float x6, long long x7, double x8);
extern void f789(void);
extern int f790(int x0, char * x1, double x2, double x3, double x4, int x5, int x6, float x7, double x8, char * x9);
extern float f791(double x0, float x1, float x2, int x3, double x4, char * x5, long long x6, double x7, int x8, float x9);
extern float f792(void);
extern char * f793(double x0);
extern long long f794(double x0, float x1);
extern void f795(long long x0, long long x1, char * x2);
extern void f796(int x0, double x1);
extern void f797(float x0, char * x1, long long x2, int x3);
extern void f798(long long x0, int x1, float x2, double x3, float x4, char * x5, double x6, int x7, char * x8);
extern float f799(int x0, float x1);
extern void f800(long long x0, float x1, double x2);
extern unsigned short f801(void);
extern void f802(float x0, long long x1, int x2, int x3, char * x4, char * x5, int x6, double x7);
extern void f803(void);
extern void f804(int x0, int x1, int x2, char * x3, int x4);
extern void f805(void);
extern long long f806(float x0, int x1, float x2, int x3, double x4, float x5, float x6);
extern unsigned char f807(char * x0, int x1, char * x2, long long x3, char * x4, long long x5, long long x6, int x7, char * x8, double x9, long long x10);
extern void f808(double x0, long long x1, float x2, float x3, char * x4, int x5, double x6, float x7, float x8, int x9);
extern void f809(char * x0, char * x1, long long x2, double x3, float x4, float x5);
extern float f810(double x0, float x1, double x2, int x3);
extern unsigned char f811(void);
extern char * f812(long long x0, long long x1, float x2, double x3, int x4, float x5);
extern unsigned char f813(long long x0, int x1, int x2, long long x3, char * x4, char * x5, char * x6, double x7, float x8, char * x9, char * x10);
extern signed char f814(long long x0, double x1, double x2, char * x3, double x4, float x5, float x6, char * x7, double x8);
extern char * f815(double x0, int x1, int x2, long long x3, float x4, int x5, char * x6);
extern void f816(char * x0);
extern short f817(double x0, float x1);
extern void f818(float x0, int x1, char * x2, char * x3, char * x4, double x5);
extern short f819(int x0, long long x1, int x2, float x3);
extern void f820(char * x0, float x1, long long x2, char * x3, int x4, long long x5, double x6);
extern void f821(double x0, char * x1, int x2, long long x3);
extern void f822(float x0);
extern void f823(float x0, int x1, double x2, char * x3, int x4, char * x5);
extern void f824(long long x0);
extern unsigned short f825(char * x0);
extern void f826(float x0, long long x1, float x2, long long x3);
extern void f827(double x0, int x1, float x2, long long x3, float x4);
extern void f828(double x0, int x1, char * x2, double x3, float x4, char * x5);
extern void f829(float x0, char * x1, long long x2, long long x3, int x4, int x5, long long x6, int x7, double x8);
extern unsigned short f830(float x0, char * x1, char * x2, char * x3, int x4, long long x5, double x6, char * x7);
extern void f831(float x0, char * x1, long long x2, long long x3, long long x4, char * x5, float x6, int x7, double x8, float x9);
extern void f832(long long x0, long long x1, double x2, long long x3, float x4, long long x5);
extern void f833(long long x0, long long x1, char * x2, double x3);
extern void f834(double x0, long long x1, double x2, long long x3, float x4, double x5, float x6, int x7, float x8);
extern signed char f835(int x0, long long x1);
extern long long f836(char * x0, int x1, double x2, char * x3, int x4, int x5, long long x6, int x7);
extern double f837(double x0, long long x1, long long x2, long long x3, double x4, long long x5, double x6, double x7);
extern signed char f838(double x0, char * x1, int x2, double x3, char * x4, float x5, char * x6);
extern void f839(void);
extern void f840(double x0, double x1, float x2, float x3, float x4, int x5);
extern void f841(char * x0, double x1, float x2, float x3, int x4, int x5, int x6, char * x7, int x8, long long x9, float x10);
extern short f842(double x0, char * x1, double x2, double x3, int x4, float x5, long long x6, long long x7);
extern void f843(char * x0, long long x1, int x2, float x3);
extern unsigned short f844(double x0, long long x1, char * x2, float x3, int x4, long long x5, int x6, double x7, float x8);
extern signed char f845(double x0, int x1, double x2);
extern void f846(void);
extern void f847(double x0, char * x1, int x2);
extern void f848(int x0, char * x1, int x2, double x3, int x4, char * x5, double x6, long long x7, int x8, double x9, int x10);
extern unsigned short f849(char * x0, double x1, char * x2, long long x3, double x4, char * x5);
extern double f850(float x0, int x1, int x2);
extern float f851(char * x0);
extern unsigned char f852(char * x0, double x1);
extern int f853(int x0, int x1, float x2, int x3, float x4, long long x5, long long x6, double x7, double x8, int x9);
extern void f854(int x0, int x1, double x2);
extern void f855(float x0, double x1);
extern double f856(int x0, char * x1, long long x2, float x3);
extern short f857(long long x0, long long x1, int x2, int x3, double x4, char * x5, double x6, char * x7, long long x8);
extern void f858(int x0, float x1, double x2, float x3, long long x4, float x5, char * x6, char * x7, long long x8, float x9, int x10);
extern char * f859(double x0);
extern signed char f860(long long x0, float x1, float x2, float x3, double x4, double x5, float x6, int x7);
extern void f861(int x0, float x1);
extern void f862(long long x0, long long x1, float x2, float x3, float x4, int x5, long long x6);
extern unsigned char f863(double x0, float x1);
extern void f864(void);
extern void f865(int x0, int x1);
extern void f866(char * x0, int x1, float x2, long long x3, int x4, char * x5, float x6, int x7, float x8, float x9);
extern void f867(char * x0, double x1, float x2, long long x3);
extern void f868(char * x0);
extern void f869(char * x0, double x1, char * x2, int x3, char * x4, double x5, char * x6, int x7, long long x8);
extern int f870(char * x0, double x1, long long x2, int x3);
extern void f871(long long x0);
extern void f872(float x0, char * x1, float x2, float x3, int x4);
extern void f873(char * x0, char * x1, long long x2, double x3, char * x4, int x5, int x6, float x7, char * x8, char * x9);
extern int f874(char * x0, char * x1, double x2);
extern int f875(long long x0, int x1, int x2, char * x3, float x4, char * x5, float x6);
extern int f876(char * x0, long long x1);
extern short f877(double x0, float x1, long long x2, long long x3, double x4, char * x5, long long x6, char * x7, long long x8, double x9);
extern void f878(float x0, double x1, int x2, double x3, int x4, long long x5);
extern void f879(char * x0, char * x1, float x2, int x3, long long x4);
extern void f880(double x0, char * x1, int x2, char * x3);
extern void f881(void);
extern int f882(float x0);
extern void f883(double x0, long long x1);
extern void f884(long long x0, char * x1);
extern void f885(float x0);
extern unsigned char f886(int x0, char * x1, long long x2, long long x3, float x4, long long x5, float x6, double x7, float x8, int x9);
extern void f887(void);
extern float f888(double x0, char * x1, long long x2, long long x3, long long x4, int x5, long long x6);
extern long long f889(float x0, long long x1, double x2, long long x3, long long x4, double x5, int x6, double x7, double x8, float x9, int x10);
extern void f890(char * x0);
extern void f891(double x0, int x1, float x2, long long x3, float x4);
extern char * f892(long long x0, int x1, long long x2, float x3, int x4, int x5, double x6);
extern char * f893(float x0, long long x1, float x2, int x3);
extern unsigned short f894(long long x0, int x1, long long x2);
extern void f895(int x0, double x1, long long x2, long long x3, float x4, int x5, double x6, double x7, float x8, double x9, int x10);
extern void f896(long long x0, float x1, long long x2, double x3, char * x4, float x5);
extern void f897(char * x0, float x1, int x2, long long x3, double x4, int x5);
extern int f898(char * x0, char * x1);
extern char * f899(int x0, long long x1);
extern void f900(float x0);
extern void f901(int x0, float x1, char * x2, char * x3, double x4, double x5, long long x6, float x7, int x8, int x9);
extern void f902(void);
extern signed char f903(float x0, float x1, char * x2);
extern void f904(float x0, double x1, char * x2, float x3, double x4, double x5);
extern int f905(long long x0, float x1, char * x2, double x3, double x4, double x5, int x6);
extern void f906(double x0, float x1, char * x2, float x3, int x4, char * x5, double x6);
extern float f907(double x0, double x1, char * x2, float x3, double x4, double x5, long long x6, long long x7);
extern void f908(char * x0, char * x1);
extern short f909(int x0);
extern void f910(char * x0);
extern long long f911(long long x0, int x1, long long x2, float x3, char * x4, int x5, int x6);
extern void f912(int x0, char * x1, int x2);
extern void f913(int x0, double x1);
extern void f914(float x0, double x1);
extern void f915(float x0, long long x1, int x2, long long x3, long long x4);
extern short f916(char * x0, double x1, long long x2);
extern int f917(char * x0, float x1, int x2);
extern void f918(long long x0, int x1, float x2, double x3, int x4, long long x5, float x6);
extern int f919(char * x0, float x1, double x2, double x3, float x4, char * x5, long long x6, char * x7, char * x8, double x9, long long x10);
extern void f920(long long x0, int x1, char * x2, float x3, double x4, float x5, int x6, int x7, double x8, int x9);
# 6 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c" 2

int failed = 0;

void call_f1(void)
{
  unsigned char r = f1();
  ((r == 52) ? (void)0 : failure("r == 52","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",12,__func__));
}

void call_f2(void)
{
  signed char r = f2();
  ((r == -46) ? (void)0 : failure("r == -46","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",18,__func__));
}

void call_f3(void)
{
  unsigned short r = f3();
  ((r == 21994) ? (void)0 : failure("r == 21994","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",24,__func__));
}

void call_f4(void)
{
  short r = f4();
  ((r == 26044) ? (void)0 : failure("r == 26044","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",30,__func__));
}

void call_f5(void)
{
  int r = f5();
  ((r == 1815701022) ? (void)0 : failure("r == 1815701022","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",36,__func__));
}

void call_f6(void)
{
  long long r = f6();
  ((r == 6091190040057659072) ? (void)0 : failure("r == 6091190040057659072","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",42,__func__));
}

void call_f7(void)
{
  float r = f7();
  ((r == -0x1.505a24p+4F) ? (void)0 : failure("r == -0x1.505a24p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",48,__func__));
}

void call_f8(void)
{
  double r = f8();
  ((r == 0x1.8bdf6347217p+4) ? (void)0 : failure("r == 0x1.8bdf6347217p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",54,__func__));
}

void call_f9(void)
{
  char * r = f9();
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",60,__func__));
}

void call_f10(void)
{
  f10(-332189767);
}

void call_f11(void)
{
  f11(337229694);
}

void call_f12(void)
{
  f12(317650142);
}

void call_f13(void)
{
  f13(-460084415);
}

void call_f14(void)
{
  f14(80612187);
}

void call_f15(void)
{
  f15(7019629353647716597);
}

void call_f16(void)
{
  f16(-0x1.6d963a576545p+3);
}

void call_f17(void)
{
  f17(-0x1.276eef6957e28p+4);
}

void call_f18(void)
{
  f18("");
}

void call_f19(void)
{
  f19(-1890349277, -897103018);
}

void call_f20(void)
{
  f20(512557790, 2810507307273687296);
}

void call_f21(void)
{
  f21(893301306, -0x1.5a88d9cb03d4ep+5);
}

void call_f22(void)
{
  f22(1076806509, -0x1.66b1425c8106ap+5);
}

void call_f23(void)
{
  f23(-215848110264998716, 986535705);
}

void call_f24(void)
{
  f24(8927202270820107824, 2486169674628109617);
}

void call_f25(void)
{
  f25(-3105154652647668272, 0x1.5861f8a4f9cfep+5);
}

void call_f26(void)
{
  f26(-636674504077813734, -0x1.ebd6f2e8c1b32p+4);
}

void call_f27(void)
{
  f27(-0x1.257778e9768e8p+5, -2123243015);
}

void call_f28(void)
{
  f28(0x1.222219f6a931p+5, -3617192151061228944);
}

void call_f29(void)
{
  f29(-0x1.eeb6b2b291ef3p+4, 0x1.56b9f82575818p+4);
}

void call_f30(void)
{
  f30(-0x1.1bf5908bc2b2p+5, 0x1.7fac25ed81fap+0);
}

void call_f31(void)
{
  f31(0x1.eb2f1b04ce814p+4, 1578492036);
}

void call_f32(void)
{
  f32(0x1.c680bbf7506e8p+4, -1895641904108992969);
}

void call_f33(void)
{
  f33(-0x1.6070d3ba43266p+4, -0x1.657e7ae346456p+4);
}

void call_f34(void)
{
  f34(0x1.74a4ec30c5bcep+5, 0x1.3a13dc3c291b8p+5);
}

void call_f35(void)
{
  f35(1788482215, -1058592089, 808710687);
}

void call_f36(void)
{
  f36(-1971247106, 934813025, 814031241209297937);
}

void call_f37(void)
{
  f37(-525776440, 117078430, -0x1.1b8b50730db52p+4);
}

void call_f38(void)
{
  f38(1516512386, -591211632, -0x1.3c51c26d3cfd8p+4);
}

void call_f39(void)
{
  f39(149499974, 6719677545270994646, 338900670);
}

void call_f40(void)
{
  f40(857904947, -5849439672846215929, -280852419404875281);
}

void call_f41(void)
{
  f41(1755375163, -6727825898062551208, -0x1.650bab5cac663p+5);
}

void call_f42(void)
{
  f42(1285894652, -4299976464738093729, 0x1.ca33868e8eap-3);
}

void call_f43(void)
{
  f43(-615122764, -0x1.b9937e734fb43p+4, 654724921);
}

void call_f44(void)
{
  f44(1535564766, 0x1.07e963677f3a8p+5, -3414950968713114912);
}

void call_f45(void)
{
  f45(1060027508, -0x1.1eee981ea9d4cp+3, 0x1.5124c2bc1a7f8p+2);
}

void call_f46(void)
{
  f46(-1977467423, -0x1.f8359f89660f6p+4, 0x1.dcd9cfff277a8p+3);
}

void call_f47(void)
{
  f47(-436264035, -0x1.655a9463c2934p+4, 590384845);
}

void call_f48(void)
{
  f48(797519720, -0x1.7d995dad1b01ap+5, -2840591129732420102);
}

void call_f49(void)
{
  f49(1327314810, 0x1.7146df38c8d0ep+5, 0x1.88e29094e9086p+5);
}

void call_f50(void)
{
  f50(-2105695283, -0x1.cc7517d56db6p+1, 0x1.906b12247d51p+4);
}

void call_f51(void)
{
  f51(3953027608139137348, -2141769635, 995364460);
}

void call_f52(void)
{
  f52(3036348530111388172, -1771018351, -5508074385608576975);
}

void call_f53(void)
{
  f53(1300353776637137055, 614859284, 0x1.4a7891ec493fap+5);
}

void call_f54(void)
{
  f54(8330435943610353924, -1607422026, 0x1.75b0578c78b96p+5);
}

void call_f55(void)
{
  f55(4900083008501218242, -8283899911481238379, 1723296699);
}

void call_f56(void)
{
  f56(-5749845212926708381, -5466138798496885377, 7446334089332560726);
}

void call_f57(void)
{
  f57(5534830060667247037, -7365380488276470379, -0x1.bc7604599276p+4);
}

void call_f58(void)
{
  f58(-7625728545207071330, -4857091745999202794, -0x1.0247b2c2fdd32p+5);
}

void call_f59(void)
{
  f59(-6373447992649167439, 0x1.449de55150304p+5, 2031799300);
}

void call_f60(void)
{
  f60(-7667834668602802102, 0x1.f5858107b041p+4, -3503088096956866809);
}

void call_f61(void)
{
  f61(30207952216662734, -0x1.3461d2ebc85e9p+5, -0x1.f279a1a25389cp+3);
}

void call_f62(void)
{
  f62(-7809997096130159372, 0x1.1cd56b5d77608p+5, 0x1.613098b9e68cp+1);
}

void call_f63(void)
{
  f63(-4788194311407302990, 0x1.390233be9b4acp+5, -1198195661);
}

void call_f64(void)
{
  f64(8475040464703966319, 0x1.2bdec1115d22p+0, 6941207221076541935);
}

void call_f65(void)
{
  f65(-213971547767150030, -0x1.c32b9d44f36e1p+4, -0x1.13702def4b8f6p+5);
}

void call_f66(void)
{
  f66(-5399524384024240867, 0x1.00a54db609c88p+5, -0x1.0caac92d227eap+5);
}

void call_f67(void)
{
  f67(-0x1.aa788aa88b378p+2, -280070486, -1634511699);
}

void call_f68(void)
{
  f68(0x1.892ee46c07476p+5, -1871219255, -6922425297852985686);
}

void call_f69(void)
{
  f69(-0x1.0150a5f11ab08p+3, 200873844, -0x1.1117646d9d841p+5);
}

void call_f70(void)
{
  f70(-0x1.b367dfdbc0f9ep+4, 1603840508, -0x1.37e73734da6b1p+5);
}

void call_f71(void)
{
  f71(0x1.fb6189aa1b36cp+4, -1196998339766994623, 1329830455);
}

void call_f72(void)
{
  f72(0x1.3edfdfe3bee78p+2, -3765815135498981049, -485628630304223850);
}

void call_f73(void)
{
  f73(0x1.47d3bff29f82ep+5, -6618604561373503371, -0x1.246b1c2c3d3fp+2);
}

void call_f74(void)
{
  f74(-0x1.4dc4dc576e344p+4, 2238207705307226773, 0x1.a4a94e4749704p+4);
}

void call_f75(void)
{
  f75(0x1.c77e1e0865d38p+4, 0x1.c42af4dbc2f88p+2, -926654137);
}

void call_f76(void)
{
  f76(0x1.f8a5108fc64bp+3, -0x1.83ffaf7d20105p+5, -6453396190629267522);
}

void call_f77(void)
{
  f77(0x1.e617159111c6p+3, -0x1.33261b085349p+1, -0x1.f8d426489d68p+1);
}

void call_f78(void)
{
  f78(-0x1.b1672a89c7b1p+4, 0x1.34f60e08c669p+2, -0x1.d185321899918p+3);
}

void call_f79(void)
{
  f79(-0x1.20b989c7f64d2p+4, 0x1.30b623d07b094p+5, -901231670);
}

void call_f80(void)
{
  f80(-0x1.7d73e9a31bb89p+5, -0x1.2f9ea63c8fc4p+5, -7066645457789567189);
}

void call_f81(void)
{
  f81(0x1.ee05e3df4ad08p+4, -0x1.226e0b63d6222p+5, 0x1.fac5d7867894p+1);
}

void call_f82(void)
{
  f82(-0x1.ed260b6cfbbfdp+4, 0x1.58403a407323ap+5, 0x1.93209fc07e1e8p+4);
}

void call_f83(void)
{
  f83(-0x1.07a2072572e6ep+5, 1374121009, 1643292383);
}

void call_f84(void)
{
  f84(0x1.36ebf4e14f56cp+3, -139571278, 6959212005104681673);
}

void call_f85(void)
{
  f85(0x1.603d4384a88p+3, -556428407, 0x1.1e6cf41d804acp+5);
}

void call_f86(void)
{
  f86(0x1.eb6b9b6196fecp+4, 1775849037, 0x1.ad8f25ea550cp-1);
}

void call_f87(void)
{
  f87(0x1.6fa041285f51cp+5, -2446134964275251616, 819952374);
}

void call_f88(void)
{
  f88(-0x1.60b0d11dc6fdcp+4, 7922390524902826388, 7139162357569542102);
}

void call_f89(void)
{
  f89(0x1.416d8622bb108p+4, -7308682386173680917, -0x1.5c5b771935e4dp+5);
}

void call_f90(void)
{
  f90(-0x1.2040f1c292bffp+5, -3902206868610871742, 0x1.5c04f6a7c2a8p+0);
}

void call_f91(void)
{
  f91(0x1.69fc837a8f958p+5, -0x1.c5b9253dfcd98p+3, -1514800662);
}

void call_f92(void)
{
  f92(-0x1.0087d4b26222ap+4, -0x1.83300d2afadc1p+4, -3685631349062350180);
}

void call_f93(void)
{
  f93(-0x1.df67c4ddd676p+1, -0x1.89118a1fe26bp+3, -0x1.3e6d189e3982p+4);
}

void call_f94(void)
{
  f94(-0x1.4c8af547dd585p+5, 0x1.4e5f19dee8188p+2, 0x1.ad28705fd81b8p+2);
}

void call_f95(void)
{
  f95(0x1.5b25a9546754cp+3, 0x1.979961b0bed1p+3, 781496805);
}

void call_f96(void)
{
  f96(0x1.59cc0836f5604p+4, 0x1.b8e539e4752bp+3, -621643334193414469);
}

void call_f97(void)
{
  f97(0x1.5373e1bee7b28p+2, -0x1.40f37acba7bbfp+5, -0x1.3f26c85a65a71p+4);
}

void call_f98(void)
{
  f98(0x1.394781ae4ed6p+1, -0x1.74fecca573fc8p+2, -0x1.7bbbf2817c08p+2);
}

void call_f99(void)
{
  f99(-322448375, 1816391595, 1172446457, 1899158975);
}

void call_f100(void)
{
  f100(98119346, 507334429, 82599028, -6009762168677869894);
}

void call_f101(void)
{
  f101(-1978637512, 1455296549, 568895837, 0x1.48b441d48292p+2);
}

void call_f102(void)
{
  f102(-651180200, -1975511877, -2052200599, -0x1.68a228830cbd8p+4);
}

void call_f103(void)
{
  f103(-312068493, -246675193, 2141993738737130324, 72756087);
}

void call_f104(void)
{
  f104(608875078, -1014960308, 5469853127711791298, 2923892079632150092);
}

void call_f105(void)
{
  f105(1884396082, 1525664605, -6103882318065480829, 0x1.334f39a967082p+5);
}

void call_f106(void)
{
  f106(-808807889, -2114261717, 7415999042694616475, -0x1.d7ed9f1228ed5p+4);
}

void call_f107(void)
{
  f107(1899025601, 146223365, 0x1.8440c965bbb34p+5, -1700808239);
}

void call_f108(void)
{
  f108(1310430298, 2071906495, 0x1.2a9b9363f69fp+4, 1538580925615931364);
}

void call_f109(void)
{
  f109(-380871711, 378020710, -0x1.8b3892ccd1e95p+5, 0x1.bdcb906e9d954p+4);
}

void call_f110(void)
{
  f110(-661347653, 381536239, -0x1.8056409669257p+4, 0x1.4b6fcc51c618p+0);
}

void call_f111(void)
{
  f111(-424158974, 1595726497, -0x1.073766362cebbp+5, -385130582);
}

void call_f112(void)
{
  f112(-1465293271, -989101768, -0x1.7cf585221bbfcp+5, -3945429839753295604);
}

void call_f113(void)
{
  f113(842257082, -1718439071, -0x1.227e596f2110ap+5, 0x1.004caa34195d8p+5);
}

void call_f114(void)
{
  f114(2076605536, 428726999, -0x1.5e16d64e3e9dp+5, -0x1.84d5009ed695p+1);
}

void call_f115(void)
{
  f115(-338582341, -2630769608351727663, -1792750286, -1410230378);
}

void call_f116(void)
{
  f116(1165794898, -864395359444466897, -1289446421, 8990493608382882555);
}

void call_f117(void)
{
  f117(-1738047084, -85604440416876734, -1615956318, 0x1.09215a7850c92p+5);
}

void call_f118(void)
{
  f118(2112187802, 783618840737200756, -913217938, 0x1.295b999dd680cp+4);
}

void call_f119(void)
{
  f119(-46331081, -904698155544514642, -3966137881959615395, 665165669);
}

void call_f120(void)
{
  f120(-287763021, -36040568405750800, -7780422812546641203, -4404512927516861989);
}

void call_f121(void)
{
  f121(1060118322, -2582310199054981422, 9064621368939513022, 0x1.5ce257334a88p+5);
}

void call_f122(void)
{
  f122(-867156108, 1626769021412313309, 2455008444113696245, 0x1.217eff006f498p+2);
}

void call_f123(void)
{
  f123(1912031218, -4572503679388489139, -0x1.c219c2a6fa809p+4, -1317759643);
}

void call_f124(void)
{
  f124(911882661, -2143479123364987124, 0x1.4db9b0c9db11cp+5, 3548237201410061436);
}

void call_f125(void)
{
  f125(-1614876653, 2024382277320690743, -0x1.614402b192af8p+5, -0x1.4180fc66f1784p+5);
}

void call_f126(void)
{
  f126(-1817190970, 596821572915558576, -0x1.345574cd53158p+2, 0x1.8d12ea069196p+4);
}

void call_f127(void)
{
  f127(-201762310, 1627288124458155545, -0x1.1968c11ca463cp+4, -71701707);
}

void call_f128(void)
{
  f128(2106265504, 1256749851627290211, 0x1.a927eaad453d8p+3, -1077422321008948614);
}

void call_f129(void)
{
  f129(-846536731, -8312999434302404611, 0x1.bd2128998c488p+2, 0x1.79b21e2ca6dep+2);
}

void call_f130(void)
{
  f130(130815322, 1059789740292793093, -0x1.62a7d285f598p+1, 0x1.3cb96ce6baaccp+4);
}

void call_f131(void)
{
  f131(1745179863, 0x1.2457513824674p+5, -383580114, -268769072);
}

void call_f132(void)
{
  f132(-483914150, 0x1.21d2808d590cap+5, 1839226646, 8743674007445272811);
}

void call_f133(void)
{
  f133(796189844, -0x1.81647bb6eaef8p+3, -1060167129, -0x1.cb029a0898ab6p+4);
}

void call_f134(void)
{
  f134(444288557, -0x1.a701c3000633p+2, -1301364964, -0x1.8ed30e5bf3c24p+4);
}

void call_f135(void)
{
  f135(1101278177, 0x1.340a128eaf088p+4, 5719978539181324563, -497898371);
}

void call_f136(void)
{
  f136(-926668119, 0x1.2de5856cfe2e6p+5, -3073456533012926684, 5605733868509837398);
}

void call_f137(void)
{
  f137(-212804632, -0x1.1818010f92e2dp+5, -1031689432387615567, 0x1.506d3f537276p+5);
}

void call_f138(void)
{
  f138(-910960455, 0x1.2ad880962da54p+5, 1625189149833360736, -0x1.6090e0de7ca6p+4);
}

void call_f139(void)
{
  f139(1665708908, 0x1.7da7b4e5a5928p+3, 0x1.7e64f00af729p+4, 2037586676);
}

void call_f140(void)
{
  f140(2060249988, -0x1.6670a18344cfcp+4, 0x1.2d53fedb5e7bcp+5, 7542536437981289980);
}

void call_f141(void)
{
  f141(1534795160, -0x1.d8169745d588p+1, 0x1.53468e56a9c94p+5, 0x1.07eb594a69418p+5);
}

void call_f142(void)
{
  f142(1105706173, -0x1.49dbbd67a17a8p+3, -0x1.1262ec08c024bp+5, 0x1.346935990ea0cp+5);
}

void call_f143(void)
{
  f143(1374387195, 0x1.ae05f06d853bcp+4, 0x1.3f231c6443c38p+4, -2073781890);
}

void call_f144(void)
{
  f144(-664509735, 0x1.d3e3008d5e254p+4, -0x1.12070fdffa2bp+1, -7034156418254800441);
}

void call_f145(void)
{
  f145(937102785, 0x1.8ec73b6ba6744p+3, -0x1.70dc342d2fc07p+4, -0x1.775892a7cf36p+3);
}

void call_f146(void)
{
  f146(-90690405, -0x1.8c1eb17c835acp+5, -0x1.669f89c371c7fp+4, 0x1.876593d53775cp+5);
}

void call_f147(void)
{
  f147(1673201646, 0x1.be7747852e638p+4, 1739929451, -203456402);
}

void call_f148(void)
{
  f148(-1873091828, -0x1.376789a35766p+3, -1365003906, 7118220047331332052);
}

void call_f149(void)
{
  f149(735055145, 0x1.2ce8615d7a508p+3, 473819009, -0x1.45d4a9ae55716p+4);
}

void call_f150(void)
{
  f150(1390966206, -0x1.fe0ba56fd4ed8p+2, -1747689767, 0x1.7a668865f958p+5);
}

void call_f151(void)
{
  f151(-237130372, -0x1.19ddff71df142p+4, 1283735415415508498, -1625455909);
}

void call_f152(void)
{
  f152(-1923255536, -0x1.613024530b7f7p+4, -6840535465861408322, 1792107979885872966);
}

void call_f153(void)
{
  f153(-624263162, 0x1.6a84d912b2ddap+5, -4078244858251663330, 0x1.0a404ee0abe3cp+4);
}

void call_f154(void)
{
  f154(-162740179, -0x1.c7a3f7900957ap+4, -8568708503769201122, 0x1.9c8213d2c338cp+3);
}

void call_f155(void)
{
  f155(-1837793097, 0x1.53012588e709cp+4, 0x1.2728a877eb524p+3, 1071652809);
}

void call_f156(void)
{
  f156(1591089178, 0x1.17e01308a3f9p+5, -0x1.ee6d99751a654p+3, -2826695336034194688);
}

void call_f157(void)
{
  f157(453509759, -0x1.6ccc12a200c6ap+4, 0x1.3536940b60c4ap+5, -0x1.9296876cf3d81p+4);
}

void call_f158(void)
{
  f158(2017027596, -0x1.e35ad3ba3e478p+3, 0x1.46887322ab0e6p+5, -0x1.cf59a532f72bp+3);
}

void call_f159(void)
{
  f159(-1937671308, -0x1.24d2e7a65c48cp+3, -0x1.0aacc86d4fc3p+3, -606700687);
}

void call_f160(void)
{
  f160(335577148, -0x1.30f764002244p+2, -0x1.b2d188edb9ad3p+4, 7076110651949465664);
}

void call_f161(void)
{
  f161(-1245721025, 0x1.016a1e3821294p+5, 0x1.a7593a9f8a584p+3, 0x1.aebad22d98d1p+3);
}

void call_f162(void)
{
  f162(1188993099, 0x1.0d66353212372p+5, 0x1.5ba0e316efedcp+3, -0x1.955e7c386a60cp+4);
}

void call_f163(void)
{
  f163(2474665750640503866, -24095825, 296626979, -1161208501);
}

void call_f164(void)
{
  f164(8210216938284524825, 414389322, -267673914, -7517838470881635308);
}

void call_f165(void)
{
  f165(6425215932790822163, -534277605, 1003073253, -0x1.ceb14cf5795fcp+3);
}

void call_f166(void)
{
  f166(-5927925312940601998, 628237630, 1086877091, -0x1.7722fc9edae58p+4);
}

void call_f167(void)
{
  f167(6194051204194735608, 270143733, -8771181705065488441, -1733757743);
}

void call_f168(void)
{
  f168(-7394088360375319255, -1598016759, -5765134792816289955, -1059978567058580180);
}

void call_f169(void)
{
  f169(-1135028986226457612, 1299291473, 5045137928792744157, -0x1.5a71df297e3b8p+5);
}

void call_f170(void)
{
  f170(-5356947645683780394, 784803821, 5639154692196298557, 0x1.712e62ea80988p+5);
}

void call_f171(void)
{
  f171(4619499530537415713, 931083944, 0x1.1e4f44c06bf48p+5, 62197542);
}

void call_f172(void)
{
  f172(-5140431636941389006, -483271256, 0x1.0822d199b2924p+3, 6848517763051598298);
}

void call_f173(void)
{
  f173(-1776471520477350974, -78632525, -0x1.23e8fe6378c8cp+4, -0x1.b4f176a5aef6cp+4);
}

void call_f174(void)
{
  f174(7143457754911430280, -1514471935, 0x1.4cd09b7bb24a2p+5, 0x1.dd9df213308d8p+3);
}

void call_f175(void)
{
  f175(7924144403258977405, -88749194, 0x1.0bf6597e3c1cp+2, -92681161);
}

void call_f176(void)
{
  f176(-189270690806015766, 1018789696, -0x1.22a5acdc7b9a4p+3, 5635761901457819553);
}

void call_f177(void)
{
  f177(-2089367899785157934, 1964623228, -0x1.0ae03a8643801p+5, 0x1.7123526617e28p+5);
}

void call_f178(void)
{
  f178(5018298447023272899, -13904451, -0x1.d06a263de4f8p+1, 0x1.abd7230e6fec8p+4);
}

void call_f179(void)
{
  f179(-4524041912124751857, -3732466241092453629, 989435626, 549881158);
}

void call_f180(void)
{
  f180(2132055560661992546, 1710333324441136959, 514272135, -4566140067892512355);
}

void call_f181(void)
{
  f181(7349587223912297324, -6561221886651031065, -752100927, 0x1.32afb485f5b1ap+5);
}

void call_f182(void)
{
  f182(-6425966247333911797, 3056217142423634625, 117301956, -0x1.c7ac8ef3d674p+0);
}

void call_f183(void)
{
  f183(8840797654394725908, -2945829585958613399, -6514553790185563787, 1896203899);
}

void call_f184(void)
{
  f184(-5496854366073140891, -708970260535385601, 8142108096765520357, 1924514459175043616);
}

void call_f185(void)
{
  f185(1420819174330059291, -1531404222641262800, -8582259010771462001, -0x1.f82f5c1a44365p+4);
}

void call_f186(void)
{
  f186(-2795071645367813907, 6643095038812751695, 637146520515759251, -0x1.6d7bdc3c8c91p+3);
}

void call_f187(void)
{
  f187(-3676171997269981938, 5433717702196276409, 0x1.bd9807d9de338p+4, 145098420);
}

void call_f188(void)
{
  f188(194012314009349454, 43377275207605189, -0x1.f9df2af1bc94p+2, 4855459320429112240);
}

void call_f189(void)
{
  f189(-883639779349024358, -752315393760978757, 0x1.6cf26de186974p+5, 0x1.4440c2a0a7c8cp+4);
}

void call_f190(void)
{
  f190(939683952992824707, 245696838050477027, -0x1.9c18bb86ad99cp+3, 0x1.31efc03bd707cp+4);
}

void call_f191(void)
{
  f191(-2539170432973974895, 3012913133546673330, -0x1.fb52559365006p+4, 1222701288);
}

void call_f192(void)
{
  f192(-9149387000798893990, -77817178297243455, -0x1.3c96f9e95b5ccp+3, 4207419177394277271);
}

void call_f193(void)
{
  f193(748324998831911987, -6477819882023706310, -0x1.23b353670682p+3, 0x1.162681607e65cp+4);
}

void call_f194(void)
{
  f194(-5672005499270099794, -7167221097260429852, -0x1.12faa40965a88p+5, 0x1.3d6f6f50d078p+4);
}

void call_f195(void)
{
  f195(5788075870483906937, 0x1.85cd8f3f3eebp+2, 1888701279, -126389512);
}

void call_f196(void)
{
  f196(7521446059299352769, -0x1.8c0ba8f7eeee7p+4, -881533844, -8428627804086955897);
}

void call_f197(void)
{
  f197(3249004910838190703, -0x1.1771bbeddd4c2p+4, -1237381754, 0x1.1e6cd4f08b99p+5);
}

void call_f198(void)
{
  f198(-2592375470943099027, 0x1.2f42cd51f68ep+4, 1642647504, 0x1.89a4f29a63e84p+3);
}

void call_f199(void)
{
  f199(1162893838056953721, 0x1.528c049934ap-2, -5830996756752973596, 278450333);
}

void call_f200(void)
{
  f200(4198862099332348442, 0x1.9424561569d48p+3, 4517141222267356958, -1305160193941866601);
}

void call_f201(void)
{
  f201(8819488965052416004, -0x1.ae76a7323e673p+4, 4445158690331229468, -0x1.3b7491432d0b6p+5);
}

void call_f202(void)
{
  f202(5904270852355322850, -0x1.ebc7ef9cc49e4p+4, 1187097452459844604, 0x1.0f32ab867e734p+3);
}

void call_f203(void)
{
  f203(3908326628027877303, -0x1.9142a7e33e3ap+0, 0x1.0f262705a15e4p+4, -1906983232);
}

void call_f204(void)
{
  f204(-8865300970792611673, -0x1.e5048f9d20188p+3, -0x1.a09fc4d83ccb6p+4, 5616242733852469262);
}

void call_f205(void)
{
  f205(-6862076601267372338, 0x1.43382facc582p+4, 0x1.0ba7c4ce5e25ep+5, 0x1.7e5425a72edecp+5);
}

void call_f206(void)
{
  f206(-5088635658223945568, -0x1.03afae0ae273p+5, 0x1.7373e1f3038bep+5, -0x1.5051203d425e8p+3);
}

void call_f207(void)
{
  f207(-1331332324954092403, -0x1.0b170049622c7p+5, -0x1.b51188144d254p+3, -1413877754);
}

void call_f208(void)
{
  f208(6085340184930593503, -0x1.1e6b316a214e1p+5, -0x1.9a889bed0e767p+4, 2636456557910330668);
}

void call_f209(void)
{
  f209(-6147606654240163406, -0x1.0d8f05c4a002ep+4, -0x1.1c9bfa17d8eb2p+5, -0x1.511ea6b101ff7p+5);
}

void call_f210(void)
{
  f210(-5493511086746694091, 0x1.6c9a7326ca9e4p+5, 0x1.73dc8a702e926p+5, 0x1.917c432befb1p+4);
}

void call_f211(void)
{
  f211(579008783723409095, 0x1.8029a797e5264p+5, 1700980336, 1133496704);
}

void call_f212(void)
{
  f212(-7993145151972751931, -0x1.4056898acaedcp+3, -2132323439, 1990434579911760528);
}

void call_f213(void)
{
  f213(-8238408782220192719, -0x1.c5af6b0fe59d8p+2, -861751977, -0x1.63c216e983455p+5);
}

void call_f214(void)
{
  f214(-601774021993265247, 0x1.ffae8bdbd3ecp+2, 1495023119, -0x1.2c0f4688a9b65p+5);
}

void call_f215(void)
{
  f215(-2508267507484212429, -0x1.448d43d68bafp+3, 701419690238885226, 310324292);
}

void call_f216(void)
{
  f216(2004723339903230192, 0x1.38c9c2ca864b8p+2, -6365876345548454188, 806631166576636488);
}

void call_f217(void)
{
  f217(4869042912548651253, 0x1.2faf75fe3beep+3, -3412915635436990106, 0x1.1d077684d2d54p+3);
}

void call_f218(void)
{
  f218(-9207998756414875964, -0x1.2bff1c4b4384ep+5, 2995147394344315091, 0x1.70117c43e2c2p+4);
}

void call_f219(void)
{
  f219(5896766846626993729, 0x1.4d5c855b36108p+3, 0x1.6d38a8e4b2738p+5, 1192271515);
}

void call_f220(void)
{
  f220(4896363821355900567, -0x1.d673e9a77d9dp+3, -0x1.0227cd8f552d4p+3, -2872094945455825693);
}

void call_f221(void)
{
  f221(8298102023564312779, -0x1.2486e69ff5328p+3, 0x1.230f4b0b8c53ap+5, 0x1.13fb3617ec71p+2);
}

void call_f222(void)
{
  f222(6511906833904990659, 0x1.cac92a99da434p+4, -0x1.2e841bf3a023p+3, 0x1.bcc29d948de98p+3);
}

void call_f223(void)
{
  f223(-7188185764807344847, -0x1.554d558b1ec45p+4, 0x1.2a9c21f9ddb7p+2, -964323787);
}

void call_f224(void)
{
  f224(-2466526938875799864, 0x1.2cdc15664c598p+2, 0x1.02448f55e220cp+4, -5604780313563474845);
}

void call_f225(void)
{
  f225(-6517368045522489634, -0x1.5cd816336ac22p+5, -0x1.444c192efd5ap+1, -0x1.4abc5f4925d6p+0);
}

void call_f226(void)
{
  f226(1072617192320951081, 0x1.fb7b7dece0df8p+3, 0x1.f3fe93c43b1a8p+3, 0x1.1a9f4432e3764p+4);
}

void call_f227(void)
{
  f227(-0x1.206414bdf07c1p+5, 766119712, 570808902, 1488469546);
}

void call_f228(void)
{
  f228(0x1.231a9d52bb0dep+5, 1446494661, -1325860983, 4073052043159053580);
}

void call_f229(void)
{
  f229(-0x1.e129c3acda77p+3, 646845237, 2082059015, 0x1.1954b606b9a68p+4);
}

void call_f230(void)
{
  f230(0x1.a0c96a3afd96cp+4, 554992662, -365478912, 0x1.5bdffed1e5f2p+5);
}

void call_f231(void)
{
  f231(-0x1.82d2d80dc52ep+1, 804794027, -1460371531416753188, 1576680964);
}

void call_f232(void)
{
  f232(-0x1.54e751031e38p+0, -1029015899, 8425633346289220482, -2422870035341521176);
}

void call_f233(void)
{
  f233(0x1.77600a237689cp+4, 258428535, -4761308511779651338, -0x1.8827a37e5903cp+4);
}

void call_f234(void)
{
  f234(-0x1.84793e2b6dep-3, 1755598789, -3741235593561171267, -0x1.535ad5763d128p+4);
}

void call_f235(void)
{
  f235(-0x1.6967df350472ep+5, -148346655, -0x1.78674d14d5d23p+4, -2014059984);
}

void call_f236(void)
{
  f236(0x1.9670798da9fp-1, -366159929, 0x1.e28d49346e85p+2, 2404150199276534881);
}

void call_f237(void)
{
  f237(0x1.c463f21db2ec8p+3, -1939248921, -0x1.0d4bc189e3ac6p+4, 0x1.7e8ebaf0c92b8p+4);
}

void call_f238(void)
{
  f238(-0x1.f7942204b9008p+3, 266530065, -0x1.10b53f7aae2f4p+4, -0x1.cbcaed02cf56cp+3);
}

void call_f239(void)
{
  f239(0x1.8e794d7216p+4, -1082560576, 0x1.1f188fccc7d66p+5, -1343660557);
}

void call_f240(void)
{
  f240(0x1.75e3e585314bp+1, -685594723, 0x1.256d8ce9a3f3cp+3, 2106706550183726330);
}

void call_f241(void)
{
  f241(0x1.6724ad5c2f584p+5, -83593517, 0x1.7c554a80fbcp+4, 0x1.6571b70d840ep+0);
}

void call_f242(void)
{
  f242(0x1.7bda4bd69cefp+5, -1316960385, -0x1.152322bc98cep+3, -0x1.334cf2449b99p+5);
}

void call_f243(void)
{
  f243(-0x1.663bc508e5ef5p+4, -5399390337454439163, 1653499321, 1391206508);
}

void call_f244(void)
{
  f244(0x1.5b935d6fe2b68p+4, 8165075520375979388, -1119454379, -8054086477955329448);
}

void call_f245(void)
{
  f245(0x1.513539831c75ap+5, -6321007264912992353, 546876469, -0x1.0a7451100d02cp+5);
}

void call_f246(void)
{
  f246(-0x1.8002508398d33p+4, -1368191711335779818, 1105507503, 0x1.697043817f028p+5);
}

void call_f247(void)
{
  f247(-0x1.534f131f4739p+2, 7499008377808014233, 6457986169601137151, 506150669);
}

void call_f248(void)
{
  f248(0x1.873521d9508c2p+5, -1588289399493144877, 1186097869956649880, -2553234038837715649);
}

void call_f249(void)
{
  f249(-0x1.cb5280ef422dp+1, 5351606017970382108, -4617725222680010413, -0x1.74e6f65af6277p+5);
}

void call_f250(void)
{
  f250(-0x1.78db08cad480ap+5, 1983581095153981358, 2825007739463278211, 0x1.8708220a12b14p+5);
}

void call_f251(void)
{
  f251(0x1.1c83ec5529b7p+3, 4494448565390693015, -0x1.51f7b310826e9p+4, 1822416003);
}

void call_f252(void)
{
  f252(0x1.d4fdf33d6a68cp+4, -5045408152623293315, -0x1.ba92938b19b28p+2, 7492969189661519081);
}

void call_f253(void)
{
  f253(0x1.b0e74c706e37p+3, -40735531055273805, -0x1.5c02e635bd14p+0, -0x1.55dab20696a1dp+5);
}

void call_f254(void)
{
  f254(0x1.aef1c611610ecp+4, -3208325518965096226, -0x1.8ca6021a51e5dp+4, -0x1.a05f6cdfea56p+0);
}

void call_f255(void)
{
  f255(0x1.7c1fc53f3f7f4p+4, 7774717424601704445, 0x1.4b033b4980b4cp+4, -1135386198);
}

void call_f256(void)
{
  f256(0x1.442a74d5bf4aap+5, -8384716095038314712, -0x1.d6263e16e2p+1, 378231293743041269);
}

void call_f257(void)
{
  f257(0x1.4bc449947103ap+5, 7899436877524914986, -0x1.2b2ad1d957735p+4, 0x1.4c41727a81d3p+3);
}

void call_f258(void)
{
  f258(-0x1.54ca4803bd408p+3, -1195728655791694515, 0x1.c14e1699cc9cp+4, -0x1.f93c767a6718p-1);
}

void call_f259(void)
{
  f259(0x1.81aee1dd71944p+5, -0x1.e38b7a75f9338p+2, 1380027330, -1436663404);
}

void call_f260(void)
{
  f260(0x1.4ebf72f7fa754p+5, -0x1.edfcbee701ee4p+3, 588627619, 8327655339970732696);
}

void call_f261(void)
{
  f261(0x1.6d018015e8a04p+5, 0x1.190303cba1e9ep+5, 894530560, 0x1.f714334357204p+4);
}

void call_f262(void)
{
  f262(0x1.2ea92720be07cp+4, 0x1.29a303014b31p+4, -1913890902, -0x1.59d91c8231611p+5);
}

void call_f263(void)
{
  f263(-0x1.740935eb74bp+5, 0x1.daa4e2714122p+2, 7582431942063544436, 1254999553);
}

void call_f264(void)
{
  f264(0x1.fea58f214c934p+4, 0x1.25fae85eadp-1, 144557777347792410, 919076514725995571);
}

void call_f265(void)
{
  f265(-0x1.2fecee3365f56p+5, -0x1.4086a49da01dp+2, 7919911886643111983, 0x1.d2f371d84339cp+4);
}

void call_f266(void)
{
  f266(-0x1.957c23a03734cp+4, 0x1.8c9b979698868p+2, 4517346182462412138, -0x1.119f4f10880ap+1);
}

void call_f267(void)
{
  f267(0x1.9681d667874p-3, 0x1.5a4f9d961343cp+3, 0x1.bd80216ef9a8p+2, 108878298);
}

void call_f268(void)
{
  f268(-0x1.e88aab99866acp+4, -0x1.5dd44c2478cep+0, 0x1.f6a8530a5fe58p+4, 5028231680057739307);
}

void call_f269(void)
{
  f269(0x1.4bdee83fcb6p+0, 0x1.38220e31d7p-2, 0x1.60d2e12a26728p+4, -0x1.cf4aed40d5f98p+3);
}

void call_f270(void)
{
  f270(0x1.0b903eee9a8c4p+3, 0x1.3f8f9229a0712p+5, 0x1.837df5dbf2336p+5, 0x1.979482a10868cp+3);
}

void call_f271(void)
{
  f271(0x1.5e1522cc5933p+1, 0x1.a46885dd6282p+1, -0x1.bd9c1620784e9p+4, -381630114);
}

void call_f272(void)
{
  f272(-0x1.cd8eb1dff81bcp+3, 0x1.8776bb3e478bp+4, 0x1.d44591f376998p+4, 6439578625645459108);
}

void call_f273(void)
{
  f273(-0x1.f82ed63367938p+2, 0x1.724a3b38a164p+2, 0x1.4c1e2d2d8c338p+4, -0x1.7be7b1d21302ep+5);
}

void call_f274(void)
{
  f274(0x1.aeb9a4cd75818p+4, 0x1.0df17d2210f36p+5, -0x1.2ba0dcc7e5a94p+3, 0x1.99df6df968fbcp+4);
}

void call_f275(void)
{
  f275(-0x1.59bcccf895926p+5, 0x1.168b6a6d71296p+5, 729141640, 932788510);
}

void call_f276(void)
{
  f276(-0x1.93a8be18f118fp+4, 0x1.518752a9d0c2p+0, 1010031513, -5730518312854327492);
}

void call_f277(void)
{
  f277(-0x1.3529e45f2d954p+5, -0x1.12d4bc17d7dcap+4, -1238173675, -0x1.98c9174d6dcf8p+2);
}

void call_f278(void)
{
  f278(0x1.fdcf55b9741bp+4, -0x1.116ced306945p+4, -776544045, 0x1.3cd256c1737bcp+3);
}

void call_f279(void)
{
  f279(-0x1.7542cb4a7fd24p+4, 0x1.70198fa77577ap+5, -4676640831765498941, -1899617899);
}

void call_f280(void)
{
  f280(-0x1.2c01343072a8p+3, -0x1.9e4b1139cb459p+4, 1348595155264568119, 142617196952546487);
}

void call_f281(void)
{
  f281(0x1.229c95b9d8f0cp+5, 0x1.1e0918811813cp+3, -1597955878845432235, -0x1.ffd7dc2157b58p+3);
}

void call_f282(void)
{
  f282(-0x1.8733ec2227d04p+3, 0x1.cc62aede088bcp+4, 4138865106599557496, -0x1.dddc7037b07dp+3);
}

void call_f283(void)
{
  f283(0x1.00786661f23dcp+4, -0x1.f8a8c66e95c55p+4, 0x1.7d2cf026a8108p+5, -1179454657);
}

void call_f284(void)
{
  f284(0x1.46f30e8b8b048p+2, 0x1.61dd91d436596p+5, -0x1.e4f48b58276c8p+4, 5463312279528034827);
}

void call_f285(void)
{
  f285(-0x1.14c8453570136p+5, 0x1.2fc51e9c760bp+4, 0x1.87cbca2702398p+3, -0x1.084e41dffb7d1p+5);
}

void call_f286(void)
{
  f286(-0x1.5ca678c795472p+4, -0x1.76d7e76bd017p+1, 0x1.258d6c28b8f7cp+3, 0x1.0802d2dc281ep+5);
}

void call_f287(void)
{
  f287(-0x1.ea0b75f2d825p+2, -0x1.7a9800f4cc17fp+5, 0x1.a7b2ed4241d88p+4, 1224572420);
}

void call_f288(void)
{
  f288(0x1.687cb3724b9dp+2, 0x1.f014c6c8a3a9cp+4, 0x1.3c7232c8cdbfcp+5, -6356849868588853112);
}

void call_f289(void)
{
  f289(-0x1.60669b7141f3ep+4, -0x1.7914de5671266p+5, -0x1.d40d0a4332b31p+4, 0x1.1ef4183bf64d4p+5);
}

void call_f290(void)
{
  f290(-0x1.0d69608dee53p+5, -0x1.493b8d8c3a1cap+4, 0x1.48b5e812da23p+4, -0x1.1f563363ef164p+4);
}

void call_f291(void)
{
  f291(-0x1.7f858f1d04a1ap+5, 1384116936, -1890988020, 762730598);
}

void call_f292(void)
{
  f292(-0x1.30dfc73258p-7, 556191707, 1778040802, -5312906134700150817);
}

void call_f293(void)
{
  f293(-0x1.4d8561f18edc6p+5, -751614125, 1664566933, 0x1.7f90a30d5ca74p+5);
}

void call_f294(void)
{
  f294(0x1.239d4a3d3891cp+5, 45908317, -1134549720, 0x1.e9df584ddf398p+4);
}

void call_f295(void)
{
  f295(-0x1.1550b80e48d35p+5, -1379717951, -6165695899100406630, -1579355106);
}

void call_f296(void)
{
  f296(-0x1.848a06b2abeep+1, 553414869, -7164013319183340508, -6274149290452297398);
}

void call_f297(void)
{
  f297(0x1.d4a059ea4f89p+4, -281310785, -424610158424772107, 0x1.8662282fefce4p+3);
}

void call_f298(void)
{
  f298(-0x1.7bd181bd5bd87p+5, -990903690, 2870233668088923113, -0x1.678f6bb15f73bp+5);
}

void call_f299(void)
{
  f299(0x1.608bf197a3338p+4, -1471304705, -0x1.0d472acbd4eeap+5, 859776317);
}

void call_f300(void)
{
  f300(0x1.7e702a5c3085ap+5, -620020397, 0x1.384ad7e653198p+4, -8609168085781150948);
}

void call_f301(void)
{
  f301(-0x1.d1ad7a98e38bcp+4, -2050555014, -0x1.1722cbd292fe2p+4, 0x1.4c79c99fddeep+3);
}

void call_f302(void)
{
  f302(0x1.158cb75ab5c7p+5, 2128424796, 0x1.a620afbf5b5ep+2, 0x1.4f63f19cc8dp-1);
}

void call_f303(void)
{
  f303(0x1.8603de811393p+4, -582514423, 0x1.2b95fb65bdac4p+3, -1378623753);
}

void call_f304(void)
{
  f304(-0x1.64956ce26016cp+5, -1273546305, -0x1.e62c8c14332dp+2, 4075154345800202349);
}

void call_f305(void)
{
  f305(0x1.febcbe53e9e88p+2, 1520108479, 0x1.6784e119993dep+5, -0x1.cdc0e65c92422p+4);
}

void call_f306(void)
{
  f306(0x1.59225318a5d8cp+4, -2117044826, 0x1.8af7d37fabc4p+2, 0x1.4c5d62b5438a2p+5);
}

void call_f307(void)
{
  f307(0x1.0c2c591da004p+0, 887319212162834346, 144330350, 324538738);
}

void call_f308(void)
{
  f308(-0x1.23f92c9ab298p+5, 7788507057432146857, 393069153, -3652585478275577320);
}

void call_f309(void)
{
  f309(0x1.226d83e562718p+2, 2968153173513475327, -1530659055, 0x1.88439d19ca22p+5);
}

void call_f310(void)
{
  f310(-0x1.624515946c039p+5, -2572936754354885655, 1683227404, 0x1.15a5aefe042c6p+5);
}

void call_f311(void)
{
  f311(0x1.3ba9b7c2e7b5p+2, -8665367117668493558, -8666117773688002816, -1527421124);
}

void call_f312(void)
{
  f312(0x1.309d2c94305c8p+2, 1524385651800878916, -7014871778848740946, -7972523454735797755);
}

void call_f313(void)
{
  f313(-0x1.74c0d8fc008d8p+3, -1960143764068172015, 5220552901029029340, 0x1.4809d3e58b42p+3);
}

void call_f314(void)
{
  f314(0x1.3390b74c30878p+4, 2421097890542942836, -4868572559017761325, -0x1.16728b2973ff4p+5);
}

void call_f315(void)
{
  f315(0x1.5ec2dfc527fdp+2, 5148209924914594035, 0x1.7a2f5ea9254dap+5, -1621772850);
}

void call_f316(void)
{
  f316(0x1.ed598d51a2a38p+2, 4594183260767331996, 0x1.02ceb09471e2cp+3, 6931479337707060465);
}

void call_f317(void)
{
  f317(-0x1.4b514c968c44ap+5, 1628249656023893440, -0x1.b2b57bb6e83bcp+3, -0x1.407eed47bd612p+5);
}

void call_f318(void)
{
  f318(-0x1.455c3caa75cbp+2, 19243385444059710, -0x1.04b60cd0b7a54p+3, -0x1.a7b99e9cb0cb5p+4);
}

void call_f319(void)
{
  f319(0x1.d0a54047f8908p+4, -1602539825163174277, -0x1.06e1f6833e6dcp+4, 1907480980);
}

void call_f320(void)
{
  f320(0x1.5202de35e9f02p+5, 1733865892510381796, 0x1.70eef36c9b9fp+1, -8166280867900889923);
}

void call_f321(void)
{
  f321(-0x1.4ec5f40d8354p+5, 8655924560434077995, 0x1.731a8a203148p-1, 0x1.119aca239232p+5);
}

void call_f322(void)
{
  f322(-0x1.8008192b0e095p+5, -5220423756235120011, -0x1.efc60ce0e5e7cp+3, 0x1.5c1f84fbeeaep+4);
}

void call_f323(void)
{
  f323(-0x1.bb19d7b368224p+3, 0x1.289e88b0ccc1cp+4, 1604089093, -996913219);
}

void call_f324(void)
{
  f324(-0x1.3c9f67347841cp+5, 0x1.8383075fd09f8p+5, 209422202, 2286552696394610993);
}

void call_f325(void)
{
  f325(0x1.0f435bbbb32c4p+5, -0x1.550b57f38f07cp+4, -965500715, 0x1.6468b96905458p+2);
}

void call_f326(void)
{
  f326(0x1.c9fee15d8953p+1, -0x1.73dd49b99f13bp+4, -835944656, -0x1.b8aff2a06f5fap+4);
}

void call_f327(void)
{
  f327(0x1.4122b231829cap+5, 0x1.aeff10cc6ef5p+2, 176495729844223595, -1110233509);
}

void call_f328(void)
{
  f328(0x1.378b91c93b45p+3, -0x1.58a57d387dad9p+5, 2559663458968797884, 8136112140863111610);
}

void call_f329(void)
{
  f329(-0x1.c309cbc51297ep+4, -0x1.27d42a9d9c60cp+3, 1392468792669355675, 0x1.6541d544e03f4p+4);
}

void call_f330(void)
{
  f330(0x1.7b51f1961e6d4p+5, -0x1.37f0850653436p+4, -6238776459103324790, -0x1.7f215900e5ddp+3);
}

void call_f331(void)
{
  f331(0x1.f392aefdc2be4p+4, 0x1.22f7abdf466b4p+5, -0x1.93e2204c9ff09p+4, 85565784);
}

void call_f332(void)
{
  f332(-0x1.2d538bcd3db1ep+4, 0x1.28bf1c16f031cp+3, -0x1.5c419fcb731a8p+5, -4624081255055915723);
}

void call_f333(void)
{
  f333(-0x1.2482d5674f924p+3, 0x1.7bfc3a0c31fp+2, 0x1.2d355eb222034p+5, 0x1.56a402d72e4fp+4);
}

void call_f334(void)
{
  f334(0x1.a1a593ef6a5ap+1, -0x1.884d7ab7aa881p+4, -0x1.436e9cf1b926p+2, -0x1.761716aee234cp+5);
}

void call_f335(void)
{
  f335(-0x1.042a82f4c6703p+5, 0x1.b4ab14f5991c4p+3, -0x1.43890acf0acf9p+4, -1375222193);
}

void call_f336(void)
{
  f336(0x1.e0cfd8c9330f8p+4, -0x1.8039bd6131675p+5, -0x1.50fe8b44dd9b2p+5, -6317117901620112104);
}

void call_f337(void)
{
  f337(-0x1.1985cc3c6497ap+5, 0x1.1ed790e7d9dcap+5, -0x1.b8ac6bd54ff3bp+4, -0x1.744ad56d6235p+5);
}

void call_f338(void)
{
  f338(-0x1.1824d06b89655p+5, 0x1.788b37026117p+5, -0x1.3b9aa8dac6668p+4, -0x1.aa4ecbf3c22eap+4);
}

void call_f339(void)
{
  f339(-0x1.3e6f6a66c3e74p+3, 0x1.8867900f93238p+4, 1105283979, -1922966666);
}

void call_f340(void)
{
  f340(0x1.fa2e547aa6b6p+2, 0x1.6c36d4674468p+5, 1325989589, -5694056187168055922);
}

void call_f341(void)
{
  f341(0x1.e21cc1ca12838p+4, 0x1.5639335dec9dcp+4, 1387942995, -0x1.3e9308eeda0f6p+5);
}

void call_f342(void)
{
  f342(-0x1.519d764d547bep+4, -0x1.fd2679a8a9154p+3, 1504887698, -0x1.b7eb5cb45eb43p+4);
}

void call_f343(void)
{
  f343(0x1.4cccff2c08aacp+5, -0x1.2a1dbccf58a56p+4, 2216751923110492342, 1513395011);
}

void call_f344(void)
{
  f344(0x1.4f3c6001ac398p+5, -0x1.bff33121065c8p+3, -3183775473145292428, -8153863183067849463);
}

void call_f345(void)
{
  f345(0x1.21d34bcdce396p+5, 0x1.d4ba10a4454cp+3, 8845191802650343226, -0x1.22c8e70ecafdfp+4);
}

void call_f346(void)
{
  f346(0x1.5b8580b6546b8p+2, 0x1.81707b2d25p+5, -1082112759578367330, 0x1.55f58ec5bef6p+2);
}

void call_f347(void)
{
  f347(-0x1.22d9f6797de6p+0, 0x1.707315e29e1ap+3, -0x1.05492c2e0cbfap+5, 1490837671);
}

void call_f348(void)
{
  f348(-0x1.233b5672f67f8p+2, -0x1.c55f976989dafp+4, -0x1.2eed23da8418cp+3, -1975012453410951728);
}

void call_f349(void)
{
  f349(-0x1.543f9e32d8841p+5, -0x1.47467d8e6424p+1, 0x1.54aa9a246632cp+5, -0x1.156075ad13088p+4);
}

void call_f350(void)
{
  f350(0x1.caf06896b983cp+4, 0x1.cda1569bc3088p+3, 0x1.4ac1e619f647ap+5, 0x1.6b721bd4cd6e8p+4);
}

void call_f351(void)
{
  f351(0x1.55c3929240d3cp+3, -0x1.17cb0d77a21fp+2, -0x1.8ed3f76358967p+4, 108418013);
}

void call_f352(void)
{
  f352(0x1.36e5e5b912652p+5, 0x1.b5c9f39e0b074p+4, -0x1.ef9aa7ac43ae6p+4, -1771001256599518628);
}

void call_f353(void)
{
  f353(0x1.cadc11b5159cp+1, -0x1.fabb6a1b123bp+4, 0x1.44a7f21bc2edp+4, -0x1.4298b2c61e658p+3);
}

void call_f354(void)
{
  f354(0x1.0386c30a1355p+1, -0x1.73df3c72deddp+5, 0x1.78144f2107088p+3, -0x1.de53cf820b458p+2);
}

void call_f355(void)
{
  f355(-423094771, 1505276306, 1173225900, -39393538, 1340083113, 124640452);
}

void call_f356(void)
{
  f356(1922578507, -1404176156, -2145968655, 2087250985, 992973758, 1178086693, -701542642, -954253759);
}

void call_f357(void)
{
  f357(-514825008, 975957544, 1465777616, 1345379491, -40814461, -864158835, -1655158826, 1131147407, 1034121376, 967938458);
}

void call_f358(void)
{
  f358(-1298572493, -2109303418, -1305870880, 1443378966, 872750106, -584067502, -1106923504, 705934465, -1103071796, -1437055712, 1916925301, -864379867);
}

void call_f359(void)
{
  f359(-859393046, -1429730775, -584436702, 907987319, 215158658, 1004607381, 1066708728, -729838178, 1486598137, 1344126429, 2031566435, 426339393, 717727326, -1883364492, -22660167, -19745483);
}

void call_f360(void)
{
  f360(1048434839, 461905554, -514234587, 96472938, -1438792809, 2058930445, -939066786, -1298062494, 83848286, -1413457542, -279075729, 956834669, -1382477177, 683174546, 1175841930, 1210628432, -160140420, -1563519804, 475735511, -1942272654, 108110044, -1187952713, 1965355593, -227220619, 1748646090, 1530829299, 1813001740, -152147627, -409678506, 1797562881, -1055359181, 204018589);
}

void call_f361(void)
{
  f361(-1432556973172761132, 6420030855427841835, -2995625662755041992, 1818443015186246839, 2052416614585665254, -6524358139460670822);
}

void call_f362(void)
{
  f362(-7893380784044236139, 3442378124667900717, -2960430863517272362, -5234052192265542229, 1793253587295126774, -5337206238629308146, -2109445881971704641, 7737659921410301462);
}

void call_f363(void)
{
  f363(6098328753400630847, 2851048571571680884, -1004897092244016623, 1979672478103890791, -8093287479821212847, 700722888949744943, 2724731105122010090, 4281405557676137988, -243587917047033645, 2928293273872764448);
}

void call_f364(void)
{
  f364(8280785781046036156, -5473828832771639042, -5843229045195453189, 1764487498711989127, 7421175693490725445, -1948336425508299808, -5495300211722437994, 4568123950159180167, -6454939088536412389, 5098031644914311974, 5549437607527880917, 8822157796788735305);
}

void call_f365(void)
{
  f365(-56088162696548283, 3141735048510226230, 7892810677154611693, -7972745059940243433, -5885227262144577902, 3478134692310580972, -8294485743144085619, -2684616029369034285, 8044998567589378292, -788138276494162104, -5196928128377147301, -7150249304022632740, 6710671048277666885, 5349442618315074672, 1592477114504556635, -4723032894781347996);
}

void call_f366(void)
{
  f366(2950949638210749720, -7157390070168439085, -7916817867445027145, -3894833564467421384, -6511094147122279554, -68840199802498301, 3508538611409765116, 9013604975829805868, -3544378733840909635, -6200752028167505346, -5780353032551804269, -4881526498773745591, 910725473368700404, -2185056190031991151, 6268896796132780175, 6366677771156053955, 5196465850108463886, -2072603470473678256, 6991261571398688119, -8330113277657259507, 8942101680030711439, -3434089458137273305, 3258848165895207272, -8640181905047538508, 155934121472931533, -7471356718194690361, -4059525863128591881, 7946916884173851674, -4371846318264939614, -7874210323407090044, 8536550905392207944, -248788625111440588);
}

void call_f367(void)
{
  f367(-0x1.b5eb43facf1c9p+4, -0x1.271aaf5766641p+4, -0x1.798f75713a5fdp+5, -0x1.abbbe47f5e68p+4, 0x1.43ffd6b007e4ep+5, 0x1.631834d88a75p+4);
}

void call_f368(void)
{
  f368(-0x1.0c6bdcd574d2p+4, 0x1.4e9770f249338p+5, 0x1.0c354bbd6f014p+4, -0x1.e870ddcb0eefp+4, -0x1.0815c0b4f2fe4p+5, -0x1.ed6b21c7c3489p+4, 0x1.12daaeac3614cp+4, 0x1.2d78ba99c59e4p+4);
}

void call_f369(void)
{
  f369(-0x1.4fecb9a6453eep+4, -0x1.37a3dbefdc14dp+5, 0x1.8751d68009ee8p+4, 0x1.411c7a8b0ecbap+5, 0x1.21b729c49a9e6p+5, -0x1.53a923b99aea6p+5, 0x1.d72d4863e8b3p+4, -0x1.c6094c4eb3f1p+3, 0x1.2a25c81b0362cp+3, 0x1.182da6970ca08p+3);
}

void call_f370(void)
{
  f370(0x1.9f7c197e357fcp+4, 0x1.00c42cdf99d2p+0, -0x1.6a159a051f2a8p+4, 0x1.79be1a68f1cdp+4, -0x1.062e7871884cp-1, -0x1.473fd2e37343ep+5, 0x1.da5b97f1f3d14p+4, -0x1.8cc8f06b36073p+5, -0x1.3afe7786e15dp+5, -0x1.bf953981aaed8p+2, -0x1.88db725023f63p+4, 0x1.5af6859febb92p+5);
}

void call_f371(void)
{
  f371(0x1.c5c621a28d8a4p+4, 0x1.bb4bd9f48a78p-2, -0x1.bcf84967b1898p+2, -0x1.228d662542a8ap+5, 0x1.07e7683964ad8p+5, 0x1.8dcb45ebec27cp+3, -0x1.1971c09e8096p+0, -0x1.8094ec28d6268p+4, -0x1.d23c2745037e7p+4, 0x1.2a438b6ecee54p+4, -0x1.643c67e6446c2p+5, -0x1.0b40ddf701c85p+5, -0x1.08967c083d9f5p+5, 0x1.776ec999b4584p+4, 0x1.5bb8569c186eep+5, 0x1.10c28ec8080f8p+4);
}

void call_f372(void)
{
  f372(-0x1.168722dab57b8p+5, 0x1.1d1cc2765be5cp+4, -0x1.427080bd32a76p+5, -0x1.10b9d0da2d72cp+4, -0x1.dc1cf89ae18a9p+4, 0x1.3179032a70cbep+5, -0x1.f08d3a20dcee2p+4, 0x1.3738f2ddcbb26p+5, 0x1.7214e885be374p+3, 0x1.1a6632f274bc8p+5, -0x1.5583c5f222a88p+5, -0x1.b6da225504a58p+3, -0x1.fcbeee065b36cp+3, 0x1.623dacdbf2ep+3, -0x1.3f507423df359p+4, 0x1.7bcc8180174f8p+5, -0x1.cb81933774fddp+4, -0x1.7355fe7a6ff67p+4, 0x1.5f19b3f9a61f8p+4, 0x1.9af6ffa2eb14p+2, 0x1.4c1f4c97469b8p+4, 0x1.634732d09a6b2p+5, -0x1.f615ebbdc8304p+3, -0x1.c708bb6ca03f5p+4, 0x1.43ba23ebcfbaep+5, -0x1.128e674ea789ap+5, 0x1.82de55de6348cp+3, -0x1.8925b3caaa8p-2, -0x1.8aaa94faadb6fp+4, -0x1.589089d36388dp+5, 0x1.204b125def3a4p+4, -0x1.35a2168664833p+4);
}

void call_f373(void)
{
  f373(-0x1.81cbd035cf3d2p+5, 0x1.29262d7c5f382p+5, 0x1.1a453ae5dd19p+5, 0x1.696dc86f54be8p+4, 0x1.2793d0c614a7p+4, 0x1.5696d5b3b5ac8p+2);
}

void call_f374(void)
{
  f374(-0x1.145244b54c25p+5, 0x1.7c76a52e7628cp+4, 0x1.054b94401229ap+5, -0x1.96c88b519fefcp+3, 0x1.107e9fe8043d6p+5, -0x1.45699871d172p+1, 0x1.247bfdff4e9ecp+3, 0x1.82ab358db711ep+5);
}

void call_f375(void)
{
  f375(0x1.3ac83bfbfec98p+5, 0x1.05042a8ae2374p+5, 0x1.5cd19a1b221e8p+4, -0x1.153cc7b2ce4a8p+5, 0x1.a3f9a65cbfc4p-1, -0x1.397c62bebb35ep+5, -0x1.70d4138887bfp+3, -0x1.e6a5898cf7718p+2, 0x1.65bf5d2ac655p+3, 0x1.7da71191d9484p+4);
}

void call_f376(void)
{
  f376(-0x1.62e12e928026ep+5, -0x1.2212be55f2156p+4, 0x1.b853a0af05214p+4, 0x1.311aa6a043616p+5, -0x1.4db0d7fc5668p+0, -0x1.320ebb06a174fp+4, -0x1.19b4b30657946p+4, -0x1.69274adb1913cp+5, 0x1.686b16e2232b8p+3, 0x1.66d9fcb759618p+3, 0x1.fef40e891edp+0, 0x1.0c0e755b92fbcp+5);
}

void call_f377(void)
{
  f377(-0x1.1ba879cdba5cp+1, 0x1.3ae959c6ebc94p+4, 0x1.47c67d7e4f73cp+4, 0x1.2701b2c54f9e8p+2, 0x1.bf0392e631ee8p+4, 0x1.50568bdec6876p+5, 0x1.e598bf056f208p+3, -0x1.08d1f8f64f098p+4, 0x1.107d84561fda4p+4, 0x1.61cd359fc6ef6p+5, -0x1.449a51464a74p-1, 0x1.89b6c3f1f5714p+5, -0x1.0895e71a21a4p+3, -0x1.8ae867ac63c6p+2, -0x1.5018078d5a622p+5, -0x1.4de64caba8fp+4);
}

void call_f378(void)
{
  f378(-0x1.a1930016a4ddbp+4, 0x1.7a92a143b1ad4p+5, 0x1.8b554c2d00344p+5, -0x1.84ddff9150292p+4, -0x1.128cc7a62baefp+5, -0x1.1001fa968b0dp+3, -0x1.804c3dfe9ba15p+4, 0x1.58b7ecd326fbcp+3, -0x1.08ae11517699ep+5, -0x1.033447a47c4cp-1, -0x1.8de4be25546b2p+5, -0x1.d2075ee851d64p+4, 0x1.0a5afa98b08p+5, 0x1.0d57bafec17ap+3, 0x1.cabddc439e59cp+4, -0x1.fcbbcacf10977p+4, -0x1.23e5b7658a3dbp+4, -0x1.1900e751d45b4p+5, -0x1.23e650c8ed121p+5, -0x1.6f0776f9b5ffp+1, 0x1.321612c7ad8fcp+4, 0x1.ec82c4e6ee65cp+4, 0x1.fcc0ab86b1dep+1, -0x1.5f8171c500dap+4, 0x1.219609c952c74p+3, -0x1.1bb3529555a77p+5, -0x1.3d631e1ddfcc4p+3, -0x1.c3ddb8adfeda8p+2, -0x1.177d114699ba2p+5, -0x1.784f721110bb9p+4, -0x1.783025597a5e4p+4, -0x1.5866e6b706673p+4);
}

void call_f379(void)
{
  f379(-2015654770, 716653978532097895, -988862123, -2466728654179640739, 823660008, -5272217850553273719);
}

void call_f380(void)
{
  f380(1528406927, -3770579074154420253, 362336643, 1257099725035211705, -1703435973, 1614099172513992492, -750013163, -4702775168291073133);
}

void call_f381(void)
{
  f381(-1595325650, 1602981869158816429, 1327133866, 3026298066479890812, -95542402, -5512131811937022583, 1039822329, 6975678907018234127, -1531371345, -3402970413890770432);
}

void call_f382(void)
{
  f382(896708658, 4236448195687343578, 983017510, -9101165479232786281, -79909837, -8483183148190961614, -1796866116, 675335784646766848, 1659592218, 5767308369281755955, -1885408982, 1035655038079628638);
}

void call_f383(void)
{
  f383(-1590025862, 7842076538450601827, -34183735, 6550337071398316611, -172267386, 8673804281254757629, -1091097255, 1813422903077560904, 334742130, -4100251046507000904, -36175878, -9151416467906400044, 1995943021, 4173621555652906187, 1353292457, -6375672691363589202);
}

void call_f384(void)
{
  f384(1283153529, 6925298346680196411, -891385059, 3379461259116639559, -1209196995, -1820234708450516249, 649603801, 527513708541539381, 1265028160, -4315037738782710494, -118581955, 4376291797803467454, -71772421, 6842489707283958516, -22927078, -7122009935182834671, 62665218, -7191874957624977033, -1503757222, -6801786523296253809, 1423833574, 2486651285551772626, 1873512994, -6124239478838528499, 1039076295, -8006903791084562979, 766797925, 2437208692896991684, 369994110, 2290879009162642306, -1815112293, 3963838333005623802);
}

void call_f385(void)
{
  f385(1206269430, -0x1.95a207dcd0c71p+4, -828017528, 0x1.26ff809974836p+5, 1777769851, -0x1.6c6cdb32eac57p+5);
}

void call_f386(void)
{
  f386(-2002700535, -0x1.12bf7f6c68cfep+4, -812165634, -0x1.764ccc77fdf11p+4, -2073747379, 0x1.bd21469444a94p+3, -880712620, 0x1.a05069ac98bdcp+4);
}

void call_f387(void)
{
  f387(-140608584, -0x1.a96ad9d83e03p+2, 746731091, 0x1.8509190ea427cp+3, 1877554659, 0x1.b84bd6c718bd4p+4, 602122405, 0x1.b70a59e111954p+4, 271418819, 0x1.f58d7cf7a4b08p+3);
}

void call_f388(void)
{
  f388(1488453224, -0x1.f803478be72b1p+4, -39249660, 0x1.f7510a2155efp+4, 1665635958, 0x1.8f262eb8955ccp+5, -435951979, 0x1.89a0030e3a45p+2, -2040690735, 0x1.1d9e352a5355ap+5, 759660220, 0x1.0ab0581f4b18ap+5);
}

void call_f389(void)
{
  f389(-1972389722, 0x1.96f0f17702f64p+4, -1934635214, -0x1.cb2145593545p+3, 1103533688, 0x1.dd245cf3a1348p+4, -589479035, 0x1.1d215bbb33d94p+4, -795105357, -0x1.48dcfef27cbc6p+4, 1316559599, -0x1.5ad45c7dca985p+5, 1491201256, 0x1.a3be763fc91bp+4, -240159590, -0x1.73fd01c1dfb12p+5);
}

void call_f390(void)
{
  f390(-1584474906, 0x1.1a5e7af57bb6cp+4, 632719022, 0x1.275c5a2aa380ep+5, -51685590, 0x1.584ffd8376e18p+5, -482778491, 0x1.390359d3fc4acp+3, 1381424819, -0x1.b653938f36825p+4, 1546356477, -0x1.c4fb3dec0901p+1, -352310184, -0x1.5d40566c15425p+4, -1303592753, -0x1.33c23ea49b155p+5, -1197739108, 0x1.8b561af66f05ap+5, 1523850238, 0x1.048bb01857b42p+5, 1522201090, -0x1.67b63838c1e84p+3, 1692645976, -0x1.80a64ef1324e2p+5, -233103132, 0x1.3b1e397d5ad5cp+5, -655067969, -0x1.3f12f9dec132ep+5, -1657848261, -0x1.2301d8d485c3bp+5, -469621136, -0x1.272311da31979p+5);
}

void call_f391(void)
{
  f391(291890958, -0x1.4bca12aef167ap+5, -1302322450, 0x1.c212251659908p+2, 404085563, 0x1.503d3d9857454p+4);
}

void call_f392(void)
{
  f392(-468039968, -0x1.b47af22ae7b01p+4, 1616050395, -0x1.ee4fd12b9c0f9p+4, 2030619672, 0x1.8d4e9b5a69564p+4, -608926474, -0x1.0e7e87e37abbcp+3);
}

void call_f393(void)
{
  f393(-502607993, -0x1.69cd66b68a5d9p+5, 1234171796, 0x1.89bf9cbad243p+4, 94251305, -0x1.816d7bc68640cp+3, 646416130, -0x1.ab2010cce6194p+4, -17798135, 0x1.e34353b26af9p+3);
}

void call_f394(void)
{
  f394(143681772, 0x1.46c0df10bac8p+2, -1931703068, -0x1.0278eb7681ef1p+5, 59026191, 0x1.691eebbe42592p+5, -1739183125, -0x1.541ad70318b24p+3, -980874536, -0x1.7fc40a5330194p+3, -995025504, 0x1.6ce6595c56728p+3);
}

void call_f395(void)
{
  f395(1910898156, -0x1.2818b9c532dfcp+5, 1658733616, -0x1.3d70c51d043efp+4, -582282100, -0x1.9c074f8758f08p+2, -1249667458, -0x1.526c8496c465p+3, -28360498, 0x1.2412485a6ff5cp+4, -1924594002, 0x1.27fa37db54ef4p+4, 1138477050, 0x1.52e686eea7ef8p+3, -1143415984, -0x1.5979124b2fd65p+5);
}

void call_f396(void)
{
  f396(806807427, -0x1.1297d955fa04ep+4, -1848197165, -0x1.6db03a8b098a7p+4, -1645767426, -0x1.667b255c2988p+5, 1978613310, 0x1.703578fdb2f14p+4, 165072864, -0x1.30105fb0b79f8p+5, 408048480, 0x1.d8f4bae679b58p+4, -2107517091, 0x1.590e767f3283ap+5, 1787122419, -0x1.fb4b855c18bap+0, 1768946980, -0x1.114c742f3336p+1, -318723215, 0x1.5b4d970ba466p+4, -982994182, 0x1.27204b475c7p+4, -1544866637, 0x1.8dbda55960becp+4, -348173931, -0x1.03cc013edab5ep+4, 1679405144, 0x1.957c5df4980a4p+4, 447449844, -0x1.b6df847381ebbp+4, -1236663055, 0x1.62db5109ca6c4p+4);
}

void call_f397(void)
{
  f397(4785801764088872046, 0x1.25b73e5521668p+2, 8586031223180042616, 0x1.db4c40b9f4cf4p+4, 3840614249491433503, 0x1.1ac97d7b69d18p+2);
}

void call_f398(void)
{
  f398(-330935148507099720, 0x1.d819a239b943cp+4, -2036618730679336579, -0x1.5ca7da3187478p+5, -4952543996741785342, -0x1.0896e0fe6da64p+3, 5252210869316814940, -0x1.8364a7e3b007cp+5);
}

void call_f399(void)
{
  f399(-4594533007969215430, -0x1.316d8edb0c81p+2, 5222965446399891275, -0x1.62e0b4239718ap+4, 930875816963334098, 0x1.6eb00ba7aa9dp+1, -4413873416109822686, 0x1.5f379473a18acp+4, -5563167892611491228, -0x1.42237cbd2232bp+5);
}

void call_f400(void)
{
  f400(5633226159284914493, -0x1.5e5bcf1a13e0dp+5, -3542461622822811062, 0x1.d5ea489a693f4p+4, -7856285668828652720, -0x1.66d641d8471dap+5, -413372358248625160, 0x1.62029a85bdc62p+5, 3141849129382149905, -0x1.37d1773656d5p+3, -2611981681636038282, -0x1.2fc550ff01668p+3);
}

void call_f401(void)
{
  f401(-4743302682290876029, 0x1.54da19f0d334ap+5, -5360701301012779250, 0x1.1bb79093a8144p+5, -7708824747727038723, -0x1.adc673c1f896p+1, 5393634098042998079, -0x1.c1e5515557f08p+4, 6602860087976457967, 0x1.70de664978f04p+4, -4560490064318100677, 0x1.8c6e60d86792p+2, -6201641412528511055, -0x1.403db1ff70a2ep+5, 4289570164227552661, -0x1.79a26849a656ep+4);
}

void call_f402(void)
{
  f402(2124944317141421801, 0x1.f440875aaa824p+4, 6683878460132795808, -0x1.c79376b85abdp+2, 3292605488923538059, -0x1.7cd34b82c0496p+5, 8254180554966866783, 0x1.f02d5a516c898p+4, -6253980212159705323, -0x1.007129d6519a8p+5, 860055996966095937, -0x1.8fa742d9d8abep+5, 8116031199702340492, -0x1.2e896c76f3fd8p+3, -3751792011146389728, -0x1.4a66b5a7ea858p+5, 6250657440629901343, -0x1.7e848a07bb9c5p+5, 4663574053055225240, -0x1.e558f94b0f992p+4, 6707007865128439334, -0x1.226fab4538791p+4, -4445166152671219617, -0x1.7c0ab4b91150ep+5, 4765646746810409789, 0x1.ef9b775411db8p+4, 2063672483915351739, 0x1.445a9fc1ba218p+2, 6758075718086150802, 0x1.092f987fcc26p+5, -7119625559893119323, -0x1.44c89b6d9aaa7p+4);
}

void call_f403(void)
{
  f403(-4625048762028647228, 0x1.929339893fd2cp+4, 6433631088760665948, -0x1.8ff6941c7ae3ep+5, -8341337005941817067, -0x1.882b4b9513002p+5);
}

void call_f404(void)
{
  f404(-8987929280055585587, -0x1.a167011062f7p+4, 7558641433951593941, 0x1.605cfe6f2619p+5, 9149640156914079572, -0x1.923497ef55238p+3, 7658198411043359483, -0x1.14105d40c0335p+5);
}

void call_f405(void)
{
  f405(-6008777600803747664, -0x1.4dd679b0293bp+4, -4901105254789267610, -0x1.7c34b41d25daap+5, -721974744206171562, 0x1.79a16cfd83bdp+4, -5044536763345915899, 0x1.9c87c763f1768p+3, -6845676587911458370, 0x1.a7eec567cf20cp+4);
}

void call_f406(void)
{
  f406(-7588476048231447857, 0x1.fff9327c44418p+4, 617801188719895415, 0x1.cab54f8415bcp+3, -8085561860157116493, -0x1.e8a8a4205cdccp+3, -6828828271868115716, -0x1.2f2b60c19e854p+5, 7256277085474007404, -0x1.4aeb7a8435c71p+4, -1059675880031231840, -0x1.7a2c41cb3bbb5p+5);
}

void call_f407(void)
{
  f407(5553857602003537301, 0x1.219cf397d59c8p+5, 994864204345752339, -0x1.7ad8f071a8aebp+5, 1357252131386745770, -0x1.51fa23bcd76b6p+4, 2823685967218127767, -0x1.81fd854c3745cp+3, -1300203100998322180, 0x1.34fa0981f7424p+3, -8203356174116463521, 0x1.e21b86cd0d274p+4, -4529103705281940574, 0x1.a051d5615e77p+3, 679711078956748442, -0x1.2455d5f34a34ap+5);
}

void call_f408(void)
{
  f408(1430938460784409464, -0x1.43198e11a29cp+0, -6918819636519950565, -0x1.4750be4b52638p+2, 8808741416378523984, -0x1.757044381618cp+4, -9062693905658193502, 0x1.0d0771250a968p+3, 6922289907895192522, 0x1.7b0e7cf18b8a6p+5, 6736159199818820134, -0x1.7b8a39e94ffc5p+5, 3804863710728130390, 0x1.c3b68f89f213p+1, 3425271500340453564, -0x1.1aa938749d43cp+4, 6607136313231776489, -0x1.a36aab875b86cp+4, -3223619728753880241, -0x1.6742262a4716cp+5, -2313296692970981738, -0x1.05ccf3165fef8p+3, 6958396398726172637, 0x1.41e81e7962ef6p+5, 6731360964491445388, -0x1.8121ca36360e8p+5, 8862774766736992880, -0x1.1cc1326ebbe5p+4, 7967132031159789466, -0x1.105df58e9e4c6p+4, 474948951647905664, 0x1.92919420fb784p+4);
}

void call_f409(void)
{
  f409(-0x1.463a0e71ef418p+5, -0x1.9c30b65a4abep+1, -0x1.837826228c497p+4, -0x1.0694ffa0efd72p+5, 0x1.29ee8291a959cp+4, -0x1.43d2dd2222668p+5);
}

void call_f410(void)
{
  f410(-0x1.069d7e9ed79e8p+5, 0x1.cf5df887a93ep+4, 0x1.a2ac3e32cd948p+4, -0x1.2931f617bf10ap+5, 0x1.fec821807e198p+3, -0x1.01a746115924ep+4, 0x1.fb85b8329e898p+2, -0x1.c3413dc8ec97p+1);
}

void call_f411(void)
{
  f411(-0x1.0408648cb2354p+4, 0x1.308b1f9934adcp+5, -0x1.206f212ba35cap+5, -0x1.1e1e7f665f6bbp+5, -0x1.9dd597be97515p+4, 0x1.1409686f6f9d8p+5, 0x1.b4bdbb9760aap+3, -0x1.fac8803ac1315p+4, 0x1.c6beca9eb01e8p+3, 0x1.154938607fef8p+4);
}

void call_f412(void)
{
  f412(-0x1.57f3214b49cdbp+5, -0x1.1e8e8a4a5ee12p+5, -0x1.bb5911e8256ap+1, -0x1.5b70468d78adcp+3, 0x1.8c8aad5b936a8p+3, -0x1.7cfd69f57dc8p+1, 0x1.426b6180e1fdcp+4, -0x1.03abf4a058278p+5, -0x1.20e917785bbefp+4, -0x1.634723c01f15cp+3, -0x1.bde1b0bcac426p+4, -0x1.0042d11c911e7p+5);
}

void call_f413(void)
{
  f413(0x1.0815ae37fa164p+5, -0x1.ba39055834b1bp+4, -0x1.964d5d1074f23p+4, 0x1.e501c2414e87cp+4, -0x1.2daa8ee58826cp+3, 0x1.c91d778ca7ac8p+2, 0x1.0b4134ab1232p+4, -0x1.7fa07f9f1943cp+5, -0x1.3ba41717ea63bp+4, 0x1.32ab21f0508d4p+4, -0x1.4a227d2236d47p+5, 0x1.3a92c1894175cp+5, -0x1.142f0e861a28ep+4, 0x1.45799d9f2727ep+5, -0x1.08935b5b6a094p+4, 0x1.f048834ea61c8p+3);
}

void call_f414(void)
{
  f414(-0x1.4e4e7f893f75dp+5, -0x1.f99f782775618p+2, -0x1.3db9e1799b71p+5, -0x1.1e97876222d98p+4, 0x1.f464296dee01p+1, -0x1.45e825adeac28p+3, -0x1.18b5a1e4c94dap+4, 0x1.1ceeaa7fcb38cp+3, 0x1.18204deec6e5ap+5, -0x1.ccf599f7f7c38p+3, 0x1.f0575c2d6eca8p+3, -0x1.d2fe3d1e5b01p+3, 0x1.3333c0fbf7f8ap+5, -0x1.0bdf6bdade8b9p+5, 0x1.2432c460c23e8p+5, 0x1.3d0114d9d2608p+2, 0x1.79925391191b8p+5, 0x1.6d3fd21cf7ep+0, -0x1.aac21c4e0651p+1, 0x1.d4d72634889ep+4, 0x1.ed96061217438p+3, -0x1.2dbd9fc6c123cp+4, -0x1.c5de007cb3ea7p+4, 0x1.f3a24ea439cep+2, 0x1.e936ff0ae08c8p+3, -0x1.06547be6370f2p+5, 0x1.54b1bcf75f30ap+5, -0x1.61df4c9b62b5bp+5, -0x1.a6f8e276358p-2, -0x1.4c9937eb589aep+4, 0x1.e8df4468678e8p+3, 0x1.bfdca90c2a3p+0);
}

void call_f415(void)
{
  f415(-2110890493, 5924198326309439683, -0x1.79630c9b238b8p+3, 0x1.c2e717265b38p-2, 716574760, -4759906004936192865);
}

void call_f416(void)
{
  f416(1433481649, 1606306312240853647, 0x1.d1c9031442de8p+4, 0x1.57035aed5e594p+3, 502332839, -4834899154163803824, -0x1.cd2fc6f103a28p+4, -0x1.d6ccce8679588p+3);
}

void call_f417(void)
{
  f417(-1071332774, -5530444281749552333, -0x1.6e5e1762b2295p+5, 0x1.02ad110d063a4p+5, -115286341, -598347636197685714, 0x1.336176744f4p-2, 0x1.52b8bc651d2d8p+5, -258550597, 1703560940339619483);
}

void call_f418(void)
{
  f418(1731576349, -142512853985259733, 0x1.34236a13b97b4p+4, -0x1.eba235df942cbp+4, -947902216, 5332257013602231417, -0x1.826a7d6c52a57p+5, -0x1.1a8d59c1fe8b8p+4, 463464297, -7599301478246900207, -0x1.c9c0f69826d2p+3, 0x1.0e5925298ca9p+4);
}

void call_f419(void)
{
  f419(-1890241325, 2630943682798004567, 0x1.61b1a6d886488p+4, -0x1.34ff82c36c14ap+5, 597978649, 2161353340787579254, 0x1.fa0bf7342f1p+4, 0x1.4064236513c88p+5, 1513625428, 1397943766896039433, -0x1.76ee012652881p+5, -0x1.20251c563d6ep+1, -1786874502, -5317524468545326241, -0x1.8a9a3670fa46p+2, -0x1.191bd128d1634p+5);
}

void call_f420(void)
{
  f420(959675783, 1196041243376320773, 0x1.0a72f513b46dap+5, -0x1.cbe643b36ad04p+3, 1123302514, -6718510740770238895, 0x1.002834459e968p+5, 0x1.f0d345e879478p+3, 1641225881, -5572241851790438625, -0x1.0e0750729e98p+3, 0x1.3fa8f1e5b895cp+4, -63478716, 3467414303472329434, -0x1.d84a7bb8248p-1, 0x1.6be3ace6af198p+3, -270024581, 6017685922514238267, -0x1.ccc22f45039acp+4, 0x1.1a551b768cabp+5, 1877570176, 4346389735073521158, 0x1.4ee12ebf46a28p+5, -0x1.f80ae605dec22p+4, 2050124089, 7082638387698057430, 0x1.927e25d6bb34p-1, -0x1.7fef1e10fc643p+4, -148676762, 7530344175266096969, 0x1.516b79b5d0ddcp+4, -0x1.15cb866980f03p+5);
}

void call_f421(void)
{
  f421(-1015869374);
}

void call_f422(void)
{
  f422(1240232142, "ub", -1647534744, -0x1.4094cedef0975p+5, -0x1.8a79ec82693ap+4, 0x1.39641bb0470d4p+3, -0x1.618a5614a557cp+5, 0x1.4edf186cead8p+1, 0x1.fe9a5b7ee898p+1);
}

void call_f423(void)
{
  f423(-8665413124681905845, -1434207296, "");
}

void call_f424(void)
{
  char * r = f424(0x1.2bca63c697988p+2, 0x1.8bc702c34bba8p+4, 3239818990999700158, "s", 992036704999165499, -0x1.d08257695f634p+3, 0x1.bcd3ae4af3e9p+3, -1493525618);
  ((strcmp(r, "nu") == 0) ? (void)0 : failure("strcmp(r, \"nu\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2136,__func__));
}

void call_f425(void)
{
  f425(-980612814, 0x1.3917823ee2f56p+5, "tg", -0x1.d5bae22c76912p+4, 91017471, 0x1.483dd620f6f1p+5, "iz", -0x1.6d6199381f1a6p+5);
}

void call_f426(void)
{
  f426(0x1.15c33c22e6478p+4, 1754775007698874349, -656432153);
}

void call_f427(void)
{
  long long r = f427(0x1.f7daae2570258p+4, 6303598955662405784, -0x1.9d7b888770df9p+4, 207824772, -1802915835, -0x1.bea5a4cfa5fap+4, "j", 1388970980, -1339300442168892344, "q", -872114698);
  ((r == 4882742375719656158) ? (void)0 : failure("r == 4882742375719656158","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2152,__func__));
}

void call_f428(void)
{
  f428(-0x1.d6fe29b3a6838p+3, -0x1.f4dbddc0309e4p+3);
}

void call_f429(void)
{
  int r = f429(6631361243123345453, -0x1.e311eb947f6bcp+3);
  ((r == -1567837711) ? (void)0 : failure("r == -1567837711","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2163,__func__));
}

void call_f430(void)
{
  f430(-1577972474, -0x1.e4787e17fb398p+4);
}

void call_f431(void)
{
  long long r = f431("lr", 7824883241317064450, -3471128067833059549, 1632927412, 1888537793, -607764353, -0x1.5123afcd7ecddp+5, 8400627593300028090);
  ((r == -4147257517354942497) ? (void)0 : failure("r == -4147257517354942497","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2174,__func__));
}

void call_f432(void)
{
  f432(0x1.17a4f199b3c22p+5, 0x1.64786a609792ep+5, -0x1.150da8287b7fp+4, 1410379071, -2413400064731809023);
}

void call_f433(void)
{
  signed char r = f433("");
  ((r == -105) ? (void)0 : failure("r == -105","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2185,__func__));
}

void call_f434(void)
{
  f434("w", -0x1.bb34aec5bf548p+2, "w", 0x1.0f10bd11171bap+5, "l", 0x1.7d81662ac4c14p+5);
}

void call_f435(void)
{
  unsigned char r = f435(-3908210990047860652, -444129001, 0x1.7c9bf3c5d174p+5, 0x1.cf4481c9e326p+0, 0x1.5754f0fd42778p+5, -8656765496303253453, -0x1.bda299b2a4c8cp+3);
  ((r == 36) ? (void)0 : failure("r == 36","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2196,__func__));
}

void call_f436(void)
{
  f436(0x1.771ef96549efcp+4, -2494910827047751660, -0x1.00887c8e99507p+5, 610850475, 0x1.ceeede4b67b38p+4, 0x1.a20843fb2fcep+2, 5605729385131691151, "p");
}

void call_f437(void)
{
  f437();
}

void call_f438(void)
{
  long long r = f438("", "", -202109029, -0x1.afb3efe66f87dp+4, "be", "", 0x1.fe63cd903e60cp+4, -0x1.5577fe70d93cfp+4);
  ((r == 7293006492954305425) ? (void)0 : failure("r == 7293006492954305425","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2212,__func__));
}

void call_f439(void)
{
  f439(-0x1.62e35341ee55p+5, -201176859960062916, -1486954930444078655, "nc");
}

void call_f440(void)
{
  int r = f440("s", "im", 1685469183, "", -0x1.9af4e3c25f34p+1, 0x1.0c86943b381dcp+4);
  ((r == -1885287289) ? (void)0 : failure("r == -1885287289","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2223,__func__));
}

void call_f441(void)
{
  f441(-0x1.4f4952fbfa6a4p+5, -0x1.0852456454e52p+4);
}

void call_f442(void)
{
  float r = f442(-4574786867840467559, 741846488, "");
  ((r == 0x1.03ef1p+4F) ? (void)0 : failure("r == 0x1.03ef1p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2234,__func__));
}

void call_f443(void)
{
  float r = f443(-929955458, 8349241252947778100, -0x1.3dad23c499d94p+4, -598892263);
  ((r == 0x1.f28354p+2F) ? (void)0 : failure("r == 0x1.f28354p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2240,__func__));
}

void call_f444(void)
{
  float r = f444(-9168495147017343737, -1355844911, 6015696631526171849, -1126124554, 0x1.0846d8d3c0b5p+1, "z", -0x1.0fddabd28c37p+2);
  ((r == -0x1.505746p+0F) ? (void)0 : failure("r == -0x1.505746p+0F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2246,__func__));
}

void call_f445(void)
{
  short r = f445(-1840827060, "k", "n", -0x1.2ab06ce6df0eep+5);
  ((r == -27948) ? (void)0 : failure("r == -27948","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2252,__func__));
}

void call_f446(void)
{
  signed char r = f446(-2084858707348297909, -697335107, 814383526);
  ((r == -120) ? (void)0 : failure("r == -120","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2258,__func__));
}

void call_f447(void)
{
  float r = f447(1735041625, 0x1.6948eea20655p+4, 1324891379, -0x1.1b172a64237cap+5, 654583766);
  ((r == -0x1.9b2bc8p+4F) ? (void)0 : failure("r == -0x1.9b2bc8p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2264,__func__));
}

void call_f448(void)
{
  f448(-42462564, 0x1.6e425c1db6638p+5, 1484676499, "u");
}

void call_f449(void)
{
  f449(-0x1.391bb7bc54cddp+5, -0x1.6d16d43bbae44p+5, -0x1.d0ea678fef55cp+3, 0x1.0903abffd70dcp+3, 0x1.7925ba2296c84p+5, 0x1.b3e12b3703288p+2, -0x1.3fe9c072c2c18p+5, 533167569);
}

void call_f450(void)
{
  float r = f450(-0x1.391341a24e36p+3, "", 0x1.2dcd1548444d8p+4);
  ((r == -0x1.5da0aap+4F) ? (void)0 : failure("r == -0x1.5da0aap+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2280,__func__));
}

void call_f451(void)
{
  f451(0x1.68a7b7ae28ac4p+5, "", -0x1.341e360af4d38p+2, 1840099829, "nu", 0x1.f411a8128bd94p+4, 0x1.1fd572f18b34p+3, "k", -762088177, "mt");
}

void call_f452(void)
{
  double r = f452("sq");
  ((r == 0x1.a111163f62bc8p+4) ? (void)0 : failure("r == 0x1.a111163f62bc8p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2291,__func__));
}

void call_f453(void)
{
  long long r = f453(0x1.2825527ad5178p+3);
  ((r == -5630994881618525096) ? (void)0 : failure("r == -5630994881618525096","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2297,__func__));
}

void call_f454(void)
{
  double r = f454(0x1.fd32c258e89ap+1, 0x1.685e53e4bd28p+0, "x", 0x1.81394c1ff027cp+3, 7640738329126546128, 1921711578, 1413687500, -0x1.2fb75b9e1336p+3);
  ((r == 0x1.495776a3bc2d4p+4) ? (void)0 : failure("r == 0x1.495776a3bc2d4p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2303,__func__));
}

void call_f455(void)
{
  long long r = f455(0x1.53c1cceca1cecp+5, "", "", 1105934127044374804, 1178487668, -0x1.c045c9600406dp+4, 0x1.b5bf8f0f1886p+4, "zd");
  ((r == 4034204378606768929) ? (void)0 : failure("r == 4034204378606768929","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2309,__func__));
}

void call_f456(void)
{
  short r = f456(0x1.1a07c6e063594p+3, 0x1.69ddf90f0a4ecp+4, 553350536);
  ((r == 13967) ? (void)0 : failure("r == 13967","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2315,__func__));
}

void call_f457(void)
{
  int r = f457("u", -347972784, "", -0x1.7755d007502f6p+5, "wd", 485822856, "", "b", 74557069, 0x1.c86b3f7ba788p+3);
  ((r == 79873958) ? (void)0 : failure("r == 79873958","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2321,__func__));
}

void call_f458(void)
{
  char * r = f458(0x1.800ee55fb124cp+5, 0x1.13e8192013b0cp+4, 8554637079345217039, 1071096687, 0x1.6582c214dff48p+4, "pl", -0x1.6293037647113p+5, 750874870, "rm", -0x1.bd38b27c5b682p+4);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2327,__func__));
}

void call_f459(void)
{
  f459(-5140499923530184650, 0x1.4a04d372a1d94p+4, 0x1.c0892d7f9ee1p+3, 2072759926690125566, -1340815779, "g", 1957795903);
}

void call_f460(void)
{
  f460(-3062114765852251643, 7862760728161655281, "xx", -0x1.12f319566176cp+4, -0x1.30622adfe7cecp+5);
}

void call_f461(void)
{
  float r = f461(6795411416575975154, "", 1511438362, 0x1.80892bd29def2p+5, -0x1.512ab561469dp+2, -0x1.07d930a601b26p+4, 741615775782368756);
  ((r == -0x1.d0782p+2F) ? (void)0 : failure("r == -0x1.d0782p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2343,__func__));
}

void call_f462(void)
{
  short r = f462();
  ((r == 71) ? (void)0 : failure("r == 71","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2349,__func__));
}

void call_f463(void)
{
  f463(0x1.206f28184c2ap+2, -1247030131, 3921076818436752973, "", 543680408);
}

void call_f464(void)
{
  f464(0x1.8285c4a2afd4cp+5, "", "xy", 0x1.7c61065b4c158p+5, -1885775365, 0x1.6a29e22565bbp+5, 944568378017938066, "q", -884704395993618939);
}

void call_f465(void)
{
  unsigned short r = f465(0x1.302d7f0b5552ap+5, "ex", "", -405891427, 1227013684972181995, -1000186948);
  ((r == 24947) ? (void)0 : failure("r == 24947","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2365,__func__));
}

void call_f466(void)
{
  unsigned char r = f466(6857221878488582098, 1730962491, 291858990, -0x1.285250f0f064p+0, -4556768309803156686, -8323750441865572717, 7563523046052198818, 0x1.45a7fd9b45ebcp+5, 565771334, 677857933);
  ((r == 49) ? (void)0 : failure("r == 49","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2371,__func__));
}

void call_f467(void)
{
  f467(-7371333566673562632, 583842555, "z", -1007304995085823762, -1006666575, -2054288800049442669, 0x1.d8faaa8d6b8d4p+4, "");
}

void call_f468(void)
{
  char * r = f468(-0x1.1fb2c2627319bp+5, 8369459781745381848);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2382,__func__));
}

void call_f469(void)
{
  char * r = f469(-2276048252443342279, 9150293830039087051, 2847786057469800577, -0x1.2ff2ee82940e3p+4, -1410904197, -613597738, -0x1.a40fda48a38c2p+4, 0x1.7049f67ae2be8p+4);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2388,__func__));
}

void call_f470(void)
{
  short r = f470("", "v", -0x1.1f57d917e44cp-1, -355225065, "zu");
  ((r == -31464) ? (void)0 : failure("r == -31464","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2394,__func__));
}

void call_f471(void)
{
  unsigned char r = f471(-0x1.a740dd3fcaf98p+3, -0x1.d9548fc4e2f38p+4, "", 0x1.d8c302bd8a89p+4, 0x1.06d3d71d68a84p+4, 5178030567210428519, "f", "rv", -0x1.2badc17b9aafap+5, -9201690741735638843, 0x1.4220d1b278ff8p+3);
  ((r == 95) ? (void)0 : failure("r == 95","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2400,__func__));
}

void call_f472(void)
{
  double r = f472();
  ((r == 0x1.75c9708ad8f2ap+5) ? (void)0 : failure("r == 0x1.75c9708ad8f2ap+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2406,__func__));
}

void call_f473(void)
{
  f473(0x1.36efd51a0015p+2, 0x1.053a40caa8adep+5, 0x1.e550a8f061234p+4, 0x1.c5e5e28ecec3p+2, -0x1.ca56a21056a4p+2, -2038269283, 740970995396018880, 8983648937899378320, "", 82375094);
}

void call_f474(void)
{
  f474(-0x1.56c9294a9523dp+5, -0x1.789738018d85dp+4, "sr", "e", "mp", 5863210990172298808, -6433859347771378132, -0x1.1a8cea40ba71cp+5, "w");
}

void call_f475(void)
{
  f475(-0x1.697531db3f382p+5, 0x1.2007a26fd0fap+3, 734632501, -1776718043);
}

void call_f476(void)
{
  f476(-0x1.23591f74c6f4p+5, 0x1.2c530b3a7e8b8p+4, 0x1.20a8a29265cap+4);
}

void call_f477(void)
{
  f477(0x1.19991094e2f94p+5, 0x1.b6ccdba4e06bcp+4, -0x1.393aff1810992p+4, -0x1.b498132a2145p+4, 554256728);
}

void call_f478(void)
{
  f478(-5546593685724542983, 1557529550, 0x1.73954a446a7f4p+3, -610134774, -0x1.8acc86906bc38p+5, 474601067, 5140219771157459695, -0x1.796a5131c2fc9p+4);
}

void call_f479(void)
{
  f479(-406157722, -0x1.8c3d25ab41e81p+5, "", "", -120163677);
}

void call_f480(void)
{
  short r = f480("wy", "", "ii", -0x1.32d00afe4de1p+5);
  ((r == -24074) ? (void)0 : failure("r == -24074","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2447,__func__));
}

void call_f481(void)
{
  int r = f481("fp", -691244055, -5836704164269698999, "en", "z");
  ((r == -2034291514) ? (void)0 : failure("r == -2034291514","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2453,__func__));
}

void call_f482(void)
{
  unsigned short r = f482(-0x1.784e368506c5fp+5, -699188504, -69797352, "r", "u", "", 6115974265430917039, 0x1.0dd9c6dae8e3p+5);
  ((r == 17826) ? (void)0 : failure("r == 17826","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2459,__func__));
}

void call_f483(void)
{
  signed char r = f483(-0x1.90813e7cd54p-3, -8559449919500890771, -0x1.3acaceea434p+1, 0x1.7466fde17b0e8p+5, 0x1.82dd7e05ba3f4p+5, 0x1.0c850042eaa88p+2, "", 0x1.4272f6302093ep+5, -0x1.164f9ac52d234p+3);
  ((r == 76) ? (void)0 : failure("r == 76","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2465,__func__));
}

void call_f484(void)
{
  f484(-0x1.1115b5392147cp+4, 0x1.1154833b2a862p+5, 8074402528906806057, -0x1.0e6ed639c8bd4p+4, -6581396348517336836, 678693974, 5648445071552397209, "i", -0x1.11b236d49e86fp+5, -202730477, -1015740042);
}

void call_f485(void)
{
  f485(-0x1.6eac77401407fp+4, "n", -0x1.76a4af3015209p+5, -822569224, -1140254162, -0x1.1bd2793611cdep+4);
}

void call_f486(void)
{
  unsigned short r = f486(0x1.65bf069576fa6p+5, -0x1.329b0ad536029p+5);
  ((r == 19773) ? (void)0 : failure("r == 19773","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2481,__func__));
}

void call_f487(void)
{
  f487();
}

void call_f488(void)
{
  long long r = f488(1982355074, -8226104597427411864, 7212037341119110900, 1568395665, 3850483097003483709, -4729629598536269587, 1350046714922444323, "u", -0x1.ae4f68711a195p+4, -0x1.b678277efbf27p+4);
  ((r == -6696833607349658218) ? (void)0 : failure("r == -6696833607349658218","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2492,__func__));
}

void call_f489(void)
{
  signed char r = f489(-6083031235165151808, -0x1.b7c2278bca9d8p+2, "", -0x1.07989ec0e1a7fp+5, -1577994914, 0x1.7d3ac10de438cp+5, -0x1.ebc09598613c3p+4, 0x1.11da48df728fp+4, -0x1.fc3e1decabc1p+1, 0x1.021d99365b772p+5, 1796734586872829134);
  ((r == -74) ? (void)0 : failure("r == -74","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2498,__func__));
}

void call_f490(void)
{
  unsigned short r = f490(-0x1.39f13783ca6cap+4, "", "kq", -0x1.fc7df3321d308p+4);
  ((r == 37303) ? (void)0 : failure("r == 37303","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2504,__func__));
}

void call_f491(void)
{
  f491(598672269, "", -25494354);
}

void call_f492(void)
{
  f492(-0x1.3c7c776fee3b8p+2, -1571227546, -4220988618446108754, "cf", -3749192386323882200);
}

void call_f493(void)
{
  int r = f493("ju");
  ((r == -1778507848) ? (void)0 : failure("r == -1778507848","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2520,__func__));
}

void call_f494(void)
{
  double r = f494(-0x1.c8cf83d46c1fp+2, "hk", -0x1.73b3c831f2b51p+5);
  ((r == 0x1.0dad368c38f6p+1) ? (void)0 : failure("r == 0x1.0dad368c38f6p+1","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2526,__func__));
}

void call_f495(void)
{
  f495("", 1537968273, -1979311235326881472, -5046356730037506026, -1941449671, -1323387536, "", "", -0x1.9b24f8b40d8c9p+4);
}

void call_f496(void)
{
  unsigned char r = f496(4930723876875984894, 6728149016525499888);
  ((r == 37) ? (void)0 : failure("r == 37","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2537,__func__));
}

void call_f497(void)
{
  f497(0x1.7a4753a57458p+4, 0x1.bdd68e06f995cp+4);
}

void call_f498(void)
{
  f498(1263588789586192381, 0x1.553c44b9a3a92p+5, 7585625474220575992, 5044516665094899378);
}

void call_f499(void)
{
  short r = f499(-691346377, "b", "j", -0x1.f366d8137648cp+3, -2088607239);
  ((r == -32155) ? (void)0 : failure("r == -32155","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2553,__func__));
}

void call_f500(void)
{
  f500(-0x1.e739eed4e2febp+4, -5978515549021103399, -0x1.a931c084d973cp+4, 0x1.e2929e49ab02p+0);
}

void call_f501(void)
{
  f501(0x1.dcd1ef1687bb8p+4, -0x1.138c64bc879cbp+5, 6726969480207662671);
}

void call_f502(void)
{
  f502(-0x1.cc9930a715ep-2, -0x1.4f1e8baec37d1p+4, -3662036530195049473, 248111488226803363, 0x1.2bfcb9e250f9cp+5);
}

void call_f503(void)
{
  char * r = f503(8620113540353252415, -359665442, "m", -813287978, -769112149, 0x1.a1320dafbc6cp+3, 0x1.d84639e17f628p+3, -964960134609094679);
  ((strcmp(r, "v") == 0) ? (void)0 : failure("strcmp(r, \"v\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2574,__func__));
}

void call_f504(void)
{
  short r = f504("", 0x1.6c77fd726d1cep+5, 0x1.671ceb71ba6bep+5, -963430962267539169, -1181088795, -5001330557312489024, 8827927699516293700, -0x1.2ec42af8b5634p+4, 0x1.508a1e6e0dd3cp+4, 1087847233);
  ((r == 24504) ? (void)0 : failure("r == 24504","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2580,__func__));
}

void call_f505(void)
{
  short r = f505(-1159901027, "q", 1344049556, 0x1.45a8b3b4ddcc8p+5, -2423654873993082626, "v", 1372302887, 631722107, "z", -0x1.7dbf2f2bd7c53p+5, -0x1.12fcc80f397b6p+4);
  ((r == 22232) ? (void)0 : failure("r == 22232","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2586,__func__));
}

void call_f506(void)
{
  signed char r = f506("", 664964448235176070, 525194230);
  ((r == 57) ? (void)0 : failure("r == 57","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2592,__func__));
}

void call_f507(void)
{
  unsigned char r = f507(1510460026, "", 0x1.309acfd27ee18p+4, 0x1.0fb80e63a9fe4p+5, -0x1.6501d1dd535a6p+4, "c");
  ((r == 19) ? (void)0 : failure("r == 19","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2598,__func__));
}

void call_f508(void)
{
  f508(-1826718983, -6697401719643977335, 0x1.17831a688412p+1, 0x1.a1cc8392ba41cp+3, 99985050, 7913024228019345951, -0x1.ef16076d4db7fp+4, -0x1.0825b98d23579p+5, -950189906, 8377736854820771371);
}

void call_f509(void)
{
  f509(-2754611682361282393, -0x1.bb3f01cb3702cp+3, 0x1.45f2378584e32p+5, 0x1.29defdc91ab7p+4, -0x1.7ef621985b488p+3, 4750590659912102080, 0x1.73a5a70525138p+4, "jn");
}

void call_f510(void)
{
  f510("", -626664832, -0x1.4f9be7f60acb4p+3, -0x1.4198cc7c21f8cp+5, 919107122, -1615561359, 415547725, -7768693109037597206, -0x1.bec0d1c490038p+2, 2053107477993060124);
}

void call_f511(void)
{
  float r = f511(52872569, "h", 2803430017098964970, 5387534862508499325, -0x1.75032ebd2020cp+3, 4052324620907096610, -46740261, 0x1.d37fc2385632cp+4);
  ((r == -0x1.1749c2p+5F) ? (void)0 : failure("r == -0x1.1749c2p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2619,__func__));
}

void call_f512(void)
{
  char * r = f512(-0x1.a0d0e7f29556p+2, -0x1.828056a1a4a67p+5, 0x1.04328b8cc88d8p+2, 8286411263679033692, -0x1.0c9fa62c33e67p+5, -6391903976554194387, 0x1.8fb7cace0123p+1, 0x1.619ab81fc8f74p+4);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2625,__func__));
}

void call_f513(void)
{
  signed char r = f513("ma", -1014162939, 608579699, "l", 0x1.5eb4df82e901cp+4, -8661487909786712245, -8816152257797260499, -334350926, 566652504041925224, -892712483);
  ((r == 35) ? (void)0 : failure("r == 35","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2631,__func__));
}

void call_f514(void)
{
  f514(-527582443, "v", -0x1.6ded7abfe33e4p+5, "vs", "be", "y", "", 0x1.724173239bc64p+3, "e", -0x1.8027c7277032fp+5, 771880246);
}

void call_f515(void)
{
  f515("c", -4907293276569942723, -0x1.736d1a6047afdp+5, -8552430054028981559, -0x1.2a5c97c64500bp+4);
}

void call_f516(void)
{
  f516(0x1.8dc8b6233525cp+5, "", "k", -3230088412229579029, -0x1.5565e763a4208p+3, 4317372558597149592, "tv");
}

void call_f517(void)
{
  int r = f517("m", -461279435, -0x1.33a9bf9957abap+5, -0x1.46dd18615688cp+5, 0x1.0e0f802577518p+5, 0x1.6eb3fb9bc63aap+5, "n", -1796721022);
  ((r == -1252582623) ? (void)0 : failure("r == -1252582623","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2652,__func__));
}

void call_f518(void)
{
  f518(0x1.87ebf53733c28p+4);
}

void call_f519(void)
{
  long long r = f519(0x1.52245f2277b48p+3, 2039224081777953098, "dn", -4975445541805959130, -4682581940285213606);
  ((r == -6024073579480704461) ? (void)0 : failure("r == -6024073579480704461","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2663,__func__));
}

void call_f520(void)
{
  f520(594117695);
}

void call_f521(void)
{
  f521(0x1.511b3729cea1cp+4, "bb", -0x1.321b141c42699p+4, 0x1.7fb062416ddf4p+5, 756390340, 310222479, 4944139713862884875, -358113743, 853787389);
}

void call_f522(void)
{
  f522(0x1.73920278b74bcp+4, -2022097331, 1607956844, -0x1.5e81a34eda5b2p+4, -7974028319228599482, 1013553401);
}

void call_f523(void)
{
  f523(-0x1.06389ff9be76p+5, 8867666783332234338, -1058549665537082104, -2494377479410752542, 52272281, "j", -3883739186517850515, "gv", -0x1.21b37c1d22c88p+4, 0x1.90ad77478e0d8p+2, 3253394525880958574);
}

void call_f524(void)
{
  f524(0x1.80601d4e808ep+0, -4471488142621784991, -1985133508, 1525173756882330153, 0x1.6c5aa050b28c8p+2, -0x1.865973373bd68p+5, 0x1.6630688793c18p+4, -1315512781, -0x1.6816637d5e54p+4, 20507477, -0x1.ec3c3897fd37p+2);
}

void call_f525(void)
{
  f525(0x1.0f8c171956644p+3, 0x1.fbf94182dcf0cp+4, "tm", 1619776955, -0x1.2168579356d38p+5, 0x1.34172ce431154p+3, "qm", 4977780903326251522, 0x1.a417f499e8af4p+4, 2849690230756390761, -0x1.1ba6fc744bb98p+2);
}

void call_f526(void)
{
  unsigned char r = f526(-0x1.d3499a0607999p+4, -727368709358862763);
  ((r == 73) ? (void)0 : failure("r == 73","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2699,__func__));
}

void call_f527(void)
{
  f527(0x1.5c31655620ef8p+4, 1733646970, -0x1.192b540dc8f5bp+5);
}

void call_f528(void)
{
  f528(1051327808, 8896495890301113775, 0x1.273360c757842p+5, -1109099889, -253384857, -1203809056, "", -0x1.234043f613459p+5, 0x1.7213f43192a2p+1, 7517532879021348602);
}

void call_f529(void)
{
  f529("lg", -0x1.1e9697847b54p+5, 248067405, 1529258124);
}

void call_f530(void)
{
  char * r = f530(-8323744167675232247, 3539557, 0x1.2b898c769af48p+4, -0x1.c54a55c51ecccp+4, "", "");
  ((strcmp(r, "vs") == 0) ? (void)0 : failure("strcmp(r, \"vs\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2720,__func__));
}

void call_f531(void)
{
  f531(-0x1.897ec3f5eee35p+5, 0x1.6608cc57d8acep+5, -0x1.77d83fa40a0c2p+5);
}

void call_f532(void)
{
  unsigned char r = f532(-0x1.6b7b39a785432p+5, -0x1.9518562afe5c1p+4, 61376882, -7129689785282767157, "t");
  ((r == 2) ? (void)0 : failure("r == 2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2731,__func__));
}

void call_f533(void)
{
  short r = f533("c", -0x1.6aa11f911e2f8p+5, 0x1.36101244d597cp+3, 0x1.0d8d996ee7c5cp+4);
  ((r == 8845) ? (void)0 : failure("r == 8845","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2737,__func__));
}

void call_f534(void)
{
  f534(-1620928346, 7524473795724813784, -839017892, -0x1.4bdc330048eeep+5, -0x1.3ed35756a7bc6p+5);
}

void call_f535(void)
{
  f535(-0x1.773e1c7e18283p+5, -473758487, -0x1.3a0a17b43ccc4p+3);
}

void call_f536(void)
{
  f536(-3689935021998155578);
}

void call_f537(void)
{
  signed char r = f537(1398323741464381415, -0x1.8435838d609f6p+4, "qg", -8605761392389449299, -0x1.625723d7844eep+4);
  ((r == 32) ? (void)0 : failure("r == 32","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2758,__func__));
}

void call_f538(void)
{
  f538(-1061043664957308148, -5188058153224787100, -955839746, -1500036888, "of", 1224517765054574935, -1440297770, "zk", 858960512713830799, -0x1.1d107faf04177p+5, 0x1.66da11bea89bp+4);
}

void call_f539(void)
{
  f539();
}

void call_f540(void)
{
  float r = f540(-0x1.d97a857237c75p+4, 0x1.93382c0ade0cp+0, -0x1.869e2f82d8e9p+1, "cf", 1939102842, 0x1.259bdb9007ed8p+3, 0x1.4f16c4c7cac12p+5, 0x1.53aacbc09c0d8p+5, 0x1.3e81bddde188cp+3, 1737315470974778600);
  ((r == -0x1.ae2e9p+2F) ? (void)0 : failure("r == -0x1.ae2e9p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2774,__func__));
}

void call_f541(void)
{
  signed char r = f541(-6107247553883553599, -1187430870, 0x1.82b27944f7fb8p+2, 0x1.25635ea74aebcp+5, 3584888379560353437, 0x1.f9a52049c5ddcp+4, -7271757314634038136, 0x1.42af591e13e64p+5, -5259724462422026812, 1993371616088053228, -268846204);
  ((r == 14) ? (void)0 : failure("r == 14","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2780,__func__));
}

void call_f542(void)
{
  unsigned char r = f542();
  ((r == 193) ? (void)0 : failure("r == 193","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2786,__func__));
}

void call_f543(void)
{
  double r = f543(6092416632768946379, 0x1.7d1c1c9be7a4cp+4, 0x1.79173f8c9ea24p+3, 0x1.0b9667c4f4a2ep+5, -7028803195288194686);
  ((r == -0x1.7dc83d2aa4a8ap+5) ? (void)0 : failure("r == -0x1.7dc83d2aa4a8ap+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2792,__func__));
}

void call_f544(void)
{
  f544(-0x1.7a446c0a64b3p+2, -0x1.0120d2028ad2cp+4, 1991695855, 2022210740, "cl");
}

void call_f545(void)
{
  f545(-0x1.fd32caf752b8p-2, 701263490, -1193353038, -754944049);
}

void call_f546(void)
{
  double r = f546(-7353881956544791761, -0x1.84e2465fe8d32p+4, -0x1.0d5fab396fe5ap+5, 0x1.2bd858bba6cd2p+5, -0x1.73daead2dfddcp+5, -1136559164783185314, -101686533257630134, "", 0x1.7c11c5f4d302p+4);
  ((r == 0x1.7eef73f35cbe4p+3) ? (void)0 : failure("r == 0x1.7eef73f35cbe4p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2808,__func__));
}

void call_f547(void)
{
  short r = f547(-0x1.f9465d2492792p+4, 0x1.2f7a2203850a6p+5);
  ((r == 26922) ? (void)0 : failure("r == 26922","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2814,__func__));
}

void call_f548(void)
{
  f548(0x1.8d699f157f8p-6, "us", -0x1.65dba02303908p+4, "c", -966813187099612790, -0x1.796bd3b1c029ep+5, 0x1.009676984d8b8p+5, "", -2101710871);
}

void call_f549(void)
{
  f549("j", 0x1.04b71f3d12b46p+5, -0x1.076871a5514p-1, 0x1.30fb1e0389b8ep+5, "", 3416104647319543681, "hy", 6206777574884090205, 0x1.43645f4ffc4a8p+2, -0x1.f7c14a905e08p+3);
}

void call_f550(void)
{
  f550(-0x1.60dfc4b265e94p+3, 1329043803, 3584683022813771067, "");
}

void call_f551(void)
{
  f551(-248692641, 0x1.23bc0a350500cp+5, "td", -2065597432, -0x1.6a8c8833ec705p+4, -123928978, 1201511381, 0x1.daddecac8b424p+4, 976121653, 0x1.db202bd19605p+1);
}

void call_f552(void)
{
  f552("fp", -0x1.c3ebde182455cp+3, -1065251822184682022, 0x1.1fd18320d5ap+0, -0x1.362e6a4bb88bdp+5, 595987680625648363);
}

void call_f553(void)
{
  f553();
}

void call_f554(void)
{
  char * r = f554(328173379, 0x1.53db42a843bc6p+5);
  ((strcmp(r, "s") == 0) ? (void)0 : failure("strcmp(r, \"s\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2850,__func__));
}

void call_f555(void)
{
  f555(-0x1.91e8eff92cc58p+3);
}

void call_f556(void)
{
  f556(-0x1.8a2595ca2cbb9p+5, 1791038992, -1801134832682844197, "l", "my", 0x1.147c840300cd8p+2, -1836854489, -80879754, "");
}

void call_f557(void)
{
  short r = f557(-0x1.6a1ee34a1e40bp+4, 0x1.7aefaee9bf22cp+5, "wy", 7108726636692390957, "", "w", 0x1.f9915cfe44bd8p+2, 615671392, 0x1.7bd4839e9c5bp+2);
  ((r == -25300) ? (void)0 : failure("r == -25300","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2866,__func__));
}

void call_f558(void)
{
  f558(0x1.cc535593a37p-1, "", "ju", -855497432, -526359235, 7033283413284996910, 0x1.d798d4f755d6cp+4, -669039527848643395, -853485197148289335);
}

void call_f559(void)
{
  long long r = f559(1876995153, 478433905, -0x1.412a477812df7p+4, 114096267, -0x1.8412eadf5d43p+1, 918512718, 0x1.5babfca46e01ap+5, -561510178);
  ((r == 5018512878203312559) ? (void)0 : failure("r == 5018512878203312559","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2877,__func__));
}

void call_f560(void)
{
  f560(-0x1.d737d8479260cp+4, -0x1.83654aaec03edp+4, 586238580, -0x1.57693a3119eb4p+3, "", "mf", -7937690199877501642, -1367782567);
}

void call_f561(void)
{
  double r = f561(-13164507, -0x1.fc9ecd8e305b8p+3, -0x1.d6d6616c19045p+4, -1989578044, 0x1.7fd4194dca2bp+4, 1291740401, 0x1.0e10e51c40d3p+3, -0x1.6c0a15ba4a24cp+4, 0x1.80ab6e5cb4024p+5, 6006767172140742084, -7933281861204681482);
  ((r == 0x1.9317c8e4d4194p+4) ? (void)0 : failure("r == 0x1.9317c8e4d4194p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2888,__func__));
}

void call_f562(void)
{
  f562(8428144610430738939, 4262459113639870837, 0x1.143d3726d358ep+5, 0x1.899e209224fcep+5, 0x1.28e196c09438p+1, 7311003213175721503);
}

void call_f563(void)
{
  signed char r = f563(1234309900, "");
  ((r == -76) ? (void)0 : failure("r == -76","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2899,__func__));
}

void call_f564(void)
{
  f564(-0x1.fec47073dcbep+4, 0x1.04e8a513075bp+5, -0x1.dcb35aeae477ap+4, 2811174495189676234, 0x1.4ffbb48158bccp+4, 64359326072775618, -0x1.7e7694c66dcp+1, "sn", "d");
}

void call_f565(void)
{
  f565(0x1.70ae74466f658p+3, 368277356, 289923933, 6106546032584976700, "k", 1374300560, -0x1.352e1c4cbcd4ep+5, -240799484);
}

void call_f566(void)
{
  unsigned char r = f566();
  ((r == 62) ? (void)0 : failure("r == 62","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2915,__func__));
}

void call_f567(void)
{
  f567(6978604483068644444, "", -0x1.5c728527d77efp+5, 0x1.62912803413b8p+3, 6704474645156904863, "js", -0x1.f32f484afe38bp+4, 0x1.d3a25ac0893fp+2, 0x1.f6734dcb7bce4p+4, -0x1.65539524df50fp+5);
}

void call_f568(void)
{
  int r = f568();
  ((r == -136765204) ? (void)0 : failure("r == -136765204","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2926,__func__));
}

void call_f569(void)
{
  signed char r = f569(0x1.4a00f79a5b2eap+5);
  ((r == 105) ? (void)0 : failure("r == 105","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2932,__func__));
}

void call_f570(void)
{
  f570();
}

void call_f571(void)
{
  signed char r = f571(-0x1.da2abd49116b8p+3, "j", -2387678148920063269, "");
  ((r == 61) ? (void)0 : failure("r == 61","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2943,__func__));
}

void call_f572(void)
{
  double r = f572(0x1.cdecb9c53369cp+4, -0x1.6ef1b96e04808p+4, 0x1.efdbf7ec0f95p+2, 0x1.65ed5f1843094p+5, -0x1.5a8ba84fec668p+5);
  ((r == 0x1.8859b20a17efp+2) ? (void)0 : failure("r == 0x1.8859b20a17efp+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2949,__func__));
}

void call_f573(void)
{
  char * r = f573(0x1.96ff714565198p+4, "u", 0x1.5461bfe06918ep+5, -0x1.05e2ef5173f28p+5, -0x1.cb49d5c3887bbp+4, 2102608899);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2955,__func__));
}

void call_f574(void)
{
  signed char r = f574(-6487226970465101703, -0x1.6229e7b7353fcp+3, 0x1.16ef47c97690ap+5, 2067529404, -1929476764);
  ((r == -87) ? (void)0 : failure("r == -87","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2961,__func__));
}

void call_f575(void)
{
  short r = f575(-1188818329, 0x1.bbe659fbc33ap+3, "lo", 0x1.22d9afd015e14p+4, 0x1.929e5fe09c308p+4, -1943870514, -0x1.29fda03f53f7p+2, 0x1.65ea07f233ebp+1, -8640028402293863422);
  ((r == -8947) ? (void)0 : failure("r == -8947","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2967,__func__));
}

void call_f576(void)
{
  unsigned short r = f576(-0x1.6236cc2d45a68p+3, -4322798192665085918, -0x1.323d5200d129dp+4, "pb", -0x1.a0190116b8308p+2, -8528865572715881798, 2038727821, -8457734237494366509, "cq", 0x1.fd146560b078cp+4);
  ((r == 42748) ? (void)0 : failure("r == 42748","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2973,__func__));
}

void call_f577(void)
{
  f577(-0x1.b5e1913f93701p+4, -671370294, "io", -0x1.cb0422ea7c4p-1, 0x1.45de6753f56p-1, 0x1.d7977ba003434p+4, -0x1.b4507d971f08p+3, "d", -0x1.b6e0e00335f06p+4, 0x1.b784a6393bf88p+3, "np");
}

void call_f578(void)
{
  int r = f578(0x1.9cbdcc10a396p+2, -4469734996351914479, 5913172784525976162, "ac", -497964490111820241, 5780156002101510432, 0x1.80c4e2d4a3e3p+5, 0x1.5fe6a93905708p+2, 557174, 6546294627533504707);
  ((r == -90914645) ? (void)0 : failure("r == -90914645","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2984,__func__));
}

void call_f579(void)
{
  char * r = f579("", "");
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",2990,__func__));
}

void call_f580(void)
{
  f580(-0x1.479997c67fb39p+4, 0x1.74cc8e36112b8p+5, -1178665603, -0x1.6f3fbbbae3de5p+4, -0x1.713d06a6d1057p+5, -0x1.6d1871e7d3ca2p+5, 3522032378087610617, 0x1.2bd3eeec7aa6ap+5, "uk", -7055732739573761145, 804809727);
}

void call_f581(void)
{
  f581("", -0x1.cf73910c23888p+2, "e", 0x1.e0214cb391d84p+4, -0x1.3afba79c75f72p+5, 2899113414305591902, -244890149434916113, -0x1.02a7918b67408p+5, -8105517686113547038, "");
}

void call_f582(void)
{
  float r = f582(-0x1.317377105a265p+4, "h", 0x1.89eb0392e3dap+4, -0x1.b040d826ae194p+3, 2000264774, "r", "", "dl", 954296379);
  ((r == 0x1.529082p+4F) ? (void)0 : failure("r == 0x1.529082p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3006,__func__));
}

void call_f583(void)
{
  f583(0x1.1ce26aa8a328p+2, "", 1000887201, -5415049164684641419, "h", "e", 222337941);
}

void call_f584(void)
{
  short r = f584(0x1.043ebec3ea45p+4, -639424147, "n", "u");
  ((r == 2534) ? (void)0 : failure("r == 2534","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3017,__func__));
}

void call_f585(void)
{
  f585("hz", 0x1.1dab10a8a933cp+5, 3144701184001031377, -179494216, 1019342578353337666);
}

void call_f586(void)
{
  unsigned char r = f586(-0x1.86d7a0f774f3cp+3, 0x1.29f438eab8f0cp+4);
  ((r == 206) ? (void)0 : failure("r == 206","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3028,__func__));
}

void call_f587(void)
{
  float r = f587(-0x1.8cac3981eba19p+5, 0x1.ffe8c7e40d14p+3, -1822832947, "iy", 1383654419, -6009196197034523138);
  ((r == 0x1.54fd16p+5F) ? (void)0 : failure("r == 0x1.54fd16p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3034,__func__));
}

void call_f588(void)
{
  unsigned char r = f588(-672066508484807980, 0x1.0d97f76f89f18p+5, "e", 0x1.88904aa657adep+5, -3702065995274095582, 0x1.f97e973fa436p+1, -4546257682687061361, -0x1.315b6e33a907p+2, 0x1.54045fc46fb18p+4);
  ((r == 173) ? (void)0 : failure("r == 173","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3040,__func__));
}

void call_f589(void)
{
  f589();
}

void call_f590(void)
{
  f590(1647446815, -6193541702350543972, -0x1.c26ccea56d98p+0, -0x1.27c50b24dc51p+5, 0x1.5705c9c32577p+3, "nc", 1396577773, "dz", -0x1.2603da5fbc78cp+3);
}

void call_f591(void)
{
  f591(-0x1.47ef58393593p+3, "nj");
}

void call_f592(void)
{
  signed char r = f592(0x1.e178299c8b934p+4, -8636781894588509441, 2080628675, 0x1.0c83ea44ef2ccp+3, -0x1.4ecadd98eed12p+4, 1061570977, -0x1.af95c6183f3d2p+4, -0x1.217c61238a4ep+0, 0x1.8c86ba8e0da84p+4, "mk");
  ((r == -32) ? (void)0 : failure("r == -32","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3061,__func__));
}

void call_f593(void)
{
  f593(1223263787, -522320639, -0x1.5a519e64cc242p+5, 0x1.852ac825e9058p+5, -6679959592138048818, -0x1.8fd01e57c0408p+2, "o", -6580894557441556500, "");
}

void call_f594(void)
{
  unsigned short r = f594("", -36754431, "", "kt");
  ((r == 33833) ? (void)0 : failure("r == 33833","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3072,__func__));
}

void call_f595(void)
{
  char * r = f595(20689923, -6793204995839088479, 0x1.b89c22e9e4f68p+2, 1823197732795040851, -5342623837261931317, -3179585446669022524);
  ((strcmp(r, "ak") == 0) ? (void)0 : failure("strcmp(r, \"ak\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3078,__func__));
}

void call_f596(void)
{
  float r = f596(661188811);
  ((r == 0x1.4a84bap+2F) ? (void)0 : failure("r == 0x1.4a84bap+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3084,__func__));
}

void call_f597(void)
{
  short r = f597("", 715241575, -0x1.c940452cb8f4p+3, "", "", 0x1.8c0a1e83a7e22p+5, 1147229647);
  ((r == -30173) ? (void)0 : failure("r == -30173","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3090,__func__));
}

void call_f598(void)
{
  double r = f598(0x1.bb577cd55f728p+4, 5804960579956464227, 0x1.7cd21441ad878p+4, -0x1.ba4f63af9deb9p+4, 283919166, -0x1.c48b316dcfd53p+4, 0x1.31db3f1306ae4p+4, 1024358491);
  ((r == 0x1.0deabbef9a76ep+5) ? (void)0 : failure("r == 0x1.0deabbef9a76ep+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3096,__func__));
}

void call_f599(void)
{
  f599("");
}

void call_f600(void)
{
  int r = f600("g", -0x1.727c85f966d58p+3, -0x1.745dc01edf28bp+4, -0x1.405908500cbcbp+5, "ge", 428387906, -0x1.19f194a74c1fep+5);
  ((r == 2108828258) ? (void)0 : failure("r == 2108828258","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3107,__func__));
}

void call_f601(void)
{
  int r = f601(0x1.22175248e3aacp+5);
  ((r == -1994242441) ? (void)0 : failure("r == -1994242441","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3113,__func__));
}

void call_f602(void)
{
  long long r = f602(-4651413786473581743, -0x1.2b0f4e197b92ep+5, "");
  ((r == 6979294995977466608) ? (void)0 : failure("r == 6979294995977466608","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3119,__func__));
}

void call_f603(void)
{
  f603(0x1.4b506a80aea3p+5, 0x1.58f4e554576fp+4, 0x1.5b9fdefbb0b98p+5, 0x1.90c2dca287a98p+3, 6725733412238426186, -0x1.33a3529057478p+2, 0x1.1d79eb9831782p+5, 383753980, -0x1.de2b7baa744dcp+4);
}

void call_f604(void)
{
  f604(-0x1.d08f5455b12p-4, 441072712, 856357263);
}

void call_f605(void)
{
  f605("", -250837378, -0x1.8358c278bfbc1p+5, -0x1.58e8b4ca6726bp+5, 4123087585576314030, "", -7607916146038228202, -6771824141246043025, -8754731885722361916, -1875098857, 8472638601732504315);
}

void call_f606(void)
{
  float r = f606(-0x1.576f67139d0fcp+3, "hg", -1271933644624608232, -355198478, 0x1.a6df71722fcfcp+3, -0x1.e82ad9982be3p+3, "", "a", 5140410438253330899);
  ((r == 0x1.581676p+4F) ? (void)0 : failure("r == 0x1.581676p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3140,__func__));
}

void call_f607(void)
{
  unsigned short r = f607(-0x1.09e30bbd6916p+3, -1054843870, 0x1.5e26ade75e40ep+5, 4372544526439175886, -0x1.ba267aefc9b18p+2, -0x1.e7a2e539c913bp+4, 6145434359693148261, -0x1.0a9886aabe378p+5, -7073683458416284407);
  ((r == 61202) ? (void)0 : failure("r == 61202","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3146,__func__));
}

void call_f608(void)
{
  f608(-0x1.43946451b7cbbp+5, 0x1.df69f42b39f8cp+4, 7451405530300462992, "un", -0x1.5ec4aee59670cp+4, -686638696);
}

void call_f609(void)
{
  f609(0x1.4dd2a41b35a9p+4, -6314838181792323321, -365489945, -0x1.22a29edc406cp+4, "");
}

void call_f610(void)
{
  f610(1011388350, "ve", "jw", 3160242178770228362, -1166505584, -0x1.e4920dcebbf84p+3, -0x1.04d59dc9ddfp+2, -234701678, -0x1.2679a90ce906cp+3);
}

void call_f611(void)
{
  char * r = f611(-0x1.e87b3fffff5p-2, 6444370021550533112, -0x1.85d80fdf6983ap+5, "j", -1843885667625270636, "ap");
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3167,__func__));
}

void call_f612(void)
{
  char * r = f612(0x1.a6d211b16e26cp+4, -0x1.5761b0314aafap+5, "c", -1680481053, 0x1.1318b380889d8p+3, 3373796530957811749, "");
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3173,__func__));
}

void call_f613(void)
{
  float r = f613(0x1.6d5a2f4eb11fp+4, -0x1.e96d9e0608ebp+2, 0x1.33af72f32cb64p+5, -0x1.80693308cf091p+5, "fe");
  ((r == -0x1.04cac2p+3F) ? (void)0 : failure("r == -0x1.04cac2p+3F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3179,__func__));
}

void call_f614(void)
{
  f614(-2146486795, 1326287294608105708, 1657842945390348681, -1984348035, "lw", "", "r");
}

void call_f615(void)
{
  long long r = f615(691077784, 0x1.c090ccaf241e8p+3, "", 2160425362983490652, 100560592, "nj", -3433288070052020237, "", "", "h");
  ((r == 4985806275768597288) ? (void)0 : failure("r == 4985806275768597288","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3190,__func__));
}

void call_f616(void)
{
  f616(2737871326558314550, 663341417, "l", "ey", -6015583168144663709, "qc", -941426339155173482, -278545374);
}

void call_f617(void)
{
  f617("", "", 7306972208340649303, 0x1.7f5eb332c213ap+5, 0x1.d4113e1e531bp+4, 0x1.388b15de4fe6cp+5, -0x1.d1b0365a16f4cp+3, 1628637997);
}

void call_f618(void)
{
  char * r = f618(0x1.d7a8b33c5d44p-1, 1852878568987487711, "uh", -2640660287949457463);
  ((strcmp(r, "rc") == 0) ? (void)0 : failure("strcmp(r, \"rc\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3206,__func__));
}

void call_f619(void)
{
  f619(-0x1.d762067b259eap+4, 1275943182, -644024723);
}

void call_f620(void)
{
  f620(1624890013460032996, 0x1.26224b76aeba6p+5, "t", 0x1.25ed8594413bp+3, 4461390300839427587, 0x1.e7a5953cf9f9cp+4, 0x1.da088e415c9cp+1, -0x1.a6f16653ab9b7p+4, -0x1.2ba65766a7e06p+5, -8314938491221024549, 0x1.6f7d2eabfb984p+4);
}

void call_f621(void)
{
  f621(-3682061705242852838, 1464030997663272324, 0x1.b50132e46a628p+3, -8793789110595534137, -0x1.5f3cabf50d678p+3, -5706280082493837267, "", -2793853872888321768, "vm", 0x1.25ed7a6f1987p+5);
}

void call_f622(void)
{
  f622(-1866606684);
}

void call_f623(void)
{
  f623(0x1.364596fefb8p+4, 0x1.827983b35ba08p+5, "x", -5420219619867047354, -477050668, -366819612, 0x1.2c9eb18da7148p+2, 0x1.674325519c684p+5);
}

void call_f624(void)
{
  f624("", -0x1.fe910af30a37ep+4, 0x1.dd2c795626c18p+4, -9031198963589321964, 4326138230415157863, "z", 0x1.db58e6364cd8p+1);
}

void call_f625(void)
{
  f625(0x1.299f32bfba7b6p+5, 0x1.1da981be1d2p+5, 4221418338584319135, 0x1.2189500a1458p+1, 0x1.f13d5942571a4p+4, "qj", 0x1.ba1695458daacp+3, -0x1.5f652580a896bp+4, "tl", 1153298645289316560);
}

void call_f626(void)
{
  unsigned short r = f626(0x1.06763190e0dp+2, 0x1.106adf849bb84p+4);
  ((r == 6444) ? (void)0 : failure("r == 6444","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3247,__func__));
}

void call_f627(void)
{
  int r = f627(1812928875, -213920401, "", 0x1.8933edc72242p+5, "ok", 1001325934, -901563535, "", -1913824044, -0x1.176138f117c2p+1, 415709930);
  ((r == 410597311) ? (void)0 : failure("r == 410597311","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3253,__func__));
}

void call_f628(void)
{
  long long r = f628(-1010136654, 6987418178592761831, 0x1.a02b4b4be5c1p+1, -1253106241536373353, 0x1.e333674b08cbp+3);
  ((r == 2919225142824789557) ? (void)0 : failure("r == 2919225142824789557","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3259,__func__));
}

void call_f629(void)
{
  f629(7374410342318604943, -3410829991425784129, "y", 0x1.5ba716e73824ep+5, 743959999, -0x1.3b365d394f227p+5, 0x1.7c2daca90a574p+5, -3706722183241536999, -1804395782);
}

void call_f630(void)
{
  float r = f630(-0x1.5e1b1a6e93d63p+4, 616424224, "i", -1805784697, 515190876182715617, -0x1.6d82c349161b8p+5, -5612381956116404776, 1286099778);
  ((r == -0x1.8172a2p+5F) ? (void)0 : failure("r == -0x1.8172a2p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3270,__func__));
}

void call_f631(void)
{
  f631(-392511167, "jv", "", -716985395, "u", "", 1100663272, -0x1.8b320cf8ef1f9p+4);
}

void call_f632(void)
{
  float r = f632(-8925483899174900365, "", 0x1.6a24571126d4cp+5, -0x1.2d45d74afbca2p+5, 0x1.3b5dcefa97a58p+3, -1166732810, 0x1.7ca739ed46444p+3, 1440799273, -0x1.7d5a5061fbff8p+3);
  ((r == -0x1.88b404p+5F) ? (void)0 : failure("r == -0x1.88b404p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3281,__func__));
}

void call_f633(void)
{
  double r = f633(0x1.c186cb0eac5p-2, 0x1.9b0626b273f4p+0, 8803619334588561153, -895073124, 87285227, "", 0x1.3c5b17f7abe96p+5, -0x1.e1d59d02928a8p+2, "t", 80169928239179683, 0x1.17e63dc7511dcp+5);
  ((r == -0x1.7865a307cfab8p+2) ? (void)0 : failure("r == -0x1.7865a307cfab8p+2","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3287,__func__));
}

void call_f634(void)
{
  f634();
}

void call_f635(void)
{
  f635("cs", 0x1.7e3797c785e12p+5, -0x1.39ce2211b366ap+5);
}

void call_f636(void)
{
  f636(721030682315969090, -9002882471829477816, "", -0x1.0356e9fbdeda4p+5, -1531829680, "", 213748582);
}

void call_f637(void)
{
  f637(257034477, "x", -402030556);
}

void call_f638(void)
{
  f638(-31482340, -0x1.45125d2ed51e3p+4);
}

void call_f639(void)
{
  int r = f639(-735811671, "br", "fp", -0x1.57204ea415a37p+5, -6621485387607570811, -0x1.9dee936cd4014p+4, -349267266136703484, 9063278725064809328, "gv", "kz");
  ((r == 24018104) ? (void)0 : failure("r == 24018104","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3318,__func__));
}

void call_f640(void)
{
  f640(0x1.4654dfb1306cep+5, -2452123380446311748);
}

void call_f641(void)
{
  f641(-4907197581510418685, 1651806001, "tm", 0x1.ce9e724da144p+2, -535540722280560155);
}

void call_f642(void)
{
  f642(0x1.382e4f87c61p-3);
}

void call_f643(void)
{
  f643(2573554687282185598, 3494431209994382574, -262321080772358460);
}

void call_f644(void)
{
  f644("w", -7122082711786443347, "kz", 1127815057);
}

void call_f645(void)
{
  f645(0x1.159c8eb0370c6p+5, -0x1.f9d277662cec5p+4, 1109473262, 0x1.2fe769976ee34p+4, "h", "o", 0x1.07bf60a640a78p+4, "hv");
}

void call_f646(void)
{
  f646(1658991097, -922601002, -454079097059809050, 3521337281645937716, 8661343488704502164, -0x1.13a384838e032p+4, 0x1.b76c0fdf48f3p+4, 1950491693);
}

void call_f647(void)
{
  f647("");
}

void call_f648(void)
{
  f648(0x1.1ca05fafeeaeap+5, -0x1.0adc6519a6d02p+5);
}

void call_f649(void)
{
  f649(-0x1.1bf9e1d9ec208p+2, -88950668625353680, -175427726);
}

void call_f650(void)
{
  long long r = f650(156046783529380308, "", "", 0x1.6be4dc52c68c2p+5, 1657700695359116681, 6679380730827117933, -0x1.62a29410d269dp+5, -6164490098793787208, 3147609220359657188, -8038447891117919371, "");
  ((r == -2099031022923076293) ? (void)0 : failure("r == -2099031022923076293","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3374,__func__));
}

void call_f651(void)
{
  char * r = f651("ak", -1739094799, -271824525, -732045677, -0x1.8fe169cd34a2fp+5);
  ((strcmp(r, "w") == 0) ? (void)0 : failure("strcmp(r, \"w\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3380,__func__));
}

void call_f652(void)
{
  char * r = f652(1640182751, -1103692418744767008, -8610868504437457704, "b", 0x1.f3233307e787p+4);
  ((strcmp(r, "xs") == 0) ? (void)0 : failure("strcmp(r, \"xs\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3386,__func__));
}

void call_f653(void)
{
  long long r = f653(2680042224106538125, -14248543, "z", "");
  ((r == -2761618418451379101) ? (void)0 : failure("r == -2761618418451379101","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3392,__func__));
}

void call_f654(void)
{
  f654(0x1.4e18e184f3c6p+2, 0x1.42926e3c4137cp+4, -0x1.b3789e23f105ep+4, 0x1.5915dd9e7ccc4p+5, "b");
}

void call_f655(void)
{
  long long r = f655("b", 0x1.4d324967611fp+3, 1124005398, -5550380184391856595, 0x1.d5a1dc93c0bep+0, 466213520, -2820210030227968869, 2597474720408398161, 7918565000898428915);
  ((r == 2299891876988547765) ? (void)0 : failure("r == 2299891876988547765","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3403,__func__));
}

void call_f656(void)
{
  float r = f656("", 0x1.e8f88f4c25d5p+1, "ip", -8364395190729036746, 1401073037, 6458047051715120622, 0x1.465d0e473aa06p+5, -0x1.aff50d7e75208p+3, "", 973009646830365618, 0x1.57a43ec890efcp+4);
  ((r == 0x1.753194p+5F) ? (void)0 : failure("r == 0x1.753194p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3409,__func__));
}

void call_f657(void)
{
  f657(-0x1.52a99e313403ep+5, 723376230, -0x1.d1b7e95cde8dp+3, "", -6779394217995128306, -1308246211, -4427019453621036844, "", "g", -937675400, 134260537135894618);
}

void call_f658(void)
{
  unsigned char r = f658(1922521098585988945, "", -1934437900, 0x1.bd18742e01aep+0, -1914535239326376454);
  ((r == 253) ? (void)0 : failure("r == 253","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3420,__func__));
}

void call_f659(void)
{
  double r = f659(-0x1.1126f588174e1p+5, "", 0x1.7078c9d53b9c4p+4, 0x1.98d8732463448p+4, 0x1.1eb0c7b5045d4p+3, 0x1.4a4dc5dc38128p+4);
  ((r == 0x1.18ef99dc57782p+5) ? (void)0 : failure("r == 0x1.18ef99dc57782p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3426,__func__));
}

void call_f660(void)
{
  unsigned short r = f660(0x1.0ea1b705a4aap+4, -0x1.a507f060420fcp+4, -0x1.cf131679db376p+4, 4207542828300427714);
  ((r == 26018) ? (void)0 : failure("r == 26018","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3432,__func__));
}

void call_f661(void)
{
  f661(-0x1.72d04854d7244p+3, 0x1.cccee482b4a94p+4, -0x1.b9e0b470e7d2dp+4, -9003653671084911240);
}

void call_f662(void)
{
  f662();
}

void call_f663(void)
{
  unsigned short r = f663("z");
  ((r == 46275) ? (void)0 : failure("r == 46275","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3448,__func__));
}

void call_f664(void)
{
  f664(-657192802, 758998198);
}

void call_f665(void)
{
  f665(0x1.33dc0ecd877bep+5, "ac", -0x1.70ca33972b08bp+4, 0x1.1f4441e852f24p+5, "", -2085516630, 3185321189926806823, 0x1.c93657a1fea7p+4, 97702899, "vr");
}

void call_f666(void)
{
  f666(0x1.cc5925897abb8p+3, "ga", -5578757459018333728, 6594643821592793736, "");
}

void call_f667(void)
{
  f667(-5571789386906641658, 0x1.1c91bca401fc8p+5);
}

void call_f668(void)
{
  char * r = f668(-0x1.c69333e071dp+0, 0x1.010a48b07907p+4, 321924011, "", -1823994727, 0x1.def740763b02p+0, -0x1.45b28212085c2p+5, -6020577877959721464, -1073518671, -822163387, "");
  ((strcmp(r, "x") == 0) ? (void)0 : failure("strcmp(r, \"x\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3474,__func__));
}

void call_f669(void)
{
  signed char r = f669();
  ((r == 90) ? (void)0 : failure("r == 90","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3480,__func__));
}

void call_f670(void)
{
  f670(-0x1.83a5d1a79be0fp+5, 0x1.41833a5cfea4p+2, -0x1.080307fa1a09dp+5, -0x1.977d47fd6ee6p+1, 9215842884093907692, 0x1.6761eb3a92896p+5, 0x1.da953f3a0f3fp+4, "bc", 0x1.6ac8af6670d1p+5, -1343211364, 0x1.6ed2d843c6e8ap+5);
}

void call_f671(void)
{
  f671("", 7822038628949301765, -0x1.343ce6f1ed494p+5, "", -0x1.3a42fc17afdap+5, -0x1.7f5d224486169p+4);
}

void call_f672(void)
{
  long long r = f672("ph", -2839165031188514118, 107680420, 0x1.16c80bd07977p+4, "ah", 512265851, 0x1.d0a026d7b254cp+4, -782829879);
  ((r == 2830096809659467978) ? (void)0 : failure("r == 2830096809659467978","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3496,__func__));
}

void call_f673(void)
{
  f673("q", 4900081967001717422, 53761227, "", 225731355, 1976384321);
}

void call_f674(void)
{
  long long r = f674(0x1.b8936cc5c9e18p+3, "u", 0x1.0f6185dd9b984p+3, -0x1.bd0a586a8addcp+3, -3651739576773170887, 2018796669);
  ((r == -9144516666895674801) ? (void)0 : failure("r == -9144516666895674801","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3507,__func__));
}

void call_f675(void)
{
  unsigned char r = f675(-0x1.098e1c72c4b4ep+5, 0x1.25d102e213708p+2, -988451417, -1209340391, 7570057974671283611, "a", -0x1.0d1cd9a277648p+5, 8174651140489100427);
  ((r == 133) ? (void)0 : failure("r == 133","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3513,__func__));
}

void call_f676(void)
{
  signed char r = f676(0x1.a6332ed1048a8p+4, 4750280955996531018, 733057397, "ll", -0x1.58c562652e5c8p+2, 0x1.a6c82bbb1788p+4, 0x1.6aaca31f6bceap+5);
  ((r == 114) ? (void)0 : failure("r == 114","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3519,__func__));
}

void call_f677(void)
{
  f677(0x1.4a9d5ef8d3bp+2, -0x1.150360201fd84p+4, 0x1.0d0a37228a25cp+4);
}

void call_f678(void)
{
  f678(-0x1.c0e01fa3127d8p+3, "f", 8689003462595601756, 0x1.65ddb98b54208p+2, -656540893, -0x1.fc1ba17d51d44p+4, 0x1.6a5467cef479ep+5);
}

void call_f679(void)
{
  int r = f679();
  ((r == 1171175008) ? (void)0 : failure("r == 1171175008","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3535,__func__));
}

void call_f680(void)
{
  int r = f680("", "", -0x1.24db25e22a22fp+4, 1682076335, "u", 4402704071085339108, "d");
  ((r == -1698676422) ? (void)0 : failure("r == -1698676422","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3541,__func__));
}

void call_f681(void)
{
  f681(4478839833669253610, 6247072333298560943, "qz", 0x1.f9ba88972266p+4, -405935961);
}

void call_f682(void)
{
  signed char r = f682(-0x1.4f028874c3afdp+4, 0x1.2eafd6d4bc304p+5, -696310937192593567, 0x1.81f56a62b682ap+5, 4833801246695419283, -0x1.d201c39f5091cp+3, -5096875918908974670, "b");
  ((r == -93) ? (void)0 : failure("r == -93","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3552,__func__));
}

void call_f683(void)
{
  f683("wm", -5011995327023601448, 0x1.7538831bd70fp+3, -0x1.890324196ad36p+5, -0x1.e6f68341f8307p+4, -5464741362459437164, -0x1.7f09ea06f5ef2p+5, 6623064473180791821, -0x1.a531530826862p+4, -0x1.3865dac6cd207p+5);
}

void call_f684(void)
{
  f684(-0x1.b59caafde01fdp+4, "ay", 0x1.68bc56346891ap+5, -460809587, "kk", "o", 1550428113, -3265270614658774949);
}

void call_f685(void)
{
  f685(0x1.34121efe8db34p+4, 968918246, 0x1.79b26c20f2a28p+5, "xo", "", 0x1.1b4a41af4026cp+5, 0x1.de2a25bcc503p+4, 0x1.75ea337c1b0ep+3, "q", "l", -0x1.9a7c3642c1e41p+4);
}

void call_f686(void)
{
  f686(1144826049388598776, -0x1.96ee544e045edp+4, 0x1.3571403dd9d8p+4, 1889118866, "j", -2780089519800044462);
}

void call_f687(void)
{
  int r = f687(-1119155783, 0x1.2a1da5aaba408p+5, "m", -0x1.328bd15ff797fp+4, 0x1.e13544e12138p-1, "ky", -1931132488, -1981902166);
  ((r == -984917413) ? (void)0 : failure("r == -984917413","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3578,__func__));
}

void call_f688(void)
{
  unsigned char r = f688("c", 2850504136917469162, -0x1.59c514eca18a6p+5, "l", 0x1.9ae44cf4a31dp+4, -1763326749, 0x1.3d6018d90c21ap+5, 0x1.8e7bc9a64d424p+4, 5251974603605088227, 0x1.055098af41bcp-1);
  ((r == 205) ? (void)0 : failure("r == 205","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3584,__func__));
}

void call_f689(void)
{
  signed char r = f689(0x1.6338ff8216248p+5, -1857321782, -1858346008, -0x1.fd91cfce01e4bp+4, -4796693542923114781, -0x1.50bdee798b8e2p+4);
  ((r == 77) ? (void)0 : failure("r == 77","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3590,__func__));
}

void call_f690(void)
{
  int r = f690("kn");
  ((r == 2107419217) ? (void)0 : failure("r == 2107419217","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3596,__func__));
}

void call_f691(void)
{
  f691(-0x1.084fc53502fb8p+5, 0x1.6c41aa35e218p+0, -0x1.48655f3d86368p+3);
}

void call_f692(void)
{
  f692("sc", -619358086288791266);
}

void call_f693(void)
{
  float r = f693("zp", 2143000020, "xr");
  ((r == 0x1.e42026p+2F) ? (void)0 : failure("r == 0x1.e42026p+2F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3612,__func__));
}

void call_f694(void)
{
  f694("v", "z", -792596204, -0x1.7d0a20ed26c8p-1, "", 0x1.2955fef21f848p+5);
}

void call_f695(void)
{
  f695(3494315375049271052, "x", -7545481984853835281, -0x1.1d0b50e4013ebp+5, 0x1.f9f777cd73d7cp+4, 101426644266383714, -1552686791, 0x1.25fecf5c6df3p+5, -0x1.5f389c8460eeap+5, -602781272);
}

void call_f696(void)
{
  f696();
}

void call_f697(void)
{
  f697(-0x1.a27224df58583p+4, -0x1.485be0721214bp+4, 2064491316, 738626010, -2083580528, "", -1051521141164062127, 0x1.3cd1f8f3f9af4p+5);
}

void call_f698(void)
{
  f698(0x1.37efb38abcdc2p+5, -0x1.e3652561198aep+4, -8870679788652031637, -8574939730439535384, "n");
}

void call_f699(void)
{
  long long r = f699(-7376180305536731766, 0x1.714b74e50d50cp+4, 0x1.b392b2e3d36b4p+3, "h", 0x1.1cedcc4a03974p+4, -0x1.74a522e1b5a7p+3, 1576401914, 0x1.39f63cf79dd7cp+4, -6266582760155735617, "f", -494357883);
  ((r == 2371837968856802687) ? (void)0 : failure("r == 2371837968856802687","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3643,__func__));
}

void call_f700(void)
{
  f700("dh", 764628381, -8083161649322145816);
}

void call_f701(void)
{
  unsigned short r = f701(0x1.166ff57b507bap+5, 0x1.a386eb81db9e8p+4, -0x1.02e3459498b4ap+5);
  ((r == 1904) ? (void)0 : failure("r == 1904","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3654,__func__));
}

void call_f702(void)
{
  unsigned short r = f702(-7423856577700084903);
  ((r == 21442) ? (void)0 : failure("r == 21442","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3660,__func__));
}

void call_f703(void)
{
  f703("", -2044765118);
}

void call_f704(void)
{
  f704(0x1.ff1d09f1fedd4p+4, 0x1.e0e6721bdfd98p+2, -0x1.8ca676df69ba5p+5, "n", -0x1.b76fc2460d26p+2, "uz", 0x1.c6a87e90d8de8p+4, 401583619, "km");
}

void call_f705(void)
{
  unsigned char r = f705(0x1.b00b119de9db4p+4, -0x1.c32a105039d1p+1, -0x1.8a30cbad4ce42p+5, "", -208201576, 4700724359637073565, 296025486);
  ((r == 186) ? (void)0 : failure("r == 186","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3676,__func__));
}

void call_f706(void)
{
  f706(-666284138, "x", -0x1.f20c6d19a83f7p+4, "");
}

void call_f707(void)
{
  f707(-4771395930333343896, 0x1.20d3cfc3de2a8p+3, "f", -240396841, -0x1.c44326fd91d02p+4);
}

void call_f708(void)
{
  f708(0x1.6ed2004615798p+5);
}

void call_f709(void)
{
  double r = f709();
  ((r == -0x1.8afcc51e4dc68p+3) ? (void)0 : failure("r == -0x1.8afcc51e4dc68p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3697,__func__));
}

void call_f710(void)
{
  f710(-2026195856, "", 4214394447110180078, -5958836228855725351, -0x1.1f3a0356615b6p+5);
}

void call_f711(void)
{
  unsigned short r = f711("no", 0x1.5308507e3bda4p+3, 1472566389, 2129183519152010017, 0x1.64998d366ead8p+4, -1323026899, -2415317846140792682);
  ((r == 26030) ? (void)0 : failure("r == 26030","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3708,__func__));
}

void call_f712(void)
{
  char * r = f712();
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3714,__func__));
}

void call_f713(void)
{
  float r = f713(-0x1.f445a6941c038p+2, 0x1.4f8cb5d263996p+5, 0x1.28f741975d72cp+4, -0x1.d67d59918f044p+3, "m", "", -8291232492584418580, -6858658574779208092, -0x1.7235489f1c5e2p+5, -1288195121);
  ((r == -0x1.d24f48p+4F) ? (void)0 : failure("r == -0x1.d24f48p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3720,__func__));
}

void call_f714(void)
{
  char * r = f714(-0x1.0d4fd5feb922p+1, -343976392, -1749941223, -1079719014, "", -0x1.dac9e5e7d878p+1);
  ((strcmp(r, "jv") == 0) ? (void)0 : failure("strcmp(r, \"jv\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3726,__func__));
}

void call_f715(void)
{
  float r = f715(-428909306, "", "", 7181706216596319577);
  ((r == -0x1.21bc34p+5F) ? (void)0 : failure("r == -0x1.21bc34p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3732,__func__));
}

void call_f716(void)
{
  char * r = f716(0x1.c339dd8393d9p+3, -2098633458);
  ((strcmp(r, "vl") == 0) ? (void)0 : failure("strcmp(r, \"vl\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3738,__func__));
}

void call_f717(void)
{
  int r = f717(0x1.4675fa6b0c87p+5, -0x1.32709f6dfda7p+2, 545537380, -1594565747, -0x1.7239df9ce4db1p+4, -4403746134495228845, -0x1.d9cac77edf738p+4, "eh", -0x1.54add567cd667p+5, -295418997);
  ((r == -164880897) ? (void)0 : failure("r == -164880897","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3744,__func__));
}

void call_f718(void)
{
  unsigned char r = f718(-913669043, 0x1.82d13d0abc098p+2, "w", "xn", "xs", 7245759750714444307, -3626760882798210088, -1688016434);
  ((r == 46) ? (void)0 : failure("r == 46","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3750,__func__));
}

void call_f719(void)
{
  f719("");
}

void call_f720(void)
{
  signed char r = f720(-7302998367745747016, 0x1.2429b02458a62p+5, -68546152, -461655491113207654, -490600668167066820, -0x1.ae8264a333f6cp+4);
  ((r == -13) ? (void)0 : failure("r == -13","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3761,__func__));
}

void call_f721(void)
{
  signed char r = f721("ky", -1919451539907617005, -4020931826548225844, 0x1.d0b76d9507034p+4, 0x1.227889bcaaf4cp+3, "", -1099044011, -277461744);
  ((r == 59) ? (void)0 : failure("r == 59","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3767,__func__));
}

void call_f722(void)
{
  f722("wb", "w", 4186064088710404635, -628411715, 231572965, 0x1.cdb860a71dcd8p+3, "e", 0x1.16c78da8bf6f4p+4);
}

void call_f723(void)
{
  double r = f723("", 0x1.98a397d3a8e48p+4, 276732313);
  ((r == -0x1.29d1c6e9f58p-4) ? (void)0 : failure("r == -0x1.29d1c6e9f58p-4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3778,__func__));
}

void call_f724(void)
{
  long long r = f724(0x1.7ddc4d0c53cp+4, -1389139239892506449, "", -1920393367, 0x1.89b1c9feb0e3cp+5);
  ((r == 531025132759234563) ? (void)0 : failure("r == 531025132759234563","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3784,__func__));
}

void call_f725(void)
{
  unsigned short r = f725("og", 0x1.6a869988e83aap+5, "q", 0x1.2d8f7cf0b58bp+4, -777167050);
  ((r == 44943) ? (void)0 : failure("r == 44943","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3790,__func__));
}

void call_f726(void)
{
  float r = f726(-0x1.83535fbd33534p+3, 0x1.57bc4ea3f1374p+3, -8670558370469767670, "", 0x1.a5abd525e59d8p+3, -0x1.0490e851afc58p+5);
  ((r == -0x1.56f2bp+4F) ? (void)0 : failure("r == -0x1.56f2bp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3796,__func__));
}

void call_f727(void)
{
  f727("", 3597387870720388596, "", "", -9100642254613773564, "", -0x1.6b3ac0e9ad925p+4, -714025561, "", 6593047330670613933, 0x1.72f53ba241436p+5);
}

void call_f728(void)
{
  f728(-461484480248249345, 0x1.4f38bb2b7721p+5, -4967336260432716161, -0x1.812ba01a8c8e1p+5, -0x1.95292386e145p+4, -0x1.4b6b5abd153b2p+5, -0x1.6bd144acf59b6p+5, "h", -467336352232171551, -309587190);
}

void call_f729(void)
{
  f729(-42372531, 0x1.20ab6c0a2652cp+3, 0x1.27dd5e40a9b74p+5, "na", -4075351236231536785, "qp");
}

void call_f730(void)
{
  unsigned char r = f730(7031249241693917138, 0x1.029d36fcfd12cp+3, 425861138, 595938393, "", -0x1.2ee7054f6b8b5p+4, "t", "");
  ((r == 181) ? (void)0 : failure("r == 181","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3817,__func__));
}

void call_f731(void)
{
  int r = f731(818672954, 0x1.2e27408a7edfcp+4, "is", 4094309789082780794, 0x1.0839e877c0a9cp+5, -5699900513737073179, 0x1.5ef2ce7f2bda2p+5, 8699848388696650387, -0x1.750df46430523p+5, "b");
  ((r == -845257859) ? (void)0 : failure("r == -845257859","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3823,__func__));
}

void call_f732(void)
{
  f732(-7936177746241009067, 0x1.1309ca52c7198p+4, -0x1.09ff87e2e11e2p+5, "", -601191800, 0x1.232c8edd7b028p+4, -46389118, 0x1.bcddf96b16ccp+4);
}

void call_f733(void)
{
  int r = f733(-0x1.567b6059acd8p-1, 1836431751, "dt", "z", 0x1.a7b3771e79f88p+4);
  ((r == 1017531477) ? (void)0 : failure("r == 1017531477","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3834,__func__));
}

void call_f734(void)
{
  long long r = f734(-1435420103488812986, "en", 945649323, 504650794, -1594306678, 0x1.68378216be2ep+1, -0x1.dcfeba3339244p+4, -0x1.398be97a85693p+4);
  ((r == 6235321514747808804) ? (void)0 : failure("r == 6235321514747808804","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3840,__func__));
}

void call_f735(void)
{
  f735();
}

void call_f736(void)
{
  f736(0x1.13b0ee65dd7eap+5, 3560850157008858492, -1307429454, -0x1.b607074fc6135p+4, -2696263098524387465, -0x1.c64a602ab0e7fp+4, 0x1.c3c2a8f652c54p+4, -1971432245);
}

void call_f737(void)
{
  long long r = f737(-0x1.be8b1b899fd2p+1);
  ((r == -4289867085074861558) ? (void)0 : failure("r == -4289867085074861558","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3856,__func__));
}

void call_f738(void)
{
  f738("il", -18170578092968140, "", -7990156624476339288);
}

void call_f739(void)
{
  unsigned short r = f739(-0x1.2d008a711526ep+5, "jn", -1567491520469665108, 7886592798951736564, 1867458335, -1502016409, 7325215673044656214, -2166657887964084638, 0x1.b0477cb19cec4p+4);
  ((r == 59355) ? (void)0 : failure("r == 59355","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3867,__func__));
}

void call_f740(void)
{
  f740(-0x1.942bceb4166ep+0, -0x1.7270fe7f6d45p+2, 0x1.8ee74f735bbd4p+3, -0x1.5df94b804b4f4p+5, 0x1.a9d4e2a3c607p+1, -1571514110);
}

void call_f741(void)
{
  f741(-1759095417, -1206403139, -0x1.79c25f4d1d20fp+5, -0x1.cd01da537c496p+4, 1032990550, -0x1.c41f408786a2p+2, "wm", "t");
}

void call_f742(void)
{
  f742("", "c", 0x1.53b03677fe674p+3, 0x1.b739bb1f1359p+1, 387257426, -0x1.8107f428ac99p+1, -175526916);
}

void call_f743(void)
{
  f743(-8178753904396014556, -0x1.c8800835e2605p+4, -7076846071543095869, 0x1.5ac8e62d56552p+5, -1731415960);
}

void call_f744(void)
{
  unsigned char r = f744(-644535622, -1364192628, -0x1.403e4f64de898p+3, 62194362, -299507073, -0x1.c888b1b2bb75ap+4, -1254031691, 591600377083463078, -0x1.d8569c2d727f1p+4);
  ((r == 3) ? (void)0 : failure("r == 3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3893,__func__));
}

void call_f745(void)
{
  f745(0x1.058da97b036fp+1, 0x1.ec26cf64a5108p+4, "", 767616693, 0x1.4638b4916f61p+2, 0x1.ee89d975b4d6p+3, 0x1.46e91030ecdccp+3, 808813962);
}

void call_f746(void)
{
  float r = f746(-5564098697449360585, "rd", "lw", -2990167971635270760, "", 0x1.e0fbd85795c5cp+4, 776353019, "", "", "p");
  ((r == 0x1.cce302p+4F) ? (void)0 : failure("r == 0x1.cce302p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3904,__func__));
}

void call_f747(void)
{
  signed char r = f747(571478508, "", "n", 0x1.969dfe5477694p+3);
  ((r == -71) ? (void)0 : failure("r == -71","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3910,__func__));
}

void call_f748(void)
{
  signed char r = f748("", -0x1.1ec72b0c722f4p+3, -469275987, -0x1.7c197af6d27p+0);
  ((r == 11) ? (void)0 : failure("r == 11","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3916,__func__));
}

void call_f749(void)
{
  f749("sm", -5471388232951685900, -1824206262, "xr", -0x1.40f8f0ca769acp+4, 621839940, -1860519216, 1834437044);
}

void call_f750(void)
{
  f750(0x1.7c70b9f2dfa9p+5, "nh", 754018202, -0x1.61d269f2a60f7p+5, -0x1.4b1c5ff03b5b8p+5);
}

void call_f751(void)
{
  f751(0x1.cd1d7c7d45608p+4, "v", 1603556444, 0x1.2d3bb1a242aap+1, 0x1.bfade10763374p+4, "l");
}

void call_f752(void)
{
  f752(-0x1.41c84f10792c1p+4, -0x1.9b5467fdfd56ap+4, -0x1.70bcd4255cc6dp+4, -0x1.833c8f1f9be08p+5);
}

void call_f753(void)
{
  double r = f753();
  ((r == 0x1.2ff86914c0368p+4) ? (void)0 : failure("r == 0x1.2ff86914c0368p+4","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3942,__func__));
}

void call_f754(void)
{
  f754("", -1438594084, 0x1.918803162afcp+2, -766116400, -0x1.a46024eede87dp+4);
}

void call_f755(void)
{
  signed char r = f755(-0x1.9c981cd42395bp+4, 0x1.22185cea3523p+3, -1950283454, -0x1.7df2482de9d8ap+4);
  ((r == 43) ? (void)0 : failure("r == 43","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3953,__func__));
}

void call_f756(void)
{
  int r = f756(541772266, 0x1.85bf1c801ad8p-2, "", 1082491246);
  ((r == 2014074411) ? (void)0 : failure("r == 2014074411","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3959,__func__));
}

void call_f757(void)
{
  unsigned char r = f757(484416525, 0x1.16d03fe94c254p+5, "i", -0x1.0d68a00f2628p+2, 4169206621767172089);
  ((r == 7) ? (void)0 : failure("r == 7","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3965,__func__));
}

void call_f758(void)
{
  f758(0x1.1955523f04fp+2, 8310344355305523420, 0x1.e5ab3a8a98ab8p+4, 0x1.47b6e538d2416p+5, -0x1.46d8e78332141p+5, -0x1.939409fb156bp+3, -1520671528, -0x1.48b5b614ef1fdp+5);
}

void call_f759(void)
{
  f759(-1620016505, -6349788528149129095, "lw");
}

void call_f760(void)
{
  signed char r = f760(0x1.8ba12e0066342p+5, 0x1.3d1fc404465bp+5, "", "", 0x1.4cac437678464p+5, 4249666250919759945, "o", 5876123328478202475);
  ((r == 99) ? (void)0 : failure("r == 99","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3981,__func__));
}

void call_f761(void)
{
  char * r = f761(0x1.70fd5ebb18b46p+5, -0x1.4ad2af329de05p+5);
  ((strcmp(r, "lg") == 0) ? (void)0 : failure("strcmp(r, \"lg\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3987,__func__));
}

void call_f762(void)
{
  unsigned char r = f762(-112556469689314213, 0x1.5842d466d43a4p+5, -814646840, 151423322851051330, 1862431828);
  ((r == 87) ? (void)0 : failure("r == 87","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",3993,__func__));
}

void call_f763(void)
{
  f763(226230441, -0x1.35b9efbde358fp+5, 0x1.7fd4b98f713fcp+4, 0x1.7b1eb97351e4cp+4, 8915411899499230738, 6337645651338999556, "ip");
}

void call_f764(void)
{
  f764(-0x1.0c23f184f92a6p+5, 0x1.8cf709c975f18p+4, "l", "p", -576964012, 6974996503024177380, -0x1.389845e33ed01p+4, -547674395, 1116871844, 116033938);
}

void call_f765(void)
{
  f765(-0x1.30598bdd9e588p+2, 624950012, -0x1.53b27342479d8p+5, 0x1.6889035863a22p+5, 314313778);
}

void call_f766(void)
{
  f766(0x1.916ee697d09d8p+4, 8482715492362192915, 0x1.75ea462556ffep+5, -382155908849846081, 0x1.5679fd2debcecp+5, 3997940097955667033, 0x1.c2601b43698bp+3);
}

void call_f767(void)
{
  long long r = f767(0x1.82d55e60ca8b8p+2, 916043783, 0x1.eeac34d5a04e8p+2, -0x1.96e61e7cafa58p+3, -5521338882720881273, -0x1.8f198c1b5ffadp+4, -0x1.c5f620cbb193p+2);
  ((r == 1651289650223424365) ? (void)0 : failure("r == 1651289650223424365","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4019,__func__));
}

void call_f768(void)
{
  signed char r = f768(-6140177283195441627, -290907145, 6499948599412342196, -0x1.9a674a92f943cp+3, -0x1.34fc8e7b6aep+2);
  ((r == 60) ? (void)0 : failure("r == 60","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4025,__func__));
}

void call_f769(void)
{
  f769("x", -0x1.f5b9e2d0521cp+1, -0x1.521a34b02556p+2, -2195469846005911650, "", "r", 2050285094488922771, 2582965507208882820);
}

void call_f770(void)
{
  f770("", 733878790102082196, -0x1.7edf4f9e903f2p+4, -0x1.0333d62978c2p+1, "", "ro", -0x1.e6b56083feb0cp+3);
}

void call_f771(void)
{
  f771("ja", -8580452957776928631, 7551253078661079189, -3096887836211969871, -866300376, -0x1.8ffc20cca6f0dp+5);
}

void call_f772(void)
{
  short r = f772(0x1.268758dfb7b38p+4);
  ((r == 13103) ? (void)0 : failure("r == 13103","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4046,__func__));
}

void call_f773(void)
{
  f773(3746714279648075138, -7765691591148172923, "", "m", 0x1.ccb183052b1bp+4, 345655732, -1225501847, -1385858462, 0x1.59d07d4484344p+4, -5068816186302177969);
}

void call_f774(void)
{
  short r = f774(642316485, -4176953204287430749, 0x1.25b95feee4f1ep+5, -0x1.66392a38e98dp+1, -0x1.96ff1fa4985fdp+4, 945447832, "tg", -610881620);
  ((r == 327) ? (void)0 : failure("r == 327","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4057,__func__));
}

void call_f775(void)
{
  f775(-0x1.3b91f1a2b81f6p+5, 0x1.2dfd04ffb2af8p+4, "p");
}

void call_f776(void)
{
  f776();
}

void call_f777(void)
{
  double r = f777(1321363793);
  ((r == 0x1.a22f4f94f391p+1) ? (void)0 : failure("r == 0x1.a22f4f94f391p+1","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4073,__func__));
}

void call_f778(void)
{
  float r = f778();
  ((r == 0x1.eb64e8p+4F) ? (void)0 : failure("r == 0x1.eb64e8p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4079,__func__));
}

void call_f779(void)
{
  unsigned short r = f779(-2195258560322172453);
  ((r == 56684) ? (void)0 : failure("r == 56684","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4085,__func__));
}

void call_f780(void)
{
  f780(9159517181826829385, "xn", -144099797, "op", 0x1.3bd80b59ba924p+3, 483493017, "b", 2701097138697027612, -0x1.3998f85da331cp+5);
}

void call_f781(void)
{
  f781(-5383175227743470451, 2189022040572435127, "sw", -3356544786841404308, -0x1.9ab8ed49b8468p+3, -0x1.29f7d05ed5b48p+2, 7388660772947968617, 173731394);
}

void call_f782(void)
{
  int r = f782(1342095235, -0x1.5aba189b6e1dp+5, 0x1.8d9a70bda2fbcp+5);
  ((r == -1614640134) ? (void)0 : failure("r == -1614640134","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4101,__func__));
}

void call_f783(void)
{
  f783(3658730263521897646, -0x1.583cf6c23379p+2, -762252738820688586, -0x1.08cc38b41ab5bp+5, 0x1.420ab75e19b5cp+3, -0x1.dd89e8be48f9cp+4, -7698359155154004701, "", -4837571043377909583, -0x1.88c6b0ef10d91p+5);
}

void call_f784(void)
{
  f784(-586433137811365420, "ec", 0x1.a450f8d3a123p+4, 0x1.105380a4ce35ep+5);
}

void call_f785(void)
{
  float r = f785("o");
  ((r == -0x1.dfd0acp+4F) ? (void)0 : failure("r == -0x1.dfd0acp+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4117,__func__));
}

void call_f786(void)
{
  double r = f786("", 1134722767);
  ((r == -0x1.85240733e0911p+5) ? (void)0 : failure("r == -0x1.85240733e0911p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4123,__func__));
}

void call_f787(void)
{
  f787(-5089208056666740400, -0x1.0299adaacdep+1, "y", 0x1.22e071350790cp+4, 7825952741526164361, 0x1.30aac25c1d43ep+5);
}

void call_f788(void)
{
  f788("", -7315699486770342807, -2282836788059700974, 0x1.6e83d28845318p+2, -0x1.1e2ec1bb46ae2p+5, 3275105333968491987, -0x1.6115d2bdc5c3ep+5, 4532822945314332555, -0x1.b059a8bc7983p+1);
}

void call_f789(void)
{
  f789();
}

void call_f790(void)
{
  int r = f790(-1590757241, "", 0x1.52b3b9bc5da78p+3, 0x1.6eab768bf95d4p+3, -0x1.f0919d73ec5a8p+3, -543258928, 1554173480, -0x1.6c4a06b28688p+0, 0x1.aa76291e3e478p+4, "rv");
  ((r == 1109161288) ? (void)0 : failure("r == 1109161288","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4144,__func__));
}

void call_f791(void)
{
  float r = f791(-0x1.272312d5b1fbdp+5, 0x1.fd5123920ad08p+3, -0x1.e10c1252e5408p+2, -261216639, 0x1.0d6da7ac8c0d8p+3, "", -8280878902247320408, -0x1.07fda0d5e994ap+4, -1381252731, -0x1.0f42e6175597cp+4);
  ((r == 0x1.445604p+5F) ? (void)0 : failure("r == 0x1.445604p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4150,__func__));
}

void call_f792(void)
{
  float r = f792();
  ((r == -0x1.7c1706p+4F) ? (void)0 : failure("r == -0x1.7c1706p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4156,__func__));
}

void call_f793(void)
{
  char * r = f793(0x1.f67fefeaa6d18p+2);
  ((strcmp(r, "id") == 0) ? (void)0 : failure("strcmp(r, \"id\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4162,__func__));
}

void call_f794(void)
{
  long long r = f794(0x1.ff7526516d734p+4, 0x1.49f9d8c7d1adp+5);
  ((r == 779798107511314629) ? (void)0 : failure("r == 779798107511314629","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4168,__func__));
}

void call_f795(void)
{
  f795(-5064066873906159058, -2786278437797658304, "");
}

void call_f796(void)
{
  f796(-1064028575, -0x1.88ea028b7b252p+5);
}

void call_f797(void)
{
  f797(0x1.ba4228adcc9c8p+3, "x", 3823687016323376035, -949981575);
}

void call_f798(void)
{
  f798(-3298259187330559108, 981809093, -0x1.4c5dd1d7361b8p+5, -0x1.6ebdad3744483p+5, -0x1.4dafdc8136ep+5, "a", -0x1.175e131ae5ce7p+5, -1841168763, "");
}

void call_f799(void)
{
  float r = f799(1104355363, 0x1.26ef6f6274f38p+5);
  ((r == -0x1.9c00b6p+4F) ? (void)0 : failure("r == -0x1.9c00b6p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4194,__func__));
}

void call_f800(void)
{
  f800(-4438325502208871440, -0x1.2f4983803ebe1p+5, -0x1.2080bc6d1cf4dp+5);
}

void call_f801(void)
{
  unsigned short r = f801();
  ((r == 40142) ? (void)0 : failure("r == 40142","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4205,__func__));
}

void call_f802(void)
{
  f802(0x1.5c9c57a150d2cp+5, -7971007743378436273, -802622102, -1015063333, "f", "", 717880731, -0x1.59a3b73c9a9e6p+5);
}

void call_f803(void)
{
  f803();
}

void call_f804(void)
{
  f804(-1548073484, 971088147, 1310307708, "o", -1810631331);
}

void call_f805(void)
{
  f805();
}

void call_f806(void)
{
  long long r = f806(0x1.00f87e44d0a56p+5, 1431002145, 0x1.9632c89f79d98p+3, 1837631332, -0x1.2538e9e40ebcp+2, -0x1.5d383b57ac68bp+4, -0x1.e6667a7677d62p+4);
  ((r == -1196731127726268288) ? (void)0 : failure("r == -1196731127726268288","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4231,__func__));
}

void call_f807(void)
{
  unsigned char r = f807("", -1589761881, "im", 6838838319401205344, "sj", -7903661603535612455, 9003263696869382472, -1619565363, "r", -0x1.d8bf141020478p+2, -1364964126876223084);
  ((r == 110) ? (void)0 : failure("r == 110","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4237,__func__));
}

void call_f808(void)
{
  f808(-0x1.863576e9d657cp+4, 8117073938869951663, 0x1.d164a86b2df98p+4, -0x1.84a4fb0af78ffp+5, "xv", 141993168, -0x1.95c268164c398p+3, 0x1.7db732bc92b98p+3, 0x1.b72630ecfb5a8p+4, -347995018);
}

void call_f809(void)
{
  f809("tv", "b", 1486680866424042762, 0x1.0280449d5c108p+5, 0x1.30a330bddbc3p+4, 0x1.495f3bed0d7eap+5);
}

void call_f810(void)
{
  float r = f810(0x1.e05866031c0acp+4, 0x1.e6cd7b924cda4p+4, -0x1.3c1789ea35f8ap+5, -1072056760);
  ((r == -0x1.3207f4p+5F) ? (void)0 : failure("r == -0x1.3207f4p+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4253,__func__));
}

void call_f811(void)
{
  unsigned char r = f811();
  ((r == 192) ? (void)0 : failure("r == 192","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4259,__func__));
}

void call_f812(void)
{
  char * r = f812(-1770364705766099551, 8214329941618885868, 0x1.15cff22734fa8p+2, -0x1.58a5271c6e5dp+5, 1085092104, -0x1.6d328f98410ep+1);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4265,__func__));
}

void call_f813(void)
{
  unsigned char r = f813(1829450013869637312, 1092809248, 2071298591, 6752608868674379438, "eu", "di", "pg", -0x1.c8a257562179p+2, -0x1.3f42b2068256p+3, "lq", "");
  ((r == 155) ? (void)0 : failure("r == 155","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4271,__func__));
}

void call_f814(void)
{
  signed char r = f814(-8046525426970221834, -0x1.145a0ef6ea90ap+5, -0x1.63141a52b350bp+5, "h", 0x1.c3701a81e83p+4, -0x1.d255b073d742p+3, 0x1.9568487d22e74p+4, "", -0x1.897e9a54d5984p+3);
  ((r == -63) ? (void)0 : failure("r == -63","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4277,__func__));
}

void call_f815(void)
{
  char * r = f815(-0x1.feed409dcaa13p+4, 726982612, -874679864, -4826381314121441090, 0x1.268faf2f21cap+3, 120031615, "zt");
  ((strcmp(r, "v") == 0) ? (void)0 : failure("strcmp(r, \"v\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4283,__func__));
}

void call_f816(void)
{
  f816("");
}

void call_f817(void)
{
  short r = f817(-0x1.0db43bf9b907p+5, -0x1.3e72f09309597p+5);
  ((r == -4310) ? (void)0 : failure("r == -4310","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4294,__func__));
}

void call_f818(void)
{
  f818(0x1.777caf7acd0c4p+3, -548874152, "c", "s", "ic", -0x1.58f844d968ffap+4);
}

void call_f819(void)
{
  short r = f819(-1411809494, 5410897577737955533, 1500564103, -0x1.e499a342089acp+3);
  ((r == -9544) ? (void)0 : failure("r == -9544","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4305,__func__));
}

void call_f820(void)
{
  f820("s", 0x1.293c95f8bcc28p+4, -1766277041554936180, "xl", 403742771, 5201456196349807378, 0x1.f8f10446e045p+4);
}

void call_f821(void)
{
  f821(-0x1.72894accb8437p+5, "x", -1345273455, 6219540297639864963);
}

void call_f822(void)
{
  f822(-0x1.0f40411f892cap+4);
}

void call_f823(void)
{
  f823(-0x1.6ce2a8c604f2ap+5, 2008430727, -0x1.7c2802cd99e5ep+5, "zj", -69733286, "r");
}

void call_f824(void)
{
  f824(4034572877824064164);
}

void call_f825(void)
{
  unsigned short r = f825("v");
  ((r == 16297) ? (void)0 : failure("r == 16297","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4336,__func__));
}

void call_f826(void)
{
  f826(0x1.b526208f7798p-2, -3449321290575507291, -0x1.47dc405a2b576p+5, 5371107002236083960);
}

void call_f827(void)
{
  f827(0x1.6b04696e1881cp+4, 1812589243, -0x1.ad5d6cee41315p+4, -6832354984686082239, 0x1.7cf5ec48845fcp+3);
}

void call_f828(void)
{
  f828(-0x1.58b657974cf0dp+4, 244953010, "q", -0x1.0915d03d8283p+3, -0x1.7a2347b6e7e9p+5, "ad");
}

void call_f829(void)
{
  f829(-0x1.7661e3434d605p+5, "fv", -2425869244969490231, 4052350698377283552, 1351187923, -953636182, -3346768091876526334, -1301708619, -0x1.b05ff04838e9cp+3);
}

void call_f830(void)
{
  unsigned short r = f830(0x1.f09e71b2a05bp+3, "rw", "", "", -581389998, -8102496600985539800, 0x1.e2d28b8151e6p+3, "ev");
  ((r == 31625) ? (void)0 : failure("r == 31625","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4362,__func__));
}

void call_f831(void)
{
  f831(-0x1.2a183f7b52f2ep+5, "", -247483365999987242, 764537077410662, 6725424127452256704, "o", 0x1.3672a109a1284p+4, 692530128, 0x1.1262957c1894p+5, 0x1.71949b74214d4p+3);
}

void call_f832(void)
{
  f832(-3459792654184079361, -5101190882443680307, -0x1.101f48f604072p+4, 1480078745351155385, -0x1.b8c9a7c5c5b5p+2, 131239646152875578);
}

void call_f833(void)
{
  f833(-2676661765287544960, -2950463006323671709, "z", 0x1.ab326a1155394p+3);
}

void call_f834(void)
{
  f834(-0x1.2f09e5b707a1ep+4, 4337537870870156605, -0x1.d1f96d886adp-3, 2130713337298332517, 0x1.821c12167069ap+5, -0x1.06debece9f29p+3, -0x1.1287ddae7a4f4p+3, 81799896, 0x1.72bcf654534acp+5);
}

void call_f835(void)
{
  signed char r = f835(-520725076, -5523720437646673030);
  ((r == 16) ? (void)0 : failure("r == 16","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4388,__func__));
}

void call_f836(void)
{
  long long r = f836("", -625320957, 0x1.1aa9d4757bb7cp+4, "bs", 2027270162, -1145445923, -245139832763243504, -1991081556);
  ((r == -3375601568554227481) ? (void)0 : failure("r == -3375601568554227481","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4394,__func__));
}

void call_f837(void)
{
  double r = f837(0x1.839701acf1098p+5, -1139108323176646199, 4083867511713434942, -7757445142144787460, -0x1.0233101bcce8ap+4, -5028268041588923476, 0x1.0ead23053e27p+4, -0x1.c8cd53fbd2993p+4);
  ((r == -0x1.09e008c317889p+5) ? (void)0 : failure("r == -0x1.09e008c317889p+5","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4400,__func__));
}

void call_f838(void)
{
  signed char r = f838(0x1.6d963666dd2aep+5, "z", 1427610071, -0x1.57177ddae7b46p+5, "", 0x1.80bd182decd58p+2, "");
  ((r == 28) ? (void)0 : failure("r == 28","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4406,__func__));
}

void call_f839(void)
{
  f839();
}

void call_f840(void)
{
  f840(-0x1.5312beb49607fp+4, -0x1.30ac0642f4a1cp+3, -0x1.4cfd36181f6a1p+4, 0x1.18947556126e4p+5, -0x1.b271b9ac47d06p+4, -950896432);
}

void call_f841(void)
{
  f841("", 0x1.3c95ba4f09d64p+3, 0x1.c0c328ccbcfa8p+3, 0x1.8fb5a421a9564p+4, 1908975104, -105745093, 1090196921, "", -1454252246, -7292777206674232171, -0x1.0ebc232563afcp+5);
}

void call_f842(void)
{
  short r = f842(-0x1.8d05933b7ab2ep+5, "", -0x1.58e6a2c564ddp+3, 0x1.24c7473a01bd2p+5, 1448498223, -0x1.963d51479a13p+4, -5874616703280485656, 910208228928336757);
  ((r == 14304) ? (void)0 : failure("r == 14304","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4427,__func__));
}

void call_f843(void)
{
  f843("pf", -5359720914691890955, -107880661, 0x1.09191db9e3p+5);
}

void call_f844(void)
{
  unsigned short r = f844(0x1.7ed9ece57cd8ep+5, -8013775107814888734, "sg", 0x1.01eb78872446ap+5, 1224569730, 7774612738340171328, 2046414756, 0x1.15d6bd60bfdc6p+5, -0x1.45e98ca0d72cp+0);
  ((r == 29280) ? (void)0 : failure("r == 29280","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4438,__func__));
}

void call_f845(void)
{
  signed char r = f845(0x1.2f240463c4978p+4, 1922958182, 0x1.77ea6b74b717p+4);
  ((r == 69) ? (void)0 : failure("r == 69","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4444,__func__));
}

void call_f846(void)
{
  f846();
}

void call_f847(void)
{
  f847(-0x1.3b44dfe05a1bp+5, "sm", -611999151);
}

void call_f848(void)
{
  f848(-558405896, "", -1555328641, 0x1.0d8418e72bd6cp+5, -1079881638, "", 0x1.fe9fff48eb4e4p+4, -1570032224626514390, 861449493, -0x1.c06f83a90a99p+2, 526517187);
}

void call_f849(void)
{
  unsigned short r = f849("x", -0x1.6128e9b9c17eap+4, "b", 1138902070332422790, -0x1.f6fa6a2c62606p+4, "");
  ((r == 17783) ? (void)0 : failure("r == 17783","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4465,__func__));
}

void call_f850(void)
{
  double r = f850(0x1.0cf2a0c584594p+4, -803754728, 7124874);
  ((r == 0x1.fdc20b9c8e97p+3) ? (void)0 : failure("r == 0x1.fdc20b9c8e97p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4471,__func__));
}

void call_f851(void)
{
  float r = f851("gn");
  ((r == 0x1.689afep+5F) ? (void)0 : failure("r == 0x1.689afep+5F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4477,__func__));
}

void call_f852(void)
{
  unsigned char r = f852("ts", 0x1.238802904462p+5);
  ((r == 99) ? (void)0 : failure("r == 99","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4483,__func__));
}

void call_f853(void)
{
  int r = f853(515341926, -1860971214, -0x1.45d42607243bep+5, 750931182, -0x1.8fe944f912324p+5, -1150862592157861352, 8171331784233314274, 0x1.52d530fbd82c8p+2, -0x1.bfd265ad4ef8dp+4, 149608997);
  ((r == -1480505480) ? (void)0 : failure("r == -1480505480","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4489,__func__));
}

void call_f854(void)
{
  f854(-1334759686, 497545491, 0x1.7c3c219567b94p+5);
}

void call_f855(void)
{
  f855(0x1.239ebd4c322fcp+5, 0x1.256848868e75p+3);
}

void call_f856(void)
{
  double r = f856(-771937132, "ry", 4040619702412822684, 0x1.0b766fd0e8ec8p+2);
  ((r == 0x1.6e47f5e772cf8p+3) ? (void)0 : failure("r == 0x1.6e47f5e772cf8p+3","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4505,__func__));
}

void call_f857(void)
{
  short r = f857(-4691332300301051343, 4690807434123943483, 1820153989, 903568965, -0x1.f93ad6ea99a9p+4, "xp", -0x1.9639cf8ac7c7cp+3, "q", 2851604057760065252);
  ((r == 29058) ? (void)0 : failure("r == 29058","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4511,__func__));
}

void call_f858(void)
{
  f858(-1050697107, 0x1.49f3863ada868p+5, 0x1.e7efb10195274p+4, -0x1.7e190c6a042dcp+5, -7749849798186912956, -0x1.557b8165ec77fp+5, "o", "fd", -396150207398090682, 0x1.72f5c000677f8p+3, 240879558);
}

void call_f859(void)
{
  char * r = f859(0x1.204a51ca68ea8p+4);
  ((strcmp(r, "u") == 0) ? (void)0 : failure("strcmp(r, \"u\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4522,__func__));
}

void call_f860(void)
{
  signed char r = f860(-6179818123857351661, 0x1.d1294d1ec2d68p+4, 0x1.00000671946p-3, -0x1.aa198f7e9482p+0, -0x1.73ffb5bfcbc08p+5, 0x1.77b83567872bcp+5, 0x1.18e152cc6a2d8p+3, -1909807372);
  ((r == -9) ? (void)0 : failure("r == -9","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4528,__func__));
}

void call_f861(void)
{
  f861(244509094, -0x1.59ab75fa9a3e8p+2);
}

void call_f862(void)
{
  f862(8927856377232355405, -4657642202948041763, 0x1.cbf60d39c2578p+3, 0x1.e36b20c9faa94p+4, 0x1.74a2d2ca3af6p+3, 2110945498, 777501587982027349);
}

void call_f863(void)
{
  unsigned char r = f863(-0x1.ae1d803c6df98p+3, 0x1.d0ae55a767d7cp+4);
  ((r == 18) ? (void)0 : failure("r == 18","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4544,__func__));
}

void call_f864(void)
{
  f864();
}

void call_f865(void)
{
  f865(-658567922, 143960784);
}

void call_f866(void)
{
  f866("ig", -213558217, 0x1.a41eeb34c1128p+3, 5593926311399131027, 1351570675, "ib", -0x1.2df8fb28b532cp+4, 1621347045, 0x1.bc41a22a00614p+3, -0x1.6f1ed64fe3d6ap+5);
}

void call_f867(void)
{
  f867("ce", -0x1.5ae92ba7fa10ep+4, -0x1.1a4a880dafabcp+5, 2638565851646001785);
}

void call_f868(void)
{
  f868("u");
}

void call_f869(void)
{
  f869("", 0x1.c6644249bb63p+3, "ik", -1167404195, "km", 0x1.fed077ad25a9p+4, "", -222053476, -4394534971716941124);
}

void call_f870(void)
{
  int r = f870("", -0x1.c9eb02682e57p+1, 9076425064247153765, 2067144261);
  ((r == -1834315133) ? (void)0 : failure("r == -1834315133","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4580,__func__));
}

void call_f871(void)
{
  f871(-3743705664185492699);
}

void call_f872(void)
{
  f872(-0x1.0a02e01b96adcp+4, "kd", 0x1.669c3ff58b824p+5, -0x1.4d45b04e9763dp+5, -420101495);
}

void call_f873(void)
{
  f873("lw", "", 3788247615926648726, 0x1.6e6c8cb99656p+3, "", -2103722223, -777238423, 0x1.669b1e8a179f8p+5, "o", "");
}

void call_f874(void)
{
  int r = f874("j", "", 0x1.14e4ce7e598acp+3);
  ((r == -1481223426) ? (void)0 : failure("r == -1481223426","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4601,__func__));
}

void call_f875(void)
{
  int r = f875(-5239875721579740148, -1635621204, -1764782236, "m", -0x1.4c6bae80ad0e1p+4, "x", -0x1.e38e3fd56af49p+4);
  ((r == 1897100905) ? (void)0 : failure("r == 1897100905","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4607,__func__));
}

void call_f876(void)
{
  int r = f876("w", -1017899302790885832);
  ((r == -176678215) ? (void)0 : failure("r == -176678215","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4613,__func__));
}

void call_f877(void)
{
  short r = f877(-0x1.a402b97d26d9cp+3, 0x1.4c9ba6748c21ep+5, -1618582805333264312, -2111173562457170729, 0x1.6d86ed18fc018p+3, "e", -5835270319391887635, "y", 170486075799396288, 0x1.cb89616cd1aep+3);
  ((r == 28413) ? (void)0 : failure("r == 28413","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4619,__func__));
}

void call_f878(void)
{
  f878(-0x1.92ccdbfa9958ep+4, 0x1.d9a110cfe1aep+3, 843248153, 0x1.bf6f0b50dbc78p+4, -1630605678, -3551820415930537204);
}

void call_f879(void)
{
  f879("vb", "", -0x1.d39b523d3e963p+4, -540178546, 9220487526464789609);
}

void call_f880(void)
{
  f880(-0x1.ebd0bb9358f5p+3, "", 536713531, "nw");
}

void call_f881(void)
{
  f881();
}

void call_f882(void)
{
  int r = f882(0x1.2a0dbde47afap+0);
  ((r == 336258132) ? (void)0 : failure("r == 336258132","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4645,__func__));
}

void call_f883(void)
{
  f883(0x1.c488d954a6974p+4, 585616867225905703);
}

void call_f884(void)
{
  f884(-8918611777954991308, "");
}

void call_f885(void)
{
  f885(-0x1.b8d8069f470fdp+4);
}

void call_f886(void)
{
  unsigned char r = f886(150770032, "r", -5118713274917623970, 4305780758304240906, 0x1.412d6bf7a638cp+4, -3183950244501470655, 0x1.5013f7f867534p+5, -0x1.582bbc4c98dccp+4, 0x1.f292151034fap+1, -1925607369);
  ((r == 176) ? (void)0 : failure("r == 176","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4666,__func__));
}

void call_f887(void)
{
  f887();
}

void call_f888(void)
{
  float r = f888(0x1.81e52638d9808p+4, "", 2424120821920988422, 7383977670089605577, -5850972608992761469, -1912741063, 2805642219292892723);
  ((r == 0x1.5a5646p+4F) ? (void)0 : failure("r == 0x1.5a5646p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4677,__func__));
}

void call_f889(void)
{
  long long r = f889(0x1.043e72a76c3ap+4, -4857765425189679978, -0x1.17ff0784ee08cp+5, 7069401775769908531, 6842800105220457250, 0x1.b80ad7f399b58p+2, 1079442871, -0x1.8104c1603f356p+5, -0x1.8eeea47eb541p+3, -0x1.657c634daa2c6p+5, 192316513);
  ((r == -5746221358603426678) ? (void)0 : failure("r == -5746221358603426678","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4683,__func__));
}

void call_f890(void)
{
  f890("");
}

void call_f891(void)
{
  f891(0x1.c5d383f9a002p+0, -223166002, -0x1.45cc8c3202b18p+5, 150370906060416310, 0x1.4c1dd05b52698p+5);
}

void call_f892(void)
{
  char * r = f892(2006782639062100641, -416427089, 2868580125326523885, -0x1.5420a7ac18cbp+1, -1585876838, -1276800099, -0x1.988351fb001cp+1);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4699,__func__));
}

void call_f893(void)
{
  char * r = f893(0x1.28c200affa5p+4, 7582969178821155840, -0x1.52ff0caaa72ap+0, -725722876);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4705,__func__));
}

void call_f894(void)
{
  unsigned short r = f894(-3936354747560077868, -1367911873, 3214319360900201481);
  ((r == 40358) ? (void)0 : failure("r == 40358","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4711,__func__));
}

void call_f895(void)
{
  f895(-275271311, 0x1.8f176c4709c9ap+5, -4390948521351229682, -8093103300582402205, -0x1.48c4f07588a38p+3, -34402090, -0x1.3db35f93821cap+5, -0x1.759296c4d686ep+4, 0x1.6f25300b70616p+5, 0x1.32a7c6e29b53cp+5, 1886701179);
}

void call_f896(void)
{
  f896(994564336601689501, 0x1.1d922fab715a8p+5, 7791722256667529060, -0x1.e53b09b36fd66p+4, "tr", -0x1.e11088032c09p+4);
}

void call_f897(void)
{
  f897("q", 0x1.0f3ccca5723d4p+5, -1107306677, 4209063472830267978, -0x1.d35f71713d37cp+3, -1796014899);
}

void call_f898(void)
{
  int r = f898("vu", "");
  ((r == 1282023088) ? (void)0 : failure("r == 1282023088","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4732,__func__));
}

void call_f899(void)
{
  char * r = f899(1059883812, -7206068211191531783);
  ((strcmp(r, "") == 0) ? (void)0 : failure("strcmp(r, \"\") == 0","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4738,__func__));
}

void call_f900(void)
{
  f900(-0x1.8c55a1cfe320ep+5);
}

void call_f901(void)
{
  f901(391446890, 0x1.cfab36d226238p+4, "", "", -0x1.fe18449463b9fp+4, -0x1.0aa3ee83f6e66p+4, -4627844753732015515, 0x1.943f05b670ba8p+4, 1018520118, -1207116149);
}

void call_f902(void)
{
  f902();
}

void call_f903(void)
{
  signed char r = f903(-0x1.11379ba84bcf8p+3, -0x1.61432d2baa8b6p+5, "");
  ((r == -57) ? (void)0 : failure("r == -57","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4759,__func__));
}

void call_f904(void)
{
  f904(0x1.8873fffd8675p+5, -0x1.12bc2d0b37a2cp+4, "qe", 0x1.650f1aa5f760ap+5, 0x1.05e75d4b50a98p+4, -0x1.2f4b8eb970883p+5);
}

void call_f905(void)
{
  int r = f905(4156285888677321556, 0x1.848f322247054p+5, "us", 0x1.2514de569b972p+5, -0x1.f8e920d918e48p+3, -0x1.fece2ae34eb08p+3, 627543581);
  ((r == 120727122) ? (void)0 : failure("r == 120727122","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4770,__func__));
}

void call_f906(void)
{
  f906(-0x1.674282e3ae065p+5, -0x1.1b5d9c367e832p+5, "mg", -0x1.299dc7cca9986p+4, -1834192665, "", 0x1.f447ef5625ef8p+4);
}

void call_f907(void)
{
  float r = f907(-0x1.b2e1636eac39p+1, -0x1.f79af0fc7edf6p+4, "e", -0x1.72b3518967012p+5, 0x1.a986af0b5b658p+4, -0x1.8df12b6892b3p+3, 1927172882496963631, 1881738861561805212);
  ((r == -0x1.421456p+4F) ? (void)0 : failure("r == -0x1.421456p+4F","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4781,__func__));
}

void call_f908(void)
{
  f908("u", "");
}

void call_f909(void)
{
  short r = f909(-1990191353);
  ((r == -23760) ? (void)0 : failure("r == -23760","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4792,__func__));
}

void call_f910(void)
{
  f910("");
}

void call_f911(void)
{
  long long r = f911(-618625183169091885, -702968197, 7509454858955511547, 0x1.69945cb652912p+5, "m", 663574653, -1545360814);
  ((r == 1287780292406983608) ? (void)0 : failure("r == 1287780292406983608","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4803,__func__));
}

void call_f912(void)
{
  f912(55773943, "", 435706122);
}

void call_f913(void)
{
  f913(-946617799, 0x1.c9ee10f24855p+2);
}

void call_f914(void)
{
  f914(0x1.aa146043c4cd8p+4, 0x1.ee6ffbc6da26p+0);
}

void call_f915(void)
{
  f915(0x1.f1305df5c936p+1, 3695267263264053686, -1710866234, -6232490480648844681, 3607500200840641504);
}

void call_f916(void)
{
  short r = f916("dx", -0x1.464124fbf8c4dp+5, -8576173029004686167);
  ((r == -6051) ? (void)0 : failure("r == -6051","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4829,__func__));
}

void call_f917(void)
{
  int r = f917("gz", 0x1.5b2272479014ap+5, 1523920409);
  ((r == 1440209601) ? (void)0 : failure("r == 1440209601","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4835,__func__));
}

void call_f918(void)
{
  f918(-3023042967722714389, -2039896299, 0x1.9f82589991f98p+4, -0x1.5afb2aefb0702p+4, -1260781545, 6757479923712449351, -0x1.0d277e764f752p+4);
}

void call_f919(void)
{
  int r = f919("", -0x1.1b7650a7b30fcp+4, -0x1.e79477b1cefe8p+4, 0x1.9aa8fe96c9f08p+3, -0x1.77316a5dd3c54p+5, "", -6041627031329776775, "p", "", -0x1.23db07a380cfp+1, 1044190138764007161);
  ((r == 309810381) ? (void)0 : failure("r == 309810381","/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/abi/fixed-native/lean/abi/fixed_use.c",4846,__func__));
}

void call_f920(void)
{
  f920(7846242801004324174, 1866800586, "gu", -0x1.779ef891bcc68p+2, -0x1.0d67087590236p+5, -0x1.cb937e3bd8e18p+3, 457947584, 417502295, 0x1.3f4f4276ccfep+5, -1047595018);
}

int main(void)
{
  alarm(60);
  call_f1();
  call_f2();
  call_f3();
  call_f4();
  call_f5();
  call_f6();
  call_f7();
  call_f8();
  call_f9();
  call_f10();
  call_f11();
  call_f12();
  call_f13();
  call_f14();
  call_f15();
  call_f16();
  call_f17();
  call_f18();
  call_f19();
  call_f20();
  call_f21();
  call_f22();
  call_f23();
  call_f24();
  call_f25();
  call_f26();
  call_f27();
  call_f28();
  call_f29();
  call_f30();
  call_f31();
  call_f32();
  call_f33();
  call_f34();
  call_f35();
  call_f36();
  call_f37();
  call_f38();
  call_f39();
  call_f40();
  call_f41();
  call_f42();
  call_f43();
  call_f44();
  call_f45();
  call_f46();
  call_f47();
  call_f48();
  call_f49();
  call_f50();
  call_f51();
  call_f52();
  call_f53();
  call_f54();
  call_f55();
  call_f56();
  call_f57();
  call_f58();
  call_f59();
  call_f60();
  call_f61();
  call_f62();
  call_f63();
  call_f64();
  call_f65();
  call_f66();
  call_f67();
  call_f68();
  call_f69();
  call_f70();
  call_f71();
  call_f72();
  call_f73();
  call_f74();
  call_f75();
  call_f76();
  call_f77();
  call_f78();
  call_f79();
  call_f80();
  call_f81();
  call_f82();
  call_f83();
  call_f84();
  call_f85();
  call_f86();
  call_f87();
  call_f88();
  call_f89();
  call_f90();
  call_f91();
  call_f92();
  call_f93();
  call_f94();
  call_f95();
  call_f96();
  call_f97();
  call_f98();
  call_f99();
  call_f100();
  call_f101();
  call_f102();
  call_f103();
  call_f104();
  call_f105();
  call_f106();
  call_f107();
  call_f108();
  call_f109();
  call_f110();
  call_f111();
  call_f112();
  call_f113();
  call_f114();
  call_f115();
  call_f116();
  call_f117();
  call_f118();
  call_f119();
  call_f120();
  call_f121();
  call_f122();
  call_f123();
  call_f124();
  call_f125();
  call_f126();
  call_f127();
  call_f128();
  call_f129();
  call_f130();
  call_f131();
  call_f132();
  call_f133();
  call_f134();
  call_f135();
  call_f136();
  call_f137();
  call_f138();
  call_f139();
  call_f140();
  call_f141();
  call_f142();
  call_f143();
  call_f144();
  call_f145();
  call_f146();
  call_f147();
  call_f148();
  call_f149();
  call_f150();
  call_f151();
  call_f152();
  call_f153();
  call_f154();
  call_f155();
  call_f156();
  call_f157();
  call_f158();
  call_f159();
  call_f160();
  call_f161();
  call_f162();
  call_f163();
  call_f164();
  call_f165();
  call_f166();
  call_f167();
  call_f168();
  call_f169();
  call_f170();
  call_f171();
  call_f172();
  call_f173();
  call_f174();
  call_f175();
  call_f176();
  call_f177();
  call_f178();
  call_f179();
  call_f180();
  call_f181();
  call_f182();
  call_f183();
  call_f184();
  call_f185();
  call_f186();
  call_f187();
  call_f188();
  call_f189();
  call_f190();
  call_f191();
  call_f192();
  call_f193();
  call_f194();
  call_f195();
  call_f196();
  call_f197();
  call_f198();
  call_f199();
  call_f200();
  call_f201();
  call_f202();
  call_f203();
  call_f204();
  call_f205();
  call_f206();
  call_f207();
  call_f208();
  call_f209();
  call_f210();
  call_f211();
  call_f212();
  call_f213();
  call_f214();
  call_f215();
  call_f216();
  call_f217();
  call_f218();
  call_f219();
  call_f220();
  call_f221();
  call_f222();
  call_f223();
  call_f224();
  call_f225();
  call_f226();
  call_f227();
  call_f228();
  call_f229();
  call_f230();
  call_f231();
  call_f232();
  call_f233();
  call_f234();
  call_f235();
  call_f236();
  call_f237();
  call_f238();
  call_f239();
  call_f240();
  call_f241();
  call_f242();
  call_f243();
  call_f244();
  call_f245();
  call_f246();
  call_f247();
  call_f248();
  call_f249();
  call_f250();
  call_f251();
  call_f252();
  call_f253();
  call_f254();
  call_f255();
  call_f256();
  call_f257();
  call_f258();
  call_f259();
  call_f260();
  call_f261();
  call_f262();
  call_f263();
  call_f264();
  call_f265();
  call_f266();
  call_f267();
  call_f268();
  call_f269();
  call_f270();
  call_f271();
  call_f272();
  call_f273();
  call_f274();
  call_f275();
  call_f276();
  call_f277();
  call_f278();
  call_f279();
  call_f280();
  call_f281();
  call_f282();
  call_f283();
  call_f284();
  call_f285();
  call_f286();
  call_f287();
  call_f288();
  call_f289();
  call_f290();
  call_f291();
  call_f292();
  call_f293();
  call_f294();
  call_f295();
  call_f296();
  call_f297();
  call_f298();
  call_f299();
  call_f300();
  call_f301();
  call_f302();
  call_f303();
  call_f304();
  call_f305();
  call_f306();
  call_f307();
  call_f308();
  call_f309();
  call_f310();
  call_f311();
  call_f312();
  call_f313();
  call_f314();
  call_f315();
  call_f316();
  call_f317();
  call_f318();
  call_f319();
  call_f320();
  call_f321();
  call_f322();
  call_f323();
  call_f324();
  call_f325();
  call_f326();
  call_f327();
  call_f328();
  call_f329();
  call_f330();
  call_f331();
  call_f332();
  call_f333();
  call_f334();
  call_f335();
  call_f336();
  call_f337();
  call_f338();
  call_f339();
  call_f340();
  call_f341();
  call_f342();
  call_f343();
  call_f344();
  call_f345();
  call_f346();
  call_f347();
  call_f348();
  call_f349();
  call_f350();
  call_f351();
  call_f352();
  call_f353();
  call_f354();
  call_f355();
  call_f356();
  call_f357();
  call_f358();
  call_f359();
  call_f360();
  call_f361();
  call_f362();
  call_f363();
  call_f364();
  call_f365();
  call_f366();
  call_f367();
  call_f368();
  call_f369();
  call_f370();
  call_f371();
  call_f372();
  call_f373();
  call_f374();
  call_f375();
  call_f376();
  call_f377();
  call_f378();
  call_f379();
  call_f380();
  call_f381();
  call_f382();
  call_f383();
  call_f384();
  call_f385();
  call_f386();
  call_f387();
  call_f388();
  call_f389();
  call_f390();
  call_f391();
  call_f392();
  call_f393();
  call_f394();
  call_f395();
  call_f396();
  call_f397();
  call_f398();
  call_f399();
  call_f400();
  call_f401();
  call_f402();
  call_f403();
  call_f404();
  call_f405();
  call_f406();
  call_f407();
  call_f408();
  call_f409();
  call_f410();
  call_f411();
  call_f412();
  call_f413();
  call_f414();
  call_f415();
  call_f416();
  call_f417();
  call_f418();
  call_f419();
  call_f420();
  call_f421();
  call_f422();
  call_f423();
  call_f424();
  call_f425();
  call_f426();
  call_f427();
  call_f428();
  call_f429();
  call_f430();
  call_f431();
  call_f432();
  call_f433();
  call_f434();
  call_f435();
  call_f436();
  call_f437();
  call_f438();
  call_f439();
  call_f440();
  call_f441();
  call_f442();
  call_f443();
  call_f444();
  call_f445();
  call_f446();
  call_f447();
  call_f448();
  call_f449();
  call_f450();
  call_f451();
  call_f452();
  call_f453();
  call_f454();
  call_f455();
  call_f456();
  call_f457();
  call_f458();
  call_f459();
  call_f460();
  call_f461();
  call_f462();
  call_f463();
  call_f464();
  call_f465();
  call_f466();
  call_f467();
  call_f468();
  call_f469();
  call_f470();
  call_f471();
  call_f472();
  call_f473();
  call_f474();
  call_f475();
  call_f476();
  call_f477();
  call_f478();
  call_f479();
  call_f480();
  call_f481();
  call_f482();
  call_f483();
  call_f484();
  call_f485();
  call_f486();
  call_f487();
  call_f488();
  call_f489();
  call_f490();
  call_f491();
  call_f492();
  call_f493();
  call_f494();
  call_f495();
  call_f496();
  call_f497();
  call_f498();
  call_f499();
  call_f500();
  call_f501();
  call_f502();
  call_f503();
  call_f504();
  call_f505();
  call_f506();
  call_f507();
  call_f508();
  call_f509();
  call_f510();
  call_f511();
  call_f512();
  call_f513();
  call_f514();
  call_f515();
  call_f516();
  call_f517();
  call_f518();
  call_f519();
  call_f520();
  call_f521();
  call_f522();
  call_f523();
  call_f524();
  call_f525();
  call_f526();
  call_f527();
  call_f528();
  call_f529();
  call_f530();
  call_f531();
  call_f532();
  call_f533();
  call_f534();
  call_f535();
  call_f536();
  call_f537();
  call_f538();
  call_f539();
  call_f540();
  call_f541();
  call_f542();
  call_f543();
  call_f544();
  call_f545();
  call_f546();
  call_f547();
  call_f548();
  call_f549();
  call_f550();
  call_f551();
  call_f552();
  call_f553();
  call_f554();
  call_f555();
  call_f556();
  call_f557();
  call_f558();
  call_f559();
  call_f560();
  call_f561();
  call_f562();
  call_f563();
  call_f564();
  call_f565();
  call_f566();
  call_f567();
  call_f568();
  call_f569();
  call_f570();
  call_f571();
  call_f572();
  call_f573();
  call_f574();
  call_f575();
  call_f576();
  call_f577();
  call_f578();
  call_f579();
  call_f580();
  call_f581();
  call_f582();
  call_f583();
  call_f584();
  call_f585();
  call_f586();
  call_f587();
  call_f588();
  call_f589();
  call_f590();
  call_f591();
  call_f592();
  call_f593();
  call_f594();
  call_f595();
  call_f596();
  call_f597();
  call_f598();
  call_f599();
  call_f600();
  call_f601();
  call_f602();
  call_f603();
  call_f604();
  call_f605();
  call_f606();
  call_f607();
  call_f608();
  call_f609();
  call_f610();
  call_f611();
  call_f612();
  call_f613();
  call_f614();
  call_f615();
  call_f616();
  call_f617();
  call_f618();
  call_f619();
  call_f620();
  call_f621();
  call_f622();
  call_f623();
  call_f624();
  call_f625();
  call_f626();
  call_f627();
  call_f628();
  call_f629();
  call_f630();
  call_f631();
  call_f632();
  call_f633();
  call_f634();
  call_f635();
  call_f636();
  call_f637();
  call_f638();
  call_f639();
  call_f640();
  call_f641();
  call_f642();
  call_f643();
  call_f644();
  call_f645();
  call_f646();
  call_f647();
  call_f648();
  call_f649();
  call_f650();
  call_f651();
  call_f652();
  call_f653();
  call_f654();
  call_f655();
  call_f656();
  call_f657();
  call_f658();
  call_f659();
  call_f660();
  call_f661();
  call_f662();
  call_f663();
  call_f664();
  call_f665();
  call_f666();
  call_f667();
  call_f668();
  call_f669();
  call_f670();
  call_f671();
  call_f672();
  call_f673();
  call_f674();
  call_f675();
  call_f676();
  call_f677();
  call_f678();
  call_f679();
  call_f680();
  call_f681();
  call_f682();
  call_f683();
  call_f684();
  call_f685();
  call_f686();
  call_f687();
  call_f688();
  call_f689();
  call_f690();
  call_f691();
  call_f692();
  call_f693();
  call_f694();
  call_f695();
  call_f696();
  call_f697();
  call_f698();
  call_f699();
  call_f700();
  call_f701();
  call_f702();
  call_f703();
  call_f704();
  call_f705();
  call_f706();
  call_f707();
  call_f708();
  call_f709();
  call_f710();
  call_f711();
  call_f712();
  call_f713();
  call_f714();
  call_f715();
  call_f716();
  call_f717();
  call_f718();
  call_f719();
  call_f720();
  call_f721();
  call_f722();
  call_f723();
  call_f724();
  call_f725();
  call_f726();
  call_f727();
  call_f728();
  call_f729();
  call_f730();
  call_f731();
  call_f732();
  call_f733();
  call_f734();
  call_f735();
  call_f736();
  call_f737();
  call_f738();
  call_f739();
  call_f740();
  call_f741();
  call_f742();
  call_f743();
  call_f744();
  call_f745();
  call_f746();
  call_f747();
  call_f748();
  call_f749();
  call_f750();
  call_f751();
  call_f752();
  call_f753();
  call_f754();
  call_f755();
  call_f756();
  call_f757();
  call_f758();
  call_f759();
  call_f760();
  call_f761();
  call_f762();
  call_f763();
  call_f764();
  call_f765();
  call_f766();
  call_f767();
  call_f768();
  call_f769();
  call_f770();
  call_f771();
  call_f772();
  call_f773();
  call_f774();
  call_f775();
  call_f776();
  call_f777();
  call_f778();
  call_f779();
  call_f780();
  call_f781();
  call_f782();
  call_f783();
  call_f784();
  call_f785();
  call_f786();
  call_f787();
  call_f788();
  call_f789();
  call_f790();
  call_f791();
  call_f792();
  call_f793();
  call_f794();
  call_f795();
  call_f796();
  call_f797();
  call_f798();
  call_f799();
  call_f800();
  call_f801();
  call_f802();
  call_f803();
  call_f804();
  call_f805();
  call_f806();
  call_f807();
  call_f808();
  call_f809();
  call_f810();
  call_f811();
  call_f812();
  call_f813();
  call_f814();
  call_f815();
  call_f816();
  call_f817();
  call_f818();
  call_f819();
  call_f820();
  call_f821();
  call_f822();
  call_f823();
  call_f824();
  call_f825();
  call_f826();
  call_f827();
  call_f828();
  call_f829();
  call_f830();
  call_f831();
  call_f832();
  call_f833();
  call_f834();
  call_f835();
  call_f836();
  call_f837();
  call_f838();
  call_f839();
  call_f840();
  call_f841();
  call_f842();
  call_f843();
  call_f844();
  call_f845();
  call_f846();
  call_f847();
  call_f848();
  call_f849();
  call_f850();
  call_f851();
  call_f852();
  call_f853();
  call_f854();
  call_f855();
  call_f856();
  call_f857();
  call_f858();
  call_f859();
  call_f860();
  call_f861();
  call_f862();
  call_f863();
  call_f864();
  call_f865();
  call_f866();
  call_f867();
  call_f868();
  call_f869();
  call_f870();
  call_f871();
  call_f872();
  call_f873();
  call_f874();
  call_f875();
  call_f876();
  call_f877();
  call_f878();
  call_f879();
  call_f880();
  call_f881();
  call_f882();
  call_f883();
  call_f884();
  call_f885();
  call_f886();
  call_f887();
  call_f888();
  call_f889();
  call_f890();
  call_f891();
  call_f892();
  call_f893();
  call_f894();
  call_f895();
  call_f896();
  call_f897();
  call_f898();
  call_f899();
  call_f900();
  call_f901();
  call_f902();
  call_f903();
  call_f904();
  call_f905();
  call_f906();
  call_f907();
  call_f908();
  call_f909();
  call_f910();
  call_f911();
  call_f912();
  call_f913();
  call_f914();
  call_f915();
  call_f916();
  call_f917();
  call_f918();
  call_f919();
  call_f920();
  return failed;
}
