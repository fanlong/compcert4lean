# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/pic/shared/lean/pic/lib1.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/pic/shared/lean/pic/lib1.c"
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/pic/shared/lean/pic/lib1.h" 1
extern int x;
extern int f(int);
# 2 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/pic/shared/lean/pic/lib1.c" 2

int x = 12;

int f(int y) { return x + y; }
