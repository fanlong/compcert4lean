# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
# 82 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4

# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef unsigned long size_t;
# 98 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef 
# 98 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h"
       int 
# 98 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
                               wchar_t;
# 33 "/usr/include/stdlib.h" 2 3 4


# 60 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 61 "/usr/include/stdlib.h" 2 3 4


typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





 typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 102 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) ;



extern double atof (const char *__nptr)
     ;

extern int atoi (const char *__nptr)
     ;

extern long int atol (const char *__nptr)
     ;



 extern long long int atoll (const char *__nptr)
     ;



extern double strtod (const char *restrict __nptr,
        char **restrict __endptr)
     ;



extern float strtof (const char *restrict __nptr,
       char **restrict __endptr) ;

extern long double strtold (const char *restrict __nptr,
       char **restrict __endptr)
     ;
# 181 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *restrict __nptr,
   char **restrict __endptr, int __base)
     ;

extern unsigned long int strtoul (const char *restrict __nptr,
      char **restrict __endptr, int __base)
     ;
# 204 "/usr/include/stdlib.h" 3 4

extern long long int strtoll (const char *restrict __nptr,
         char **restrict __endptr, int __base)
     ;


extern unsigned long long int strtoull (const char *restrict __nptr,
     char **restrict __endptr, int __base)
     ;
# 577 "/usr/include/stdlib.h" 3 4
extern int rand (void) ;

extern void srand (unsigned int __seed) ;
# 676 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size)
     ;

extern void *calloc (size_t __nmemb, size_t __size)
     ;






extern void *realloc (void *__ptr, size_t __size)
     ;


extern void free (void *__ptr) ;
# 752 "/usr/include/stdlib.h" 3 4
extern void abort (void) ;



extern int atexit (void (*__func) (void)) ;
# 778 "/usr/include/stdlib.h" 3 4
extern void exit (int __status) ;
# 790 "/usr/include/stdlib.h" 3 4
extern void _Exit (int __status) ;




extern char *getenv (const char *__name) ;
# 945 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 970 "/usr/include/stdlib.h" 3 4
typedef int (*__compar_fn_t) (const void *, const void *);
# 982 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     ;
# 998 "/usr/include/stdlib.h" 3 4
extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) ;
# 1008 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) ;
extern long int labs (long int __x) ;


 extern long long int llabs (long long int __x)
     ;
# 1026 "/usr/include/stdlib.h" 3 4
extern div_t div (int __numer, int __denom)
     ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     ;


 extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     ;
# 1096 "/usr/include/stdlib.h" 3 4
extern int mblen (const char *__s, size_t __n) ;


extern int mbtowc (wchar_t *restrict __pwc,
     const char *restrict __s, size_t __n) ;


extern int wctomb (char *__s, wchar_t __wchar) ;



extern size_t mbstowcs (wchar_t *restrict __pwcs,
   const char *restrict __s, size_t __n)
    ;

extern size_t wcstombs (char *restrict __s,
   const wchar_t *restrict __pwcs, size_t __n)
    
 
  ;
# 1202 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1203 "/usr/include/stdlib.h" 2 3 4
# 1214 "/usr/include/stdlib.h" 3 4

# 83 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 2
# 1 "/usr/include/errno.h" 1 3 4
# 28 "/usr/include/errno.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/errno.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/bits/errno.h" 3 4
# 1 "/usr/include/linux/errno.h" 1 3 4
# 1 "/usr/include/x86_64-linux-gnu/asm/errno.h" 1 3 4
# 1 "/usr/include/asm-generic/errno.h" 1 3 4




# 1 "/usr/include/asm-generic/errno-base.h" 1 3 4
# 6 "/usr/include/asm-generic/errno.h" 2 3 4
# 2 "/usr/include/x86_64-linux-gnu/asm/errno.h" 2 3 4
# 2 "/usr/include/linux/errno.h" 2 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/errno.h" 2 3 4
# 29 "/usr/include/errno.h" 2 3 4








extern int *__errno_location (void) ;
# 52 "/usr/include/errno.h" 3 4

# 84 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.h" 1
# 69 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.h"
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 29 "/usr/include/stdio.h" 2 3 4









# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 39 "/usr/include/stdio.h" 2 3 4


# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 1 3 4
# 43 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 42 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 45 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 46 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 47 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 48 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 2 3 4

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2:24;

  char _short_backupbuf[1];
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;

  int _unused3;

  __uint64_t _total_written;




  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
# 49 "/usr/include/stdio.h" 2 3 4
# 89 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;
# 133 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 134 "/usr/include/stdio.h" 2 3 4
# 153 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) ;

extern int rename (const char *__old, const char *__new) ;
# 191 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) ;
# 201 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  ;
# 218 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) ;
# 243 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 271 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *restrict __filename,
      const char *restrict __modes)
  ;




extern FILE *freopen (const char *restrict __filename,
        const char *restrict __modes,
        FILE *restrict __stream) ;
# 341 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *restrict __stream, char *restrict __buf)
  ;



extern int setvbuf (FILE *restrict __stream, char *restrict __buf,
      int __modes, size_t __n) ;
# 364 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *restrict __stream,
      const char *restrict __format, ...) ;




extern int printf (const char *restrict __format, ...);

extern int sprintf (char *restrict __s,
      const char *restrict __format, ...) ;





extern int vfprintf (FILE *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;




extern int vprintf (const char *restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;



extern int snprintf (char *restrict __s, size_t __maxlen,
       const char *restrict __format, ...)
     ;

extern int vsnprintf (char *restrict __s, size_t __maxlen,
        const char *restrict __format, __gnuc_va_list __arg)
     ;
# 429 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *restrict __stream,
     const char *restrict __format, ...) ;




extern int scanf (const char *restrict __format, ...) ;

extern int sscanf (const char *restrict __s,
     const char *restrict __format, ...) ;
# 479 "/usr/include/stdio.h" 3 4
extern int __isoc99_fscanf (FILE *restrict __stream,
       const char *restrict __format, ...)
  ;
extern int __isoc99_scanf (const char *restrict __format, ...) ;
extern int __isoc99_sscanf (const char *restrict __s,
       const char *restrict __format, ...) ;
# 497 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *restrict __s, const char *restrict __format,
      __gnuc_va_list __arg)
     ;





extern int vscanf (const char *restrict __format, __gnuc_va_list __arg)
     ;


extern int vsscanf (const char *restrict __s,
      const char *restrict __format, __gnuc_va_list __arg)
     ;
# 561 "/usr/include/stdio.h" 3 4
extern int __isoc99_vfscanf (FILE *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
extern int __isoc99_vscanf (const char *restrict __format,
       __gnuc_va_list __arg) ;
extern int __isoc99_vsscanf (const char *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
# 582 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) ;
extern int getc (FILE *__stream) ;





extern int getchar (void);
# 615 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) ;
extern int putc (int __c, FILE *__stream) ;





extern int putchar (int __c);
# 658 "/usr/include/stdio.h" 3 4
extern char *fgets (char *restrict __s, int __n, FILE *restrict __stream)
     ;
# 671 "/usr/include/stdio.h" 3 4
extern char *gets (char *__s) ;
# 711 "/usr/include/stdio.h" 3 4
extern int fputs (const char *restrict __s, FILE *restrict __stream)
  ;





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) ;






extern size_t fread (void *restrict __ptr, size_t __size,
       size_t __n, FILE *restrict __stream)
  ;




extern size_t fwrite (const void *restrict __ptr, size_t __size,
        size_t __n, FILE *restrict __s) ;
# 773 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  ;




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream) ;
# 823 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *restrict __stream, fpos_t *restrict __pos)
  ;




extern int fsetpos (FILE *__stream, const fpos_t *__pos) ;
# 854 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) ;

extern int feof (FILE *__stream) ;

extern int ferror (FILE *__stream) ;
# 872 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) ;
# 953 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 977 "/usr/include/stdio.h" 3 4

# 70 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.h" 2





# 74 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.h"
typedef enum
{
    BF_READ = 0,
    BF_WRITE = 1,
    BF_APPEND= 2,
    BF_NO_MODE
} BF_MODES;


struct bit_file_t;
typedef struct bit_file_t bit_file_t;






bit_file_t *BitFileOpen(const char *fileName, const BF_MODES mode);
bit_file_t *MakeBitFile(FILE *stream, const BF_MODES mode);
int BitFileClose(bit_file_t *stream);
FILE *BitFileToFILE(bit_file_t *stream);


int BitFileByteAlign(bit_file_t *stream);


int BitFileGetChar(bit_file_t *stream);
int BitFilePutChar(const int c, bit_file_t *stream);


int BitFileGetBit(bit_file_t *stream);
int BitFilePutBit(const int c, bit_file_t *stream);


int BitFileGetBits(bit_file_t *stream, void *bits, const unsigned int count);
int BitFilePutBits(bit_file_t *stream, void *bits, const unsigned int count);






int BitFileGetBitsInt(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size);
int BitFilePutBitsInt(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size);
# 85 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 2





typedef enum
{
    BF_UNKNOWN_ENDIAN,
    BF_LITTLE_ENDIAN,
    BF_BIG_ENDIAN
} endian_t;

struct bit_file_t
{
    FILE *fp;
    endian_t endian;
    unsigned char bitBuffer;
    unsigned char bitCount;
    BF_MODES mode;
};


typedef union
{
    unsigned long word;
    unsigned char bytes[sizeof(unsigned long)];
} endian_test_t;




endian_t DetermineEndianess(void);

int BitFilePutBitsLE(bit_file_t *stream, void *bits, const unsigned int count);
int BitFilePutBitsBE(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size);

int BitFileGetBitsLE(bit_file_t *stream, void *bits, const unsigned int count);
int BitFileGetBitsBE(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size);
# 145 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
bit_file_t *BitFileOpen(const char *fileName, const BF_MODES mode)
{
    char modes[3][3] = {"rb", "wb", "ab"};
    bit_file_t *bf;

    bf = (bit_file_t *)malloc(sizeof(bit_file_t));

    if (bf == 
# 152 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
             ((void *) 0)
# 152 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 )
    {

        
# 155 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
       (*__errno_location ()) 
# 155 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
             = 
# 155 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
               12
# 155 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     ;
    }
    else
    {
        bf->fp = fopen(fileName, modes[mode]);

        if (bf->fp == 
# 161 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                     ((void *) 0)
# 161 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                         )
        {

            free(bf);
            return 
# 165 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                  ((void *) 0)
# 165 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                      ;
        }
        else
        {

            bf->bitBuffer = 0;
            bf->bitCount = 0;
            bf->mode = mode;







        }
    }

    bf->endian = DetermineEndianess();
    return (bf);
}
# 201 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
bit_file_t *MakeBitFile(FILE *stream, const BF_MODES mode)
{
    bit_file_t *bf;

    if (stream == 
# 205 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                 ((void *) 0)
# 205 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     )
    {

        
# 208 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
       (*__errno_location ()) 
# 208 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
             = 
# 208 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
               9
# 208 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                    ;
        bf = 
# 209 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
            ((void *) 0)
# 209 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                ;
    }
    else
    {
        bf = (bit_file_t *)malloc(sizeof(bit_file_t));

        if (bf == 
# 215 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                 ((void *) 0)
# 215 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     )
        {

            
# 218 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
           (*__errno_location ()) 
# 218 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 = 
# 218 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                   12
# 218 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                         ;
        }
        else
        {

            bf->fp = stream;
            bf->bitBuffer = 0;
            bf->bitCount = 0;
            bf->mode = mode;
        }
    }

    bf->endian = DetermineEndianess();

    return (bf);
}
# 246 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
endian_t DetermineEndianess(void)
{
    endian_t endian;
    endian_test_t endianTest;

    endianTest.word = 1;

    if (endianTest.bytes[0] == 1)
    {

        endian = BF_LITTLE_ENDIAN;
    }
    else if (endianTest.bytes[sizeof(unsigned long) - 1] == 1)
    {

        endian = BF_BIG_ENDIAN;
    }
    else
    {
        endian = BF_UNKNOWN_ENDIAN;
    }

    return endian;
}
# 280 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFileClose(bit_file_t *stream)
{
    int returnValue = 0;

    if (stream == 
# 284 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                 ((void *) 0)
# 284 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     )
    {
        return(
# 286 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              (-1)
# 286 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 );
    }

    if ((stream->mode == BF_WRITE) || (stream->mode == BF_APPEND))
    {

        if (stream->bitCount != 0)
        {
            (stream->bitBuffer) <<= 8 - (stream->bitCount);
            fputc(stream->bitBuffer, stream->fp);
        }
    }







    returnValue = fclose(stream->fp);


    free(stream);

    return(returnValue);
}
# 322 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
FILE *BitFileToFILE(bit_file_t *stream)
{
    FILE *fp = 
# 324 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              ((void *) 0)
# 324 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                  ;

    if (stream == 
# 326 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                 ((void *) 0)
# 326 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     )
    {
        return(
# 328 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              ((void *) 0)
# 328 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                  );
    }

    if ((stream->mode == BF_WRITE) || (stream->mode == BF_APPEND))
    {

        if (stream->bitCount != 0)
        {
            (stream->bitBuffer) <<= 8 - (stream->bitCount);
            fputc(stream->bitBuffer, stream->fp);
        }
    }







    fp = stream->fp;


    free(stream);

    return(fp);
}
# 366 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFileByteAlign(bit_file_t *stream)
{
    int returnValue;

    if (stream == 
# 370 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                 ((void *) 0)
# 370 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     )
    {
        return(
# 372 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              (-1)
# 372 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 );
    }

    returnValue = stream->bitBuffer;

    if ((stream->mode == BF_WRITE) || (stream->mode == BF_APPEND))
    {

        if (stream->bitCount != 0)
        {
            (stream->bitBuffer) <<= 8 - (stream->bitCount);
            fputc(stream->bitBuffer, stream->fp);
        }
    }

    stream->bitBuffer = 0;
    stream->bitCount = 0;

    return (returnValue);
}
# 402 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFileGetChar(bit_file_t *stream)
{
    int returnValue;
    unsigned char tmp;

    if (stream == 
# 407 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                 ((void *) 0)
# 407 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     )
    {
        return(
# 409 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              (-1)
# 409 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 );
    }

    returnValue = fgetc(stream->fp);

    if (stream->bitCount == 0)
    {

        return returnValue;
    }


    if (returnValue != 
# 421 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                      (-1)
# 421 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                         )
    {

        tmp = ((unsigned char)returnValue) >> (stream->bitCount);
        tmp |= ((stream->bitBuffer) << (8 - (stream->bitCount)));


        stream->bitBuffer = returnValue;

        returnValue = tmp;
    }

    return returnValue;
}
# 445 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFilePutChar(const int c, bit_file_t *stream)
{
    unsigned char tmp;

    if (stream == 
# 449 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                 ((void *) 0)
# 449 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     )
    {
        return(
# 451 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              (-1)
# 451 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 );
    }

    if (stream->bitCount == 0)
    {

        return fputc(c, stream->fp);
    }


    tmp = ((unsigned char)c) >> (stream->bitCount);
    tmp = tmp | ((stream->bitBuffer) << (8 - stream->bitCount));

    if (fputc(tmp, stream->fp) != 
# 464 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                                 (-1)
# 464 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                                    )
    {

        stream->bitBuffer = c;
    }
    else
    {
        return 
# 471 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              (-1)
# 471 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 ;
    }

    return tmp;
}
# 487 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFileGetBit(bit_file_t *stream)
{
    int returnValue;

    if (stream == 
# 491 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                 ((void *) 0)
# 491 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     )
    {
        return(
# 493 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              (-1)
# 493 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 );
    }

    if (stream->bitCount == 0)
    {

        if ((returnValue = fgetc(stream->fp)) == 
# 499 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                                                (-1)
# 499 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                                                   )
        {
            return 
# 501 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                  (-1)
# 501 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     ;
        }
        else
        {
            stream->bitCount = 8;
            stream->bitBuffer = returnValue;
        }
    }


    stream->bitCount--;
    returnValue = (stream->bitBuffer) >> (stream->bitCount);

    return (returnValue & 0x01);
}
# 527 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFilePutBit(const int c, bit_file_t *stream)
{
    int returnValue = c;

    if (stream == 
# 531 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                 ((void *) 0)
# 531 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     )
    {
        return(
# 533 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              (-1)
# 533 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 );
    }

    stream->bitCount++;
    stream->bitBuffer <<= 1;

    if (c != 0)
    {
        stream->bitBuffer |= 1;
    }


    if (stream->bitCount == 8)
    {
        if (fputc(stream->bitBuffer, stream->fp) == 
# 547 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                                                   (-1)
# 547 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                                                      )
        {
            returnValue = 
# 549 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                         (-1)
# 549 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                            ;
        }


        stream->bitCount = 0;
        stream->bitBuffer = 0;
    }

    return returnValue;
}
# 574 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFileGetBits(bit_file_t *stream, void *bits, const unsigned int count)
{
    unsigned char *bytes, shifts;
    int offset, remaining, returnValue;

    bytes = (unsigned char *)bits;

    if ((stream == 
# 581 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                  ((void *) 0)
# 581 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                      ) || (bits == 
# 581 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                                    ((void *) 0)
# 581 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                                        ))
    {
        return(
# 583 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              (-1)
# 583 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 );
    }

    offset = 0;
    remaining = count;


    while (remaining >= 8)
    {
        returnValue = BitFileGetChar(stream);

        if (returnValue == 
# 594 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                          (-1)
# 594 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                             )
        {
            return 
# 596 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                  (-1)
# 596 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     ;
        }

        bytes[offset] = (unsigned char)returnValue;
        remaining -= 8;
        offset++;
    }

    if (remaining != 0)
    {

        shifts = 8 - remaining;

        while (remaining > 0)
        {
            returnValue = BitFileGetBit(stream);

            if (returnValue == 
# 613 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                              (-1)
# 613 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                                 )
            {
                return 
# 615 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                      (-1)
# 615 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                         ;
            }

            bytes[offset] <<= 1;
            bytes[offset] |= (returnValue & 0x01);
            remaining--;
        }


        bytes[offset] <<= shifts;
    }

    return count;
}
# 644 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFilePutBits(bit_file_t *stream, void *bits, const unsigned int count)
{
    unsigned char *bytes, tmp;
    int offset, remaining, returnValue;

    bytes = (unsigned char *)bits;

    if ((stream == 
# 651 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                  ((void *) 0)
# 651 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                      ) || (bits == 
# 651 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                                    ((void *) 0)
# 651 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                                        ))
    {
        return(
# 653 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              (-1)
# 653 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 );
    }

    offset = 0;
    remaining = count;


    while (remaining >= 8)
    {
        returnValue = BitFilePutChar(bytes[offset], stream);

        if (returnValue == 
# 664 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                          (-1)
# 664 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                             )
        {
            return 
# 666 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                  (-1)
# 666 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     ;
        }

        remaining -= 8;
        offset++;
    }

    if (remaining != 0)
    {

        tmp = bytes[offset];

        while (remaining > 0)
        {
            returnValue = BitFilePutBit((tmp & 0x80), stream);

            if (returnValue == 
# 682 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                              (-1)
# 682 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                                 )
            {
                return 
# 684 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                      (-1)
# 684 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                         ;
            }

            tmp <<= 1;
            remaining--;
        }
    }

    return count;
}
# 711 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFileGetBitsInt(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size)
{
    int returnValue;

    if ((stream == 
# 716 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                  ((void *) 0)
# 716 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                      ) || (bits == 
# 716 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                                    ((void *) 0)
# 716 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                                        ))
    {
        return(
# 718 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              (-1)
# 718 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 );
    }

    if (stream->endian == BF_LITTLE_ENDIAN)
    {
        returnValue = BitFileGetBitsLE(stream, bits, count);
    }
    else if (stream->endian == BF_BIG_ENDIAN)
    {
        returnValue = BitFileGetBitsBE(stream, bits, count, size);
    }
    else
    {
        returnValue = 
# 731 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                     (-1)
# 731 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                        ;
    }

    return returnValue;
}
# 752 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFileGetBitsLE(bit_file_t *stream, void *bits, const unsigned int count)
{
    unsigned char *bytes, shifts;
    int offset, remaining, returnValue;

    bytes = (unsigned char *)bits;

    offset = 0;
    remaining = count;


    while (remaining >= 8)
    {
        returnValue = BitFileGetChar(stream);

        if (returnValue == 
# 767 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                          (-1)
# 767 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                             )
        {
            return 
# 769 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                  (-1)
# 769 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     ;
        }

        bytes[offset] = (unsigned char)returnValue;
        remaining -= 8;
        offset++;
    }

    if (remaining != 0)
    {

        shifts = 8 - remaining;

        while (remaining > 0)
        {
            returnValue = BitFileGetBit(stream);

            if (returnValue == 
# 786 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                              (-1)
# 786 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                                 )
            {
                return 
# 788 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                      (-1)
# 788 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                         ;
            }

            bytes[offset] <<= 1;
            bytes[offset] |= (returnValue & 0x01);
            remaining--;
        }

    }

    return count;
}
# 817 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFileGetBitsBE(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size)
{
    unsigned char *bytes, shifts;
    int offset, remaining, returnValue;

    if (count > (size * 8))
    {

        return 
# 826 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              (-1)
# 826 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 ;
    }

    bytes = (unsigned char *)bits;

    offset = size - 1;
    remaining = count;


    while (remaining >= 8)
    {
        returnValue = BitFileGetChar(stream);

        if (returnValue == 
# 839 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                          (-1)
# 839 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                             )
        {
            return 
# 841 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                  (-1)
# 841 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     ;
        }

        bytes[offset] = (unsigned char)returnValue;
        remaining -= 8;
        offset--;
    }

    if (remaining != 0)
    {

        shifts = 8 - remaining;

        while (remaining > 0)
        {
            returnValue = BitFileGetBit(stream);

            if (returnValue == 
# 858 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                              (-1)
# 858 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                                 )
            {
                return 
# 860 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                      (-1)
# 860 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                         ;
            }

            bytes[offset] <<= 1;
            bytes[offset] |= (returnValue & 0x01);
            remaining--;
        }

    }

    return count;
}
# 890 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFilePutBitsInt(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size)
{
    int returnValue;

    if ((stream == 
# 895 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                  ((void *) 0)
# 895 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                      ) || (bits == 
# 895 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                                    ((void *) 0)
# 895 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                                        ))
    {
        return(
# 897 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              (-1)
# 897 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 );
    }

    if (stream->endian == BF_LITTLE_ENDIAN)
    {
        returnValue = BitFilePutBitsLE(stream, bits, count);
    }
    else if (stream->endian == BF_BIG_ENDIAN)
    {
        returnValue = BitFilePutBitsBE(stream, bits, count, size);
    }
    else
    {
        returnValue = 
# 910 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                     (-1)
# 910 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                        ;
    }

    return returnValue;
}
# 931 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFilePutBitsLE(bit_file_t *stream, void *bits, const unsigned int count)
{
    unsigned char *bytes, tmp;
    int offset, remaining, returnValue;

    bytes = (unsigned char *)bits;
    offset = 0;
    remaining = count;


    while (remaining >= 8)
    {
        returnValue = BitFilePutChar(bytes[offset], stream);

        if (returnValue == 
# 945 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                          (-1)
# 945 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                             )
        {
            return 
# 947 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                  (-1)
# 947 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     ;
        }

        remaining -= 8;
        offset++;
    }

    if (remaining != 0)
    {

        tmp = bytes[offset];
        tmp <<= (8 - remaining);

        while (remaining > 0)
        {
            returnValue = BitFilePutBit((tmp & 0x80), stream);

            if (returnValue == 
# 964 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                              (-1)
# 964 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                                 )
            {
                return 
# 966 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                      (-1)
# 966 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                         ;
            }

            tmp <<= 1;
            remaining--;
        }
    }

    return count;
}
# 992 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
int BitFilePutBitsBE(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size)
{
    unsigned char *bytes, tmp;
    int offset, remaining, returnValue;

    if (count > (size * 8))
    {

        return 
# 1001 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
              (-1)
# 1001 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                 ;
    }

    bytes = (unsigned char *)bits;
    offset = size - 1;
    remaining = count;


    while (remaining >= 8)
    {
        returnValue = BitFilePutChar(bytes[offset], stream);

        if (returnValue == 
# 1013 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                          (-1)
# 1013 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                             )
        {
            return 
# 1015 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                  (-1)
# 1015 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                     ;
        }

        remaining -= 8;
        offset--;
    }

    if (remaining != 0)
    {

        tmp = bytes[offset];
        tmp <<= (8 - remaining);

        while (remaining > 0)
        {
            returnValue = BitFilePutBit((tmp & 0x80), stream);

            if (returnValue == 
# 1032 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                              (-1)
# 1032 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                                 )
            {
                return 
# 1034 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c" 3 4
                      (-1)
# 1034 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.c"
                         ;
            }

            tmp <<= 1;
            remaining--;
        }
    }

    return count;
}
