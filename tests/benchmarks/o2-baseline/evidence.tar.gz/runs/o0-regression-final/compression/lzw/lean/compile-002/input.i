# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
# 64 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 29 "/usr/include/stdio.h" 2 3 4









# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4

# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef unsigned long size_t;
# 39 "/usr/include/stdio.h" 2 3 4


# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 1 3 4
# 43 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 42 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 45 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 46 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 47 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 48 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 2 3 4

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2:24;

  char _short_backupbuf[1];
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;

  int _unused3;

  __uint64_t _total_written;




  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
# 49 "/usr/include/stdio.h" 2 3 4
# 89 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;
# 133 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 134 "/usr/include/stdio.h" 2 3 4
# 153 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) ;

extern int rename (const char *__old, const char *__new) ;
# 191 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) ;
# 201 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  ;
# 218 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) ;
# 243 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 271 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *restrict __filename,
      const char *restrict __modes)
  ;




extern FILE *freopen (const char *restrict __filename,
        const char *restrict __modes,
        FILE *restrict __stream) ;
# 341 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *restrict __stream, char *restrict __buf)
  ;



extern int setvbuf (FILE *restrict __stream, char *restrict __buf,
      int __modes, size_t __n) ;
# 364 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *restrict __stream,
      const char *restrict __format, ...) ;




extern int printf (const char *restrict __format, ...);

extern int sprintf (char *restrict __s,
      const char *restrict __format, ...) ;





extern int vfprintf (FILE *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;




extern int vprintf (const char *restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;



extern int snprintf (char *restrict __s, size_t __maxlen,
       const char *restrict __format, ...)
     ;

extern int vsnprintf (char *restrict __s, size_t __maxlen,
        const char *restrict __format, __gnuc_va_list __arg)
     ;
# 429 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *restrict __stream,
     const char *restrict __format, ...) ;




extern int scanf (const char *restrict __format, ...) ;

extern int sscanf (const char *restrict __s,
     const char *restrict __format, ...) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 445 "/usr/include/stdio.h" 2 3 4
# 479 "/usr/include/stdio.h" 3 4
extern int __isoc99_fscanf (FILE *restrict __stream,
       const char *restrict __format, ...)
  ;
extern int __isoc99_scanf (const char *restrict __format, ...) ;
extern int __isoc99_sscanf (const char *restrict __s,
       const char *restrict __format, ...) ;
# 497 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *restrict __s, const char *restrict __format,
      __gnuc_va_list __arg)
     ;





extern int vscanf (const char *restrict __format, __gnuc_va_list __arg)
     ;


extern int vsscanf (const char *restrict __s,
      const char *restrict __format, __gnuc_va_list __arg)
     ;
# 561 "/usr/include/stdio.h" 3 4
extern int __isoc99_vfscanf (FILE *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
extern int __isoc99_vscanf (const char *restrict __format,
       __gnuc_va_list __arg) ;
extern int __isoc99_vsscanf (const char *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
# 582 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) ;
extern int getc (FILE *__stream) ;





extern int getchar (void);
# 615 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) ;
extern int putc (int __c, FILE *__stream) ;





extern int putchar (int __c);
# 658 "/usr/include/stdio.h" 3 4
extern char *fgets (char *restrict __s, int __n, FILE *restrict __stream)
     ;
# 671 "/usr/include/stdio.h" 3 4
extern char *gets (char *__s) ;
# 711 "/usr/include/stdio.h" 3 4
extern int fputs (const char *restrict __s, FILE *restrict __stream)
  ;





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) ;






extern size_t fread (void *restrict __ptr, size_t __size,
       size_t __n, FILE *restrict __stream)
  ;




extern size_t fwrite (const void *restrict __ptr, size_t __size,
        size_t __n, FILE *restrict __s) ;
# 773 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  ;




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream) ;
# 823 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *restrict __stream, fpos_t *restrict __pos)
  ;




extern int fsetpos (FILE *__stream, const fpos_t *__pos) ;
# 854 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) ;

extern int feof (FILE *__stream) ;

extern int ferror (FILE *__stream) ;
# 872 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) ;
# 953 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 977 "/usr/include/stdio.h" 3 4

# 65 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 98 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef 
# 98 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h"
       int 
# 98 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
                               wchar_t;
# 33 "/usr/include/stdlib.h" 2 3 4


# 63 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





 typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 102 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) ;



extern double atof (const char *__nptr)
     ;

extern int atoi (const char *__nptr)
     ;

extern long int atol (const char *__nptr)
     ;



 extern long long int atoll (const char *__nptr)
     ;



extern double strtod (const char *restrict __nptr,
        char **restrict __endptr)
     ;



extern float strtof (const char *restrict __nptr,
       char **restrict __endptr) ;

extern long double strtold (const char *restrict __nptr,
       char **restrict __endptr)
     ;
# 181 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *restrict __nptr,
   char **restrict __endptr, int __base)
     ;

extern unsigned long int strtoul (const char *restrict __nptr,
      char **restrict __endptr, int __base)
     ;
# 204 "/usr/include/stdlib.h" 3 4

extern long long int strtoll (const char *restrict __nptr,
         char **restrict __endptr, int __base)
     ;


extern unsigned long long int strtoull (const char *restrict __nptr,
     char **restrict __endptr, int __base)
     ;
# 577 "/usr/include/stdlib.h" 3 4
extern int rand (void) ;

extern void srand (unsigned int __seed) ;
# 676 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size)
     ;

extern void *calloc (size_t __nmemb, size_t __size)
     ;






extern void *realloc (void *__ptr, size_t __size)
     ;


extern void free (void *__ptr) ;
# 752 "/usr/include/stdlib.h" 3 4
extern void abort (void) ;



extern int atexit (void (*__func) (void)) ;
# 778 "/usr/include/stdlib.h" 3 4
extern void exit (int __status) ;
# 790 "/usr/include/stdlib.h" 3 4
extern void _Exit (int __status) ;




extern char *getenv (const char *__name) ;
# 945 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 970 "/usr/include/stdlib.h" 3 4
typedef int (*__compar_fn_t) (const void *, const void *);
# 982 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     ;
# 998 "/usr/include/stdlib.h" 3 4
extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) ;
# 1008 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) ;
extern long int labs (long int __x) ;


 extern long long int llabs (long long int __x)
     ;
# 1026 "/usr/include/stdlib.h" 3 4
extern div_t div (int __numer, int __denom)
     ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     ;


 extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     ;
# 1096 "/usr/include/stdlib.h" 3 4
extern int mblen (const char *__s, size_t __n) ;


extern int mbtowc (wchar_t *restrict __pwc,
     const char *restrict __s, size_t __n) ;


extern int wctomb (char *__s, wchar_t __wchar) ;



extern size_t mbstowcs (wchar_t *restrict __pwcs,
   const char *restrict __s, size_t __n)
    ;

extern size_t wcstombs (char *restrict __s,
   const wchar_t *restrict __pwcs, size_t __n)
    
 
  ;
# 1202 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1203 "/usr/include/stdlib.h" 2 3 4
# 1214 "/usr/include/stdlib.h" 3 4

# 66 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 2
# 1 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 1 3 4
# 34 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 3 4
# 1 "/usr/lib/gcc/x86_64-linux-gnu/15/include/syslimits.h" 1 3 4






 
# 7 "/usr/lib/gcc/x86_64-linux-gnu/15/include/syslimits.h" 3 4
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 1 3 4
# 210 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 3 4
# 1 "/usr/include/limits.h" 1 3 4
# 26 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/limits.h" 2 3 4
# 45 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 46 "/usr/include/limits.h" 2 3 4
# 211 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 2 3 4
# 10 "/usr/lib/gcc/x86_64-linux-gnu/15/include/syslimits.h" 2 3 4
#pragma GCC diagnostic pop
# 35 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 2 3 4
# 67 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4


# 37 "/usr/include/string.h" 3 4
# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 38 "/usr/include/string.h" 2 3 4
# 47 "/usr/include/string.h" 3 4
extern void *memcpy (void *restrict __dest, const void *restrict __src,
       size_t __n) ;


extern void *memmove (void *__dest, const void *__src, size_t __n)
     ;
# 65 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) ;
# 75 "/usr/include/string.h" 3 4
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     ;
# 91 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     ;
# 118 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      ;
# 156 "/usr/include/string.h" 3 4
extern char *strcpy (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncpy (char *restrict __dest,
        const char *restrict __src, size_t __n)
     ;


extern char *strcat (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncat (char *restrict __dest, const char *restrict __src,
        size_t __n) ;


extern int strcmp (const char *__s1, const char *__s2)
     ;

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     ;


extern int strcoll (const char *__s1, const char *__s2)
     ;

extern size_t strxfrm (char *restrict __dest,
         const char *restrict __src, size_t __n)
    ;
# 261 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     ;
# 292 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     ;
# 316 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     ;


extern size_t strspn (const char *__s, const char *__accept)
     ;
# 346 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     ;
# 377 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     ;
# 388 "/usr/include/string.h" 3 4
extern char *strtok (char *restrict __s, const char *restrict __delim)
     ;



extern char *__strtok_r (char *restrict __s,
    const char *restrict __delim,
    char **restrict __save_ptr)
     ;
# 439 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     ;
# 451 "/usr/include/string.h" 3 4
extern char *strerror (int __errnum) ;
# 584 "/usr/include/string.h" 3 4

# 68 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzw.h" 1
# 65 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzw.h"

# 65 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzw.h"
int LZWEncodeFile(char *inFile, char *outFile);


int LZWDecodeFile(char *inFile, char *outFile);
# 69 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.h" 1
# 74 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/bitfile.h"
typedef enum
{
    BF_READ = 0,
    BF_WRITE = 1,
    BF_APPEND= 2,
    BF_NO_MODE
} BF_MODES;


struct bit_file_t;
typedef struct bit_file_t bit_file_t;






bit_file_t *BitFileOpen(const char *fileName, const BF_MODES mode);
bit_file_t *MakeBitFile(FILE *stream, const BF_MODES mode);
int BitFileClose(bit_file_t *stream);
FILE *BitFileToFILE(bit_file_t *stream);


int BitFileByteAlign(bit_file_t *stream);


int BitFileGetChar(bit_file_t *stream);
int BitFilePutChar(const int c, bit_file_t *stream);


int BitFileGetBit(bit_file_t *stream);
int BitFilePutBit(const int c, bit_file_t *stream);


int BitFileGetBits(bit_file_t *stream, void *bits, const unsigned int count);
int BitFilePutBits(bit_file_t *stream, void *bits, const unsigned int count);






int BitFileGetBitsInt(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size);
int BitFilePutBitsInt(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size);
# 70 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 2





typedef struct dict_node_t
{
    unsigned int codeWord;
    unsigned char suffixChar;
    unsigned int prefixCode;


    struct dict_node_t *left;
    struct dict_node_t *right;
} dict_node_t;
# 123 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
extern char currentCodeLen;






dict_node_t *MakeNode(unsigned int codeWord,
    unsigned int prefixCode, unsigned char suffixChar);
void FreeTree(dict_node_t *node);


dict_node_t *FindDictionaryEntry(dict_node_t *root, int prefixCode,
    unsigned char c);


unsigned int MakeKey(unsigned int prefixCode, unsigned char suffixChar);


void PutCodeWord(int code, bit_file_t *bfpOut);
# 158 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
int LZWEncodeFile(char *inFile, char *outFile)
{
    FILE *fpIn;
    bit_file_t *bfpOut;

    int code;
    unsigned int nextCode;
    int c;

    dict_node_t *dictRoot;
    dict_node_t *node;


    if (
# 171 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
       ((void *) 0) 
# 171 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
            == (fpIn = fopen(inFile, "rb")))
    {
        perror(inFile);
        return 0;
    }

    if (
# 177 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
       ((void *) 0) 
# 177 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
            == outFile)
    {
        bfpOut = MakeBitFile(
# 179 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
                            stdout
# 179 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                                  , BF_WRITE);
    }
    else
    {
        if (
# 183 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
           ((void *) 0) 
# 183 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                == (bfpOut = BitFileOpen(outFile, BF_WRITE)))
        {
            fclose(fpIn);
            perror(outFile);
            return 0;
        }
    }


    dictRoot = 
# 192 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
              ((void *) 0)
# 192 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                  ;


    currentCodeLen = 9;

    nextCode = (1 << 8
# 197 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
              );



    code = fgetc(fpIn);


    if ((c = fgetc(fpIn)) != 
# 204 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
                            (-1)
# 204 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                               )
    {

        dictRoot = MakeNode(nextCode, code, c);
        nextCode++;


        PutCodeWord(code, bfpOut);


        code = c;
    }


    while ((c = fgetc(fpIn)) != 
# 218 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
                               (-1)
# 218 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                                  )
    {

        node = FindDictionaryEntry(dictRoot, code, c);

        if ((node->prefixCode == code) &&
            (node->suffixChar == c))
        {

            code = node->codeWord;
        }
        else
        {

            if (nextCode < (1 << 15))
            {
                dict_node_t *tmp;

                tmp = MakeNode(nextCode, code, c);
                nextCode++;

                if (MakeKey(code, c) <
                    MakeKey(node->prefixCode, node->suffixChar))
                {
                    node->left = tmp;
                }
                else
                {
                    node->right = tmp;
                }
            }


            if ((code >= ((1 << (currentCodeLen)) - 1)) &&
                (currentCodeLen < 15))
            {

                PutCodeWord(((1 << (currentCodeLen)) - 1), bfpOut);
                currentCodeLen++;
            }


            PutCodeWord(code, bfpOut);


            code = c;
        }
    }


    PutCodeWord(code, bfpOut);

    fclose(fpIn);
    BitFileClose(bfpOut);


    if (dictRoot != 
# 274 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
                   ((void *) 0)
# 274 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                       )
    {
        FreeTree(dictRoot);
    }

    return 1;
}
# 294 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
unsigned int MakeKey(unsigned int prefixCode, unsigned char suffixChar)
{
    unsigned int key;


    key = suffixChar & 0xF0;
    key <<= 15;


    key |= (prefixCode << 4);


    key |= (suffixChar & 0x0F);

    return key;
}
# 323 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
dict_node_t *MakeNode(unsigned int codeWord,
    unsigned int prefixCode, unsigned char suffixChar)
{
    dict_node_t *node;

    node = malloc(sizeof(dict_node_t));

    if (
# 330 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
       ((void *) 0) 
# 330 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
            != node)
    {
        node->codeWord = codeWord;
        node->prefixCode = prefixCode;
        node->suffixChar = suffixChar;

        node->left = 
# 336 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
                    ((void *) 0)
# 336 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                        ;
        node->right = 
# 337 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
                     ((void *) 0)
# 337 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                         ;
    }
    else
    {
        perror("allocating dictionary node");
        exit(
# 342 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
            1
# 342 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                        );
    }

    return node;
}
# 356 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
void FreeTree(dict_node_t *node)
{

    if (node->left != 
# 359 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
                     ((void *) 0)
# 359 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                         )
    {
        FreeTree(node->left);
    }


    if (node->right != 
# 365 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
                      ((void *) 0)
# 365 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                          )
    {
        FreeTree(node->right);
    }


    free(node);
}
# 387 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
dict_node_t *FindDictionaryEntry(dict_node_t *root, int prefixCode,
    unsigned char c)
{
    unsigned int searchKey, key;

    if (
# 392 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
       ((void *) 0) 
# 392 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
            == root)
    {
        return 
# 394 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
              ((void *) 0)
# 394 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                  ;
    }

    searchKey = MakeKey(prefixCode, c);

    while (1)
    {

        key = MakeKey(root->prefixCode, root->suffixChar);

        if (key == searchKey)
        {

            return root;
        }
        else if (searchKey < key)
        {
            if (
# 411 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
               ((void *) 0) 
# 411 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                    != root->left)
            {

                root = root->left;
            }
            else
            {

                return root;
            }
        }
        else
        {
            if (
# 424 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
               ((void *) 0) 
# 424 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                    != root->right)
            {

                root = root->right;
            }
            else
            {

                return root;
            }
        }
    }
}
# 453 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
void PutCodeWord(int code, bit_file_t *bfpOut)
{
    unsigned char byte;


    byte = code & 0xFF;
    BitFilePutChar(byte, bfpOut);


    byte = (code >> ((currentCodeLen) - 8
# 462 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                   )) &
        (
# 463 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c" 3 4
       (0x7f * 2 + 1) 
# 463 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
       << (8 
# 463 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
       - ((currentCodeLen) - 8
# 463 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
       )));
    BitFilePutBits(bfpOut, &byte, ((currentCodeLen) - 8
# 464 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzw/lean/compression/lzwencode.c"
                                 ));
}
