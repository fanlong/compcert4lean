# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
# 86 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 29 "/usr/include/stdio.h" 2 3 4









# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4

# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef unsigned long size_t;
# 39 "/usr/include/stdio.h" 2 3 4


# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 1 3 4
# 43 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 42 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 45 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 46 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 47 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 48 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 2 3 4

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2:24;

  char _short_backupbuf[1];
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;

  int _unused3;

  __uint64_t _total_written;




  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
# 49 "/usr/include/stdio.h" 2 3 4
# 89 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;
# 133 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 134 "/usr/include/stdio.h" 2 3 4
# 153 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) ;

extern int rename (const char *__old, const char *__new) ;
# 191 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) ;
# 201 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  ;
# 218 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) ;
# 243 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 271 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *restrict __filename,
      const char *restrict __modes)
  ;




extern FILE *freopen (const char *restrict __filename,
        const char *restrict __modes,
        FILE *restrict __stream) ;
# 341 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *restrict __stream, char *restrict __buf)
  ;



extern int setvbuf (FILE *restrict __stream, char *restrict __buf,
      int __modes, size_t __n) ;
# 364 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *restrict __stream,
      const char *restrict __format, ...) ;




extern int printf (const char *restrict __format, ...);

extern int sprintf (char *restrict __s,
      const char *restrict __format, ...) ;





extern int vfprintf (FILE *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;




extern int vprintf (const char *restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;



extern int snprintf (char *restrict __s, size_t __maxlen,
       const char *restrict __format, ...)
     ;

extern int vsnprintf (char *restrict __s, size_t __maxlen,
        const char *restrict __format, __gnuc_va_list __arg)
     ;
# 429 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *restrict __stream,
     const char *restrict __format, ...) ;




extern int scanf (const char *restrict __format, ...) ;

extern int sscanf (const char *restrict __s,
     const char *restrict __format, ...) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 445 "/usr/include/stdio.h" 2 3 4
# 479 "/usr/include/stdio.h" 3 4
extern int __isoc99_fscanf (FILE *restrict __stream,
       const char *restrict __format, ...)
  ;
extern int __isoc99_scanf (const char *restrict __format, ...) ;
extern int __isoc99_sscanf (const char *restrict __s,
       const char *restrict __format, ...) ;
# 497 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *restrict __s, const char *restrict __format,
      __gnuc_va_list __arg)
     ;





extern int vscanf (const char *restrict __format, __gnuc_va_list __arg)
     ;


extern int vsscanf (const char *restrict __s,
      const char *restrict __format, __gnuc_va_list __arg)
     ;
# 561 "/usr/include/stdio.h" 3 4
extern int __isoc99_vfscanf (FILE *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
extern int __isoc99_vscanf (const char *restrict __format,
       __gnuc_va_list __arg) ;
extern int __isoc99_vsscanf (const char *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
# 582 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) ;
extern int getc (FILE *__stream) ;





extern int getchar (void);
# 615 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) ;
extern int putc (int __c, FILE *__stream) ;





extern int putchar (int __c);
# 658 "/usr/include/stdio.h" 3 4
extern char *fgets (char *restrict __s, int __n, FILE *restrict __stream)
     ;
# 671 "/usr/include/stdio.h" 3 4
extern char *gets (char *__s) ;
# 711 "/usr/include/stdio.h" 3 4
extern int fputs (const char *restrict __s, FILE *restrict __stream)
  ;





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) ;






extern size_t fread (void *restrict __ptr, size_t __size,
       size_t __n, FILE *restrict __stream)
  ;




extern size_t fwrite (const void *restrict __ptr, size_t __size,
        size_t __n, FILE *restrict __s) ;
# 773 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  ;




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream) ;
# 823 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *restrict __stream, fpos_t *restrict __pos)
  ;




extern int fsetpos (FILE *__stream, const fpos_t *__pos) ;
# 854 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) ;

extern int feof (FILE *__stream) ;

extern int ferror (FILE *__stream) ;
# 872 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) ;
# 953 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 977 "/usr/include/stdio.h" 3 4

# 87 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 98 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef 
# 98 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h"
       int 
# 98 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
                               wchar_t;
# 33 "/usr/include/stdlib.h" 2 3 4


# 63 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





 typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 102 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) ;



extern double atof (const char *__nptr)
     ;

extern int atoi (const char *__nptr)
     ;

extern long int atol (const char *__nptr)
     ;



 extern long long int atoll (const char *__nptr)
     ;



extern double strtod (const char *restrict __nptr,
        char **restrict __endptr)
     ;



extern float strtof (const char *restrict __nptr,
       char **restrict __endptr) ;

extern long double strtold (const char *restrict __nptr,
       char **restrict __endptr)
     ;
# 181 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *restrict __nptr,
   char **restrict __endptr, int __base)
     ;

extern unsigned long int strtoul (const char *restrict __nptr,
      char **restrict __endptr, int __base)
     ;
# 204 "/usr/include/stdlib.h" 3 4

extern long long int strtoll (const char *restrict __nptr,
         char **restrict __endptr, int __base)
     ;


extern unsigned long long int strtoull (const char *restrict __nptr,
     char **restrict __endptr, int __base)
     ;
# 577 "/usr/include/stdlib.h" 3 4
extern int rand (void) ;

extern void srand (unsigned int __seed) ;
# 676 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size)
     ;

extern void *calloc (size_t __nmemb, size_t __size)
     ;






extern void *realloc (void *__ptr, size_t __size)
     ;


extern void free (void *__ptr) ;
# 752 "/usr/include/stdlib.h" 3 4
extern void abort (void) ;



extern int atexit (void (*__func) (void)) ;
# 778 "/usr/include/stdlib.h" 3 4
extern void exit (int __status) ;
# 790 "/usr/include/stdlib.h" 3 4
extern void _Exit (int __status) ;




extern char *getenv (const char *__name) ;
# 945 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 970 "/usr/include/stdlib.h" 3 4
typedef int (*__compar_fn_t) (const void *, const void *);
# 982 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     ;
# 998 "/usr/include/stdlib.h" 3 4
extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) ;
# 1008 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) ;
extern long int labs (long int __x) ;


 extern long long int llabs (long long int __x)
     ;
# 1026 "/usr/include/stdlib.h" 3 4
extern div_t div (int __numer, int __denom)
     ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     ;


 extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     ;
# 1096 "/usr/include/stdlib.h" 3 4
extern int mblen (const char *__s, size_t __n) ;


extern int mbtowc (wchar_t *restrict __pwc,
     const char *restrict __s, size_t __n) ;


extern int wctomb (char *__s, wchar_t __wchar) ;



extern size_t mbstowcs (wchar_t *restrict __pwcs,
   const char *restrict __s, size_t __n)
    ;

extern size_t wcstombs (char *restrict __s,
   const wchar_t *restrict __pwcs, size_t __n)
    
 
  ;
# 1202 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1203 "/usr/include/stdlib.h" 2 3 4
# 1214 "/usr/include/stdlib.h" 3 4

# 88 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4


# 37 "/usr/include/string.h" 3 4
# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 38 "/usr/include/string.h" 2 3 4
# 47 "/usr/include/string.h" 3 4
extern void *memcpy (void *restrict __dest, const void *restrict __src,
       size_t __n) ;


extern void *memmove (void *__dest, const void *__src, size_t __n)
     ;
# 65 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) ;
# 75 "/usr/include/string.h" 3 4
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     ;
# 91 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     ;
# 118 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      ;
# 156 "/usr/include/string.h" 3 4
extern char *strcpy (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncpy (char *restrict __dest,
        const char *restrict __src, size_t __n)
     ;


extern char *strcat (char *restrict __dest, const char *restrict __src)
     ;

extern char *strncat (char *restrict __dest, const char *restrict __src,
        size_t __n) ;


extern int strcmp (const char *__s1, const char *__s2)
     ;

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     ;


extern int strcoll (const char *__s1, const char *__s2)
     ;

extern size_t strxfrm (char *restrict __dest,
         const char *restrict __src, size_t __n)
    ;
# 261 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     ;
# 292 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     ;
# 316 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     ;


extern size_t strspn (const char *__s, const char *__accept)
     ;
# 346 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     ;
# 377 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     ;
# 388 "/usr/include/string.h" 3 4
extern char *strtok (char *restrict __s, const char *restrict __delim)
     ;



extern char *__strtok_r (char *restrict __s,
    const char *restrict __delim,
    char **restrict __save_ptr)
     ;
# 439 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     ;
# 451 "/usr/include/string.h" 3 4
extern char *strerror (int __errnum) ;
# 584 "/usr/include/string.h" 3 4

# 89 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzlocal.h" 1
# 62 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzlocal.h"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 1 3 4
# 34 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 3 4
# 1 "/usr/lib/gcc/x86_64-linux-gnu/15/include/syslimits.h" 1 3 4






 
# 7 "/usr/lib/gcc/x86_64-linux-gnu/15/include/syslimits.h" 3 4
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 1 3 4
# 210 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 3 4
# 1 "/usr/include/limits.h" 1 3 4
# 26 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/limits.h" 2 3 4
# 45 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 46 "/usr/include/limits.h" 2 3 4
# 211 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 2 3 4
# 10 "/usr/lib/gcc/x86_64-linux-gnu/15/include/syslimits.h" 2 3 4
#pragma GCC diagnostic pop
# 35 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 2 3 4
# 63 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzlocal.h" 2
# 96 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzlocal.h"

# 96 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzlocal.h"
typedef struct encoded_string_t
{
    unsigned int offset;
    unsigned int length;
} encoded_string_t;
# 115 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzlocal.h"
void InitializeSearchStructures(void);


void FindMatch(encoded_string_t * ,
               unsigned int windowHead, unsigned int uncodedHead);

void ReplaceChar(unsigned int charIndex, unsigned char replacement);
# 90 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/bitfile.h" 1
# 74 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/bitfile.h"
typedef enum
{
    BF_READ = 0,
    BF_WRITE = 1,
    BF_APPEND= 2,
    BF_NO_MODE
} BF_MODES;


struct bit_file_t;
typedef struct bit_file_t bit_file_t;






bit_file_t *BitFileOpen(const char *fileName, const BF_MODES mode);
bit_file_t *MakeBitFile(FILE *stream, const BF_MODES mode);
int BitFileClose(bit_file_t *stream);
FILE *BitFileToFILE(bit_file_t *stream);


int BitFileByteAlign(bit_file_t *stream);


int BitFileGetChar(bit_file_t *stream);
int BitFilePutChar(const int c, bit_file_t *stream);


int BitFileGetBit(bit_file_t *stream);
int BitFilePutBit(const int c, bit_file_t *stream);


int BitFileGetBits(bit_file_t *stream, void *bits, const unsigned int count);
int BitFilePutBits(bit_file_t *stream, void *bits, const unsigned int count);






int BitFileGetBitsInt(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size);
int BitFilePutBitsInt(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size);
# 91 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 2
# 104 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
extern unsigned char slidingWindow[];
extern unsigned char uncodedLookahead[];
# 128 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
int EncodeLZSSByFile(FILE *fpIn, FILE *fpOut)
{
    bit_file_t *bfpOut;

    encoded_string_t matchData;
    unsigned int i, c;
    unsigned int len;


    unsigned int windowHead, uncodedHead;


    if (fpIn == 
# 140 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
               ((void *) 0)
# 140 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                   )
    {
        fpIn = 
# 142 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
              stdin
# 142 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                   ;
    }

    if (fpOut == 
# 145 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
                ((void *) 0)
# 145 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                    )
    {

        bfpOut = MakeBitFile(
# 148 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
                            stdout
# 148 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                                  , BF_WRITE);
    }
    else
    {

        bfpOut = MakeBitFile(fpOut, BF_WRITE);
    }

    windowHead = 0;
    uncodedHead = 0;






    memset(slidingWindow, ' ', (1 << 12) * sizeof(unsigned char));





    for (len = 0; len < ((1 << 4) + 2); len++) {
        c = getc(fpIn);
        if (c == 
# 172 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
                (-1)
# 172 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                   ) break;
        uncodedLookahead[len] = c;
    }

    if (len == 0)
    {
        return (
# 178 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
               0
# 178 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                           );
    }


    InitializeSearchStructures();
    FindMatch(&matchData, windowHead, uncodedHead);


    while (len > 0)
    {
        if (matchData.length > len)
        {

            matchData.length = len;
        }

        if (matchData.length <= 2)
        {

            BitFilePutBit(1, bfpOut);
            BitFilePutChar(uncodedLookahead[uncodedHead], bfpOut);

            matchData.length = 1;
        }
        else
        {
            unsigned int adjustedLen;


            adjustedLen = matchData.length - (2 + 1);


            BitFilePutBit(0, bfpOut);
            BitFilePutBitsInt(bfpOut, &matchData.offset, 12,
                sizeof(unsigned int));
            BitFilePutBitsInt(bfpOut, &adjustedLen, 4,
                sizeof(unsigned int));
        }





        i = 0;
        while ((i < matchData.length) && ((c = getc(fpIn)) != 
# 222 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
                                                             (-1)
# 222 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                                                                ))
        {

            ReplaceChar(windowHead, uncodedLookahead[uncodedHead]);
            uncodedLookahead[uncodedHead] = c;
            windowHead = ((unsigned int)((windowHead + 1)) % (unsigned int)((1 << 12)));
            uncodedHead = ((unsigned int)((uncodedHead + 1)) % (unsigned int)(((1 << 4) + 2)));
            i++;
        }


        while (i < matchData.length)
        {
            ReplaceChar(windowHead, uncodedLookahead[uncodedHead]);

            windowHead = ((unsigned int)((windowHead + 1)) % (unsigned int)((1 << 12)));
            uncodedHead = ((unsigned int)((uncodedHead + 1)) % (unsigned int)(((1 << 4) + 2)));
            len--;
            i++;
        }


        FindMatch(&matchData, windowHead, uncodedHead);
    }


    BitFileToFILE(bfpOut);

   return (
# 250 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
          0
# 250 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                      );
}
# 263 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
int EncodeLZSSByName(char *inFile, char *outFile)
{
    FILE *fpIn, *fpOut;
    int returnValue;


    if (inFile == 
# 269 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
                 ((void *) 0)
# 269 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                     )
    {
        fpIn = 
# 271 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
              stdin
# 271 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                   ;
    }
    if ((fpIn = fopen(inFile, "rb")) == 
# 273 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
                                       ((void *) 0)
# 273 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                                           )
    {
        perror(inFile);
        return (
# 276 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
               1
# 276 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                           );
    }

    if (outFile == 
# 279 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
                  ((void *) 0)
# 279 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                      )
    {
        fpOut = 
# 281 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
               stdout
# 281 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                     ;
    }
    else
    {
        if ((fpOut = fopen(outFile, "wb")) == 
# 285 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
                                             ((void *) 0)
# 285 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                                                 )
        {
            fclose(fpIn);
            perror(outFile);
            return (
# 289 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c" 3 4
                   1
# 289 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzencode.c"
                               );
        }
    }

    returnValue = EncodeLZSSByFile(fpIn, fpOut);


    fclose(fpIn);
    fclose(fpOut);

    return (returnValue);
}
