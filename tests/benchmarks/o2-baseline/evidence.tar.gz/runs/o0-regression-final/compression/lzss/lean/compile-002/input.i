# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzvars.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzvars.c"
# 53 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzvars.c"
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzlocal.h" 1
# 62 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzlocal.h"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 1 3 4
# 34 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 3 4
# 1 "/usr/lib/gcc/x86_64-linux-gnu/15/include/syslimits.h" 1 3 4






#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 1 3 4
# 210 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 3 4
# 1 "/usr/include/limits.h" 1 3 4
# 26 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/limits.h" 2 3 4
# 45 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 46 "/usr/include/limits.h" 2 3 4
# 211 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 2 3 4
# 10 "/usr/lib/gcc/x86_64-linux-gnu/15/include/syslimits.h" 2 3 4
#pragma GCC diagnostic pop
# 35 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 2 3 4
# 63 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzlocal.h" 2
# 96 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzlocal.h"

# 96 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzlocal.h"
typedef struct encoded_string_t
{
    unsigned int offset;
    unsigned int length;
} encoded_string_t;
# 115 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzlocal.h"
void InitializeSearchStructures(void);


void FindMatch(encoded_string_t * ,
               unsigned int windowHead, unsigned int uncodedHead);

void ReplaceChar(unsigned int charIndex, unsigned char replacement);
# 54 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzvars.c" 2
# 67 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/lzss/lean/compression/lzvars.c"
unsigned char slidingWindow[(1 << 12)];
unsigned char uncodedLookahead[((1 << 4) + 2)];
