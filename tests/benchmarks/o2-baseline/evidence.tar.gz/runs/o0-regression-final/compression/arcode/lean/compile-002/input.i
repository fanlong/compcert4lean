# 0 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
# 58 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 29 "/usr/include/stdio.h" 2 3 4









# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4

# 67 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef unsigned long size_t;
# 39 "/usr/include/stdio.h" 2 3 4


# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 1 3 4
# 43 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 42 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 45 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 46 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 47 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 48 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 2 3 4

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2:24;

  char _short_backupbuf[1];
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;

  int _unused3;

  __uint64_t _total_written;




  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
# 49 "/usr/include/stdio.h" 2 3 4
# 89 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;
# 133 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 134 "/usr/include/stdio.h" 2 3 4
# 153 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) ;

extern int rename (const char *__old, const char *__new) ;
# 191 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) ;
# 201 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  ;
# 218 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) ;
# 243 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 271 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *restrict __filename,
      const char *restrict __modes)
  ;




extern FILE *freopen (const char *restrict __filename,
        const char *restrict __modes,
        FILE *restrict __stream) ;
# 341 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *restrict __stream, char *restrict __buf)
  ;



extern int setvbuf (FILE *restrict __stream, char *restrict __buf,
      int __modes, size_t __n) ;
# 364 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *restrict __stream,
      const char *restrict __format, ...) ;




extern int printf (const char *restrict __format, ...);

extern int sprintf (char *restrict __s,
      const char *restrict __format, ...) ;





extern int vfprintf (FILE *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;




extern int vprintf (const char *restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *restrict __s, const char *restrict __format,
       __gnuc_va_list __arg) ;



extern int snprintf (char *restrict __s, size_t __maxlen,
       const char *restrict __format, ...)
     ;

extern int vsnprintf (char *restrict __s, size_t __maxlen,
        const char *restrict __format, __gnuc_va_list __arg)
     ;
# 429 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *restrict __stream,
     const char *restrict __format, ...) ;




extern int scanf (const char *restrict __format, ...) ;

extern int sscanf (const char *restrict __s,
     const char *restrict __format, ...) ;





# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 445 "/usr/include/stdio.h" 2 3 4
# 479 "/usr/include/stdio.h" 3 4
extern int __isoc99_fscanf (FILE *restrict __stream,
       const char *restrict __format, ...)
  ;
extern int __isoc99_scanf (const char *restrict __format, ...) ;
extern int __isoc99_sscanf (const char *restrict __s,
       const char *restrict __format, ...) ;
# 497 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *restrict __s, const char *restrict __format,
      __gnuc_va_list __arg)
     ;





extern int vscanf (const char *restrict __format, __gnuc_va_list __arg)
     ;


extern int vsscanf (const char *restrict __s,
      const char *restrict __format, __gnuc_va_list __arg)
     ;
# 561 "/usr/include/stdio.h" 3 4
extern int __isoc99_vfscanf (FILE *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
extern int __isoc99_vscanf (const char *restrict __format,
       __gnuc_va_list __arg) ;
extern int __isoc99_vsscanf (const char *restrict __s,
        const char *restrict __format,
        __gnuc_va_list __arg) ;
# 582 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) ;
extern int getc (FILE *__stream) ;





extern int getchar (void);
# 615 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) ;
extern int putc (int __c, FILE *__stream) ;





extern int putchar (int __c);
# 658 "/usr/include/stdio.h" 3 4
extern char *fgets (char *restrict __s, int __n, FILE *restrict __stream)
     ;
# 671 "/usr/include/stdio.h" 3 4
extern char *gets (char *__s) ;
# 711 "/usr/include/stdio.h" 3 4
extern int fputs (const char *restrict __s, FILE *restrict __stream)
  ;





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) ;






extern size_t fread (void *restrict __ptr, size_t __size,
       size_t __n, FILE *restrict __stream)
  ;




extern size_t fwrite (const void *restrict __ptr, size_t __size,
        size_t __n, FILE *restrict __s) ;
# 773 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  ;




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream) ;
# 823 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *restrict __stream, fpos_t *restrict __pos)
  ;




extern int fsetpos (FILE *__stream, const fpos_t *__pos) ;
# 854 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) ;

extern int feof (FILE *__stream) ;

extern int ferror (FILE *__stream) ;
# 872 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) ;
# 953 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 977 "/usr/include/stdio.h" 3 4

# 59 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 1 3 4
# 98 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
typedef 
# 98 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h"
       int 
# 98 "/home/fanl/compcert-lean-meta/CompCert/runtime/include/stddef.h" 3 4
                               wchar_t;
# 33 "/usr/include/stdlib.h" 2 3 4


# 63 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





 typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 102 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) ;



extern double atof (const char *__nptr)
     ;

extern int atoi (const char *__nptr)
     ;

extern long int atol (const char *__nptr)
     ;



 extern long long int atoll (const char *__nptr)
     ;



extern double strtod (const char *restrict __nptr,
        char **restrict __endptr)
     ;



extern float strtof (const char *restrict __nptr,
       char **restrict __endptr) ;

extern long double strtold (const char *restrict __nptr,
       char **restrict __endptr)
     ;
# 181 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *restrict __nptr,
   char **restrict __endptr, int __base)
     ;

extern unsigned long int strtoul (const char *restrict __nptr,
      char **restrict __endptr, int __base)
     ;
# 204 "/usr/include/stdlib.h" 3 4

extern long long int strtoll (const char *restrict __nptr,
         char **restrict __endptr, int __base)
     ;


extern unsigned long long int strtoull (const char *restrict __nptr,
     char **restrict __endptr, int __base)
     ;
# 577 "/usr/include/stdlib.h" 3 4
extern int rand (void) ;

extern void srand (unsigned int __seed) ;
# 676 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size)
     ;

extern void *calloc (size_t __nmemb, size_t __size)
     ;






extern void *realloc (void *__ptr, size_t __size)
     ;


extern void free (void *__ptr) ;
# 752 "/usr/include/stdlib.h" 3 4
extern void abort (void) ;



extern int atexit (void (*__func) (void)) ;
# 778 "/usr/include/stdlib.h" 3 4
extern void exit (int __status) ;
# 790 "/usr/include/stdlib.h" 3 4
extern void _Exit (int __status) ;




extern char *getenv (const char *__name) ;
# 945 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 970 "/usr/include/stdlib.h" 3 4
typedef int (*__compar_fn_t) (const void *, const void *);
# 982 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     ;
# 998 "/usr/include/stdlib.h" 3 4
extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) ;
# 1008 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) ;
extern long int labs (long int __x) ;


 extern long long int llabs (long long int __x)
     ;
# 1026 "/usr/include/stdlib.h" 3 4
extern div_t div (int __numer, int __denom)
     ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     ;


 extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     ;
# 1096 "/usr/include/stdlib.h" 3 4
extern int mblen (const char *__s, size_t __n) ;


extern int mbtowc (wchar_t *restrict __pwc,
     const char *restrict __s, size_t __n) ;


extern int wctomb (char *__s, wchar_t __wchar) ;



extern size_t mbstowcs (wchar_t *restrict __pwcs,
   const char *restrict __s, size_t __n)
    ;

extern size_t wcstombs (char *restrict __s,
   const wchar_t *restrict __pwcs, size_t __n)
    
 
  ;
# 1202 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1203 "/usr/include/stdlib.h" 2 3 4
# 1214 "/usr/include/stdlib.h" 3 4

# 60 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 2
# 1 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 1 3 4
# 34 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 3 4
# 1 "/usr/lib/gcc/x86_64-linux-gnu/15/include/syslimits.h" 1 3 4






 
# 7 "/usr/lib/gcc/x86_64-linux-gnu/15/include/syslimits.h" 3 4
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 1 3 4
# 210 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 3 4
# 1 "/usr/include/limits.h" 1 3 4
# 26 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/limits.h" 2 3 4
# 45 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 46 "/usr/include/limits.h" 2 3 4
# 211 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 2 3 4
# 10 "/usr/lib/gcc/x86_64-linux-gnu/15/include/syslimits.h" 2 3 4
#pragma GCC diagnostic pop
# 35 "/usr/lib/gcc/x86_64-linux-gnu/15/include/limits.h" 2 3 4
# 61 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.h" 1
# 64 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.h"

# 64 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.h"
int ArEncodeFile(char *inFile, char *outFile, char staticModel);


int ArDecodeFile(char *inFile, char *outFile, char staticModel);
# 62 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 2
# 1 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/bitfile.h" 1
# 74 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/bitfile.h"
typedef enum
{
    BF_READ = 0,
    BF_WRITE = 1,
    BF_APPEND= 2,
    BF_NO_MODE
} BF_MODES;


struct bit_file_t;
typedef struct bit_file_t bit_file_t;






bit_file_t *BitFileOpen(const char *fileName, const BF_MODES mode);
bit_file_t *MakeBitFile(FILE *stream, const BF_MODES mode);
int BitFileClose(bit_file_t *stream);
FILE *BitFileToFILE(bit_file_t *stream);


int BitFileByteAlign(bit_file_t *stream);


int BitFileGetChar(bit_file_t *stream);
int BitFilePutChar(const int c, bit_file_t *stream);


int BitFileGetBit(bit_file_t *stream);
int BitFilePutBit(const int c, bit_file_t *stream);


int BitFileGetBits(bit_file_t *stream, void *bits, const unsigned int count);
int BitFilePutBits(bit_file_t *stream, void *bits, const unsigned int count);






int BitFileGetBitsInt(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size);
int BitFilePutBitsInt(bit_file_t *stream, void *bits, const unsigned int count,
    const size_t size);
# 63 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 2
# 74 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
typedef unsigned short probability_t;
# 100 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
probability_t lower;
probability_t upper;

probability_t code;

unsigned char underflowBits;


probability_t ranges[(((
# 108 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                    (0x7f * 2 + 1) 
# 108 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                    + 1)) + 1) + 1];
probability_t cumulativeProb;





void WriteHeader(bit_file_t *bfpOut);
int ReadHeader(bit_file_t *bfpIn);


void ApplySymbolRange(int symbol, char staticModel);


void WriteEncodedBits(bit_file_t *bfpOut);
void WriteRemaining(bit_file_t *bfpOut);
int BuildProbabilityRangeList(FILE *fpIn);
void InitializeAdaptiveProbabilityRangeList(void);


void InitializeDecoder(bit_file_t *bfpOut, char staticModel);
probability_t GetUnscaledCode(void);
int GetSymbolFromProbability(probability_t probability);
void ReadEncodedBits(bit_file_t *bfpIn);
# 148 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
int ArEncodeFile(char *inFile, char *outFile, char staticModel)
{
    int c;
    FILE *fpIn;
    bit_file_t *bfpOut;


    if ((fpIn = fopen(inFile, "rb")) == 
# 155 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                                       ((void *) 0)
# 155 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                                           )
    {
        perror(inFile);
        return 0;
    }

    if (outFile == 
# 161 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                  ((void *) 0)
# 161 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                      )
    {
        bfpOut = MakeBitFile(
# 163 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                            stdout
# 163 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                                  , BF_WRITE);
    }
    else
    {
        if ((bfpOut = BitFileOpen(outFile, BF_WRITE)) == 
# 167 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                                                        ((void *) 0)
# 167 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                                                            )
        {
            fclose(fpIn);
            perror(outFile);
            return 0;
        }
    }

    if (staticModel)
    {

        if (!BuildProbabilityRangeList(fpIn))
        {
            fclose(fpIn);
            BitFileClose(bfpOut);
            fprintf(
# 182 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                   stderr
# 182 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                         , "Error determining frequency ranges.\n");
            return 0;
        }

        rewind(fpIn);


        WriteHeader(bfpOut);
    }
    else
    {

        InitializeAdaptiveProbabilityRangeList();
    }


    lower = 0;
    upper = ~0;
    underflowBits = 0;


    while ((c = fgetc(fpIn)) != 
# 203 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                               (-1)
# 203 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                                  )
    {
        ApplySymbolRange(c, staticModel);
        WriteEncodedBits(bfpOut);
    }

    fclose(fpIn);

    ApplySymbolRange((
# 211 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                    (0x7f * 2 + 1) 
# 211 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                    + 1), staticModel);
    WriteEncodedBits(bfpOut);

    WriteRemaining(bfpOut);
    BitFileClose(bfpOut);

    return 1;
}
# 231 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
void SymbolCountToProbabilityRanges(void)
{
    int c;

    ranges[0] = 0;
    ranges[(((
# 236 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
          (0x7f * 2 + 1) 
# 236 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
          + 1)) + 1)] = 1;
    cumulativeProb++;


    for (c = 1; c <= (((
# 240 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                    (0x7f * 2 + 1) 
# 240 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                    + 1)) + 1); c++)
    {
        ranges[c] += ranges[c - 1];
    }
# 253 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
    return;
}
# 266 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
int BuildProbabilityRangeList(FILE *fpIn)
{
    int c;






    unsigned long countArray[(
# 275 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                            (0x7f * 2 + 1) 
# 275 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                            + 1)];
    unsigned long totalCount = 0;
    unsigned long rescaleValue;

    if (fpIn == 
# 279 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
               ((void *) 0)
# 279 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                   )
    {
        return 0;
    }


    for (c = 0; c < (
# 285 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                   (0x7f * 2 + 1) 
# 285 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                   + 1); c++)
    {
        countArray[c] = 0;
    }

    while ((c = fgetc(fpIn)) != 
# 290 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                               (-1)
# 290 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                                  )
    {
        if (totalCount == 
# 292 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                         (0x7fffffffffffffffL * 2UL + 1UL)
# 292 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                                  )
        {
            fprintf(
# 294 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                   stderr
# 294 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                         , "Error: file too large\n");
            return 0;
        }

        countArray[c]++;
        totalCount++;
    }


    if (totalCount >= (1 << ((8 * sizeof(probability_t)) - 2)))
    {
        rescaleValue = (totalCount / (1 << ((8 * sizeof(probability_t)) - 2))) + 1;

        for (c = 0; c < (
# 307 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                       (0x7f * 2 + 1) 
# 307 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                       + 1); c++)
        {
            if (countArray[c] > rescaleValue)
            {
                countArray[c] /= rescaleValue;
            }
            else if (countArray[c] != 0)
            {
                countArray[c] = 1;
            }
        }
    }


    ranges[0] = 0;
    cumulativeProb = 0;
    for (c = 0; c < (
# 323 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                   (0x7f * 2 + 1) 
# 323 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                   + 1); c++)
    {
        ranges[((c) + 1)] = countArray[c];
        cumulativeProb += countArray[c];
    }


    SymbolCountToProbabilityRanges();
    return 1;
}
# 344 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
void WriteHeader(bit_file_t *bfpOut)
{
    int c;
    probability_t previous = 0;





    for(c = 0; c <= ((
# 353 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                    (0x7f * 2 + 1) 
# 353 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                    + 1) - 1); c++)
    {
        if (ranges[((c) + 1)] > previous)
        {

            BitFilePutChar((char)c, bfpOut);
            previous = (ranges[((c) + 1)] - previous);






            BitFilePutBitsInt(bfpOut, &previous, ((8 * sizeof(probability_t)) - 2),
                sizeof(probability_t));


            previous = ranges[((c) + 1)];
        }
    }


    BitFilePutChar(0x00, bfpOut);
    previous = 0;
    BitFilePutBits(bfpOut, (void *)&previous, (8 * sizeof(probability_t)) - 2);
}
# 393 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
void InitializeAdaptiveProbabilityRangeList(void)
{
    int c;

    cumulativeProb = 0;
    ranges[0] = 0;


    for (c = 1; c <= (((
# 401 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                    (0x7f * 2 + 1) 
# 401 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                    + 1)) + 1); c++)
    {
        ranges[c] = ranges[c - 1] + 1;
        cumulativeProb++;
    }
# 415 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
    return;
}
# 435 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
void ApplySymbolRange(int symbol, char staticModel)
{
    unsigned long range;
    unsigned long rescaled;



    int i;
    probability_t original;
    probability_t delta;





    range = (unsigned long)(upper - lower) + 1;


    rescaled = (unsigned long)ranges[((symbol) + 1)] * range;
    rescaled /= (unsigned long)cumulativeProb;


    upper = lower + (probability_t)rescaled - 1;


    rescaled = (unsigned long)ranges[(symbol)] * range;
    rescaled /= (unsigned long)cumulativeProb;


    lower = lower + (probability_t)rescaled;

    if (!staticModel)
    {

        cumulativeProb++;
        for (i = ((symbol) + 1); i <= (((
# 470 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                                    (0x7f * 2 + 1) 
# 470 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                                    + 1)) + 1); i++)
        {
            ranges[i] += 1;
        }


        if (cumulativeProb >= (1 << ((8 * sizeof(probability_t)) - 2)))
        {
            cumulativeProb = 0;
            original = 0;

            for (i = 1; i <= (((
# 481 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                            (0x7f * 2 + 1) 
# 481 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                            + 1)) + 1); i++)
            {
                delta = ranges[i] - original;
                if (delta <= 2)
                {

                    original = ranges[i];
                    ranges[i] = ranges[i - 1] + 1;
                }
                else
                {
                    original = ranges[i];
                    ranges[i] = ranges[i - 1] + (delta / 2);
                }

                cumulativeProb += (ranges[i] - ranges[i - 1]);
            }
        }
    }
# 508 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
}
# 530 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
void WriteEncodedBits(bit_file_t *bfpOut)
{
    for (;;)
    {
        if ((upper & (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (0))))) == (lower & (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (0))))))
        {

            BitFilePutBit((upper & (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (0))))) != 0, bfpOut);


            while (underflowBits > 0)
            {
                BitFilePutBit((upper & (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (0))))) == 0, bfpOut);
                underflowBits--;
            }
        }
        else if ((lower & (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (1))))) && !(upper & (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (1))))))
        {





            underflowBits += 1;
            lower &= ~((probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (0)))) | (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (1)))));
            upper |= (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (1))));





        }
        else
        {

            return ;
        }





        lower <<= 1;
        upper <<= 1;
        upper |= 1;
    }
}
# 588 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
void WriteRemaining(bit_file_t *bfpOut)
{
    BitFilePutBit((lower & (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (1))))) != 0, bfpOut);


    for (underflowBits++; underflowBits > 0; underflowBits--)
    {
        BitFilePutBit((lower & (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (1))))) == 0, bfpOut);
    }
}
# 610 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
int ArDecodeFile(char *inFile, char *outFile, char staticModel)
{
    int c;
    probability_t unscaled;
    bit_file_t *bfpIn;
    FILE *fpOut;


    if ((bfpIn = BitFileOpen(inFile, BF_READ)) == 
# 618 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                                                 ((void *) 0)
# 618 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                                                     )
    {
        perror(inFile);
        return 0;
    }

    if (outFile == 
# 624 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                  ((void *) 0)
# 624 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                      )
    {
        fpOut = 
# 626 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
               stdout
# 626 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                     ;
    }
    else
    {
        if ((fpOut = fopen(outFile, "wb")) == 
# 630 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                                             ((void *) 0)
# 630 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                                                 )
        {
            BitFileClose(bfpIn);
            perror(outFile);
            return 0;
        }
    }

    if (staticModel)
    {

        if (ReadHeader(bfpIn) == 0)
        {
            BitFileClose(bfpIn);
            fclose(fpOut);
            return 0;
        }
    }


    InitializeDecoder(bfpIn, staticModel);


    for (;;)
    {

        unscaled = GetUnscaledCode();


        if((c = GetSymbolFromProbability(unscaled)) == -1)
        {

            break;
        }

        if (c == (
# 665 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                (0x7f * 2 + 1) 
# 665 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                + 1))
        {

            break;
        }

        fputc((char)c, fpOut);


        ApplySymbolRange(c, staticModel);
        ReadEncodedBits(bfpIn);
    }

    fclose(fpOut);
    BitFileClose(bfpIn);

    return 1;
}
# 694 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
int ReadHeader(bit_file_t *bfpIn)
{
    int c;
    probability_t count;





    cumulativeProb = 0;

    for (c = 0; c < (((
# 705 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                   (0x7f * 2 + 1) 
# 705 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                   + 1)) + 1); c++)
    {
        ranges[((c) + 1)] = 0;
    }


    for (;;)
    {
        c = BitFileGetChar(bfpIn);
        count = 0;


       if (BitFileGetBitsInt(bfpIn, &count, ((8 * sizeof(probability_t)) - 2),
            sizeof(probability_t)) == 
# 718 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                                     (-1)
# 718 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                                        )
        {

            fprintf(
# 721 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                   stderr
# 721 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                         , "Error: unexpected EOF\n");
            return 0;
        }





        if (count == 0)
        {

            break;
        }

        ranges[((c) + 1)] = count;
        cumulativeProb += count;
    }


    SymbolCountToProbabilityRanges();
    return 1;
}
# 756 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
void InitializeDecoder(bit_file_t *bfpIn, char staticModel)
{
    int i;

    if (!staticModel)
    {

        InitializeAdaptiveProbabilityRangeList();
    }

    code = 0;


    for (i = 0; i < (8 * sizeof(probability_t)); i++)
    {
        code <<= 1;


        if(BitFileGetBit(bfpIn) == 1)
        {
            code |= 1;
        }
    }


    lower = 0;
    upper = ~0;
}
# 794 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
probability_t GetUnscaledCode(void)
{
    unsigned long range;
    unsigned long unscaled;

    range = (unsigned long)(upper - lower) + 1;


    unscaled = (unsigned long)(code - lower) + 1;
    unscaled = unscaled * (unsigned long)cumulativeProb - 1;
    unscaled /= range;

    return ((probability_t)unscaled);
}
# 818 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
int GetSymbolFromProbability(probability_t probability)
{
    int first, last, middle;

    first = 0;
    last = (((
# 823 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
          (0x7f * 2 + 1) 
# 823 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
          + 1)) + 1);
    middle = last / 2;


    while (last >= first)
    {
        if (probability < ranges[(middle)])
        {

            last = middle - 1;
            middle = first + ((last - first) / 2);
            continue;
        }

        if (probability >= ranges[((middle) + 1)])
        {

            first = middle + 1;
            middle = first + ((last - first) / 2);
            continue;
        }


        return middle;
    }


    fprintf(
# 850 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
           stderr
# 850 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                 , "Unknown Symbol: %d (max: %d)\n", probability,
        ranges[(((
# 851 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
              (0x7f * 2 + 1) 
# 851 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
              + 1)) + 1)]);
    return -1;
}
# 877 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
void ReadEncodedBits(bit_file_t *bfpIn)
{
    int nextBit;

    for (;;)
    {
        if (( upper & (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (0))))) == (lower & (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (0))))))
        {

        }
        else if ((lower & (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (1))))) && !(upper & (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (1))))))
        {





                        lower &= ~((probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (0)))) | (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (1)))));
            upper |= (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (1))));
            code ^= (probability_t)(1 << ((8 * sizeof(probability_t)) - (1 + (1))));


        }
        else
        {

            return;
        }





                lower <<= 1;
        upper <<= 1;
        upper |= 1;
        code <<= 1;

        if ((nextBit = BitFileGetBit(bfpIn)) == 
# 915 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c" 3 4
                                               (-1)
# 915 "/home/fanl/compcert-lean-meta/compcert4lean/.lake/prototype/o0-regression-final/compression/arcode/lean/compression/arcode.c"
                                                  )
        {

        }
        else
        {
            code |= nextBit;
        }
    }

    return;
}
